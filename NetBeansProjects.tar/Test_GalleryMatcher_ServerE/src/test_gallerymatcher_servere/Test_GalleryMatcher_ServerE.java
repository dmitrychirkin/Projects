/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test_gallerymatcher_servere;

import tech5.com.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 *
 * @author dmitry
 */
public class Test_GalleryMatcher_ServerE {
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";
    
    public static final String ANSI_BLACK_BACKGROUND = "\u001B[40m";
    public static final String ANSI_RED_BACKGROUND = "\u001B[41m";
    public static final String ANSI_GREEN_BACKGROUND = "\u001B[42m";
    public static final String ANSI_YELLOW_BACKGROUND = "\u001B[43m";
    public static final String ANSI_BLUE_BACKGROUND = "\u001B[44m";
    public static final String ANSI_PURPLE_BACKGROUND = "\u001B[45m";
    public static final String ANSI_CYAN_BACKGROUND = "\u001B[46m";
    public static final String ANSI_WHITE_BACKGROUND = "\u001B[47m";    
    
    static class folderContent
    {
        /**
         * folder name
         */
        public String dirName;
        /**
         * list of files
         */
        public ArrayList<String> fileName;
        public folderContent()
        {
            dirName = "";
            fileName = new ArrayList<String>();
        }
    }

    public static ArrayList<folderContent> getListFiles(String parentFolder, String[] ext, boolean goToSubdirs)
    {
        String currentFolder = "";
        File f = null;
        int pos = parentFolder.lastIndexOf("/");
        if(pos == -1)
            pos = parentFolder.lastIndexOf("\\");
        if(pos > 0)
            currentFolder = parentFolder.substring(pos+1);
        else
            currentFolder = parentFolder;
        folderContent currDir = new folderContent();
        currDir.dirName = currentFolder;
        ArrayList<folderContent> resultList = new ArrayList<folderContent>();
        try
        {
            f = new File(parentFolder);
            for (File s : f.listFiles())
            {
                if (s.isFile())
                {
                    if( ext == null || ext.length == 0)
                        currDir.fileName.add(s.getAbsolutePath());
                    else
                    {
                        for(int i = 0; i < ext.length; i++)
                        {
                            if(s.getName().endsWith(ext[i]))
                            {
                                currDir.fileName.add(s.getAbsolutePath());
                                break;
                            }
                        }
                    }
                }
                else if (s.isDirectory()  && goToSubdirs)
                {
                    resultList.addAll( getListFiles(s.getAbsolutePath(), ext, goToSubdirs));
                }
            }
        }
        catch(Exception ex)
        {
            System.out.printf(ANSI_RED + " Error : %s\n", ex.getMessage() + ANSI_RESET);
        }
        resultList.add(currDir);
        return resultList;
    }
    
    static byte[] readFile(String fileName)
    {
        byte[] buffer = null;
        int length = 0;
        try
        {
            File f = new File(fileName);
            if(!f.exists())
                return null;
            length = (int)f.length();
            buffer = new byte[length];
            InputStream in = new FileInputStream(f);
            length = in.read (buffer);
            in.close();
        }
        catch(Exception ex)
        {
            
        }
        return buffer;
    }
    
    static void readAllTemplates(ArrayList<String> fileName, byte[][] fpTemplate)
    {
        for(int finger = 0; (finger < fileName.size()) && (finger < 10) ; finger++)
        {
            fpTemplate[finger] = readFile (fileName.get(finger));
            if( fpTemplate[finger] == null)
            {
                System.out.println("cannot read file : " +  fileName.get(finger));
            }
        }
    }

    public static class CreateTemplateThread implements Runnable
    {
        TemplateCreator m_creator = null;
        String[] m_wsqFilename = null;
        int m_fingpos = FINGERS.FINGPOS_UK;
        
        @Override
        public void run()
        {
            try
            {
                int finger_position;
                for(int i = 0; i < m_wsqFilename.length; i++)
                {
                    WsqImage m_wsq = null;
                    if(m_fingpos == -1)
                        finger_position = i+1;
                    else
                        finger_position = m_fingpos;
                    System.out.println("Thread #" + finger_position +" Reading file : " + m_wsqFilename[i]);
                    m_wsq = new WsqImage(finger_position,readFile(m_wsqFilename[i]));
                    
                    Integer tplSize = new Integer(0);
                    Byte tplQuality = new Byte((byte)0);
                    int retVal = m_creator.createTemplate(m_wsq, tplSize, tplQuality);
                    if( retVal == ErrorCodes.SUCCESS)
                        System.out.println("Success creating template size = " + tplSize.toString() + " quality = " + tplQuality.toString());
                    else
                        System.out.println("Error of template building = " + retVal);
                }
            }
            catch(Exception ex)
            {
                System.out.println(ANSI_RED + " From thread error is " + ex.getMessage() + ANSI_RESET);
            }
        }

        public CreateTemplateThread(String license, String[] wsqFilename, int fingpos)
        {
            try
            {
                m_creator = new TemplateCreator();
                if( !m_creator.create() )
                    throw new Exception("create failed");
                if( !m_creator.initLicense(license))
                    throw new Exception("Error of license :" + license);
                m_wsqFilename = wsqFilename;
                m_fingpos = fingpos;
            }
            catch(Exception ex)
            {
                System.out.println("CreateTemplateThread error!");
            }
        }
    }

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        // TODO code application logic here
        String[] libNative = new String[2];
        libNative[1] = "Tech5_GalleryMatcher_ServerE_jni_d_x64";
        libNative[0] = "Tech5_GalleryMatcher_ServerE_d_x64";

        Matcher m_matcher = null;
        TemplateCreator m_creator = null;
        FpTemplateChecker m_checker = null;
        
        MatchingParameters m_param = null;
        ArrayList<candidates_string> candidates = null;
        TpTemplate pTemplProbe = null;
        
        ArrayList<folderContent> fileList = null;
        boolean goToSubdirs = true;
        String[] ext = null;
        
        String licensePath = "C:\\Users\\dmitry\\Documents\\tech5_gallery_matcher.lic";
        String baseName = "D:/home/test";
        
        int poolSize = 6;
        ExecutorService service = Executors.newFixedThreadPool(poolSize);
        List<Future<Runnable>> futures = null;
        
        System.out.println(ANSI_BLUE + "Start program" + ANSI_RESET);
        
        try
        {
            for( int i=0; i < libNative.length; i++)
                System.loadLibrary(libNative[i]);
            
            m_param = new MatchingParameters();
            pTemplProbe = new TpTemplate();
            m_matcher = new Matcher();
            if( !m_matcher.create())
                throw new Exception("create failed");
            if( !m_matcher.initLicense(licensePath))
                throw new Exception("Error of license :" + licensePath);
            
            String iD = "0";
            fileList = new ArrayList<folderContent>();
            ext = new String[2];
            ext[0] = ".tpl";
            ext[1] = ".TPL";
            

            fileList = getListFiles(baseName+"/temp1",ext,goToSubdirs);
            for(int i = 0; i < fileList.size(); i++)
            {
                folderContent folderInfo = new folderContent();
                folderInfo = fileList.get(i);
                TpTemplate pTempl = new TpTemplate();
                readAllTemplates(folderInfo.fileName, pTempl.templ);
                if( ErrorCodes.SUCCESS == m_matcher.insertRecord(folderInfo.dirName, pTempl))
                {
                    System.out.println("Records for ID = " + folderInfo.dirName + " were inserted");                    
                }
                if( i == 0)
                {
                    if(pTempl.templ[5] != null)
                    {
                        pTemplProbe.templ[5] = new byte[pTempl.templ[5].length];
                        System.arraycopy(pTempl.templ[5], 0, pTemplProbe.templ[5], 0, pTempl.templ[5].length);
                    }
                    if(pTempl.templ[6] != null)
                    {
                        pTemplProbe.templ[6] = new byte[pTempl.templ[6].length];
                        System.arraycopy(pTempl.templ[6], 0, pTemplProbe.templ[6], 0, pTempl.templ[6].length);
                    }
                    if(pTempl.templ[7] != null)
                    {
                        pTemplProbe.templ[7] = new byte[pTempl.templ[7].length];
                        System.arraycopy(pTempl.templ[7], 0, pTemplProbe.templ[7], 0, pTempl.templ[7].length);
                    }
                }
            }
            iD = "1";
            int retCode = m_matcher.insertRecord(iD, pTemplProbe);
            if( ErrorCodes.SUCCESS == retCode)
            {
                System.out.println("Records are inserted");
                Double score = new Double(0.0);
                if( ErrorCodes.SUCCESS == m_matcher.verify_record(m_param, pTemplProbe, pTemplProbe, score))
                {
                    System.out.println("Verified with score = " + score.toString());
                }
                else
                    System.out.println("Error of verifying");

                if( (candidates = m_matcher.identify_record(m_param,pTemplProbe,1,10)) != null)
                {
                    for( int i = 0; i < candidates.size(); i++)
                        System.out.println("Candidtae " + candidates.get(i).uid + " Identified with score " + candidates.get(i).score);
                }
                else
                    System.out.println("Error of identifying");
            }
            else
            {
                System.out.println(ANSI_YELLOW + "Error of inserting record for ID: "+ iD + " code : "+ retCode + ANSI_RESET);
            }
            
            System.out.println("Records count : " + m_matcher.getFinalGallerySize());
            
            
/*
            m_creator = new TemplateCreator();
            if( !m_creator.create() )
                throw new Exception("create failed");
            if( !m_creator.initLicense(licensePath))
                throw new Exception("Error of license :" + licensePath);
*/
            fileList.clear();
            ext[0] = ".wsq";
            ext[1] = ".WSQ";
            
            fileList = getListFiles(baseName+"/NIST14/images",ext,goToSubdirs);

            futures = new ArrayList<Future<Runnable>>();
            
            String[][] image_names = null;
            int files_in_queue = 10;
            for(int i = 0; i < fileList.size(); i++)
            {
                int files_count = fileList.get(i).fileName.size();
                if( files_count < 1)
                    continue;
                int thread_count = files_count/files_in_queue;
                if( files_count - thread_count*files_in_queue ==  0)
                    image_names = new String[thread_count][files_in_queue];
                else
                {
                    image_names = new String[thread_count+1][];
                    for(int j = 0; j < thread_count; j++)
                        image_names[j] = new String[files_in_queue];
                    image_names[thread_count] = new String[files_count - thread_count*files_in_queue];
                    thread_count =  thread_count + 1;
                }
                
                for(int k = 0; k < thread_count; k++)
                {
                    for(int n = 0; n < files_in_queue; n++)
                    {
                        if(k*files_in_queue + n < files_count)
                            image_names[k][n] = fileList.get(i).fileName.get(k*files_in_queue+n);
                    }
                }
                for(int j = 0; j < thread_count; j++)
                {
                    Future f = service.submit(new CreateTemplateThread(licensePath,image_names[j],-1));
                    futures.add(f);
                    
                    /*
                    WsqImage m_wsq = null;
                    m_wsq = new WsqImage(FINGERS.FINGPOS_RI,readFile(fileList.get(i).fileName.get(j)));
                    
                    Integer tplSize = new Integer(0);
                    Byte tplQuality = new Byte((byte)0);
                    int retVal = m_creator.createTemplate(m_wsq, tplSize, tplQuality);
                    if( retVal == ErrorCodes.SUCCESS)
                        System.out.println("Success creating template from " + fileList.get(i).fileName.get(j) + " size = " + tplSize.toString() + " quality = " + tplQuality.toString());
                    else
                        System.out.println("Error of template building = " + retVal);
                    */
                    /*
                    RawImage m_raw = null;
                    m_raw = new RawImage(FINGERS.FINGPOS_RI,320,480,readFile(fileList.get(i).fileName.get(j)));
                    
                    Integer tplSize = new Integer(0);
                    Byte tplQuality = new Byte((byte)0);
                    int retVal = m_creator.createTemplate(m_raw, tplSize, tplQuality);
                    if( retVal == ErrorCodes.SUCCESS)
                        System.out.println("Success creating template from " + fileList.get(i).fileName.get(j) + " size = " + tplSize.toString() + " quality = " + tplQuality.toString());
                    else
                        System.out.println("Error of template building = " + retVal);
                    */
                }
            }
            
            // wait for all tasks to complete before continuing
            for (Future<Runnable> f : futures)
            {
                f.get();
            }

            m_checker = new FpTemplateChecker();
            if( !m_checker.create() )
                throw new Exception("create failed");
            for( int i = 0; i < pTemplProbe.templ.length; i++)
            {
                if( pTemplProbe.templ[i]!= null) 
                {
                    if( m_checker.check(pTemplProbe.templ[i]) )
                        System.out.println("Template #" + i + " is good!");
                    else
                        System.out.println("Template #" + i + " is bad!");
                }
            }

            System.out.println(ANSI_GREEN + "All is Success" + ANSI_RESET);
        }
        catch(Exception ex)
        {
            System.out.println(ANSI_RED + ex.getMessage() + ANSI_RESET);
        }
        
        if( m_checker != null)
            m_checker.cancel();
        if( m_creator!= null)
            m_creator.cancel();
        if( m_matcher != null)
            m_matcher.cancel();
        //shut down the executor service so that this thread can exit
        service.shutdownNow();
        System.out.println(ANSI_BLUE + "End of program" + ANSI_RESET);
    }    
}
