/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech5.com;

/**
 *
 * @author dmitry
 */
public class TpTemplate    
{
    public static final int MAX_TEMPLATE_SIZE = 12*1024;
    public byte[][] templ = new byte[10][];              // TECH5 template each of 10 fingers
    public TpTemplate()
    {
        clear();
    }
    public TpTemplate(TpTemplate tp)
    {
        for(int finger = 0; finger < 10; finger++)
        {
            if(tp.templ[finger] != null)
            {
                this.templ[finger] = new byte[tp.templ[finger].length];
                System.arraycopy(tp.templ[finger], 0, this.templ[finger], 0, tp.templ[finger].length);
            }
            else
                this.templ[finger] = null;
        }
    }
    void clear()
    {
        for(int finger = 0; finger < 10; finger++)
            templ[finger] = null;
    }
}
