/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech5.com;
import java.lang.Byte;
import java.lang.Integer;


/**
 *
 * @author Dmitry Chirkin
 * @version 2.0.0
 */
public class TemplateCreator {
    
    long m_sdk = 0;
    
    public TemplateCreator()
    {
        m_sdk = 0;
    }

    /**
     * create object of TemplateCreator
     * @return Return false in case of error
     */
    public boolean create()
    {
        m_sdk = create_();
        if( m_sdk == 0)
            return false;
        else
            return true;
    }
    native long create_();
            
    /**
     * delete object of TemplateCreator
     */
    public void cancel()
    {
        if( m_sdk != 0)
            cancel_(m_sdk);
        m_sdk = 0;
    }
    native void cancel_(long sdk);
    
    /**
     * 
     * Function set license
     * Parameters:
     * @param licensePath (input) - path to the license file
     * @return  Return value:
     * true if success and false otherwise
     */
    public boolean initLicense(String licensePath)
    {
        if( m_sdk != 0)
            return initLicense_(m_sdk, licensePath);
        else
            return false;
    }
    native boolean initLicense_(long sdk, String licensePath);
    
    /**
     * Function build template from image in RAW format 
     * Parameters:
     * @param image ( input) - fingerprint image in RAW format. Image should be 500 DPI, 256 greyscale leveles
     * @param templateSize (output) - size of builded template
     * @param quality      (output) - quality of fingerprint image
     * @return Return value:
     * SUCCESS if success and error code otherwise
     */
      public int createTemplate (RawImage image, Integer templateSize, Byte quality)
      {
          if( m_sdk != 0)          
              return createTemplate_(m_sdk, image,templateSize,quality);
          else
              return ErrorCodes.WRONG_PARAMETRS;
      }
      native int createTemplate_(long sdk, RawImage image, Integer templateSize, Byte quality);
     
    /**
     * Function build template from image in WSQ format 
     * Parameters:
     * @param image ( input) - fingerprint image in WSQ format. Image should be 500 DPI, 256 greyscale leveles
     * @param templateSize (output) - size of builded template
     * @param quality      (output) - quality of fingerprint image
     * @return Return value:
     * SUCCESS if success and error code otherwise
     */
      public int createTemplate (WsqImage image, Integer templateSize, Byte quality)
      {
          if( m_sdk != 0)
          {
              return createTemplate_(m_sdk, image, templateSize,quality);
          }
          else
              return ErrorCodes.WRONG_PARAMETRS;
      }
      native int createTemplate_(long sdk, WsqImage image, Integer templateSize, Byte quality);

      /**
       * Function copy template builded by one of 'createTemplate' function
       * to the 'fpTemplate' buffer
       * Parameters:
       * @param fpTemplate   ( input/output) - pointer to the buffer where fingerprint template will be copied. 
       * Memory for that buffer should be allocated in application based on templateSize value, returned by 
       * 'createTemplate' function
       */
      public void getTemplate(byte[] fpTemplate)
      {
          if( m_sdk != 0)
              getTemplate_(m_sdk, fpTemplate);
      }
      native void getTemplate_(long sdk, byte[] fpTemplate);
}
