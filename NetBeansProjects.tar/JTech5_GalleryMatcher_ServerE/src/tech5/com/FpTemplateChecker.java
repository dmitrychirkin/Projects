/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech5.com;

/**
 *
 * @author Dmitry Chirkin
 * @version 2.0.0
 */
public class FpTemplateChecker {
    
    long m_sdk = 0;
    
    public FpTemplateChecker()
    {
        m_sdk = 0;
    }
    
    /**
     * create object of FpTemplateChecker
     * @return false in case of error
     */
    public boolean create()
    {
        m_sdk = create_();
        if(  m_sdk != 0 )
            return true;
        else
            return false;
    }
    native long create_();
    /**
     * delete object of FpTemplateChecker
     */
    public void cancel()
    {
        if( m_sdk != 0)
            cancel_(m_sdk);
        m_sdk = 0;
    }
    native void cancel_(long sdk);

      /**
       * Function check  fingerprint template - if it has a right format and in good health
       * Parameters:
       * @param fpTemplate   ( input) - fingerprint template for checking
       * @return Return value:
       * true if template is OK and false  otherwise
       */
    public boolean check (byte[] fpTemplate)
    {
        if( m_sdk!= 0)
            return check_(m_sdk,fpTemplate);
        else
            return false;
    }
    native boolean check_(long sdk, byte[] fpTemplate);
}
