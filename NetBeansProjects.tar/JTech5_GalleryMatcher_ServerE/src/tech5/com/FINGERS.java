/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech5.com;

/**
 *
 * @author dmitry
 */
public class FINGERS {
    /**
     * Unknown finger
     */
    public static final int FINGPOS_UK     =  0;
    /**
     * Right thumb    
     */
    public static final int FINGPOS_RT     =  1;
    /**
     * Right index finger
     * 
     */
    public static final int FINGPOS_RI     =  2;
    /**
     * Right middle finger
     * 
     */
    public static final int FINGPOS_RM     =  3;
    /**
     * Right ring finger
     * 
     */
    public static final int FINGPOS_RR     =  4;
    /**
     * Right little finger
     * 
     */
    public static final int FINGPOS_RL     =  5;
    /**
     * Left thumb
     * 
     */
    public static final int FINGPOS_LT     =  6;
    /**
     * Left index finger
     * 
     */
    public static final int FINGPOS_LI     =  7;
    /**
     * Left middle finger
     * 
     */
    public static final int FINGPOS_LM     =  8;
    /**
     * Left ring finger
     * 
     */
    public static final int FINGPOS_LR     =  9;
    /**
     * Left little finger    
     * 
     */
    public static final int FINGPOS_LL     =  10;
    }
