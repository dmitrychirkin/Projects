/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech5.com;

/**
 *
 * @author dmitry
 */
public class FUSION_MODE {
    /**
     * Method, optimised for reach the best ROC and CMC
     */
    public static final int OPTIMAL_FUSION_MODE     = 0;
    
    /**
     * Resulting scores from every finger are separated in 3 bins
     * by low and high thresholds (from SearchParams)
     * scores are sorted by increase, and only scores from lowest bin
     * are used in calculating cumulative score
     * (s1*8+s2*4+s3*2+s4)/(8+4+2+1)
     */

    public static final int   LOW_BINNING_FUSION_MODE = 1;
    /**
     * Same as LOW_BINNING, except that sorting is done by decrease,
     * and scores from highest bin are used.
     */
    public static final int HIGH_BINNING_FUSION_MODE = 2;
}
