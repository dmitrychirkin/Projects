/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech5.com;

/**
 *
 * @author dmitry
 */
public class RawImage {
    public int      m_finger;   // finger position
    public int      m_width;   // image width, pixels 
    public int      m_height;   // image height, pixels
    public byte[]   m_image;   // image buffer

    public RawImage()
    {
        m_finger = FINGERS.FINGPOS_UK;
        m_width = 0;
        m_height = 0;
        m_image = null;
    }
    public RawImage( RawImage rawImage)
    {
        m_finger = rawImage.m_finger;
        m_width = rawImage.m_width;
        m_height = rawImage.m_height;
        m_image = new byte[rawImage.m_image.length];
        System.arraycopy(rawImage.m_image,0, m_image,0,rawImage.m_image.length);
    }

    public RawImage(int fingpos, int width , int height, byte[] image)
    {
        m_finger = fingpos;
        m_width = width;
        m_height = height;
        m_image = new byte[m_width*m_height];
        System.arraycopy(image,0, m_image,0,image.length);
    }
}
