/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech5.com;

/**
 *
 * @author dmitry
 */

public class MATCHING_MODE
{
    /**   
     * in this mode all probe finger positions will be matched only
     * with corresponded gallery finger positions
     */

    public static final int NORMAL_MATCHING_MODE = 0;
    /**
     * check if some finger were mixed. In this mode
     * matching process will check all possible 
     * combination of probe and gallery fingers and 
     * choose the combination of probe and gallery fingers 
     * that give the max fusion score
     */
    public static final int CHECK_MIX_FINGER_MATCHING_MODE   = 1;
    /**
     * check if slaps were mixed. 
     */ 
    public static final int CHECK_MIX_SLAP_MATCHING_MODE     = 2;
    /**
     * check if hand (slaps and/or thumbs) were mixed. 
     */
    public static final int CHECK_MIX_HAND_MATCHING_MODE     = 3;   
}
