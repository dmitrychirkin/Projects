/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech5.com;

/**
 *
 * @author dmitry
 */

public class candidates_string
{
    public String uid;
    public float score;
    public candidates_string(String uiD, float sCore)
    {
        uid = uiD; score = sCore;
    }
    public candidates_string()
    {
        uid = "0";
        score = 0.0f;
    }
}
