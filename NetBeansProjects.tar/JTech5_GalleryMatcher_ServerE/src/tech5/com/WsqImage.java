/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech5.com;

/**
 *
 * @author dmitry
 */
public class WsqImage {
    public int   m_finger;           // finger position
    public int   m_size;             // size of wsq image    
    public byte[] m_wsq;              // wsq image buffer 
    
    public WsqImage()
    {
        m_finger = 0;           // finger position
        m_size = 0;             // size of wsq image    
        m_wsq = null;              // wsq image buffer         
    }
    public WsqImage( WsqImage wsq)
    {
        this.m_finger = wsq.m_finger;           // finger position
        this.m_size = wsq.m_size;             // size of wsq image    
        this.m_wsq = new byte[m_size];
        System.arraycopy(wsq.m_wsq,0, this.m_wsq,0,this.m_size);
    }

    public WsqImage(int fingpos, byte[] image)
    {
        m_finger = fingpos;           // finger position
        m_size = image.length;             // size of wsq image   
        m_wsq = new byte[m_size];
        System.arraycopy(image,0, m_wsq,0,m_size);
    }
}
