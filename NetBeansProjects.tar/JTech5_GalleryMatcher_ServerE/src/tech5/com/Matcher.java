/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech5.com;
import java.lang.Double;
import java.util.ArrayList;

/**
 *
 * @author Dmitry Chirkin
 * @version 2.0.0
 */
public class Matcher
   {
       long m_sdk;
       
       /**
        * create object of Matcher. Return NULL in case of error
        * 
        */
       public Matcher()
       {
           m_sdk = 0;
       }
      
      /**
       * create object of Matcher
       * @return Return false in case of error
       */
       public boolean create()
       {
           m_sdk = create_();
           if( m_sdk == 0)
               return false;
           else
               return true;
       }
       native long create_();
       
       /**
        * delete object of Matcher
        * 
        */
       public void cancel()
       {
           if( m_sdk != 0)
               cancel_(m_sdk);
           m_sdk = 0;
       }
       native void cancel_(long sdk);
       
       /**
        * Function set license
        * 
        * @param  licensePath (input) - path to the license file
        * @return true if success and false otherwise
        */
       public boolean initLicense(String licensePath)
       {
           if( m_sdk != 0)
               return initLicense_(m_sdk, licensePath);
           else
               return false;
       }
       native boolean initLicense_(long sdk, String licensePath);
       /**
        * Function verify two records, each of them can have from 1 till 10 fingerprints
        * @param matchingParameters ( input) - matching parameters
        * @param tpTemplate1        ( input) - first  10-finger template record. It can have from 1 till 10 fingerprint templates.
        * @param tpTemplate2        ( input) - second 10-finger template record. It can have from 1 till 10 fingerprint templates.
        * @param score              (output) - similarity of two records in a range 0...1
        * 
        * @return  SUCCESS if success and error code otherwise
        */
       public long verify_record( MatchingParameters matchingParameters,
               TpTemplate tpTemplate1,
               TpTemplate tpTemplate2,
               Double score)
       {
           if( m_sdk!= 0)
               return verify_record_(m_sdk,matchingParameters,tpTemplate1.templ,tpTemplate2.templ,score);
           else
               return ErrorCodes.WRONG_PARAMETRS;
       }
       native long verify_record_( long sdk, MatchingParameters matchingParameters,
                                           byte[][] tpTemplate1, byte[][] tpTemplate2,Double score);
       
       /**
        * Function insert record in memory database
        * Parameters:
        * @param id         ( input) - unique record ID. NOTE: id - should be numerical only!
        * @param tpTemplate ( input) - 10-finger template record. It can have from 1 till 10 fingerprint templates.
        * @return Return value:
        * SUCCESS if success and error code otherwise
        */
       public int insertRecord (String id, TpTemplate tpTemplate)
       {
           if( m_sdk != 0 )
               return insertRecord_(m_sdk, id, tpTemplate.templ);
           else
               return ErrorCodes.WRONG_PARAMETRS;
       }
       native int insertRecord_(long sdk, String id, byte[][] tpTemplate);
       /**
        * Function delete record from memory database
        * Parameters:
        * @param id         ( input) - unique record ID. NOTE: id - should be numerical only!
        * @return  Return value:
        * number of removed records
        */
       public int deleteRecord (String id)
       {
           if( m_sdk != 0)
               return deleteRecord_(m_sdk,id);
           return ErrorCodes.WRONG_PARAMETRS;
       }
       native int deleteRecord_(long sdk,String id);
       /**
        * Function return current gallery size
        * @return current gallery size
        */
       public long getFinalGallerySize()
       {
           if( m_sdk != 0 )
               return getFinalGallerySize_(m_sdk);
           else
               return ErrorCodes.WRONG_PARAMETRS;
       }
       native long getFinalGallerySize_(long sdk);
       /**
        * Function perform identification 
        * Parameters:
        * @param matchingParameters    ( input) - matching parameters
        * @param probe                 ( input) - probe 10-finger record. It can have from 1 till 10 fingerprint templates.
        * @param numberOfThreads       ( input) - number of threads that will be used in matching. 
        * 0 - means use all logical CPU (the value returned by omp_get_num_procs())
        * @param candidate_list_length ( input) - size of output candidate list
        * @return  output candidate list on SUCCESS or null otherwise
        */
       public ArrayList<candidates_string> identify_record(   MatchingParameters matchingParameters,
                                    TpTemplate                     probe,
                                    int                  numberOfThreads, 
                                    int                  candidate_list_length 
                                    )
       {
           if( m_sdk != 0 )
               return identify_record_(m_sdk,matchingParameters,probe.templ,numberOfThreads, candidate_list_length);
           else
               return null;
       }
       native ArrayList<candidates_string> identify_record_(long sdk,  MatchingParameters matchingParameters, 
                                    byte[][]                     probe,
                                    int                  numberOfThreads, 
                                    int                  candidate_list_length 
                                    );
   };
