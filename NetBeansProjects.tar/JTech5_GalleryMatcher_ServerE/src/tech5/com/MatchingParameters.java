/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech5.com;

import tech5.com.MATCHING_MODE;
/**
 *
 * @author dmitry
 */
public class MatchingParameters {
    
   public final static int MATCHING_SPEED_DEF = 3;
   public final static int MAX_ANGLE_DEF      = 180;
    
    
   // search speed. The current valid value from 0 to 7
   public int   searchSpeed;  
   // the maximum of the finger turn angle for all fingers expcept thumbs, (0...180 degree)
   public int   maxAngle;     
   // the maximum of the finger turn angle for thumbs, (0...180 degree)
   public int   maxAngleThumbs;     
   public int  matchingMode;

   public MatchingParameters()
   {
      searchSpeed                   = MATCHING_SPEED_DEF ;
      maxAngle                      = MAX_ANGLE_DEF      ;
      maxAngleThumbs                = MAX_ANGLE_DEF      ;
      matchingMode                  = MATCHING_MODE.NORMAL_MATCHING_MODE;
   }
}
