/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tech5.com;

/**
 *
 * @author dmitry
 */
public class ErrorCodes {
   public static final int SUCCESS                    =  0;
   public static final int LICENSE_FILE_NAME_INVALID  =  1;               
   public static final int LOW_MEMORY                 =  2;  
   public static final int IMAGE_TOO_BIG              =  3;       // image width > MAX_WIDTH  or image height > MAX_HEIGHT
   public static final int NO_IMAGE                   =  4;       // image size = 0, or pointer to the image = 0 or image processing cannot find any fingerprint image 
   public static final int IMAGE_PROCESSING_FAILED    =  5;       // image processing error  
   public static final int WRONG_FINGER_POS           =  6;       // wrong finger position was passed to the image processing 
   public static final int WSQ_INIT_FAILED            =  7;       // error of WSQ library initialization
   public static final int WRONG_WSQ_IMAGE            =  8;       // error of parsing WSQ image 
   public static final int WSQ_FAILED                 =  9;       // WSQ decompressing error
   public static final int VERIFICATION_FAILED        = 10;       // verification error  
   public static final int WRONG_TEMPLATE             = 11;       // fingerprint template parsing error
   public static final int NO_SAME_FINGERS            = 12;       // two 10-fingerprint templates have no fingerprint templates for same finger position
   public static final int WRONG_PARAMETRS            = 13;       // wrong matching parameters
   public static final int UNPACK_INIT_FAILED         = 14;       // error of unpack library initialization      
   public static final int ACCEL_CORRUPT              = 15;       // accelerator template is corrupted  
   public static final int NOT_SUPPORT_SSE3           = 16;       // the CPU is not support SSE3
   public static final int ACCEL_CALC_ERR             = 17;       // accel calculation error
   public static final int NO_FINGERS_GOOD_FOR_ACCEL  = 18;    
   public static final int ACCEL_MATCHING_FAILED      = 19;       // accelerator matching failed  
   public static final int DOUBLE_ID                  = 20;       // record with such ID already exist in database
   public static final int IDENTIFICATION_FAILED      = 21;       // identifation error 

   public static final int UNKNOWN_EXCEPTION          = 100;     // unknown exception thrown
  
}
