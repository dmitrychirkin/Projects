/*
 *  gosthash.h 
 *   
 *  GOST R 34.11-94, Russian Standard Hash Function 
 *  header with function prototypes.
 *
 */

#ifndef GOSTHASH_H
#define GOSTHASH_H

#include <stdlib.h>

#include "data_types.h"

#if defined( _WINDOWS ) || defined(_WIN32_WCE)
#  define CIPHER_PACKED_1
#elif defined( linux )
#  define CIPHER_PACKED_1 __attribute__ ((aligned(1),packed))
#elif defined( ANDROID )
#  define CIPHER_PACKED_1 __attribute__ ((aligned(1),packed))
#else
#  error Cannot determine alligment - contact your vendor for support
#endif

#if defined (_WINDOWS) || defined(_WIN32_WCE)
#pragma pack(push,1)
#endif

/* State structure */

typedef struct CIPHER_PACKED_1 GOSTHASHCTX
{
  snd_ulong sum[8];
  snd_ulong hash[8];
  snd_ulong len[8];
  snd_char partial[32];
  snd_uint partial_bytes;  
} GostHashCtx;

#if defined (_WINDOWS) || defined(_WIN32_WCE)
#pragma pack(pop)
#endif

/* Compute some lookup-tables that are needed by all other functions. */

void gosthash_init();     

/* Clear the state of the given context structure. */

void gosthash_reset(GostHashCtx* ctx);  

/* Mix in len bytes of data for the given buffer. */

void gosthash_update(GostHashCtx* ctx, const snd_char* buf, snd_uint len);

/* Compute and save the 32-byte digest. */

void gosthash_final(GostHashCtx* ctx, snd_char* digest);

#endif /* GOSTHASH_H */
