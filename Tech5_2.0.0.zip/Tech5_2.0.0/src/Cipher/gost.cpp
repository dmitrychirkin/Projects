#include <stdio.h>
#include <memory.h>
#include <cipher.h>
#include "gosthash.h"

const snd_int BLOCK_SIZE = 8;

#if defined (_WINDOWS) || defined(_WIN32_WCE)
#pragma pack(push,1)
#endif

typedef struct CIPHER_PACKED_1 GOST_CTX{
	snd_ulong k[8];
	snd_char k87[256], k65[256], k43[256], k21[256];
} gost_ctx;

#if defined (_WINDOWS) || defined(_WIN32_WCE)
#pragma pack(pop)
#endif

void gost_enc(gost_ctx*, snd_ulong*, snd_int);
void gost_dec(gost_ctx*, snd_ulong*, snd_int);
void gost_key(gost_ctx*, snd_ulong*);
void gost_init(gost_ctx*);
void gost_destroy(gost_ctx*);
void gost_hash(const snd_char* password, snd_int passwordLength, snd_char* key);

void gost_destroy( gost_ctx *c)
{
	for(snd_int i = 0; i < 8; i++)
		c->k[i] = 0;
}

void gost_init( gost_ctx *c)
{
	snd_byte k8[16] = { 14,  4, 13,  1,  2, 15, 11,  8,  3, 10,  6, 12,  5,  9,  0,  7};
	snd_byte k7[16] = { 15,  1,  8, 14,  6, 11,  3,  4,  9,  7,  2, 13, 12,  0,  5, 10};
	snd_byte k6[16] = { 10,  0,  9, 14,  6,  3, 15,  5,  1, 13, 12,  7, 11,  4,  2,  8};
	snd_byte k5[16] = {  7, 13, 14,  3,  0,  6,  9, 10,  1,  2,  8,  5, 11, 12,  4, 15};
	snd_byte k4[16] = {  2, 12,  4,  1,  7, 10, 11,  6,  8,  5,  3, 15, 13,  0, 14,  9};
	snd_byte k3[16] = { 12,  1, 10, 15,  9,  2,  6,  8,  0, 13,  3,  4, 14,  7,  5, 11};
	snd_byte k2[16] = {  4, 11,  2, 14, 15,  0,  8, 13,  3, 12,  9,  7,  5, 10,  6,  1};
	snd_byte k1[16] = { 13,  2,  8,  4,  6, 15, 11,  1, 10,  9,  3, 14,  5,  0, 12,  7};
	
	for( snd_int i = 0; i < 256; i++)
	{
		c->k87[i] = k8[i >> 4] << 4 | k7[i & 15];
		c->k65[i] = k6[i >> 4] << 4 | k5[i & 15];
		c->k43[i] = k4[i >> 4] << 4 | k3[i & 15];
		c->k21[i] = k2[i >> 4] << 4 | k1[i & 15];
	}
}

static snd_ulong gost_f(gost_ctx* c, snd_ulong x)
{
	x = c->k87[x>>24 & 255] << 24 | c->k65[x>>16 & 255] << 16 |
		c->k43[x>> 8 & 255] <<  8 | c->k21[x & 255];
	return x<<11 | x>>(32-11);
}

void gostcrypt(gost_ctx* c, snd_ulong* d)
{
	register snd_ulong n1 = 0, n2 = 0;

	n1 = d[0];
	n2 = d[1];

	n2 ^= gost_f(c, n1 + c->k[0]); n1 ^= gost_f(c, n2 + c->k[1]);
	n2 ^= gost_f(c, n1 + c->k[2]); n1 ^= gost_f(c, n2 + c->k[3]);
	n2 ^= gost_f(c, n1 + c->k[4]); n1 ^= gost_f(c, n2 + c->k[5]);
	n2 ^= gost_f(c, n1 + c->k[6]); n1 ^= gost_f(c, n2 + c->k[7]);

	n2 ^= gost_f(c, n1 + c->k[0]); n1 ^= gost_f(c, n2 + c->k[1]);
	n2 ^= gost_f(c, n1 + c->k[2]); n1 ^= gost_f(c, n2 + c->k[3]);
	n2 ^= gost_f(c, n1 + c->k[4]); n1 ^= gost_f(c, n2 + c->k[5]);
	n2 ^= gost_f(c, n1 + c->k[6]); n1 ^= gost_f(c, n2 + c->k[7]);

	n2 ^= gost_f(c, n1 + c->k[0]); n1 ^= gost_f(c, n2 + c->k[1]);
	n2 ^= gost_f(c, n1 + c->k[2]); n1 ^= gost_f(c, n2 + c->k[3]);
	n2 ^= gost_f(c, n1 + c->k[4]); n1 ^= gost_f(c, n2 + c->k[5]);
	n2 ^= gost_f(c, n1 + c->k[6]); n1 ^= gost_f(c, n2 + c->k[7]);

	n2 ^= gost_f(c, n1 + c->k[7]); n1 ^= gost_f(c, n2 + c->k[6]);
	n2 ^= gost_f(c, n1 + c->k[5]); n1 ^= gost_f(c, n2 + c->k[4]);
	n2 ^= gost_f(c, n1 + c->k[3]); n1 ^= gost_f(c, n2 + c->k[2]);
	n2 ^= gost_f(c, n1 + c->k[1]); n1 ^= gost_f(c, n2 + c->k[0]);

	d[0] = n2; d[1] = n1;
}

void gostdecrypt(gost_ctx* c, snd_ulong* d)
{
	register snd_ulong n1 = 0, n2 = 0;

	n1 = d[0]; n2 = d[1];

	n2 ^= gost_f(c, n1 + c->k[0]); n1 ^= gost_f(c, n2 + c->k[1]);
	n2 ^= gost_f(c, n1 + c->k[2]); n1 ^= gost_f(c, n2 + c->k[3]);
	n2 ^= gost_f(c, n1 + c->k[4]); n1 ^= gost_f(c, n2 + c->k[5]);
	n2 ^= gost_f(c, n1 + c->k[6]); n1 ^= gost_f(c, n2 + c->k[7]);

	n2 ^= gost_f(c, n1 + c->k[7]); n1 ^= gost_f(c, n2 + c->k[6]);
	n2 ^= gost_f(c, n1 + c->k[5]); n1 ^= gost_f(c, n2 + c->k[4]);
	n2 ^= gost_f(c, n1 + c->k[3]); n1 ^= gost_f(c, n2 + c->k[2]);
	n2 ^= gost_f(c, n1 + c->k[1]); n1 ^= gost_f(c, n2 + c->k[0]);

	n2 ^= gost_f(c, n1 + c->k[7]); n1 ^= gost_f(c, n2 + c->k[6]);
	n2 ^= gost_f(c, n1 + c->k[5]); n1 ^= gost_f(c, n2 + c->k[4]);
	n2 ^= gost_f(c, n1 + c->k[3]); n1 ^= gost_f(c, n2 + c->k[2]);
	n2 ^= gost_f(c, n1 + c->k[1]); n1 ^= gost_f(c, n2 + c->k[0]);

	n2 ^= gost_f(c, n1 + c->k[7]); n1 ^= gost_f(c, n2 + c->k[6]);
	n2 ^= gost_f(c, n1 + c->k[5]); n1 ^= gost_f(c, n2 + c->k[4]);
	n2 ^= gost_f(c, n1 + c->k[3]); n1 ^= gost_f(c, n2 + c->k[2]);
	n2 ^= gost_f(c, n1 + c->k[1]); n1 ^= gost_f(c, n2 + c->k[0]);

	d[0] = n2; d[1] = n1;
}

void gost_enc(gost_ctx* c, snd_ulong* d, snd_int blocks)
{
	for(snd_int i = 0; i < blocks; i++)
	{
		gostcrypt(c,d);
		d += 2;
	}
}

void gost_dec(gost_ctx* c, snd_ulong* d, snd_int blocks)
{
	for(snd_int i = 0; i < blocks; i++)
	{
		gostdecrypt(c,d);
		d += 2;
	}
}

void gost_key(gost_ctx* c,snd_ulong* k)
{
	for(snd_int i = 0; i < 8; i++)
		c->k[i] = k[i];
}

void gost_hash(const snd_char* password, snd_int passwordLength, snd_char* key)
{
	GostHashCtx hash;
	snd_char digest[32];

	gosthash_init();
	gosthash_reset(&hash);
	gosthash_update(&hash, password,(snd_ulong)passwordLength);
	gosthash_final(&hash, digest);

	memcpy(key,digest,32);
	gosthash_reset(&hash);
}

snd_bool modificator CAPIEncryptGostString(snd_char* pbSource, snd_ulong lenSource, const snd_char* szPassword, snd_ulong passwordLength, snd_char* pbDestination, snd_ulong* lenDest)
{
	snd_bool status = false;
	snd_bool init = false;
	gost_ctx gc;
	snd_ulong k[8], data[2];
	snd_int count_repeat = lenSource/BLOCK_SIZE;
	snd_int remainder = lenSource - count_repeat*BLOCK_SIZE;
	try
	{
		if(*lenDest == -1)
		{
			if(remainder)
				*lenDest = count_repeat*BLOCK_SIZE+BLOCK_SIZE;
			else
				*lenDest = count_repeat*BLOCK_SIZE;
		}
		else
		{
			*lenDest = 0;
			gost_init(&gc);
			init = true;
			gost_hash(szPassword,passwordLength,(snd_char*)k);
			gost_key(&gc,k);


			for(snd_int i = 0; i < count_repeat; i++)
			{
				snd_int size = sizeof(snd_ulong); // must be 4 bytes
				memcpy(data,pbSource + i*8,size*2);
				gost_enc(&gc,data,1);
				memcpy(pbDestination + i*8,data,size*2);
				*lenDest += size*2;
			}
			if(remainder)
			{
				memset(data,0,8);
				memcpy(data,pbSource+count_repeat*8,remainder);
				gost_enc(&gc,data,1);
				memcpy(pbDestination+count_repeat*8,data,8);
				*lenDest += 8;
			}
		}
		status = true;
	}
	catch(...)
	{
		status = false;
	}
	if(init)
	gost_destroy(&gc);
	return status;
}

snd_bool modificator CAPIDecryptGostString(snd_char* pbSource, snd_ulong lenSource, const snd_char* szPassword, snd_ulong passwordLength, snd_char* pbDestination, snd_ulong* lenDest)
{
	snd_bool status = false;
	snd_bool init = false;
	gost_ctx gc;
	snd_ulong k[8], data[2];
	snd_int count_repeat = lenSource/BLOCK_SIZE;
	snd_int remainder = lenSource - count_repeat*BLOCK_SIZE;
	try
	{
		if(*lenDest == -1)
		{
			if(remainder)
				*lenDest = count_repeat*BLOCK_SIZE+BLOCK_SIZE;
			else
				*lenDest = count_repeat*BLOCK_SIZE;
		}
		else
		{
			*lenDest = 0;
			gost_init(&gc);
			init = true;
			gost_hash(szPassword,passwordLength,(snd_char*)k);
			gost_key(&gc,k);


			for(snd_int i = 0; i < count_repeat; i++)
			{
				snd_int size = sizeof(snd_ulong); // must be 4 bytes
				memcpy(data,pbSource + i*8,size*2);
				gost_dec(&gc,data,1);
				memcpy(pbDestination + i*8,data,size*2);
				*lenDest += size*2;
			}
			if(remainder)
			{
				memset(data,0,8);
				memcpy(data,pbSource+count_repeat*8,remainder);
				gost_dec(&gc,data,1);
				memcpy(pbDestination+count_repeat*8,data,8);
				*lenDest += 8;
			}
		}
		status = true;
	}
	catch(...)
	{
		status = 0;
	}
	if(init)
	gost_destroy(&gc);
	return status;
}
