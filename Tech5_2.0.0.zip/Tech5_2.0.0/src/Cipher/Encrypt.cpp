#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <cipher.h>
#include "common_cipher.h"

void swap_byte(snd_uchar& x,snd_uchar& y)
{
	snd_uchar t = 0;
	t = x;
	x = y;
	y = t;
}


void prepare_key(snd_uchar *key_data_ptr, snd_int key_data_len, rc4_key *key)
{
	snd_uchar index1 = 0;
	snd_uchar index2 = 0;
	snd_uchar* state = 0;
	snd_int counter = 0;

	state = &(key->state[0]);

	state[  0] =   2;	state[  1] =   3;	state[  2] =   0;	state[  3] =   1;	state[  4] =   5;	state[  5] =   4;	state[  6] =   9;	state[  7] =   8;	state[  8] =   7;	state[  9] =   6;
	state[ 10] =  12;	state[ 11] =  13;	state[ 12] =  10;	state[ 13] =  11;	state[ 14] =  15;	state[ 15] =  14;	state[ 16] =  19;	state[ 17] =  18;	state[ 18] =  17;	state[ 19] =  16;
	state[ 20] =  22;	state[ 21] =  23;	state[ 22] =  20;	state[ 23] =  21;	state[ 24] =  25;	state[ 25] =  24;	state[ 26] =  29;	state[ 27] =  28;	state[ 28] =  27;	state[ 29] =  26;
	state[ 30] =  32;	state[ 31] =  33;	state[ 32] =  30;	state[ 33] =  31;	state[ 34] =  35;	state[ 35] =  34;	state[ 36] =  39;	state[ 37] =  38;	state[ 38] =  37;	state[ 39] =  36;
	state[ 40] =  42;	state[ 41] =  43;	state[ 42] =  40;	state[ 43] =  41;	state[ 44] =  45;	state[ 45] =  44;	state[ 46] =  49;	state[ 47] =  48;	state[ 48] =  47;	state[ 49] =  46;
	state[ 50] =  52;	state[ 51] =  53;	state[ 52] =  50;	state[ 53] =  51;	state[ 54] =  55;	state[ 55] =  54;	state[ 56] =  59;	state[ 57] =  58;	state[ 58] =  57;	state[ 59] =  56;
	state[ 60] =  62;	state[ 61] =  63;	state[ 62] =  60;	state[ 63] =  61;	state[ 64] =  65;	state[ 65] =  64;	state[ 66] =  69;	state[ 67] =  68;	state[ 68] =  67;	state[ 69] =  66;
	state[ 70] =  72;	state[ 71] =  73;	state[ 72] =  70;	state[ 73] =  71;	state[ 74] =  75;	state[ 75] =  74;	state[ 76] =  79;	state[ 77] =  78;	state[ 78] =  77;	state[ 79] =  76;
	state[ 80] =  82;	state[ 81] =  83;	state[ 82] =  80;	state[ 83] =  81;	state[ 84] =  85;	state[ 85] =  84;	state[ 86] =  89;	state[ 87] =  88;	state[ 88] =  87;	state[ 89] =  86;
	state[ 90] =  92;	state[ 91] =  93;	state[ 92] =  90;	state[ 93] =  91;	state[ 94] =  95;	state[ 95] =  94;	state[ 96] =  99;	state[ 97] =  98;	state[ 98] =  97;	state[ 99] =  96;
	state[100] = 102;	state[101] = 103;	state[102] = 100;	state[103] = 101;	state[104] = 105;	state[105] = 104;	state[106] = 109;	state[107] = 108;	state[108] = 107;	state[109] = 106;
	state[110] = 112;	state[111] = 113;	state[112] = 110;	state[113] = 111;	state[114] = 115;	state[115] = 114;	state[116] = 119;	state[117] = 118;	state[118] = 117;	state[119] = 116;
	state[120] = 122;	state[121] = 123;	state[122] = 120;	state[123] = 121;	state[124] = 125;	state[125] = 124;	state[126] = 129;	state[127] = 128;	state[128] = 127;	state[129] = 126;
	state[130] = 132;	state[131] = 133;	state[132] = 130;	state[133] = 131;	state[134] = 135;	state[135] = 134;	state[136] = 139;	state[137] = 138;	state[138] = 137;	state[139] = 136;
	state[140] = 142;	state[141] = 143;	state[142] = 140;	state[143] = 141;	state[144] = 145;	state[145] = 144;	state[146] = 149;	state[147] = 148;	state[148] = 147;	state[149] = 146;
	state[150] = 152;	state[151] = 153;	state[152] = 150;	state[153] = 151;	state[154] = 155;	state[155] = 154;	state[156] = 159;	state[157] = 158;	state[158] = 157;	state[159] = 156;
	state[160] = 162;	state[161] = 163;	state[162] = 160;	state[163] = 161;	state[164] = 165;	state[165] = 164;	state[166] = 169;	state[167] = 168;	state[168] = 167;	state[169] = 166;
	state[170] = 172;	state[171] = 173;	state[172] = 170;	state[173] = 171;	state[174] = 175;	state[175] = 174;	state[176] = 179;	state[177] = 178;	state[178] = 177;	state[179] = 176;
	state[180] = 182;	state[181] = 183;	state[182] = 180;	state[183] = 181;	state[184] = 185;	state[185] = 184;	state[186] = 189;	state[187] = 188;	state[188] = 187;	state[189] = 186;
	state[190] = 192;	state[191] = 193;	state[192] = 190;	state[193] = 191;	state[194] = 195;	state[195] = 194;	state[196] = 199;	state[197] = 198;	state[198] = 197;	state[199] = 196;
	state[200] = 202;	state[201] = 203;	state[202] = 200;	state[203] = 201;	state[204] = 205;	state[205] = 204;	state[206] = 209;	state[207] = 208;	state[208] = 207;	state[209] = 206;
	state[210] = 212;	state[211] = 213;	state[212] = 210;	state[213] = 211;	state[214] = 215;	state[215] = 214;	state[216] = 219;	state[217] = 218;	state[218] = 217;	state[219] = 216;
	state[220] = 222;	state[221] = 223;	state[222] = 220;	state[223] = 221;	state[224] = 225;	state[225] = 224;	state[226] = 229;	state[227] = 228;	state[228] = 227;	state[229] = 226;
	state[230] = 232;	state[231] = 233;	state[232] = 230;	state[233] = 231;	state[234] = 235;	state[235] = 234;	state[236] = 239;	state[237] = 238;	state[238] = 237;	state[239] = 236;
	state[240] = 242;	state[241] = 243;	state[242] = 240;	state[243] = 241;	state[244] = 245;	state[245] = 244;	state[246] = 249;	state[247] = 248;	state[248] = 247;	state[249] = 246;
	state[250] = 252;	state[251] = 253;	state[252] = 250;	state[253] = 251;	state[254] = 255;	state[255] = 254;

	key->x = 0;
	key->y = 0;
	index1 = 0;
	index2 = 0;
	
	for(counter = 0; counter < 256; counter++)
	{
		index2 = (key_data_ptr[index1] + state[counter] + index2) % 256;
		swap_byte(state[counter], state[index2]);
		index1 = (index1 + 1) % key_data_len;
	}
}

void rc4(snd_uchar *buffer_ptr, snd_int buffer_len, rc4_key *key)
{
	snd_uchar x = 0;
	snd_uchar y = 0;
	snd_uchar* state = 0;
	snd_uchar xorIndex = 0;
	snd_int counter = 0;
	
	x = key->x;
	y = key->y;
	state = &(key->state[0]);

	for(counter = 0; counter < buffer_len; counter ++)
	{
		x = (x + 1) % 256;
		y = (state[x] + y) % 256;
		swap_byte(state[x], state[y]);
		xorIndex = (state[x] + state[y]) % 256;
		buffer_ptr[counter] ^= state[xorIndex];
	}

	key->x = x;
	key->y = y;
}
//////////////////////////////////////////////////////////////////////////////

snd_bool modificator SEncryptFile( FILE* hSource, FILE* hDestination, const snd_char* szPassword, snd_ulong passwordLength, snd_ulong dwSize)
{
    snd_uchar*		pbBuffer = NULL;
    snd_ulong		dwBlockLen = 0;
    snd_ulong		dwBufferLen = 0;
    snd_ulong		dwCount = 0;
	snd_ulong		SourceLen = 0;
	snd_ulong		written = 0;

    snd_bool status = false;

	try
	{
		if(dwSize)
			SourceLen = dwSize;
		else
		{
			written = fseek(hSource,0,SEEK_CUR);
			SourceLen = fseek(hSource,0,SEEK_END) - written;
			if(SourceLen < 0 )
				return false;
			if(SourceLen == 0)
				return true;
		}

		if((pbBuffer = new snd_uchar[ENCRYPT_BLOCK_SIZE]) == NULL) {
			throw 0;
		}

		dwCount = SourceLen / ENCRYPT_BLOCK_SIZE;
		dwBlockLen = SourceLen - dwCount * ENCRYPT_BLOCK_SIZE;

		rc4_key key;
		memset(&key,0,sizeof(key));
		prepare_key((snd_uchar*)szPassword, passwordLength, &key);

		for(snd_ulong i = 0; i < dwCount; i++)
		{
			written = (snd_ulong)fread(pbBuffer,1,ENCRYPT_BLOCK_SIZE,hSource);

			dwBufferLen = ENCRYPT_BLOCK_SIZE;
			rc4(pbBuffer, dwBufferLen, &key);

			written = (snd_ulong)fwrite(pbBuffer,1,ENCRYPT_BLOCK_SIZE,hDestination);
		}

		if(dwBlockLen)
		{

			written = (snd_ulong)fread(pbBuffer,1,dwBlockLen,hSource);

			dwBufferLen = written;
			rc4(pbBuffer, dwBufferLen, &key);

			written = (snd_ulong)fwrite(pbBuffer,1,dwBlockLen,hDestination);
		}
		status = true;
	}
	catch(...)
	{
		status = false;
	}

    if(pbBuffer)
		delete pbBuffer;
	return(status);
}
