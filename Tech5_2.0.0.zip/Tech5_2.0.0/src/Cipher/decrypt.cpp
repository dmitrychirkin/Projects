#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <cipher.h>
#include "common_cipher.h"

bool modificator SDecryptFile( FILE* hSource, FILE* hDestination, const snd_char* szPassword, snd_ulong passwordLength, snd_ulong dwSize)
{
    snd_uchar*			pbBuffer	= NULL;
    snd_ulong			dwBlockLen	= 0;
    snd_ulong			dwBufferLen	= 0;
    snd_ulong			dwCount		= 0;
	snd_ulong			read		= 0;
	snd_ulong			rest		= 0;
	snd_bool			status		= false;

	try
	{
		dwCount = dwSize/ENCRYPT_BLOCK_SIZE;
		rest  = dwSize - dwCount*ENCRYPT_BLOCK_SIZE;

		// Determine number of bytes to decrypt at a time. This must be a multiple
		// of ENCRYPT_BLOCK_SIZE.
		dwBlockLen = ENCRYPT_BLOCK_SIZE;

		// Allocate memory.
		if((pbBuffer = (snd_uchar*)malloc(ENCRYPT_BLOCK_SIZE)) == NULL) {
			throw 0;
		}

		rc4_key key;
		memset(&key,0,sizeof(key));
		prepare_key((snd_uchar*)szPassword, passwordLength, &key);

		for(snd_ulong i = 0; i < dwCount; i++)
		{
			read = (snd_ulong)fread(pbBuffer,1,ENCRYPT_BLOCK_SIZE,hSource);

			dwBufferLen = dwBlockLen;
			rc4(pbBuffer, dwBufferLen, &key);

			read = (snd_ulong)fwrite(pbBuffer,1,ENCRYPT_BLOCK_SIZE,hDestination);
		}

		read = (snd_ulong)fread(pbBuffer,1,rest,hSource);
		dwBufferLen = rest;

		if( rest > 0)
		{
			// Decrypt data
			rc4(pbBuffer, dwBufferLen, &key);
			read = (snd_ulong)fwrite(pbBuffer,1,dwBufferLen,hDestination);
		}
		status = true;
	}
	catch(...)
	{
		status = false;
	}
	if(pbBuffer) free(pbBuffer);

    return status;
}

snd_bool modificator CAPIEncryptData(snd_uchar* pbSource, snd_ulong lenSource, const snd_char* szPassword, snd_ulong passwordLength)
{
    snd_bool status = false;
	rc4_key key;

	try
	{
		memset(&key,0,sizeof(key));
		prepare_key((snd_uchar*)szPassword, passwordLength, &key);
        
		rc4(pbSource, lenSource, &key);
		status = true;
	}
	catch(...)
	{
	}
	return status;
}

snd_bool modificator CAPIDecryptData(snd_uchar* pbSource, snd_ulong lenSource, const snd_char* szPassword, snd_ulong passwordLength)
{
	snd_bool	status		= false;
	rc4_key	key;
	try
	{
		memset(&key,0,sizeof(key));
		prepare_key((snd_uchar*)szPassword, passwordLength, &key);
		rc4(pbSource, lenSource, &key);
		status = true;
	}
	catch(...)
	{
	}
    return status;
}
