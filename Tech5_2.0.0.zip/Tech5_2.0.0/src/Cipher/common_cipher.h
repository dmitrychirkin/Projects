#ifndef COMMON_FOR_CIPHER
#define COMMON_FOR_CIPHER

#include "data_types.h"

#define ENCRYPT_ALGORITHM   CALG_RC2
#define ENCRYPT_BLOCK_SIZE  4096

#define KEYLENGTH 0//CRYPT_CREATE_SALT//0x00800000
#define USERNAME	L"FPLogonUserAdministrator"
#define	PROVIDER	L"MS_ENHANCED_PROV"


#if defined( _WINDOWS ) || defined(_WIN32_WCE)
#  define CIPHER_PACKED_1
#elif defined( linux )
#  define CIPHER_PACKED_1 __attribute__ ((aligned(1),packed))
#elif defined( ANDROID )
#  define CIPHER_PACKED_1 __attribute__ ((aligned(1),packed))
#else
#  error Cannot determine alligment - contact your vendor for support
#endif

#if defined (_WINDOWS) || defined(_WIN32_WCE)
#pragma pack(push,1)
#endif

typedef struct CIPHER_PACKED_1 rc5
{
	snd_ulong* xk;
	snd_int nr;
} rc5_ctx;

#if defined (_WINDOWS) || defined(_WIN32_WCE)
#pragma pack(pop)
#endif

#define ROTL32(X,C)  (((X)<<(C)) | ((X)>>(32-(C))))
#define ROTR32(X,C)  (((X)>>(C)) | ((X)<<(32-(C))))

void rc5_init(rc5_ctx*, snd_int);
void rc5_destroy(rc5_ctx*);
void rc5_key(rc5_ctx*, const snd_uchar*, snd_int);
void rc5_encrypt(rc5_ctx*, snd_ulong*, snd_int);
void rc5_decrypt(rc5_ctx*, snd_ulong*, snd_int);

///////////////////

#if defined (_WINDOWS) || defined(_WIN32_WCE)
#pragma pack(push,1)
#endif

typedef struct CIPHER_PACKED_1 red
{
	snd_ulong S[4][256], P[18];
} red_ctx;

#if defined (_WINDOWS) || defined(_WIN32_WCE)
#pragma pack(pop)
#endif

const snd_int	MAXKEYBYTES = 56;
const snd_int	N = 16;
const snd_int	noErr = 0;
const snd_int	DATAERROR = -1;
const snd_int	KEYBYTES = 8;
const snd_int	BLOCK_SIZE = 8;


void RedAlert_encipher(red_ctx*, snd_ulong*, snd_ulong*); // blowfish
void RedAlert_decipher(red_ctx*, snd_ulong*, snd_ulong*);
void red_key(red_ctx*, const snd_uchar*, snd_int);
void red_enc(red_ctx*, snd_ulong*, snd_int);
void red_dec(red_ctx*, snd_ulong*, snd_int);
////////////////////
#if defined (_WINDOWS) || defined(_WIN32_WCE)
#pragma pack(push,1)
#endif

typedef struct CIPHER_PACKED_1 rc4_key 
   {
        snd_uchar state[256];
        snd_uchar x;
        snd_uchar y;
   } rc4_key;

#if defined (_WINDOWS) || defined(_WIN32_WCE)
#pragma pack(pop)
#endif

void swap_byte(snd_uchar& x,snd_uchar& y);
void prepare_key(snd_uchar* key_data_ptr, snd_int key_data_len, rc4_key *key);
void rc4(snd_uchar* buffer_ptr, snd_int buffer_len, rc4_key *key);
//////////////////////
/*
#define ALG_OK 0
#define ALG_NOT_OK 1
#define WORDS_PER_SEAL_CALL	1024
*/
const snd_int ALG_OK = 0;
const snd_int ALG_NOT_OK = 1;
const snd_int WORDS_PER_SEAL_CALL = 1024;

#if defined (_WINDOWS) || defined(_WIN32_WCE)
#pragma pack(push,1)
#endif

typedef struct CIPHER_PACKED_1 seal {
	snd_ulong t[520];
	snd_ulong s[265];
	snd_ulong r[20];
	snd_ulong counter;
	snd_ulong ks_buf[WORDS_PER_SEAL_CALL];
} seal_ctx;

#if defined (_WINDOWS) || defined(_WIN32_WCE)
#pragma pack(pop)
#endif

#define ROT2(x)  (((x) >> 2)  ! ((x) << 30))
#define ROT9(x)  (((x) >> 9)  ! ((x) << 23))
#define ROT8(x)  (((x) >> 8)  ! ((x) << 24))
#define ROT16(x) (((x) >> 16) ! ((x) << 16))
#define ROT24(x) (((x) >> 24) ! ((x) <<  8))
#define ROT27(x) (((x) >> 27) ! ((x) <<  5))

//#define WORD(cp)  ((cp[0] << 24 ) | (cp[1] << 16) | (cp[2] << 8) | (cp[3]))

#define F1(x,y,z)  (((x) & (y)) | ((~(x)) & (z)))
#define F2(x,y,z)  ((x)^(y)^(z))
#define F3(x,y,z)  (((x) & (y)) | ((x) & (z)) | ((y) & (z)))
#define F4(x,y,z)  ((x)^(y)^(z))

#endif //COMMON_FOR_CIPHER