#ifndef _GRAPH8_H_
#define _GRAPH8_H_



// �������������� 8-32

void ConvertImg32To8(int *img, unsigned int size);
void ConvertImg8To32(int *img, unsigned int size);

void ConvertImg8ToImg32(unsigned char *img, int *res, unsigned int size);
void ConvertImg32ToImg8(int *img, unsigned char *res, unsigned int size);


int GetClone8(unsigned char *img, unsigned int w, unsigned int h, unsigned char *&res); 

int Get2Rect8(unsigned char *img,
              unsigned int   imgWidth,
              unsigned int   imgHeight,
              int x1, int y1,
              int x2, int y2,
              unsigned char *res,
              unsigned int  &resWidth,
              unsigned int  &resHeight,
              unsigned char  bgColor = 255);

int Get3Rect8(unsigned char *img,
              unsigned int   imgWidth,
              unsigned int   imgHeight,
              int x1, int y1,
              int x2, int y2,
              int x3, int y3,
              unsigned char *res,
              unsigned int  &resWidth,
              unsigned int  &resHeight,
              unsigned char  bgColor = 255);

/*
void ArrMul8            (unsigned char *arr, unsigned int len, int n);
void ArrDiv8            (unsigned char *arr, unsigned int len, int n);
*/
void ArrNormalize256_8  (unsigned char *arr, unsigned int len);
void ArrAutoLevels8     (unsigned char *arr, unsigned int len, int n1, int n2);
void ArrAutoLevelsC8    (unsigned char *arr, unsigned int len, unsigned int num);
int  ArrGetSumm8        (unsigned char *arr, int len);
int  ArrGetMean8        (unsigned char *arr, int len);
void ArrSetMinMax8      (unsigned char *arr, unsigned int len, unsigned char min_val, unsigned char max_val);
int  ArrValueExists8    (unsigned char *arr, unsigned int len, unsigned char val);

void Equalize8 (unsigned char *img, unsigned int w, unsigned int h, unsigned char min_val);
void Blur8     (unsigned char *img, unsigned int w, unsigned int h, int n);

void Blur3x3To8(unsigned char *img,
                unsigned int w,
                unsigned int h,
                int x1,
                int y1,
                int x2,
                int y2,
                unsigned char *sum);

void Summ3x3To8(unsigned char *img,
                unsigned int w,
                unsigned int h,	 
                int x1,
                int y1,
                int x2,
                int y2,
                unsigned char *sum);

void Summ3x38To32(unsigned char *img,
                  unsigned int w,
                  unsigned int h,
                  int x1,
                  int y1,
                  int x2,
                  int y2,
                  int *sum);

void Summ3x3To32(int *img,
                 unsigned int w,
                 unsigned int h,
                 int x1,
                 int y1,
                 int x2,
                 int y2,
                 int *sum);
/*
void Summ3x3QTo32(int *img,
                  unsigned int w,
                  unsigned int h,
                  int x1,
                  int y1,
                  int x2,
                  int y2,
				  unsigned char *qlt,
                  int *sum);
*/
void Summ3x3To8(unsigned char *img,
                unsigned int w,
                unsigned int h,
                unsigned char *sum);
/*
int SummToL32(int *img,
              unsigned int w,
              unsigned int h,
              int x1,
              int y1,
              int x2,
              int y2,
              int n,
              int *sum);

void Get1Dxy8(int *dxy, int w);
*/
int AutoLevelsToL8(unsigned char *img,
                   unsigned int w,
                   unsigned int h,
                   int x1,
                   int y1,
                   int x2,
                   int y2,
                   int n,
                   unsigned char *res);

int  SummDirTo8(unsigned char *img,
                unsigned int w,
                unsigned int h,
                int n,
                unsigned char *roi,
                unsigned char *dir,
                unsigned char *frq,
                unsigned char *sum);
/*
int  BinarizationLDTo8(unsigned char *img,
                unsigned int w,
                unsigned int h,
                int n,
                unsigned char *roi,
                unsigned char *dir,
                unsigned char *sum);

void SummFrqTo8(unsigned char *img,
                unsigned int w,
                unsigned int h,
                int n,
                int *dxy,
                unsigned char *roi,
                unsigned char *dir,
                unsigned char *frq,
                unsigned char *sum);
*/

unsigned char GetBgColor8 (unsigned char *img, unsigned int  w, unsigned int  h, unsigned char *msk);
void DeleteLongLinesH8    (unsigned char *img, unsigned int  w, unsigned int  h, int n);
int  NormalizationL8      (unsigned char *img, unsigned int  w, unsigned int  h, int n, int b);
void GetSummMaskS8        (unsigned char *img, unsigned int  w, unsigned int  h, int n, unsigned char *msk);
int  GetDirectionsS8      (unsigned char *img, unsigned int  w, unsigned int  h, int n, int k, unsigned char *dir);
int  GetPatternMask8      (unsigned char *img, unsigned int &w, unsigned int &h, unsigned char *&msk);

#endif