#include "fpalm_lines.h"

#include <math.h>



CLine::CLine()
{
	x1 = 0;
	y1 = 0;
	x2 = 0;
	y2 = 0;
	xc = 0;
	yc = 0;
	dx = 0;
	dy = 0;

	a = 1;
	b = 0;
	c = 0;

	length = 0;
	width  = 0;
}

CLine::CLine(double xl1, double yl1, double xl2, double yl2, double wl)
{
	init(xl1, yl1, xl2, yl2, wl);
}

//----------------------------------------------------------------------------//
// ���������� : ������������� ���������� �������.                             //
// ���������  : xl1, yl1 - ���������� ��������� �����;                        //
//              xl1, yl2 - ���������� ��������  �����;                        //
//              wl       - ������.                                            //
//----------------------------------------------------------------------------//
void CLine::init(double xl1, double yl1, double xl2, double yl2, double wl)
{
	if (yl2 > yl1)
	{
		x1 = xl1;
		y1 = yl1;
		x2 = xl2;
		y2 = yl2;
	}
	else
	{
		x1 = xl2;
		y1 = yl2;
		x2 = xl1;
		y2 = yl1;
	}

	xc = 0.5 * (x1 + x2);
	yc = 0.5 * (y1 + y2);
	dx = x2 - x1;
	dy = y2 - y1;

	length = sqrt(dy * dy + dx * dx);
	width  = wl;

	a = -dy;
	b =  dx;
	c = (x1 * y2 - x2 * y1);

	double k = -1 / length;

	a *= k;
	b *= k;
	c *= k;
}

double CLine::getX(double yp) const
{
	if (a != 0)
	{
		return -(b * yp + c) / a;
	}

	return xc;
}


CDevLine::CDevLine(): CLine()
{
	devidersCount = 0;
	fingerIndex   = 0;
}

void CDevLine::init(double xl1, double yl1, double xl2, double yl2, double wl)
{
	int i, k = 0;

	CLine::init(xl1, yl1, xl2, yl2, wl);

	for (i = 0; i < devidersCount; i++)
	{
		if ((deviders[i].y >= y1) &&
		    (deviders[i].y <= y2))
		{
			if (i > k)
				deviders[k] = deviders[i];
			k++;
		}
	}

	devidersCount = k;
}

void CRect4::init(CLine *line)
{
	double wa = line->width * line->a;
	double wb = line->width * line->b;

	m_x11 = line->x1 - wa;
	m_y11 = line->y1 - wb;
	m_x12 = line->x1 + wa;
	m_y12 = line->y1 + wb;

	m_x21 = line->x2 - wa;
	m_y21 = line->y2 - wb;
	m_x22 = line->x2 + wa;
	m_y22 = line->y2 + wb;

	m_xc  = 0.5 * (m_x11 + m_x22);
	m_yc  = 0.5 * (m_y11 + m_y22);

	m_x1 = line->x1;
	m_y1 = line->y1;
	
	m_x2 = line->x2;
	m_y2 = line->y2;

	m_width = line->width;
}

double CRect4::x1() const
{
	return m_x1;
}

double CRect4::y1() const
{
	return m_y1;
}

double CRect4::x2() const
{
	return m_x2;
}

double CRect4::y2() const
{
	return m_y2;
}

double CRect4::width() const
{
	return m_width;
}
