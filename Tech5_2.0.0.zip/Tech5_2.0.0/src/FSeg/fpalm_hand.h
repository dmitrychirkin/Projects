#ifndef _HAND_H_
#define _HAND_H_

#include "fpalm_lines.h"
#include "fpalm_image.h"



class CFinger;
class CPalm;
class CHand;


class CPhalanx
{
public:
	CPhalanx(int index,
	         double xp1, double yp1,
	         double xp2, double yp2,
	         double wp);

	int    index() const;
	CRect4 rect() const;

	double getLowPointX() const;
	double getLowPointY() const;

private:
	int    m_index;

	CLine  m_line;
	CRect4 m_rect;
};


class CFinger
{
public:
	CFinger(CHand *hand, CDevLine *devLine);
	~CFinger();

	int       index() const;
	int       phalanxesCount() const;
	CPhalanx* phalanx(int phalanxIndex) const;

	void setIndex(int index);
	void findConnectionPoint(CLine *handLine);
	void findPhalanxes();

	double getWidth() const;
	double getPower() const;
	double getPhalanxLength(double maxLength) const;
	
	double getLowPointX() const;
	double getLowPointY() const;

	double connectionPointX() const;
	double connectionPointY() const;

	void   setWidth(double Width);
	double setAvrPhalanxLength(double &avrPhalanxLength);

	void   setConnectionPointY(double connectionPointY);

protected:
	int       m_index;

	CHand    *m_hand;
	CRect4    m_rect;
	CDevLine  m_line;

	int       m_phalanxesCount;
	CPhalanx* m_phalanxes[3];

	double    m_avrPhalanxLength;
	double    m_connectionPointX;
	double    m_connectionPointY;

	double getCirclePointY(double x, double y, double r, CLine *line) const;

	void addPhalanx(CPhalanx *phalanx);
};


class CHand
{
public:
	CHand();
	~CHand();

	CRect4   rect() const;
	int      fingersCount() const;
	CFinger* finger(int fingerIndex) const;

	void setFindType(int findType);

	void find(unsigned char *img,
	          unsigned int   imgWidth,
	          unsigned int   imgHeight,
	          int            findType);

	int imageWidth() const;
	int imageHeight() const;

	int isRightHand() const;

private:
	CRect4   m_rect;
	CLine    m_line;

	int      m_imageWidth;
	int      m_imageHeight;
	int      m_imageHalfWidth;
	int      m_imageHalfHeight;

	int      m_xMin;
	int      m_yMin;
	int      m_xMax;
	int      m_yMax;

	int      m_findType;
	int      m_rightHand;
	int      m_palmUpLineY;
	double   m_avrPhalanxLength;

	CImage   m_sourceImage;

	int      m_devLinesCount;      // ���������� ��������
	CDevLine m_devLines[maxLines]; // ������ ��������

	int      m_stdFingersCount;
	CFinger* m_stdFingers[4];
	double   m_stdFingersAvrWidth;

	void free();

	void addStdFinger(CFinger *stdFinger);

	void findFingers();
	void findPalm();

	void checkRightHand();
	void findConnectionPoints();

	void correctFingers();
	void correctPalm1();
	void correctPalm2();
};

#endif //_HAND_H_