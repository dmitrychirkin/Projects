#ifndef _SPOT_H_
#define _SPOT_H_

#include <stdio.h>

#include "FSeg.h"


#define MAX_SPOT_POINTS_COUNT  2048


struct DPOINT
{
	int x, y;

#ifdef __cplusplus
	DPOINT()
	{
		memset(this, 0, sizeof(DPOINT));
	}
#endif
};


class CSpot
{
private:

	DPOINT m_points[MAX_SPOT_POINTS_COUNT];

	int m_pointsCount;

public:

	int x1, y1;
	int x2, y2;
	int xc, yc;
	int dx, dy;

	double a, b, c;
	double angle;

	unsigned int length;
	unsigned int width;

	int size;
	int type;
	SGM_SEGMENT segment;
	int err;


	CSpot();
	CSpot(int xl1, int yl1, int xl2, int yl2, int wl);
	CSpot(const CSpot &spot);

	virtual ~CSpot();

	CSpot& operator = (const CSpot &spot);


	void init(int xl1, int yl1, int xl2, int yl2, int wl);

	int initV(unsigned char *img, unsigned int w, unsigned int h, unsigned char *p0, unsigned char col);
	int initR(unsigned char *img, unsigned int w, unsigned int h, unsigned char *p0, unsigned char col);

	void saveV(FILE *f, unsigned int pow2ScalingFactor, unsigned int alignment);
	void saveR(FILE *f, unsigned int pow2ScalingFactor, unsigned int alignment);

	void getRectV(SgmRect *rect, unsigned int pow2ScalingFactor, unsigned int alignment);
	void getRectR(SgmRect *rect, unsigned int pow2ScalingFactor, unsigned int alignment);

	void setAngleAndLength  (double ut, int l, int n);
	void setAngle           (double ut, int ym);

	void setAngleAuto(bool fullAuto = false);

	unsigned int getScaledWidth  (unsigned int pow2ScalingFactor);
	unsigned int getScaledHeight (unsigned int pow2ScalingFactor);
	int getX(int yp);

	void move   (int deltaX, int deltaY);
	void rotate (double cs, double sn);

	int isPointInRect(int x, int y, int n);

};
#endif//_SPOT_H_
