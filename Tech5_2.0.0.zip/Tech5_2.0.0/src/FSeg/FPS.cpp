////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  ������ ����������� ���������� �������                                     //
//                                                                            //
//  �����: �. ���������                                                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#include <math.h>
#include <memory.h>

#include "FPS.h"

#include "graph8_const.h"
#include "graph8.h"
#include "graph8_bin.h"
#include "graph8_scale.h"
#include "graph8_spot.h"
#include "graph8_dir.h"
#include "graph8_frq.h"



////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  ����� CFps - ����������� ���������� �������                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

//----------------------------------------------------------------------------//
// ���������� : �����������.                                                  //
//----------------------------------------------------------------------------//
CFps::CFps()
{
	m_srcWidth    = 0;
	m_srcHeight   = 0;
	m_srcPPI      = 500;
	m_srcHand     = SGM_HAND_UNKNOWN;
	m_srcImpType  = IMP_TYPE_FP_LS_PL;
	m_srcRotation = true;
	m_srcScale    = 0;

	m_img  = NULL;
	m_imgW = 0;
	m_imgH = 0;

	m_resHand = SGM_HAND_UNKNOWN;

	Reset();
}

//----------------------------------------------------------------------------//
// ���������� : ����������� �����������.                                      //
// ���������  : fps - ���������� ������.                                      //
//----------------------------------------------------------------------------//
CFps::CFps(const CFps& fps)
{
	m_srcWidth    = fps.m_srcWidth;
	m_srcHeight   = fps.m_srcHeight;
	m_srcPPI      = fps.m_srcPPI;
	m_srcHand     = fps.m_srcHand;
	m_srcImpType  = fps.m_srcImpType;
	m_srcRotation = fps.m_srcRotation;
	m_srcScale    = fps.m_srcScale;

	m_img  = NULL;
	m_imgW = 0;
	m_imgH = 0;

	m_resHand = fps.m_resHand;

	CopyImg(fps.m_img, fps.m_imgW, fps.m_imgH);

	memcpy(m_points, fps.m_points, sizeof(fps.m_points));

	for (int i = 0; i < fps.m_rectsCount; i++)
	{
		m_rects[i] = fps.m_rects[i];
	}

	for (int i = 0; i < fps.m_fingerRectsCount; i++)
	{
		m_fingerRects[i] = fps.m_fingerRects[i];
	}

	m_pointsCount      = fps.m_pointsCount;
	m_rectsCount       = fps.m_rectsCount;
	m_fingerRectsCount = fps.m_fingerRectsCount;
}

//----------------------------------------------------------------------------//
// ���������� : ����������.                                                   //
//----------------------------------------------------------------------------//
CFps::~CFps()
{
	FreeImg();
}

//----------------------------------------------------------------------------//
// ���������� : �������� ������������.                                        //
// ���������  : fps - ������������� ������.                                   //
//----------------------------------------------------------------------------//
CFps& CFps::operator = (const CFps &fps)
{
	if (this == &fps)
	{
		return *this;
	}

	m_srcWidth    = fps.m_srcWidth;
	m_srcHeight   = fps.m_srcHeight;
	m_srcPPI      = fps.m_srcPPI;
	m_srcHand     = fps.m_srcHand;
	m_srcImpType  = fps.m_srcImpType;
	m_srcRotation = fps.m_srcRotation;
	m_srcScale    = fps.m_srcScale;
	m_resHand     = fps.m_resHand;

	CopyImg(fps.m_img, fps.m_imgW, fps.m_imgH);

	memcpy(m_points, fps.m_points, sizeof(fps.m_points));

	for (int i = 0; i < fps.m_rectsCount; i++)
	{
		m_rects[i] = fps.m_rects[i];
	}

	for (int i = 0; i < fps.m_fingerRectsCount; i++)
	{
		m_fingerRects[i] = fps.m_fingerRects[i];
	}

	m_pointsCount      = fps.m_pointsCount;
	m_rectsCount       = fps.m_rectsCount;
	m_fingerRectsCount = fps.m_fingerRectsCount;

	return *this;
}

//----------------------------------------------------------------------------//
// ���������� : ����������� ��������������� �����������.                      //
//----------------------------------------------------------------------------//
SGM_RESULT CFps::CopyImg(unsigned char *img, unsigned int w, unsigned int h)
{
	FreeImg();

	if (img == NULL)  return SGM_RES_ERR_IMAGE;
	if (w   == 0)     return SGM_RES_ERR_WIDTH;
	if (h   == 0)     return SGM_RES_ERR_HEIGHT;

	m_img = new unsigned char[w * h];

	if (m_img == NULL)
	{
		return SGM_RES_ERR_MEMORY;
	}

	memcpy(m_img, img, w * h);

	m_imgW = w;
	m_imgH = h;

	return SGM_RES_SUCCESS;
}

//----------------------------------------------------------------------------//
// ���������� : ������������ ������ ��������������� �����������.              //
//----------------------------------------------------------------------------//
void CFps::FreeImg()
{
	if (m_img != NULL)
	{
		delete [] m_img;

		m_img  = NULL;
		m_imgW = 0;
		m_imgH = 0;
	}
}

//----------------------------------------------------------------------------//
// ���������� : ��������� ������ � ������ � ���������������.                  //
//----------------------------------------------------------------------------//
void CFps::Reset()
{
	memset(m_points, 0, sizeof(m_points));

	m_pointsCount      = 0;
	m_rectsCount       = 0;
	m_fingerRectsCount = 0;
}

//----------------------------------------------------------------------------//
// ����������: ����������� ���������� �������.                                //
// ���������:  SGM_RES_SUCCESS, SGM_RES_WRN..., SGM_RES_ERR_...               //
//----------------------------------------------------------------------------//
SGM_RESULT CFps::Segmentation(unsigned char *img,          // ����������� (RAW, 8-bit)
                              unsigned char *background,   // ������� ����������� (RAW, 8-bit)
                              unsigned int   imgWidth,     // ������ �����������
                              unsigned int   imgHeight,    // ������ �����������
                              unsigned int   imgPPI,       // ���������� �����������, PPI (����� (��������) �� ����)
                              SGM_HAND       sgmHand,      // ����
                              NIST_IMP_TYPE  impType,      // ��� ���������
                              bool           rotation,     // ������� ��������
                              SGM_FINGER    *exclPos,      // ������ ����������� ����� ����������� (������������� �� �����������) ����������
                              unsigned int   exclPosCount, // ���������� ��������� � ������� exclPos
                              SgmRect       *rects,        // ������ ��� ������ ���������������� ���������������
                              unsigned int  &rectsCount,   // ���������� ��������������� (1 .. SGM_MAX_RECTS_COUNT)
                              unsigned int   alignment)    // ������������ �������� ��������������� �� ������� alignment
{
	if (img     == NULL)  return SGM_RES_ERR_IMAGE;
	if (imgWidth   < 64)  return SGM_RES_ERR_WIDTH;
	if (imgHeight  < 64)  return SGM_RES_ERR_HEIGHT;
	if (imgPPI     < 50)  return SGM_RES_ERR_PPI;

	if ((exclPos == NULL) && (exclPosCount > 0))
	{
		return SGM_RES_ERR_EXCLUDE;
	}

	if (rects   == NULL)  return SGM_RES_ERR_RECTS;
	if (rectsCount == 0)  return SGM_RES_ERR_COUNT;

	m_srcWidth    = imgWidth;
	m_srcHeight   = imgHeight;
	m_srcPPI      = imgPPI;
	m_srcHand     = sgmHand;
	m_srcImpType  = impType;
	m_srcRotation = rotation;
	m_srcScale    = 0;

	m_resHand = m_srcHand;

	if (m_srcHand == SGM_HAND_PROBABLY_LEFT)   m_resHand = SGM_HAND_LEFT;  else
	if (m_srcHand == SGM_HAND_PROBABLY_RIGHT)  m_resHand = SGM_HAND_RIGHT;

	Reset();

	SGM_RESULT sgmRes = CopyImg(img, imgWidth, imgHeight);

	if (sgmRes != SGM_RES_SUCCESS)
	{
		return sgmRes;
	}

	if (background != NULL)
	{
		CleanBackground(background);
	}

	int graphRes = Preprocessing();

	if (graphRes == GRAPH_RES_ERR_MEM)  return SGM_RES_ERR_MEMORY;
	if (graphRes != GRAPH_RES_SUCCESS)  return SGM_RES_ERR_UNKNOWN;

	graphRes = Recognition(exclPos, exclPosCount);

	if (graphRes == GRAPH_RES_ERR_MEM)  return SGM_RES_ERR_MEMORY;
	if (graphRes != GRAPH_RES_SUCCESS)  return SGM_RES_ERR_UNKNOWN;

	return RectsOut(rects, rectsCount, alignment);
}

void CFps::CleanBackground(unsigned char *background)
{
	unsigned char *pi, *pb, *li;

	for (pi = m_img, pb = background, li = m_img + m_imgW * m_imgH; pi < li; 
	     pi++, pb++)
	{
		*pi = (*pi < *pb) ? (*pi + (255 - *pb)) : 255;
	}
}

void CFps::FindPoints()
{
	register unsigned char *px, *py, *pt;

	unsigned int x, y;

	unsigned char *lx, *ly;
	unsigned char *p1, *p2;

	const unsigned int w     = m_imgW;
	const unsigned int h     = m_imgH;
	const unsigned int wm1   = w - 1;
	const unsigned int hm1   = h - 1;
	const unsigned int wxhm1 = w * hm1;
	const unsigned int x_min = w >> 4;
	const unsigned int x_max = w - x_min;
	const unsigned int y_min = h >> 4;
	const unsigned int y_max = h - y_min;


	m_pointsCount = 0;

	for (py = m_img + w, ly = m_img + wxhm1; py < ly; py += w)
	{
		for (px = py + 1, lx = py + wm1; (px < lx) && (*px == 1); px++);

		while (px < lx)
		{
			while ((px < lx) && (*px != 1))  px++;

			if (px < lx)
			{
				pt = px - w;
				if (*pt == 1)  pt = px + w;

				for (p1 = px; (px < lx) && (*px == 1) && (*pt != 1); px++, pt++);

				if (px < lx)
				{
					if (*px != 1)
					{
						p2 = px - 1;

						x  = ((unsigned int)(p1 - m_img) % w + 
						      (unsigned int)(p2 - m_img) % w) >> 1;
						y  =  (unsigned int)(pt - m_img) / w;

						if ((x > x_min) && (x < x_max) && 
						    (y > y_min) && (y < y_max))
						{
							if (m_pointsCount >= SGM_MAX_POINTS_COUNT)
							{
								return;
							}

							m_points[m_pointsCount].p  = m_img + x + y * w;
							m_points[m_pointsCount].x  = x;
							m_points[m_pointsCount].y  = y;
							m_points[m_pointsCount].tp = (*(p2 + w) != 1) ? 1 : -1;

							m_pointsCount++;
						}
					}
					else
					{
						while ((px < lx) && (*px == 1))  px++;
					}
				}
			}
		}
	}

	for (px = m_img + 1, lx = m_img + wm1; px < lx; px++)
	{
		for (py = px + w, ly = px + wxhm1; (py < ly) && (*py == 1); py += w);

		while (py < ly)
		{
			while ((py < ly) && (*py != 1))  py += w;

			if (py < ly)
			{
				pt = py - 1;
				if (*pt == 1)  pt = py + 1;

				for (p1 = py; (py < ly) && (*py == 1) && (*pt != 1); 
				     py += w, pt += w);

				if (py < ly)
				{
					if (*py != 1)
					{
						if (m_pointsCount >= SGM_MAX_POINTS_COUNT)
						{
							return;
						}

						p2 = py - w;

						x =  (int)(pt - m_img) % w;
						y = ((int)(p1 - m_img) / w + (int)(p2 - m_img) / w) >> 1;

						m_points[m_pointsCount].p  = m_img + x + y * w;
						m_points[m_pointsCount].x  = x;
						m_points[m_pointsCount].y  = y;
						m_points[m_pointsCount].tp = (*(p2 + 1) != 1) ? 2 : -2;

						m_pointsCount++;
					}
					else
					{
						while ((py < ly) && (*py == 1))  py += w;
					}
				}
			}
		}
	}
}

int CFps::ClearLines(int maxLength)
{
	if (m_pointsCount == 0)  return 0;


	int i, j, n;
	int res;
	int len;
	int x1, y1;
	int x2, y2;
	int x1n, y1n;
	int x2n, y2n;
	int xc, yc;
	int dx, dy;
	int dxt, dyt;
	int dxa, dya;
	int t1, t2;
	int dxy, dxyMin;

	int num = 0;

	int l2 = maxLength;
	int l1 = 0;

	const unsigned int wm1 = m_imgW - 1;
	const unsigned int hm1 = m_imgH - 1;

	double k, kt;


	for (i = 0; i < m_pointsCount; i++)
	{
		x1 = m_points[i].x;
		y1 = m_points[i].y;

		if (m_rects[m_rectsCount].isPointInRect(x1, y1, 0) == 1)
		{
			t1 = m_points[i].tp;

			n = -1;
			dxyMin = m_imgW * m_imgW + m_imgH * m_imgH;

			for (j = 0; j < m_pointsCount; j++)
			{
				if (i != j)
				{
					t2 = m_points[j].tp;

					if (t1 != t2)
					{
						x2 = m_points[j].x;
						y2 = m_points[j].y;

						if (m_rects[m_rectsCount].isPointInRect(x2, y2, 0) == 1)
						{
							dx = x2 - x1;
							dy = y2 - y1;

							if ((dx != 0) || (dy != 0))
							{
								dxa = abs(dx);
								dya = abs(dy);

								//if (dya > dxa)

								dxy = dx * dx + dy * dy;
								len = (dxa * l1 + dya * l2) / (dxa + dya);
								len = len * len;

								if ((dxy < dxyMin) && (dxy <= len))
								{
									res = IsLine8(m_img, m_imgW, m_imgH, 
									              x1, y1, x2, y2, 1);

									if (res < 4)
									{
										xc = (x1 + x2) >> 1;
										yc = (y1 + y2) >> 1;

										k = 1.0;

										if (xc < dya)
										{
											kt = xc / (double)dya;

											if (k > kt)
												k = kt;
										}

										dxt = wm1 - xc;

										if (dxt < dya)
										{
											kt = dxt / (double)dya;

											if (k > kt)
												k = kt;
										}

										if (yc < dxa)
										{
											kt = yc / (double)dxa;

											if (k > kt)
												k = kt;
										}

										dyt = hm1 - yc;

										if (dyt < dxa)
										{
											kt = dyt / (double)dxa;

											if (k > kt)
												k = kt;
										}

										x1n = (int)(xc - k * dy);
										y1n = (int)(yc + k * dx);
										x2n = (int)(xc + k * dy);
										y2n = (int)(yc - k * dx);

										if ((x1n >= 0) && (x1n < (int)m_imgW) &&
										    (y1n >= 0) && (y1n < (int)m_imgH) &&
										    (x2n >= 0) && (x2n < (int)m_imgW) &&
										    (y2n >= 0) && (y2n < (int)m_imgH))
										{
											res = IsLine8(m_img, m_imgW, m_imgH, 
											              x1n, y1n, x2n, y2n, 1);

											if (res < 4)
											{
												n = j;
												dxyMin = dxy;
											}
										}
									}
								}
							}
						}
					}
				}
			}

			if (n != -1)
			{
				m_points[i].tp = 0;
				m_points[n].tp = 0;

				x2 = m_points[n].x;
				y2 = m_points[n].y;

				if (x1 < x2)
				{
					x1 -= 4;
					x2 += 4;
				}
				else
				{
					x1 += 4;
					x2 -= 4;
				}

				if (y1 < y2)
				{
					y1 -= 4;
					y2 += 4;
				}
				else
				{
					y1 += 4;
					y2 -= 4;
				}

				LineTh8(m_img, m_imgW, m_imgH, x1, y1, x2, y2, 1, 6);

				num++;
			}
		}
	}

	return num;
}

void CFps::FindRects(unsigned int wNrm, unsigned int wMax)
{
	unsigned char *pi, *lp;

	unsigned int  l, w;
	unsigned char col = 10;

	bool findPointsFlag = false;


	m_rectsCount = 0;

	Border8(m_img, m_imgW, m_imgH, 1);

	for (pi = m_img, lp = m_img + m_imgW * m_imgH; pi < lp; pi++)
	{
		if (*pi == 0)
		{
			if (m_rectsCount >= SGM_MAX_RECTS_COUNT)
			{
				break;
			}

//			Fill8(m_img, m_imgW, m_imgH, 0, 0, m_imgW - 1, m_imgH - 1, col, 254, pi);
			Fill8(m_img, m_imgW, m_imgH, pi, col);

			if (m_srcRotation == false)
			{
				if (m_rects[m_rectsCount].
				    initV(m_img, m_imgW, m_imgH, pi, col) == 0)
				{
					if (m_rects[m_rectsCount].width < wMax)
					{
						m_rectsCount++;
					}
					else
					{
						if (findPointsFlag == false)
						{
							findPointsFlag = true;
							FindPoints();
						}

						if (ClearLines(80) == 0)
						{
							LineV8(m_img, m_imgW, m_imgH,
							       m_rects[m_rectsCount].xc,
							       m_rects[m_rectsCount].y1,
							       m_rects[m_rectsCount].y2, 1);
						}

						ChangeColor8(m_img, m_imgW, m_imgH, col, 0);

						pi = m_img;
					}
				}
			}
			else
			{
				if (m_rects[m_rectsCount].
				    initR(m_img, m_imgW, m_imgH, pi, col) == 0)
				{
					w = m_rects[m_rectsCount].width;
					l = m_rects[m_rectsCount].length;

					if ((w < wNrm) && ((l < 5.5 * w) || (l > 6 * w)))
					{
						m_rects[m_rectsCount].setAngleAuto();
						m_rectsCount++;
					}
					else
					{
						if (findPointsFlag == false)
						{
							findPointsFlag = true;
							FindPoints();
						}

						if (ClearLines(80) > 0)
						{
							ChangeColor8(m_img, m_imgW, m_imgH, col, 0);

							pi = m_img;
						}
						else
						{
							m_rects[m_rectsCount].setAngleAuto();
							m_rectsCount++;
						}
					}
				}
			}

			col++;

			if (col >= 254)
			{
				ChangeColors8(m_img, m_imgW, m_imgH, 10, 253, 255);
				col = 10;
			}
		}
	}


	if ((m_srcRotation == true) && (m_rectsCount > 0))
	{
		int i;

		unsigned int ls = 0;
		unsigned int ws = 0;

		double us = 0;


		for (i = 0; i < m_rectsCount; i++)
		{
			l = m_rects[i].length;

			ls += l;
			us += m_rects[i].angle * l;
			ws += m_rects[i].width;
		}

		us /= (double)ls;
		ws /= m_rectsCount;

		const double gr20 = (double)(20 * PI / 180.0);

		for (i = 0; i < m_rectsCount; i++)
		{
			if ((fabs(us - m_rects[i].angle) > gr20) &&
			    (m_rects[i].width > ws))
			{
				m_rects[i].setAngle(us, 0);
			}
		}
	}
}

void CFps::SlapAutoRotate()
{
	if (m_fingerRectsCount == 0)  return;


	int i;

	double us = 0;


	for (i = 0; i < m_fingerRectsCount; i++)
	{
		us += m_fingerRects[i].angle;
	}

	us /= (double)m_fingerRectsCount;

	for (i = 0; i < m_fingerRectsCount; i++)
	{
/*
		if ((m_fingerRects[i].length > (3 * m_fingerRects[i].width)) &&
		    (fabs(us - m_fingerRects[i].angle) > gr20))
		{
			m_fingerRects[i].err = true;
		}
*/
		m_fingerRects[i].setAngle(us, 0);
	}
}

void CFps::CorrectRectsLength(double k1, double k2, double ks)
{
	if (m_fingerRectsCount == 0)  return;

	double fingerLengths[11] = 
	{
		(double)1.0,
		(double)1.0, (double)1.0, (double)1.0, (double)1.0, (double)0.9,
		(double)1.0, (double)1.0, (double)1.0, (double)1.0, (double)0.9
	};

	int i, n;
	unsigned int ln;

	unsigned int w1 = 0;
	unsigned int w2 = 0;
	unsigned int ws = 0;
	unsigned int ls = 0;


	for (i = 0; i < m_fingerRectsCount; i++)
	{
		ws += m_fingerRects[i].width;
	}

	ws /= m_fingerRectsCount;

	w1 = (int)(k1 * ws);
	w2 = (int)(k2 * ws);
	ws = (int)(ks * ws);

	n = 0;

	for (i = 0; i < m_fingerRectsCount; i++)
	{
		ln = (m_fingerRects[i].type < 11) ? 
		     ((int)(ws * fingerLengths[m_fingerRects[i].type])) : ws;

		if (m_fingerRects[i].length > ln)
		{
			m_fingerRects[i].setAngleAndLength(m_fingerRects[i].angle, ln, 24);
		}

		ln = m_fingerRects[i].length;

		if ((ln >= w1) && (ln <= w2))
		{
			ls += ln;
			n++;
		}
	}

	if (n > 0)
	{
		ls /= n;

		for (i = 0; i < m_fingerRectsCount; i++)
		{
			ln = (m_fingerRects[i].type < 11) ? 
			     ((int)(ls * fingerLengths[m_fingerRects[i].type])) : ls;

			m_fingerRects[i].setAngleAndLength(m_fingerRects[i].angle, ln, 24);
		}
	}

/*
	int x, y;
	int x1, y1;
	int x2, y2;
	int xr1, yr1;
	int i1, i2;
	int cs, cl, cm, ct;
	int w, wa, wb;
	int ym;

	double a, b;


	for (i = 0; i < m_fingerRectsCount; i++)
	{
		ln = (m_fingerRects[i].Type < 11) ? 
		     ((int)(ws * FingerLengths[m_fingerRects[i].Type])) : ws;

		if (m_fingerRects[i].Length > ln)
		{
			xr1 = m_fingerRects[i].x1;
			yr1 = m_fingerRects[i].y1;

			cs = LineBr(src, imgW, imgH, xr1, yr1,
			            m_fingerRects[i].x2,
			            m_fingerRects[i].y2);

			a  = m_fingerRects[i].a;
			b  = m_fingerRects[i].b;
			w  = m_fingerRects[i].Width;
			wa = (int)(a * w);
			wb = (int)(b * w);

			w <<= 1;

			ym = yr1 + (int)(ln * a);
			i1 = ym - (int)(a * 48);
			i2 = ym + (int)(a * 24);

			cm = 0;

			for (y = i1; y <= i2; y++)
			{
				x  = m_fingerRects[i].GetX(y);
				x1 = x - wa;
				y1 = y - wb;
				x2 = x + wa;
				y2 = y + wb;

				ct = LineN8(img, imgW, imgH, x1, y1, x2, y2, 1);

				if (ct > 0)
				{
					cl = LineBr(src, imgW, imgH, x1, y1, x2, y2);
					ct = ((w - ct) << 1) + abs(cl - cs);

					if (ct > cm)
					{
						cm = ct;
						ym = y;
					}
				}
			}

			m_fingerRects[i].Init(xr1, yr1,
			                      m_fingerRects[i].GetX(ym), ym,
			                      w >> 1);
		}
	}
*/
}

void CFps::CorrectRects(int dy1, int dy2, int dw)
{
	if (m_fingerRectsCount == 0)  return;

	int y1, y2, yt;

	for (int i = 0; i < m_fingerRectsCount; i++)
	{
		y1 = m_fingerRects[i].y1 - (int)(dy1 * m_fingerRects[i].a);
		y2 = m_fingerRects[i].y2 + (int)(dy2 * m_fingerRects[i].a);  // 12

		if (y1 < 0)
		{
			yt = 1 - abs((int)(m_fingerRects[i].b * m_fingerRects[i].width));

			if (y1 < yt)
				y1 = yt;
		}

		if (y2 >= (int)m_imgH)
		{
			yt = m_imgH - 1 + 
			     abs((int)(m_fingerRects[i].b * m_fingerRects[i].width));

			if (y2 > yt)
				y2 = yt;
		}

		m_fingerRects[i].init(m_fingerRects[i].getX(y1), y1,
		                      m_fingerRects[i].getX(y2), y2,
		                      m_fingerRects[i].width + dw);
	}
}

SGM_RESULT CFps::RectsOut(SgmRect *rects, 
                          unsigned int &rectsCount, 
                          unsigned int alignment)
{
	if (m_fingerRectsCount == 0)
	{
		rectsCount = 0;
		return SGM_RES_WRN_NORECTS;
	}

	unsigned int resRectsCount = 0;

	const unsigned int min_width  = (32 * m_srcPPI) / 500;  // 32 ������� ��� 500 DPI
	const unsigned int min_height = (64 * m_srcPPI) / 500;  // 64 ������� ��� 500 DPI

	for (int i = 0; i < m_fingerRectsCount; i++)
	{
		if ((m_fingerRects[i].getScaledWidth(m_srcScale)  >= min_width) &&
		    (m_fingerRects[i].getScaledHeight(m_srcScale) >= min_height))
		{
			if (resRectsCount >= rectsCount)
			{
				return SGM_RES_ERR_COUNT;
			}

			if (m_srcRotation == false)
			{
				m_fingerRects[i].getRectV(&rects[resRectsCount], m_srcScale, 
				                          alignment);
/*
				for (k = 0; k < 4; k++)
				{
					if (FRects[i].Coords[k][0] < 0)  FRects[i].Coords[k][0] = 0;
					if (FRects[i].Coords[k][1] < 0)  FRects[i].Coords[k][1] = 0;

					if (FRects[i].Coords[k][0] >= (int)m_srcWidth)
						FRects[i].Coords[k][0] = m_srcWidth - 1;
					if (FRects[i].Coords[k][1] >= (int)m_srcHeight)
						FRects[i].Coords[k][1] = m_srcHeight - 1;
				}
*/
			}
			else
			{
				m_fingerRects[i].getRectR(&rects[resRectsCount], m_srcScale, 
				                          alignment);
			}

			rects[resRectsCount].pos     = (NIST_POS_CODE)(m_fingerRects[i].type);
			rects[resRectsCount].segment = m_fingerRects[i].segment;
			resRectsCount++;
		}
	}

	rectsCount = resRectsCount;

	if (rectsCount == 0)
	{
		return SGM_RES_WRN_NORECTS;
	}

	if (((m_srcHand == SGM_HAND_PROBABLY_LEFT)  && 
	     (m_resHand == SGM_HAND_RIGHT)) ||
	    ((m_srcHand == SGM_HAND_PROBABLY_RIGHT) && 
	     (m_resHand == SGM_HAND_LEFT)))
	{
		return SGM_RES_WRN_HAND;
	}

	return SGM_RES_SUCCESS;
}



////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  ����� CFpsSlap - ����������� ���������� 4-� ������� �������.              //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

CFpsSlap::CFpsSlap(): CFps()
{
	m_src = NULL;
}

CFpsSlap::~CFpsSlap()
{
	if (m_src != NULL)
	{
		delete [] m_src;
		m_src = NULL;
	}
}

int CFpsSlap::Preprocessing()
{
	m_srcScale += ResizeDecFastForDPI8(m_img, m_imgW, m_imgH, m_srcPPI, 200);

	const unsigned int w = m_imgW;
	const unsigned int h = m_imgH;

	Equalize8(m_img, w, h, 16);
	Blur8(m_img, w, h, 4);

	int res = GetClone8(m_img, w, h, m_src);

	if (res != GRAPH_RES_SUCCESS)
	{
		return res;
	}

	if ((m_srcImpType == IMP_TYPE_FP_NON_LS_PL) ||
	    (m_srcImpType == IMP_TYPE_FP_NON_LS_RD))
	{
		int col = ArrGetMean8(m_img, w * h);

		DeleteLongLinesH8(m_img, w, h, w / 3);
		ChangeColors8(m_img, w, h, 0, 3, col + ((255 - col) >> 1));
	}

	if ((m_srcImpType == IMP_TYPE_FP_LS_PL)           ||
	    (m_srcImpType == IMP_TYPE_FP_LS_RD)           ||
	    (m_srcImpType == IMP_TYPE_FP_LS_V_SWIPE)      ||
	    (m_srcImpType == IMP_TYPE_FP_LS_OP_CT_PL)     ||
	    (m_srcImpType == IMP_TYPE_FP_LS_OP_CT_RD)     ||
	    (m_srcImpType == IMP_TYPE_FP_LS_NON_OP_CT_PL) ||
	    (m_srcImpType == IMP_TYPE_FP_LS_NON_OP_CT_RD) ||
	    (m_srcImpType == IMP_TYPE_FP_LS_OP_CS_PL)     ||
	    (m_srcImpType == IMP_TYPE_FP_LS_OP_CS_RD)     ||
	    (m_srcImpType == IMP_TYPE_FP_LS_NON_OP_CS_PL) ||
	    (m_srcImpType == IMP_TYPE_FP_LS_NON_OP_CS_RD) ||
	    (m_srcImpType == IMP_TYPE_FP_LS_OP_MS_PL)     ||
	    (m_srcImpType == IMP_TYPE_FP_LS_OP_MS_RD))
	{
		int delta = (int)(w * h) - 4 * 
		            ((((300 * m_srcPPI) / 500) * ((450 * m_srcPPI) / 500)) >> 
		             (2 * m_srcScale));

		delta = (100 * delta) / (int)(w * h);

		if (delta > 0)
		{
			ArrAutoLevels8(m_img, w * h, 0, delta);
		}

		BinarizationC8(m_img, w, h, 230);
	}
	else
	{
		if (m_srcRotation == false)
		{
			int fingerWidth  = ((350 * m_srcPPI) / 500) >> m_srcScale;
			int fingersCount = 1;

			if (fingerWidth > 0)
			{
				fingersCount = (w + (fingerWidth / 2)) / fingerWidth;

				if (fingersCount < 1)  fingersCount = 1; else
				if (fingersCount > 4)  fingersCount = 4;
			}

			for (int i = 0; i < fingersCount; i++)
			{
				res = BinarizationX8(m_img, w, h, 
				                     (i * w) / fingersCount, 0, 
				                     (((i + 1) * w) / fingersCount) - 1, h - 1);

				if (res != GRAPH_RES_SUCCESS)
				{
					return res;
				}
			}
		}
		else
		{
			res = BinarizationX8(m_img, w, h, 0, 0, w - 1, h - 1);

			if (res != GRAPH_RES_SUCCESS)
			{
				return res;
			}
		}
	}

	DeleteSpots8(m_img, w, h, 0, 1, 16);
	DeleteLines8(m_img, w, h, 0, 0, w - 1, h - 1, 0, 2, 20);
	ExpandLines8(m_img, w, h, 0, 1, 4);
	DeleteLines8(m_img, w, h, 0, 0, w - 1, h - 1, 0, 1, 8);

	return GRAPH_RES_SUCCESS;
}

void CFpsSlap::DelRects()
{
	int i, j, n;
	int y1, y2;
	int b1, b2;
	int l1, l2;
	int w1, w2;
	int dy1, dy2;

	double u1, u2;

	const double piDiv6 = (double)(PI / 6.0);


	for (i = 0; i < m_rectsCount; i++)
	{
		y1 = m_rects[i].y1;
		y2 = m_rects[i].y2;

		if (((y1 <= 4) || (y2 >= (int)(m_imgH - 4))) && (m_rects[i].length < 30))
		{
			m_rects[i].type = -1;
		}
		else
		{
			y1 = m_rects[i].yc;
			b1 =(m_rects[i].y2 + y1) >> 1;
			l1 = m_rects[i].dy;
			u1 = m_rects[i].angle;
			w1 = m_rects[i].width;

			for (j = i + 1; j < m_rectsCount; j++)
			{
				y2 = m_rects[j].yc;
				b2 =(m_rects[j].y2 + y2) >> 1;
				l2 = m_rects[j].dy;
				u2 = m_rects[j].angle;
				w2 = m_rects[j].width;

				dy1 = abs(y1 - y2);
				dy2 = (l1 + l2) >> 1;

				if ((dy1 < (dy2 + 24)) && (fabs(u1 - u2) < piDiv6))
				{
					if (y1 > y2)
					{
						if (m_rects[j].
						    isPointInRect(m_rects[i].getX(b2), b2, 15) == 1)
						{
							m_rects[i].type = -1;
						}

					} else

					if (y2 > y1)
					{
						if (m_rects[i].
						    isPointInRect(m_rects[j].getX(b1), b1, 15) == 1)
						{
							m_rects[j].type = -1;
						}
					}
				}
			}
		}
	}

	n = 0;

	for (i = 0; i < m_rectsCount; i++)
	{
		if (m_rects[i].type != -1)
		{
			if (i > n)
			{
				m_rects[n] = m_rects[i];
			}

			n++;
		}
	}

	m_rectsCount = n;
}

const double yT1 = (double) 0.9;
const double yT2 = (double)-1.3;
const double yT3 = (double)-2.1;
const double yT4 = (double)-1.1;

#define TEMPLS_COUNT 22

TEMPL templs[TEMPLS_COUNT] = 
{
	{SGM_HAND_LEFT,  4, (double)fabs(yT1 - yT3), {yT1, yT2, yT3, yT4}, {POS_CODE_L_LITTLE_F, POS_CODE_L_RING_F,   POS_CODE_L_MIDDLE_F, POS_CODE_L_INDEX_F},  {(double)1.0, (double)1.0, (double)1.0, (double)0.0}}, 
	{SGM_HAND_LEFT,  3, (double)fabs(yT1 - yT3), {yT1, yT2, yT3, 0.0}, {POS_CODE_L_LITTLE_F, POS_CODE_L_RING_F,   POS_CODE_L_MIDDLE_F, POS_CODE_U_FINGER},   {(double)1.0, (double)1.0, (double)0.0, (double)0.0}},
	{SGM_HAND_LEFT,  3, (double)fabs(yT1 - yT2), {yT1, yT2, yT4, 0.0}, {POS_CODE_L_LITTLE_F, POS_CODE_L_RING_F,   POS_CODE_L_INDEX_F,  POS_CODE_U_FINGER},   {(double)0.8, (double)1.2, (double)0.0, (double)0.0}},
	{SGM_HAND_LEFT,  3, (double)fabs(yT1 - yT3), {yT1, yT3, yT4, 0.0}, {POS_CODE_L_LITTLE_F, POS_CODE_L_MIDDLE_F, POS_CODE_L_INDEX_F,  POS_CODE_U_FINGER},   {(double)1.2, (double)0.8, (double)0.0, (double)0.0}},
	{SGM_HAND_LEFT,  3, (double)fabs(yT3 - yT4), {yT2, yT3, yT4, 0.0}, {POS_CODE_L_RING_F,   POS_CODE_L_MIDDLE_F, POS_CODE_L_INDEX_F,  POS_CODE_U_FINGER},   {(double)1.0, (double)1.0, (double)0.0, (double)0.0}},
	{SGM_HAND_LEFT,  2, (double)fabs(yT1 - yT2), {yT1, yT2, 0.0, 0.0}, {POS_CODE_L_LITTLE_F, POS_CODE_L_RING_F,   POS_CODE_U_FINGER,   POS_CODE_U_FINGER},   {(double)1.0, (double)0.0, (double)0.0, (double)0.0}},
	{SGM_HAND_LEFT,  2, (double)fabs(yT1 - yT3), {yT1, yT3, 0.0, 0.0}, {POS_CODE_L_LITTLE_F, POS_CODE_L_MIDDLE_F, POS_CODE_U_FINGER,   POS_CODE_U_FINGER},   {(double)1.0, (double)0.0, (double)0.0, (double)0.0}},
	{SGM_HAND_LEFT,  2, (double)fabs(yT1 - yT4), {yT1, yT4, 0.0, 0.0}, {POS_CODE_L_LITTLE_F, POS_CODE_L_INDEX_F,  POS_CODE_U_FINGER,   POS_CODE_U_FINGER},   {(double)1.0, (double)0.0, (double)0.0, (double)0.0}},
	{SGM_HAND_LEFT,  2, (double)fabs(yT2 - yT3), {yT2, yT3, 0.0, 0.0}, {POS_CODE_L_RING_F,   POS_CODE_L_MIDDLE_F, POS_CODE_U_FINGER,   POS_CODE_U_FINGER},   {(double)1.0, (double)0.0, (double)0.0, (double)0.0}},
	{SGM_HAND_LEFT,  2, (double)fabs(yT2 - yT4), {yT2, yT4, 0.0, 0.0}, {POS_CODE_L_RING_F,   POS_CODE_L_INDEX_F,  POS_CODE_U_FINGER,   POS_CODE_U_FINGER},   {(double)1.0, (double)0.0, (double)0.0, (double)0.0}},
	{SGM_HAND_LEFT,  2, (double)fabs(yT3 - yT4), {yT3, yT4, 0.0, 0.0}, {POS_CODE_L_MIDDLE_F, POS_CODE_L_INDEX_F,  POS_CODE_U_FINGER,   POS_CODE_U_FINGER},   {(double)1.0, (double)0.0, (double)0.0, (double)0.0}},

	{SGM_HAND_RIGHT, 4, (double)fabs(yT1 - yT3), {yT4, yT3, yT2, yT1}, {POS_CODE_R_INDEX_F,  POS_CODE_R_MIDDLE_F, POS_CODE_R_RING_F,   POS_CODE_R_LITTLE_F}, {(double)1.0, (double)1.0, (double)1.0, (double)0.0}},
	{SGM_HAND_RIGHT, 3, (double)fabs(yT3 - yT4), {yT4, yT3, yT2, 0.0}, {POS_CODE_R_INDEX_F,  POS_CODE_R_MIDDLE_F, POS_CODE_R_RING_F,   POS_CODE_U_FINGER},   {(double)1.0, (double)1.0, (double)0.0, (double)0.0}},
	{SGM_HAND_RIGHT, 3, (double)fabs(yT1 - yT3), {yT4, yT3, yT1, 0.0}, {POS_CODE_R_INDEX_F,  POS_CODE_R_MIDDLE_F, POS_CODE_R_LITTLE_F, POS_CODE_U_FINGER},   {(double)0.8, (double)1.2, (double)0.0, (double)0.0}},
	{SGM_HAND_RIGHT, 3, (double)fabs(yT1 - yT2), {yT4, yT2, yT1, 0.0}, {POS_CODE_R_INDEX_F,  POS_CODE_R_RING_F,   POS_CODE_R_LITTLE_F, POS_CODE_U_FINGER},   {(double)1.2, (double)0.8, (double)0.0, (double)0.0}},
	{SGM_HAND_RIGHT, 3, (double)fabs(yT1 - yT3), {yT3, yT2, yT1, 0.0}, {POS_CODE_R_MIDDLE_F, POS_CODE_R_RING_F,   POS_CODE_R_LITTLE_F, POS_CODE_U_FINGER},   {(double)1.0, (double)1.0, (double)0.0, (double)0.0}},
	{SGM_HAND_RIGHT, 2, (double)fabs(yT4 - yT3), {yT4, yT3, 0.0, 0.0}, {POS_CODE_R_INDEX_F,  POS_CODE_R_MIDDLE_F, POS_CODE_U_FINGER,   POS_CODE_U_FINGER},   {(double)1.0, (double)0.0, (double)0.0, (double)0.0}},
	{SGM_HAND_RIGHT, 2, (double)fabs(yT4 - yT2), {yT4, yT2, 0.0, 0.0}, {POS_CODE_R_INDEX_F,  POS_CODE_R_RING_F,   POS_CODE_U_FINGER,   POS_CODE_U_FINGER},   {(double)1.0, (double)0.0, (double)0.0, (double)0.0}},
	{SGM_HAND_RIGHT, 2, (double)fabs(yT4 - yT1), {yT4, yT1, 0.0, 0.0}, {POS_CODE_R_INDEX_F,  POS_CODE_R_LITTLE_F, POS_CODE_U_FINGER,   POS_CODE_U_FINGER},   {(double)1.0, (double)0.0, (double)0.0, (double)0.0}},
	{SGM_HAND_RIGHT, 2, (double)fabs(yT3 - yT2), {yT3, yT2, 0.0, 0.0}, {POS_CODE_R_MIDDLE_F, POS_CODE_R_RING_F,   POS_CODE_U_FINGER,   POS_CODE_U_FINGER},   {(double)1.0, (double)0.0, (double)0.0, (double)0.0}},
	{SGM_HAND_RIGHT, 2, (double)fabs(yT3 - yT1), {yT3, yT1, 0.0, 0.0}, {POS_CODE_R_MIDDLE_F, POS_CODE_R_LITTLE_F, POS_CODE_U_FINGER,   POS_CODE_U_FINGER},   {(double)1.0, (double)0.0, (double)0.0, (double)0.0}},
	{SGM_HAND_RIGHT, 2, (double)fabs(yT2 - yT1), {yT2, yT1, 0.0, 0.0}, {POS_CODE_R_RING_F,   POS_CODE_R_LITTLE_F, POS_CODE_U_FINGER,   POS_CODE_U_FINGER},   {(double)1.0, (double)0.0, (double)0.0, (double)0.0}}
};

double CFpsSlap::TestSlap(int templIndex,
                          int fingersCount,
                          int *indexes,
                          int *indexesSort)
{
	int i, j, k, ni;

	int x, y, ry;
	int dx, dy, dym;
	int x1, y1;
	int x2, y2;
	int dy1, dy2;

	double a  = 0;
	double b  = 0;
//	double u  = 0;
	double rs = 0;

	int xc = 0;
	int yc = 0;
	int ws = 0;
	int rx = 0;

	unsigned int l;
//	unsigned int ls = 0;

	CSpot slapRect;


	// ����������� ����������� ���������������

	for (i = 0; i < fingersCount; i++)
	{
		ni = indexes[i];

		indexesSort[i] = ni;
		m_slapRects[i]   = m_rects[ni];

		ws += m_rects[ni].width;
/*
		l   = m_rects[ni].Length;
		u  += m_rects[ni].Angle * l;
		ls += l;
*/
	}

	ws /= fingersCount;
//	u  /= (double)ls;

	l = (int)(3.3 * ws);

	for (i = 0; i < fingersCount; i++)
	{
//		SlapRects[i].SetAngle(u - SlapRects[i].Angle, 0);

		x1 = m_slapRects[i].x1;
		y1 = m_slapRects[i].y1;
		x2 = m_slapRects[i].x2;
		y2 = m_slapRects[i].y2;

		if ((y1 < 2) && (m_slapRects[i].b != 0))
		{
			y1 = -25;
			x1 = m_slapRects[i].getX(y1);
		}

		if (m_slapRects[i].length < l)
		{
			rs += (double)(0.6 * (l - m_slapRects[i].length));
		}
		else
		{
			y2 = y1 + (int)(m_slapRects[i].a * l);
			x2 = m_slapRects[i].getX(y2);
		}

		m_slapRects[i].init(x1, y1, x2, y2, m_slapRects[i].width);

		a  += m_slapRects[i].a;
		b  += m_slapRects[i].b;
		xc += m_slapRects[i].xc;
		yc += m_slapRects[i].yc;
	}

	a  /= (double)fingersCount;
	b  /= (double)fingersCount;
	xc /= fingersCount;
	yc /= fingersCount;


	// �������� � ������ ��������� � �������

	for (i = 0; i < fingersCount; i++)
	{
		m_slapRects[i].move(-xc, -yc);
		m_slapRects[i].rotate(a, -b);
	}

	// ���������� �� X

	for (k = 1; k != 0;)
	{
		for (i = 0, j = 1, k = 0; j < fingersCount; i = j, j++)
		{
			if (m_slapRects[i].xc > m_slapRects[j].xc)
			{
				k = 1;

				slapRect       = m_slapRects[i];
				m_slapRects[i] = m_slapRects[j];
				m_slapRects[j] = slapRect;

				ni = indexesSort[i];

				indexesSort[i] = indexesSort[j];
				indexesSort[j] = ni;
			}
		}
	}

	y1 = m_imgW;
	y2 = 0;

	dym = 0;

	for (i = 0; i < fingersCount; i++)
	{
		y = m_slapRects[i].y1;

		if (y < y1)  y1 = y;

		y = (int)(y + 3.55 * ws * m_slapRects[i].a);

		if (y > y2)  y2 = y;

		if (i > 0)
		{
			dx  = abs(m_slapRects[i].xc - m_slapRects[i - 1].xc);
			rx += dx;

			if (dx < 1.5 * ws) return -1;
		}

		for (j = 0; j < fingersCount; j++)
		{
			if (i != j)
			{
				dy = abs(m_slapRects[i].y1 - m_slapRects[j].y1);

				if (dym < dy)
				    dym = dy;
			}
		}
	}

//	if (dym < 2.3 * ws)  return -1;


	rx /= (fingersCount - 1);
	ry  = (int)((y2 - y1) / (templs[templIndex].sy + 2));
	x   = (int)(-0.5 * rx * (fingersCount - 1));

	if (rx < 1.8 * ws)  return -1;

	rs += rx;

	//if (ry > 3 * ws)  return -1;

	for (i = 0; i < fingersCount; i++)
	{
		y1 = (int)(ry * templs[templIndex].p[i]);
		y2 = (int)(y1 + 3.6 * ws);

		m_slapTempl[i].init(x, y1, x, y2, (int)(0.9 * ws));

		x += (int)(rx * templs[templIndex].kx[i]);
	}

	for (i = 1; i < fingersCount; i++)
	{
		y1 = m_slapTempl[i].y1;
		y2 = m_slapRects[i].y1;

		dy1 = y1 - m_slapTempl[i - 1].y1;
		dy2 = y2 - m_slapRects[i - 1].y1;

		if (((dy1 < 0) && (dy2 >  ws)) ||
		    ((dy1 > 0) && (dy2 < -ws)))
		{
			return -1;
		}
	}

	for (i = 0; i < fingersCount; i++)
	{
		rs += abs(m_slapTempl[i].y1 - m_slapRects[i].y1);
		rs += abs(m_slapTempl[i].y2 - m_slapRects[i].y2);
		rs += (double)(0.6 * abs(m_slapTempl[i].xc - m_slapRects[i].xc));
		rs += abs((int)m_slapTempl[i].length - (int)m_slapRects[i].length);
		rs += abs((int)m_slapTempl[i].width  - (int)m_slapRects[i].width);

		//if (fabs(SlapTempl[i].yc - SlapRects[i].yc) > 1.5 * ws)  return -1;
		//if (fabs(SlapTempl[i].xc - SlapRects[i].xc) > 0.5 * ws)  return -1;

		if (//(SlapRects[i].IsPointInRect(SlapTempl[i].xc, SlapTempl[i].yc, 0) == 0) ||
		    (m_slapTempl[i].
		     isPointInRect(m_slapRects[i].xc, m_slapRects[i].yc, 0) == 0))
		{
			return -1;
		}
	}

	return rs;
}

void CFpsSlap::FindSlap4(SGM_FINGER *exclPos, unsigned int exclPosCount)
{
	m_fingerRectsCount = 0;

	if (m_rectsCount == 0)  return;

	int i, j, n;
	int templIndex   = -1;
	int templIndexL  = -1;
	int templIndexR  = -1;
	int exclPosIndex = -1;

	bool exclTempl = false;

	int indTest[4];
	int indSort[4];
	int indSlapL[4];
	int indSlapR[4];

	double errorCurr = 0.0;
	double errorMinL = 0.0;
	double errorMinR = 0.0;


	for (int fingersCount = (m_rectsCount >= 4) ? 4 : m_rectsCount; 
	     fingersCount >= 2; fingersCount--)
	{
		templIndexL = -1;
		templIndexR = -1;

		errorMinL = (double)(m_imgH * m_imgH);
		errorMinR = errorMinL;

		n = (m_rectsCount < 3) ? m_rectsCount : 3;

		for (templIndex = 0; templIndex < TEMPLS_COUNT; templIndex++)
		{
			if (templs[templIndex].n == fingersCount)
			{
				exclTempl = false;

				for (exclPosIndex = 0; exclPosIndex < (int)exclPosCount; 
				     exclPosIndex++)
				{
					for (j = 0; j < fingersCount; j++)
					{
						if (templs[templIndex].pos[j] == exclPos[exclPosIndex])
						{
							exclTempl = true;
							exclPosIndex = exclPosCount;
							break;
						}
					}
				}

				if (exclTempl == false)
				{
					for (j = 0; j < fingersCount; j++)
					{
						indTest[j] = j;
					}

					while (indTest[0] < n)
					{
						errorCurr = TestSlap(templIndex, fingersCount, indTest, 
						                     indSort);

						if (errorCurr != -1)
						{
							if (templs[templIndex].hand == SGM_HAND_LEFT)
							{
								if (errorCurr < errorMinL)
								{
									errorMinL   = errorCurr;
									templIndexL = templIndex;

									for (j = 0; j < fingersCount; j++)
									{
										indSlapL[j] = indSort[j];
									}
								}

							} else

							if (templs[templIndex].hand == SGM_HAND_RIGHT)
							{
								if (errorCurr < errorMinR)
								{
									errorMinR   = errorCurr;
									templIndexR = templIndex;

									for (j = 0; j < fingersCount; j++)
									{
										indSlapR[j] = indSort[j];
									}
								}
							}
						}

						indTest[fingersCount - 1]++;

						while ((indTest[fingersCount - 1] >= m_rectsCount) && 
						       (indTest[0] < n))
						{
							j = fingersCount - 1;

							while ((j > 0) && (indTest[j] >= m_rectsCount))
							{
								j--;
								indTest[j]++;
							}

							for (j++; j < fingersCount; j++)
							{
								indTest[j] = indTest[j - 1] + 1;
							}
						}
					}
				}
			}
		}

		if ((templIndexL != -1) || (templIndexR != -1))
		{
			if ((templIndexL != -1) &&
			    ((m_srcHand == SGM_HAND_LEFT)           ||
			     (m_srcHand == SGM_HAND_PROBABLY_LEFT)  ||
			    ((m_srcHand == SGM_HAND_PROBABLY_RIGHT) &&  (templIndexR == -1)) ||
			    ((m_srcHand == SGM_HAND_UNKNOWN)        && ((templIndexR == -1)  || 
			     (errorMinL <= errorMinR)))))
			{
				TestSlap(templIndexL, fingersCount, indSlapL, indSort);

				m_resHand = SGM_HAND_LEFT;
				m_fingerRectsCount = fingersCount;

				for (j = 0; j < fingersCount; j++)
				{
					m_fingerRects[j]         = m_rects[indSlapL[j]];
					m_fingerRects[j].type    = templs[templIndexL].pos[j];
					m_fingerRects[j].segment = SGM_SEGMENT_DISTAL;
				}

				return;
			}

			if ((templIndexR != -1) &&
			    ((m_srcHand == SGM_HAND_RIGHT)          ||
			     (m_srcHand == SGM_HAND_PROBABLY_RIGHT) ||
			    ((m_srcHand == SGM_HAND_PROBABLY_LEFT)  &&  (templIndexL == -1)) ||
			    ((m_srcHand == SGM_HAND_UNKNOWN)        && ((templIndexL == -1)  || 
			     (errorMinR <= errorMinL)))))
			{
				TestSlap(templIndexR, fingersCount, indSlapR, indSort);

				m_resHand = SGM_HAND_RIGHT;
				m_fingerRectsCount = fingersCount;

				for (j = 0; j < fingersCount; j++)
				{
					m_fingerRects[j]         = m_rects[indSlapR[j]];
					m_fingerRects[j].type    = templs[templIndexR].pos[j];
					m_fingerRects[j].segment = SGM_SEGMENT_DISTAL;
				}

				return;
			}
		}
	}

	if (m_fingerRectsCount == 0)
	{
		int st;
		int sm = 0;

		j = -1;

		for (i = 0; i < m_rectsCount; i++)
		{
			st = m_rects[i].width * m_rects[i].length;

			if (sm < st)
			{
				sm = st;
				j  = i;
			}
		}

		if (j != -1)
		{
			m_fingerRects[0]         = m_rects[j];
			m_fingerRects[0].type    = POS_CODE_U_FINGER;
			m_fingerRects[0].segment = SGM_SEGMENT_DISTAL;

			m_fingerRectsCount = 1;

			const NIST_POS_CODE fingers[8] = 
			{
				POS_CODE_R_INDEX_F,
				POS_CODE_R_MIDDLE_F,
				POS_CODE_R_RING_F,
				POS_CODE_R_LITTLE_F,

				POS_CODE_L_LITTLE_F,
				POS_CODE_L_RING_F,
				POS_CODE_L_MIDDLE_F,
				POS_CODE_L_INDEX_F
			};

			int iFirst = 0;
			int iLast  = 7;

			if ((m_srcHand == SGM_HAND_LEFT)  || 
			    (m_srcHand == SGM_HAND_PROBABLY_LEFT))  iFirst = 4; else

			if ((m_srcHand == SGM_HAND_RIGHT) || 
			    (m_srcHand == SGM_HAND_PROBABLY_RIGHT)) iLast  = 3;

			for (i = iFirst; i <= iLast; i++)
			{
				exclTempl = false;

				for (exclPosIndex = 0; exclPosIndex < (int)exclPosCount; 
				     exclPosIndex++)
				{
					if (fingers[i] == exclPos[exclPosIndex])
					{
						exclTempl = true;
						break;
					}
				}

				if (exclTempl == false)
				{
					m_fingerRects[0].type    = fingers[i];
					m_fingerRects[0].segment = SGM_SEGMENT_DISTAL;
					break;
				}
			}
		}
	}
}

void CFpsSlap::CorrectSlapRectsTypes(SGM_FINGER *exclPos, 
                                     unsigned int exclPosCount)
{
	if ((m_fingerRectsCount == 0) || 
	    (m_fingerRectsCount >= 4))  return;

	const unsigned int w = m_imgW;
	const unsigned int h = m_imgH;

	int i;
	int x, y;

	int xc = w >> 1;
	int yc = h >> 1;

	CSpot tempRect;
	int   tempTypes[3];


	for (i = 0; i < m_fingerRectsCount; i++)
	{
		tempRect = m_fingerRects[i];

		tempRect.move(-xc, -yc);
		tempRect.rotate(tempRect.a, -tempRect.b);
		tempRect.move(xc, yc);
		tempRect.setAngleAndLength(tempRect.angle, 3 * tempRect.width, 24);

		x = tempRect.xc;
		y = tempRect.yc;

		if (m_resHand == SGM_HAND_LEFT)
		{
			if (x < 0.25 * w)  tempTypes[i] = POS_CODE_L_LITTLE_F; else
			if (x < 0.50 * w)  tempTypes[i] = POS_CODE_L_RING_F;   else
			if (x < 0.75 * w)  tempTypes[i] = POS_CODE_L_MIDDLE_F; else
			                   tempTypes[i] = POS_CODE_L_INDEX_F;
		} else

		if (m_resHand == SGM_HAND_RIGHT)
		{
			if (x < 0.25 * w)  tempTypes[i] = POS_CODE_R_INDEX_F;  else
			if (x < 0.50 * w)  tempTypes[i] = POS_CODE_R_MIDDLE_F; else
			if (x < 0.75 * w)  tempTypes[i] = POS_CODE_R_RING_F;   else
			                   tempTypes[i] = POS_CODE_R_LITTLE_F;
		} 
		else
		{
			if (x < 0.25 * w)
				tempTypes[i] = (y > 0.50 * h) ? POS_CODE_L_LITTLE_F
				                              : POS_CODE_R_INDEX_F;  else
			if (x < 0.50 * w)
				tempTypes[i] = (y > 0.25 * h) ? POS_CODE_L_RING_F
				                              : POS_CODE_R_MIDDLE_F; else
			if (x < 0.75 * w)
				tempTypes[i] = (y < 0.25 * h) ? POS_CODE_L_MIDDLE_F
				                              : POS_CODE_R_RING_F;
			else
				tempTypes[i] = (y < 0.50 * h) ? POS_CODE_L_INDEX_F
				                              : POS_CODE_R_LITTLE_F;
		}
	}

	if (m_fingerRectsCount == 1)
	{
		m_fingerRects[0].type = tempTypes[0];
	}
	else
	{
		int j, k;
		int n = 0;

		for (i = 0; i < m_fingerRectsCount; i++)
		{
			if (m_fingerRects[i].type == tempTypes[i])
			{
				n = 1;
				break;
			}
		}

		if (n == 1)
		{
			for (k = 0; k < 3; k++)
			{
				for (i = 0; i < m_fingerRectsCount; i++)
				{
					if (m_fingerRects[i].type != tempTypes[i])
					{
						n = 0;

						if (m_resHand == SGM_HAND_LEFT)
						{
							for (j = 0; j < i; j++)
							{
								if (tempTypes[i] >= m_fingerRects[j].type)
								{
									n = 1;
									break;
								}
							}

							if (n == 0)
							{
								for (j = i + 1; j < m_fingerRectsCount; j++)
								{
									if (tempTypes[i] <= m_fingerRects[j].type)
									{
										n = 1;
										break;
									}
								}

								if (n == 0)
								{
									m_fingerRects[i].type = tempTypes[i];
								}
							}

						} else

						if (m_resHand == SGM_HAND_RIGHT)
						{
							for (j = 0; j < i; j++)
							{
								if (tempTypes[i] <= m_fingerRects[j].type)
								{
									n = 1;
									break;
								}
							}

							if (n == 0)
							{
								for (j = i + 1; j < m_fingerRectsCount; j++)
								{
									if (tempTypes[i] >= m_fingerRects[j].type)
									{
										n = 1;
										break;
									}
								}

								if (n == 0)
								{
									m_fingerRects[i].type = tempTypes[i];
								}
							}
						}
					}
				}
			}
		}
	}
}

void CFpsSlap::CorrectSlapRectsSize()
{
	if (m_fingerRectsCount == 0) return;

	int i, w, l;

	int ws = 0;
	int ls = 0;

	bool err = false;


	for (i = 0; i < m_fingerRectsCount; i++)
	{
		ws += m_fingerRects[i].width;
		ls += m_fingerRects[i].length;
	}

	ws /= m_fingerRectsCount;
	ls /= m_fingerRectsCount;


	int w1 = ws - 8;
	int w2 = ws + 8;
	int l1 = ls - 4;
	int l2 = ls << 1;

	for (i = 0; i < m_fingerRectsCount; i++)
	{
		w = m_fingerRects[i].width;
		l = m_fingerRects[i].length;

		if (l < l1)
		{
			m_fingerRects[i].err = -(2 + ls - l);
			err = true;

		} else

		if (ls < (ws<<1)) 
		{
			m_fingerRects[i].err = -(2 + (ws << 1) - ls);
			err = true;

		} else

		if (w < w1)
		{
			m_fingerRects[i].err = -1;
			err = true;
		}
/*
		if ((ws > w2) || (ls > l2))
		{
			m_fingerRects[i].err =  1;
			err = true;

		} else
*/
	}

	if (err == false) return;


	int x1, y1, x2, y2, xt, yt;
	int x1r, y1r, x2r, y2r, x, y;
	int wa, wb;

	for (i = 0; i < m_fingerRectsCount; i++)
	{
		if (m_fingerRects[i].err < -1)
		{
			ws = m_fingerRects[i].width;
			wa = (int)(ws * m_fingerRects[i].a);
			wb = (int)(ws * m_fingerRects[i].b);

			yt = m_fingerRects[i].y1 + m_fingerRects[i].err - 
			     (int)(4 * m_fingerRects[i].a);
			xt = m_fingerRects[i].getX(yt);

			x1 = xt - wa;
			y1 = yt - wb;
			x2 = xt + wa;
			y2 = yt + wb;

			if (x1 < x2)
			{
				x1r = x1;
				x2r = x2;
			}
			else
			{
				x1r = x2;
				x2r = x1;
			}

			if (y1 < y2)
			{
				y1r = y1;
				y2r = y2;
			}
			else
			{
				y1r = y2;
				y2r = y1;
			}

			x = m_fingerRects[i].xc;
			y = m_fingerRects[i].yc;

			x1 = x - wa;
			y1 = y - wb;
			x2 = x + wa;
			y2 = y + wb;

			if (x1 < x1r)  x1r = x1; else
			if (x1 > x2r)  x2r = x1;
			if (y1 < y1r)  y1r = y1; else
			if (y1 > y2r)  y2r = y1;
			if (x2 < x1r)  x1r = x2; else
			if (x2 > x2r)  x2r = x2;
			if (y2 < y1r)  y1r = y2; else
			if (y2 > y2r)  y2r = y2;

			x = (x2r - x1r) >> 1;

			x1r -= x;
			x2r += x;

			if (x1r < 0)  x1r = 0;
			if (y1r < 0)  y1r = 0;

			if (x2r >= (int)m_imgW)  x2r = (int)(m_imgW - 1);
			if (y2r >= (int)m_imgH)  y2r = (int)(m_imgH - 1);

			memcpy(m_img, m_src, m_imgW * m_imgH);

			BinarizationX8(m_img, m_imgW, m_imgH, x1r, y1r, x2r, y2r);

			int yMin = yt;
			int yMax = m_fingerRects[i].y1 - 1;

			for (y = yMax; y >= yMin; y--)
			{
				x  = m_fingerRects[i].getX(y);

				x1 = x - wa;
				y1 = y - wb;
				x2 = x + wa;
				y2 = y + wb;

				if (LineN8(m_img, m_imgW, m_imgH, x1, y1, x2, y2, 1) <= 12)
				{
					break;
				}
			}

			y1 = y - (int)(2 * m_fingerRects[i].a);
			x1 = m_fingerRects[i].getX(y);
			x2 = m_fingerRects[i].x2;
			y2 = m_fingerRects[i].y2;

			m_fingerRects[i].init(x1, y1, x2, y2, ws);
		}
	}
}

int CFpsSlap::Recognition(SGM_FINGER *exclPos, unsigned int exclPosCount)
{
	int nrmFingerWidth = ((350 * m_srcPPI) / 500) >> m_srcScale;
	int maxFingerWidth = ((467 * m_srcPPI) / 500) >> m_srcScale;

	FindRects(nrmFingerWidth / 2, maxFingerWidth / 2);
	DelRects();
	FindSlap4(exclPos, exclPosCount);

	if (m_srcRotation == true)
	{
		SlapAutoRotate();
	}

	CorrectRectsLength(2.5, 4.0, 3.4);
//	CorrectSlapRectsTypes(exclPos, exclPosCount);
	CorrectSlapRectsSize();
	CorrectRects(12, 10, 8);

	if ((m_fingerRectsCount == 1) && (6 * m_fingerRects[0].width > (int)m_imgW))
	{
		m_fingerRectsCount = 0;
	}

	return GRAPH_RES_SUCCESS;
}



////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  ����� CFpsThumbs - ����������� ���������� 2-� ������� �������.            //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

int CFpsThumbs::Preprocessing()
{
	m_srcScale += ResizeDecFastForDPI8(m_img, m_imgW, m_imgH, m_srcPPI, 200);

	const unsigned int w = m_imgW;
	const unsigned int h = m_imgH;

	Equalize8(m_img, w, h, 16);
	Blur8(m_img, w, h, 4);

	if ((m_srcImpType == IMP_TYPE_FP_NON_LS_PL) ||
	    (m_srcImpType == IMP_TYPE_FP_NON_LS_RD))
	{
		int col = ArrGetMean8(m_img, w * h);

//		DeleteLongLinesH(m_img, w, h, w / 3);
		ChangeColors8(m_img, w, h, 0, 3, col + ((255 - col) >> 1));
	}

	int xc = w >> 1;
	int yc = h >> 1;

	BinarizationX8(m_img, w, h, 0,      0,      xc,    yc);
	BinarizationX8(m_img, w, h, 0,      yc + 1, xc,    h - 1);
	BinarizationX8(m_img, w, h, xc + 1, 0,      w - 1, yc);
	BinarizationX8(m_img, w, h, xc + 1, yc + 1, w - 1, h - 1);

//	BinarizationN8(m_img, w, h);

	DeleteSpots8(m_img, w, h, 0, 1, 16);
	DeleteLines8(m_img, w, h, 0, 0, w - 1, h - 1, 0, 2, 24);
	ExpandLines8(m_img, w, h, 0, 1, 4);
	DeleteLines8(m_img, w, h, 0, 0, w - 1, h - 1, 0, 1, 8);

	return GRAPH_RES_SUCCESS;
}

void CFpsThumbs::FindRects()
{
	unsigned char *pi, *lp;
	unsigned char col = 10;

	const unsigned int wMax = m_imgW / 3;


	m_rectsCount = 0;

	Border8(m_img, m_imgW, m_imgH, 1);

	for (pi = m_img, lp = m_img + m_imgW * m_imgH; pi < lp; pi++)
	{
		if (*pi == 0)
		{
			if (m_rectsCount >= SGM_MAX_RECTS_COUNT)
			{
				break;
			}

//			Fill8(m_img, m_imgW, m_imgH, 0, 0, m_imgW - 1, m_imgH - 1, col, 254, pi);
			Fill8(m_img, m_imgW, m_imgH, pi, col);

			if (m_rects[m_rectsCount].initV(m_img, m_imgW, m_imgH, pi, col) == 0)
			{
				if (m_rects[m_rectsCount].width < wMax)
				{
					m_rectsCount++;
				}
				else
				{
					LineV8(m_img, m_imgW, m_imgH,
					       m_rects[m_rectsCount].xc,
					       m_rects[m_rectsCount].y1,
					       m_rects[m_rectsCount].y2, 1);

					ChangeColor8(m_img, m_imgW, m_imgH, col, 0);

					pi = m_img;
				}
			}

			col++;

			if (col >= 254)
			{
				ChangeColors8(m_img, m_imgW, m_imgH, 10, 253, 255);
				col = 10;
			}
		}
	}
}

void CFpsThumbs::FindThumbs()
{
	if (m_rectsCount == 0)  return;

	int st;
	int sm = 0;

	int i1, i2;
	int i1s, i2s;


	if (m_rectsCount >= 2)
	{
		for (i1 = 0; i1 < m_rectsCount; i1++)
		{
			for (i2 = i1 + 1; i2 < m_rectsCount; i2++)
			{
				st = m_rects[i1].width * m_rects[i1].length + 
				     m_rects[i2].width * m_rects[i2].length;

				if (st > sm)
				{
					sm  = st;
					i1s = i1;
					i2s = i2;
				}
			}
		}
	}

	if (sm > 0)
	{
		if (m_rects[i1s].xc < m_rects[i2s].xc)
		{
			m_fingerRects[0] = m_rects[i1s];
			m_fingerRects[1] = m_rects[i2s];
		}
		else
		{
			m_fingerRects[0] = m_rects[i2s];
			m_fingerRects[1] = m_rects[i1s];
		}

		m_fingerRects[0].type    = POS_CODE_L_THUMB;
		m_fingerRects[0].segment = SGM_SEGMENT_DISTAL;

		m_fingerRects[1].type    = POS_CODE_R_THUMB;
		m_fingerRects[1].segment = SGM_SEGMENT_DISTAL;

		m_fingerRectsCount = 2;
	}
	else
	{
		sm =  0;
		i2 = -1;

		for (i1 = 0; i1 < m_rectsCount; i1++)
		{
			st = m_rects[i1].width * m_rects[i1].length;

			if (st > sm)
			{
				sm = st;
				i2 = i1;
			}
		}

		if (i2 != -1)
		{
			m_fingerRects[0] = m_rects[i2];
			m_fingerRects[0].type = (m_rects[i2].xc < (int)(m_imgW >> 1)) 
			                      ? POS_CODE_L_THUMB
			                      : POS_CODE_R_THUMB;
			m_fingerRects[0].segment = SGM_SEGMENT_DISTAL;
			m_fingerRectsCount = 1;
		}
	}
}

void CFpsThumbs::CorrectThumbs()
{
	if (m_fingerRectsCount != 2) return;


	int i, j;

	int dy = m_fingerRects[0].dy - m_fingerRects[1].dy;


	if (dy > 0)
	{
		i = 0;
		j = 1;
	}
	else
	{
		i = 1;
		j = 0;

		dy = -dy;
	}

	int x1 = m_fingerRects[i].xc;
	int x2 = m_fingerRects[j].xc;
	int w1 = (int)(1.1 * m_fingerRects[i].width);
	int w2 = (int)(1.1 * m_fingerRects[j].width);

	int y11 = m_fingerRects[i].y1;
	int y12 = m_fingerRects[i].y2;
	int y21 = m_fingerRects[j].y1;
	int y22 = m_fingerRects[j].y2;

	m_fingerRects[i].init(x1, y11, x1, y12, w1);

	if ((y11 < y21) && (y12 < y22))
	{
		m_fingerRects[j].init(x2, y21 - dy, x2, y22, w2);

	} else

	if ((y11 > y21) && (y12 > y22))
	{
		m_fingerRects[j].init(x2, y21, x2, y22 + dy, w2);

	} else

	if ((y11 < y21) && (y12 > y22))
	{
		m_fingerRects[j].init(x2, y11, x2, y12, w2);
	}
}

void CFpsThumbs::ExpandThumbs()
{
	const unsigned int addSize = 8 >> m_srcScale;

	for (int i = 0; i < m_fingerRectsCount; i++)
	{
		m_fingerRects[i].init(m_fingerRects[i].x1, m_fingerRects[i].y1 - addSize,
		                      m_fingerRects[i].x2, m_fingerRects[i].y2 + addSize,
		                      m_fingerRects[i].width + addSize);
	}
}

int CFpsThumbs::Recognition(SGM_FINGER *exclPos, unsigned int exclPosCount)
{
	FindRects();
	FindThumbs();

	CorrectRectsLength(2.0, 3.0, 2.3);
	CorrectRects(8, 6, 0);
	CorrectThumbs();
	ExpandThumbs();

	return GRAPH_RES_SUCCESS;
}



////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  ����� CFpsLowerPalm - ����������� ��������� 1-� ������                    //
//                        (��� ������� �� �����).                             //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

int CFpsLowerPalm::Preprocessing()
{
	m_srcScale += ResizeDecFastForDPI8(m_img, m_imgW, m_imgH, m_srcPPI, 50);

	const unsigned int w = m_imgW;
	const unsigned int h = m_imgH;

	Equalize8(m_img, w, h, 16);
	Blur8(m_img, w, h, 5);

	Binarization8(m_img, w, h);
	DeleteHLines8(m_img, w, h, 0, 0, w - 1, h - 1, 0, 2, 24);
	DeleteVLines8(m_img, w, h, 0, 0, w - 1, h - 1, 0, 2, 8);
	ExpandLines8(m_img, m_imgW, m_imgH, 0, 1, 4);

	return GRAPH_RES_SUCCESS;
}

void CFpsLowerPalm::FindRects()
{
	unsigned char col = 10;

	m_rectsCount = 0;

	Border8(m_img, m_imgW, m_imgH, 1);

	for (unsigned char *pi = m_img, *lp = m_img + m_imgW * m_imgH; pi < lp; pi++)
	{
		if (*pi == 0)
		{
			if (m_rectsCount >= SGM_MAX_RECTS_COUNT)
			{
				break;
			}

			Fill8(m_img, m_imgW, m_imgH, pi, col);

			if (m_rects[m_rectsCount].initV(m_img, m_imgW, m_imgH, pi, col) == 0)
			{
				if (m_srcRotation)
				{
					m_rects[m_rectsCount].setAngleAuto(true);
				}

				m_rectsCount++;
			}

			col++;

			if (col >= 254)
			{
				ChangeColors8(m_img, m_imgW, m_imgH, 10, 253, 255);
				col = 10;
			}
		}
	}
}

void CFpsLowerPalm::FindLowerPalm()
{
	if (m_rectsCount == 0)
	{
		return;
	}

	int maxRectArea  =  0;
	int maxRectIndex = -1;

	for (int rectIndex = 0; rectIndex < m_rectsCount; rectIndex++)
	{
		int rectArea = m_rects[rectIndex].width * m_rects[rectIndex].length;

		if (maxRectArea < rectArea)
		{
			maxRectArea  = rectArea;
			maxRectIndex = rectIndex;
		}
	}

	if (maxRectIndex != -1)
	{
		m_fingerRects[0] = m_rects[maxRectIndex];

		const double maxLowerPalmLength = 130.0;

		if (m_fingerRects->length > maxLowerPalmLength)
		{
			const double scaleFactor = maxLowerPalmLength / 
			                           (double)(m_fingerRects->length);

			m_fingerRects[0].init((int)(m_fingerRects[0].x2 + 
			                            scaleFactor * (m_fingerRects[0].x1 - 
			                                           m_fingerRects[0].x2)),
			                      (int)(m_fingerRects[0].y2 + 
			                            scaleFactor * (m_fingerRects[0].y1 - 
			                                           m_fingerRects[0].y2)),
			                      m_fingerRects[0].x2,
			                      m_fingerRects[0].y2,
			                      m_fingerRects[0].width);
		}

		const double interdigitalLength = 45.0;
		const double scaleFactor = interdigitalLength / 
		                           (double)(m_fingerRects->length);

		m_fingerRects[1] = m_fingerRects[0];
		m_fingerRects[1].init(m_fingerRects[1].x1, 
		                      m_fingerRects[1].y1, 
		                      (int)(m_fingerRects[1].x1 + 
		                      scaleFactor * (m_fingerRects[1].x2 - 
		                                     m_fingerRects[1].x1)),
		                      (int)(m_fingerRects[1].y1 + 
		                      scaleFactor * (m_fingerRects[1].y2 - 
		                                     m_fingerRects[1].y1)),
		                      m_fingerRects[1].width);

		if (m_resHand == SGM_HAND_UNKNOWN)
		{
			m_resHand = (m_fingerRects[0].angle > 0) ? SGM_HAND_LEFT 
			                                         : SGM_HAND_RIGHT;
		}

		if (m_resHand == SGM_HAND_LEFT)
		{
			m_fingerRects[0].type = POS_CODE_L_LOWER_PALM;
			m_fingerRects[1].type = POS_CODE_L_INTERDIGITAL;
		}
		else
		{
			m_fingerRects[0].type = POS_CODE_R_LOWER_PALM;
			m_fingerRects[1].type = POS_CODE_R_INTERDIGITAL;
		}

		m_fingerRectsCount = 2;
	}
}

int CFpsLowerPalm::Recognition(SGM_FINGER *exclPos, unsigned int exclPosCount)
{
	FindRects();
	FindLowerPalm();

	return GRAPH_RES_SUCCESS;
}



////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  ����� CFpsLowerPalms - ����������� ���������� 2-� �������                 //
//                         (��� ������� �� �����).                            //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

int CFpsLowerPalms::Preprocessing()
{
	m_srcScale += ResizeDecFastForDPI8(m_img, m_imgW, m_imgH, m_srcPPI, 50);

	const unsigned int w = m_imgW;
	const unsigned int h = m_imgH;

	Equalize8(m_img, w, h, 16);
	Blur8(m_img, w, h, 4);

	Binarization8(m_img, w, h);

	DeleteHLines8(m_img, w, h, 0, 0, w - 1, h - 1, 0, 1, 10);
	DeleteVLines8(m_img, w, h, 0, 0, w - 1, h - 1, 0, 1, 4);

	return GRAPH_RES_SUCCESS;
}

void CFpsLowerPalms::FindPalms()
{
	if (m_rectsCount == 0)  return;

	int st;
	int sm = 0;

	int i1, i2;
	int i1s, i2s;

	int wd2 = m_imgW >> 1;
	int hd2 = m_imgH >> 1;


	for (i1 = 0; i1 < m_rectsCount; i1++)
	{
		for (i2 = i1 + 1; i2 < m_rectsCount; i2++)
		{
			if ((((m_rects[i1].yc > m_rects[i2].y1)  && 
			      (m_rects[i1].yc < m_rects[i2].y2))  ||
			     ((m_rects[i2].yc > m_rects[i1].y1)  && 
			      (m_rects[i2].yc < m_rects[i1].y2))) &&
			     (abs(m_rects[i1].xc - m_rects[i2].xc) > 
			      0.8 * (m_rects[i1].width + m_rects[i2].width)))
			{
				st = m_rects[i1].width * m_rects[i1].length + 
				     m_rects[i2].width * m_rects[i2].length;

				if (sm < st)
				{
					sm = st;

					i1s = i1;
					i2s = i2;
				}
			}
		}
	}

	if (sm > 0)
	{
		if (m_rects[i1s].xc < m_rects[i2s].xc)
		{
			m_fingerRects[0] = m_rects[i1s];
			m_fingerRects[1] = m_rects[i2s];
		}
		else
		{
			m_fingerRects[0] = m_rects[i2s];
			m_fingerRects[1] = m_rects[i1s];
		}

		m_fingerRects[0].type = POS_CODE_L_LOWER_PALM;
		m_fingerRects[1].type = POS_CODE_R_LOWER_PALM;

		m_fingerRectsCount = 2;
	}
	else
	{
		sm =  0;
		i2 = -1;

		for (i1 = 0; i1 < m_rectsCount; i1++)
		{
			st = m_rects[i1].width * m_rects[i1].length;

			if (sm < st)
			{
				sm = st;
				i2 = i1;
			}
		}

		if (i2 != -1)
		{
			m_fingerRects[0] = m_rects[i2];

			m_fingerRects[0].type = (m_rects[i2].xc < wd2) ? POS_CODE_L_LOWER_PALM 
			                                               : POS_CODE_R_LOWER_PALM;

			m_fingerRectsCount = 1;
		}
	}

	int x1, y1;

	for (i1 = 0; i1 < m_fingerRectsCount; i1++)
	{
		if ((5 * m_fingerRects[i1].width) < m_fingerRects[i1].length)
		{
			y1 = (int)(m_fingerRects[i1].y2 - 
			     4 * m_fingerRects[i1].width * m_fingerRects[i1].a);
			x1 = m_fingerRects[i1].getX(y1);

			m_fingerRects[i1].init(x1, y1, 
			                       m_fingerRects[i1].x2, m_fingerRects[i1].y2, 
			                       m_fingerRects[i1].width);
		}
	}

	if (m_fingerRectsCount == 2)
	{
		int wa, wb;

		int w1 = m_fingerRects[0].width;
		int w2 = m_fingerRects[1].width;
		int dw = abs(w1 - w2);


		if (1.2 * w1 < w2)
		{
			wa = (int)(dw * m_fingerRects[1].a);
			wb = (int)(dw * m_fingerRects[1].b);

			m_fingerRects[1].init(m_fingerRects[1].x1 - wa,
			                      m_fingerRects[1].y1 - wb,
			                      m_fingerRects[1].x2 - wa,
			                      m_fingerRects[1].y2 - wb,
			                      w1);
		} else

		if (1.2 * w2 < w1)
		{
			wa = (int)(dw * m_fingerRects[0].a);
			wb = (int)(dw * m_fingerRects[0].b);

			m_fingerRects[0].init(m_fingerRects[0].x1 + wa,
			                      m_fingerRects[0].y1 + wb,
			                      m_fingerRects[0].x2 + wa,
			                      m_fingerRects[0].y2 + wb,
			                      w2);
		}
	}
}

int CFpsLowerPalms::Recognition(SGM_FINGER *exclPos, unsigned int exclPosCount)
{
	FindRects(m_imgW - (m_imgW >> 2), m_imgW - (m_imgW >> 2));
	FindPalms();

	if (m_srcRotation == true)
	{
		SlapAutoRotate();
	}

	return GRAPH_RES_SUCCESS;
}



////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  ����� CFpsWritersPalm - ����������� ��������� 1-�� ����� ������.          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

int CFpsWritersPalm::Preprocessing()
{
	m_srcScale += ResizeDecFastForDPI8(m_img, m_imgW, m_imgH, m_srcPPI, 50);

	const unsigned int w = m_imgW;
	const unsigned int h = m_imgH;

	Equalize8(m_img, w, h, 16);
	Blur8(m_img, w, h, 5);

	Binarization8(m_img, w, h);
	FillCavities8(m_img, m_imgW, m_imgH, 10, 10);
	DeleteHLines8(m_img, w, h, 0, 0, w - 1, h - 1, 0, 2, 9);
	DeleteVLines8(m_img, w, h, 0, 0, w - 1, h - 1, 0, 2, 9);
	ExpandLines8(m_img, m_imgW, m_imgH, 0, 1, 5);

	return GRAPH_RES_SUCCESS;
}

void CFpsWritersPalm::FindRects()
{
	unsigned char col = 10;


	m_rectsCount = 0;

	Border8(m_img, m_imgW, m_imgH, 1);

	for (unsigned char *pi = m_img, *lp = m_img + m_imgW * m_imgH; pi < lp; pi++)
	{
		if (*pi == 0)
		{
			if (m_rectsCount >= SGM_MAX_RECTS_COUNT)
			{
				break;
			}

			Fill8(m_img, m_imgW, m_imgH, pi, col);

			if (m_rects[m_rectsCount].initV(m_img, m_imgW, m_imgH, pi, col) == 0)
			{
				if (m_srcRotation)
				{
					m_rects[m_rectsCount].setAngleAuto(true);
				}

				m_rectsCount++;
			}

			col++;

			if (col >= 254)
			{
				ChangeColors8(m_img, m_imgW, m_imgH, 10, 253, 255);
				col = 10;
			}
		}
	}
}

void CFpsWritersPalm::FindWritersPalm()
{
	if (m_rectsCount == 0)
	{
		return;
	}

	int maxRectArea  =  0;
	int maxRectIndex = -1;

	for (int rectIndex = 0; rectIndex < m_rectsCount; rectIndex++)
	{
		int rectArea = m_rects[rectIndex].width * m_rects[rectIndex].length;

		if (maxRectArea < rectArea)
		{
			maxRectArea  = rectArea;
			maxRectIndex = rectIndex;
		}
	}

	if (maxRectIndex != -1)
	{
		m_fingerRects[0] = m_rects[maxRectIndex];

		const double maxWritersPalmLength = 110.0;

		if (m_fingerRects->length > maxWritersPalmLength)
		{
			const double scaleFactor = maxWritersPalmLength / 
			                           (double)(m_fingerRects->length);

			m_fingerRects[0].init((int)(m_fingerRects[0].x2 + 
			                            scaleFactor * (m_fingerRects[0].x1 - 
			                                           m_fingerRects[0].x2)),
			                      (int)(m_fingerRects[0].y2 + 
			                            scaleFactor * (m_fingerRects[0].y1 - 
			                                           m_fingerRects[0].y2)),
			                      m_fingerRects[0].x2,
			                      m_fingerRects[0].y2,
			                      m_fingerRects[0].width);
		}

		if (m_resHand == SGM_HAND_UNKNOWN)
		{
			m_resHand = (m_fingerRects[0].angle > 0) ? SGM_HAND_LEFT 
			                                         : SGM_HAND_RIGHT;
		}

		m_fingerRects[0].type = (m_resHand == SGM_HAND_LEFT) ? POS_CODE_L_WR_PALM
		                                                     : POS_CODE_R_WR_PALM;

		m_fingerRectsCount = 1;
	}
}

int CFpsWritersPalm::Recognition(SGM_FINGER *exclPos, unsigned int exclPosCount)
{
	FindRects();
	FindWritersPalm();

	return GRAPH_RES_SUCCESS;
}



////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  ����� CFpsFinger - ����������� ���������� ��������� (������� �������).    //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

CFpsFinger::CFpsFinger(): CFps()
{
	m_src = NULL;
}

CFpsFinger::~CFpsFinger()
{
	if (m_src != NULL)
	{
		delete [] m_src;
		m_src = NULL;
	}
}

int CFpsFinger::Preprocessing()
{
	m_srcScale += ResizeDecFastForDPI8(m_img, m_imgW, m_imgH, m_srcPPI, 500);

	const unsigned int wt   = (((m_imgW + 15) >> 4) + 2) << 4;
	const unsigned int ht   = (((m_imgH + 15) >> 4) + 2) << 4;
	const unsigned int wh   = wt * ht;
	const unsigned int w16  = wt >> 4;
	const unsigned int h16  = ht >> 4;
	const unsigned int wh16 = w16 * h16;

	unsigned char *buf = new unsigned char[2 * wh + 3 * wh16];

	if (buf == NULL)
	{
		return GRAPH_RES_ERR_MEM;
	}

	unsigned char *tmp = buf;          // wh
	unsigned char *roi = tmp + wh;     // wh
	unsigned char *dir = roi + wh;     // wh16
	unsigned char *qlt = dir + wh16;   // wh16
	unsigned char *frq = qlt + wh16;   // wh16

	unsigned int ww = w16;
	unsigned int hh = h16;

	memset(roi, 0, wh16);

	ArrAutoLevelsC8(m_img, m_imgW * m_imgH, 10000);
	SetSize8(m_img, m_imgW, m_imgH, wt, ht, tmp);
	GetDirections8(tmp, wt, ht, 4, roi, dir, qlt);
	DirsCorrection8(dir, w16, h16, roi);
	Border8(roi, w16, h16, 1);
	GetFrequencies8(tmp, wt, ht, 4, roi, dir, frq);
	FreqCorrection8(frq, w16, h16, roi);
	FillCavities8(roi, w16, h16, 1);

	memcpy(tmp, roi, wh16);

	DeleteLines8(roi, w16, h16, 0, 0, w16 - 1, h16 - 1, 0, 2, 7);
	ExpandLines8(roi, w16, h16, 0, 1, 2);

	if (!ArrValueExists8(roi, wh16, 0))
	{
		memcpy(roi, tmp, wh16);
	}

	ResizeIncFast8(roi, ww, hh, 4);
	SetSize8(roi, ww, hh, m_imgW, m_imgH, tmp);

	ww = m_imgW;
	hh = m_imgH;

	int deltaScale = ResizeDecFastForDPI8(m_img, m_imgW, m_imgH, 
	                                      m_srcPPI >> m_srcScale, 200);

	const unsigned int w = m_imgW;
	const unsigned int h = m_imgH;

	m_srcScale += deltaScale;

	ResizeDecFast8(tmp, ww, hh, deltaScale);

	int res = GetClone8(m_img, w, h, m_src);

	if (res != GRAPH_RES_SUCCESS)
	{
		return res;
	}

	memcpy(m_img, tmp, w * h); // !!!
/*
	Equalize8(m_img, w, h, 16);
	Blur8(m_img, w, h, 4);

	int delta = w * h - ((((300 * m_srcPPI) / 500) * ((450 * m_srcPPI) / 500)) >> (2 * m_srcScale));    // ������ ��������� 300 x 450 ��� 500 PPI

	delta = (100 * delta) / (int)(w * h);

	if (delta > 0)
	{
		ArrAutoLevels8(m_img, w * h, 0, delta);
	}

	BinarizationC8(m_img, w, h, 230);

	FillSpaces8(tmp, m_img, w, h);
//	DeleteLines8(m_img, w, h, 0, 0, w - 1, h - 1, 0, 1, 12);
	FillCavities8(m_img, w, h, 16);

	for (unsigned char *p1 = tmp, *p2 = m_img, *lp = tmp + w * h; p1 < lp; p1++, p2++)
	{
		if (*p1)
		{
			*p2 = 1;
		}
	}

	memcpy(tmp, m_img, w * h);

	DeleteLines8(m_img, w, h, 0, 0, w - 1, h - 1, 0, 2, 15);
	ExpandLines8(m_img, w, h, 0, 1, 4);
	DeleteLines8(m_img, w, h, 0, 0, w - 1, h - 1, 0, 1, 8);

	if (!ArrValueExists8(m_img, w * h, 0))
	{
		memcpy(m_img, tmp, w * h);
	}
*/
	delete [] buf;

	return GRAPH_RES_SUCCESS;
}

void CFpsFinger::FindRects()
{
	unsigned char *pi, *lp;
	unsigned char col = 10;


	m_rectsCount = 0;

	Border8(m_img, m_imgW, m_imgH, 1);

	for (pi = m_img, lp = m_img + m_imgW * m_imgH; pi < lp; pi++)
	{
		if (*pi == 0)
		{
			if (m_rectsCount >= SGM_MAX_RECTS_COUNT)
			{
				break;
			}

//			Fill8(m_img, m_imgW, m_imgH, 0, 0, m_imgW - 1, m_imgH - 1, col, 254, pi);
			Fill8(m_img, m_imgW, m_imgH, pi, col);

			if (m_rects[m_rectsCount].initV(m_img, m_imgW, m_imgH, pi, col) == 0)
			{
				m_rectsCount++;
			}

			col++;

			if (col >= 254)
			{
				ChangeColors8(m_img, m_imgW, m_imgH, 10, 252, 255);
				col = 10;
			}
		}
	}
}

void CFpsFinger::FindRect()
{
	if (m_rectsCount == 0)  return;

	int i, index;
	int t, tMax;

	const int xc = m_imgW >> 1;
	const int yc = m_imgH >> 1;


	index = 0;
	tMax  = (m_rects[0].width << 1) * m_rects[0].length;

	for (i = 1; i < m_rectsCount; i++)
	{
		t = (m_rects[i].width << 1) * m_rects[i].length;

		if (t > tMax)
		{
			tMax  = t;
			index = i;
		}
	}

	int x1, y1;
	int x2, y2;
	int xt1, xt2, dx;

	int xMin = 0;
	int xMax = 0;
	int yMax = 0;


	x1 = m_rects[index].xc - m_rects[index].width;
	x2 = m_rects[index].xc + m_rects[index].width;
	y1 = m_rects[index].y1;
	y2 = m_rects[index].y2;

	while ((x1 != xMin) || (x2 != xMax) || (y2 != yMax))
	{
		xMin = x1;
		xMax = x2;
		yMax = y2;

		for (int i = 0; i < m_rectsCount; i++)
		{
			if (i != index)
			{
				if (m_rects[i].y1 > y1)
				{
					xt1 = m_rects[i].xc - m_rects[i].width;
					xt2 = m_rects[i].xc + m_rects[i].width;

					if ((xt1 <= x1) && (xt2 >= x2))  dx = x2  - x1;  else
					if ((xt1 >= x1) && (xt2 <= x2))  dx = xt2 - xt1; else
					if ((xt1 <= x1) && (xt2 >= x1))  dx = xt2 - x1;  else
					if ((xt1 <= x2) && (xt2 >= x2))  dx = x2  - xt1; else  dx = 0;

					if (2 * dx >= (xt2 - xt1))
					{
						if (abs(m_rects[i].y1 - yMax) > abs(m_rects[i].y2 - yMax))
						{
							if (xt1 < xMin) xMin = xt1;
							if (xt2 > xMax) xMax = xt2;

							if (m_rects[i].y2 > yMax)
							{
								yMax = m_rects[i].y2;
							}

						} else

						if (m_rects[i].y1 > yMax)
						{
							yMax = m_rects[i].y1;
						}
					}
				}
			}
		}

		if ((x1 != xMin) || (x2 != xMax) || (y2 != yMax))
		{
			dx = (xMax + xMin + 1) >> 1;

			m_rects[index].init(dx, y1, dx, yMax, (xMax - xMin + 1) >> 1);

			x1 = m_rects[index].xc - m_rects[index].width;
			x2 = m_rects[index].xc + m_rects[index].width;
			y2 = m_rects[index].y2;
		}
	}

	x1 = m_rects[index].xc;

	m_rects[0].init(x1, y1, x1, m_rects[index].y2, m_rects[index].width);
}

void CFpsFinger::CorrectRect()
{
	if (m_rectsCount == 0)  return;

	int l  =  m_rects[0].length;
	int w  =  m_rects[0].width;
	int xc =  m_rects[0].xc;
	int yn = -1;


	if (l > (w << 1))
	{
		int x1 = xc - w;
		int x2 = xc + w;
		int y1 = m_rects[0].y1;
		int y2 = m_rects[0].y2;

		if (x1 < 0) x1 = 0;
		if (y1 < 0) y1 = 0;

		if (x2 >= (int)m_imgW)  x2 = m_imgW - 1;
		if (y2 >= (int)m_imgH)  y2 = m_imgH - 1;

		int yMin = y1 + 100;
		int yMax = y2;

		if ((x1 < x2) && (yMin <= yMax))
		{
			unsigned char *bin = new unsigned char[m_imgW * m_imgH];

			if (bin != NULL)
			{
				BinarizationToL8(m_src, m_imgW, m_imgH, 
				                 0, 0, m_imgW - 1, m_imgH - 1, 4, bin);

				int f1, f2, f3, f4;
				int x1l, y1l;
				int x2l, y2l;
				int x3l, y3l;
				int dy   = (x2 - x1) >> 2;
				int nMax = (x2 - x1) >> 4;
				int y2t, y2b;

				for (y1 = yMin; (y1 <= yMax) && (yn == -1); y1++)
				{
					y2t = y1 - dy;
					y2b = y1 + dy;

					if (y2t < yMin)  y2t = yMin;
					if (y2b > yMax)  y2b = yMax;

					for (y2 = y2t; y2 <= y2b; y2++)
					{
						x1l = (3 * x1 + x2) >> 2;
						y1l = (3 * y1 + y2) >> 2;
						x2l = (x1 + x2) >> 1;
						y2l = (y1 + y2) >> 1;
						x3l = (x1 + 3 * x2) >> 2;
						y3l = (y1 + 3 * y2) >> 2;

						f1 = IsLine8(bin, m_imgW, m_imgH, 
						             x1,  y1,  x1l, y1l, 0) < nMax;
						f2 = IsLine8(bin, m_imgW, m_imgH, 
						             x1l, y1l, x2l, y2l, 0) < nMax;
						f3 = IsLine8(bin, m_imgW, m_imgH, 
						             x2l, y2l, x3l, y3l, 0) < nMax;
						f4 = IsLine8(bin, m_imgW, m_imgH, 
						             x3l, y3l, x2,  y2,  0) < nMax;

						if ((f1 + f2 + f3 + f4) >= 3)
						{
							yn = (y1 > y2) ? y1 : y2;
							break;
						}
					}
				}

				delete [] bin;
			}
		}
	}

	if ((yn != -1) && ((m_rects[0].y2 - yn) > 20))
	{
		m_rects[1].init(xc, m_rects[0].y1, xc, yn, w);
	}
	else
	{
		m_rects[1].init(xc, m_rects[0].y1, xc, m_rects[0].y2, w);
	}

	const int addSize = 3;

	for (int i = 0; i < 2; i++)
	{
		m_rects[i].init(m_rects[i].x1, m_rects[i].y1 - addSize,
		                m_rects[i].x2, m_rects[i].y2 + addSize,
		                m_rects[i].width + addSize);
	}
}

int CFpsFinger::Recognition(SGM_FINGER *exclPos, unsigned int exclPosCount)
{
	FindRects();
	FindRect();
	CorrectRect();

	return GRAPH_RES_SUCCESS;
}

SGM_RESULT CFpsFinger::RectsOut(SgmRect *rects, 
                                unsigned int &rectsCount, 
                                unsigned int alignment)
{
	if ((m_rectsCount > 0) && (rectsCount > 0))
	{
		m_fingerRectsCount = 2;//1;

		m_fingerRects[0] = m_rects[0];
		m_fingerRects[0].type = POS_CODE_U_FINGER;

		m_fingerRects[1] = m_rects[1];
		m_fingerRects[1].type = POS_CODE_U_FINGER;
	}

	return CFps::RectsOut(rects, rectsCount, alignment);
}



////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  ����� CFpsLatent - ����������� ���������� ��������� ������ �������        //
//                     �������� (����� �� ������������ �����).                //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

int CFpsLatent::Preprocessing()
{
	m_srcRotation = false;

	m_srcScale += ResizeDecFastForDPI8(m_img, m_imgW, m_imgH, m_srcPPI, 400);
	m_srcScale += 3;

	return GRAPH_RES_SUCCESS;
}

//----------------------------------------------------------------------------//
// ���������� : �������� �������������� �� ����������.                        //
// ���������  : rect - ����������� �������������.                             //
// ���������  : 1 - ���������� ���������;                                     //
//              0 - ������������ ���������.                                   //
//----------------------------------------------------------------------------//
int CFpsLatent::CheckRect(CSpot *rect)
{
	int rw = rect->width << 1;
	int rh = rect->length;
	int rs = rect->size;

	if ((rw >= 5) && (5 * rw > rh) && 
	    (rh >= 5) && (5 * rh > rw) && 
	    (rs >= 4) && (rs > 0.03 * rw * rh))
	{
		return 1;
	}

	return 0;
}

//----------------------------------------------------------------------------//
// ���������� : ����������� ������ ��������������� � ����������� ������.      //
//----------------------------------------------------------------------------//
int CFpsLatent::FindRects()
{
	m_rectsCount = 0;

	unsigned char *msk = NULL;
	unsigned char *sum = NULL;

	int res = GRAPH_RES_SUCCESS;

	const unsigned int imgW0 = m_imgW;
	const unsigned int imgH0 = m_imgH;


	for (int i = 0; i < 2; i++)
	{
		m_imgW = imgW0;
		m_imgH = imgH0;

		if (i == 1)
		{
			ArrSetMinMax8(m_img, m_imgW * m_imgH, 90, 255);
		}

		res = GetPatternMask8(m_img, m_imgW, m_imgH, msk);

		if (res != GRAPH_RES_SUCCESS)
		{
			goto freeall;
		}

		if (sum == NULL)
		{
			sum = new unsigned char[m_imgW * m_imgH];

			if (sum == NULL)
			{
				res = GRAPH_RES_ERR_MEM;
				goto freeall;
			}

			memcpy(sum, msk, m_imgW * m_imgH);
		}
		else
		{
			Binary_AND8(sum, msk, m_imgW, m_imgH);
		}

		if (msk != NULL)
		{
			delete [] msk;
			msk = NULL;
		}
	}

	if (sum != NULL)
	{
		int err;
		int col = 2;
		int x1, y1, x2, y2, wr;

		Border8(sum, m_imgW, m_imgH, 1);

		for (unsigned char *pm = sum, *lp = sum + m_imgW * m_imgH; pm < lp; pm++)
		{
			if (*pm == 0)
			{
				if (m_rectsCount >= SGM_MAX_RECTS_COUNT)
				{
					break;
				}

//				Fill8(sum, m_imgW, m_imgH, 0, 0, m_imgW - 1, m_imgH - 1, col, 254, pm);
				Fill8(sum, m_imgW, m_imgH, pm, col);

				err = m_rects[m_rectsCount].initV(sum, m_imgW, m_imgH, pm, col);

				if ((!err) && (CheckRect(&m_rects[m_rectsCount])))
				{
					x1 = m_rects[m_rectsCount].x1;
					y1 = m_rects[m_rectsCount].y1;
					x2 = m_rects[m_rectsCount].x2;
					y2 = m_rects[m_rectsCount].y2;
					wr = m_rects[m_rectsCount].width;

					m_rects[m_rectsCount].init(x1, y1 - 1, x2, y2 + 1, wr + 1);
					m_rectsCount++;
				}

				col++;

				if (col >= 254)
				{
					ChangeColors8(sum, m_imgW, m_imgH, 10, 253, 255);
					col = 10;
				}
			}
		}
	}

freeall:

	if (msk != NULL)  delete [] msk;
	if (sum != NULL)  delete [] sum;

	return res;
}

int CFpsLatent::Recognition(SGM_FINGER *exclPos, unsigned int exclPosCount)
{
	int res = FindRects();

	if (res != GRAPH_RES_SUCCESS)
	{
		return res;
	}

	if (m_rectsCount == 0)
	{
		return GRAPH_RES_SUCCESS;
	}

	int i, index;
	int t, tMin;

	const int xc = m_imgW >> 1;
	const int yc = m_imgH >> 1;

	index = 0;
	tMin  = 14 * ((int)(abs(xc - m_rects[0].xc) + abs(yc - m_rects[0].yc))) - 
	        (((m_rects[0].width << 1) + m_rects[0].length));

	for (i = 1; i < m_rectsCount; i++)
	{
		t = 14 * ((int)(abs(xc - m_rects[i].xc) + abs(yc - m_rects[i].yc))) - 
		    (((m_rects[i].width << 1) + m_rects[i].length));

		if (t < tMin)
		{
			tMin  = t;
			index = i;
		}
	}

	if (index != 0)
	{
		CSpot bestRect = m_rects[index];

		m_rects[index] = m_rects[0];
		m_rects[0]     = bestRect;
	}

	return GRAPH_RES_SUCCESS;
}

SGM_RESULT CFpsLatent::RectsOut(SgmRect *rects, 
                                unsigned int &rectsCount, 
                                unsigned int alignment)
{
	m_fingerRectsCount = m_rectsCount;

	for (int i = 0; i < m_rectsCount; i++)
	{
		m_fingerRects[i] = m_rects[i];
		m_fingerRects[i].type = POS_CODE_U_FINGER;
	}

	return CFps::RectsOut(rects, rectsCount, alignment);
}



////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  ����� CFpsFullPalm - ����������� ��������� 1-� ������ ������.             //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

int CFpsFullPalm::Preprocessing()
{
	return GRAPH_RES_SUCCESS;
}

int CFpsFullPalm::Recognition(SGM_FINGER *exclPos, unsigned int exclPosCount)
{
	m_hand.find(m_img, m_imgW, m_imgH, 0);

	return GRAPH_RES_SUCCESS;
}

SGM_RESULT CFpsFullPalm::RectsOut(SgmRect *rects, 
                                  unsigned int &rectsCount, 
                                  unsigned int alignment)
{
	m_fingerRectsCount = 0;

	CRect4 lowerPalmRect = m_hand.rect();

	m_fingerRects[m_fingerRectsCount].init((int)(lowerPalmRect.x1()),
	                                       (int)(lowerPalmRect.y1()),
	                                       (int)(lowerPalmRect.x2()),
	                                       (int)(lowerPalmRect.y2()),
	                                       (int)(lowerPalmRect.width()));
	if (m_hand.isRightHand())
	{
		m_fingerRects[m_fingerRectsCount].type = POS_CODE_R_LOWER_PALM;
		m_resHand = SGM_HAND_RIGHT;
	}
	else
	{
		m_fingerRects[m_fingerRectsCount].type = POS_CODE_L_LOWER_PALM;
		m_resHand = SGM_HAND_LEFT;
	}

	m_fingerRectsCount++;

	for (int fingerIndex = 0, fingersCount = m_hand.fingersCount();
	     fingerIndex < fingersCount; fingerIndex++)
	{
		CFinger *finger = m_hand.finger(fingerIndex);

		for (int phalanxIndex = 0, phalanxesCount = finger->phalanxesCount();
		     phalanxIndex < phalanxesCount; phalanxIndex++)
		{
			CPhalanx *phalanx = finger->phalanx(phalanxIndex);
			CRect4 phalanxRect = phalanx->rect();

			m_fingerRects[m_fingerRectsCount].init((int)(phalanxRect.x1()),
			                                       (int)(phalanxRect.y1()),
			                                       (int)(phalanxRect.x2()),
			                                       (int)(phalanxRect.y2()),
			                                       (int)(phalanxRect.width()));

			m_fingerRects[m_fingerRectsCount].type    = finger->index();
			m_fingerRects[m_fingerRectsCount].segment = 
				(SGM_SEGMENT)(phalanx->index() + 1);

			m_fingerRectsCount++;
		}
	}

	return CFps::RectsOut(rects, rectsCount, alignment);
}
