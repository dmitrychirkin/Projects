#ifndef _GRAPH8_FRQ_H_
#define _GRAPH8_FRQ_H_



int  GetFrequencies8  (unsigned char *img, unsigned int w, unsigned int h, int n, unsigned char *roi, unsigned char *dir, unsigned char *frq);
int  GetFrequenciesL8 (unsigned char *img, unsigned int w, unsigned int h, unsigned int x1, unsigned int y1, unsigned int x2, unsigned int y2, int n, unsigned char *dir, unsigned char *frq);
int  FreqCorrection8  (unsigned char *frq, unsigned int w, unsigned int h, unsigned char *roi);

#endif