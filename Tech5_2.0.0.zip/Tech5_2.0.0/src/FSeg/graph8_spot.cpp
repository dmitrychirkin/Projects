////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  ����� "�����"                                                             //
//                                                                            //
//  �����: �. ���������                                                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#include <math.h>
#include <memory.h>
#include "graph8_const.h"
#include "graph8_spot.h"


const double piDiv2 = (double)(0.50 * PI);
const double gr10   = (double)(PI / 18.0);
const double gr50   = (double)(50 * PI / 180.0);

int roundDouble(double x)
{
	return (x >= 0) ? (int)(x + 0.5) : (int)(x - 0.5);
}



////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  ����� CSpot - �����                                                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

//----------------------------------------------------------------------------//
// ���������� : �����������.                                                  //
//----------------------------------------------------------------------------//
CSpot::CSpot()
{
	x1 = 0;
	y1 = 0;
	x2 = 0;
	y2 = 0;
	xc = 0;
	yc = 0;
	dx = 0;
	dy = 0;

	a = 1.0;
	b = 0.0;
	c = 0.0;

	angle   = 0.0;
	length  = 0;
	width   = 0;
	size    = 0;
	type    = 0;
	segment = SGM_SEGMENT_UNKNOWN;
	err     = 0;

	memset(m_points, 0, sizeof(m_points));
	m_pointsCount = 0;
}

//----------------------------------------------------------------------------//
// ���������� : �����������.                                                  //
//----------------------------------------------------------------------------//
CSpot::CSpot(int xl1, int yl1, int xl2, int yl2, int wl)
{
	init(xl1, yl1, xl2, yl2, wl);

	type    = 0;
	segment = SGM_SEGMENT_UNKNOWN;
	err     = 0;

	memset(m_points, 0, sizeof(m_points));
	m_pointsCount = 0;
}

//----------------------------------------------------------------------------//
// ���������� : ����������� �����������.                                      //
// ���������  : spot - ���������� ������.                                     //
//----------------------------------------------------------------------------//
CSpot::CSpot(const CSpot &spot)
{
	x1 = spot.x1;
	y1 = spot.y1;
	x2 = spot.x2;
	y2 = spot.y2;
	xc = spot.xc;
	yc = spot.yc;
	dx = spot.dx;
	dy = spot.dy;

	a = spot.a;
	b = spot.b;
	c = spot.c;

	angle   = spot.angle;
	length  = spot.length;
	width   = spot.width;
	size    = spot.size;
	type    = spot.type;
	segment = spot.segment;
	err     = spot.err;

	memcpy(m_points, spot.m_points, sizeof(spot.m_points));
	m_pointsCount = spot.m_pointsCount;
}

//----------------------------------------------------------------------------//
// ���������� : ����������.                                                   //
//----------------------------------------------------------------------------//
CSpot::~CSpot()
{
}

//----------------------------------------------------------------------------//
// ���������� : �������� ������������.                                        //
// ���������  : spot - ������������� ������.                                  //
//----------------------------------------------------------------------------//
CSpot& CSpot::operator = (const CSpot &spot)
{
	if (this == &spot)
	{
		return *this;
	}

	x1 = spot.x1;
	y1 = spot.y1;
	x2 = spot.x2;
	y2 = spot.y2;
	xc = spot.xc;
	yc = spot.yc;
	dx = spot.dx;
	dy = spot.dy;

	a = spot.a;
	b = spot.b;
	c = spot.c;

	angle   = spot.angle;
	length  = spot.length;
	width   = spot.width;
	size    = spot.size;
	type    = spot.type;
	segment = spot.segment;
	err     = spot.err;

	memcpy(m_points, spot.m_points, sizeof(spot.m_points));
	m_pointsCount = spot.m_pointsCount;

	return *this;
}

//----------------------------------------------------------------------------//
// ���������� : ������������� ����������.                                     //
// ���������  : xl1, yl1 - ���������� ��������� ����� ������� �������;        //
//              xl2, yl2 - ���������� ��������  ����� ������� �������;        //
//              wl       - ������.                                            //
//----------------------------------------------------------------------------//
void CSpot::init(int xl1, int yl1, int xl2, int yl2, int wl)
{
	if (yl2 > yl1)
	{
		x1 = xl1;
		y1 = yl1;
		x2 = xl2;
		y2 = yl2;
	}
	else
	{
		x1 = xl2;
		y1 = yl2;
		x2 = xl1;
		y2 = yl1;
	}

	xc = (x1 + x2 + 1) >> 1;
	yc = (y1 + y2 + 1) >> 1;
	dx = x2 - x1;
	dy = y2 - y1;

	length = (unsigned int)(sqrt((double)((dy + 1) * (dy + 1) + 
	                                      (dx + 1) * (dx + 1))) + 0.5);
	width  = wl;
	size   = length * (wl << 1);

	double k = sqrt((double)(dy * dy + dx * dx));

	if (k > 0)
	{
		a = (double)-dy;
		b = (double) dx;
		c = (double)(x1 * y2 - x2 * y1);

		k = -1 / k;

		a *= k;
		b *= k;
		c *= k;
	}
	else
	{
		a = 0;
		b = 0;
		c = 0;
	}

	angle = acos(b) - piDiv2;
}

int CSpot::initV(unsigned char *img,
                 unsigned int w,
                 unsigned int h,
                 unsigned char *p0,
                 unsigned char col)
{
	unsigned char *px, *py;
	unsigned char *lx, *ly;

	int x;

	int xm1 = w;
	int xm2 = 0;

	int y = (int)(p0 - img);


	size = 0;
	m_pointsCount = 0;

	for (py = p0 - y % w, ly = img + w * h, y /= w; py < ly; py += w, y++)
	{
		for (px = py, lx = py + w; (px < lx) && (*px != col); px++);

		if (px < lx)
		{
			if (m_pointsCount >= MAX_SPOT_POINTS_COUNT)
			{
				break;
			}

			x = (int)(px - py);

			if (x < xm1)  xm1 = x;
			if (x > xm2)  xm2 = x;

			size += (w - x);

			m_points[m_pointsCount].x = x;
			m_points[m_pointsCount].y = y;
			m_pointsCount++;

			if (m_pointsCount >= MAX_SPOT_POINTS_COUNT)
			{
				break;
			}

			for (px = lx - 1; (px >= py) && (*px != col); px--);

			x = (int)(px - py);

			if (x < xm1)  xm1 = x;
			if (x > xm2)  xm2 = x;

			size -= (w - x - 1);

			m_points[m_pointsCount].x = x;
			m_points[m_pointsCount].y = y;
			m_pointsCount++;
		}
		else
		{
			break;
		}
	}

	if (m_pointsCount == 0)  return 1;

	y1 = (int)(p0 - img) / w;
	y2 = (int)(py - img) / w;
	dy =  y2 - y1;
	yc = (y1 + y2 + 1) >> 1;

	length  = dy + 1;
	width   = (xm2 - xm1 + 2) >> 1;
	angle   = 0;
	type    = 0;
	segment = SGM_SEGMENT_UNKNOWN;

	err = 0;

	xc = (xm1 + xm2 + 1) >> 1;
	x1 = xc;
	x2 = xc;
	dx = 0;

	a = (double)-dy;
	b = (double)0;
	c = (double)(xc * dy);

	double k = -1 / (double)dy;

	a *= k;
	c *= k;

	return 0;
}

int CSpot::initR(unsigned char *img,
                 unsigned int w,
                 unsigned int h,
                 unsigned char *p0,
                 unsigned char col)
{
	unsigned char *px, *py;
	unsigned char *lx, *ly;
	unsigned int   wl;

	int x;
	int xi1, xi2;

	int sx  = 0;
	int sy  = 0;
	int sxy = 0;
	int syy = 0;

	int y = (int)(p0 - img);


	size  = 0;
	width = 0;

	m_pointsCount = 0;

	for (py = p0 - y % w, ly = img + w * h, y /= w; py < ly; py += w, y++)
	{
		for (px = py, lx = py + w; (px < lx) && (*px != col); px++);

		if (px < lx)
		{
			if (m_pointsCount >= MAX_SPOT_POINTS_COUNT)
			{
				break;
			}

			xi1 = (int)(px - py);

			size += (w - xi1);

			m_points[m_pointsCount].x = xi1;
			m_points[m_pointsCount].y = y;
			m_pointsCount++;

			if (m_pointsCount >= MAX_SPOT_POINTS_COUNT)
			{
				break;
			}

			for (px = lx - 1; (px >= py) && (*px != col); px--);

			xi2 = (int)(px - py);

			size -= (w - xi2 - 1);

			m_points[m_pointsCount].x = xi2;
			m_points[m_pointsCount].y = y;
			m_pointsCount++;

			x = (xi1 + xi2 + 1) >> 1;

			sx += x;
			sy += y;

			sxy += x * y;
			syy += y * y;

			wl = xi2 - xi1 + 1;

			if (width < wl)
			{
				width = wl;
			}
		}
		else
		{
			break;
		}
	}

	if (m_pointsCount == 0)  return 1;


	// �������� �������������

	y1 = (int)(p0 - img) / w;
	y2 = (int)(py - img) / w;
	dy =  y2 - y1;
	yc = (y1 + y2 + 1) >> 1;

	double ut = 0.5 * atan2((double)(sy << 1), (double)syy - dy);
	double cs = cos(ut);
	double sn = sin(ut);
	double cc = cs * cs;
	double ss = sn * sn;
	double dd = 2  * cs * sn * sy;
	double d1 = cc * dy + ss * syy - dd;
	double d2 = ss * dy + cc * syy + dd;
	double t1 = cs * sx - sn * sxy;
	double t2 = sn * sx + cs * sxy;

	t1 = (d1 != 0) ? (t1 / d1) : 0;
	t2 = (d2 != 0) ? (t2 / d2) : 0;

	a  =  cs * t1 + sn * t2;
	b  = -sn * t1 + cs * t2;

	x1 = roundDouble(y1 * b + a);
	x2 = roundDouble(y2 * b + a);
	dx =  x2 - x1;
	xc = (x1 + x2 + 1) >> 1;

	length = (unsigned int)(sqrt((double)((dy + 1) * (dy + 1) + 
	                                      (dx + 1) * (dx + 1))) + 0.5);
	width  = (width + 1) >> 1;

	a = (double)-dy;
	b = (double) dx;
	c = (double)(x1 * y2 - x2 * y1);

	double k = -1 / sqrt((double)(dy * dy + dx * dx));

	a *= k;
	b *= k;
	c *= k;

	angle   = acos(b) - piDiv2;
	type    = 0;
	segment = SGM_SEGMENT_UNKNOWN;

	err = 0;

	return 0;
}

void CSpot::setAngleAndLength(double ut, int l, int n)
{
	y2 = y1 + roundDouble(l * a);

	init(x1, y1, getX(y2), y2, width);


	double cs = cos(ut);
	double sn = sin(ut);


	int dyt = roundDouble(0.2 * l * a);

	int y1t = y2 - dyt;
	int y2t = y2 + dyt;

	y1t = roundDouble((getX(y1t) - xc) * sn + (y1t - yc) * cs);
	y2t = roundDouble((getX(y2t) - xc) * sn + (y2t - yc) * cs);

	int x1t, x2t, dxt;
	int x0, y0;
	int dytMin1;
	int dytMin2;

	int dxtMin = width << 2;

	DPOINT *pt;
	DPOINT *lp = m_points + m_pointsCount;


	for (int yt = y1t; yt <= y2t; yt++)
	{
		x1t = 0;
		x2t = 0;

		dytMin1 = l;
		dytMin2 = l;

		pt = m_points;

		while (pt < lp)
		{
			x0  = pt->x - xc;
			y0  = pt->y - yc;
			dyt = abs(roundDouble(x0 * sn + y0 * cs) - yt);

			if (dyt < dytMin1)
			{
				dytMin1 = dyt;

				x1t = roundDouble(x0 * cs - y0 * sn);
			}

			pt++;

			if (pt < lp)
			{
				x0  = pt->x - xc;
				y0  = pt->y - yc;
				dyt = abs(roundDouble(x0 * sn + y0 * cs) - yt);

				if (dyt < dytMin2)
				{
					dytMin2 = dyt;

					x2t = roundDouble(x0 * cs - y0 * sn);
				}

				pt++;
			}

			if ((dytMin1 < 2) && (dytMin2 < 2)) break;
		}

		if ((dytMin1 < 2) || (dytMin2 < 2))
		{
			dxt = abs(x2t - x1t);

			if (dxt < dxtMin)
			{
				dxtMin = dxt;

				y2 = yt;
			}
		}
	}

	setAngle(ut, y2);
}

void CSpot::setAngle(double ut, int ym)
{
	int xy;

	double cs = cos(ut);
	double sn = sin(ut);

	DPOINT *pt = m_points;
	DPOINT *lp = m_points + m_pointsCount;

	x1 = 0;
	y1 = 0;
	x2 = 0;
	y2 = 0;

	if (ym == 0)
	{
		while (pt < lp)
		{
			dx = pt->x - xc;
			dy = pt->y - yc;

			xy = roundDouble(dx * cs - dy * sn);

			if (xy < x1)  x1 = xy;  else
			if (xy > x2)  x2 = xy;

			xy = roundDouble(dx * sn + dy * cs);

			if (xy < y1)  y1 = xy;  else
			if (xy > y2)  y2 = xy;

			pt++;
		}
	}
	else
	{
		while (pt < lp)
		{
			dx = pt->x - xc;
			dy = pt->y - yc;

			xy = roundDouble(dx * sn + dy * cs);

			if (xy <= ym)
			{
				if (xy < y1)  y1 = xy;  else
				if (xy > y2)  y2 = xy;

				xy = roundDouble(dx * cs - dy * sn);

				if (xy < x1)  x1 = xy;  else
				if (xy > x2)  x2 = xy;
			}

			pt++;
		}
	}

	if ((x1 >= x2) || (y1 >= y2))  return;


	cs = cos(-ut);
	sn = sin(-ut);

	int x1n = xc + roundDouble(x1 * cs - y1 * sn);
	int y1n = yc + roundDouble(x1 * sn + y1 * cs);
	int x2n = xc + roundDouble(x2 * cs - y1 * sn);
	int y2n = yc + roundDouble(x2 * sn + y1 * cs);
	int x3n = xc + roundDouble(x1 * cs - y2 * sn);
	int y3n = yc + roundDouble(x1 * sn + y2 * cs);
	int x4n = xc + roundDouble(x2 * cs - y2 * sn);
	int y4n = yc + roundDouble(x2 * sn + y2 * cs);


	// �������������

	x1 = (x1n + x2n + 1) >> 1;
	y1 = (y1n + y2n + 1) >> 1;
	x2 = (x3n + x4n + 1) >> 1;
	y2 = (y3n + y4n + 1) >> 1;
	dx = abs(x1n - x2n);
	dy = abs(y1n - y2n);

	width = (unsigned int)(0.5 * sqrt((double)((dx + 1) * (dx + 1) + 
	                                           (dy + 1) * (dy + 1))) + 0.5);

	xc = (x1 + x2 + 1) >> 1;
	yc = (y1 + y2 + 1) >> 1;
	dx =  x2 - x1;
	dy =  y2 - y1;

	length = (unsigned int)(sqrt((double)((dx + 1) * (dx + 1) + 
	                                      (dy + 1) * (dy + 1))) + 0.5);

	a = (double)-dy;
	b = (double) dx;
	c = (double)(x1 * y2 - x2 * y1);

	double k = sqrt((double)(dx * dx + dy * dy));

	if (k > 0)
	{
		k = -1 / k;

		a *= k;
		b *= k;
		c *= k;
	}

	angle = ut;
}

void CSpot::setAngleAuto(bool fullAuto)
{
	int i;

	double ut = angle;
	double um = angle;
	double u1 = (ut < -gr50) ?  ut   : -gr50;
	double u2 = (ut >  gr50) ?  ut   :  gr50;
	double du = (ut <  0)    ? -gr10 :  gr10;

	int sm = (length * length) << 2;

	double cs, sn;
	int    x0, y0, xn, yn, st;

	if (fullAuto)
	{
		u1 = -val_pi_div_180 * 30 - angle;
		u2 =  val_pi_div_180 * 30 - angle;
		ut =  u1;
		du =  val_pi_div_180;
	}

	while ((ut >= u1) && (ut <= u2))
	{
		x1 = 0;
		y1 = 0;
		x2 = 0;
		y2 = 0;

		cs = cos(ut);
		sn = sin(ut);

		for (i = 0; i < m_pointsCount; i++)
		{
			x0 = m_points[i].x - xc;
			y0 = m_points[i].y - yc;

			xn = roundDouble(x0 * cs - y0 * sn);
			yn = roundDouble(x0 * sn + y0 * cs);

			if (xn < x1)  x1 = xn;
			if (xn > x2)  x2 = xn;
			if (yn < y1)  y1 = yn;
			if (yn > y2)  y2 = yn;
		}

		st = (x2 - x1) * (y2 - y1);

		if (sm > st)
		{
			sm = st;
			um = ut;
		}

		ut += du;
	}

	setAngle(um, 0);
}

/*
void CSpot::draw(HDC dc)
{
	const double wa = a * width;
	const double wb = b * width;


	MoveToEx(dc, roundDouble(x1 + wa), roundDouble(y1 + wb), NULL);

	LineTo(dc, roundDouble(x1 - wa), roundDouble(y1 - wb));
	LineTo(dc, roundDouble(x2 - wa), roundDouble(y2 - wb));
	LineTo(dc, roundDouble(x2 + wa), roundDouble(y2 + wb));
	LineTo(dc, roundDouble(x1 + wa), roundDouble(y1 + wb));
}

void CSpot::drawDebug(HDC dc)
{
	const double wa = a * width;
	const double wb = b * width;


	MoveToEx(dc, roundDouble(x1 + wa), roundDouble(y1 + wb), NULL);

	LineTo(dc, roundDouble(x1 - wa), roundDouble(y1 - wb));
	LineTo(dc, roundDouble(x2 - wa), roundDouble(y2 - wb));
	LineTo(dc, roundDouble(x2 + wa), roundDouble(y2 + wb));
	LineTo(dc, roundDouble(x1 + wa), roundDouble(y1 + wb));


	if (m_pointsCount > 0)
	{
		int i;

		MoveToEx(dc, m_points[0].x, m_points[0].y, NULL);

		for (i = 2; i < m_pointsCount; i += 2)
		{
			LineTo(dc, m_points[i].x, m_points[i].y);
		}

		i = (i == m_pointsCount) ? (i - 1) : (i - 3);

		for (; i > 0; i -= 2)
		{
			LineTo(dc, m_points[i].x, m_points[i].y);
		}

		LineTo(dc, m_points[0].x, m_points[0].y);
	}
}
*/

void CSpot::saveR(FILE *f, unsigned int pow2ScalingFactor, 
                  unsigned int alignment)
{
	SgmRect rect;

	getRectR(&rect, pow2ScalingFactor, alignment);

	fprintf(f, "%d,%d,%d,%d,%d,%d,%d,%d\n",
	           rect.coords[0][0], rect.coords[0][1],
	           rect.coords[1][0], rect.coords[1][1],
	           rect.coords[2][0], rect.coords[2][1],
	           rect.coords[3][0], rect.coords[3][1]);
}

void CSpot::saveV(FILE *f, unsigned int pow2ScalingFactor, 
                  unsigned int alignment)
{
	SgmRect rect;

	getRectV(&rect, pow2ScalingFactor, alignment);

	fprintf(f, "%d,%d,%d,%d\n",
	           rect.coords[0][0], rect.coords[0][1],
	           rect.coords[3][0], rect.coords[3][1]);
}

void CSpot::getRectR(SgmRect *rect, unsigned int pow2ScalingFactor, 
                     unsigned int alignment)
{
	const double wa = width * a;
	const double wb = width * b;

	const int scalingFactor = 1 << pow2ScalingFactor;

	double x1t = scalingFactor * (x1 - wa);
	double y1t = scalingFactor * (y1 - wb);
	double x2t = scalingFactor * (x1 + wa);
	double y2t = scalingFactor * (y1 + wb);
	double x3t = scalingFactor * (x2 - wa);
	double y3t = scalingFactor * (y2 - wb);
	double x4t = scalingFactor * (x2 + wa);
	double y4t = scalingFactor * (y2 + wb);

	if (alignment > 1)
	{
		const int deltaX12 = roundDouble(x2t) - roundDouble(x1t);
		const int deltaY12 = roundDouble(y2t) - roundDouble(y1t);
		const int deltaX13 = roundDouble(x3t) - roundDouble(x1t);
		const int deltaY13 = roundDouble(y3t) - roundDouble(y1t);

		const int scaledWidth  = 
			(unsigned int)(sqrt((double)((deltaX12 + 1) * (deltaX12 + 1) + 
			                             (deltaY12 + 1) * (deltaY12 + 1))) + 0.5);
		const int scaledHeight = 
			(unsigned int)(sqrt((double)((deltaX13 + 1) * (deltaX13 + 1) + 
			                             (deltaY13 + 1) * (deltaY13 + 1))) + 0.5);

		int alignmentX = scaledWidth % alignment;

		if (alignmentX > 0)
		{
			double alignmentXd2 = 0.5 * (alignment - alignmentX);

			double aXa = alignmentXd2 * a;
			double aXb = alignmentXd2 * b;
/*
			x1t -= aXa;
			y1t -= aXb;
			x2t += aXa;
			y2t += aXb;
			x3t -= aXa;
			y3t -= aXb;
			x4t += aXa;
			y4t += aXb;
*/
		}

		int alignmentY = scaledHeight % alignment;
		if (alignmentY > 0)
		{
			double alignmentYd2 = 0.5 * (alignment - alignmentY);

			double aYa = alignmentYd2 * a;
			double aYb = alignmentYd2 * b;
/*
			x1t -= aYa;
			y1t -= aYb;
			x2t -= aYa;
			y2t -= aYb;
			x3t += aYa;
			y3t += aYb;
			x4t += aYa;
			y4t += aYb;
*/
		}
	}

	rect->coords[0][0] = roundDouble(x1t);
	rect->coords[0][1] = roundDouble(y1t);
	rect->coords[1][0] = roundDouble(x2t);
	rect->coords[1][1] = roundDouble(y2t);
	rect->coords[2][0] = roundDouble(x3t);
	rect->coords[2][1] = roundDouble(y3t);
	rect->coords[3][0] = roundDouble(x4t);
	rect->coords[3][1] = roundDouble(y4t);
}

void CSpot::getRectV(SgmRect *rect, unsigned int pow2ScalingFactor, 
                     unsigned int alignment)
{
	int x1t = (x1 - width) << pow2ScalingFactor;
	int x2t = (x2 + width) << pow2ScalingFactor;
	int y1t = y1 << pow2ScalingFactor;
	int y2t = y2 << pow2ScalingFactor;

	if (alignment > 1)
	{
		const int scaledWidth  = x2t - x1t + 1;
		const int scaledHeight = y2t - y1t + 1;

		int alignmentX = scaledWidth % alignment;

		if (alignmentX > 0)
		{
			alignmentX = alignment - alignmentX;
			int alignmentDx = alignmentX / 2;
			x1t -= alignmentDx;
			x2t += (alignmentX - alignmentDx);
		}

		int alignmentY = scaledHeight % alignment;

		if (alignmentY > 0)
		{
			alignmentY = alignment - alignmentY;
			int alignmentDy = alignmentY / 2;
			y1t -= alignmentDy;
			y2t += (alignmentY - alignmentDy);
		}
	}

	rect->coords[0][0] = x1t;
	rect->coords[0][1] = y1t;
	rect->coords[1][0] = x2t;
	rect->coords[1][1] = y1t;
	rect->coords[2][0] = x1t;
	rect->coords[2][1] = y2t;
	rect->coords[3][0] = x2t;
	rect->coords[3][1] = y2t;
}

unsigned int CSpot::getScaledWidth(unsigned int pow2ScalingFactor)
{
	return (width << pow2ScalingFactor);
}

unsigned int CSpot::getScaledHeight(unsigned int pow2ScalingFactor)
{
	const int deltaX = x1 - x2 + 1;
	const int deltaY = y1 - y2 + 1;
	const int scalingFactor = 1 << pow2ScalingFactor;

	return (unsigned int)(scalingFactor * sqrt((double)(deltaX * deltaX + 
	                                                    deltaY * deltaY)) + 0.5);
}

int CSpot::getX(int yp)
{
	if ((a != 0) && (b != 0))
	{
		return roundDouble(-(b * yp + c) / a);
	}

	return xc;
}

void CSpot::move(int deltaX, int deltaY)
{
	init(x1 + deltaX, y1 + deltaY, x2 + deltaX, y2 + deltaY, width);
}

void CSpot::rotate(double cs, double sn)
{
	init(roundDouble(x1 * cs - y1 * sn),
	     roundDouble(x1 * sn + y1 * cs),
	     roundDouble(x2 * cs - y2 * sn),
	     roundDouble(x2 * sn + y2 * cs),
	     width);
}

int  CSpot::isPointInRect(int x, int y, int n)
{
	if ((y >= (y1 + n)) &&
	    (y <= (y2 - n)))
	{
		int xp = getX(y);
		int wa = roundDouble(a * width);

		if ((x >= (xp - wa + n)) &&
		    (x <= (xp + wa - n)))
		{
			return 1;
		}
	}

	return 0;
}