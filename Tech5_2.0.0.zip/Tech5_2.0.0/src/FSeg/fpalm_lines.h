#ifndef _LINES_H_
#define _LINES_H_

#include "fpalm_types.h"



class CLine
{
public:
	double x1, y1;
	double x2, y2;
	double xc, yc;
	double dx, dy;

	double a, b, c;
	double length;
	double width;
	double xMin;
	double xMax;

	CLine();
	CLine(double xl1, double yl1, double xl2, double yl2, double wl);

	void init(double xl1, double yl1, double xl2, double yl2, double wl);

	double getX(double yp) const;
};


class CDevLine : public CLine
{
public:
	int    devidersCount;
	POINTD deviders[1000];

	int fingerIndex;

	CDevLine();

	void init(double xl1, double yl1, double xl2, double yl2, double wl);
};


class CRect4
{
public:
	void init(CLine *line);

	double x1() const;
	double y1() const;
	double x2() const;
	double y2() const;
	double width() const;

private:
	double m_x11, m_y11;
	double m_x12, m_y12;
	double m_x21, m_y21;
	double m_x22, m_y22;
	double m_xc, m_yc;

	double m_x1, m_y1;
	double m_x2, m_y2;
	double m_width;
};

#endif //_LINES_H_