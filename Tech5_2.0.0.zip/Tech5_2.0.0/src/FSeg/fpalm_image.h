#ifndef _IMAGE_H_
#define _IMAGE_H_

#include "fpalm_constants.h"
#include "fpalm_lines.h"



class CImage
{
public:
	void getDirectLines(unsigned char *bitmap,
	                    int &xMin,
	                    int &yMin,
	                    int &xMax,
	                    int &yMax,
	                    CDevLine *devLines,
	                    int &devLinesCount,
	                    int &upLineY,
	                    int findType);

private:
	int m_img[siH][siW];
	int m_tmp[siH][siW];

	HPOINT m_tx[siH][siW];
	int    m_tn[siH];
	
	HLINE m_ml[siWh];

	int m_siXMin;
	int m_siXMax;
	int m_siYMin;
	int m_siYMax;

	int m_riW;
	int m_riH;

	double m_s2rXk;
	double m_s2rYk;
	double m_r2sXk;
	double m_r2sYk;
	double m_s2sXYk;

	int m_fingersCount;
	int m_separatorsCount;

	CLine m_fingers[5];
	CLine m_separators[4];
	
	double lineS(int x1, int y1,
	             int x2, int y2,
	             unsigned char bgCol);

	void lineWhite(int x1, int y1, int x2, int y2);
	void lineBlack(int x1, int y1, int x2, int y2);
	void lineLight(int x1, int y1, int x2, int y2);

	void loadFromBitmap(unsigned char *bitmap);

	void crop();
	void findFS(CLine *lines, CLine *linesF, int &linesCount, int tp);

	void normalization();
	void blur5();
	void binarization(int findType);
	void fillWhiteRegions();
	void deleteSmallFragmets();
	void correction();
	void getBounds();

	bool isBlackLine(int y);
	int  findUpLine();

	void fillAndFindPoints   (int x, int y);
	void findLineDeviders    (CDevLine* devLine, int x, int y1, int y2);
	void linearApproximation (CDevLine *devLines, int &devLinesCount);

	void setFingerIndexes (CDevLine *devLines, int &devLinesCount);
	void filterLines      (CDevLine *devLines, int &devLinesCount);
};

#endif //_IMAGE_H_