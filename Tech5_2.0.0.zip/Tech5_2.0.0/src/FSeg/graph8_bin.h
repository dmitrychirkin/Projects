#ifndef _GRAPH8_BIN_H_
#define _GRAPH8_BIN_H_



// ����������� �����������

void Binarization8     (unsigned char *img, unsigned int w, unsigned int h);
void BinarizationN8    (unsigned char *img, unsigned int w, unsigned int h);
void BinarizationC8    (unsigned char *img, unsigned int w, unsigned int h, unsigned char col);
int  BinarizationX8    (unsigned char *img, unsigned int w, unsigned int h, unsigned int x1, unsigned int y1, unsigned int x2, unsigned int y2);
int  BinarizationToL8  (unsigned char *img, unsigned int w, unsigned int h, int x1, int y1, int x2, int y2, int n, unsigned char *bin);
void BinarizationOtsu8 (unsigned char *img, unsigned int w, unsigned int h);


// ���������� ��������

void Binary_NOT8    (unsigned char *img, unsigned int w, unsigned int h);
//void Binary_NOT_To8 (unsigned char *img, unsigned int w, unsigned int h, unsigned char *res);
void Binary_AND8   (unsigned char *img1, unsigned char *img2, unsigned int w, unsigned int h);


// ��������� �������� �����������

void GetBounds8       (unsigned char *img, unsigned int w, unsigned int h, unsigned char col, int &x1, int &y1, int &x2, int &y2);
void DeleteHLines8    (unsigned char *img, unsigned int w, unsigned int h, int x1, int y1, int x2, int y2, unsigned char col, unsigned char bg_col, int n);
void DeleteVLines8    (unsigned char *img, unsigned int w, unsigned int h, int x1, int y1, int x2, int y2, unsigned char col, unsigned char bg_col, int n);
void DeleteLines8     (unsigned char *img, unsigned int w, unsigned int h, int x1, int y1, int x2, int y2, unsigned char col, unsigned char bg_col, int n);
//void Fill8            (unsigned char *img, unsigned int w, unsigned int h, int x1, int y1, int x2, int y2, unsigned char col, unsigned char col_tmp, unsigned char *p0);
int  Fill8            (unsigned char *img, unsigned int w, unsigned int h, unsigned char *p0, unsigned char fillColor);
void DeleteSpots8     (unsigned char *img, unsigned int w, unsigned int h, unsigned char col, unsigned char bg_col, int n);
void ExpandLines8     (unsigned char *img, unsigned int w, unsigned int h, unsigned char col, unsigned char bg_col, int n);
/*
void DeleteSpots4x4_8 (unsigned char *img, unsigned int w, unsigned int h, int x1, int y1, int x2, int y2);
void ExpandTo8        (unsigned char *img, unsigned int w, unsigned int h, unsigned char *res);
*/
void Border8          (unsigned char *img, unsigned int w, unsigned int h, unsigned char col);
void FillCavities8    (unsigned char *img, unsigned int w, unsigned int h, int border, int maxLineLength = 0);
void FillSpaces8      (unsigned char *img1, unsigned char *img2, unsigned int w, unsigned int h);
int  FillAroundRoI8   (unsigned char *img, unsigned int w, unsigned int h, unsigned char col, int n, unsigned char *roi);
/*
void FillIfNotInRoI8  (unsigned char *img, unsigned int w, unsigned int h, unsigned char col, int n, unsigned char *roi);
void Line8            (unsigned char *img, unsigned int w, unsigned int h, int x1, int y1, int x2, int y2, unsigned char col);
*/
int  Thinning8        (unsigned char *img, unsigned int w, unsigned int h, int n, unsigned char *roi);
//int  SkelCorrection8  (unsigned char *img, unsigned int w, unsigned int h, int n, unsigned char *roi, unsigned char *dir, unsigned char *res);
int  SkelCorrection8  (unsigned char *img, unsigned int w, unsigned int h, int n, unsigned char *dir);
/*
int  CheckSklROI8     (unsigned char *img, unsigned int w, unsigned int h, int n, unsigned char *roi, unsigned char *dir, unsigned char *res);
*/

int  IsLine8  (unsigned char *img, unsigned int w, unsigned int h, int x1, int y1, int x2, int y2, unsigned char col);
void LineTh8  (unsigned char *img, unsigned int w, unsigned int h, int x1, int y1, int x2, int y2, unsigned char col, int n);
void LineV8   (unsigned char *img, unsigned int w, unsigned int h, int x,  int y1, int y2, unsigned char col);
int  LineN8   (unsigned char *img, unsigned int w, unsigned int h, int x1, int y1, int x2, int y2, unsigned char col);
int  LineCD8  (unsigned char *img, unsigned int w, unsigned int h, int x1, int y1, int x2, int y2, unsigned char col);

void ChangeColor8  (unsigned char *img, unsigned int w, unsigned int h, unsigned char col,  unsigned char col_new);
void ChangeColors8 (unsigned char *img, unsigned int w, unsigned int h, unsigned char col1, unsigned char col2, unsigned char col_new);


#endif