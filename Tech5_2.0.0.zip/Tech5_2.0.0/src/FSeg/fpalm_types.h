#ifndef _TYPES_H_
#define _TYPES_H_



typedef struct tagPOINTD
{
	double x;
	double y;

} POINTD;


typedef struct tagHLINE
{
	int x1, x2;
	int y;

} HLINE;


typedef struct tagHPOINT
{
	int x;
	int w;

} HPOINT;

#endif //_TYPES_H_
