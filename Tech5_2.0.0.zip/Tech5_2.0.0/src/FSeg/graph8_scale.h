#ifndef _GRAPH8_SCALE_H_
#define _GRAPH8_SCALE_H_



void ResizeDecFast8       (unsigned char *img, unsigned int &w, unsigned int &h, unsigned int n);
void ResizeDecFastTo8     (unsigned char *img, unsigned int &w, unsigned int &h, unsigned int n, unsigned char *res);
void ResizeDecLinearTo8   (unsigned char *img, unsigned int &w, unsigned int &h, unsigned int n, unsigned char *res);
int  ResizeDecLinearTo8   (unsigned char *image, unsigned int imageWidth, unsigned int imageHeight, unsigned int resultWidth, unsigned int resultHeight, unsigned char *result);
void ResizeIncFast8       (unsigned char *img, unsigned int &w, unsigned int &h, unsigned int n);
void ResizeIncLinear8     (unsigned char *img, unsigned int &w, unsigned int &h, unsigned int n);
int  ResizeIncDirs8       (unsigned char *dir, unsigned int &w, unsigned int &h, unsigned int n);
int  ResizeIncFrTo8       (unsigned char *img, unsigned int &w, unsigned int &h, unsigned int n, unsigned char *res);
void ResizeFast8          (unsigned char *img, unsigned int &w, unsigned int &h, int n);
int  ResizeDecFastForDPI8 (unsigned char *img, unsigned int &w, unsigned int &h, unsigned int curDPI, unsigned int minDPI);
void SetSize8             (unsigned char *img, unsigned int  w, unsigned int  h, unsigned int wn, unsigned int hn, unsigned char *res, unsigned char bgColor = 255);


#endif