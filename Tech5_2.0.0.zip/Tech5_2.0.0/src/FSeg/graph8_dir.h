#ifndef _GRAPH8_DIR_H_
#define _GRAPH8_DIR_H_



int  GetDirections8  (unsigned char *img, unsigned int w, unsigned int h, int n, unsigned char *roi, unsigned char *dir, unsigned char *qlt);
int  GetDirectionsN8 (unsigned char *img, unsigned int w, unsigned int h, int n, unsigned char *roi, unsigned char *dir, unsigned char *qlt);
int  GetDirectionsL8 (unsigned char *img,
                      unsigned int w,
                      unsigned int h,
                      unsigned int x1,
                      unsigned int y1,
                      unsigned int x2,
                      unsigned int y2,
                      int n,
                      unsigned char *dir);

int  DirsCorrection8 (unsigned char *dir, unsigned int w, unsigned int h, unsigned char *roi);
int  DirsCorrectionL8(unsigned char *dirf,
                      unsigned int w,
                      unsigned int h,
                      int n,
                      unsigned char *img,
                      unsigned char *cor,
                      unsigned char *dlt);

void DirsSegBlurH8(unsigned char *dir,
                   unsigned int w,
                   unsigned int h,
                   unsigned int x1,
                   unsigned int y1,
                   unsigned int x2,
                   unsigned int y2,
                   int n);

void GetCoreAndDelta8(unsigned char *dir,
                      unsigned int w,
                      unsigned int h,
                      unsigned char *roi,
                      unsigned char *cor,
                      unsigned char *dlt);

void GetDir180Quality8(unsigned char *dir, unsigned int w, unsigned int h, unsigned char *roi, unsigned char *qlt);

#endif