////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  ������ �����������, ������� � ��������� ������� ������.                   //
//                                                                            //
//  �����: �. ���������                                                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////


#include "graph8.h"
#include "graph8_const.h"
#include "graph8_frq.h"


#include <stdlib.h>
#include <memory.h>



//----------------------------------------------------------------------------//
// ���������� : ���������� ��� ����������� ������� ������.                    //
// ���������  : pca - �������������� ������� ������������� ��������;          //
//              m   - ������ ����������� (2*m x m);                           //
//              w   - ������ �����������;                                     //
//----------------------------------------------------------------------------//
void GetFrequenciesPrecalc8(int *pca, int m, unsigned int w)
{
	int ang = 0;
	int x = 0;
	int y = 0;

	double cs = 0.0, sn = 0.0;
	double xc = 0.0, xs = 0.0;
	double yc = 0.0, ys = 0.0;

	double *pc = arr_cos_f720 + 90;
	double *ps = arr_sin_f720 + 90;

	const int md2 = m >> 1;

	int *pt = pca;

	for (ang = 0; ang < 180; ang++, pc++, ps++) 
	{
		cs = (*pc);
		sn = (*ps);

		for (x = -m, xc = -m * cs - md2 * sn, xs = -m * sn + md2 * cs; x < m; x++, xc += cs, xs += sn)
		{
			for (y = -md2, yc = -xs, ys = xc; y < md2; y++, yc += cs, ys += sn)
			{
				*pt = (int)ys + w * (int)yc;
				pt++;
			}
		}
	}
}

//----------------------------------------------------------------------------//
// ���������� : ��������� ������� ������.                                     //
// ���������  : img - �����������;                                            //
//              w   - ������ �����������;                                     //
//              h   - ������ �����������;                                     //
//              n   - ������ �������� (2^n);                                  //
//              roi - ����� RoI (������� ���������);                          //
//              dir - ������� �����������;                                    //
//              frq - ������� ������.                                         //
// ���������  : GRAPH_RES_SUCCESS - ������� ������ ��������;                  //
//              GRAPH_RES_ERR_MEM - ������������ ������.                      //
//----------------------------------------------------------------------------//
int GetFrequencies8(unsigned char *img,
                    unsigned int w,
                    unsigned int h,
                    int n,
                    unsigned char *roi,
                    unsigned char *dir,
                    unsigned char *frq)
{
	unsigned char *prx = NULL, *pry = NULL;
	unsigned char *pdx = NULL, *pdy = NULL;
	unsigned char *pfx = NULL, *pfy = NULL;
	unsigned char *pix = NULL, *piy = NULL;
	unsigned char *lrx = NULL, *lry = NULL;

	int *pa = NULL, *pb = NULL;
//	int *pbt;

	int x = 0, y = 0;
	int sum_x = 0;
	int sum_y = 0;
	int flag  = 0;
//	int per, per0;
//	int sum, sum0;

	const int m   = 1 << n;
	const int md2 = m >> 1;
	const int k   = n + 1;
	const int l   = 1 << k;
	const int nk  = n + k;
	const int wm  = w >> n;
	const int hm  = h >> n;
	const int wh  = wm * hm;
	const int wxm = w  * m;

	int *buf = new int[l + l + (180 << nk)];
	int *lb  = buf + l;
	int *arr_sum = lb;
	int *pca     = arr_sum + l;
	int  sum_m   = 255 * m;


	if (buf == NULL)
	{
		return GRAPH_RES_ERR_MEM;
	}

//	int i1, i2, i3;

	GetFrequenciesPrecalc8(pca, m, w);

	memset(frq,           1, wm);
	memset(frq + wh - wm, 1, wm);

	for (pry = roi + wm,
	     pdy = dir + wm,
	     pfy = frq + wm,
	     piy = img + (w + 1) * (m + (m >> 1)),
	     lrx = roi + (wm << 1) - 1,
	     lry = roi + wh - wm;
	     pry < lry;
	     pry += wm,
	     pdy += wm,
	     pfy += wm,
	     piy += wxm,
	     lrx += wm)
	{
		*pfy = 1;

		for (prx = pry + 1,
		     pdx = pdy + 1,
		     pfx = pfy + 1,
		     pix = piy;
		     prx < lrx;
		     prx++,
		     pdx++,
		     pfx++,
		     pix += m)
		{
			if (!(*prx))
			{
				pa = pca + ((*pdx) << nk);
				pb = buf;

				sum_x = 0;

				for (x = -m; x < m; x++)
				{
					sum_y = 0;

					for (y = -md2; y < md2; y++)
					{
						sum_y += *(pix + (*pa));
						pa++;
					}

					sum_x += sum_y;

					*pb = sum_y;  // >> n;  // new
					pb++;
				}

				sum_x >>= k;
				sum_y   = 0;
/*
				// new block begin

				for (i1 = 2; i1 <= m; i1++) // period
				{
					arr_sum[i1] = 0;
					for (i2 = 0; i2 < l; i2++)
					{
						i3 = i2 + i1;
						if (i3 >= l)
						{
							i3 = i2 % i1;
						}
						arr_sum[i1] += arr_abs_delta[buf[i2]][buf[i3]];
					}
				}

				for (i1 = 3, i2 = 2; i1 <= m; i1++)
				{
					if (arr_sum[i1] < arr_sum[i2])
					{
						i2 = i1;
					}
				}

				*pfx = i2;
				// new block end
*/

/*
				flag = 0;
				sum0 = 2 * m * (m * 255) * (m * 255);
				per0 = 0;

				for (per = 1; per < l; per++)
				{
					sum = 0;

					for (pb = buf, pbt = pb + per; pbt < lb; pb++, pbt++)
					{
						sum += (*pb) * (*pbt);
					}

					for (pbt = pb - per; pb < lb; pb++, pbt++)
					{
						sum += (*pb) * (*pbt);
					}

					if (sum > sum0)
					{
						flag = 1;
						per0 = per;

					} else

					if (sum < sum0)
					{
						if (flag == 1)
						{
							per0 = (per0 + per) >> 1;
							break;
						}
					}

					sum0 = sum;
				}

				per = (per0 > 0) ? (((2 * l) + (per0 / 2)) / per0) : 16;

				*pfx = (per <= 16) ? per : 16;
*/

				flag = 0;
				for (pb = buf; pb < lb; pb++)
				{
					if ((*pb) < sum_x - 128)
					{
						if (flag == 1)
						{
							sum_y++;
						}

						flag = -1;

					} else

					if ((*pb) > sum_x + 128)
					{
						if (flag == -1)
						{
							sum_y++;
						}

						flag = 1;
					}
				}

				if (sum_y != 0)
				{
					*pfx = (sum_y <= 16) ? sum_y : 16;
				}
				else
				{
					*pfx = 1;
				}
			}
			else
			{
				*pfx = 1;
			}
		}

		*pfx = 1;
	}

	delete [] buf;

	return GRAPH_RES_SUCCESS;
}

//----------------------------------------------------------------------------//
// ���������� : ���������� ��� ����������� ������� ������.                    //
// ���������  : pca - �������������� ������� ������������� ��������;          //
//              m   - ������ ����������� (2*m x m);                           //
//              w   - ������ �����������;                                     //
//----------------------------------------------------------------------------//
void GetFrequenciesLPrecalc8(int *pca, int m, unsigned int w)
{
	int ang = 0;
	int x   = 0;

	double cs = 0.0, sn = 0.0;
	double xc = 0.0, xs = 0.0;

	double *pc = arr_cos_f720 + 90;
	double *ps = arr_sin_f720 + 90;

	const int md2 = m >> 1;

	int *pt = pca;

	for (ang = 0; ang < 180; ang++, pc++, ps++) 
	{
		cs = (*pc);
		sn = (*ps);

		for (x = -m, xc = -m * cs, xs = -m * sn; x < m; x++, xc += cs, xs += sn)
		{
			*pt = (int)xc - w * (int)xs;
			pt++;
		}
	}
}

int GetFrequenciesL8(unsigned char *img,
                     unsigned int w,
                     unsigned int h,
                     unsigned int x1,
                     unsigned int y1,
                     unsigned int x2,
                     unsigned int y2,
                     int n,
                     unsigned char *dir,
                     unsigned char *frq)
{
	unsigned char *px, *py;
	unsigned char *lx, *ly;
	unsigned char *pdx, *pdy;
	unsigned char *pfx, *pfy;

	int *pb, *pa;

	const int m = 1 << n;
	const int k = n + 1;
	const int l = 1 << k;

	const int dy1  = y1 * w;
	const int dxy1 = x1 + dy1;

	int *buf = new int[l + l + (180 << k)];
	int *lb  = buf + l;
	int *arr_sum = lb;
	int *pca = arr_sum + l;

	if (buf == NULL)
	{
		return GRAPH_RES_ERR_MEM;
	}

	int i1, i2, /*i3,*/ avg, sum;     //, sum_per, count;

	GetFrequenciesLPrecalc8(pca, m, w);

	for (py  = img + dxy1,
		 pdy = dir + dxy1,
		 pfy = frq + dxy1,
		 lx  = img + x2 + dy1,
		 ly  = img + x1 + y2 * w;
		 py <= ly;
		 py += w, pdy += w, pfy += w, lx  += w)
	{
		for (px = py, pdx = pdy, pfx = pfy; px <= lx; px++, pdx++, pfx++)
		{
			avg = 0;

			for (pb = buf, pa = pca + ((*pdx) << k); pb < lb; pb++, pa++)
			{
				*pb = *(px + (*pa));
				avg += *pb;
			}

			avg /= l;

			for (i1 = 2; i1 <= m; i1++)          // period
			{
				sum = 0;

				for (i2 = 0; i2 < m; i2++)
				{
					if ((buf[i2] > avg) == (buf[i2 + i1] > avg))
					{
						sum += (abs(buf[i2]) < abs(buf[i2 + i1])) ? abs(buf[i2]) : abs(buf[i2 + i1]);
					}
				}

				arr_sum[i1] = sum;

/*
				sum = 0;

				for (i2 = 0; i2 < l; i2++)
				{
					i3 = i2 + i1;

					if (i3 >= l)
					{
						i3 = i2 % i1;
					}

					sum += arr_abs_delta[buf[i2]][buf[i3]];
				}

				arr_sum[i1] = sum;
*/

/*
				sum_per = 0;

				for (i2 = 0; i2 < i1; i2++)      // phase
				{
					avg = 0;
					count = 0;

					for (i3 = i2; i3 < l; i3 += i1)
					{
						avg += buf[i3];
						count++;
					}

					avg /= count;
					sum = 0;

					for (i3 = i2; i3 < l; i3 += i1)
					{
						sum += arr_abs_delta[avg][buf[i3]];
					}

					sum_per += sum / count;
				}

				arr_sum[i1] = sum_per / i1;
*/
			}

			for (i1 = 3, i2 = 2; i1 <= m; i1++)
			{
				if (arr_sum[i1] > arr_sum[i2])
				{
					i2 = i1;
				}
			}

			*pfx = i2;
		}
	}

	delete [] buf;

	return GRAPH_RES_SUCCESS;
}

//----------------------------------------------------------------------------//
// ���������� : ��������� ������� ������.                                     //
// ���������  : frq - ������� ������ (freq < 32);                             //
//              w   - ������ ������� ������;                                  //
//              h   - ������ ������� ������;                                  //
//              roi - ����� RoI (������� ���������).                          //
// ���������  : GRAPH_RES_SUCCESS - ��������� ���������;                      //
//              GRAPH_RES_ERR_MEM - ������������ ������.                      // 
//----------------------------------------------------------------------------//
int FreqCorrection8(unsigned char *frq,
                    unsigned int w,
                    unsigned int h,
                    unsigned char *roi)
{
	register unsigned char dlt,freq;

	unsigned char *pr,*pf,*lp;
	unsigned char *p0,*p1,*p2,*p3,*p4,*p5,*p6,*p7;
	unsigned char *p8,*p9,*pA,*pB,*pC,*pD,*pE,*pF;

	const int wh  = w*h;
	const int len = wh<<4;

	unsigned char *mt1 = new unsigned char[len<<1];
	unsigned char *mt2 = mt1+len;

	int flag = 1;
	int iter = 0;


	if (mt1 == NULL)
	{
		return GRAPH_RES_ERR_MEM;
	}

	Blur8(frq, w, h, 1);

	while ((flag == 1) && (iter < 100))
	{
		for (pr = roi,
			 pf = frq,
			 p0 = mt1,   p1 = p0+wh, p2 = p1+wh, p3 = p2+wh,
			 p4 = p3+wh, p5 = p4+wh, p6 = p5+wh, p7 = p6+wh,
			 p8 = p7+wh, p9 = p8+wh, pA = p9+wh, pB = pA+wh,
			 pC = pB+wh, pD = pC+wh, pE = pD+wh, pF = pE+wh,
			 lp = mt1+len;
			 pF < lp;
			 pr++, pf++,
			 p0++, p1++, p2++, p3++, p4++, p5++, p6++, p7++,
			 p8++, p9++, pA++, pB++, pC++, pD++, pE++, pF++)
		{
			if (!(*pr))
			{
				freq = *pf;

				*p0 = abs(freq-1);
				*p1 = abs(freq-2);
				*p2 = abs(freq-3);
				*p3 = abs(freq-4);
				*p4 = abs(freq-5);
				*p5 = abs(freq-6);
				*p6 = abs(freq-7);
				*p7 = abs(freq-8);
				*p8 = abs(freq-9);
				*p9 = abs(freq-10);
				*pA = abs(freq-11);
				*pB = abs(freq-12);
				*pC = abs(freq-13);
				*pD = abs(freq-14);
				*pE = abs(freq-15);
				*pF = abs(freq-16);
			}
			else
			{
				*p0 = 16;
				*p1 = 16;
				*p2 = 16;
				*p3 = 16;
				*p4 = 16;
				*p5 = 16;
				*p6 = 16;
				*p7 = 16;
				*p8 = 16;
				*p9 = 16;
				*pA = 16;
				*pB = 16;
				*pC = 16;
				*pD = 16;
				*pE = 16;
				*pF = 16;
			}
		}

		for (p1 = mt1, p2 = mt2; p1 < lp; p1 += wh, p2 += wh)
		{
			Summ3x3To8(p1, w, h, p2);
		}

		flag = 0;

		for (pr = roi,
			 pf = frq,
			 p0 = mt2,   p1 = p0+wh, p2 = p1+wh, p3 = p2+wh,
			 p4 = p3+wh, p5 = p4+wh, p6 = p5+wh, p7 = p6+wh,
			 p8 = p7+wh, p9 = p8+wh, pA = p9+wh, pB = pA+wh,
			 pC = pB+wh, pD = pC+wh, pE = pD+wh, pF = pE+wh,
			 lp = mt2+len;
			 pF < lp;
			 pr++, pf++,
			 p0++, p1++, p2++, p3++, p4++, p5++, p6++, p7++,
			 p8++, p9++, pA++, pB++, pC++, pD++, pE++, pF++)
		{
			if (!(*pr))
			{
				dlt  = *p0;
				freq = 1;

				if (*p1 < dlt) {dlt = *p1; freq = 2;}
				if (*p2 < dlt) {dlt = *p2; freq = 3;}
				if (*p3 < dlt) {dlt = *p3; freq = 4;}
				if (*p4 < dlt) {dlt = *p4; freq = 5;}
				if (*p5 < dlt) {dlt = *p5; freq = 6;}
				if (*p6 < dlt) {dlt = *p6; freq = 7;}
				if (*p7 < dlt) {dlt = *p7; freq = 8;}
				if (*p8 < dlt) {dlt = *p8; freq = 9;}
				if (*p9 < dlt) {dlt = *p9; freq = 10;}
				if (*pA < dlt) {dlt = *pA; freq = 11;}
				if (*pB < dlt) {dlt = *pB; freq = 12;}
				if (*pC < dlt) {dlt = *pC; freq = 13;}
				if (*pD < dlt) {dlt = *pD; freq = 14;}
				if (*pE < dlt) {dlt = *pE; freq = 15;}
				if (*pF < dlt) {freq = 16;}

				if (*pf != freq)
				{
					flag = 1;
					*pf = freq;
				}
			}
		}

		iter++;
	}

	for (pf = frq, pr = roi, lp = pf+wh; pf < lp; pf++, pr++)
	{
		if (!(*pr))
		{
			if ((*pf < 2) || (*pf > 10))
//			if ((*pf < 6) || (*pf > 32))
			{
				*pr = 1;
			}
		}
	}

	delete [] mt1;

	return GRAPH_RES_SUCCESS;
}