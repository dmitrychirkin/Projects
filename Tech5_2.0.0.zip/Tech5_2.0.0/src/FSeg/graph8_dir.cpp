////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  ������ �����������, ������� � ��������� ������� �����������.              //
//                                                                            //
//  �����: �. ���������                                                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////


#include "graph8.h"
#include "graph8_const.h"
#include "graph8_dir.h"


#include <stdlib.h>
#include <math.h>
#include <memory.h>



//----------------------------------------------------------------------------//
// ���������� : ��������� ������� �����������.                                //
// ���������  : img - �����������;                                            //
//              w   - ������ �����������;                                     //
//              h   - ������ �����������;                                     //
//              n   - ������ �������� (2^n);                                  //
//              roi - ����� RoI (������� ���������);                          //
//              dir - ������� �����������.                                    //
// ���������  : GRAPH_RES_SUCCESS - ������������ ���������;                   //
//              GRAPH_RES_ERR_MEM - ������������ ������.                      // 
//----------------------------------------------------------------------------//
int GetDirections8(unsigned char *img,
                   unsigned int w,
                   unsigned int h,
                   int n,
                   unsigned char *roi,
                   unsigned char *dir,
                   unsigned char *qlt)
{
	register int gx, gy;

	unsigned char *pr, *pd, *pq;
	unsigned char *px, *py;
	unsigned char *lx, *ly;
	unsigned char *p1y, *p2y, *p3y;
	unsigned char *lbx, *lby;
	unsigned char *p1, *p2, *p3;
	unsigned char  v1, v2, v3, v4, v5, v6, v7, v8, v9;

	int d1, d2;
	int g1, g2;

	const int m   = 1 << n;
	const int wm  = w >> n;
	const int hm  = h >> n;
	const int wxm = w << n;
	const int wh  = wm * hm;

	int *mg1 = new int[wh << 2];
	int *mg2 = mg1 + wh;
	int *pg1, *pg2;


	if (mg1 == NULL)
	{
		return GRAPH_RES_ERR_MEM;
	}

	for (pr  = roi,
	     pq  = qlt,
	     pg1 = mg1,
	     pg2 = mg2,
	     py  = img,
	     lx  = roi + wm,
	     ly  = roi + wh;
	     pr  < ly;
	     py += wxm,
	     lx += wm)
	{
		for (px = py; pr < lx; pr++, pq++, pg1++, pg2++, px += m)
		{
			if (!(*pr))
			{
				g1 = 0;
				g2 = 0;

				for (p1y = px,
				     p2y = p1y + w,
				     p3y = p2y + w,
				     lbx = px + m,
				     lby = px + wxm;
				     p3y < lby;
				     p1y = p2y,
				     p2y = p3y,
				     p3y += w,
				     lbx += w)
				{
					v1 = *p1y;
					v4 = *p2y; 
					v7 = *p3y;

					p1 = p1y + 1;
					p2 = p2y + 1;
					p3 = p3y + 1;

					v2 = *p1;
					v5 = *p2; 
					v8 = *p3;

					for (p1++, p2++, p3++; p1 < lbx; p1++, p2++, p3++)
					{
						v3 = *p1;
						v6 = *p2; 
						v9 = *p3;

						d1 = v9 - v1;
						d2 = v7 - v3;

						gx = d1 + d2 + ((v8 - v2) << 1);
						gy = d1 - d2 + ((v6 - v4) << 1);

						g1 += gx * gy;
						g2 += gx * gx - gy * gy;

						v1 = v2;
						v2 = v3;
						v4 = v5;
						v5 = v6;
						v7 = v8;
						v8 = v9;
					}
				}

				*pg1 = g1;
				*pg2 = g2;
/*
				g1 = abs(*pg1)>>14;
				g2 = abs(*pg2)>>15;
				g1 = (int)(sqrt((double)(g1*g1+g2*g2)+0.5));
*/
				*pq = 255;//(g1 < 256) ? g1 : 255;
			}
			else
			{
				*pq = 0;
			}
		}
	}
/*
	Blur8(qlt, wm, hm, 4);

	for (pd = qlt, pr = roi; pr < lx; pd++, pr++)
	{
		if (*pd == 0)
		{
			*pr = 1;
		}
	}
*/
	pg1 = mg1 + wh + wh;
	pg2 = mg2 + wh + wh;
/*
	Summ3x3QTo32(mg1, wm, hm, 0, 0, wm-1, hm-1, qlt, pg1);
	Summ3x3QTo32(mg2, wm, hm, 0, 0, wm-1, hm-1, qlt, pg2);
*/
	Summ3x3To32(mg1, wm, hm, 0, 0, wm - 1, hm - 1, pg1);
	Summ3x3To32(mg2, wm, hm, 0, 0, wm - 1, hm - 1, pg2);

	double ang_r;
	unsigned char ang;

	for (pd = dir, lx = dir + wh; pd < lx; pd++, pg1++, pg2++)
	{
		ang_r = val_90_div_pi * atan2((double)((*pg1) << 1), (double)(*pg2));
		ang   = (ang_r >= 0.0) ? (unsigned char)(ang_r + 0.5) : (unsigned char)(ang_r + 180.5);
		*pd = (ang != 180) ? ang : 0;
	}

	delete [] mg1;

	return GRAPH_RES_SUCCESS;
}

//----------------------------------------------------------------------------//
// ���������� : ��������� ������� �����������.                                //
// ���������  : img - �����������;                                            //
//              w   - ������ �����������;                                     //
//              h   - ������ �����������;                                     //
//              n   - ������ �������� (2^n);                                  //
//              roi - ����� RoI (������� ���������);                          //
//              dir - ������� �����������.                                    //
// ���������  : GRAPH_RES_SUCCESS - ������������ ���������;                   //
//              GRAPH_RES_ERR_MEM - ������������ ������.                      // 
//----------------------------------------------------------------------------//
int GetDirectionsN8(unsigned char *img,
                    unsigned int w,
                    unsigned int h,
                    int n,
                    unsigned char *roi,
                    unsigned char *dir,
                    unsigned char *qlt)
{
	unsigned char *pr, *pd, *pq, *pa;
	unsigned char *px, *py;
	unsigned char *lx, *ly;

	unsigned char *lbx, *lby, *lbx2;
	unsigned char *px1, *py1, *px2, *py2;

	const int m   = 1 << n;
	const int mm1 = m - 1;
	const int wm  = w >> n;
	const int hm  = h >> n;
	const int wxm = w << n;
	const int wh  = wm * hm;

	int x1, y1, x2, y2;
	int vt, nt;
	double vr, vm;
	double ang_r;
	int sum[180];
	int num1[180];
	double num5[180];
	int szs = 180 * sizeof(int);

	unsigned char va;
	unsigned char *ang = new unsigned char[1 << (n << 2)];


	memset(num1, 0, szs);

	pa = ang;

	for (y1 = 0; y1 < m; y1++)
	{
		for (x1 = 0; x1 < m; x1++)
		{
			if (x1 != mm1)
			{
				x2 = x1 + 1;
				y2 = y1;
			}
			else
			{
				x2 = 0;
				y2 = y1 + 1;
			}

			for (; y2 < m; y2++)
			{
				for (; x2 < m; x2++)
				{
					ang_r = val_180_div_pi * atan2((double)(y1 - y2), (double)(x2 - x1));

					nt = (ang_r >= 0.0) ? (int)(ang_r + 0.5) : (int)(ang_r + 180.5);

					if (nt == 180)
					{
						nt = 0;
					}

					*pa = nt;
					pa++;

					num1[nt]++;
				}

				x2 = 0;
			}
		}
	}

	unsigned char a, a1, a2;

	a1 = 175;
	a2 = 6;
	nt = num1[175] + num1[176] + num1[177] + num1[178] + num1[179] + num1[0] + num1[1] + num1[2] + num1[3] + num1[4] + num1[5];

	num5[0] = 1.0 / nt;

	for (a = 1; a < 180; a++)
	{
		nt -= num1[a1];
		nt += num1[a2];

		num5[a] = (nt != 0) ? (1.0 / nt) : 0;

		a1 = (a1 != 179) ? (a1 + 1) : 0;
		a2 = (a2 != 179) ? (a2 + 1) : 0;
	}

	for (pr  = roi,
	     pq  = qlt,
	     pd  = dir,
	     py  = img,
	     lx  = roi + wm,
	     ly  = roi + wh;
	     pr  < ly;
	     py += wxm,
	     lx += wm)
	{
		for (px = py; pr < lx; pr++, pq++, pd++, px += m)
		{
			if (!(*pr))
			{
				memset(sum, 0, szs);

				pa = ang;

				for (py1 = px, lbx = px + mm1, lby = px + wxm; py1 < lby; py1 += w, lbx += w)
				{
					for (px1 = py1; px1 <= lbx; px1++)
					{
						va = *px1;

						if (px1 != lbx)
						{
							px2  = px1 + 1;
							py2  = py1;
							lbx2 = lbx;
						}
						else
						{
							px2  = py1 + w;
							py2  = px2;
							lbx2 = lbx + w;
						}

						for (; py2 < lby; py2 += w, lbx2 += w)
						{
							for (; px2 <= lbx2; px2++)
							{
								sum[*pa] += arr_abs_delta[*px2][va];
								pa++;
							}

							px2 = py2 + w;
						}
					}
				}

				a1 = 175;
				a2 = 6;
				vt = sum[175] + sum[176] + sum[177] + sum[178] + sum[179] + sum[0] + sum[1] + sum[2] + sum[3] + sum[4] + sum[5];
				vm = vt * num5[0];
				va = 0;

				for (a = 1; a < 180; a++)
				{
					vt -= sum[a1];
					vt += sum[a2];

					vr = vt * num5[a];
					if (vr < vm)
					{
						vm = vr;
						va = a;
					}

					a1 = (a1 != 179) ? (a1 + 1) : 0;
					a2 = (a2 != 179) ? (a2 + 1) : 0;
				}

				*pd = va;
				*pq = 255; //(g1 < 256) ? g1 : 255;
			}
			else
			{
				*pd = 0;
				*pq = 0;
			}
		}
	}
/*
	Blur8(qlt, wm, hm, 4);

	for (pd = qlt, pr = roi; pr < lx; pd++, pr++)
	{
		if (*pd == 0)
		{
			*pr = 1;
		}
	}
*/
	return GRAPH_RES_SUCCESS;
}

//----------------------------------------------------------------------------//
// ���������� : ��������� ������� �����������.                                //
// ���������  : img   - �������� �����������;                                 //
//              w     - ������ �����������;                                   //
//              h     - ������ �����������;                                   //
//              x1,y1 - ���������� ������ �������� ���� �������������� RoI;   //
//              x2,y2 - ���������� ������� ������� ���� �������������� RoI;   //
//              n     - ������ ����������� 2^n;                               //
//              dir   - ������� �����������.                                  //
// ���������  : GRAPH_RES_SUCCESS - ������� ����������� ��������;             //
//              GRAPH_RES_ERR_MEM - ������������ ������.                      // 
//----------------------------------------------------------------------------//
int GetDirectionsL8(unsigned char *img,
                    unsigned int w,
                    unsigned int h,
                    unsigned int x1,
                    unsigned int y1,
                    unsigned int x2,
                    unsigned int y2,
                    int n,
                    unsigned char *dir)
{
	register int val1 = 0;
	register int val2 = 0;
	register int *p11, *p12, *p21, *p22;

	unsigned char *py,  *ly;
	unsigned char *px1, *py1;
	unsigned char *px2, *py2;
	unsigned char *pxi, *pyi;
	int *pg1, *pg2;

	const int nx2 = n << 1;
	const int m   = 1 << n;
	const int md2 = m >> 1;
	const int x1t = x1 - md2;
	const int y1t = y1 - md2;
	const int x2t = x2 + m - md2 - 1;
	const int y2t = y2 + m - md2 - 1;
	const int wr  = x2t - x1t + 1;
	const int wh  = (x2 - x1 + 1) * (y2 - y1 + 1);

	int *ml1 = new int[(wr << 1) + (wh << 2)];
	int *ml2 = ml1 + wr;
	int *mg1 = ml2 + wr;
	int *mg2 = mg1 + wh;

	if (ml1 == NULL)
	{
		return GRAPH_RES_ERR_MEM;
	}

	const int d1  = x1t + w * y1t;
	const int d2  = x1t + w * y2t;
	const int dc  = d1  + md2 * (w + 1);

	const int *l1 = ml1 + m - 1;
	const int *l2 = ml1 + wr;

	const int dv1 = -1 - w;
	const int dv2 = -(int)w;
	const int dv3 =  1 - w;
	const int dv4 = -1;
	const int dv6 =  1;
	const int dv7 = -1 + w;
	const int dv8 =  w;
	const int dv9 =  1 + w;

	int d91, d73;
	int gx, gy;
	double ang_r;
	unsigned char ang;

	for (p21 = ml1,
	     p22 = ml2,
	     px1 = img + d1,
	     px2 = px1 + w * m;
	     p21 < l1;
	     p21++, p22++,
	     px1++, px2++)
	{
		*p21 = 0;
		*p22 = 0;

		for (py = px1; py < px2; py += w)
		{
			d91 = (*(py + dv9)) - (*(py + dv1));
			d73 = (*(py + dv7)) - (*(py + dv3));

			gx = d91 + d73 + (((*(py + dv8)) - (*(py + dv2))) << 1);
			gy = d91 - d73 + (((*(py + dv6)) - (*(py + dv4))) << 1);

			*p21 += gx * gy;
			*p22 += gx * gx - gy * gy;
		}

		val1 += (*p21);
		val2 += (*p22);
	}

	for (p11 = ml1,
	     p12 = ml2,
	     pxi = img + dc,
	     pg1 = mg1,
	     pg2 = mg2;
	     p21 < l2;
	     p11++, p12++,
	     p21++, p22++,
	     px1++, px2++,
	     pxi++, pg1++, pg2++)
	{
		*p21 = 0;
		*p22 = 0;

		for (py = px1; py < px2; py += w)
		{
			d91 = (*(py + dv9)) - (*(py + dv1));
			d73 = (*(py + dv7)) - (*(py + dv3));

			gx = d91 + d73 + (((*(py + dv8)) - (*(py + dv2))) << 1);
			gy = d91 - d73 + (((*(py + dv6)) - (*(py + dv4))) << 1);

			*p21 += gx * gy;
			*p22 += gx * gx - gy * gy;
		}

		val1 += (*p21);
		val2 += (*p22);

		*pg1 = val1;
		*pg2 = val2;

		val1 -= (*p11);
		val2 -= (*p12);
	}

	for (py1 = img + d1,
	     py2 = py1 + w * m,
	     pyi = img + dc + w,
	     ly  = img + x1t + y2t * w;
	     py2 <= ly;
	     py1 += w, py2 += w, pyi += w)
	{
		val1 = 0;
		val2 = 0;

		for (p21 = ml1,
		     p22 = ml2,
		     px1 = py1,
		     px2 = py2;
		     p21 < l1;
		     p21++, p22++,
		     px1++, px2++)
		{
			d91 = (*(px1 + dv9)) - (*(px1 + dv1));
			d73 = (*(px1 + dv7)) - (*(px1 + dv3));

			gx = d91 + d73 + (((*(px1 + dv8)) - (*(px1 + dv2))) << 1);
			gy = d91 - d73 + (((*(px1 + dv6)) - (*(px1 + dv4))) << 1);

			*p21 -= gx * gy;
			*p22 -= gx * gx - gy * gy;

			d91 = (*(px2 + dv9)) - (*(px2 + dv1));
			d73 = (*(px2 + dv7)) - (*(px2 + dv3));

			gx = d91 + d73 + (((*(px2 + dv8)) - (*(px2 + dv2))) << 1);
			gy = d91 - d73 + (((*(px2 + dv6)) - (*(px2 + dv4))) << 1);

			*p21 += gx * gy;
			*p22 += gx * gx - gy * gy;

			val1 += (*p21);
			val2 += (*p22);
		}

		for (p11 = ml1,
		     p12 = ml2,
		     pxi = pyi;
		     p21 < l2;
		     p11++, p12++, p21++, p22++, px1++, px2++, pxi++, pg1++, pg2++)
		{
			d91 = (*(px1 + dv9)) - (*(px1 + dv1));
			d73 = (*(px1 + dv7)) - (*(px1 + dv3));

			gx = d91 + d73 + (((*(px1 + dv8)) - (*(px1 + dv2))) << 1);
			gy = d91 - d73 + (((*(px1 + dv6)) - (*(px1 + dv4))) << 1);

			*p21 -= gx * gy;
			*p22 -= gx * gx - gy * gy;

			d91 = (*(px2 + dv9)) - (*(px2 + dv1));
			d73 = (*(px2 + dv7)) - (*(px2 + dv3));

			gx = d91 + d73 + (((*(px2 + dv8)) - (*(px2 + dv2))) << 1);
			gy = d91 - d73 + (((*(px2 + dv6)) - (*(px2 + dv4))) << 1);

			*p21 += gx * gy;
			*p22 += gx * gx - gy * gy;

			val1 += (*p21);
			val2 += (*p22);

			*pg1 = val1;
			*pg2 = val2;

			val1 -= (*p11);
			val2 -= (*p12);
		}
	}
/*
	pg1 = mg1 + wh + wh;
	pg2 = mg2 + wh + wh;

	Summ3x3To32(mg1, x2 - x1 + 1, y2 - y1 + 1, 0, 0, x2 - x1, y2 - y1, pg1);
	Summ3x3To32(mg2, x2 - x1 + 1, y2 - y1 + 1, 0, 0, x2 - x1, y2 - y1, pg2);
*/
	pg1 = mg1;
	pg2 = mg2;

	for (py1 = dir + x1 + y1 * w,
	     py2 = dir + x1 + y2 * w,
	     px2 = dir + x2 + y1 * w;
	     py1 <= py2;
	     py1 += w,
	     px2 += w)
	{
		for (px1 = py1; px1 <= px2; px1++, pg1++, pg2++)
		{
			ang_r = val_90_div_pi * atan2((double)((*pg1) << 1), (double)(*pg2));
			ang   = (ang_r >= 0.0) ? (unsigned char)(ang_r + 0.5) : (unsigned char)(ang_r + 180.5);
			*px1  = (ang   != 180) ? ang : 0;
		}
	}

	delete [] ml1;

	return GRAPH_RES_SUCCESS;
}

//----------------------------------------------------------------------------//
// ���������� : ��������� ������� �����������.                                //
// ���������  : dir - ������� �����������;                                    //
//              w   - ������ ������� �����������;                             //
//              h   - ������ ������� �����������;                             //
//              roi - ����� RoI (������� ���������).                          //
// ���������  : GRAPH_RES_SUCCESS - ��������� ���������;                      //
//              GRAPH_RES_ERR_MEM - ������������ ������.                      // 
//----------------------------------------------------------------------------//
int DirsCorrection8(unsigned char *dir,
                    unsigned int w,
                    unsigned int h,
                    unsigned char *roi)
{
	register unsigned char dlt,ang,res;

	unsigned char *pr,*pd;
	unsigned char *p1,*p2,*p;

	const int wh  = w*h;
	const int len = 180*wh;

	const unsigned char *lp = roi+wh;

	unsigned char *mt1 = new unsigned char[len<<1];
	unsigned char *mt2 = mt1+len;

	int flag = 1;
	int iter = 0;


	if (mt1 == NULL)
	{
		return GRAPH_RES_ERR_MEM;
	}

	while ((flag == 1) && (iter < 1))
	{
		p = mt1;

		for (ang = 0, p1 = mt1, p2 = mt2; ang < 180; ang++, p1 += wh, p2 += wh)
		{
			for (pr = roi, pd = dir; pr < lp; pr++, pd++, p++)
			{
				if (!(*pr))
				{
					dlt = abs(*pd-ang);
					*p  = (dlt <= 90) ? dlt : 180-dlt;
				}
				else
				{
					*p = 90;
				}
			}

			Blur3x3To8(p1, w, h, 0, 0, w-1, h-1, p2);
		}

		flag = 0;

		for (pr = roi, pd = dir, p1 = mt2; pr < lp; pr++, pd++, p1++)
		{
			if (!(*pr))
			{
				res = 0;
				dlt = *p1;

				for (ang = 1, p2 = p1+wh; ang < 180; ang++, p2 += wh)
				{
					if (*p2 < dlt)
					{
						dlt = *p2;
						res = ang;
					}
				}

				dlt = abs(*pd-res);

				if (dlt > 90)
				{
					dlt = 180-dlt;
				}

				if (dlt > 5)
				{
					flag = 1;
					*pd = res;
				}
			}
		}

		iter++;
	}

	delete [] mt1;

	return iter;//GRAPH_RES_SUCCESS;
}


//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//
void DirsSegBlurH8(unsigned char *dir,
                   unsigned int w,
                   unsigned int h,
                   unsigned int x1,
                   unsigned int y1,
                   unsigned int x2,
                   unsigned int y2,
                   int n)
{
	register unsigned char *px,*py,*pt;

	unsigned char *pl,*lx,*lxx,*ly;
	unsigned char p1,p2,p3;
	unsigned char d1,d2,d12;

	const int y1w = y1*w;


	for (int i = 0; i < n; i++)
	{
		for (py = dir+y1w+x1,
		     lx = dir+y1w+x2-3,
		     ly = dir+y2*w+x1;
		     py <= ly;
		     py += w,
		     lx += w)
		{
			px =  py;
			p1 = *px++;
			p2 = *px;
			pl =  px;
			d1 = p1+p2;

			if (abs(p1-p2) > 9)
			{
				d1 = (d1 >= 18) ? (d1-18) : (d1+18);
			}

			*py = (d1+1)>>1;

			while (px <= lx)
			{
				pt =  px++;
				p3 = *px;
				d2 = p2+p3;

				if (abs(p2-p3) > 9)
				{
					d2 = (d2 >= 18) ? (d2-18) : (d2+18);
				}

				if (abs(d1-d2) > 18)
				{
					d12 = d1+d2;
					*pt = (d12 >= 36) ? ((d12-34)>>2) : ((d12+38)>>2);
				}
				else
				{
					*pt = (d1+d2+2)>>2;
				}

				pt =  px++;
				p1 = *px;
				d1 = p3+p1;

				if (abs(p3-p1) > 9)
				{
					d1 = (d1 >= 18) ? (d1-18) : (d1+18);
				}

				if (abs(d1-d2) > 18)
				{
					d12 = d1+d2;
					*pt = (d12 >= 36) ? ((d12-34)>>2) : ((d12+38)>>2);
				}
				else
				{
					*pt = (d1+d2+2)>>2;
				}

				pt =  px++;
				p2 = *px;

				d2 = p1+p2;

				if (abs(p1-p2) > 9)
				{
					d2 = (d2 >= 18) ? (d2-18) : (d2+18);
				}

				if (abs(d1-d2) > 18)
				{
					d12 = d1+d2;
					*pt = (d12 >= 36) ? ((d12-34)>>2) : ((d12+38)>>2);
				}
				else
				{
					*pt = (d1+d2+2)>>2;
				}

				d1 = d2;
			}

			lxx = lx+2;

			while (px <= lxx)
			{
				pt =  px++;
				p3 =  p1;
				p1 =  p2;
				p2 = *px;
				d2 = p1+p2;

				if (abs(p1-p2) > 9)
				{
					d2 = (d2 >= 18) ? (d2-18) : (d2+18);
				}

				if (abs(d1-d2) > 18)
				{
					d12 = d1+d2;
					*pt = (d12 >= 36) ? ((d12-34)>>2) : ((d12+38)>>2);
				}
				else
				{
					*pt = (d1+d2+2)>>2;
				}

				d1 = d2;
			}

			*px = (d2+1)>>1;
		}
	}
}


//----------------------------------------------------------------------------//
// ���������� : ��������� ������ ������ ���� � ������.                        //
// ���������  : dir - ������� �����������;                                    //
//              w   - ������ ������� �����������;                             //
//              h   - ������ ������� �����������;                             //
//              roi - ����� RoI (������� ���������);                          //
//              cor - ������� ��� ������ ����;                                //
//              dlr - ������� ��� ������ ������.                              //
//----------------------------------------------------------------------------//
void GetCoreAndDelta8(unsigned char *dir,
                      unsigned int w,
                      unsigned int h,
                      unsigned char *roi,
                      unsigned char *cor,
                      unsigned char *dlt)
{
	unsigned char *pr,*py;
	unsigned char *pc,*pd,*pt;
	unsigned char *lx,*ly;
	unsigned char *px1,*px2,*px3,*px4,*px5,*px6,*px7,*px8,*px9;
	unsigned char *pr1,*pr2,*pr3,*pr4,*pr5,*pr6,*pr7,*pr8,*pr9;

	int sum,val;

	const int wh    = w*h;
	const int wx2p2 = (w<<1)+2;
	const int wx3   = w*3;


	memset(cor,        0, wx3);
	memset(cor+wh-wx3, 0, wx3);
	memset(dlt,        0, wx3);
	memset(dlt+wh-wx3, 0, wx3);

	for (py = dir+wx2p2,
	     pr = roi+wx2p2,
	     pc = cor+wx3,
	     pd = dlt+wx3,
	     lx = dir+wx3-2,
	     ly = dir+wh-(w<<2)+2;
	     py < ly;
	     py += w,
	     pr += w,
	     lx += w)
	{
		memset(pc, 0, 3);
		pc += 3;

		memset(pd, 0, 3);
		pd += 3;

		for (px1 = py,    px2 = px1+1, px3 = px2+1,
		     px4 = px1+w, px5 = px4+1, px6 = px5+1,
		     px7 = px4+w, px8 = px7+1, px9 = px8+1,
		     pr1 = pr,    pr2 = pr1+1, pr3 = pr2+1,
		     pr4 = pr1+w, pr5 = pr4+1, pr6 = pr5+1,
		     pr7 = pr4+w, pr8 = pr7+1, pr9 = pr8+1;
		     px3 < lx;
		     px1 = px2, px2 = px3, px3++,
		     px4 = px5, px5 = px6, px6++,
		     px7 = px8, px8 = px9, px9++,
		     pr1 = pr2, pr2 = pr3, pr3++,
		     pr4 = pr5, pr5 = pr6, pr6++,
		     pr7 = pr8, pr8 = pr9, pr9++,
		     pc++, pd++)
		{
			if (!(*pr1) && !(*pr2) && !(*pr3) && 
			    !(*pr4) && !(*pr5) && !(*pr6) &&
			    !(*pr7) && !(*pr8) && !(*pr9))
			{
				sum = (*px2)-(*px1);

				if (sum >  90)  sum = -180+sum; else
				if (sum < -90)  sum =  180+sum;

				val = (*px3)-(*px2);

				if (val >  90)  sum += -180+val; else
				if (val < -90)  sum +=  180+val; else  sum += val;

				val = (*px6)-(*px3);

				if (val >  90)  sum += -180+val; else
				if (val < -90)  sum +=  180+val; else  sum += val;

				val = (*px9)-(*px6);

				if (val >  90)  sum += -180+val; else
				if (val < -90)  sum +=  180+val; else  sum += val;

				val = (*px8)-(*px9);

				if (val >  90)  sum += -180+val; else
				if (val < -90)  sum +=  180+val; else  sum += val;

				val = (*px7)-(*px8);

				if (val >  90)  sum += -180+val; else
				if (val < -90)  sum +=  180+val; else  sum += val;

				val = (*px4)-(*px7);

				if (val >  90)  sum += -180+val; else
				if (val < -90)  sum +=  180+val; else  sum += val;

				val = (*px1)-(*px4);

				if (val >  90)  sum += -180+val; else
				if (val < -90)  sum +=  180+val; else  sum += val;

				if (abs(sum) == 180)
				{
					for (pt = pr5-3; pt <= pr5+3; pt++)
					{
						if ((*(pt-wx3) == 1) || (*(pt+wx3) == 1))
						{
							sum = 0;
							break;
						}
					}
				}

				if (abs(sum) == 180)
				{
					for (pt = pr5-wx3; pt <= pr5+wx3; pt += w)
					{
						if ((*(pt-3) == 1) || (*(pt+3) == 1))
						{
							sum = 0;
							break;
						}
					}
				}

				*pc = (sum == -180);
				*pd = (sum ==  180);
			}
			else
			{
				*pd = 0;
				*pc = 0;
			}
		}

		memset(pc, 0, 3);
		pc += 3;

		memset(pd, 0, 3);
		pd += 3;
	}
}

//----------------------------------------------------------------------------//
// ���������� : ��������� ������� �������� �����������.                       //
// ���������  : dir - ������� �����������;                                    //
//              w   - ������ ������� �����������;                             //
//              h   - ������ ������� �����������;                             //
//              roi - ����� RoI (������� ���������);                          //
//              qlt - ������� �������� �����������.                           //
//----------------------------------------------------------------------------//
void GetDir180Quality8(unsigned char *dir,
                       unsigned int w,
                       unsigned int h,
                       unsigned char *roi,
                       unsigned char *qlt)
{
	register int d;

	unsigned char *pry,*pdy,*pqy;
	unsigned char *lrx,*lry;
	unsigned char *pr1,*pr2,*pr3,*pr4;
	unsigned char *pd1,*pd2,*pd3,*pd4;
	unsigned char *pq1,*pq2,*pq3,*pq4;

	const int wh = w*h;


	memset(qlt, 0, wh);

	for (pry = roi,
	     pdy = dir,
	     pqy = qlt,
	     lrx = roi+w-1,
	     lry = roi+wh-w;
	     pry < lry;
	     pry += w,
	     pdy += w,
	     pqy += w,
	     lrx += w)
	{
		for (pr1 = pry, pr2 = pr1+1, pr3 = pry+w, pr4 = pr3+1,
		     pd1 = pdy, pd2 = pd1+1, pd3 = pdy+w, pd4 = pd3+1,
		     pq1 = pqy, pq2 = pq1+1, pq3 = pqy+w, pq4 = pq3+1;
		     pr2 < lrx;
		     pr1 = pr2, pr3 = pr4, pr2++, pr4++,
		     pd1 = pd2, pd3 = pd4, pd2++, pd4++,
		     pq1 = pq2, pq3 = pq4, pq2++, pq4++)
		{
			if (!(*pr1))
			{
				if (!(*pr2))
				{
					d = abs(*pd1-(*pd2));

					if (d > 90)
					{
						d = 180-d;
					}

					*pq1 += d;
					*pq2 += d;
				}

				if (!(*pr3))
				{
					d = abs(*pd1-(*pd3));

					if (d > 90)
					{
						d = 180-d;
					}

					*pq1 += d;
					*pq3 += d;
				}

				if (!(*pr4))
				{
					d = abs(*pd1-(*pd4));

					if (d > 90)
					{
						d = 180-d;
					}

					*pq1 += d;
					*pq4 += d;
				}
			}

			if ((!(*pr2)) && (!(*pr3)))
			{
				d = abs(*pd2-(*pd3));

				if (d > 90)
				{
					d = 180-d;
				}

				*pq2 += d;
				*pq3 += d;
			}
		}
	}
}

int DirsCorrectionL8(unsigned char *dirf,
                     unsigned int w,
                     unsigned int h,
                     int n,
                     unsigned char *img,
                     unsigned char *cor,
                     unsigned char *dlt)
{
	int x,y,res;
	unsigned char *pc,*pd;

	const int wn   = w>>n;
	const int hn   = h>>n;
	const int wnm1 = wn-1;
	const int hnm1 = hn-1;


	for (y = 0, pc = cor, pd = dlt; y < hn; y++)
	{
		for (x = 0; x < wn; x++, pc++, pd++)
		{
			if ((*pc) || (*pd) ||
			    ((x > 0)    && ((*(pc-1))  || (*(pd-1)))) ||
			    ((x < wnm1) && ((*(pc+1))  || (*(pd+1)))) ||
			    ((y > 0)    && ((*(pc-wn)) || (*(pd-wn)))) ||
			    ((y < hnm1) && ((*(pc+hn)) || (*(pd+wn)))))
			{
				res = GetDirectionsL8(img, w, h, x<<4, y<<4, (x<<4)+15, (y<<4)+15, 4, dirf);

				if (res != GRAPH_RES_SUCCESS)
				{
					return res;
				}
			}
		}
	}

	return GRAPH_RES_SUCCESS;
}