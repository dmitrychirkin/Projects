#include <stdio.h>
#include "test_Tech5_GalleryMatcher_ServerE.h"

void freeBuffer(BYTE **buffer)
{
   if (*buffer) delete [] *buffer, *buffer = NULL;
}

void allocBuffer(BYTE **buffer, uint32_t size)
{
   freeBuffer(buffer);
   *buffer = new BYTE [size];
   if (!(*buffer))
      throw "Cannot allocate memory for buffer";
}


void checkResult(char *funcName, uint32_t result)
{
   if (result == SUCCESS)
      return;
   char msg[1024];
   sprintf (msg, "%s return error = %d", funcName, result);
   throw msg;
}



int main(int argc, char* argv[])
{
	char *imageDir        = "../../test/NIST14/Images";
	char *templateDir     = "../../test/NIST14/Templates";
	char *resultFilePath = "../../test/NIST14/cmc_speed.txt";
   char *license_file    ="../../test/tech5_gallery_matcher.lic";
	
   // test building templates
	buildAllTemplates( imageDir  , templateDir,    license_file);
	// test checking templates
   //checkAllTemplates(templateDir,                 license_file);
   // check matching templates
   //matchAllTemplates(templateDir, resultFilePath, license_file);


	return 0;
}

