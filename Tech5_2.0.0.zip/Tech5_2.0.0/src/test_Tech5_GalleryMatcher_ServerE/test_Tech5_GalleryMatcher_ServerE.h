#ifndef TEST_TECH5_GALLERYMATCHER_SERVERE_H_
#define  TEST_TECH5_GALLERYMATCHER_SERVERE_H_

#if defined _WIN32 || defined _WIN64
#include <windows.h>
#include <vld.h>
#endif

#include "Tech5_GalleryMatcher_ServerE.h"

using namespace std        ;
using namespace Tech5Finger;



// allocate and free memory for *buffer
void allocBuffer(BYTE **buffer, uint32_t size);
void freeBuffer (BYTE **buffer               );

// check function return code
void checkResult(char *funcName, uint32_t result);

// build all templates from NIST14 database
void buildAllTemplates(char   *imageDir, char *templateDir    , char *license_file);

// check all templates from NIST14 database
void checkAllTemplates(char *templateDir,                       char *license_file);

// match all templates from NIST14 database
void matchAllTemplates(char *templateDir, char *resultFilePath, char *license_file);


#endif // TEST_TECH5_GALLERYMATCHER_SERVERE_H_