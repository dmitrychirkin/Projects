#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#include "test_Tech5_GalleryMatcher_ServerE.h"
#include "checkTime.h"
#include "fileUtl.h"
#include "sfsDef.h"
#include "NIST14_test.h"
#include "calcCMC.h"



void freeMatcher(Matcher *&matcher)
{
  if (matcher) Matcher::cancel(matcher), matcher = NULL;
}

void initMatcher(Matcher *&matcher, char *license_file)
{
   freeMatcher(matcher);

   matcher = Matcher::create();
   if (!matcher)
         throw "Cannot create Matcher object";
   if (!matcher->initLicense (license_file))
      throw "Wrong license";
}

void freeTemplateBuffers(BYTE **&templBuffer)
{
   if (!templBuffer)
      return;
   for(uint32_t i = 0; i < 10; i++)
      freeBuffer(&templBuffer[i]);
   delete [] templBuffer, templBuffer = NULL;
}

void allocTemplateBuffers(BYTE **&templBuffer)
{
   freeTemplateBuffers(templBuffer);

   templBuffer = new BYTE* [10];
   if (!templBuffer)
      throw "Cannot allocate array of templBuffer";
   memset(templBuffer, 0, sizeof(templBuffer[0]) * 10);

   for(uint32_t i = 0; i < 10; i++)
      allocBuffer (&templBuffer[i], MAX_TEMPLATE_SIZE);
}

void freeTpTemplates(TpTemplate *&tpTemplates)
{
   if (tpTemplates) delete [] tpTemplates, tpTemplates = NULL;
}

void allocTpTemplates(TpTemplate *&tpTemplates, uint64_t gallerySize)
{
   freeTpTemplates(tpTemplates);

   tpTemplates = new TpTemplate [gallerySize];
   if (!tpTemplates)
      throw "Cannot allocate array of templBuffer";
   memset(tpTemplates, 0, sizeof(tpTemplates[0]) * gallerySize);
}

void loadRecord(char *templateDir, Matcher *matcher, BYTE **templateBuffer, vector<TpTemplate*> &gallery, uint64_t regNum, TpTemplate &tpTemplate)
{
   char templatePath[MAX_PATH], msg[1024];
   for(int finger = 0; finger < 10; finger++)
   {
      NIST14_getTemplatePath (templateDir, templatePath, regNum, finger);
      size_t size = MAX_TEMPLATE_SIZE;
      if (readFile (templatePath, templateBuffer[finger], &size) != FU_OK)
      {
         sprintf (msg, "Cannot read %s file", templatePath);
         throw msg;
      }
      // allocate memory for templates, and fill tpTemplate
      allocBuffer(&tpTemplate.templ[finger], (uint32_t)size);
      memcpy(tpTemplate.templ[finger], templateBuffer[finger], size);
   }
   gallery.push_back (&tpTemplate);
   string id = uint64ToString(regNum);
   uint32_t result = matcher->insertRecord (id, tpTemplate);
   // check delete
   //result = matcher->deleteRecord (id);
   //result = matcher->insertRecord (id, tpTemplate);
   // insert double
   //result = matcher->insertRecord (id, tpTemplate);
   if (result != SUCCESS)
      throw result;
}


void loadAll(char *templateDir, Matcher *matcher, BYTE **templateBuffer, vector<TpTemplate*> &gallery, TpTemplate *tpTemplates)
{
   printf ("\nStart loading templates\n\n");
   TpTemplate tpTemplate;
   
   uint64_t dbSize = NIST14_getDbSize();
   for(uint64_t regNum = 0; regNum < dbSize; regNum++)
      loadRecord(templateDir, matcher, templateBuffer, gallery, regNum, tpTemplates[regNum]);
   
   printf ("\nAll templates loaded successfully\n\n");
}

void freeGallery(vector <TpTemplate*> &gallery)
{
   vector <TpTemplate*>::iterator p    = gallery.begin(); 
   vector <TpTemplate*>::iterator pEnd = gallery.end  (); 
   TpTemplate *tpTemplate = NULL;
   for(; p != pEnd; p++)
   {
      if (!(tpTemplate = *p))
         continue;
      for(int finger = 0; finger < 10; finger++)
         if (tpTemplate->templ[finger]) delete [] tpTemplate->templ[finger], tpTemplate->templ[finger] = NULL;
   }
   gallery.clear();
}

void reportSpeedAndParamters(FILE *log, uint64_t dbSize, Timer &tm, MatchingParameters &matchingParameters)
{
   char msg[1024];
   sprintf (msg, "\nMatching parameters:\nSpeed = %d MaxAngle = %d MaxAngleThumb\n\n",  matchingParameters.searchSpeed   , 
                                                                                        matchingParameters.maxAngle      , 
                                                                                        matchingParameters.maxAngleThumbs);
   printf  (     "%s", msg);
   fprintf (log, "%s", msg);


   sprintf (msg, "\nAverange matching speed = %f thousands tp/sec\n\n", (float)dbSize * dbSize / tm.elapsed_sec() / 1000);
   printf  (     "%s", msg);
   fprintf (log, "%s", msg);
}


void match_all(Matcher *matcher, vector<TpTemplate*> &gallery, char *resultFilePath)
{
   printf ("Start matching\n");
   FILE *log = fopen(resultFilePath, "w");
   if (!log)
      throw "Cannot open log file for writing";
   MatchingParameters matchingParameters;
   matchingParameters.searchSpeed = 3;
   matchingParameters.maxAngle = matchingParameters.maxAngleThumbs = 50;
   std::vector<candidates_string>  candidate_list;
   int rlSize = 10;
   int placeArray[CMC_SIZE], placeMoreRlSize = 0; 
   memset(placeArray, 0, sizeof(placeArray));
   
   Timer tm;
   tm.start();
   uint64_t dbSize = NIST14_getDbSize();
   for(uint64_t probeRegNum = 0; probeRegNum < dbSize; probeRegNum++)
   {
      // do identification
      matcher->identify_record (matchingParameters, *gallery[probeRegNum], 0, rlSize,  candidate_list);
      // report result
      calcCMC (log, probeRegNum, candidate_list, placeArray, placeMoreRlSize, NIST14_isGenuine, NIST14_getNumGenuine, 
                                                                     NIST14_fillNumGenuine, NIST14_getTpName, rlSize);
   }
   // report summarized results
   reportCmc (log, placeArray, placeMoreRlSize, rlSize);
   reportSpeedAndParamters(log, dbSize, tm, matchingParameters);

   if (log) fclose(log), log = NULL;

   printf ("\nMatching finished seccessfully\n\n");
}

void prepareBadGuyRecord(BYTE **templateBuffer, TpTemplate &tpTemplate)
{
   char templatePath[MAX_PATH], msg[1024];
   for(int finger = 0; finger < 10; finger++)
   {
      sprintf (templatePath, "../../test/temp1/1/%d.tpl", finger + 1);
      size_t size = MAX_TEMPLATE_SIZE;
      if (readFile (templatePath, templateBuffer[finger], &size) != FU_OK)
      {
         sprintf (msg, "Cannot read %s file", templatePath);
         throw msg;
      }
      // allocate memory for templates, and fill tpTemplate
      allocBuffer(&tpTemplate.templ[finger], (uint32_t)size);
      memcpy(tpTemplate.templ[finger], templateBuffer[finger], size);
   }
}

void releaseTpTemplate(TpTemplate &tpTemplate)
{
   for(int finger = 0; finger < 10; finger++)
      if (tpTemplate.templ[finger]) delete [] tpTemplate.templ[finger], tpTemplate.templ[finger] = NULL;
}

void badGuyIdentify(Matcher *matcher, BYTE ** templateBuffer)
{
   printf ("Identify the record of bad guy who cause the moving to new version in a rush\n");
   
   TpTemplate badTp;
   prepareBadGuyRecord(templateBuffer, badTp);

   std::vector<candidates_string>  candidate_list;
   int rlSize = 10;
   MatchingParameters matchingParameters;
   matchingParameters.searchSpeed = 3;
   matchingParameters.maxAngle = matchingParameters.maxAngleThumbs = 50;

   matcher->identify_record (matchingParameters, badTp, 0, rlSize,  candidate_list);

   // release memory fo BadTp
   releaseTpTemplate (badTp);

   int realRlSize = (int)candidate_list.size();
   if (!realRlSize)
   {
      printf ("nothing match found for this bad guy, but we don't even expected\n");
      printf ("the most wonderful thing is the system is not crasing anymore!\n\n");
      return;
   }
   char tpName[MAX_PATH];
   printf ("Candidates:\n");
   for(int i = 0; i < realRlSize; i++)
   {
      uint64_t regNum = getIdFromString (candidate_list[i].uid.c_str());  
      NIST14_getTpName (tpName, regNum);
      printf ("place %d: %-15s %6.4f\n", i + 1, tpName, candidate_list[i].score);
   }
}



void matchAllTemplates(char *templateDir, char *resultFilePath, char *license_file)
{
   printf ("Matching test\n");

   Matcher     *matcher          = NULL;
   BYTE       **templateBuffer   = NULL;
   TpTemplate  *tpTemplates      = NULL; 
   uint64_t dbSize = NIST14_getDbSize();
   vector<TpTemplate*> gallery;
   try
   {
      if (!templateDir || !resultFilePath)
	      throw "Wrong directory or output file name";
      // do intialization
      initMatcher (matcher, license_file);
      allocTemplateBuffers(templateBuffer);
      allocTpTemplates(tpTemplates, dbSize);

      // upload db
      loadAll(templateDir, matcher, templateBuffer, gallery, tpTemplates);

      // do matching
      match_all(matcher, gallery, resultFilePath);

      // identify the record of bad guy who cause moving to new version in a rush
      badGuyIdentify(matcher, templateBuffer);
   }
   catch(uint32_t &e)
   {
      printf ("error code = %d\n", e);
   }
   catch(char *e)
   {
      printf ("%s\n", e);
   }
   // free memory
   freeMatcher         (matcher       );
   freeTemplateBuffers (templateBuffer);
   freeGallery         (gallery       );
   freeTpTemplates     (tpTemplates   );

   printf ("Press any key to continue\n");
   getchar();
}	



