#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#include "test_Tech5_GalleryMatcher_ServerE.h"
#include "checkTime.h"
#include "fileUtl.h"
#include "NIST14_test.h"


#define MAX_IMAGE_SIZE  1024 * 1024


void freeTemplateCreatorArray(uint32_t numProc, TemplateCreator **&tc)
{
   if (!tc)
      return ;
   for(uint32_t i = 0; i < numProc; i++)
      if (tc[i]) TemplateCreator::cancel(tc[i]), tc[i] = NULL;
   delete [] tc, tc = NULL;
}

void initTemplateCreatorArray(uint32_t numProc, TemplateCreator **&tc, char *license_file)
{
   freeTemplateCreatorArray(numProc, tc);

   tc = new TemplateCreator* [numProc];
   if (!tc)
      throw "Cannot create array of TemplateCreator";
   for(uint32_t i = 0; i < numProc; i++)
   {
      tc[i] = TemplateCreator::create();
      if (!tc[i])
         throw "Cannot create TemplateCreator object";
      if (!tc[i]->initLicense (license_file))
         throw "wrong license";
   }
}

void freeImageBuffers(uint32_t numProc, BYTE **&imageBuffer)
{
   if (!imageBuffer)
      return;
   for(uint32_t i = 0; i < numProc; i++)
      freeBuffer(&imageBuffer[i]);
   delete [] imageBuffer, imageBuffer = NULL;
}

void allocImageBuffers(uint32_t numProc, BYTE **&imageBuffer)
{
   freeImageBuffers(numProc, imageBuffer);

   imageBuffer = new BYTE* [numProc];
   if (!imageBuffer)
      throw "Cannot allocate array of imageBuffer";
   memset(imageBuffer, 0, sizeof(imageBuffer[0]) * numProc);

   for(uint32_t i = 0; i < numProc; i++)
      allocBuffer (&imageBuffer[i], MAX_IMAGE_SIZE);
}

void createTpTemplate(char *imagePath, char *templatePath, TemplateCreator *tc, BYTE *imageBuffer, int finger)
{
   char msg[1024];
   BYTE *fpTemplate = NULL;
   size_t size = MAX_IMAGE_SIZE;
   Timer tm;
   tm.start();
   if (readFile (imagePath, imageBuffer, &size) != FU_OK)
   {
      sprintf (msg, "Cannot read %s file", imagePath);
      throw msg;
   }
   WsqImage wsq;
   wsq.m_finger = (FINGERS)(finger + 1);
   wsq.m_wsq    = imageBuffer;
   wsq.m_size   = (uint32_t)size;
   uint32_t templateSize = 0;
   uint8_t quality = 0;
   checkResult("createTemplate", tc->createTemplate (wsq, templateSize, quality)); 
   allocBuffer(&fpTemplate, templateSize);
   tc->getTemplate    (fpTemplate); 

   if (saveFile (templatePath, fpTemplate, templateSize) != FU_OK)      
   {
      sprintf (msg, "Cannot save %s file", templatePath);
      throw msg;
   }
   freeBuffer(&fpTemplate);
   printf ("template for image %s: OK time = %6.2f sec\n", imagePath, tm.elapsed_sec());
}


void createTpTemplates(char *imageDir, char *templateDir, uint32_t regNum, TemplateCreator **tc, BYTE **imageBuffer, int threadNum)
{
   char imagePath[MAX_PATH], templatePath[MAX_PATH];
   for(uint32_t finger = 0; finger < 10; finger++)
   {
      NIST14_getImagePath    (imageDir   , imagePath   , regNum, finger);
      NIST14_getTemplatePath (templateDir, templatePath, regNum, finger);
      createTpTemplate(imagePath, templatePath, tc[threadNum], imageBuffer[threadNum], finger);
   }
}


void buildAllTemplates(char *imageDir, char *templateDir, char *license_file)
{
   printf ("\nStart building templates\n");

   TemplateCreator **tc           = NULL;
   BYTE            **imageBuffer  = NULL;
   int numProc = omp_get_num_procs();
   Timer tm;
   int dbSize = (int)NIST14_getDbSize();
   try
   {
    	if (!imageDir|| !templateDir)
	   	throw "Wrong directory name";
      // do intialization
      initTemplateCreatorArray(numProc, tc, license_file);
      allocImageBuffers(numProc, imageBuffer);

      // build all templates
      tm.start();
      #pragma omp parallel for num_threads(numProc)
      for(int i = 0; i < dbSize; i++)
      {
         int threadNum = omp_get_thread_num();
         createTpTemplates (imageDir, templateDir, i, tc, imageBuffer, threadNum);
      }
   }
   catch(uint32_t &e)
   {
      printf ("error code = %d\n", e);
   }
   catch(char *e)
   {
      printf ("%s\n", e);
   }
   // free memory
   freeTemplateCreatorArray (numProc, tc         );
   freeImageBuffers         (numProc, imageBuffer);

   printf ("\nFinish building templates.\n");
   printf ("Averange build template time (programm works in %d threads) = %4.2f sec\n\n",  numProc, (float)tm.elapsed_sec() / 10.0 / dbSize);
   printf ("Press any key to continue\n");
   getchar();
}	



