#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#include "test_Tech5_GalleryMatcher_ServerE.h"
#include "checkTime.h"
#include "fileUtl.h"
#include "sfsDef.h"
#include "NIST14_test.h"



void freeCheckerArray(uint32_t numProc, FpTemplateChecker **&checker)
{
   if (!checker)
      return ;
   for(uint32_t i = 0; i < numProc; i++)
      if (checker[i]) FpTemplateChecker::cancel(checker[i]), checker[i] = NULL;
   delete [] checker, checker = NULL;
}

void initCheckerArray(uint32_t numProc, FpTemplateChecker **&checker)
{
   freeCheckerArray(numProc, checker);

   checker = new FpTemplateChecker* [numProc];
   if (!checker)
      throw "Cannot create array of FpTemplateChecker";
   for(uint32_t i = 0; i < numProc; i++)
   {
      checker[i] = FpTemplateChecker::create();
      if (!checker[i])
         throw "Cannot create FpTemplateChecker object";
   }
}

void freeTemplateBuffers(uint32_t numProc, BYTE **&templBuffer)
{
   if (!templBuffer)
      return;
   for(uint32_t i = 0; i < numProc; i++)
      freeBuffer(&templBuffer[i]);
   delete [] templBuffer, templBuffer = NULL;
}

void allocTemplateBuffers(uint32_t numProc, BYTE **&templBuffer)
{
   freeTemplateBuffers(numProc, templBuffer);

   templBuffer = new BYTE* [numProc];
   if (!templBuffer)
      throw "Cannot allocate array of templBuffer";
   memset(templBuffer, 0, sizeof(templBuffer[0]) * numProc);

   for(uint32_t i = 0; i < numProc; i++)
      allocBuffer (&templBuffer[i], MAX_TEMPLATE_SIZE);
}

bool checkTemplate(char *templatePath, FpTemplateChecker *checker, BYTE *templateBuffer)
{
   char msg[1024];
   size_t size = MAX_TEMPLATE_SIZE;
   if (readFile (templatePath, templateBuffer, &size) != FU_OK)
   {
      sprintf (msg, "Cannot read %s file", templatePath);
      throw msg;
   }
   bool result = checker->check (templateBuffer);
   printf ("check template %s: %s\n", templatePath, result ? "OK" : "Fail");
   return result;
}


void checkAllTemplates(char *templateDir, char *license_file)
{
   printf ("Start checking templates\n");

   FpTemplateChecker **checker         = NULL;
   BYTE              **templateBuffer  = NULL;
   int numProc = omp_get_num_procs();
   Timer tm;
   int dbSize = (int)NIST14_getDbSize();
   uint32_t *faultCount = NULL, totalFaultCount = 0;
   try
   {
    	if (!templateDir)
	   	throw "Wrong directory name";
      faultCount = new uint32_t [numProc];
      if (!faultCount)
         throw LOW_MEMORY;
      memset (faultCount, 0, sizeof(faultCount[0]) * numProc);
      // do initialization
      initCheckerArray(numProc, checker);
      allocTemplateBuffers(numProc, templateBuffer);

      // check all templates
      char templatePath[MAX_PATH];
      tm.start();
      #pragma omp parallel for num_threads(numProc) private (templatePath)
      for(int regNum = 0; regNum < dbSize; regNum++)
         for(int finger = 0; finger < 10; finger++)
         {
            int threadNum = omp_get_thread_num();
            NIST14_getTemplatePath (templateDir, templatePath, regNum, finger);
            if (!checkTemplate (templatePath, checker[threadNum], templateBuffer[threadNum])) 
               faultCount[threadNum] ++;
         }
         for(int i = 0; i < numProc; i++)
            totalFaultCount += faultCount[i];
   }
   catch(uint32_t &e)
   {
      printf ("error code = %d\n", e);
   }
   catch(char *e)
   {
      printf ("%s\n", e);
   }
   // free memory
   freeCheckerArray     (numProc, checker       );
   freeTemplateBuffers  (numProc, templateBuffer);
   if (faultCount) delete [] faultCount, faultCount = NULL;

   printf ("\nFinish checking templates. %d fault templates found\n", totalFaultCount);
   printf ("Averange time of checking one template (programm works in %d threads) = %4.2f msec\n\n", numProc, (float)tm.elapsed_msec() / 10.0 / dbSize);
   printf ("Press any key to continue\n");
   getchar();
}	



