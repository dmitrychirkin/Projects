/*
   constants and function for cooperation accelerator and final mathching
*/

#ifndef CHOOSE_FINAL_PARAM_H_
#define CHOOSE_FINAL_PARAM_H_

// accel score when found minutiae will be passed to final matching
static const int ACCEL_RELIABLE_SIM             =  1000; 
// if accel search speed more than this value and accel score < ACCEL_RELIABLE_SIM we don't do a final matching  
static const int MAX_SPEED_WITHOUT_PICK_UP      =     3;
// maximum value of 'numStep' in 'doStepCompareTP' function
static const int MAX_STEPS                      =     2;

static inline unsigned int getFirstFinalSpeed (unsigned int accelSpeed)
{
   switch(accelSpeed)
   {
   case 2:
      return 1;
   case 1:
   case 0:
      return 0;
   default:
      return 2;
   }
}
static inline unsigned int getSecondFinalSpeed (unsigned int accelSpeed)
{
   switch(accelSpeed)
   {
   case 2:
   case 1:
   case 0:
      return 0;
   default:
      return 2;
   }
}




#endif // CHOOSE_FINAL_PARAM_H_
