
#include <stdlib.h>
#include <assert.h>
#include <time.h>
//#include <intrin.h>

#include "accel.h"
#include "accelData.h"
#include "calcScore.h"
#include "accelAdjust.h"
#include "speedParam.h"
#include "getFusedScore.h"
#include "adjustParam.h"
#include "TpAccel.h"
#include "correctSegmentationError.h"
#include "getFusedScore.h"
#include "accelMatchEx.h"
#include "chooseParam.h"
#include "sse_proxy.h"

//#define TIME_PROTECT    

//using namespace LDS;
using namespace ESK;

//long long g_accelPairNum = 0;
//long long g_qualityP = 0;
//long long g_qualityG = 0;
//long long g_numFinger = 0;

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)



unsigned int getMaximOneFingerAccelSize()
{
   AllAccel allAccel;
   allAccel.numMinutiae = (BYTE)MAX_ACCEL_MIN;
   allAccel.numAccel = (BYTE)MAX_ACCEL;
   return getAccelDataSize(&allAccel);
}

unsigned int getMaximOneFingerFullAccelSize()
{
   AllAccel allAccel;
   allAccel.numMinutiae = (BYTE)MAX_ACCEL_MIN;
   allAccel.numAccel = (BYTE)MAX_ACCEL_MIN;
   return getAccelDataSize(&allAccel);
}

unsigned int getMaximumAccelSize(unsigned int numFingers)
{
   return getMaximOneFingerAccelSize() * numFingers + sizeof(TpAccelHeader);
}

int calcOneFingerAccel (void *accelHandle, BYTE *templ, BYTE *accel, DWORD *accelSize, 
                           unsigned int threadNum, BYTE *fullAccel = NULL)
{
   if (!accelHandle || !templ || !accel || !accelSize)
      return SA_NULL_POINTER;
   templ += sizeof (TemplHeader);
   *accelSize = 0;
   AccelData *accelData = (AccelData*)accelHandle;
   if (!accelData->m_init)
      return SA_NOT_INITIALIZED;

   ThreadData* threadData = getThreadData (accelData, threadNum);
	if (!threadData->m_unwrap->verify (templ))
      return SA_UNPACK_ERR;
   ESK::twin_t numNest = threadData->m_unwrap->idnova (templ);
   ESK::twin_t numSing = threadData->m_unwrap->idmain(templ);
   if (numNest > MAX_UNPACKED_MINUTIAE || numSing > MAX_UNPACKED_SINGULAR)
      return SA_UNPACK_ERR;
   if (threadData->m_unwrap->denova (threadData->m_minutiae, templ) != numNest)
      return SA_UNPACK_ERR;
   if (threadData->m_unwrap->denest (threadData->m_link, threadData->m_minutiae, numNest, templ) != numNest)
      return SA_UNPACK_ERR;
   numSing          = threadData->m_unwrap->demain (threadData->m_sing, templ);
   BYTE quality     = threadData->m_unwrap->qualit (templ);
   BYTE patternType = threadData->m_unwrap->immask (templ);
 	WORD width   = threadData->m_unwrap->size_x(templ);
   WORD height  = threadData->m_unwrap->size_y(templ);
   if (!threadData->m_unwrap->dearea (threadData->m_area, templ))
      return SA_UNPACK_ERR;

   // calc accelerators for this fingerprint
   calcAccel_base (accelData->m_accelTables, threadData->m_minutiae, threadData->m_link, numNest, threadData->m_sing, numSing, threadData->m_area, width, height, accelSize, 
      accel, quality, patternType, fullAccel);
   if (*accelSize > (fullAccel ? getMaximOneFingerFullAccelSize() : getMaximOneFingerAccelSize()))
      return SA_ACCEL_CALC_ERR;
 
   return SA_OK;
}

int calcAccel (void *accelHandle, TpTemplate &templ, BYTE *tpAccel, DWORD &accelSize, PersonalData *personalData)
{
   int result = SA_OK, rs = SA_OK;
   if (!accelHandle || !tpAccel)
      return SA_NULL_POINTER;
 
   accelSize = 0;
   // calculate accelerator for each finger
   AccelData *accelData = (AccelData*)accelHandle;
   DWORD accelSizeOneFinger[10];
   memset(accelSizeOneFinger, 0, sizeof(accelSizeOneFinger));
   unsigned int threadNum = 0;
#pragma omp parallel for private (rs, threadNum) num_threads (accelData->m_numThreads)
   for(int finger = 0; finger < 10; finger++)
   {
      if (!templ.templ[finger])
         continue;
      threadNum = getThreadNum (accelData);
      rs = calcOneFingerAccel (accelHandle, templ.templ[finger], accelData->m_accelBuffer[finger], 
                                 &accelSizeOneFinger[finger], threadNum); 
      if (rs != SA_OK)
         result = rs;
   }
   //if (result != SA_OK)   // ���� �����, �.�. ����� �� ������� ��� ���� � �������, ����� �� ������� ����������� ���� �� ���� �����, � 
   //   return result;      // ��������� � �����.    

   // copy data to tpAccel
   TpAccelHeader *header = (TpAccelHeader*)tpAccel;
   header->clear(); 
   if (personalData)
      memcpy(&header->m_personalData,  personalData, sizeof(PersonalData));
   else       // copy default PersonalData
   {
      PersonalData a_personalData;
      memcpy(&header->m_personalData,  &a_personalData, sizeof(PersonalData));
   }
   BYTE *pos = tpAccel + sizeof(TpAccelHeader);
   header->m_size = sizeof(TpAccelHeader);
   for (int finger = 0; finger < 10; finger++)
   {
      if (!accelSizeOneFinger[finger])
         continue;
      header->m_accelOffset[finger] = (WORD)(pos - tpAccel);
      memcpy(pos, accelData->m_accelBuffer[finger], accelSizeOneFinger[finger]);
      pos            += accelSizeOneFinger[finger];
      header->m_size +=  accelSizeOneFinger[finger];
   }
   accelSize = header->m_size;
	if (accelSize == sizeof(TpAccelHeader))
	{
		accelSize = 0;
		return SA_NO_FINGERS;
	}
   if (accelSize > getMaximumAccelSize())
      return SA_ACCEL_CALC_ERR;

   return SA_OK;
}

//BYTE getModifiedQuality (AllAccel *allAccel)
//{
//   assert (allAccel);
//   BYTE quality = allAccel->quality;
//   if (allAccel->numRelMin < NUM_REL_POINTS) 
//      quality = BYTE(quality * allAccel->numRelMin   / NUM_REL_POINTS);
//
//   return quality;
//}


inline bool addTriplet(Triplet *t, BYTE i, BYTE j, WORD sim, int &count)
{
   if (count > MAX_TRIPLETS - 1)
      return false;
   t[count].i     = i;
   t[count].j     = j;
   t[count].sim   = sim;
   count++;
   return true;
}


inline bool compareGroupNestsByAccel(unsigned int fill, Triplet *t, unsigned int minSim, int &count, 
                                     int minIndexP, int maxIndexP, int minIndexG, int maxIndexG, 
                                     Accel *accelP, Accel *accelG)//, 
                                     //BYTE *accelSignP, BYTE *accelSignG, BYTE minQ)
{
   Accel *pAccelP      = &accelP    [minIndexP],  *pAccelG     = NULL;
//   BYTE *pAccelSignP   = &accelSignP[minIndexP],  *pAccelSignG = NULL;
   WORD sim = 0;
   for(int i = minIndexP; i < maxIndexP; i++, pAccelP++)//, pAccelSignP++)
   {
      pAccelG     = &accelG    [minIndexG];
//      pAccelSignG = &accelSignG[minIndexG];
      for(int j = minIndexG; j < maxIndexG; j++, pAccelG++)//, pAccelSignG++)
      {
         //if (pAccelP->accel.m128i_i8[0] != pAccelG->accel.m128i_i8[0]
         //&&  pAccelP->accel.m128i_i8[1] != pAccelG->accel.m128i_i8[1] )
         //   continue;
         //if (minQ > 60 && abs (*pAccelSignP - *pAccelSignG) > 3)
         //   continue;
         sim = getAccelSim  (pAccelP, pAccelG);
         if (sim < minSim)
            continue;
         if (!addTriplet(t, i, j, sim, count))
           return false;                           
      }
   }
   return true;
}


inline bool compareNestsByAccel (unsigned int fill, Triplet *t, unsigned int minSim, 
                                int numP_min, int numP_max, int numG_min, int numG_max, 
                                Accel *accelP, Accel *accelG, int &count)//, 
                                //BYTE *accelSignP, BYTE *accelSignG, BYTE minQ)
{
   return compareGroupNestsByAccel (fill, t, minSim, count, numP_min, numP_max, numG_min, numG_max, accelP, accelG)//, accelSignP, accelSignG, minQ)
      &&  compareGroupNestsByAccel (fill, t, minSim, count,        0, numP_min, numG_min, numG_max, accelP, accelG)//, accelSignP, accelSignG, minQ)
      &&  compareGroupNestsByAccel (fill, t, minSim, count, numP_min, numP_max,        0, numG_min, accelP, accelG);//, accelSignP, accelSignG, minQ);
}


int compareTriplets( const void *triplet1, const void *triplet2 )
{
   return (int)(((Triplet*)triplet2)->sim) - (int)(((Triplet*)triplet1)->sim);
}

inline bool compareGroupNestsByAccelAnchor (Triplet *t, WORD minSim[17], int &count, 
                                         int numP, int numG, Accel *accelG, 
                                         AnchorAccel *anchorAccelP, BYTE *fillG, BYTE *dist2AnchorG)
{
   WORD sim = 0;
   BYTE fill_G = 0;
   int minDist = 0, maxDist = 0;
   int maxDistP = anchorAccelP[numP - 1].dist + 10;
   Accel *accel_G = NULL;
   for(int i = 0; i < numG; i++)
   {
      if (dist2AnchorG[i] > maxDistP || dist2AnchorG[i] < 10)
         continue;
      fill_G = fillG[i];
      accel_G = &accelG[i];
      minDist = dist2AnchorG[i] - 15;
      maxDist = dist2AnchorG[i] + 15;
      int j = 0;
      while (anchorAccelP[j].dist < minDist && j < numP)
         j++;
      for(; j < numP; j++)
      {
         if (anchorAccelP[j].dist > maxDist) break;
         sim = getAccelSim  (anchorAccelP[j].accel, accel_G);
         if (sim < minSim[minAB(anchorAccelP[j].fill, fill_G)])
            continue;
         if (!addTriplet(t, j, i, sim, count))
           return false;                           
      }
   }
   return true;
}


void compMainNests(AccelData *accelData, Triplet *t, AccelPair *accelPair, unsigned int *minSim, 
                          int numP, int numG, Accel *accelP, Accel *accelG, 
                          BYTE  *accelNumP, BYTE  *accelNumG,
                          MinutiaeData *minP, MinutiaeData *minG, int angleTol, 
                          AllAccel *allAccelP, AllAccel *allAccelG, unsigned int minFill)
{
   assert(accelData && accelPair && accelP && accelG && accelNumP && accelNumG && minP && minG && allAccelP && allAccelG);
   int count = 0;
   int numP_min = 0, numG_min = 0, numP_max = 0, numG_max = 0;

   //if (useAnchor)
   //   compareGroupNestsByAccelAnchor (t, minSim, count, numP, numG, accelG, anchorAccelP, fillG, dist2AnchorG);  
   //else
   {
      unsigned int fillThreshold = minFill >= 4 ? minFill : 4;
      for (unsigned int fill = 16; fill >= fillThreshold; fill--)
      {
         numP_max = allAccelP->num_fill_n[fill - 4] < numP ? allAccelP->num_fill_n[fill - 4] : numP;
         numG_max = allAccelG->num_fill_n[fill - 4] < numG ? allAccelG->num_fill_n[fill - 4] : numG;
         if (!compareNestsByAccel(fill, t, minSim[fill], numP_min, numP_max, numG_min, numG_max, accelP, accelG, count))//, accelSignP, accelSignG, minQ))
            break;
         numP_min = numP_max;
         numG_min = numG_max;
      }
   }
   // sort triplets by accelSim
   qsort((void*)t, count, sizeof(Triplet), compareTriplets);
   // take only top of triplets array
   if (count > MAX_SORTED_TRIPLETS)
      count = MAX_SORTED_TRIPLETS;

   // check choosen triplets by minutiae angle
   int np = 0, ng = 0;
   for(int i = 0; i < count; i++)
   {
//      np = useAnchor ? anchorAccelP[t[i].i].num : accelNumP[t[i].i];
      np = accelNumP[t[i].i];
      ng = accelNumG[t[i].j];
      if (angleTol < 30 && !checkMinutiaeAngle(accelData, minP[np].a, minG[ng].a, angleTol))
         continue;
      if (!accelPair->add (np, ng))  
         return;                      // reach maximum size
   }
}

bool checkOneFingerAccel(BYTE *accel, bool fullCheck)
{
   if (!accel) return false;
   AllAccel *header = (AllAccel*)accel;
   if (header->numAccel > header->numMinutiae)
      return false;
   if (!fullCheck)
      return true;

   if (
      header->numMinutiae > MAX_ACCEL_MIN                ||
      header->numAccel > MAX_ACCEL                       ||
      header->quality > 100                              ||
      header->num_fill_n[0]   > header->numAccel       ||
      header->num_fill_n[1]   > header->num_fill_n[ 0] ||
      header->num_fill_n[2]   > header->num_fill_n[ 1] ||
      header->num_fill_n[3]   > header->num_fill_n[ 2] ||
      header->num_fill_n[4]   > header->num_fill_n[ 3] ||
      header->num_fill_n[5]   > header->num_fill_n[ 4] ||
      header->num_fill_n[6]   > header->num_fill_n[ 5] ||
      header->num_fill_n[7]   > header->num_fill_n[ 6] ||
      header->num_fill_n[8]   > header->num_fill_n[ 7] ||
      header->num_fill_n[9]   > header->num_fill_n[ 8] ||
      header->num_fill_n[10]  > header->num_fill_n[ 9] ||
      header->num_fill_n[11]  > header->num_fill_n[10] ||
      header->num_fill_n[12]  > header->num_fill_n[11]
   ) return false;

   // check accelNum array
   BYTE *accelNum = assignAcceleratorNum (accel, header);
   BYTE numAccel = header->numAccel;
   BYTE numMin = header->numMinutiae;
   for(BYTE i = 0; i < numAccel; i++)
      if (accelNum[i] >= numMin)
         return false;
   // check minutiae data
   MinutiaeData* min = assignMinutiae (accel, header);
   for(BYTE i = 0; i < numMin; i++)
   {
      if (min[i].a >= 90) return false;
   }

   return true;
}

bool checkAccel(BYTE *accel, bool fullCheck)
{
   TpAccel tpAccel;
   if (!tpAccel.readFromBuffer(accel))
      return false;
//   int count = 0;
   for(int finger = 0; finger < 10; finger++)
   {
      if (!tpAccel.m_accel[finger])
         continue;
      if (!checkOneFingerAccel(tpAccel.m_accel[finger], fullCheck))
         return false;
//      count++;
   }
   return true;
}


   inline int compAccel (AccelData *accelData, AccelSearchParam &param, unsigned int *speedParam, int probeFinger, BYTE *accelG_buf, 
                     int &similarity, SortedAccel *sortedAccelG, AccelPair **localGroup, 
                     unsigned int threadNum, AccelPair *bestGroup = NULL)
   {
      similarity = 0;
      if (!checkOneFingerAccel(accelG_buf, false))
         return SA_ACCEL_CORRUPT;      
      // get accelerators
      AllAccel *allAccelG    = assignHeader         (accelG_buf);
      Accel    *accelG       = assignAccelerator    (accelG_buf);
   //   BYTE     *accelSignG   = assignAcceleratorSign (accelG_buf, allAccelG);
   //   MainAccel *mainAccelG  = assignMainAccel      (accelG_buf, allAccelG);
      BYTE  *accelNumG       = assignAcceleratorNum (accelG_buf, allAccelG);
   //   BYTE  *dist2AnchorG    = assignDist2Anchor    (accelG_buf, allAccelG);
      MinutiaeData *minG     = assignMinutiae       (accelG_buf, allAccelG);
      assert (accelData->m_allAccelP[probeFinger]);
      AllAccel *allAccelP = accelData->m_allAccelP[probeFinger];
   //   int minQ = minAB(allAccelP->quality, allAccelG->quality);
      BYTE minPointInLocalGroup_1st = 0, minPointInLocalGroup_2nd = 0, minFill = 0;
      unsigned int *minSim = NULL; 
      unsigned int numP   = chooseNumAccelForCompareTT (speedParam, allAccelP);
      unsigned int numG   = chooseNumAccelForCompareTT (speedParam, allAccelG);
      chooseParam (accelData, speedParam, allAccelP, allAccelG, allAccelP->numMinutiae, allAccelG->numMinutiae, 
                     minSim, minPointInLocalGroup_1st, minPointInLocalGroup_2nd, minFill);
      // compare accelerators
      ThreadData* threadData = getThreadData (accelData, threadNum);
      AccelPair *accelPair   = &threadData->m_accelPair;
      Triplet *t             = threadData->m_t;
      accelPair->clear();
      accelPair->m_minP = accelData->m_minP[probeFinger];
      accelPair->m_minG = minG;
      int angleTol = (probeFinger == 0 || probeFinger == 5) ? (param.maxAngleThumbs + 2) / 4 : (param.maxAngle + 2) / 4;

      //BYTE  fillG [MAX_ACCEL_MIN]; 
      //bool  useAnchor = false;     
      //if (allAccelP->anchorX >= 0 && allAccelG->anchorX >= 0) // there are anchor points
      //{
      //   getAccelFill (allAccelG, fillG);
      //   useAnchor = true;
      //}
   //useAnchor = false;     
      compMainNests (accelData, t, accelPair, minSim, numP, numG, accelData->m_accelP[probeFinger], 
               accelG, //accelData->m_mainAccelP[probeFinger], mainAccelG, 
               accelData->m_accelNumP[probeFinger], accelNumG, accelData->m_minP[probeFinger], 
               minG, angleTol, accelData->m_allAccelP[probeFinger], allAccelG, minFill);
   //            , accelData->m_accelSignP[probeFinger], accelSignG, minAB (allAccelP->quality, allAccelG->quality));//, 
   //            useAnchor, accelData->m_anchorAccelP[probeFinger], fillG, dist2AnchorG);
      if (!accelPair->m_num)
         return SA_OK; 

      // build groups
      int maxGroups = accelPair->m_num;
      if (maxGroups > MAX_LOCAL_GROUP_1ST)
         maxGroups = MAX_LOCAL_GROUP_1ST;
   
      int kDist = param.searchSpeed == 0 ? 1 : 2;
      for(int i = 0; i < maxGroups; i++) 
		   localGroup[i]->init(accelData->m_minP[probeFinger], minG, accelData->m_accelTables, kDist);

      int numMinutiaeG = allAccelG->numMinutiae;
      getSortedAccelerator(allAccelG, accelG, accelNumG, /*directionG, */sortedAccelG);
   //   int posDif = 0, angleDif = 0;
   //   int numExcludeG = 0;
   //   int mainGroupSize = 0;
   //return SA_OK;
      similarity = buildGroup(accelData, probeFinger, param, accelPair, sortedAccelG, minG, 
                              numMinutiaeG, localGroup, minPointInLocalGroup_1st, minPointInLocalGroup_2nd, 
                               allAccelG->quality, threadNum, bestGroup);
      return SA_OK;
   }

int loadProbeFinger (AccelData *accelData, BYTE *templ, int finger, unsigned int threadNum)
{
   assert (threadNum < accelData->m_numThreads && templ);
   assert (finger >= 0 && finger <= 9);

   int result = SA_OK;
   BYTE *accelP_buf = NULL;
   DWORD accelSize = 0;
   accelData->clearProbe(finger);
   accelData->m_probeAccel[finger] = NULL;
   if (!templ)
      return SA_NULL_TEMPLATE;

   ThreadData *threadData = &accelData->m_threadData[threadNum];
   BYTE *fpTempl = templ + sizeof (TemplHeader);
   result = threadData->m_unwrap->dearea (accelData->m_areaP[finger], fpTempl);
   if (!result)
   	return SA_WRONG_TEMPLATE;
   accelData->m_areaWidthP [finger] =  result        & 0xffff;
   accelData->m_areaHeightP[finger] = (result >> 16) & 0xffff;
   accelData->m_widthP     [finger] = threadData->m_unwrap->size_x (fpTempl);
   accelData->m_heighP     [finger] = threadData->m_unwrap->size_y (fpTempl);
   result = calcOneFingerAccel (accelData, templ, accelData->m_accelBuffer[finger], &accelSize, 
                                 threadNum, accelData->m_probeFullAccel[finger]);
   if (result != SA_OK)
      return result;
   accelData->m_probeAccel[finger] = accelData->m_accelBuffer[finger];
   accelP_buf = accelData->m_probeAccel[finger];
   bool rs = checkOneFingerAccel (accelP_buf, false);
   assert (rs);
   AllAccel *allAccelP = assignHeader (accelP_buf);
   accelData->m_allAccelP    [finger]  = allAccelP;
   accelData->m_accelP       [finger] = assignAccelerator     (accelP_buf);
//   accelData->m_accelSignP   [finger] = assignAcceleratorSign (accelP_buf, allAccelP);
//      accelData->m_mainAccelP   [finger] = assignMainAccel       (accelP_buf, accelData->m_allAccelP[finger]);
   accelData->m_accelNumP    [finger] = assignAcceleratorNum  (accelP_buf, allAccelP);
   accelData->m_minP         [finger] = assignMinutiae        (accelP_buf, allAccelP);
   //if (accelData->m_allAccelP[finger]->anchorX >= 0)
   //{
   //   BYTE *dist2AnchorP = assignDist2Anchor (accelP_buf, allAccelP);
   //   getAnchorSortedAccel (allAccelP, numP, accelData->m_accelP[finger], dist2AnchorP, 
   //                           accelData->m_accelNumP[finger], accelData->m_anchorAccelP[finger]);  
   //}
      
   getSortedAccelerator(accelData->m_allAccelP[finger], accelData->m_accelP[finger], accelData->m_accelNumP[finger], &accelData->m_sortedAccelP[finger]);
   return SA_OK;
}


int loadAccelTP (void *accelHandle, TpTemplate &probe, PersonalData *probePersonalData)
{
   if (!accelHandle)
      return SA_NULL_POINTER;
   AccelData *accelData = (AccelData*)accelHandle;
   if (!accelData->m_init)
      return SA_NOT_INITIALIZED;

   accelData->clearRl();
   accelData->clearProbe();
   if (probePersonalData)
      memcpy (&accelData->m_personalDataP, probePersonalData, sizeof(PersonalData));
   int result = SA_OK, rs = SA_OK, successCount = 0;
   unsigned int threadNum = 0;
#pragma omp parallel for private(rs, threadNum) num_threads (accelData->m_numThreads)
   for(int finger = 0; finger < 10; finger++)
   {
      if (!probe.templ[finger])
         continue;
      threadNum = getThreadNum (accelData);
      rs = loadProbeFinger (accelData, probe.templ[finger], finger, threadNum);
      if (rs == SA_OK) successCount++;
      else             result = rs;
   }
   // return success if at least one finger was loaded error otherwise
   if      (successCount   ) return SA_OK;
   else if (result != SA_OK) return result;
   else                      return SA_NO_FINGERS;
}

inline bool compPersonalData(AccelSearchParam &param, PersonalData *probePesonalData, PersonalData *galleryPersonalData)
{
   if (param.useSexFilter)
   {
      if (probePesonalData->m_sex == SEX_F && galleryPersonalData->m_sex == SEX_M) return false;
      if (probePesonalData->m_sex == SEX_M && galleryPersonalData->m_sex == SEX_F) return false;
   }
   if (param.useAgeFilter && probePesonalData->m_birthYear && galleryPersonalData->m_birthYear)
   {
      if ((unsigned int)abs((int)probePesonalData->m_birthYear - (int)galleryPersonalData->m_birthYear) > param.ageTolerance)
         return false;
   } 
   return true;
}

bool compareTpByPatterns (AccelData *accelData, TpAccel &galleryAccel)
{
   AllAccel *allAccelG = NULL;
   int numErrors = 0;
   for (int finger = 0; finger < 10; finger++)
   {
      allAccelG = assignHeader(galleryAccel.m_accel[finger]);
      if (!accelData->m_allAccelP[finger] || !allAccelG)
         continue;
      if (accelData->m_allAccelP[finger]->patternType == MAIN_ACCEL_UNKNOWN_TYPE || allAccelG->patternType == MAIN_ACCEL_UNKNOWN_TYPE)
         continue;
      if      (accelData->m_allAccelP[finger]->patternType == MAIN_ACCEL_RIGHT_LOOP && allAccelG->patternType == MAIN_ACCEL_LEFT_LOOP) 
         numErrors++;
      else if (accelData->m_allAccelP[finger]->patternType == MAIN_ACCEL_LEFT_LOOP && allAccelG->patternType == MAIN_ACCEL_RIGHT_LOOP) 
         numErrors++;
      //if (!(accelData->m_allAccelP[finger]->patternType & allAccelG->patternType))
      //   numErrors++;
   }
   return (numErrors < 1);
}



int compareAccelTP_ (void *accelHandle, AccelSearchParam &param, BYTE *galleryAccel, unsigned int threadNum, 
                     MatchResultTT &matchResultTT, bool saveCombineData)
{
   matchResultTT.clear();
   if (!galleryAccel) return SA_OK;
   if (!accelHandle)  return SA_NULL_POINTER;
   
   int result = SA_OK;
   AccelData *accelData = (AccelData*)accelHandle;
   if (!accelData->m_init)
      return SA_NOT_INITIALIZED;
   if (threadNum >= accelData->m_numThreads)
      return SA_NUM_THREADS_EXCEEDED;

   TpAccel gallery;
   gallery.readFromBuffer(galleryAccel);
   if (!compPersonalData(param, &accelData->m_personalDataP, gallery.m_personalData))
      return SA_OK;
//   if (!compareTpByPatterns (accelData, gallery))
//      return SA_OK;

   ThreadData* threadData    = &accelData->m_threadData[threadNum];
   AccelPair **localGroup    = threadData->m_localGroup;
   SortedAccel *sortedAccelG = &threadData->m_sortedAccelG;
   FingerPairsSet *pairs     = &threadData->m_pairSet;
   if (param.matchingMode == CHECK_MIX_FINGER_MATCHING_MODE) 
      param.numFingers = 10;
   int numFingers = param.numFingers;
   if (numFingers > 10)
      numFingers = 10;
   unsigned int speedParams[NUM_SPEED_PARAM];
   int numPairs = getFingerPairs (param, accelData->m_ipVer, speedParams, numFingers, &accelData->m_personalDataP, accelData->m_allAccelP, gallery, pairs);
   BYTE probePos = 0, galleryPos = 0;
   int similarity = 0;
   AccelPair *bestGroup = saveCombineData ? threadData->m_bestGroup : NULL;
   unsigned int maxMatchedG = 0;
   for (int i = 0; i < 10; i++)
      if (gallery.m_accel[i] && assignHeader(gallery.m_accel[i])->modQuality)
         maxMatchedG++;
   for(int i = 0; i < numPairs; i++)
   {
   	bool matchedP = false;
      probePos   = pairs->getSortedProbePos (i);
      if (!accelData->m_accelP[probePos])
         continue;
      for(int j = 0; j < pairs->getSortedSize (i); j++)
      {
         galleryPos = pairs->getSortedGalleryPos(i, j);
         if (!gallery.m_accel[galleryPos])
            continue;
         result = compAccel (accelData, param, speedParams, probePos, gallery.m_accel[galleryPos], similarity, sortedAccelG, 
                                localGroup, threadNum, bestGroup);
         if (result != SA_OK)
            return result;
         matchedP = true;
         if (saveCombineData) 
            pairs->addSortedGalleryCandidate (i, j, bestGroup, similarity);
         if (matchResultTT.score[probePos] < similarity)
         {
            matchResultTT.score      [probePos] = similarity; 
            matchResultTT.galleryPair[probePos] = galleryPos;
         }
      }
      if (matchedP)
         matchResultTT.numMatched++;
   }
   if (matchResultTT.numMatched > maxMatchedG)
      matchResultTT.numMatched = maxMatchedG;

   matchResultTT.fusionScore = getFusedScore_accel (10, matchResultTT.numMatched, matchResultTT.score);
   return SA_OK;
} 

int compareAccelTP (void *accelHandle, AccelSearchParam &param, BYTE *galleryAccel, 
               unsigned int threadNum, MatchResultTT &matchResultTT)
{
   AccelData *accelData = (AccelData*)accelHandle;
   if (!accelData->m_init)
      return SA_NOT_INITIALIZED;

   return compareAccelTP_ (accelHandle, param, galleryAccel, threadNum, matchResultTT, false);
}

int uploadDb (void *accelHandle, list <GalleryItem> &gallery)
{
   int result = SA_OK;
   if (!accelHandle)
      return SA_NULL_POINTER;
   AccelData *accelData = (AccelData*)accelHandle;
   if (!accelData->m_init)
      return SA_NOT_INITIALIZED;
   uint32_t gallerySize = (uint32_t)gallery.size();
   if (!gallerySize)
      return SA_DB_SIZE_NULL;
   if (!accelData->allocTemplates (gallerySize))
      return SA_LOW_MEMORY;

   accelData->m_realGallerySize = 0;
   list <GalleryItem>::iterator p    = gallery.begin();
   list <GalleryItem>::iterator pEnd = gallery.end();
   for(uint64_t i = 0; i < gallerySize && p != pEnd; i++, p++)
   {
     // if (!p->m_accel)
       //  continue;
      accelData->m_id              [accelData->m_realGallerySize] = p->m_id        ;
      accelData->m_galleryAccel    [accelData->m_realGallerySize] = p->m_accel     ;
      accelData->m_galleryTemplate [accelData->m_realGallerySize] = p->m_tpTemplate;
      accelData->m_realGallerySize++;
   }

   return SA_OK;
}


int accelIdentifyTP_ (void *accelHandle, AccelSearchParam &param, TpTemplate &probe, 
                     RL_SET &rlSet, PersonalData *probePersonalData)
{
   int result = SA_OK;
   if (!accelHandle)
      return SA_NULL_POINTER;
   AccelData *accelData = (AccelData*)accelHandle;
   if (!accelData->m_init)
      return SA_NOT_INITIALIZED;
   if (!accelData->m_realGallerySize)
      return SA_DB_NOT_LOADED;

   // perform first stage of matching
   if ((result = loadAccelTP(accelHandle, probe, probePersonalData)) != SA_OK)
      return result;
   unsigned int threadNum = 0;
   MatchResultTT matchResultTT;
   int gallerySize = (int)accelData->m_realGallerySize;
#pragma omp parallel for schedule (guided) private(result, threadNum, matchResultTT) num_threads (accelData->m_numThreads)
   for(int i = 0; i < gallerySize; i++)
   {
//#ifdef ADJUST
//      g_galleryId = i;
//      g_numGroup = 0;
//#endif 
      threadNum = getThreadNum (accelData);
      result = compareAccelTP_ (accelHandle, param, accelData->m_galleryAccel[i], threadNum, matchResultTT, false);
      if (result != SA_OK)
         continue;
      if (matchResultTT.fusionScore)
         getThreadData (accelData, threadNum)->m_rlSet.insert (RLex(i, -1, matchResultTT.fusionScore));
   }
   combineThreadsRl (accelData, rlSet);

   return SA_OK;
}


int accelIdentifyTP (void *accelHandle, AccelSearchParam &param, TpTemplate &probe, RL *rl, unsigned int sizeRl, 
                        PersonalData *probePersonalData)
{
   int result = SA_OK;
   RL_SET rlSet;
   if ((result = accelIdentifyTP_ (accelHandle, param, probe, rlSet, probePersonalData) ) != SA_OK)
      return result;
   fillRecomList (rlSet, rl, sizeRl);
   buildFinalRecomList (rl, sizeRl, ((AccelData*)accelHandle)->m_id);
   return SA_OK;
}


int getFingers (BYTE *accel, unsigned int &numFingers)
{
   numFingers = 0;
   if(!accel)
      return SA_NULL_POINTER;
   TpAccel tpAccel;
   if (!tpAccel.readFromBuffer (accel))
      return SA_ACCEL_CORRUPT;
   for(int fingerPos = 0; fingerPos < 10; fingerPos++)
      if   (tpAccel.m_accel[fingerPos]) numFingers++;

   return SA_OK;
}



int initAccelLib(void **accelHandle, unsigned int &numThreads)
{ 
#ifdef TIME_PROTECT
	time_t t;	
	time(&t);
	struct tm* pTime = localtime(&t);  
	if (pTime->tm_year + 1900 > 2016) 
      return SA_TRIAL_TIME_EXPIRED;
#endif
   // check SSE support
   if (!check_SSSE3())
      return SA_NOT_SUPPORT_SSSE3;
   AccelData *accelData = new AccelData;
   if (!accelData || !accelData->init(numThreads, 73))
      return SA_LOW_MEMORY;
   *accelHandle = (void*)accelData;
   return SA_OK;
}

int closeAccelLib (void **accelHandle)
{
   if (!accelHandle ) return SA_NULL_POINTER;
   if (!*accelHandle) return SA_OK;

   AccelData *accelData = (AccelData*)*accelHandle;
   if (accelData) delete accelData, accelData = NULL;
   *accelHandle = NULL;
   
   return SA_OK;
}

int initFinalMatching (void *accelHandle, unsigned int &maxGallerySize)
{
   AccelData *accelData = (AccelData*)accelHandle;
   if (!accelData->m_init)
      return SA_NOT_INITIALIZED;
   if (!accelData->initFinalMatching(accelHandle, maxGallerySize))
      return SA_LOW_MEMORY;
   return SA_OK;
}


// load probe accel
int loadProbeAccel (void *accelHandle, BYTE *probe, int finger)
{
   if (!accelHandle || !probe)
      return SA_NULL_POINTER;
   AccelData *accelData = (AccelData*)accelHandle;
   if (!accelData->m_init)
      return SA_NOT_INITIALIZED;
   if (finger < 0 || finger > 9)
      return SA_WRONG_FINGER_NUMBER;
   accelData->clearRl();
   return loadProbeFinger (accelData, probe, finger, 0);
}

int accelPairMatchEx (void *accelHandle, AccelSearchParam &param, BYTE *gallery_accel, 
                      int probeFinger, int galleryFinger, int &similarity, MatchResult &matchResult)
{
   if (!accelHandle || !gallery_accel)
      return SA_NULL_POINTER;
   if (probeFinger < 0 || probeFinger > 9 || galleryFinger < 0 || galleryFinger > 9)
      return SA_WRONG_FINGER_NUMBER;
   int result = SA_OK;
   similarity = 0;
   memset (&matchResult, 0, sizeof(MatchResult));
   AccelData *accelData = (AccelData*)accelHandle;
   if (!accelData->m_init)
      return SA_NOT_INITIALIZED;
   SortedAccel sortedAccelG; 
   TpAccel tpAccel;
   tpAccel.readFromBuffer (gallery_accel);

   unsigned int speedParams[NUM_SPEED_PARAM];
   getSpeedParams (param.searchSpeed, speedParams, accelData->m_ipVer, 1);


   ThreadData* threadData = &accelData->m_threadData[0];
   AccelPair bestGroup;
   if (!bestGroup.init())
      return SA_LOW_MEMORY;
   result = compAccel (accelData, param, speedParams, probeFinger, tpAccel.m_accel[galleryFinger], similarity, &sortedAccelG, threadData->m_localGroup, 
                        0, &bestGroup);
   matchResult.fingerP     = (FINGERS)probeFinger;
   matchResult.fingerG     = (FINGERS)galleryFinger;
   matchResult.similarity = similarity;
   matchResult.numPairs = bestGroup.m_num;
   for(int i = 0; i < bestGroup.m_num; i++)
      matchResult.minutiaeNum[i][0] = bestGroup.m_np[i], matchResult.minutiaeNum[i][1] = bestGroup.m_ng[i];

   return result;
}

int accelPairMatch (void *accelHandle, AccelSearchParam &param, BYTE *probe, BYTE *gallery_accel, int probeFinger, int galleryFinger, int &similarity, MatchResult &matchResult)
{
   int result = loadProbeAccel(accelHandle, probe, probeFinger);
   if (result != SA_OK)
      return result;
   return accelPairMatchEx (accelHandle, param, gallery_accel, probeFinger, galleryFinger, similarity, matchResult);
}


#pragma pack(pop)
} // namespace accelMatch{
