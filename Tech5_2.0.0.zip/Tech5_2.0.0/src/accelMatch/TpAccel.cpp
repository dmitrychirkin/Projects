#include "TpAccel.h"
#include "accel.h"

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)



DWORD TpAccel::getSize (int finger)   
{
   if (!m_accel[finger]) return 0;
   return getAccelDataSize((AllAccel*)m_accel[finger]);
}

DWORD TpAccel::getSize()   
{
   DWORD size = sizeof(TpAccelHeader);
   for(int finger = 0; finger < 10; finger++)
   {
      if (!m_accel[finger]) continue;
      size += getSize (finger);
   }
   return (size > sizeof(TpAccelHeader) ? size : 0);
}


// save information about all 10 accelerators and personal data in buffer.
// memory for this buffer should be prevoiosly allocated
// use getSize() function for get a real required size
// or allocate getMaximumAccelSize() bytes memory
// return a real size of data copied to buffer
DWORD TpAccel::save2Buffer (BYTE *buffer)
{
   if (!buffer)
      return 0;
   int size = 0;
   TpAccelHeader *header = (TpAccelHeader*)buffer;
   header->clear();
   if (m_personalData)
      memcpy(&header->m_personalData, m_personalData, sizeof(PersonalData));
   else       // copy default PersonalData
   {
      PersonalData a_personalData;
      memcpy(&header->m_personalData,  &a_personalData, sizeof(PersonalData));
   }
   BYTE *pos = buffer + sizeof(TpAccelHeader);
   header->m_size = sizeof(TpAccelHeader);
   for(int finger = 0; finger < 10; finger++)
   {
      if (!m_accel[finger])
         continue;
      size = getAccelDataSize((AllAccel*)m_accel[finger]);
      header->m_accelOffset[finger] = (WORD)(pos - buffer);
      memcpy(pos, m_accel[finger], size);
      pos += size;
      header->m_size += size;
   }
   return header->m_size;
}

// read inforamtion about all 10 accel from buffer
// memoty not allocated. Memory allocated for buffer will be used
bool TpAccel::readFromBuffer (BYTE *buffer)
{
   if (!buffer)
      return false;
   TpAccelHeader *header = (TpAccelHeader*)buffer;
   if (header->m_version != 10)
      return false;
   this->m_personalData = &header->m_personalData;
   for(int finger = 0; finger < 10; finger++)
   {
      if (!header->m_accelOffset[finger])
         this->m_accel[finger] = NULL;
      else
         this->m_accel[finger] = buffer + header->m_accelOffset[finger];
   }
   return true;
}

#pragma pack(pop)
} // namespace accelMatch{

