#ifndef CHOOSE_PARAM_H_
#define CHOOSE_PARAM_H_

#include "accelMatch.h"

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)

//                                          1 * 255        2 * 255         3 * 255        4 * 255           5 * 255           6 * 255           7 * 255           8 * 255           9 * 255           10 * 255          11 * 255          12 * 255        
static const unsigned int g_minSim_73 [] = {255, 255, 255, 510, 510, 510,  765, 765, 765, 1020, 1020, 1020, 1275, 1275, 1275, 1530, 1530, 1530, 1785, 1785, 1785, 2040, 2040, 2040, 2295, 2295, 2295, 2550, 2550, 2550, 2805, 2805, 2805, 3060, 3060, 3060};
//                                          1 * 255                  2 * 255         3 * 255        4 * 255           5 * 255           6 * 255           7 * 255           8 * 255           9 * 255           10 * 255          11 * 255          12 * 255        
static const unsigned int g_minSim_140[] = {255, 255, 255, 255, 255, 510, 510, 510, 510,  765, 765, 765, 765, 1020, 1020, 1020, 1020, 1275, 1275, 1275, 1275, 1530, 1530, 1530, 1530, 1785, 1785, 1785, 1785, 2040, 2040, 2040, 2040, 2295, 2295, 2295, 2295, 2550, 2550, 2550, 2550, 2805, 2805, 2805, 2805, 3060, 3060, 3060, 3060};


static inline unsigned int chooseNumAccelForCompareTT (unsigned int *speedParams, AllAccel *allAccel)
{
   unsigned int num = allAccel->numMinutiae;
   BYTE quality = allAccel->modQuality; //getModifiedQuality(allAccel);
   if (quality < 20)
   {
      num = (num * speedParams[5]) >> 16;
      if (num > speedParams[1])  num = speedParams[1];
   }
   else if (quality < 40) 
   {
      num = (num * speedParams[6]) >> 16;
      if (num > speedParams[2])  num = speedParams[2];
   }
   else if (quality < 60) 
   {
      num = (num * speedParams[7]) >> 16;
      if (num > speedParams[3])  num = speedParams[3];
   }
   else   // quality >= 60 
   {
      num = (num * speedParams[8]) >> 16;
      if (num > speedParams[4]) num = speedParams[4];
   }
   if (num > allAccel->numAccel) num = allAccel->numAccel;
   return num;
}

static inline unsigned int chooseNumAccelForCompareLT (AccelSearchParam &param, AllAccel *allAccel)
{
   unsigned int speedParams[NUM_SPEED_PARAM];
   memcpy(speedParams, g_speedParamsLT[param.searchSpeed], sizeof(speedParams));

   unsigned int num = allAccel->numMinutiae;
   BYTE quality = allAccel->modQuality; //getModifiedQuality(allAccel);
//   BYTE quality = allAccel->quality;
   if (quality < 20)
   {
      num = (num * speedParams[5]) >> 16;
      if (num > speedParams[1])  num = speedParams[1];
   }
   else if (quality < 40) 
   {
      num = (num * speedParams[6]) >> 16;
      if (num > speedParams[2])  num = speedParams[2];
   }
   else if (quality < 60) 
   {
      num = (num * speedParams[7]) >> 16;
      if (num > speedParams[3])  num = speedParams[3];
   }
   else   // quality >= 60 
   {
      num = (num * speedParams[8]) >> 16;
      if (num > speedParams[4]) num = speedParams[4];
   }
   if (num > allAccel->numAccel) num = allAccel->numAccel;
   return num;
}


static inline void chooseParam (AccelData *accelData, unsigned int *speedParams, AllAccel *allAccelP, AllAccel *allAccelG,
                         int numMinP, int numMinG,
                         unsigned int *&minSim, BYTE &minPointInLocalGroup_1st, BYTE &minPointInLocalGroup_2nd, 
                         BYTE &minFill)
{
   unsigned int minNumMin = minAB (numMinP, numMinG);
   BYTE qualityP = allAccelP->modQuality;//getModifiedQuality(allAccelP);
   BYTE qualityG = allAccelG->modQuality;//getModifiedQuality(allAccelG);
   unsigned int minQ = minAB(qualityP, qualityG);
   unsigned int *minSimArray = accelData->m_ipVer == 140 ? (unsigned int*)g_minSim_140 : (unsigned int*)g_minSim_73;

   minFill = 1;
//#ifdef IP_73
//   if (param.searchSpeed > 5)
//   {
//      if      (minNumMin >  150)                minPointInLocalGroup_1st = 7;
//      else if (minQ      >= 65 )                minPointInLocalGroup_1st = 7;
//      else if (minNumMin >  120)                minPointInLocalGroup_1st = 6;
//      else                                      minPointInLocalGroup_1st = 5;
//
//      if       (minQ < 35)  minPointInLocalGroup_2nd = 10;//9;
//      else if  (minQ < 50)  minPointInLocalGroup_2nd = 11;//10;
//      else                  minPointInLocalGroup_2nd = 12;
//
//      if      (minQ  >= 80) minFill = 8, minSim = (unsigned int*)(g_minSim + 14);
//      else if (minQ  >= 60) minFill = 8, minSim = (unsigned int*)(g_minSim + 14);//12);
//      else if (minQ  >= 40) minFill = 6, minSim = (unsigned int*)(g_minSim + 10);
//      else if (minQ  >= 20) minFill = 4, minSim = (unsigned int*)(g_minSim +  6);
//      else                  minFill = 4, minSim = (unsigned int*)(g_minSim +  6);
//      if (minPointInLocalGroup_2nd > minNumMin / 4)
//      {
//         minPointInLocalGroup_2nd = minNumMin / 4;
//         if (minQ <= 20)  
//            minPointInLocalGroup_2nd--;
//      }
//   }
//   else if (param.searchSpeed > 4)
//   {
//      if      (minNumMin >  150)                minPointInLocalGroup_1st = 7;
//      else if (minQ      >= 65 )                minPointInLocalGroup_1st = 7;
//      else if (minNumMin >  120)                minPointInLocalGroup_1st = 6;
//      else                                      minPointInLocalGroup_1st = 5;
//
//      if       (minQ < 35)  minPointInLocalGroup_2nd = 9;
//      else if  (minQ < 50)  minPointInLocalGroup_2nd = 10;
//      else                  minPointInLocalGroup_2nd = 12;
//
//      if      (minQ  >= 80) minFill = 8, minSim = (unsigned int*)(g_minSim + 14);
//      else if (minQ  >= 60) minFill = 8, minSim = (unsigned int*)(g_minSim + 10);
//      else if (minQ  >= 40) minFill = 6, minSim = (unsigned int*)(g_minSim + 10);
//      else if (minQ  >= 20) minFill = 4, minSim = (unsigned int*)(g_minSim +  6);
//      else                  minFill = 4, minSim = (unsigned int*)(g_minSim +  6);
//      if (minPointInLocalGroup_2nd > minNumMin / 4)
//      {
//         minPointInLocalGroup_2nd = minNumMin / 4;
//         if (minQ <= 20)  
//            minPointInLocalGroup_2nd--;
//      }
//   }
//   else if (param.searchSpeed > 2)
//   {
//      if      (minNumMin >  150)                minPointInLocalGroup_1st = 7;
//      else if (minQ      >= 65 )                minPointInLocalGroup_1st = 7;
//      else if (minNumMin >  120)                minPointInLocalGroup_1st = 6;
//      else if (minQ      >= 40 )                minPointInLocalGroup_1st = 5;
//      else if (minNumMin >  55 )                minPointInLocalGroup_1st = 5;
//      else if (minNumMin >  45 && minQ >= 35)   minPointInLocalGroup_1st = 5;
//      else if (minNumMin >  45 )                minPointInLocalGroup_1st = 4;
//      else                                      minPointInLocalGroup_1st = 3;
//
//      if       (minQ < 35)  minPointInLocalGroup_2nd =  9;
//      else if  (minQ < 50)  minPointInLocalGroup_2nd = 10;
//      else                  minPointInLocalGroup_2nd = 12;
//
//      if      (minQ  >= 80) minFill = 8, minSim = (unsigned int*)(g_minSim + 14);
//      else if (minQ  >= 60) minFill = 8, minSim = (unsigned int*)(g_minSim + 10);
//      else if (minQ  >= 40) minFill = 6, minSim = (unsigned int*)(g_minSim + 10);
//      else if (minQ  >= 20) minFill = 4, minSim = (unsigned int*)(g_minSim +  6);
//      else                  minFill = 4, minSim = (unsigned int*)(g_minSim +  6);
//      if (minPointInLocalGroup_2nd > minNumMin / 4)
//      {
//         minPointInLocalGroup_2nd = minNumMin / 4;
//         if (minQ <= 20)  
//            minPointInLocalGroup_2nd--;
//      }
//      if (minQ < 25 && minNumMin <= 30)
//         minPointInLocalGroup_2nd = 5;
//      if (minPointInLocalGroup_2nd < 5)
//         minPointInLocalGroup_2nd = 5;
//   }
//   else if (param.searchSpeed == 2)
//   {
//      if      (minNumMin >  150)                minPointInLocalGroup_1st = 7;
//      else if (minQ      >= 65 )                minPointInLocalGroup_1st = 7;
//      else if (minNumMin >  120)                minPointInLocalGroup_1st = 6;
//      else if (minQ      >= 40 )                minPointInLocalGroup_1st = 5;
//      else if (minNumMin >  55 )                minPointInLocalGroup_1st = 5;
//      else if (minNumMin >  45 && minQ >= 35)   minPointInLocalGroup_1st = 5;
//      else if (minNumMin >  45 )                minPointInLocalGroup_1st = 4;
//      else                                      minPointInLocalGroup_1st = 3;
//                                                         
//      if      (minQ <= 10)  minPointInLocalGroup_2nd =  7;
//      else if (minQ <  35)  minPointInLocalGroup_2nd =  9;
//      else if (minQ <  50)  minPointInLocalGroup_2nd = 10;
//      else                  minPointInLocalGroup_2nd = 11;
//
//      if      (minQ  >= 80) minFill = 8, minSim = (unsigned int*)(g_minSim + 14);
//      else if (minQ  >= 60) minFill = 8, minSim = (unsigned int*)(g_minSim + 10);
//      else if (minQ  >= 40) minFill = 6, minSim = (unsigned int*)(g_minSim + 10); 
//      else if (minQ  >= 20) minFill = 4, minSim = (unsigned int*)(g_minSim +  5);
//      else                  minFill = 4, minSim = (unsigned int*)(g_minSim +  5);
//      if (minPointInLocalGroup_2nd > minNumMin / 4)
//      {
//         minPointInLocalGroup_2nd = minNumMin / 4;
//         if (minQ <= 20)  
//            minPointInLocalGroup_2nd--;
//      }
//      if (minQ < 25 && minNumMin <= 30)
//         minPointInLocalGroup_2nd = 5;
//      if (minPointInLocalGroup_2nd < 5)
//         minPointInLocalGroup_2nd = 5;
//   }
//   else //param.searchSpeed < 2
//   {
//      if      (minNumMin >  150)                minPointInLocalGroup_1st = 7;
//      else if (minQ      >= 65 )                minPointInLocalGroup_1st = 7;
//      else if (minNumMin >  120)                minPointInLocalGroup_1st = 6;
//      else if (minQ      >= 40 )                minPointInLocalGroup_1st = 5;
//      else if (minNumMin >  55 )                minPointInLocalGroup_1st = 5;
//      else if (minNumMin >  45 && minQ >= 35)   minPointInLocalGroup_1st = 5;
//      else if (minNumMin >  45 )                minPointInLocalGroup_1st = 4;
//      else                                      minPointInLocalGroup_1st = 3;
//                                                         
//      if      (minQ <= 10)  minPointInLocalGroup_2nd =  7;
//      else if (minQ <  20)  minPointInLocalGroup_2nd =  8;
//      else if (minQ <  40)  minPointInLocalGroup_2nd =  9;
//      else                  minPointInLocalGroup_2nd = 10;
//
//      if      (minQ  >= 80) minFill = 8, minSim = (unsigned int*)(g_minSim + 14);
//      else if (minQ  >= 60) minFill = 8, minSim = (unsigned int*)(g_minSim + 10);
//      else if (minQ  >= 40) minFill = 6, minSim = (unsigned int*)(g_minSim + 10);
//      else if (minQ  >= 20) minFill = 4, minSim = (unsigned int*)(g_minSim +  4);
//      else                  minFill = 4, minSim = (unsigned int*)(g_minSim +  2);
//      if (minPointInLocalGroup_2nd > minNumMin / 4)
//      {
//         minPointInLocalGroup_2nd = minNumMin / 4;
//         if (minQ <= 20)  
//            minPointInLocalGroup_2nd--;
//      }
//      if (minQ < 25 && minNumMin <= 30)
//         minPointInLocalGroup_2nd = 5;
//      if (minPointInLocalGroup_2nd < 5)
//         minPointInLocalGroup_2nd = 5;
//   }
//#else
   //if (param.searchSpeed > 5)
   //{
   //   if      (minNumMin >  150)                minPointInLocalGroup_1st = 7;
   //   else if (minQ      >= 65 )                minPointInLocalGroup_1st = 7;
   //   else if (minNumMin >  120)                minPointInLocalGroup_1st = 6;
   //   else                                      minPointInLocalGroup_1st = 5;

   //   if       (minQ < 35)  minPointInLocalGroup_2nd = 10;//9;
   //   else if  (minQ < 50)  minPointInLocalGroup_2nd = 11;//10;
   //   else                  minPointInLocalGroup_2nd = 12;

   //   if      (minQ  >= 80) minFill = 8, minSim = (unsigned int*)(g_minSim + 14);
   //   else if (minQ  >= 60) minFill = 8, minSim = (unsigned int*)(g_minSim + 14);//12);
   //   else if (minQ  >= 40) minFill = 6, minSim = (unsigned int*)(g_minSim + 10);
   //   else if (minQ  >= 20) minFill = 4, minSim = (unsigned int*)(g_minSim +  6);
   //   else                  minFill = 4, minSim = (unsigned int*)(g_minSim +  6);
   //   if (minPointInLocalGroup_2nd > minNumMin / 4)
   //   {
   //      minPointInLocalGroup_2nd = minNumMin / 4;
   //      if (minQ <= 20)  
   //         minPointInLocalGroup_2nd--;
   //   }
   //}
   //else if (param.searchSpeed > 4)
   //{
   //   if      (minNumMin >  150)                minPointInLocalGroup_1st = 7;
   //   else if (minQ      >= 65 )                minPointInLocalGroup_1st = 7;
   //   else if (minNumMin >  120)                minPointInLocalGroup_1st = 6;
   //   else                                      minPointInLocalGroup_1st = 5;

   //   if       (minQ < 35)  minPointInLocalGroup_2nd = 9;
   //   else if  (minQ < 50)  minPointInLocalGroup_2nd = 10;
   //   else                  minPointInLocalGroup_2nd = 12;

   //   if      (minQ  >= 80) minFill = 8, minSim = (unsigned int*)(g_minSim + 14);
   //   else if (minQ  >= 60) minFill = 8, minSim = (unsigned int*)(g_minSim + 10);
   //   else if (minQ  >= 40) minFill = 6, minSim = (unsigned int*)(g_minSim + 10);
   //   else if (minQ  >= 20) minFill = 4, minSim = (unsigned int*)(g_minSim +  6);
   //   else                  minFill = 4, minSim = (unsigned int*)(g_minSim +  6);
   //   if (minPointInLocalGroup_2nd > minNumMin / 4)
   //   {
   //      minPointInLocalGroup_2nd = minNumMin / 4;
   //      if (minQ <= 20)  
   //         minPointInLocalGroup_2nd--;
   //   }
   //}
   //else if (param.searchSpeed > 2)
   //{
   //   if      (minNumMin >  150)                minPointInLocalGroup_1st = 7;
   //   else if (minQ      >= 65 )                minPointInLocalGroup_1st = 7;
   //   else if (minNumMin >  120)                minPointInLocalGroup_1st = 6;
   //   else if (minQ      >= 40 )                minPointInLocalGroup_1st = 5;
   //   else if (minNumMin >  55 )                minPointInLocalGroup_1st = 5;
   //   else if (minNumMin >  45 && minQ >= 35)   minPointInLocalGroup_1st = 5;
   //   else if (minNumMin >  45 )                minPointInLocalGroup_1st = 4;
   //   else                                      minPointInLocalGroup_1st = 3;

   //   if       (minQ < 35)  minPointInLocalGroup_2nd =  9;
   //   else if  (minQ < 50)  minPointInLocalGroup_2nd = 10;
   //   else                  minPointInLocalGroup_2nd = 12;

   //   if      (minQ  >= 80) minFill = 8, minSim = (unsigned int*)(g_minSim + 14);
   //   else if (minQ  >= 60) minFill = 8, minSim = (unsigned int*)(g_minSim + 10);
   //   else if (minQ  >= 40) minFill = 6, minSim = (unsigned int*)(g_minSim + 10);
   //   else if (minQ  >= 20) minFill = 4, minSim = (unsigned int*)(g_minSim +  6);
   //   else                  minFill = 4, minSim = (unsigned int*)(g_minSim +  6);
   //   if (minPointInLocalGroup_2nd > minNumMin / 4)
   //   {
   //      minPointInLocalGroup_2nd = minNumMin / 4;
   //      if (minQ <= 20)  
   //         minPointInLocalGroup_2nd--;
   //   }
   //   if (minQ < 25 && minNumMin <= 30)
   //      minPointInLocalGroup_2nd = 5;
   //   if (minPointInLocalGroup_2nd < 5)
   //      minPointInLocalGroup_2nd = 5;
   //}
   //else if (param.searchSpeed == 2)
   //{
   //   if      (minNumMin >  150)                minPointInLocalGroup_1st = 7;
   //   else if (minQ      >= 65 )                minPointInLocalGroup_1st = 7;
   //   else if (minNumMin >  120)                minPointInLocalGroup_1st = 6;
   //   else if (minQ      >= 40 )                minPointInLocalGroup_1st = 5;
   //   else if (minNumMin >  55 )                minPointInLocalGroup_1st = 5;
   //   else if (minNumMin >  45 && minQ >= 35)   minPointInLocalGroup_1st = 5;
   //   else if (minNumMin >  45 )                minPointInLocalGroup_1st = 4;
   //   else                                      minPointInLocalGroup_1st = 3;
   //                                                      
   //   if      (minQ <= 10)  minPointInLocalGroup_2nd =  7;
   //   else if (minQ <  35)  minPointInLocalGroup_2nd =  9;
   //   else if (minQ <  50)  minPointInLocalGroup_2nd = 10;
   //   else                  minPointInLocalGroup_2nd = 11;

   //   if      (minQ  >= 80) minFill = 8, minSim = (unsigned int*)(g_minSim + 14);
   //   else if (minQ  >= 60) minFill = 8, minSim = (unsigned int*)(g_minSim + 10);
   //   else if (minQ  >= 40) minFill = 6, minSim = (unsigned int*)(g_minSim + 10); 
   //   else if (minQ  >= 20) minFill = 4, minSim = (unsigned int*)(g_minSim +  5);
   //   else                  minFill = 4, minSim = (unsigned int*)(g_minSim +  5);
   //   if (minPointInLocalGroup_2nd > minNumMin / 4)
   //   {
   //      minPointInLocalGroup_2nd = minNumMin / 4;
   //      if (minQ <= 20)  
   //         minPointInLocalGroup_2nd--;
   //   }
   //   if (minQ < 25 && minNumMin <= 30)
   //      minPointInLocalGroup_2nd = 5;
   //   if (minPointInLocalGroup_2nd < 5)
   //      minPointInLocalGroup_2nd = 5;
   //}
   //else //param.searchSpeed < 2
//   {
      if      (minNumMin >  speedParams[ 9] && minQ >= speedParams[10]) minPointInLocalGroup_1st = 7;
      else if (minNumMin >  speedParams[11] && minQ >= speedParams[12]) minPointInLocalGroup_1st = 7;
      else if (minNumMin >  speedParams[13] && minQ >= speedParams[14]) minPointInLocalGroup_1st = 6;
      else if (minNumMin >  speedParams[15] && minQ >= speedParams[16]) minPointInLocalGroup_1st = 6;
      else if (minNumMin >  speedParams[17] && minQ >= speedParams[18]) minPointInLocalGroup_1st = 5;
      else if (minNumMin >  speedParams[19] && minQ >= speedParams[20]) minPointInLocalGroup_1st = 5;
      else if (minNumMin >  speedParams[21] && minQ >= speedParams[22]) minPointInLocalGroup_1st = 5;
      else if (minNumMin >  speedParams[23] && minQ >= speedParams[24]) minPointInLocalGroup_1st = 4;
      else                                                              minPointInLocalGroup_1st = 3;
// ��� ������ minPointInLocalGroup_2nd ����� �� ������������ ��� �� ������, ��� � ��� minPointInLocalGroup_1st, �.� �������� ��������� �������� � �����. �����?  
// ����� � �� ����� ����� ��������� ���. ��������?
      if      (minQ < speedParams[25]) minPointInLocalGroup_2nd =   7;
      else if (minQ < speedParams[26]) minPointInLocalGroup_2nd =   8;
      else if (minQ < speedParams[27]) minPointInLocalGroup_2nd =   9;
      else if (minQ < speedParams[28]) minPointInLocalGroup_2nd =  10;
      else if (minQ < speedParams[29]) minPointInLocalGroup_2nd =  11;
      else if (minQ < speedParams[30]) minPointInLocalGroup_2nd =  12;
      else                             minPointInLocalGroup_2nd =  13;
      if      (minQ  >= 90) minFill = speedParams[31], minSim = (unsigned int*)(minSimArray + speedParams[41]);
      else if (minQ  >= 80) minFill = speedParams[32], minSim = (unsigned int*)(minSimArray + speedParams[42]);
      else if (minQ  >= 70) minFill = speedParams[33], minSim = (unsigned int*)(minSimArray + speedParams[43]);
      else if (minQ  >= 60) minFill = speedParams[34], minSim = (unsigned int*)(minSimArray + speedParams[44]);
      else if (minQ  >= 50) minFill = speedParams[35], minSim = (unsigned int*)(minSimArray + speedParams[45]);
      else if (minQ  >= 40) minFill = speedParams[36], minSim = (unsigned int*)(minSimArray + speedParams[46]);
      else if (minQ  >= 30) minFill = speedParams[37], minSim = (unsigned int*)(minSimArray + speedParams[47]);
      else if (minQ  >= 20) minFill = speedParams[38], minSim = (unsigned int*)(minSimArray + speedParams[48]);
      else if (minQ  >= 10) minFill = speedParams[39], minSim = (unsigned int*)(minSimArray + speedParams[49]);
      else                  minFill = speedParams[40], minSim = (unsigned int*)(minSimArray + speedParams[50]);

      if (minPointInLocalGroup_2nd > minNumMin / 4)
      {
         minPointInLocalGroup_2nd = minNumMin / 4;
         if (minQ <= speedParams[51])  
            minPointInLocalGroup_2nd--;
      }
      if (minQ < speedParams[52] && minNumMin <= speedParams[53])
         minPointInLocalGroup_2nd = 5;
      if (minPointInLocalGroup_2nd < 5)
         minPointInLocalGroup_2nd = 5;
//   }
//#endif
}

static inline void chooseParamLT (AccelData *accelData, AccelSearchParam &param, AllAccel *allAccelP, AllAccel *allAccelG,
                         int numMinP, int numMinG,
                         unsigned int *&minSim, BYTE &minPointInLocalGroup_1st, BYTE &minPointInLocalGroup_2nd, 
                         BYTE &minFill)
{
   unsigned int minNumMin = minAB (numMinP, numMinG);
   BYTE qualityP = allAccelP->modQuality;
   BYTE qualityG = allAccelG->modQuality;
   int minQ = minAB(qualityP, qualityG);
   unsigned int *minSimArray = accelData->m_ipVer == 140 ? (unsigned int*)g_minSim_140 : (unsigned int*)g_minSim_73;

   minFill = 1;
   if      (minNumMin >  150)                minPointInLocalGroup_1st = 7;
   else if (minQ      >= 65 )                minPointInLocalGroup_1st = 7;
   else if (minNumMin >  120)                minPointInLocalGroup_1st = 6;
   else if (minQ      >= 40 )                minPointInLocalGroup_1st = 5;
   else if (minNumMin >  55 )                minPointInLocalGroup_1st = 5;
   else if (minNumMin >  45 && minQ >= 35)   minPointInLocalGroup_1st = 5;
   else if (minNumMin >  45 )                minPointInLocalGroup_1st = 4;
   else                                      minPointInLocalGroup_1st = 3;
                                                         
   if      (minQ <= 10)  minPointInLocalGroup_2nd =  7;
   else if (minQ <  20)  minPointInLocalGroup_2nd =  8;
   else if (minQ <  40)  minPointInLocalGroup_2nd =  9;
   else                  minPointInLocalGroup_2nd = 10;

   if      (minQ  >= 80) minFill = 8, minSim = (unsigned int*)(minSimArray + 14);
   else if (minQ  >= 60) minFill = 8, minSim = (unsigned int*)(minSimArray + 10);
   else if (minQ  >= 40) minFill = 6, minSim = (unsigned int*)(minSimArray +  4);
   else if (minQ  >= 20) minFill = 4, minSim = (unsigned int*)(minSimArray +  2);
   else                  minFill = 4, minSim = (unsigned int*)(minSimArray +  2);
   if (minPointInLocalGroup_2nd > minNumMin / 4)
   {
      minPointInLocalGroup_2nd = minNumMin / 4;
      if (minQ <= 20)  
         minPointInLocalGroup_2nd--;
   }
   if (minQ < 25 && minNumMin <= 30)
      minPointInLocalGroup_2nd = 5;
   if (minPointInLocalGroup_2nd < 5)
      minPointInLocalGroup_2nd = 5;
}

#pragma pack(pop)
} // namespace accelMatch{

#endif // CHOOSE_PARAM_H_
