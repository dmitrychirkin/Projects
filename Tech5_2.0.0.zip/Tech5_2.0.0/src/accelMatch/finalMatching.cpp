#include <assert.h>
#ifdef USE_OMP
   #include <omp.h>
#endif
#include <stdio.h>

#include "accelMatchEx.h"
#include "accelData.h"
#include "TpAccel.h"
#include "correctSegmentationError.h"
#include "getFusedScore.h"
#include "checkFingerPairSequences.h"
#include "chooseFinalParam.h"

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)

// Extended accelerator search parameters
struct AccelSearchParamEx : public AccelSearchParam
{
   /* 
     parameters for final (precise) stage of matching in 'completeIdentifyTP' and 'finalIdentifyTP' functions:
   */
   unsigned int   rl_size_divisor_1;             // define which part of gallerysize will be passed to 1st stage of final matching
   unsigned int   rl_size_divisor_2;             // define which part of gallerysize will be passed to 2nd stage of final matching  
   bool           use_2nd_stage_final_matching;  // if true, 2nd stage of final matching will be performed 
   bool           use_3rd_stage_final_matching;  // if true, 3rd stage of final matching will be performed

   AccelSearchParamEx() : AccelSearchParam()
   {
      use_2nd_stage_final_matching  = true;
      use_3rd_stage_final_matching  = false;
      rl_size_divisor_1             = 1024;
      rl_size_divisor_2             = 10 * 1024;
   }
   AccelSearchParamEx(const AccelSearchParam& param)
   {
      *this = param;
   }
   void setFinalParam(int numFingerPairs)
   {
      if (!numFingerPairs)
         return;
      if (numFingerPairs <= 1)
      {
         switch (searchSpeed)
         {
         case 0:
            rl_size_divisor_1 =       512;
            rl_size_divisor_2 = 10 * 1024;
            break;
         case 1:
            rl_size_divisor_1 =   5 * 1024;
            rl_size_divisor_2 = 100 * 1024; 
            break;
         case 2:
         case 3:
            rl_size_divisor_1 =  10 * 1024;
            rl_size_divisor_2 = 100 * 1024; 
            break;
            break;
         default:
            rl_size_divisor_1 =  100 * 1024;
            rl_size_divisor_2 = 1024 * 1024;
            break;
         }
      }
      else if (numFingerPairs <= 2)
      {
         switch (searchSpeed)
         {
         case 0:
            rl_size_divisor_1 =       512;
            rl_size_divisor_2 = 10 * 1024;  
            break;
         case 1:
            rl_size_divisor_1 =      1024; 
            rl_size_divisor_2 = 10 * 1024;
            break;
         case 2:
            rl_size_divisor_1 =   5 * 1024; 
            rl_size_divisor_2 = 100 * 1024; 
            break;
         case 3:
            rl_size_divisor_1 =  10 * 1024;
            rl_size_divisor_2 = 100 * 1024; 
            break;
         case 4:
            rl_size_divisor_1 =  50 * 1024; 
            rl_size_divisor_2 = 1024 * 1024;
            break;
         default:
            rl_size_divisor_1 =  100 * 1024;
            rl_size_divisor_2 = 1024 * 1024;
            break;
         }
      }
      else if (numFingerPairs <= 8)
      {
         switch (searchSpeed)
         {
         case 0:
            rl_size_divisor_1 =      1024;   
            rl_size_divisor_2 = 10 * 1024;
            break;
         case 1:
         case 2:
         case 3:
            rl_size_divisor_1 =   5 * 1024;  
            rl_size_divisor_2 = 100 * 1024; 
            break;
         case 4:
            rl_size_divisor_1 =  10 * 1024; 
            rl_size_divisor_2 = 100 * 1024; 
            break;
         default:
            rl_size_divisor_1 =  100 * 1024;
            rl_size_divisor_2 = 1024 * 1024;
            break;
         }
      }
      else   // numFingerPairs > 8
      {
         switch (searchSpeed)
         {
         case 0:
         case 1:
            rl_size_divisor_1 =      1024;
            rl_size_divisor_2 = 10 * 1024;
            break;
         case 2:
            rl_size_divisor_1 =   5 * 1024;
            rl_size_divisor_2 = 100 * 1024; 
            break;
         default:
            rl_size_divisor_1 =  100 * 1024;
            rl_size_divisor_2 = 1024 * 1024;
               break;
            }
      }
      if (rl_size_divisor_1 < RL_SIZE_DIVISOR_1_MIB) 
         rl_size_divisor_1 = RL_SIZE_DIVISOR_1_MIB;
      use_2nd_stage_final_matching  = true;
      use_3rd_stage_final_matching  = false;
   }

   AccelSearchParamEx& operator=(const AccelSearchParam& param)
   {
      memcpy(this, &param, sizeof(AccelSearchParam));
      return *this;
   }
};


int preciseMatchEx (ThreadData *threadData, SearchParam &param, BYTE *galleryTempl, int &sim, int fingerP,
                     bool useCombineData, BYTE *np, BYTE *ng, BYTE accelGroupSize)
{
   return threadData->m_ma.matchEx (param, galleryTempl, UNKNOWN, sim, (FINGERS)(fingerP + 1), NULL, 
                                    useCombineData, np, ng, accelGroupSize, false);
   //return threadData->m_ma.matchEx (param, galleryTempl, sim);
}

inline int getFusedScore (unsigned int numItems, unsigned int numRealScore, int *score)
{
   return getFusedScore_100 (numItems, numRealScore, score);
}

// compare TP at first by accelerator with same accelParam as in accelIdentifyTP and perform precise matching for 
// best finger pairs
int twoStepsCompareTP (void *accelHandle, AccelSearchParam &accelParam, SearchParam &maParam, TpTemplate &probe, 
                    BYTE *galleryAccel_buf, TpTemplate &galleryTemplate, MatchResultTT &matchResultTT, unsigned int threadNum)
{
   assert (accelHandle);
   if (!galleryAccel_buf) return SA_OK;
   AccelData *accelData = (AccelData*)accelHandle;
   assert(accelData->m_initFinalMatching);
   if (threadNum >= accelData->m_numThreads)
      return SA_NUM_THREADS_EXCEEDED;

   
   int result = SA_OK;
   ThreadData* threadData = &accelData->m_threadData[threadNum];
   MatchResultTT matchResultTT_temp;
   if ((result = compareAccelTP_ (accelHandle, accelParam, galleryAccel_buf, threadNum, matchResultTT_temp, true)) != SA_OK)
       return result;
   FingerPairsSet &pairs = threadData->m_pairSet;
   // sorting pairs in order of decrease similarity and quality
   pairs.sort();

   unsigned int probePos = 0, galleryPos = 0, numCompared = 0;
   int bestGalleryPos = -1;
   TpAccel gallery;
   gallery.readFromBuffer (galleryAccel_buf);
   FingerPairSequences fingerPairSequences (accelParam, &accelData->m_personalDataP, gallery.m_personalData, accelData->m_probeAccel, gallery.m_accel);
   BYTE *np = NULL, *ng = NULL, accelGroupSize = 0;
   bool useCombineData = false;
   bool takenG[10];
   memset (takenG, 0, sizeof(takenG));

   for (int probeFinger = 0; probeFinger < 10; probeFinger++)
   {
      int galleryFinger = matchResultTT.galleryPair[probeFinger];
      if (galleryFinger >= 0)
      {
         takenG[galleryFinger] = true;
         fingerPairSequences.add (probeFinger, galleryFinger);
         numCompared++;
      }
   }
   matchResultTT.fusionScore = getFusedScore (10, numCompared, matchResultTT.score);

   // left for when matched at least minMatch pairs of real fingers and when at least one of 4 conditions true:
   // maxMatch pairs are matched
   // fusionScore <= lowThreshold or fusionScore >= hightThreshold or
   // there are no more pairs that have not null score after accel matching
   for(unsigned int i = 0; i < maParam.maxMatch; i++)
   {
      probePos = pairs.getSortedProbePos(i);
      if (!probe.templ[probePos]) 
         continue;
      if (matchResultTT.galleryPair[probePos] >= 0)
         continue;
      if (!pairs.getSortedSim(i) && numCompared >= maParam.minMatch) 
         break;
      bestGalleryPos = -1;
      for (int j = 0; j < pairs.getSortedSize (i); j++)
      {
         galleryPos = pairs.getSortedGalleryPos (i, j);
         if (!galleryTemplate.templ[galleryPos])
            continue;
         if (!fingerPairSequences.canAdd (probePos, galleryPos))
            continue;
         if (accelParam.searchSpeed > MAX_SPEED_WITHOUT_PICK_UP && pairs.getSortedSim (i, j) <= ACCEL_RELIABLE_SIM)
            continue;   //not break, because array m_galleryCand in ProbePairs not sorted by sim, that's why we shoud go through all pairs  
         int similar = 0;
         if (pairs.getSortedSim (i, j) > ACCEL_RELIABLE_SIM)
         {
            useCombineData = true;                                        
            pairs.getSortedCombineData (i, j, np, ng, accelGroupSize);
            //accelGroupSize=1;
         }
         else
            useCombineData = false;

         result = preciseMatchEx (threadData, maParam, galleryTemplate.templ[galleryPos], similar, probePos,
                  useCombineData, np, ng, accelGroupSize);
         if (matchResultTT.score[probePos] < similar)
         {
            matchResultTT.score[probePos] = similar;
            bestGalleryPos = galleryPos;
         }
      }
      if (bestGalleryPos >= 0)
         numCompared++;
      if (matchResultTT.score[probePos] > 0)
      {
         matchResultTT.galleryPair[probePos]  = bestGalleryPos;
         takenG[bestGalleryPos] = true;
      }
      if (accelParam.doSegErrCorrect && bestGalleryPos >= 0)
         fingerPairSequences.add (probePos, bestGalleryPos);
      matchResultTT.fusionScore = getFusedScore (10, numCompared, matchResultTT.score);
      if (numCompared >= maParam.minMatch && 
         (matchResultTT.fusionScore >= maParam.highThreshold || matchResultTT.fusionScore <= maParam.lowThreshold))
         break;
   }
   matchResultTT.numMatched = numCompared;
   return SA_OK;
}


// load probe template in all threads
int  loadProbeTemplate (AccelData *accelData, TpTemplate &probe)
{
   assert(accelData && accelData->m_initFinalMatching);

   int result = SA_OK;
#pragma omp parallel for schedule(guided) num_threads (accelData->m_numThreads)
   for(int numThread = 0; numThread < (int)accelData->m_numThreads; numThread++)
   {
      //int rs = getThreadData(accelData, numThread)->m_ma.loadTT (probe, UNKNOWN, accelData->m_probeFullAccel, 
      //   accelData->m_areaP, accelData->m_areaWidthP, accelData->m_areaHeightP);
      int rs = getThreadData(accelData, numThread)->m_ma.loadTT (probe, UNKNOWN, accelData->m_areaP, accelData->m_areaWidthP, accelData->m_areaHeightP);
      //int rs = getThreadData(accelData, numThread)->m_ma.loadTemplate (probe.templ[0]);
      if (rs != MA_OK && rs != MA_NOT_ALL_FINGES_LOADED)
         result = SA_WRONG_TEMPLATE;
   }
   return result;
}

// fill m_rl with RL_SET data 
inline size_t fillInputRl (AccelData *accelData, RL_SET &rlSet, uint64_t maxSize)
{
   assert(accelData && accelData->m_init);
   size_t realRlSize = minAB(rlSet.size(), maxSize);
   realRlSize = minAB(realRlSize, accelData->m_rlSize);
   memset (accelData->m_rl, 0, sizeof (accelData->m_rl[0]) * realRlSize);

   RL_SET::iterator p    = rlSet.begin();
   RL_SET::iterator pEnd = rlSet.end();
   for(size_t i = 0; i < realRlSize && p != pEnd; i++, p++)
      accelData->m_rl[i].regNum = p->regNum;
   return realRlSize;
}

// fill m_rl with SS_RL_SET data 
inline size_t fillInputRl (AccelData *accelData, SS_RL_SET &rlSet, uint64_t maxSize)
{
   assert(accelData && accelData->m_init);
   size_t realRlSize = minAB(rlSet.size(), maxSize);
   realRlSize = minAB(realRlSize, accelData->m_rlSize);
   memset (accelData->m_rl, 0, sizeof (accelData->m_rl[0]) * realRlSize);

   SS_RL_SET::iterator p    = rlSet.begin();
   SS_RL_SET::iterator pEnd = rlSet.end();
   for(size_t i = 0; i < realRlSize && p != pEnd; i++, p++)
   {
      accelData->m_rl[i].regNum = p->regNum;
      memcpy(accelData->m_rl[i].galleryPair, p->galleryPair, sizeof(p->galleryPair[0]) * 10);
      memcpy(accelData->m_rl[i].score      , p->score      , sizeof(p->score[0]      ) * 10);
   }
   return realRlSize;
}

// perform one pass of final matching:
// - repeat the accelerator matching for top of recommended list, saving information about combining fingerprints
// - perfrom precise matching for best fingers saving information about matched fingers
int onePassFinalIdentifyTP (void *accelHandle, AccelSearchParam &accelParam, SearchParam &maParam, TpTemplate &probe, 
                              size_t inSize, SS_RL_SET &outRlset, unsigned int numStep)
{
   assert (accelHandle);
   AccelData *accelData = (AccelData*)accelHandle;
   assert(accelData->m_init);

   // repeat the accelerator matching for top of recommended list
   int result = SA_OK;
   unsigned int threadNum = 0;
   accelData->clear_ss_Rl();
   uint64_t regNum = 0;
   MatchResultTT matchResultTT;
#pragma omp parallel for schedule(guided) private(regNum, threadNum, result, matchResultTT) num_threads (accelData->m_numThreads)
   for(int i = 0; i < inSize; i++)
   {
      regNum = accelData->m_rl[i].regNum; 
      if (numStep == 1)
         matchResultTT.clear();
      else
      {
         memcpy(matchResultTT.score      , accelData->m_rl[i].score      , sizeof(matchResultTT.score[0]      ) * 10);
         memcpy(matchResultTT.galleryPair, accelData->m_rl[i].galleryPair, sizeof(matchResultTT.galleryPair[0]) * 10);
      }
      assert (regNum < accelData->m_realGallerySize);
      threadNum = getThreadNum (accelData);
      result = twoStepsCompareTP (accelHandle, accelParam, maParam, probe, 
                                  accelData->m_galleryAccel[regNum], accelData->m_galleryTemplate[regNum], matchResultTT,
                                  threadNum);
      if (result != SA_OK)
         continue;
      if (matchResultTT.fusionScore)
         getThreadData (accelData, threadNum)->m_ssRlSet.insert (SS_RL(regNum, matchResultTT.fusionScore, 
                                                                        matchResultTT.score, matchResultTT.galleryPair));
   }
   combine_ssThreadsRl (accelData, outRlset);
   
	return SA_OK;
}

int getNumFingerPairs(AccelData *accelData, TpTemplate &probe, RL_SET &rlSet, unsigned int outRlSize)
{
   assert(accelData);
   int numFingerPairsArray[11];
   memset (numFingerPairsArray, 0, sizeof(numFingerPairsArray));
   RL_SET::iterator p    = rlSet.begin();
   RL_SET::iterator pEnd = rlSet.end();
   for(size_t i = 0; i < outRlSize && p != pEnd; i++, p++)
   {
      uint64_t regNum = p->regNum;
      int numFingerPairs = 0;
      for (int finger = 0; finger < 10; finger++)
      {
         if (probe.templ[finger] && accelData->m_galleryTemplate[regNum].templ[finger])
            numFingerPairs++;
      }
      numFingerPairsArray[numFingerPairs]++;
   }
   int maxPairs = 0, maxIndex = 0;
   for (int numFingerPairs = 0; numFingerPairs <= 10; numFingerPairs++)
      if (numFingerPairsArray[numFingerPairs] > maxPairs) 
      {
         maxPairs = numFingerPairsArray[numFingerPairs];
         maxIndex = numFingerPairs;
      }
   return maxIndex;
}

int finalIdentifyTP (void *accelHandle, AccelSearchParam &accelParam, TpTemplate &probe,
                     RL_SET &rlSet, RL *outRl, unsigned int outRlSize)
{
   int result = SA_OK;
   if (!accelHandle || !outRl)
      return SA_NULL_POINTER;
   AccelData *accelData = (AccelData*)accelHandle;
   if (!accelData->m_realGallerySize)
      return SA_DB_NOT_LOADED;
   if (!accelData->m_initFinalMatching)
      return SA_FINAL_NOT_INITIALIZED;
   int numFingerPairs = getNumFingerPairs(accelData, probe, rlSet, outRlSize);

   AccelSearchParamEx paramEx = accelParam;
   paramEx.setFinalParam (numFingerPairs);

   // load probe template in all threads
   if ((result = loadProbeTemplate (accelData, probe)) != SA_OK)
      return result;

   // fill input RL with accel matching result
   uint64_t gallerySize = accelData->m_realGallerySize;
   uint64_t realRlSize = fillInputRl (accelData, rlSet, maxAB(gallerySize / paramEx.rl_size_divisor_1, outRlSize));
   // perform 1st stage of final matching:
   // - repeat the accelerator matching for top of recommended list, saving information about combining fingerprints
   // - perfrom precise matching for best fingers saving information about matched fingers
   SS_RL_SET outRlset;
   SearchParam maParam;
   maParam.maxAngle       = accelParam.maxAngle;
   maParam.maxAngleThumbs = accelParam.maxAngleThumbs;
   maParam.lowThreshold   = accelParam.low_threshold;
   maParam.highThreshold  = accelParam.high_threshold;
   AccelSearchParam newAccelParam;
   memcpy (&newAccelParam, &accelParam, sizeof (AccelSearchParam));
   maParam.minMatch = 1, maParam.maxMatch = 2;
   newAccelParam.searchSpeed = getFirstFinalSpeed(accelParam.searchSpeed);
   if ((result = onePassFinalIdentifyTP (accelHandle, newAccelParam, maParam, probe, realRlSize, outRlset, 1)) != SA_OK)
      return result;
   if (!paramEx.use_2nd_stage_final_matching)
   {
      fillRecomList (outRlset, outRl, outRlSize);
      buildFinalRecomList (outRl, outRlSize, accelData->m_id);
      return SA_OK;
   }
   // fill input RL with result of previous step matching
   realRlSize = fillInputRl (accelData, outRlset, maxAB(gallerySize / paramEx.rl_size_divisor_2, outRlSize));
   // perform 2nd stage of final matching:
   // - repeat the accelerator matching for top of recommended list, saving information about combining fingerprints
   // - perfrom precise matching for best fingers saving information about matched fingers
   maParam.minMatch = 4, maParam.maxMatch = 4;
   newAccelParam.numFingers = 10;
   newAccelParam.searchSpeed = getSecondFinalSpeed(accelParam.searchSpeed);
   if (newAccelParam.searchSpeed > 0) newAccelParam.searchSpeed--;
   if ((result = onePassFinalIdentifyTP (accelHandle, newAccelParam, maParam, probe, realRlSize, outRlset, 2)) != SA_OK)
      return result;
     fillRecomList (outRlset, outRl, outRlSize);

   if (!paramEx.use_3rd_stage_final_matching)
   {
      buildFinalRecomList (outRl, outRlSize, accelData->m_id);
      return SA_OK;
   }
 
   // fill input RL with result of previous step matching
   realRlSize = fillInputRl (accelData, outRlset, outRlSize);
   // perform 3nd stage of final matching:
   // - repeat the accelerator matching for top of recommended list, saving information about combining fingerprints
   // - perfrom precise matching for all avalilable fingers
   maParam.minMatch = 10, maParam.maxMatch = 10;
   newAccelParam.numFingers = 10;
   if ((result = onePassFinalIdentifyTP (accelHandle, newAccelParam, maParam, probe, realRlSize, outRlset, 3)) != SA_OK)
      return result;
  
   updateTopRecomList (outRlset, realRlSize, outRl, outRlSize);
   buildFinalRecomList (outRl, outRlSize, accelData->m_id);
      
	return SA_OK;
}


int completeIdentifyTP (void *accelHandle, AccelSearchParam &param, TpTemplate &probe, 
                        RL *outRl, unsigned int outRlsize, PersonalData *probePersonalData)
{
   if (!accelHandle || !outRl)
      return SA_NULL_POINTER;

   RL_SET rlSet;
   int result = SA_OK;
   memset (outRl, 0, sizeof(outRl[0]) * outRlsize);
   if ((result = accelIdentifyTP_ (accelHandle, param, probe, rlSet, probePersonalData)) != SA_OK)
      return result;

   return finalIdentifyTP (accelHandle, param, probe, rlSet, outRl, outRlsize);
}

int loadTP (void *accelHandle, TpTemplate &probe, PersonalData *probePersonalData)
{
   if (!accelHandle)
      return SA_NULL_POINTER;
   int result = SA_OK;
   // load accel
   if ((result = loadAccelTP (accelHandle, probe, probePersonalData)) != SA_OK) 
      return result;

   // load probe template to ma
   AccelData *accelData = (AccelData*)accelHandle;
   if (!accelData->m_initFinalMatching)
      return SA_OK;
   // load probe template in all threads
   return loadProbeTemplate (accelData, probe);
}

unsigned int getMaxStepNum()
{
   return MAX_STEPS;
}

int doStepCompareTP (void *accelHandle, AccelSearchParam &param, unsigned int threadNum, unsigned int numStep,
                         TpTemplate &probe, BYTE *galleryAccel, TpTemplate &galleryTemplate, 
                         MatchResultTT &matchResultTT)
{
   if (numStep > MAX_STEPS)
      return SA_STEP_NUM_ERR;
   if (!accelHandle || !galleryAccel)
      return SA_NULL_POINTER;
   AccelData *accelData = (AccelData*)accelHandle;

   int result = SA_OK;
   if (!numStep) // first step - do accelerator search
      return compareAccelTP_ (accelHandle, param, galleryAccel, threadNum, matchResultTT, false);

   if (!((AccelData*)accelHandle)->m_initFinalMatching)
      return SA_FINAL_NOT_INITIALIZED;

   // final matching  
  if (numStep == 1) // start final matching
     matchResultTT.clear();

   SearchParam maParam;
   maParam.maxAngle       = param.maxAngle;
   maParam.maxAngleThumbs = param.maxAngleThumbs;
   maParam.lowThreshold   = param.low_threshold;
   maParam.highThreshold  = param.high_threshold;
   AccelSearchParam newAccelParam;
   memcpy (&newAccelParam, &param, sizeof (AccelSearchParam));
   if (newAccelParam.searchSpeed > 0) newAccelParam.searchSpeed--;
   if (newAccelParam.searchSpeed > 2) newAccelParam.searchSpeed = 2;
      
   if (numStep == 1) maParam.minMatch = 1, maParam.maxMatch = 2;         
   else              maParam.minMatch = 4, maParam.maxMatch = 4, newAccelParam.numFingers = 10;

   return twoStepsCompareTP (accelHandle, newAccelParam, maParam, probe, galleryAccel, 
                                 galleryTemplate, matchResultTT, threadNum);
}




#pragma pack(pop)
} // namespace accelMatch{