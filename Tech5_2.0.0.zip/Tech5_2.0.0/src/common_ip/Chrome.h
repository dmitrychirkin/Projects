#pragma		once
#ifndef		CHROME_H
#define		CHROME_H

//	Header project file
#include		"Memory.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
		Target template class Chrome
**************************************/
template<class _Ty,class _Ax = Allocator<_Ty> >
class Chrome;

template<class _Ty,class _Alloc>
class Chrome_const_iterator : public Ranit<_Ty, typename _Alloc::diff_t,
																typename _Alloc::const_pointer, 
																typename _Alloc::const_reference>
	{//iterator for nonmutable Chrome
public:
	typedef Chrome_const_iterator<_Ty,_Alloc> Self_t;
	typedef Random_access_iterator_tag iterator_category;

   typedef typename _Alloc::pointer _Tptr;
	typedef _Ty item_t;
	typedef typename _Alloc::diff_t diff_t;
	typedef typename _Alloc::const_pointer pointer;
	typedef typename _Alloc::const_reference reference;

	Chrome_const_iterator() : Cursor()
		{//construct with null pointer
		}

	Chrome_const_iterator( _Tptr _Ptr ) : Cursor(_Ptr)
		{//construct with pointer _Ptr
		}

	reference 
      operator*() const
		   {//return designated object
		   return (*Cursor);
		   }

	pointer 
      operator->() const
		   {//return pointer to class object
		   return (&**this);
		   }

	Self_t& 
      operator++()
		   {//preincrement
		   ++Cursor;
		   return (*this);
		   }

	Self_t 
      operator++(int)
		   {//postincrement
		   Self_t _Tmp = *this;
		   ++*this;
		   return (_Tmp);
		   }

	Self_t& 
      operator--()
		   {//predecrement
		   --Cursor;
		   return (*this);
		   }

	Self_t 
      operator--(int)
		   {//postdecrement
		   Self_t _Tmp = *this;
		   --*this;
		   return (_Tmp);
		   }

	Self_t&
      operator+=( diff_t _Off )
		   {//increment by integer
		   Cursor += _Off;
		   return (*this);
		   }

	Self_t         
      operator+( diff_t _Off ) const
		   {//return this + integer
		   Self_t _Tmp = *this;
		   return (_Tmp += _Off);
		   }

	Self_t&
      operator-=( diff_t _Off )
		   {//decrement by integer
		   return (*this += -_Off);
		   }

	Self_t
      operator-( diff_t _Off ) const
		   {//return this - integer
		   Self_t _Tmp = *this;
		   return (_Tmp -= _Off);
		   }

	diff_t
      operator-( const Self_t &_Right) const
		   {//return difference of iterators
         return (Cursor - _Right.Cursor);
		   }

	reference
      operator[]( diff_t _Off ) const
		   {//subscript
		   return (*(*this + _Off));
		   }

	bool_t
      operator==( const Self_t &_Right ) const
		   {//test for iterator equality
		   return (Cursor == _Right.Cursor);
		   }

	bool_t
      operator!=( const Self_t &_Right ) const
		   {//test for iterator inequality
		   return (!(*this == _Right));
		   }

	bool_t
      operator<( const Self_t &_Right ) const
		   {//test if this < _Right
		   return (Cursor < _Right.Cursor);
		   }

	bool_t
      operator>( const Self_t &_Right ) const
		   {//test if this > _Right
		   return (_Right < *this);
		   }

	bool_t
      operator<=( const Self_t &_Right ) const
		   {//test if this <= _Right
		   return (!(_Right < *this));
		   }

	bool_t
      operator>=( const Self_t &_Right ) const
		   {//test if this >= _Right
		   return (!(*this < _Right));
		   }

	_Tptr //pointer to element in vector
      Cursor; 

	};//Chrome_const_iterator

template<class _Ty,class _Alloc>
class Chrome_iterator : public Chrome_const_iterator<_Ty,_Alloc>
	{//iterator for mutable vector
public:
	typedef Chrome_iterator<_Ty,_Alloc> Self_t;
	typedef Chrome_const_iterator<_Ty,_Alloc> Base_t;
	typedef Random_access_iterator_tag iterator_category;

	typedef _Ty item_t;
	typedef typename _Alloc::diff_t diff_t;
	typedef typename _Alloc::pointer pointer;
	typedef typename _Alloc::reference reference;

	Chrome_iterator()
		{//construct with null vector pointer
		}

	Chrome_iterator( pointer _Ptr ) : Base_t( _Ptr )
		{//construct with pointer _Ptr
		}

	reference 
      operator*() const
		   {//return designated object
		   return ((reference)**(Base_t*)this);
		   }

	pointer 
      operator->() const
		   {//return pointer to class object
		   return (&**this);
		   }

	Self_t& 
      operator++()
		   {//preincrement
		   ++*(Base_t*)this;
		   return (*this);
		   }

	Self_t 
      operator++(int)
		   {//postincrement
		   Self_t _Tmp = *this;
		   ++*this;
		   return (_Tmp);
		   }

	Self_t& 
      operator--()
		   {//predecrement
		   --*(Base_t*)this;
		   return (*this);
		   }

	Self_t 
      operator--(int)
		   {//postdecrement
		   Self_t _Tmp = *this;
		   --*this;
		   return (_Tmp);
		   }

	Self_t&
      operator+=( diff_t _Off )
		   {//increment by integer
		   *(Base_t*)this += _Off;
		   return (*this);
		   }

	Self_t
      operator+( diff_t _Off ) const
		   {//return this + integer
		   Self_t _Tmp = *this;
		   return (_Tmp += _Off);
		   }

	Self_t&
      operator-=( diff_t _Off )
		   {//decrement by integer
		   return (*this += -_Off);
		   }

	Self_t
      operator-( diff_t _Off ) const
		   {//return this - integer
		   Self_t _Tmp = *this;
		   return (_Tmp -= _Off);
		   }

	diff_t
      operator-( const Base_t &_Right ) const
		   {//return difference of iterators
		   return (*(Base_t*)this - _Right);
		   }

   reference
      operator[]( diff_t _Off ) const
		   {//subscript
		   return (*(*this + _Off));
		   }

	};//Chrome_iterator

template<class _Ty,class _Alloc>
class Chrome_base
	{//base class for vector to hold allocator allocator_value
protected:
	Chrome_base( _Alloc _Al = _Alloc()) : _Alval(_Al)
		{//construct allocator from _Al
		}
	typedef typename _Alloc::template rebind<_Ty>::other _Alty;

	_Alty //allocator object for values
      _Alval;
	};

template<class _Ty,class _Ax>
class Chrome : public Chrome_base<_Ty,_Ax>
	{//various size array of objects or values
public:
	typedef Chrome<_Ty,_Ax> Self_t;
	typedef Chrome_base<_Ty,_Ax> Base_t;
	typedef typename Base_t::_Alty _Alloc;

	typedef _Alloc allocator_type;
	typedef typename _Alloc::diff_t diff_t;
	typedef typename _Alloc::pointer pointer;
	typedef typename _Alloc::const_pointer const_pointer;
	typedef typename _Alloc::reference reference;
	typedef typename _Alloc::const_reference const_reference;
	typedef typename _Alloc::item_t item_t;

	typedef Chrome_iterator<_Ty,_Alloc> iterator;
	typedef Chrome_const_iterator<_Ty,_Alloc> const_iterator;

	//----------------------------------
	//	Constructors and destructor
	//----------------------------------
	Chrome()	: Base_t()
		{//construct empty vector
		buy(0);
		}

	explicit Chrome( const _Alloc &_Al ) : Base_t(_Al)
		{//construct empty vector with allocator
		buy(0);
		}

	~Chrome() _NOTHROW
		{// destroy the object
		tidy();
		}

	void_t
      reserve( size_t _Count )
		   {//determine new minimum length of allocated storage
		   if (max_size() < _Count)
			   _xlen();
		   else
		   if (capacity() < _Count)
			   {//not enough room, reallocate
			   pointer 
               _Ptr = this->_Alval.allocate( _Count );

			   try
               {
				   u_move( First,Last,_Ptr );
				   }
			   catch(...)
				   {
				   this->_Alval.deallocate( _Ptr,_Count ); 
				   throw;
				   }
			   size_t 
               _Size = size();

			   if (First != pointer())
				   {// only deallocate old array
				   this->_Alval.deallocate( First,End - First );
				   }
			   End   = _Ptr + _Count;
			   Last  = _Ptr + _Size;
			   First = _Ptr;
			   }
		   }

	iterator
      begin() _NOTHROW
		   {//return iterator for beginning of mutable sequence
		   return iterator( First );
		   }

	const_iterator
      begin() const _NOTHROW
		   {//return iterator for beginning of nonmutable sequence
		   return const_iterator( First );
		   }

	iterator
      end() _NOTHROW
		   {//return iterator for end of mutable sequence
		   return iterator( Last );
		   }

	const_iterator
      end() const _NOTHROW
		   {//return iterator for end of nonmutable sequence
		   return const_iterator( Last );
		   }

	size_t 
      size() const _NOTHROW
		   {//return length of sequence
		   return size_t(Last - First);
		   }

	size_t
      capacity() const _NOTHROW
		   {//return current length of allocated storage
		   return size_t(End - First);
		   }

	size_t
      max_size() const _NOTHROW
		   {//return maximum possible length of sequence
		   return (this->_Alval.max_size());
		   }

	bool_t
      empty() const _NOTHROW      
		   {//test if sequence is empty
		   return (First == Last);
		   }

	const_pointer
      it( size_t _Pos ) const
		   {//subscript nonmutable sequence
		   return (First + _Pos);
		   }

	pointer
      it( size_t _Pos )
		   {//subscript mutable sequence
		   return (First + _Pos);
		   }

	const_reference
      at( size_t _Pos ) const
		   {//subscript nonmutable sequence with checking
		   if (size() <= _Pos)
			   _xran();

         return (*it(_Pos));
		   }

	reference 
      at( size_t _Pos )
		   {//subscript mutable sequence with checking
		   if (size() <= _Pos)
			   _xran();

         return (*it(_Pos));
		   }

	const_reference 
      operator[]( size_t _Pos ) const _NOTHROW
		   {//subscript nonmutable sequence
         return (*it(_Pos));
		   }

	reference 
      operator[]( size_t _Pos ) _NOTHROW
		   {//subscript mutable sequence
         return (*it(_Pos));
		   }

	pointer 
      data() _NOTHROW
		   {//get address of first element
		   return First;
		   }

	const_pointer 
      data() const _NOTHROW
		   {//get address of first element
		   return First;
		   }
                                                                           
	void_t 
      push_back( const _Ty &_Val )
		   {//insert element at end
			if(Last == End)
				room(1);

			_construct_val( this->_Alval,Last,_Val ); ++Last;
		   }

	void_t 
      pop_back()
		   {//erase last element
         if (!empty())
			   {
			   _destroy_val( this->_Alval,Last - 1 ); --Last;
            }
		   }

	void_t
      tidy()
		   {//free all storage
		   if (First != pointer())
			   {//something to free, destroy and deallocate it
			   destroy( First,Last ); this->_Alval.deallocate( First,End - First );
			   }
		   First = pointer();
         Last  = pointer();
         End   = pointer();
		   }

private:
	bool_t
      buy( size_t _Capacity )
		   {//allocate array with _capacity elements
		   First = pointer();
         Last  = pointer();
         End   = pointer();

		   if(_Capacity == 0)
			   return false;

		   if(_Capacity > max_size())
			   _xlen();
		   else
			   {//nonempty array, allocate storage
			   First = this->_Alval.allocate( _Capacity );
			   Last  = First;
			   End   = First + _Capacity;
			   }
		   return true;
		   }

	void_t
      destroy( pointer _First,pointer _Last )
		   {//destroy [_First, _Last) using allocator
         _destroy_range( _First,_Last,this->_Alval );
		   }

	size_t
      grow( size_t _Count ) const _NOTHROW
		   {//grow by part or at least to _Count
		   size_t 
            _Capacity = capacity();
		      _Capacity = max_size() - _Capacity/4 < _Capacity ? 0 : _Capacity + _Capacity/4;

		   if(_Capacity < _Count)
			   _Capacity = _Count; return _Capacity;
         }

	void_t
      room( size_t _Count )
		   {//ensure room for _Count new elements, grow exponentially
		   size_t 
            _Size = size();

		   if(_Size > max_size() - _Count)
			   _xlen();
		   else
         if((_Size += _Count) <= capacity())
			   ;
		   else
			   reserve( grow( _Size ));
		   }

private:
	template<class _Iter> pointer
      u_copy( _Iter _First,_Iter _Last,pointer _Ptr )
		   {//copy initializing [_First,_Last), using allocator
		   return (_uninitialized_copy( _First,_Last,_Ptr,this->_Alval ));
		   }

	template<class _Iter> pointer
      u_move( _Iter _First,_Iter _Last,pointer _Ptr )
		   {//move initializing [_First, _Last), using allocator
		   return (_uninitialized_move( _First,_Last,_Ptr,this->_Alval ));
		   }

	static void_t
      _xlen()
		   {//report a length_error
		   throw Length_error( "Chrome<T> too long" );
		   }

	static void_t 
      _xran()
		   {//report an out_of_range error
		   throw Out_of_range( "Invalid Chrome<T> subscript" );
		   }

private:
	pointer 
      First, // pointer to beginning of array
	   Last,  // pointer to current end of sequence
	   End;   // pointer to end of array

	};//Chrome

_ESK_END
#pragma pack(pop)
#endif//CHROME_H
