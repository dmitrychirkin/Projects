#pragma		once
#ifndef		MEMORY_H
#define		MEMORY_H

//	Use project headers
#include		"Aidant.h"
#include		"Anonim.h"

#pragma pack(push,_ESK_PACKING)
/**************************************
		Declarations new & delete
**************************************/
#if defined (linux)
#define GTS ESK
#else//global type scope
#define GTS
#endif

//-------------------------------------
// New - delete pairs
//-------------------------------------
void*
   operator new  ( GTS::size_t ) _NOTHROW;
void*
   operator new[]( GTS::size_t ) _NOTHROW;

void
   operator delete  ( void* ) _NOTHROW;
void
   operator delete[]( void* ) _NOTHROW;

#ifndef __PLACEMENT_NEW_INLINE
#define __PLACEMENT_NEW_INLINE
inline void*
   operator new( GTS::size_t,void *_Where ) _NOTHROW
	   {//construct array with placement at _Where
	   return (_Where);
	   }

inline void
   operator delete( void*,void* ) _NOTHROW
	   {//delete if placement new fails
	   }
#endif

#ifndef __PLACEMENT_VEC_NEW_INLINE
#define __PLACEMENT_VEC_NEW_INLINE
inline void*
   operator new[]( GTS::size_t,void *_Where ) _NOTHROW
	   {//construct array with placement at _Where
	   return (_Where);
	   }

inline void
   operator delete[]( void*,void* ) _NOTHROW
	   {//delete if placement array new fails
	   }
   #endif

#ifndef __NOTHROW_T_DEFINED
#define __NOTHROW_T_DEFINED
_ESK_BEGIN
struct nothrow_t
	{//placement new tag type to suppress exceptions
	};
_ESK_END

void*
   operator new  ( GTS::size_t,const ESK::nothrow_t& ) _NOTHROW;
void*
   operator new[]( GTS::size_t,const ESK::nothrow_t& ) _NOTHROW;

void
   operator delete  ( void *,const ESK::nothrow_t& ) _NOTHROW;
void
   operator delete[]( void *,const ESK::nothrow_t& ) _NOTHROW;
#endif

_ESK_BEGIN
/**************************************
		Allocator generic functions
**************************************/
typedef void_t(* new_handler)();
                 new_handler set_new_handler( new_handler ) _NOTHROW;
                 new_handler get_new_handler() _NOTHROW;

template<class _Ty> inline _Ty*
   _allocate( size_t _Count,_Ty* )
	   {//allocate storage for _Count elements of type _Ty
      void_t *_Ptr = Null;

	   if(_Count == 0)
		   ;
	   else 
	   if (((size_t)(-1)/sizeof (_Ty) < _Count) || (_Ptr = ::operator new(_Count * sizeof (_Ty))) == Null)
		   throw Bad_alloc();

	   return ((_Ty*)_Ptr);
	   }

template<class _Ty,class _Tp> inline void_t
   _construct( _Ty *_Ptr,const _Tp &_Val )
	   {//construct object at _Ptr with value _Val
      void_t *_Vptr = _Ptr; new (_Vptr) _Ty(_Val);
	   }

template<class _Ty> inline void_t
   _construct( _Ty *_Ptr )
	   {//construct object at _Ptr with default value
	   void_t *_Vptr = _Ptr; new (_Vptr) _Ty();
	   }

template<class _Ty> inline void_t
   _destroy( _Ty *_Ptr )
	   {//destroy object at _Ptr
      if (_Ptr)
         (_Ptr)->~_Ty();
      else
         throw Invalid_argument();
	   }

template<> inline void_t
   _destroy( char* )
	   {//destroy a char (do nothing)
	   }

template<> inline void_t
   _destroy( wchar_t* )
	   {//destroy a wchar_t (do nothing)
	   }

template<class _Ty> inline void_t
   _delete( _Ty *_Ptr )
	   {//delete routine
	   ::operator delete(_Ptr);
	   }

//-------------------------------------
// Templates to destroy range
//-------------------------------------
template<class _Alloc> inline void_t
   _destroy_range( typename _Alloc::pointer _First,
                   typename _Alloc::pointer _Last,_Alloc &_Al )
	   {//destroy [_First, _Last)
	   _destroy_range( _First,_Last,_Al,_ptr_cat( _First,_Last ));
	   }

template<class _Alloc> inline void_t
   _destroy_range( typename _Alloc::pointer _First,                                 
                   typename _Alloc::pointer _Last,_Alloc &_Al,Nonscalar_ptr_iterator_tag )
	   {//destroy [_First, _Last), arbitrary type
	   for (; _First != _Last; ++_First)
		   _Al.destroy( _First );
	   }

template<class _Alloc> inline void_t
   _destroy_range( typename _Alloc::pointer,
                   typename _Alloc::pointer,_Alloc &,Scalar_ptr_iterator_tag )
	   {//destroy [_First, _Last), scalar type (do nothing)
	   }

//-------------------------------------
// Templates to get address
//-------------------------------------
template<class _Ty> inline _Ty*
   addressof( _Ty &_Val )
	   {//return address of _Val
	   return ((_Ty *) &(char&)_Val);
	   }

/**************************************
			Tags for Allocator
**************************************/
template<class _Ty>
struct Allocator_base
	{//base class for generic allocators
	typedef _Ty item_t;
	};

template<class _Ty>
struct Allocator_base<const _Ty>
	{//base class for generic allocators for const _Ty
	typedef _Ty item_t;
	};

//-------------------------------------
// Template class Allocator
//-------------------------------------
template<class _Ty>
class Allocator : public Allocator_base<_Ty>
	{//generic allocator for objects of class _Ty
public:
	typedef Allocator_base<_Ty> Self_t;
	typedef typename Self_t::item_t item_t;
	typedef item_t* pointer;
	typedef item_t& reference;
	typedef const item_t* const_pointer;
	typedef const item_t& const_reference;
	typedef Ptrdiff_t diff_t;
					
	template<class _Other>
	struct rebind
		{//convert an allocator<_Ty> to an allocator <_Other>
		typedef Allocator<_Other> other;
		};

	pointer 
      address( reference _Val) const _NOTHROW
		   {//address of mutable _Val
         return addressof( _Val );
		   }

	const_pointer 
      address( const_reference _Val) const _NOTHROW
		   {//address of nonmutable _Val
         return addressof( _Val );
		   }

	Allocator() _NOTHROW
		{//construct default allocator (do nothing)
		}

	Allocator( const Allocator<_Ty>& ) _NOTHROW
		{//construct by copying (do nothing)
		}

	template<class _Other>
	Allocator( const Allocator<_Other>& ) _NOTHROW
		{//construct from a related allocator (do nothing)
		}

	template<class _Other> Allocator<_Ty>& 
      operator=( const Allocator<_Other>& )
		   {//assign from a related allocator (do nothing)
		   return (*this);
		   }

	void_t 
      deallocate( pointer _Ptr,size_t )
		   {//deallocate object at _Ptr, ignore size
		   _delete( _Ptr );
		   }

	pointer
      allocate( size_t _Count )
		   {//allocate array of _Count elements
		   return _allocate( _Count,pointer());
		   }

	pointer
      allocate( size_t _Count,const void_p )
		   {//allocate array of _Count elements, ignore hint
		   return allocate( _Count );
		   }

	void_t
      construct( pointer _Ptr )
		   {//default construct object at _Ptr
         _construct( _Ptr );
		   }

	void_t
      construct( pointer _Ptr,const _Ty &_Val)
		   {//construct object at _Ptr with value _Val
         _construct( _Ptr,_Val );
		   }

	void_t
      destroy( pointer _Ptr )
		   {//destroy object at _Ptr
		   _destroy( _Ptr );
		   }

	size_t
      max_size() const _NOTHROW
		   {//estimate maximum array size
		   return ((size_t)(-1)/sizeof(_Ty));
		   }

	};//Allocator

template<class _Ty,class _Other> inline bool_t
   operator==( const Allocator<_Ty>&,const Allocator<_Other>& ) _NOTHROW
	   {//test for allocator equality (always true)
	   return (true);
	   }

template<class _Ty,class _Other> inline bool_t
   operator!=( const Allocator<_Ty>&,const Allocator<_Other>& ) _NOTHROW
	   {//test for allocator inequality (always false)
	   return (false);
	   }

//-------------------------------------
// Template functions using allocator
//-------------------------------------
template<class _Alloc,class _Ty,class _Tp> inline void_t
   _construct_val( _Alloc &_Val,_Ty *_Dst,const _Tp &_Src )
	   {//construct using allocator
	   _Val.construct( _Dst,_Src );
	   }

template<class _Alloc,class _Ty> inline void_t
   _destroy_val( _Alloc &_Val,_Ty *_Dst )
	   {//destroy using allocator
	   _Val.destroy( _Dst );
	   }

//-------------------------------------
// Uninitialized copy using allocator
//-------------------------------------
template<class _InIt,class _FwdIt,class _Alloc> inline _FwdIt
   _uninit_copy( _InIt _First,_InIt _Last,_FwdIt _Dest,_Alloc &_Al,Nonscalar_ptr_iterator_tag )
	   {// copy [_First,_Last) to raw _Dest, using _Al, arbitrary type
	   _FwdIt _Next = _Dest;
	   try{
		   for (; _First != _Last; ++_Dest,++_First)
            _construct_val( _Al,_Dest,*_First );
		   }
	   catch(...)
		   {
		   for (; _Next != _Dest; ++_Next)
            _destroy_val( _Al,_Next );
		   throw;
		   }
	   return (_Dest);
	   }

template<class _InIt,class _FwdIt,class _Alloc> inline _FwdIt
   _uninit_copy( _InIt _First,_InIt _Last,_FwdIt _Dest,_Alloc &_Al,Scalar_ptr_iterator_tag )
	   {//copy [_First,_Last) to raw _Dest, using _Al, scalar type
	   return (_uninit_copy( _First,_Last,_Dest,_Al,Nonscalar_ptr_iterator_tag()));
	   }

template<class _InIt,class _FwdIt> inline _FwdIt*
   _uninit_copy( _InIt *_First,_InIt *_Last,_FwdIt *_Dest,Allocator<_FwdIt> &,Scalar_ptr_iterator_tag )
	   {//non-overlapping copy [_First,_Last) to raw _Dest, (const) scalar type
	   size_t _Count = (size_t)(_Last - _First);
	   return ((_FwdIt*)_mem_move( &*_Dest,&*_First,_Count*sizeof(*_First)) + _Count);
	   }

template<class _InIt,class _FwdIt> inline _FwdIt*
   _uninit_copy( _InIt *_First,_InIt *_Last,_FwdIt *_Dest,Allocator<const _FwdIt> &,Scalar_ptr_iterator_tag)
	   {//non-overlapping move copy [_First,_Last) to raw _Dest, (const) scalar type
	   size_t _Count = (size_t)(_Last - _First);
	   return ((_FwdIt*)_mem_move( &*_Dest,&*_First,_Count*sizeof(*_First)) + _Count);
	   }

template<class _InIt,class _FwdIt,class _Alloc> inline _FwdIt
   _uninitialized_copy( _InIt _First,_InIt _Last,_FwdIt _Dest,_Alloc &_Al )
	   {//copy [_First,_Last) to raw _Dest, using _Al
	   return (_uninit_copy( _First,_Last,_Dest,_Al,_ptr_cat( _First,_Dest )));
	   }

//-------------------------------------
// Uninitialized move using allocator
//-------------------------------------
template<class _InIt,class _FwdIt,class _Alloc,class _Valty> inline _FwdIt
   _uninit_move( _InIt _First,_InIt _Last,_FwdIt _Dest,_Alloc &_Al,_Valty *,Nonscalar_ptr_iterator_tag )
	   {//move [_First, _Last) to raw _Dest, using _Al, arbitrary type
	   _FwdIt _Next = _Dest;

	   try{
	      for (; _First != _Last; ++_Dest, ++_First)
		      _construct_val( _Al,_Dest,(_Valty)*_First );
         }
      catch(...)
         {
	      for (; _Next != _Dest; ++_Next)
		      _destroy_val( _Al,_Next );
         throw;
         }
	   return (_Dest);
	   }

template<class _InIt,class _FwdIt,class _Alloc,class _Valty> inline _FwdIt
   _uninit_move( _InIt _First,_InIt _Last,_FwdIt _Dest,_Alloc &_Al,_Valty *,Scalar_ptr_iterator_tag )
	   {//move [_First, _Last) to raw _Dest, using _Al, scalar type
	   return (_uninit_move( _First,_Last,_Dest,_Al,(_Valty *)0,Nonscalar_ptr_iterator_tag()));
	   }

template<class _InIt,class _FwdIt,class _Valty> inline _FwdIt*
   _uninit_move( _InIt *_First,_InIt *_Last,_FwdIt *_Dest,Allocator<_FwdIt> &,_Valty *,Scalar_ptr_iterator_tag )
	   {//non-overlapping move [_First, _Last) to raw _Dest, scalar type
	   size_t _Count = (size_t)(_Last - _First);
	   return ((_FwdIt*)_mem_move( &*_Dest,&*_First,_Count*sizeof(*_First)) + _Count);
	   }

template<class _InIt,class _FwdIt,class _Alloc> inline _FwdIt
   _uninitialized_move( _InIt _First,_InIt _Last,_FwdIt _Dest,_Alloc &_Al )
	   {//move [_First, _Last) to raw _Dest, using _Al
	   return (_uninit_move( _First,_Last,_Dest,_Al,_val_type(_First),_ptr_cat( _First,_Dest )));
	   }

//-------------------------------------
// Uninitialized fill n with allocator
//-------------------------------------      
template<class _FwdIt,class _Diff,class _Tval,class _Alloc> inline void_t
   _uninit_fill_n( _FwdIt _First,_Diff _Count,const _Tval &_Val,_Alloc &_Al,Nonscalar_ptr_iterator_tag )
	   {//copy _Count *_Val to raw _First, using _Al, arbitrary type
	   _FwdIt _Next = _First;
	   try{
		   for (; 0 < _Count; --_Count, ++_First) 
            _construct_val( _Al,_First,_Val );
		   }
	   catch(...)
		   {
		   for (;_Next != _First; ++_Next) 
            _destroy_val( _Al,_Next );
		   throw;
		   }
	   }

template<class _FwdIt,class _Diff,class _Tval,class _Alloc> inline void_t
   _uninit_fill_n( _FwdIt _First,_Diff _Count,const _Tval &_Val,_Alloc &_Al,Scalar_ptr_iterator_tag )
	   {//copy _Count *_Val to raw _First, using _Al, arbitrary type
      _uninit_fill_n( _First,_Count,_Val,_Al,Nonscalar_ptr_iterator_tag());
	   }

template<class _FwdIt,class _Diff,class _Tval> inline void_t
   _uninit_fill_n( _FwdIt *_First,_Diff _Count,const _Tval &_Val,Allocator<_FwdIt> &,Scalar_ptr_iterator_tag )
	   {//copy _Count *_Val to raw _First, using _Al, scalar type
	   _fill_n( _First,_Count,_Val );
	   }

template<class _FwdIt,class _Diff,class _Tval> inline void_t
   _uninit_fill_n( _FwdIt *_First,_Diff _Count,const _Tval &_Val,Allocator<const _FwdIt>&,Scalar_ptr_iterator_tag )
	   {//copy _Count *_Val to raw _First, using _Al, scalar type
	   fill_n( _First,_Count,_Val );
	   }

template<class _FwdIt,class _Diff,class _Tval,class _Alloc> inline void_t
   _uninitialized_fill_n( _FwdIt _First,_Diff _Count,const _Tval &_Val,_Alloc &_Al)
	   {	// copy _Count *_Val to raw _First, using _Al
	   _uninit_fill_n( _First,_Count,_Val,_Al,_ptr_cat( _First,_First ));
	   }

/**************************************
				Class Autop
**************************************/
template<class _Ty>
class Autop;

template<class _Ty>
struct Autor
	{//proxy reference for Autop copying
   typedef _Ty* pointer;

	explicit Autor( _Ty *_Rhs ) : Reference(_Rhs)
		{//construct from generic auto pointer
		}

	_Ty*
      Reference;	//generic pointer 
	};

template<class _Ty>
class Autop
	{//wrap an object pointer to ensure destruction
public:
   typedef Autop<_Ty> Self_t;
	typedef _Ty  element_t;
   typedef _Ty* pointer;

	explicit Autop( _Ty *_Ptr = pointer()) _NOTHROW : Pointer(_Ptr)
		{//construct from object pointer
		}

   Autop( Self_t &_Rhs ) _NOTHROW : Pointer(_Rhs.release())
		{//construct by assuming pointer from _Rhs auto pointer
		}

	Autop( Autor<_Ty> _Rhs ) _NOTHROW
		{//construct by assuming pointer from _Rhs auto reference and release the old
		_Ty *_Ptr = _Rhs.Reference;
		            _Rhs.Reference = Autor<_Ty>::pointer(); Pointer = _Ptr;
		}

	template<class _Other>
	   operator Autop<_Other>() _NOTHROW
		   {//convert to compatible auto pointer
		   return (Autop<_Other>(*this));
		   }

	template<class _Other>
	   operator Autor<_Other>() _NOTHROW
		   {//convert to compatible auto reference and test implicit conversion
		   _Other *_Ptr = Pointer;
                        Pointer = pointer(); return (Autor<_Other>()(_Ptr));
		   }
   
	template<class _Other> Self_t&
      operator=( Autop<_Other> &_Rhs ) _NOTHROW
		   {//assign compatible _Rhs (assume pointer)
		   reset( _Rhs.release());
		   return (*this);
		   }
   
	template<class _Other>
   Autop( Autop<_Other> &_Rhs ) _NOTHROW : Pointer(_Rhs.release())
		{//construct by assuming pointer from _Rhs
		}

	Self_t& 
      operator=( Self_t &_Rhs ) _NOTHROW
		   {//assign compatible _Rhs (assume pointer)
		   reset( _Rhs.release()); 
         return (*this);
		   }

	Self_t& 
      operator=( Autor<_Ty> &_Rhs ) _NOTHROW
		   {//assign compatible reference (assume pointer), release old, set new
		   _Ty *_Ptr = _Rhs.Reference;
		               _Rhs.Reference = Autor<_Ty>::geneic(); reset(_Ptr); 
         return (*this);
		   }

	~Autop() _NOTHROW
		{//destroy the object
	   delete Pointer;
             Pointer = Null;
		}

	_Ty& 
      operator*() const _NOTHROW
		   {//return designated value
		   return(*get());
		   }

	_Ty* 
      operator->() const _NOTHROW
		   {//return pointer to class object
		   return (get());
		   }

	_Ty*
      get() const _NOTHROW
		   {//return wrapped pointer
		   return (Pointer);
		   }

	_Ty*
      release() _NOTHROW
		   {//return wrapped pointer and give up ownership
		   _Ty *_Tmp = Pointer;
						   Pointer = pointer(); 
         return (_Tmp);
		   }

	_Ty*
      reset( _Ty *_Ptr = pointer())
		   {//destroy designated object and store new pointer
		   if(Pointer && Pointer != _Ptr) 
            delete Pointer; 

         return (Pointer = _Ptr);
		   }

	operator bool_t() const _NOTHROW
		{//test if an object pointer exist
		return (get() != pointer());
		}

private: //the wrapped object pointer
	_Ty* 
      Pointer;

	};//Autop

template<class _Ty>
class Aviso : public Autop<_Ty>  
	{//wrap an object pointer (reuse known size)
   typedef Autop<_Ty> Base;
   typedef typename   Base::pointer pointer;

public:
	Aviso() : Size()
		{//constructor
		}

	_Ty&
      operator[]( size_t _Pos )
		   {//subscript mutable sequence
         if(size() <= _Pos)
            _xran();

	      return (*(Base::get() + _Pos));
		   }

	_Ty*
      allocate( size_t _Val )
		   {//allocate memory
		   try
			   {
			   if(Base::get() && _Val <= size())
				   return  Base::get();

			   if(_Val && Base::reset( _allocate( _Val,pointer())))
				   {//if success
				   Size = _Val;
				   return  Base::get();
				   }
			   return pointer();
			   }
		   catch( ... )
			   {//caution!
			   return pointer();
			   }
		   }

	size_t
      size() const _NOTHROW
		   {//return length of sequence
		   return Size;
		   }

private:
	static void_t 
      _xran()
		   {//report an out_of_range error
		   throw Out_of_range( "Invalid Aviso<T> subscript" );
		   }

private:
	size_t	
		Size;	//memory size

	};//Aviso

_ESK_END
#pragma pack(pop)
#endif//MEMORY_H
