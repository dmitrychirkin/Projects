#pragma		once
#ifndef		EXCEPT_H
#define	   EXCEPT_H

//	Header project file
#include		"Eskdef.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
			Class Exception
**************************************/
class Exception
	{//base of all exceptions
public:
	explicit Exception( const char *_Message = "unknown" ) _NOTHROW : _Ptr(_Message)
		{//construct from message string
		}

	Exception( const Exception &_Right ) _NOTHROW : _Ptr(_Right._Ptr)
		{//construct by copying _Right
		}

	Exception& operator=( const Exception &_Right ) _NOTHROW
		{//assign _Right
		_Ptr = _Right._Ptr;
		return (*this);
		}

	virtual ~Exception()
		{//destroy the object
		}

	virtual const char*
      what() const _NOTHROW
		   {//Pointer to message string
         return (_Ptr != 0 ? _Ptr : "unknown exception");
		   }

	void_t
      raise() const
		   {//raise first the protected virtual exception then this exception
		   doraise();
		   throw (*this);
		   }

protected:
	virtual void_t
      doraise() const
		   {//perform class-specific exception handling
		   }

protected:
	const char
      *_Ptr;	// the message Pointer
	};

//-------------------------------------
//	List of classes based on exception
//-------------------------------------
class Bad_exception : public Exception
	{//base of all bad exceptions
public:
	Bad_exception( const char *_Message = "bad exception" ) _NOTHROW : Exception(_Message)
		{//construct from message string
		}

	virtual ~Bad_exception() _NOTHROW
		{//destroy the object
		}

	};//Bad_exception

class Bad_alloc : public Exception
	{//base of all bad allocation exceptions
public:
	Bad_alloc( const char *_Message = "bad allocation" ) _NOTHROW : Exception(_Message)
		{//construct from message
		}

	virtual ~Bad_alloc() _NOTHROW
		{// destroy the object
		}

	};//Bad_alloc

//-------------------------------------
// Errors can be controled by program
//-------------------------------------
class Logic_error : public Exception
	{//base of all logic exceptions
public:
	explicit Logic_error( const char *_Message = "logic error" ) : Exception(_Message)
		{//construct from message
		}

	};//Logic_error

class Domain_error : public Logic_error
	{//base of all domain-error exceptions
public:
	explicit Domain_error( const char *_Message = "domain error" ) : Logic_error(_Message)
		{//construct from message string
		}

	};//Dommain_error

class Invalid_argument : public Logic_error
	{// base of all invalid-argument exceptions
public:
	explicit Invalid_argument( const char *_Message = "invalid argument" ) : Logic_error(_Message)
		{//construct from message string
		}

	};//Invalid_argument

class Length_error : public Logic_error
	{//base of all length-error exceptions
public:
	explicit Length_error( const char *_Message = "length error" ) : Logic_error(_Message)
		{//construct from message string
		}

	};//Length_error

class Out_of_range : public Logic_error
	{//base of all out-of-range exceptions
public:
	explicit Out_of_range( const char *_Message = "out of range" ) : Logic_error(_Message)
		{//construct from message string
		}

	};//Out_of_range

//-------------------------------------
// Errors are not controled by program
//-------------------------------------
class Runtime_error : public Exception
	{//base of all runtime-error exceptions 
public:
	explicit Runtime_error( const char *_Message = "runtime error" ) : Exception(_Message)
		{//construct from message string
		}

	};//Runtime_error

class Range_error : public Runtime_error
	{//base of all out-of-range exceptions
public:
	explicit Range_error( const char *_Message = "range error" ) : Runtime_error(_Message)
		{//construct from message string
		}

	};//Range_error

/**************************************
		  Dispatcher of errors
**************************************/
struct Say
	{//functor for error messages
   enum
      {//string quantity
      SIZE = 50
      };

	const char*
      operator()( iint_t _Ind ) const _NOTHROW
		   {
         static Exception
            _Myerror;
		   static const char*
            _Message[SIZE] =
			      {	 
               /* image processing */
               "Bad library version or engine is not loaded",
			      "Wrong identification CPU code or session time out",
			      "Image types are: L-latenprint, F-fingerprint, P-palmprint, T-tenprint, V-view",
			      "Invalid dot per inch",
			      "",
			      "Bad pointer to submit image",            //5
			      "Can not allocate accelerators to load image",
			      "Image size is too large to load image",
			      "Image size is too small to load image",
			      "Can not allocate memory to load image",
			      "All image sizes must be positive",       //10
			      "Pattern has not enough grey levels",
			      "",
			      "",
			      "",
               /* latentprint editor */
               "Image patch the same size",              //15
			      "Image patch too large",          
			      "Image patch too small",
			      "Not enough memory",
			      "",
               "Can not zoom in image",                  //20
			      "Used the hole image",
			      "",
			      "",
			      "",
               "",                                       //25
			      "",
			      "",
			      "",
			      "",
               /* matcher */
               "Can not allocate matcher",               //30
               "Can not unpack or allocate template",
               "Bad library version",
               "Matcher is not created",
               "Test if rated thread number limited",
               "",                                       //35
               "",
               "",
               "",
               "",
               "",                                       //40
               "",
               "",
               "",
               "",
               "",                                       //45
               "",
               "",
               "",
               "Ready",
			      };

         if (0 <= _Ind && _Ind < SIZE)
            {//test if new message
            _Myerror = Exception( _Message[_Ind]);
            }
         return _Myerror.what();
		   }
	};//My_message

inline const char*
   say( iint_t _Ind = -1 ) _NOTHROW
	   {//adapter: replica
	   return (Say()( _Ind ));
	   }

inline bool_t
   fail( iint_t _Ind ) _NOTHROW
	   {//adapter
      say( _Ind ); return false;
	   }

inline bool_t
   ready() _NOTHROW
	   {//adapter
      say( Say::SIZE - 1 ); return true;
	   }

_ESK_END
#pragma pack(pop)
#endif//EXCEPT_H
