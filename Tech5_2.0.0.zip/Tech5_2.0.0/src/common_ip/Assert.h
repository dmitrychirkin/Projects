#pragma		once
#ifndef		ASSERT_H
#define		ASSERT_H

//	Header project file
#include		"Eskdef.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
#ifdef _UPBUG
   extern void_t  affirmation( bool_t _Expr,char *_File,iint_t _Line );
#endif

//-------------------------------------
// Detect redifinitions
//-------------------------------------
#ifdef AFFIRM
	#pragma message( "AFFIRM redifinition in " __FILE__,__LINE__ )
#endif
#ifdef AFFBIF
	#pragma message( "AFFBIF redifinition in " __FILE__,__LINE__ )
#endif
#ifdef AFFBUG
	#pragma message( "AFFBUG redifinition in " __FILE__,__LINE__ )
#endif

//-------------------------------------
// Debug helper
//-------------------------------------
#ifdef _UPBUG
   #define AFFBIF( _Cond,_Expr ) if(_Cond) affirmation((_Expr) != 0,__FILE__,__LINE__)
   #define AFFIRM( _Expr )                 affirmation((_Expr) != 0,__FILE__,__LINE__)
	#define AFFBUG                          affirmation((false)     ,__FILE__,__LINE__)
#else
	#define AFFBIF( _Cond,_Expr )
	#define AFFIRM( _Expr )
	#define AFFBUG
#endif

_ESK_END
#pragma pack(pop)
#endif//ASSERT_H
