#pragma		once
#ifndef		VIRTUE_H
#define		VIRTUE_H

//	Use project headers
#include		"Eskdef.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
//-------------------------------------
// Type of linkage's events
//-------------------------------------
enum Topology_events
   {//overevent
   E0	=    0,		   //nothing
   Ei	=    4,		   //interruption
   Ec	=    8,		   //cross
   Eu =   16,        //hidrance

   //for bifurcation
   E1	=    1,		   //right bifurcation opening
   E2	=    2,		   //left bifurcation openning
   E3	=	  3,		   //bifurcation
   E5	=    5,		   //right bifurcation closing
   E6	=    6,		   //left bifurcation closing
   E7	=    7,		   //bifurcation anti clockwize
   Eb	=   11,		   //bifurcation clockwize

   //for ending
   E9	=    9,		   //right beginning
   Ea	=   10,		   //left beginning
   Ed	=   13,		   //right ending
   Ee	=   14,		   //left ending
   Ef	=   15,		   //ending
   };

//-------------------------------------
// Opening or closing event
//-------------------------------------
const
struct _LNX_PACKING CloseOpen : public Fictitious
	{//classify event: 0 - opening, 1 - closing
	template<class _Ty> inline byte_t
      operator[]( const _Ty &_Left ) const _NOTHROW
		   {
		   static const byte_t Table[] = 
			   {_, 0, 0, 0, _, 1, 1, 1, _, 0, 0, 1, _, 1, 1, 1
			   };
		   return Table[_Left];
		   }
	} Clop;

//-------------------------------------
// Detect head or tail front
//-------------------------------------
const
struct _LNX_PACKING HeadTail : public Fictitious
	{//detect head front - 1 or tail front - 0
   template<class _Ty> byte_t
      operator()( const _Ty &_Type,const _Ty &_Idx ) const _NOTHROW
		   {
         static const byte_t Selector[] = 
            {//shift to mutation
            0,  39,
            };

		   static const byte_t Table[] = 
			   {//bufurcation front
			   _, 1, 1, 1, _, _, 1, 
                     1, _, _, 1,
                     1, _, _, 1,
                     1, _, _, 1,
                     1, _, _, 1,
                     1, _, _, 1,
                     1, _, _, 1,
                     1, _, _, 1,
                     1, _, _, 1,
             //ending front
			         1, 1, _, _, 1,
                     1, _, _, 1,
                     1, _, _, 1,
                     1, _, _, 1,
                     1, _, _, 1,
                     1, _, _, 1,
                     1, _, _, 1,
                     1, _, _, 1,
                     1, _, _, 1,
			   };
         //get front
         return (Table + Selector[_Type])[_Idx];
		   }
	} Heta;

//-------------------------------------
// Detect opposite link on the same line
//-------------------------------------
const
struct _LNX_PACKING Oppo_link : public Fictitious
	{//detect head front - 1 or tail front - 0
   template<class _Ty> inline byte_t
      operator()( const _Ty &_Type,const _Ty &_Idx ) const _NOTHROW
		   {
         static const byte_t Selector[] = 
            {//shift to mutation
            0,  39,
            };

		   static const byte_t Detector[] = 
			   {//bufurcation opposite link
            _, _, _, 4, 3, 6, 5,
                     8, 7,10, 9,
                    12,11,14,13,
                    16,15,18,17,
                    20,19,22,21,
                    24,23,26,25,
                    28,27,30,29,
                    32,31,34,33,
                    36,35,38,37,
             //ending opposite link
                  _, 2, 1, 4, 3,
                     6, 5, 8, 7,
                    10, 9,12,11,
                    14,13,16,15,
                    18,17,20,19,
                    22,21,24,23,
                    26,25,28,27,
                    30,29,32,31,
                    34,33,36,35,
			   };
         //get opposite link
         return (Detector + Selector[_Type])[_Idx];
		   }
	}  Oppo;

//-------------------------------------
// Renumber links if query mutated
//-------------------------------------
const
struct _LNX_PACKING Switcher : public Fictitious
	{//possible mutations
   template<class _Ty> inline const byte_t*
      operator[]( const _Ty &_Left ) const _NOTHROW
		   {
         static const twin_t Selector[] = 
            {//shift to mutation
            0,   _,   _,  39,  78,   _,   _,   _,
            _, 117, 156,   _,   _,   _,   _,   _,
            _, 195, 234,   _,   _,   _,   _,   _,
            0,   _,   _, 273, 312,   _,   _,   _,
            };

		   static const byte_t Commutator[] = 
			   {//not - without mutation: 0
            0, 1, 2,    3, 4,	5, 6, 
							   7, 8, 9,10,
							  11,12,13,14,
						     15,16,17,18,
						     19,20,21,22,
						     23,24,25,26,
						     27,28,29,30,
                       31,32,33,34,
                       35,36,37,38,
            //bcl - bifurcation close to left: 39
			   4, 2, 3,    7, 8, 0, 1,
						     11,12, 5, 6,
						     15,16, 9,10,
						     19,20,13,14,
						     23,24,17,18,
						     27,28,21,22,
						     31,32,25,26,
						     35,36,29,30,
						     39,40,33,34,
            //bcr - bifurcation close to right: 78
			   5, 6, 1,    2, 0, 9,10, 
							   3, 4,13,14, 
							   7, 8,17,18,
						     11,12,21,22,
						     15,16,25,26,
						     19,20,29,30,
						     23,24,33,34,
						     27,28,37,38,
						     31,32,41,42,
            //ecl - ending close to left: 117
			   2, 3, 4,    0, 1,	7, 8, 
							   5, 6,11,12,
							   9,10,15,16,
						     13,14,19,20,
						     17,18,23,24,
						     21,22,27,28,
						     25,26,31,32,
                       29,30,35,36,
                       33,34,39,40,
            //ecr - ending close to right: 156
			   1, 2, 0,    5, 6, 3, 4, 
							   9,10, 7, 8,
						     13,14,11,12,
						     17,18,15,16,
						     21,22,19,20,
						     25,26,23,24,
						     29,30,27,28,
						     33,34,31,32,
                       37,38,35,36,
            //bbl - bifurcation break to left: 195
			   2, 0, 1,    5, 6, 3, 4,   
							   9,10, 7, 8,
						     13,14,11,12,
						     17,18,15,16,
						     21,22,19,20,
						     25,26,23,24,
						     29,30,27,28,
						     33,34,31,32,
                       37,38,35,36,
            //bbr - bifurcation break to right: 234
			   3, 4, 0,    1, 2, 7, 8,
							   5, 6,11,12,
							   9,10,15,16,
						     13,14,19,20,
						     17,18,23,24,
						     21,22,27,28,
						     25,26,31,32,
                       29,30,35,36,
                       33,34,39,40,
            //esl - ending switch to left: 273
			   1, 5, 6,    2, 0,	9,10,
							   3, 4,13,14,
							   7, 8,17,18,
						     11,12,21,22,
						     15,16,25,26,
						     19,20,29,30,
						     23,24,33,34,
						     27,28,37,38,
						     31,32,41,42,
            //esr - ending switch to right: 312
			   4, 0, 3,    7, 8,	1, 2,
						     11,12, 5, 6,
						     15,16, 9,10,
						     19,20,13,14,
						     23,24,17,18,
						     27,28,21,22,
						     31,32,25,26,
						     35,36,29,30,
						     39,40,33,34,
			   };
         //get pointer
		   return Commutator + Selector[_Left];
		   }
	}  Swit;

//-------------------------------------
// See far links in case of mutation
//-------------------------------------
const
struct _LNX_PACKING Relink_bbr : public Fictitious
	{//prognoze link if bifurcation break to right
   template<class _Ty> inline byte_t
      operator[]( const _Ty &_Left ) const _NOTHROW
		   {//argument event, return link
		   static const byte_t Table[] = 
			   {
            _, 6, _, _, _, _, 5, _, _, _, _, _, _, _, _, _
			   };  
		   return Table[_Left];
		   }
	}  Lbbr;

const
struct _LNX_PACKING Relink_bbl : public Fictitious
	{//prognoze link if bifurcation break to left
   template<class _Ty> inline byte_t
      operator[]( const _Ty &_Left ) const _NOTHROW
		   {//argument event, return link
		   static const byte_t Table[] = 
			   {
            _, _, 3, _, _, 4, _, _, _, _, _, _, _, _, _, _
			   };  
		   return Table[_Left];
		   }
	}  Lbbl;

const
struct _LNX_PACKING Relink_bcr : public Fictitious
	{//prognoze link if bifurcation close to right
   template<class _Ty> inline byte_t
      operator[]( const _Ty &_Left ) const _NOTHROW
		   {//argument event, return link
		   static const byte_t Table[] = 
			   {
            _, 6, _, _, _, _, 5, _, _, _, _, _, _, _, _, _
			   };  
		   return Table[_Left];
		   }
	}  Lbcr;

const
struct _LNX_PACKING Relink_bcl : public Fictitious
	{//prognoze link if bifurcation close to left
   template<class _Ty> inline byte_t
      operator[]( const _Ty &_Left ) const _NOTHROW
		   {//argument event, return link
		   static const byte_t Table[] = 
			   {
            _, _, 3, _, _, 4, _, _, _, _, _, _, _, _, _, _
			   };  
		   return Table[_Left];
		   }
	}  Lbcl;

const
struct _LNX_PACKING Relink_esr : public Fictitious
	{//prognoze link if ending switch to right
   template<class _Ty> inline byte_t
      operator[]( const _Ty &_Left ) const _NOTHROW
		   {//argument event, return link
		   static const byte_t Table[] = 
			   {
            _, _, _, _, _, _, _, _, _, 4, _, _, _, _, 3, _
			   };  
		   return Table[_Left];
		   }
	}  Lesr;

const
struct _LNX_PACKING Relink_esl : public Fictitious
	{//prognoze link if ending switch to left
   template<class _Ty> inline byte_t
      operator[]( const _Ty &_Left ) const _NOTHROW
		   {//argument event, return link
		   static const byte_t Table[] = 
			   {
            _, _, _, _, _, _, _, _, _, _, 1, _, _, 2, _, _
			   };  
		   return Table[_Left];
		   }
	}  Lesl;

//-------------------------------------
// Rename events in case of mutation 
//       for the same minutiae
//-------------------------------------
const
struct _LNX_PACKING Events_bbr : public Fictitious
	{//rename events if bifurcation break to right
   template<class _Ty> inline byte_t
      operator[]( const _Ty &_Left ) const _NOTHROW
		   {//argument event, return event
		   static const byte_t Table[] = 
			   {
            _, _,Ea,E9, _,Ed, _,Ee, _, _, _,Ef, _, _, _, _
			   };  
		   return Table[_Left];
		   }
	}  Ebbr;

const
struct _LNX_PACKING Events_bbl : public Fictitious
	{//get link if bifurcation break to left
   template<class _Ty> inline byte_t
      operator[]( const _Ty &_Left ) const _NOTHROW
		   {//argument event, return event
		   static const byte_t Table[] = 
			   {
            _,E9, _,Ea, _, _,Ee,Ef, _, _, _,Ed, _, _, _, _
			   };  
		   return Table[_Left];
		   }
	}  Ebbl;

const
struct _LNX_PACKING Events_bcr : public Fictitious
	{//rename events if bifurcation close to right
   template<class _Ty> inline byte_t
      operator[]( const _Ty &_Left ) const _NOTHROW
		   {//argument event, return event
		   static const byte_t Table[] = 
			   {
            _, _,E3,E1, _,Eb, _,E6, _, _, _,E7, _, _, _, _
			   };  
		   return Table[_Left];
		   }
	}  Ebcr;

const
struct _LNX_PACKING Events_bcl : public Fictitious
	{//rename events if bifurcation close to left
   template<class _Ty> inline byte_t
      operator[]( const _Ty &_Left ) const _NOTHROW
		   {//argument event, return event
		   static const byte_t Table[] = 
			   {
            _,E3, _,E2, _, _,E7,Eb, _, _, _,E5, _, _, _, _
			   };  
		   return Table[_Left];
		   }
	}  Ebcl;

const
struct _LNX_PACKING Events_esr : public Fictitious
	{//rename events if ending switch to right
   template<class _Ty> inline byte_t
      operator[]( const _Ty &_Left ) const _NOTHROW
		   {//argument event, return event
		   static const byte_t Table[] = 
			   {
            _, _, _, _, _, _, _, _, _, _,E9, _, _,Ef, _,Ee
			   };  
		   return Table[_Left];
		   }
	}  Eesr;

const
struct _LNX_PACKING Events_esl : public Fictitious
	{//rename events if ending switch to left
   template<class _Ty> inline byte_t
      operator[]( const _Ty &_Left ) const _NOTHROW
		   {//argument event, return event
		   static const byte_t Table[] = 
			   {
            _, _, _, _, _, _, _, _, _,Ea, _, _, _, _,Ef,Ed
			   };  
		   return Table[_Left];
		   }
	}  Eesl;

//-------------------------------------
// Asymmetric permissible mutations
//-------------------------------------
const 
struct _LNX_PACKING Mutter : public Fictitious
	{//permissible mutations
   inline uint_t
      operator[]( iint_t _Idx ) const _NOTHROW
         {
		   static const byte_t 
            Table_events[] =
               {//  E1   E2   E3   E4   E5   E6   E7   E8   E9   Ea   Eb   Ec   Ed   Ee   Ef
               _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _, //E0
               _,   1,   _,   5,   _,   _,   _,   _,   _,   3,   _,   _,   _,   _,   _,   _, //E1
               _,   _,   1,   5,   _,   _,   _,   _,   _,   _,   3,   _,   _,   _,   _,   _, //E2
               _,   5,   5,   1,   _,   _,   _,   _,   _,   3,   3,   _,   _,   _,   _,   _, //E3
               _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _, //
               _,   _,   _,   _,   _,   1,   _,   _,   _,   _,   _,   5,   _,   3,   _,   _, //E5
               _,   _,   _,   _,   _,   _,   1,   5,   _,   _,   _,   _,   _,   _,   3,   _, //E6
               _,   _,   _,   _,   _,   _,   5,   1,   _,   _,   _,   5,   _,   _,   3,   3, //E7
               _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _, //
               _,   2,   _,   2,   _,   _,   _,   _,   _,   1,   4,   _,   _,   _,   _,   _, //E9
               _,   _,   2,   2,   _,   _,   _,   _,   _,   4,   1,   _,   _,   _,   _,   _, //Ea
               _,   _,   _,   _,   _,   5,   _,   5,   _,   _,   _,   1,   _,   3,   _,   3, //Eb
               _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _, //
               _,   _,   _,   _,   _,   2,   _,   _,   _,   _,   _,   2,   _,   1,   4,   _, //Ed
               _,   _,   _,   _,   _,   _,   2,   2,   _,   _,   _,   _,   _,   4,   1,   _, //Ee
               _,   _,   _,   _,   _,   _,   _,   2,   _,   _,   _,   2,   _,   _,   _,   1, //Ef
               //   E1   E2   E3   E4   E5   E6   E7   E8   E9   Ea   Eb   Ec   Ed   Ee   Ef
			      };
         return Table_events[_Idx];
         }
	} Mutt;

_ESK_END
#pragma pack(pop)
#endif//VIRTUE_H
