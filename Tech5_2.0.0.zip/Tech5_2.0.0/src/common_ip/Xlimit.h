#pragma		once
#ifndef		XLIMIT_H
#define		XLIMIT_H

//	Use project headers
#include		"Eskdef.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
	 Template Xlimit
		with specializations
**************************************/
template<class _Ty>
class Xlimit
	{//numeric limits for arbitrary type _Ty
public:
	 _Ty 
       min() const _NOTHROW
		   {//return minimum value
		   return (_Ty(0));
		   }

	 _Ty 
       max() const _NOTHROW
		   {//return maximum value
		   return (_Ty(0));
		   }

	 _Ty 
       epsilon() const _NOTHROW
		   {//return smallest effective increment from 1.0
		   return (_Ty(0));
		   }

	 _Ty 
       round_error() const _NOTHROW
		   {//return largest rounding error
		   return (_Ty(0));
		   }
	};
 
template<class _Ty>
class Xlimit<const _Ty> : public Xlimit<_Ty>
	{//numeric limits for const types
	};

template<> 
class Xlimit<bool>
	{//limits for type bool
public:
	typedef bool _Ty;

	 _Ty 
       min() const _NOTHROW
		   {//return minimum value
		   return (false);
		   }

	 _Ty 
       max() const _NOTHROW
		   {//return maximum value
		   return (true);
		   }

	 _Ty 
       epsilon() const _NOTHROW
		   {//return smallest effective increment from 1.0
		   return (0);
		   }

	 _Ty 
       round_error() const _NOTHROW
		   {//return largest rounding error
		   return (0);
		   }
	};

template<> 
class Xlimit<signed char>
	{//limits for type signed char
public:
	typedef signed char _Ty;

	 _Ty 
       min() const _NOTHROW
		   {//return minimum value
		   return (-127-1);
		   }

	 _Ty 
       max() const _NOTHROW
		   {//return maximum value
		   return (127);
		   }

	 _Ty 
       epsilon() const _NOTHROW
		   {//return smallest effective increment from 1.0
		   return (0);
		   }

	 _Ty 
       round_error() const _NOTHROW
		   {//return largest rounding error
		   return (0);
		   }
	};

template<> 
class Xlimit<unsigned char>
	{//limits for type unsigned char
public:
	typedef unsigned char _Ty;

	 _Ty 
       min() const _NOTHROW
		   {//return minimum value
		   return (0);
		   }

	 _Ty 
       max() const _NOTHROW
		   {//return maximum value
		   return (0xff);
		   }

	 _Ty 
       epsilon() const _NOTHROW
		   {//return smallest effective increment from 1.0
		   return (0);
		   }

	 _Ty 
       round_error() const _NOTHROW
		   {//return largest rounding error
		   return (0);
		   }
	};

template<> 
class Xlimit<signed short>
	{//limits for type short
public:
	typedef signed short _Ty;

	 _Ty 
       min() const _NOTHROW
		   {//return minimum value
		   return (-32767-1);
		   }

	 _Ty 
       max() const _NOTHROW
		   {//return maximum value
		   return (32767);
		   }

	 _Ty 
       epsilon() const _NOTHROW
		   {//return smallest effective increment from 1.0
		   return (0);
		   }

	 _Ty 
       round_error() const _NOTHROW
		   {//return largest rounding error
		   return (0);
		   }
	};

template<> 
class Xlimit<unsigned short>
	{//limits for type unsigned short
public:
	typedef unsigned short _Ty;

	 _Ty
       min() const _NOTHROW
		   {//return minimum value
		   return (0);
		   }

	 _Ty 
       max() const _NOTHROW
		   {//return maximum value
		   return (0xffff);
		   }

	 _Ty 
       epsilon() const _NOTHROW
		   {//return smallest effective increment from 1.0
		   return (0);
		   }

	 _Ty 
       round_error() const _NOTHROW
		   {//return largest rounding error
		   return (0);
		   }
	};

template<> 
class Xlimit<signed int>
	{//limits for type int
public:
	typedef signed int _Ty;

	 _Ty 
       min() const _NOTHROW
		   {//return minimum value
		   return (-2147483647-1);
		   }

	 _Ty 
       max() const _NOTHROW
		   {//return maximum value
		   return (2147483647);
		   }

	 _Ty 
       epsilon() const _NOTHROW
		   {//return smallest effective increment from 1.0
		   return (0);
		   }

	 _Ty 
       round_error() const _NOTHROW
		   {//return largest rounding error
		   return (0);
		   }
	};

template<> 
class Xlimit<unsigned int>
	{//limits for type unsigned int
public:
	typedef unsigned int _Ty;

	 _Ty 
       min() const _NOTHROW
		   {//return minimum value
		   return (0);
		   }

	 _Ty 
       max() const _NOTHROW
		   {//return maximum value
		   return (0xffffffff);
		   }

	 _Ty 
       epsilon() const _NOTHROW
		   {//return smallest effective increment from 1.0
		   return (0);
		   }

	 _Ty 
       round_error() const _NOTHROW
		   {//return largest rounding error
		   return (0);
		   }
	};

template<> 
class Xlimit<signed long>
	{//limits for type long
public:
	typedef signed long _Ty;

	 _Ty 
       min() const _NOTHROW
		   {//return minimum value
		   return (-2147483647L-1);
		   }

	 _Ty 
       max() const _NOTHROW
		   {//return maximum value
		   return (2147483647L);
		   }

	 _Ty 
       epsilon() const _NOTHROW
		   {//return smallest effective increment from 1.0
		   return (0);
		   }

	 _Ty 
       round_error() const _NOTHROW
		   {//return largest rounding error
		   return (0);
		   }
	};

template<> 
class Xlimit<unsigned long>
	{//limits for type unsigned long
public:
	typedef unsigned long _Ty;

	 _Ty 
       min() const _NOTHROW
		   {//return minimum value
		   return (0UL);
		   }

	 _Ty 
       max() const _NOTHROW
		   {//return maximum value
		   return (0xffffffffUL);
		   }

	 _Ty 
       epsilon() const _NOTHROW
		   {//return smallest effective increment from 1.0
		   return (0);
		   }

	 _Ty 
       round_error() const _NOTHROW
		   {//return largest rounding error
		   return (0);
		   }
	};

template<> 
class Xlimit<signed long long>
	{//limits for type long
public:
	typedef signed long long _Ty;

	 _Ty 
       min() const _NOTHROW
		   {//return minimum value
		   return (-9223372036854775807 - 1);
		   }

	 _Ty 
       max() const _NOTHROW
		   {//return maximum value
		   return (9223372036854775807);
		   }

	 _Ty 
       epsilon() const _NOTHROW
		   {//return smallest effective increment from 1.0
		   return (0);
		   }

	 _Ty 
       round_error() const _NOTHROW
		   {//return largest rounding error
		   return (0);
		   }
	};

template<> 
class Xlimit<unsigned long long>
	{//limits for type long
public:
	typedef unsigned long long _Ty;

	 _Ty 
       min() const _NOTHROW
		   {//return minimum value
		   return (0);
		   }

	 _Ty 
       max() const _NOTHROW
		   {//return maximum value
		   return (0xffffffffffffffff);
		   }

	 _Ty 
       epsilon() const _NOTHROW
		   {//return smallest effective increment from 1.0
		   return (0);
		   }

	 _Ty 
       round_error() const _NOTHROW
		   {//return largest rounding error
		   return (0);
		   }
	};

template<> 
class Xlimit<float>
	{//limits for type float
public:
	typedef float _Ty;

	 _Ty 
       min() const _NOTHROW
		   {//return minimum value
		   return (1.175494351e-38F);
		   }

	 _Ty 
       max() const _NOTHROW
		   {//return maximum value
		   return (3.402823466e+38F);
		   }

	 _Ty 
       epsilon() const _NOTHROW
		   {//return smallest effective increment from 1.0
		   return (1.192092896e-07F);
		   }

	 _Ty 
       round_error() const _NOTHROW
		   {//return largest rounding error
		   return (0.5);
		   }
	};

template<> 
class Xlimit<double>
	{//limits for type double
public:
	typedef double _Ty;

	 _Ty 
       min() const _NOTHROW
		   {//return minimum value
		   return (2.2250738585072014e-308);
		   }

	 _Ty 
       max() const _NOTHROW
		   {//return maximum value
		   return (1.7976931348623158e+308);
		   }

	 _Ty 
       epsilon() const _NOTHROW
		   {//return smallest effective increment from 1.0
		   return (2.2204460492503131e-016);
		   }

	 _Ty 
       round_error() const _NOTHROW
		   {//return largest rounding error
		   return (0.5);
		   }
	};

template<> 
class Xlimit<long double>
	{//limits for type long double
public:
	typedef long double _Ty;

	 _Ty 
       min() const _NOTHROW
		   {//return minimum value
		   return (2.2250738585072014e-308);
		   }

	 _Ty 
       max() const _NOTHROW
		   {//return maximum value
		   return (1.7976931348623158e+308);
		   }

	 _Ty 
       epsilon() const _NOTHROW
		   {//return smallest effective increment from 1.0
		   return (2.2204460492503131e-016);
		   }

	 _Ty 
       round_error() const _NOTHROW
		   {//return largest rounding error
		   return (0.5);
		   }
	};

_ESK_END
#pragma pack(pop)
#endif//XLIMIT_H
