//	Use project headers
#include		"Anonim.h"
#include		"Armour.h"

#if _ESK_GUARD == 1
   //use system headers
   #if defined (linux)
      #include <stdio.h>
      #include <cpuid.h>
      #include <time.h>
   #else
      #include <stdio.h>
      #include <intrin.h>
      #include <time.h>
   #endif
   #pragma message( "Licence agreement is supported" )
#else
   #pragma message( "Licence agreement is not supported" )
#endif

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
//-------------------------------------
// Interface with file OS
//-------------------------------------
#if _ESK_GUARD == 1
Iosstd::Iosstd() : File()
		{//constructor
		};

Iosstd::~Iosstd()
		{//destructor
      fclose();
		}

bool_t Iosstd::fopen( const char *_Name,const char *_Mode )
	{//open file
	if (File == Null)
#if defined (linux)
      return ((File = ::fopen( _Name,_Mode )) != 0);
#else
		return (::fopen_s((FILE**)&File,_Name,_Mode )  == 0);
#endif
	else
		return (false);
	}

bool_t Iosstd::fwrite( void_p _From,size_t _Size,size_t _Coin )
	{//write data to file
	if (File != Null)
		return (::fwrite( _From,_Size,_Coin,(FILE*)File ) == _Coin);
	else
		return (false);
	}

bool_t Iosstd::fread( void_p _Dest,size_t _Size,size_t _Coin )
	{//read data from file
	if (File != Null)
		return (::fread( _Dest,_Size,_Coin,(FILE*)File ) == _Coin);
	else
		return (false);
	}

bool_t Iosstd::fseek( uint_t _Move )
	{//moves the file pointer to a specified location from the beginning of file
	if (File != Null)
		return (::fseek((FILE*)File,_Move,SEEK_SET ) == 0);
	else
		return (false);
	}

void_t Iosstd::fclose()
	{//close file
	if (Null !=  File)
      {//if open
      ::fclose((FILE*)File );
                      File = Null;
      }
	}

//-------------------------------------
// Interface with chip and time OS
//-------------------------------------
quad_t Intrin::timeid()
   {//time in seconds since UTC 1/1/70
   return time(0);
   }

void_t Intrin::cpu_id( info_t *_Info,iint_t _Call )
   {//read CPU code
   #if defined linux
      __get_cpuid ( _Call,_Info,_Info+1,_Info+2,_Info+3 );
   #else
      __cpuid( _Info,_Call );
   #endif
   }
#endif

_ESK_END
#pragma pack(pop)
