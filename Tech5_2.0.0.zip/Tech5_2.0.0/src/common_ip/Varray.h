#pragma		once
#ifndef		VARRAY_H
#define		VARRAY_H

//	Header project file
#include		"Fnctnl.h"
#include		"Xlimit.h"
#include		"Memory.h"
#include		"Spline.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
         Forward references
**************************************/
template<class _Ty> 
class   Varray;

typedef Varray<bool_t> Barray; //bool array
typedef Varray<char_t> Carray; //signed char array
typedef Varray<shrt_t> Sarray; //signed short array
typedef Varray<iint_t> Iarray; //signed int array
typedef Varray<guar_t> Garray; //signed long long array

/**************************************
		Template class Varray
**************************************/
#define _VALOP( TYPE,LENGTH,RHS )                                                                  \
	Varray<TYPE> _Ans(LENGTH);                                                                      \
   for (register uint_t _Idx = _Ans.size(); _Idx--;)                                               \
		_Ans[_Idx] = RHS;                                                                            \
	return (_Ans)

#define _VALGOP( RHS )                                                                             \
   for (register uint_t _Idx = size(); _Idx--;)                                                    \
		Cursor[_Idx] RHS;                                                                            \
	return (*this)

#define _VALIF( IFO,RHS )                                                                          \
	_Ty _Val = Cursor[0];                                                                           \
   for (register uint_t _Idx = size(); _Idx--;)                                                    \
      if (_Val IFO Cursor[_Idx])                                                                   \
			 _Val RHS Cursor[_Idx];                                                                   \
	return(_Val)

template<class _Ty>
class Varray : Xlimit<_Ty>
	{//store array with various indexing options
public:
   typedef Xlimit<_Ty> Base_t;
   typedef Varray<_Ty> Self_t;
	typedef _Ty item_t;

   //----------------------------------
   // Public standard partition
   //----------------------------------
	Varray()
		{//construct empty Varray
		tidy();
		}

	explicit Varray( uint_t _Count )
		{//construct with _Count *_Ty()
		tidy();
		grow( _Count );
		}

	Varray( const _Ty &_Val,uint_t _Count )
		{//construct with _Count*_Val
		tidy();
		grow( _Count,&_Val );
		}

	Varray( const _Ty *_Ptr,uint_t _Count )
		{//construct with [_Ptr,_Ptr + _Count)
		tidy();
		grow( _Count,_Ptr,1 );
		}

	Varray( const Self_t &_Right )
		{//construct from Varray
		tidy();
		grow( _Right.size(),_Right.Cursor,1 );
		}

	~Varray() _NOTHROW
		{//destroy the object
		tidy( true );
		}

	Self_t& 
      operator=( const Self_t &_Right )
		   {// assign Varray _Right
		   if (this == &_Right)
			   ;//do nothing
		   else 
         if (size() == _Right.size())
            {//accurate assign
			   for (uint_t _Idx = 0; _Idx < size(); ++_Idx)
				   Cursor[_Idx] = _Right[_Idx];
            }
		   else
			   {//resize and copy
			   tidy( true );
			   grow( _Right.size(),_Right.Cursor,1 );
			   }
		   return (*this);
		   }

	Self_t& 
      operator=( const _Ty &_Val )
		   {//assign _Val to each element
		   _VALGOP(= _Val);
		   }

	void_t 
      resize( uint_t _Upsize )
		   {//determine new length, filling with _Ty() elements
		   tidy( true );
		   grow( _Upsize );
		   }

	void_t 
      resize( uint_t _Upsize,const _Ty _Val )
		   {//determine new length, filling with _Val elements
		   tidy( true );
		   grow( _Upsize,&_Val,0 );
		   }

	Self_t 
      operator+() const
		   {//return +Varray
		   _VALOP( _Ty,size(),+Cursor[_Idx] );
		   }

	Self_t
      operator-() const
		   {//return -Varray
		   _VALOP( _Ty,size(),-Cursor[_Idx] );
		   }

	Self_t 
      operator~() const
		   {//return ~Varray
		   _VALOP( _Ty,size(),~Cursor[_Idx] );
		   }

	Barray
      operator!() const
		   {//return !Varray
		   _VALOP( bool_t,size(),!Cursor[_Idx] );
		   }

	Self_t& 
      operator*=( const _Ty &_Right )
		   {//multiply Varray elements by _Right
         _VALGOP(*= _Right);
		   }

	Self_t& 
      operator/=( const _Ty &_Right )
		   {//divide Varray elements by _Right
		   _VALGOP(/= _Right);
		   }

	Self_t&
      operator%=( const _Ty &_Right )
		   {//remainder Varray elements by _Right
		   _VALGOP(%= _Right);
		   }

	Self_t&
      operator+=( const _Ty &_Right )
		   {//add _Right to Varray elements
		   _VALGOP(+= _Right);
		   }

	Self_t&
      operator-=( const _Ty &_Right )
		   {//subtract _Right from Varray elements
		   _VALGOP(-= _Right);
		   }

	Self_t& 
      operator^=( const _Ty &_Right )
		   {//XOR _Right into Varray elements
		   _VALGOP(^= _Right);
		   }

	Self_t&
      operator&=( const _Ty &_Right )
		   {//AND _Right into Varray elements
		   _VALGOP(&= _Right);
		   }

	Self_t&
      operator|=( const _Ty &_Right )
		   {//OR _Right into Varray elements
		   _VALGOP(|= _Right);
		   }

	Self_t&
      operator<<=( const _Ty &_Right )
		   {//left shift Varray elements by _Right
		   _VALGOP(<<= _Right);
		   }

	Self_t&
      operator>>=( const _Ty &_Right )
		   {//right shift Varray elements by _Right
		   _VALGOP(>>= _Right);
		   }

	Self_t&
      operator*=( const Self_t &_Right )
		   {//multiply Varray elements by Varray _Right elements
		   _VALGOP(*= _Right[_Idx]);
		   }

	Self_t&
      operator/=( const Self_t &_Right )
		   {//divide Varray elements by Varray _Right elements
		   _VALGOP(/= _Right[_Idx]);
		   }

	Self_t&
      operator%=( const Self_t &_Right )
		   {//remainder Varray elements by Varray _Right elements
		   _VALGOP(%= _Right[_Idx]);
		   }

	Self_t&
      operator+=( const Self_t &_Right )
		   {//add Varray _Right elements to Varray elements
		   _VALGOP(+= _Right[_Idx]);
		   }

	Self_t&
      operator-=( const Self_t &_Right )
		   {//subtract Varray _Right elements from Varray elements
		   _VALGOP(-= _Right[_Idx]);
		   }

	Self_t&
      operator^=( const Self_t &_Right )
		   {//XOR Varray _Right elements into Varray elements
		   _VALGOP(^= _Right[_Idx]);
		   }

	Self_t&
      operator|=( const Self_t &_Right )
		   {//OR Varray _Right elements into Varray elements
		   _VALGOP(|= _Right[_Idx]);
		   }

	Self_t&
      operator&=( const Self_t &_Right )
		   {//AND Varray _Right elements into Varray elements
		   _VALGOP(&= _Right[_Idx]);
		   }

	Self_t&
      operator<<=( const Self_t &_Right )
		   {//left shift Varray elements by Varray _Right elements
		   _VALGOP(<<= _Right[_Idx]);
		   }

	Self_t&
      operator>>=( const Self_t &_Right )
		   {//right shift Varray elements by Varray _Right elements
		   _VALGOP(>>= _Right[_Idx]);
		   }

	uint_t
      size() const
		   {//return length of sequence
		   return (Mykeep);
		   }

	void_t
      rekeep( uint_t _Size )
		   {//restrict length of sequence
         if(Mysize >= _Size)
            Mykeep  = _Size; 
         else
            AFFBUG;
		   }

	template<class _Other> _Other
      in( _Other _Off ) const
		   {//return length of sequence
         return med<_Other>( 0,Mykeep-1,_Off );
		   }

	_Ty
      operator[]( uint_t _Off ) const
		   {//subscript nonmutable sequence
         AFFIRM( Cursor[_Off] < omax());
         AFFIRM( Cursor[_Off] > omin());
         AFFIRM(        _Off  < size());
		   return( Cursor[_Off] );
		   }

	_Ty&
      operator[]( uint_t _Off )
		   {//subscript mutable sequence
         AFFIRM( Cursor[_Off] < omax());
         AFFIRM( Cursor[_Off] > omin());
         AFFIRM(        _Off  < size());
		   return( Cursor[_Off] );
		   }

	guar_t
      getsum( guar_t _Val = 0 ) const
		   {//return sum all elements
         for (register uint_t _Idx = size(); _Idx--;)
            _Val += Cursor[_Idx];
	      return _Val;
		   }

	_Ty
      getmin() const
		   {//return smallest of all elements
         _VALIF(>,=);
		   }

	_Ty
      getmax() const
		   {//return largest of all elements
         _VALIF(<,=);
		   }

	Self_t
      apply( _Ty _Func(_Ty)) const
		   {//return Varray transformed by _Func, value argument
		   _VALOP( _Ty,size(),_Func( Cursor[_Idx] ));
		   }

	Self_t
      apply( _Ty _Func( const _Ty& )) const
		   {//return Varray transformed by _Func, nonmutable argument
		   _VALOP( _Ty,size(),_Func( Cursor[_Idx] ));
		   }

	void_t
      free()
		   {//erase all elements
		   tidy( true );
		   }

   //----------------------------------
   // Special-purpose partition
   //----------------------------------
	template<class _Other> Self_t&
      spline( const _Other *_Tbl )
		   {//Pavlidis spline
         _VALGOP(= _Ty( gudwin( _Tbl,_Other(_Idx))));
		   }

	template<class _Other> Self_t&
      spline( const _Ty *_Tbl,_Other _Min,_Other _Max )
		   {//Pavlidis spline
         _VALGOP(= _Ty( gudwin( _Tbl,_Other(_Idx),_Min,_Max )));
		   }

	uint_t
      partof( guar_t _Div ) const
		   {//define the share... scale is 128
         guar_t _Sum = getsum()*(128 - _Div)/128;

         for (register uint_t _Idx = size(); _Idx--;)
            if((_Sum -= Cursor[_Idx]) <= 0) 
               return _Idx;
         return 0;
		   }

   Self_t&
      smooth( uint_t _Len )
         {//smooth data
         if (_Len < 96) 
            {//allocate
            Aviso<guar_t> _Avs; smooth( _Len,_Avs.allocate( size()));
            }
         return (*this);
         }

	template<class _Fn> Self_t &
	   sincos( const Self_t &_Src,uint_t _Win,_Fn _Op = _Fn())
		   {//trigonometrical convolution
		   AFFIRM( 1 < _Win && _Win < 60 );
         AFFIRM( _Src.size() == size() );

		   //special data
		   iint_t _Ang[60],
                _Val;

		   for (uint_t j = 0; j <= _Win; j++) 
			   _Ang[j] = (j << 7) / _Win; //half period

		   for (uint_t i = 0; i < size(); i++)
			   {//for every point
			   _Val = _Src[i]*_Op(_Ang[0]);

            for (uint_t j = 1; j <= _Win; j++)
               {//convolution
               if (i+j < size())
					   _Val += _Src[i+j]*_Op(+_Ang[j]);
               if(i >= j)
                  _Val += _Src[i-j]*_Op(-_Ang[j]);
				   }
            //press if edge
            Cursor[i] = _Val/iint_t(2*_Win + 1);
			   }	
		   return (*this);
		   }

   Self_t &
      univer()
         {//measure histogram weight
         guar_t _Sum = 1 + getsum(),
                _Val = 0;
	      
	      for (uint_t i = 0; i < size(); i++)
	         {//equalize histogramm
		      _Val += Cursor[i];

		      //oversign the histogram
            Cursor[i] = item_t(BM*_Val/_Sum);
	         }
         return (*this);
         }

   //----------------------------------
   // Private special partition
   //----------------------------------
private:
   template<class _Other> void_t
      smooth( uint_t _Len,_Other *_Ptr )
		   {//smooth histogram
         if(_Ptr)
            {
		      for (register uint_t i = 0; i < size(); i++)
			      {//initialization
			      _Other _Val	= Cursor[i],
                      _Cnt = 1;
			
			      for (register uint_t j = 1; j < _Len; j++)
				      {//use convolution
                  if(i+j < size())
                     {//right index
					      _Val += Cursor[i+j]; ++_Cnt;
                     }
                  if(i >= j)
                     {//left index
                     _Val += Cursor[i-j]; ++_Cnt;
                     }
				      }
               //everage value
               _Ptr[i] = _Val ? _Val/_Cnt : 0;
               }
		      for (register uint_t i = 0; i < size(); i++)
			      Cursor[i] = _Ty(_Ptr[i]);
            }
		   }

	//----------------------------------
	//	Ascent and descent in profile
	//----------------------------------
public:
	bool_t 
      ascent( iint_t _Thr,uint_t &_Idx ) const
		   {//ascent to the height
         return stroll<Less<_Ty>,Greater<_Ty> >( _Thr,_Idx );
		   }

	bool_t 
      dscent( iint_t _Thr,uint_t &_Idx ) const
		   {//descent from the height
         return stroll<Greater<_Ty>,Less<_Ty> >( _Thr,_Idx );
		   }

 private:
	template<class _Fnf,class _Fns> bool_t 
      stroll( iint_t _Thr,uint_t &_Idx,_Fnf _Opf = _Fnf(),_Fns _Ops = _Fns()) const
		   {//parse height and valley
         register uint_t _Pos = _Idx;
                  iint_t _Val = _Thr;

		   for( ; _Pos < size(); _Pos++)
            {//blank
			   if (_Opf( _Thr,Cursor[_Pos] ))
               break;
            }
		   for( ; _Pos < size(); _Pos++)
			   {//find extremum
			   if (_Opf( _Val,Cursor[_Pos] ))
				    _Val = Cursor[_Idx = _Pos];
            else
			   if (_Ops( _Thr,Cursor[_Pos] ))
				   break;
			   }
         return _Ops( _Val,_Thr );
		   }

   //----------------------------------
   // Standard partition
   //----------------------------------
public:
	void_t
      grow( uint_t _Upsize,const _Ty *_Ptr = 0,uint_t _Inc = 0 )
		   {//grow to _Count elements and pad
		   if (_Upsize == 0)
			   tidy( true );// new sequence empty
		   else 
         if (_Upsize <= Mysize)
			   Mykeep = _Upsize;//big enough, no need to pad
		   else
			   {//allocate new array, copy and pad
			   _Ty * 
               _Newptr = 0, _Val = 0;

            try
               {
			      _Newptr = _allocate( _Upsize,(_Ty*)0 );

			      if (_Ptr != 0)
				      for (uint_t _Idx = 0; _Idx < _Upsize; ++_Idx, _Ptr += _Inc)
					      _construct( &_Newptr[_Idx],*_Ptr );
			      else
				      for (uint_t _Idx = 0; _Idx < _Upsize; ++_Idx)
					      _construct( &_Newptr[_Idx], _Val );
               }
            catch(...)
               {//allocation failed, discard storage and reraise
			      tidy( true ); 
			      throw;
               }

			   tidy( true );
			   Cursor = _Newptr;
            Mysize = 
            Mykeep = _Upsize;
			   }
		   }

	void_t
      tidy( bool_t _Constructed = false )
		   {//initialize the object, freeing any allocated storage
		   if (_Constructed && Cursor != Null)
			   {// destroy elements
			   for(uint_t _Idx = 1; _Idx < Mysize; ++_Idx)
				   _destroy( &Cursor[_Idx] );
            
			   delete Cursor;
			   }
		   Mysize = 0;
         Mykeep = 0;
		   Cursor = 0;
		   }

   //----------------------------------
   // Test overflow
   //----------------------------------
private:
   _Ty
      omax() const
         {//detect max overflow
         return Base_t::max()/2;
         }

   _Ty
      omin() const
         {//detect min overflow
         return Base_t::min()/2;
         }

private:
	_Ty*   
      Cursor; //current storage reserved for array
	uint_t 
      Mysize, //current length of sequence
      Mykeep; //current length of sequence

	};//Varray

//-------------------------------------
//	Operators
//-------------------------------------
#ifdef _OPERATOR_VARRAY
template<class _Ty> inline Varray<_Ty>
   operator*( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray * scalar
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] * _Right );
	   }

template<class _Ty> inline Varray<_Ty>
   operator*( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar * Varray
	   _VALOP( _Ty,_Right.size(),_Left * _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator/( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray / scalar
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] / _Right );
	   }

template<class _Ty> inline Varray<_Ty>
   operator/( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar / Varray
	   _VALOP( _Ty,_Right.size(),_Left / _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator%( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray % scalar
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] % _Right );
	   }

template<class _Ty> inline Varray<_Ty>
   operator%( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar % Varray
	   _VALOP( _Ty,_Right.size(),_Left % _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator+( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray + scalar
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] + _Right );
	   }

template<class _Ty> inline Varray<_Ty>
   operator+( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar + Varray
	   _VALOP( _Ty,_Right.size(),_Left + _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator-( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray - scalar
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] - _Right );
	   }

template<class _Ty> inline Varray<_Ty>
   operator-( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar - Varray
	   _VALOP( _Ty,_Right.size(),_Left - _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator^( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray ^ scalar
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] ^ _Right );
	   }

template<class _Ty> inline Varray<_Ty>
   operator^( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar ^ Varray
	   _VALOP( _Ty,_Right.size(),_Left ^ _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator&( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray & scalar
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] & _Right );
	   }

template<class _Ty> inline Varray<_Ty>
   operator&( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar & Varray
	   _VALOP( _Ty,_Right.size(),_Left & _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator|( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray | scalar
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] | _Right );
	   }

template<class _Ty> inline Varray<_Ty>
   operator|( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar | Varray
	   _VALOP( _Ty,_Right.size(),_Left | _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator<<( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray << scalar
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] << _Right );
	   }

template<class _Ty> inline Varray<_Ty>
   operator<<( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar << Varray
	   _VALOP( _Ty,_Right.size(),_Left << _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator>>( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray >> scalar
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] >> _Right );
	   }

template<class _Ty> inline Varray<_Ty>
   operator>>( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar >> Varray
	   _VALOP( _Ty,_Right.size(),_Left >> _Right[_Idx] );
	   }

template<class _Ty> inline Barray
   operator&&( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray && scalar
	   _VALOP( bool_t,_Left.size(),_Left[_Idx] && _Right );
	   }

template<class _Ty> inline Barray
   operator&&( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar && Varray
	   _VALOP( bool_t,_Right.size(),_Left && _Right[_Idx] );
	   }

template<class _Ty> inline Barray
   operator||( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray || scalar
	   _VALOP( bool_t,_Left.size(),_Left[_Idx] || _Right );
	   }

template<class _Ty> inline Barray
   operator||( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar || Varray
	   _VALOP( bool_t,_Right.size(),_Left || _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty> 
   operator*( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray * Varray
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] * _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator/( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray ? Varray
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] / _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator%( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray % Varray
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] % _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator+( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray + Varray
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] + _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator-( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray - Varray
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] - _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator^( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray ^ Varray
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] ^ _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator&( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray & Varray
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] & _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator|( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray | Varray
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] | _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator<<( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray << Varray
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] << _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   operator>>( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray >> Varray
	   _VALOP( _Ty,_Left.size(),_Left[_Idx] >> _Right[_Idx] );
	   }

template<class _Ty> inline Barray
   operator&&( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray && Varray
	   _VALOP( bool_t,_Left.size(),_Left[_Idx] && _Right[_Idx] );
	   }

template<class _Ty> inline Barray
   operator||( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray || Varray
	   _VALOP( bool_t,_Left.size(),_Left[_Idx] || _Right[_Idx] );
	   }

template<class _Ty> inline Barray
   operator==( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray == scalar
	   _VALOP( bool_t,_Left.size(),_Left[_Idx] == _Right );
	   }

template<class _Ty> inline Barray
   operator==( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar == Varray
	   _VALOP( bool_t,_Right.size(),_Left == _Right[_Idx] );
	   }

template<class _Ty> inline Barray
   operator==( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray == Varray
	   _VALOP( bool_t,_Left.size(),_Left[_Idx] == _Right[_Idx] );
	   }

template<class _Ty> inline Barray
   operator!=( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray != scalar
	   _VALOP( bool_t,_Left.size(),_Left[_Idx] != _Right );
	   }

template<class _Ty> inline Barray
   operator!=( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar != Varray
	   _VALOP( bool_t,_Right.size(),_Left != _Right[_Idx] );
	   }

template<class _Ty> inline Barray
   operator!=( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray != Varray
	   _VALOP( bool_t,_Left.size(),_Left[_Idx] != _Right[_Idx] );
	   }

template<class _Ty> inline Barray
   operator<( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray < scalar
	   _VALOP( bool_t,_Left.size(),_Left[_Idx] < _Right );
	   }

template<class _Ty> inline Barray
   operator<( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar < Varray
	   _VALOP( bool_t,_Right.size(),_Left < _Right[_Idx] );
	   }

template<class _Ty> inline Barray
   operator<( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray < Varray
	   _VALOP( bool_t,_Left.size(),_Left[_Idx] < _Right[_Idx] );
	   }

template<class _Ty> inline Barray
   operator>( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray > scalar
	   _VALOP( bool_t,_Left.size(),_Left[_Idx] > _Right );
	   }

template<class _Ty> inline Barray
   operator>( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar > Varray
	   _VALOP( bool_t,_Right.size(),_Left > _Right[_Idx] );
	   }

template<class _Ty> inline Barray
   operator>( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray > Varray
	   _VALOP( bool_t,_Left.size(),_Left[_Idx] > _Right[_Idx] );
	   }

template<class _Ty> inline Barray
   operator<=(const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray <= scalar
	   _VALOP( bool_t,_Left.size(),_Left[_Idx] <= _Right );
	   }

template<class _Ty> inline Barray
   operator<=( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar <= Varray
	   _VALOP( bool_t,_Right.size(),_Left <= _Right[_Idx] );
	   }

template<class _Ty> inline Barray
   operator<=( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray <= Varray
	   _VALOP( bool_t,_Left.size(),_Left[_Idx] <= _Right[_Idx] );
	   }

template<class _Ty> inline Barray
   operator>=( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//return Varray >= scalar
	   _VALOP( bool_t,_Left.size(),_Left[_Idx] >= _Right );
	   }

template<class _Ty> inline Barray
   operator>=( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//return scalar >= Varray
	   _VALOP( bool_t,_Right.size(),_Left >= _Right[_Idx] );
	   }

template<class _Ty> inline Barray
   operator>=( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//return Varray >= Varray
	   _VALOP( bool_t,_Left.size(),_Left[_Idx] >= _Right[_Idx] );
	   }

template<class _Ty> inline Varray<_Ty>
   abs( const Varray<_Ty> &_Left )
	   {//apply abs to each element of Varray
	   _VALOP( _Ty,_Left.size(),abs( _Left[_Idx] ));
	   }

template<class _Ty> inline Varray<_Ty>
   arctg( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//apply atan to pairs of Varray elements
	   _VALOP( _Ty,_Left.size(),arctg( _Left[_Idx],_Right[_Idx] ));
	   }

template<class _Ty> inline Varray<_Ty>
   arctg( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//apply atan to each Varray element and scalar
	   _VALOP( _Ty,_Left.size(),arctg( _Left[_Idx],_Right ));
	   }

template<class _Ty> inline Varray<_Ty>
   arctg( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//apply atan to scalar and each Varray element
	   _VALOP( _Ty,_Right.size(),arctg( _Left,_Right[_Idx] ));
	   }

template<class _Ty> inline Varray<_Ty>
   sin( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//apply sin to pairs of Varray elements
	   _VALOP( _Ty,_Left.size(),_sin( _Left[_Idx],_Right[_Idx] ));
	   }

template<class _Ty> inline Varray<_Ty>
   sin( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//apply sin to each Varray element and scalar
	   _VALOP( _Ty,_Left.size(),_sin( _Left[_Idx],_Right ));
	   }

template<class _Ty> inline Varray<_Ty>
   sin( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//apply sin to scalar each Varray element
	   _VALOP( _Ty,_Right.size(),_sin( _Left,_Right[_Idx] ));
	   }

template<class _Ty> inline Varray<_Ty>
   cos( const Varray<_Ty> &_Left,const Varray<_Ty> &_Right )
	   {//apply cos to pairs of Varray elements
	   _VALOP( _Ty,_Left.size(),_cos( _Left[_Idx],_Right[_Idx] ));
	   }

template<class _Ty> inline Varray<_Ty>
   cos( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {//apply cos to each Varray element and scalar
	   _VALOP( _Ty,_Left.size(),_cos( _Left[_Idx],_Right ));
	   }

template<class _Ty> inline Varray<_Ty>
   cos( const _Ty &_Left,const Varray<_Ty> &_Right )
	   {//apply cos to scalar and each Varray element
	   _VALOP( _Ty,_Right.size(),_cos( _Left,_Right[_Idx] ));
	   }

template<class _Ty> inline Varray<_Ty>
   logdc( const Varray<_Ty> &_Left,const _Ty &_Right )
	   {	// apply log to each element of Varray
	   _VALOP( _Ty,_Left.size(),logdc( _Left[_Idx],_Right ));
	   }

template<class _Ty> inline Varray<_Ty>
   sqri( const Varray<_Ty> &_Left )
	   {	// apply sqrt to each element of Varray
	   _VALOP( _Ty,_Left.size(),sqri( _Left[_Idx] ));
	   }
#endif

_ESK_END
#pragma pack(pop)
#endif//VARRAY_H
