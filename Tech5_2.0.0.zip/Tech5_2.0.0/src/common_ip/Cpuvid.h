/**************************************
					CPUVID.H
      Detect the cpuid instruction.

        Copyright (c) 1994-2004.
        Copyright (c) 2005-2012.
**************************************/
#pragma		once
#ifndef		CPUVID_H
#define		CPUVID_H

//	Use project headers
#include		"Ldsdef.h"

//	Use extern headers
//#include		<intrin.h>

#pragma pack(push,_LDS_PACKING)
_LDS_BEGIN
/**************************************
		Class to get serial number
**************************************/
class Cpuvid
	{//get code of central processor
public:
	uint_t 
      operator()()
		   {//calculate CPU ID
		   return cpuvid();
		   }

	uint_t 
      operator[]( uint_t _Key ) const
		   {//test engineering code, if true - return 0
		   return verify( _Key,gvjvid());
		   }

	uint_t 
      operator()( uint_t _Key )
		   {//test genuine CPU ID, if true - return 0
		   return verify( _Key,cpuvid());
		   }

private:
	uint_t 
      verify( uint_t _Para,uint_t _Parb ) const
		   {//compare parameters
		   return (_Para + ~_Parb + 1);
		   }

	uint_t 
      cpuvid()
		   {//kernal of CPU ID
//         iint_t _Info[4];
//         uint_t _Cpuv(7);

//         for(iint_t _typeid = 0; _typeid < 3; _typeid++)
  //          {//generate key
    //        __cpuid( _Info,_typeid ); for( iint_t i = 0; i < 4; i++) _Cpuv *= (_Info[i] + 3);
      //      }
         //genuine key
        // return _Cpuv;
         return 0;
         }

	uint_t 
      gvjvid() const
		   {//engineering code
         return uint_t('G')*
                uint_t('V')*
                uint_t('J')*405;
         }

   };//Cpuvid


inline bool_t 
   invalid_cpu( uint_t _Serial )
	   {//test key of CPU
	   return Cpuvid()( _Serial ) != 0;
	   }

inline bool_t
   invalid_gvj( uint_t _Serial )
	   {//test engineering code
	   return Cpuvid()[ _Serial ] != 0;
	   }

inline bool_t 
   invalid_key( uint_t _Serial )
	   {//test both key
	   return Cpuvid()( _Serial ) && Cpuvid()[ _Serial ];
	   }

_LDS_END
#pragma pack(pop)
#endif//CPUVID_H
/*
All rights reserved. Consult your license regarding permissions and restrictions.
*/