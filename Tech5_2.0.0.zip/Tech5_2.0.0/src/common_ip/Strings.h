/**************************************
				 STRINGS.H
	String manipulation functions.

        Copyright (c) 1994-2004.
        Copyright (c) 2005-2012.
**************************************/
#pragma		once
#ifndef		STRING_H
#define		STRING_H

//	Use project headers
#include		"Ldsdef.h"

#pragma pack(push,_LDS_PACKING)
_LDS_BEGIN
/**************************************
Functions for strings
**************************************/
template<class _Ty> inline _Ty* 
   type_copy( _Ty *_Dst,const _Ty *_Src,size_t _Count )
	   {//copies _Ty's between buffers, return _Dst
      if(_Dst > _Src)
         for(register size_t i = _Count; i--;) _Dst[i] = _Src[i];
      else
         for(register size_t i = 0; i < _Count; i++) _Dst[i] = _Src[i];

      return _Dst;
	   }

template<class _Ty> inline _Ty* 
   type_init( _Ty *_Dst,_Ty _Val,size_t _Count )
	   {//initialize buffer
      for(register size_t i = _Count; i--;) _Dst[i] = _Val; 

      return _Dst;
	   }

template<class _Ty> inline _Ty* 
   type_init( _Ty *_Dst,size_t _Count )
	   {//adapter
      return type_init( _Dst,_Ty(),_Count );
	   }

inline void_t*
   _mem_move( void_t *_Dst,const void_t *_Src,size_t _Count )
	   {//moves one buffer to another, return _Dst
      return type_copy((byte_t*)_Dst,(byte_t*)_Src,_Count );
	   }

inline void_t* 
   byte_copy( void_t *_Dst,const void_t *_Src,size_t _Count )
	   {//copies bytes between buffers, return _Dest
      return type_copy((byte_t*)_Dst,(byte_t*)_Src,_Count );
	   }

inline void_t* 
   byte_copy_jump( void_t *_Dst,const void_t *_Src,size_t _Count )
	   {//copies bytes between buffers and jump to the end
      return type_copy((byte_t*)_Dst,(byte_t*)_Src,_Count ) + _Count;
	   }

_LDS_END
#pragma pack(pop)
#endif//STRING_H
/*
All rights reserved. Consult your license regarding permissions and restrictions.
*/

