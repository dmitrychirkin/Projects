#pragma		once
#ifndef		FNCTNL_H
#define		FNCTNL_H

//	Header project file
#include		"Eskdef.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
			Base structures
**************************************/
template<class _Af,class _Rt>
struct Unary_functor
	{//struct unary functor
	typedef _Af farg_t;
	typedef _Rt retd_t;
	};

template<class _Af,class _As,class _Rt>
struct Binary_functor
	{//struct binary functor
	typedef _Af farg_t;
	typedef _As sarg_t;
	typedef _Rt retd_t;
	};

/**************************************
				Functional
**************************************/
template<class _Ty>
struct Plus	: public Binary_functor<_Ty,_Ty,_Ty>
	{//struct plus
	_Ty 
      operator()( const _Ty &_Left,const _Ty &_Right ) const
		   {	
		   return (_Left + _Right);
		   }
	};

template<class _Ty>
struct Minus : public Binary_functor<_Ty,_Ty,_Ty>
	{//struct minus
	_Ty 
      operator()( const _Ty &_Left,const _Ty &_Right ) const
		   {
		   return (_Left - _Right);
		   }
	};

template<class _Ty>
struct Multiplies	: public Binary_functor<_Ty,_Ty,_Ty>
	{//struct multiplies
	_Ty
      operator()( const _Ty &_Left,const _Ty &_Right ) const
		   {
		   return (_Left * _Right);
		   }
	};

template<class _Ty>
struct Divides	: public Binary_functor<_Ty,_Ty,_Ty>
	{//struct divides
	_Ty 
      operator()( const _Ty &_Left,const _Ty &_Right ) const
		   {
		   return (_Left / _Right);
		   }
	};

template<class _Ty>
struct Modulus	: public Binary_functor<_Ty,_Ty,_Ty>
	{//struct modulus
	_Ty 
      operator()( const _Ty &_Left,const _Ty &_Right ) const
		   {
		   return (_Left % _Right);
		   }
	};

template<class _Ty>
struct Negate : public Unary_functor<_Ty,_Ty>
	{//struct negate
	_Ty 
      operator()( const _Ty &_Left ) const
		   {
		   return (-_Left);
		   }
	};

template<class _Ty>
struct Equal : public Binary_functor<_Ty,_Ty,bool_t>
	{//struct equal
	bool_t 
      operator()( const _Ty &_Left,const _Ty &_Right ) const
		   {
		   return (_Left == _Right);
		   }
	};

template<class _Ty>
struct Not_equal : public Binary_functor<_Ty,_Ty,bool_t>
	{//struct not equal
	bool_t 
      operator()( const _Ty &_Left,const _Ty &_Right ) const
		   {
		   return (_Left != _Right);
		   }
	};

template<class _Ty>
struct Greater	: public Binary_functor<_Ty,_Ty,bool_t>
	{//struct greater
	bool_t 
      operator()( const _Ty &_Left,const _Ty &_Right ) const
		   {
		   return (_Left > _Right);
		   }
	};

template<class _Ty>
struct Less	: public Binary_functor<_Ty,_Ty,bool_t>
	{//struct less
	bool_t 
      operator()( const _Ty &_Left,const _Ty &_Right ) const
		   {
		   return (_Left < _Right);
		   }
	};

template<class _Ty>
struct Greater_equal : public Binary_functor<_Ty,_Ty,bool_t>
	{//struct greater or equal
	bool_t 
      operator()( const _Ty &_Left,const _Ty &_Right ) const
		   {
		   return (_Left >= _Right);
		   }
	};

template<class _Ty>
struct Less_equal : public Binary_functor<_Ty,_Ty,bool_t>
	{//struct less or equal
	bool_t 
      operator()( const _Ty &_Left,const _Ty &_Right ) const
		   {
		   return (_Left <= _Right);
		   }
	};

template<class _Ty>
struct Logical_and : public Binary_functor<_Ty,_Ty,bool_t>
	{//struct logical and
	bool_t 
      operator()( const _Ty &_Left,const _Ty &_Right ) const
		   {
		   return (_Left && _Right);
		   }
	};

template<class _Ty>
struct Logical_or : public Binary_functor<_Ty,_Ty,bool_t>
	{//struct logical or
	bool_t 
      operator()( const _Ty &_Left,const _Ty &_Right ) const
		   {
		   return (_Left || _Right);
		   }
	};

/**************************************
				Negations
**************************************/
template<class _Ty>
struct Logical_not : public Unary_functor<_Ty,bool_t>
	{//struct logical not
	bool_t 
      operator()( const _Ty &_Left ) const
		   {
		   return (!_Left);
		   }
	};

template<class _Fn>
class Unary_negate : public Unary_functor<typename _Fn::farg_t,bool_t>
	{//adapter !func( _Left )
public:
	explicit Unary_negate( const _Fn &_Func ) : Functor(_Func)
		{//constructor
		}
	bool_t 
      operator()( const typename _Fn::farg_t &_Left ) const
		   {//apply functor to operand
		   return (!Functor( _Left ));
		   }

protected:
	_Fn Functor;	//the functor
	};

template<class _Fn> inline 
   Unary_negate<_Fn> unary_not( const _Fn &_Func )
	   {//function unary not
	   return (Unary_negate<_Fn>( _Func ));
	   }

template<class _Fn>
class Binary_negate : public Binary_functor<typename _Fn::farg_t,typename _Fn::sarg_t,bool_t>
	{//adapter !func( _Left,_Right )	
public:
	explicit Binary_negate( const _Fn &_Func ) : Functor(_Func)
		{//constructor
		}
	bool_t 
      operator()( const typename _Fn::farg_t &_Left,const typename _Fn::sarg_t &_Right ) const
		   {//apply functor to operands
		   return (!Functor( _Left,_Right ));
		   }

protected:
	_Fn Functor;	//the functor
	};

template<class _Fn> inline 
   Binary_negate<_Fn> binary_not( const _Fn &_Func )
	   {//function binary not
	   return (Binary_negate<_Fn>( _Func ));
	   }

/**************************************
					Binders
**************************************/
template<class _Fn>
class Binder_first : public Unary_functor<typename _Fn::sarg_t,typename _Fn::retd_t>
	{//adapter func( stored,_Right )
public:
	typedef Unary_functor<typename _Fn::sarg_t,typename _Fn::retd_t> Self_base;
	typedef typename Self_base::farg_t _Ag;
	typedef typename Self_base::retd_t _Rt;

	Binder_first( const _Fn &_Func,const typename _Fn::farg_t &_Left ) : Op(_Func),Value(_Left)
		{//constructor
		}
	_Rt 
      operator()( const _Ag &_Right ) const
		   {//apply functor to operands
		   return (Op( Value,_Right ));
		   }
	_Rt 
      operator()( _Ag &_Right ) const
		   {//apply functor to operands
		   return (Op( Value,_Right ));
		   }

protected:
	_Fn Op;	//the functor
	typename _Fn::farg_t Value; //the _Left operand
	};

template<class _Fn,class _Ty> inline 
   Binder_first<_Fn> bind_first( const _Fn &_Func,const _Ty &_Left )
	   {//function bind first operand
	   typename _Fn::farg_t 
         _Tmp(_Left);
	   return (Binder_first<_Fn>( _Func,_Tmp ));
	   }

template<class _Fn>
class Binder_second : public Unary_functor<typename _Fn::farg_t,typename _Fn::retd_t>
	{//adapter func( _Left,stored )
public:
	typedef Unary_functor<typename _Fn::farg_t,typename _Fn::retd_t> Self_base;
	typedef typename Self_base::farg_t _Ag;
	typedef typename Self_base::retd_t _Rt;

	Binder_second( const _Fn &_Func,const typename _Fn::sarg_t &_Right) : Op(_Func),Value(_Right)
		{//constructor
		}
	_Rt 
      operator()( const _Ag &_Left ) const
		   {//apply functor to operands
		   return (Op( _Left,Value ));
		   }
	_Rt 
      operator()( _Ag &_Left ) const
		   {//apply functor to operands
		   return (Op( _Left,Value ));
		   }

protected:
	_Fn 
      Op;   //the functor
	typename _Fn::sarg_t 
      Value;//the _Right operand
	};

template<class _Fn,class _Ty> inline 
   Binder_second<_Fn> bind_second( const _Fn &_Func,const _Ty &_Right )
	   {//function bind second operand
	   typename _Fn::sarg_t 
         _Tmp(_Right);
	   return (Binder_second<_Fn>( _Func,_Tmp ));
	   }

/**************************************
	Pointers to adapters of functions
**************************************/
template<class _Af,class _Rt,class _Fn = _Rt (*)(_Af)>
class Unary_pointer_function : public Unary_functor<_Af,_Rt>
	{//adapter (*pfunc)(_Left)
public:
	explicit Unary_pointer_function( _Fn _Left ) : _Pfun(_Left)
		{//construct from pointer
		}
	_Rt 
      operator()( _Af _Left ) const
		   {//call function with operand
		   return (_Pfun( _Left ));
		   }

protected:
	_Fn   //pointer to unary function
      _Pfun;
	};

template<class _Af,class _As,class _Rt,class _Fn = _Rt (*)(_Af,_As)>
class Binary_pointer_function	: public Binary_functor<_Af,_As,_Rt>
	{//adapter (*pfunc)( _Left,_Right )
public:
	explicit Binary_pointer_function( _Fn _Left ) : _Pfun(_Left)
		{//construct from pointer
		}
	_Rt 
      operator()( _Af _Left,_As _Right ) const
		   {//call function with operands
		   return (_Pfun( _Left,_Right ));
		   }

protected:
	_Fn   //pointer to binary function
      _Pfun;
	};

template<class _Af,class _Rt> inline 
   Unary_pointer_function<_Af,_Rt,_Rt (*)(_Af)> ptr_fun( _Rt (*_Left)(_Af))
	   {//function pointer to unary function
	   return (Unary_pointer_function<_Af,_Rt,_Rt (*)(_Af)>( _Left ));
	   }

template<class _Af,class _As,class _Rt> inline 
   Binary_pointer_function<_Af,_As,_Rt,_Rt(*)(_Af,_As)> ptr_fun( _Rt (*_Left)(_Af,_As))
	   {//function Pointer to binary function
	   return (Binary_pointer_function<_Af,_As,_Rt,_Rt (*)(_Af,_As)>(_Left)>( _Left ));
	   }

/**************************************
					Adapters
	for pointer to member function
**************************************/
template<class _Rt,class _Ty>
class Mem_function_ptr : public Unary_functor<_Ty*,_Rt>
	{//adapter (*p->*pfunc)(), non-const *pfunc
public:
	explicit Mem_function_ptr(_Rt (_Ty::*_Pm)()) : _Pmemfun(_Pm)
		{//constructor
		}
	_Rt 
      operator()( _Ty *_Left ) const
		   {//call function
		   return ((_Left->*_Pmemfun)());
		   }

private:
	_Rt (_Ty::*_Pmemfun)();	// the member function pointer
	};

template<class _Rt,class _Ty,class _Ag>
class Mem_function_ptr_arg : public Binary_functor<_Ty*,_Ag,_Rt>
	{//adapter (*p->*pfunc)(val), non-const *pfunc
public:
	explicit Mem_function_ptr_arg(_Rt (_Ty::*_Pm)(_Ag)) : _Pmemfun(_Pm)
		{//constructor
		}
	_Rt 
      operator()( _Ty *_Left,_Ag _Right ) const
		   {//call function with operand
		   return ((_Left->*_Pmemfun)( _Right ));
		   }

private:
	_Rt (_Ty::*_Pmemfun)(_Ag);	// the member function pointer
	};

template<class _Rt,class _Ty>
class Const_mem_function_ptr : public Unary_functor<const _Ty*,_Rt>
	{//adapter (*p->*pfunc)(), const *pfunc
public:
	explicit Const_mem_function_ptr(_Rt (_Ty::*_Pm)() const) : _Pmemfun(_Pm)
		{//constructor
		}
	_Rt 
      operator()( const _Ty *_Left ) const
		   {//call function
		   return ((_Left->*_Pmemfun)());
		   }

private:
	_Rt (_Ty::*_Pmemfun)() const;	// the member function pointer
	};

template<class _Rt,class _Ty,class _Ag>
class Const_mem_function_ptr_arg : public Binary_functor<const _Ty*,_Ag,_Rt>
	{//adapter (*p->*pfunc)(val), const *pfunc
public:
	explicit Const_mem_function_ptr_arg(_Rt (_Ty::*_Pm)(_Ag) const) : _Pmemfun(_Pm)
		{//constructor
		}
	_Rt 
      operator()( const _Ty *_Left,_Ag _Right ) const
		   {//call function with operand
		   return ((_Left->*_Pmemfun)( _Right ));
		   }

private:
	_Rt (_Ty::*_Pmemfun)(_Ag) const;	// the member function pointer
	};

template<class _Rt,class _Ty> inline 
   Mem_function_ptr<_Rt,_Ty> mem_fun( _Rt (_Ty::*_Pm)())
	   {//adapter for member function without argument
	   return (Mem_function_ptr<_Rt,_Ty>( _Pm ));
	   }

template<class _Rt,class _Ty,class _Ag> inline 
   Mem_function_ptr_arg<_Rt,_Ty,_Ag> mem_fun( _Rt (_Ty::*_Pm)(_Ag))
	   {//adapter for member function with one argument
	   return (Mem_function_ptr_arg<_Rt,_Ty,_Ag>( _Pm ));
	   }

template<class _Rt,class _Ty> inline 
   Const_mem_function_ptr<_Rt, _Ty> mem_fun( _Rt (_Ty::*_Pm)() const)
	   {//adapter for const member function without argument
	   return (Const_mem_function_ptr<_Rt,_Ty>( _Pm ));
	   }

template<class _Rt,class _Ty,class _Ag> inline 
   Const_mem_function_ptr_arg<_Rt,_Ty,_Ag> mem_fun( _Rt (_Ty::*_Pm)(_Ag) const)
	   {//adapter for const member function with one argument
	   return (Const_mem_function_ptr_arg<_Rt,_Ty,_Ag>( _Pm ));
	   }

/**************************************
					Adapters
	for reference to member function
**************************************/
template<class _Rt,class _Ty>
class Mem_function_ref : public Unary_functor<_Ty,_Rt>
	{//functor adapter (*left.*pfunc)(), non-const *pfunc
public:
	explicit Mem_function_ref(_Rt (_Ty::*_Pm)()) : _Pmemfun(_Pm)
		{//construct from pointer
		}
	_Rt 
      operator()( _Ty &_Left) const
		   {//call function
		   return ((_Left.*_Pmemfun)());
		   }

private:
	_Rt (_Ty::*_Pmemfun)();	// the member function pointer
	};

template<class _Rt,class _Ty,class _Ag>
class Mem_function_ref_arg	: public Binary_functor<_Ty,_Ag,_Rt>
	{//functor adapter (*left.*pfunc)(val), non-const *pfunc
public:
	explicit Mem_function_ref_arg(_Rt (_Ty::*_Pm)(_Ag)) : _Pmemfun(_Pm)
		{//construct from pointer
		}

	_Rt 
      operator()( _Ty &_Left,_Ag _Right ) const
		   {//call function with operand
		   return ((_Left.*_Pmemfun)( _Right ));
		   }

private:
	_Rt (_Ty::*_Pmemfun)(_Ag);	// the member function pointer
	};

template<class _Rt,class _Ty>
class Const_mem_function_ref : public Unary_functor<_Ty,_Rt>
	{//functor adapter (*left.*pfunc)(), const *pfunc
public:
	explicit Const_mem_function_ref(_Rt (_Ty::*_Pm)() const) : _Pmemfun(_Pm)
		{//construct from pointer
		}

	_Rt 
      operator()( const _Ty &_Left ) const
		   {	// call function
		   return ((_Left.*_Pmemfun)());
		   }

private:
	_Rt (_Ty::*_Pmemfun)() const;	// the member function pointer
	};

template<class _Rt,class _Ty,class _Ag>
class Const_mem_function_ref_arg	: public Binary_functor<_Ty,_Ag,_Rt>
	{//functor adapter (*left.*pfunc)(val), const *pfunc
public:
	explicit Const_mem_function_ref_arg(_Rt (_Ty::*_Pm)(_Ag) const) : _Pmemfun(_Pm)
		{//construct from pointer
		}

	_Rt 
      operator()( const _Ty &_Left,_Ag _Right ) const
		   {//call function with operand
		   return ((_Left.*_Pmemfun)( _Right ));
		   }

private:
	_Rt (_Ty::*_Pmemfun)(_Ag) const;	// the member function pointer
	};

template<class _Rt,class _Ty> inline
   Mem_function_ref<_Rt,_Ty> mem_fun_ref(_Rt (_Ty::*_Pm)())
	   {//return a mem_fun_ref_t functor adapter
	   return (Mem_function_ref<_Rt,_Ty>( _Pm ));
	   }

template<class _Rt,class _Ty,class _Ag> inline
   Mem_function_ref_arg<_Rt,_Ty,_Ag> mem_fun_ref(_Rt (_Ty::*_Pm)(_Ag))
	   {//return a mem_fun1_ref_t functor adapter
	   return (Mem_function_ref_arg<_Rt,_Ty,_Ag>( _Pm ));
	   }

template<class _Rt,class _Ty> inline
   Const_mem_function_ref<_Rt,_Ty> mem_fun_ref(_Rt (_Ty::*_Pm)() const)
	   {//return a const_mem_fun_ref_t functor adapter
	   return (Const_mem_function_ref<_Rt,_Ty>( _Pm ));
	   }

template<class _Rt,class _Ty,class _Ag> inline
   Const_mem_function_ref_arg<_Rt,_Ty,_Ag> mem_fun_ref(_Rt (_Ty::*_Pm)(_Ag) const)
	   {//return a const_mem_fun1_ref_t functor adapter
	   return (Const_mem_function_ref_arg<_Rt,_Ty,_Ag>( _Pm ));
	   }

_ESK_END
#pragma pack(pop)
#endif//FNCTNL_H
