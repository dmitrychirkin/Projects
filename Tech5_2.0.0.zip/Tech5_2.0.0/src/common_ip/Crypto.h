#pragma		once
#ifndef		CRYPTO_H
#define		CRYPTO_H

//	Use project headers
#include		"Eskdef.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
		      Cryptography 
 Russian Federation standard 28147-89
**************************************/
#define O_CRYPTO_KEY    "INSTALL_JULWIN_OKEY_14"
#define C_CRYPTO_KEY    "INSTALL_JULWIN_CKEY_14"

#define _CIRCLE_OPEN_CRYPTO_BLOCKS( FUNC )                                                         \
   {/* network of block */                                                                         \
   quad_t *_BlockSrc = (quad_t*)_Src,                                                              \
          *_BlockDst = (quad_t*)_Dst;                                                              \
                                                                                                   \
   for(uint_t _Ind = 0,_Blk = _Len >> 3; _Ind < _Blk; _Ind++)                                      \
      {                                                                                            \
      _BlockDst[_Ind] = FUNC;                                                                      \
      }                                                                                            \
   }

#define _CIRCLE_TAIL_GAMMA_FACTOR_( FUNC,TAIL )                                                    \
   {/* network of tails */                                                                         \
   if (_Len & 7)                                                                                   \
      {                                                                                            \
      byte_t *_Byte_Src = _Src + ((_Len >> 3) << 3),                                               \
             *_Byte_Dst = _Dst + ((_Len >> 3) << 3); quad_t _Tail = TAIL;                          \
                                                                                                   \
      for(uint_t _Idx = 0; _Idx < (_Len & 7); _Idx++)                                              \
         {                                                                                         \
         _Byte_Dst[_Idx] = FUNC;                                                                   \
         }                                                                                         \
      }                                                                                            \
   }

#define _CIRCLE_OPEN_CRYPTO_INSERT( FUNC )                                                         \
   {/* insert signature */                                                                         \
   quad_t *_BlockSrc = (quad_t*)_Src,                                                              \
           _Ins = 0;                                                                               \
                                                                                                   \
   for(uint_t _Ind = 0,_Blk = _Len >> 3; _Ind < _Blk; _Ind++)                                      \
      {                                                                                            \
      _Ins = FUNC;                                                                                 \
      }                                                                                            \
   return _Ins;                                                                                    \
   }

//-------------------------------------
// Implementation
//-------------------------------------
class Crypto
	{//cryptography
   enum
      {
      SIZE = 8,
      };

   //-------------------------------
   // Constructors
   //-------------------------------
public:
   Crypto() : Hgen(),Lgen()
      {//default constructor - test regime
      keydel();
      }

   Crypto( const char *_Psw ) : Hgen(),Lgen()
      {//construct keys from string
      keydel();

      for( ; *_Psw; _Psw++ )
         {//look over string
         for(uint_t i = 0; i < SIZE; i++)
            Keys[i] = uint_t( encryp( *_Psw ));
         }
      }

   Crypto( const quad_t &_Syn ) : Hgen(),Lgen()
      {//construct keys from synchronous parcel
      keydel();
      random( _Syn );

      for(uint_t i = 0; i < SIZE; i++)
         Keys[i] = uint_t( encryp( random()));
      }

   //-------------------------------
   // Interface functions
   //-------------------------------
public:
   template<class _Ty> void_t
      encryp( _Ty *_Dst,_Ty *_Src,uint_t _Len,quad_t _Syn )
         {//cipher: regime gamma factor with synchronous parcel
         random( _Syn );

         _CIRCLE_OPEN_CRYPTO_BLOCKS( _BlockSrc[_Ind] ^ encryp( random()));
         _CIRCLE_TAIL_GAMMA_FACTOR_( _Byte_Src[_Idx] ^ ((_Tail >> (_Idx << 3)) & 0xff),encryp( random()));
         }

   template<class _Ty> void_t
      decryp( _Ty *_Dst,_Ty *_Src,uint_t _Len,quad_t _Syn )
         {//source: regime gamma factor with synchronous parcel
         random( _Syn );

         _CIRCLE_OPEN_CRYPTO_BLOCKS( _BlockSrc[_Ind] ^ encryp( random()));
         _CIRCLE_TAIL_GAMMA_FACTOR_( _Byte_Src[_Idx] ^ ((_Tail >> (_Idx << 3)) & 0xff),encryp( random()));
         }

   template<class _Ty> void_t
      enloop( _Ty *_Dst,_Ty *_Src,uint_t _Len,quad_t _Syn )
         {//cipher: regime backloop gamma with synchronous parcel
         _Syn = encryp( _Syn );

         _CIRCLE_OPEN_CRYPTO_BLOCKS( _BlockSrc[_Ind] ^ _Syn; _Syn = encryp( _BlockDst[_Ind] ));
         _CIRCLE_TAIL_GAMMA_FACTOR_( _Byte_Src[_Idx] ^ ((_Tail >> (_Idx << 3)) & 0xff),_Syn );
         }

   template<class _Ty> void_t
      deloop( _Ty *_Dst,_Ty *_Src,uint_t _Len,quad_t _Syn )
         {//source: regime backloop gamma with synchronous parcel
         _Syn = encryp( _Syn );

         _CIRCLE_OPEN_CRYPTO_BLOCKS( _BlockSrc[_Ind] ^ _Syn; _Syn = encryp( _BlockSrc[_Ind] ));
         _CIRCLE_TAIL_GAMMA_FACTOR_( _Byte_Src[_Idx] ^ ((_Tail >> (_Idx << 3)) & 0xff),_Syn );
         }

   template<class _Ty> void_t
      encryp( _Ty *_Dst,_Ty *_Src,uint_t _Len )
         {//cipher: regime simple replacement
         _CIRCLE_OPEN_CRYPTO_BLOCKS( encryp( _BlockSrc[_Ind] ));
         }

   template<class _Ty> void_t
      decryp( _Ty *_Dst,_Ty *_Src,uint_t _Len )
         {//source: regime simple replacement
         _CIRCLE_OPEN_CRYPTO_BLOCKS( decryp( _BlockSrc[_Ind] ));
         }

   template<class _Ty> quad_t
      insert( _Ty *_Src,uint_t _Len )
         {//get simple signature
         _CIRCLE_OPEN_CRYPTO_INSERT( insert( _Ins ^ _BlockSrc[_Ind] ));
         }

   //-------------------------------
   // Base circles
   //-------------------------------
private:
   quad_t
      encryp( quad_t _Dat )
         {//encode only 8 bytes
         for(iint_t i = 0; i < SIZE;) _Dat = core( _Dat,Keys[i++] );
         for(iint_t i = 0; i < SIZE;) _Dat = core( _Dat,Keys[i++] );
         for(iint_t i = 0; i < SIZE;) _Dat = core( _Dat,Keys[i++] );
         for(iint_t i = SIZE; i > 0;) _Dat = core( _Dat,Keys[--i] );

         //final exchange
         return swap( _Dat );
         }

   quad_t
      decryp( quad_t _Dat )
         {//decode only 8 bytes
         for(iint_t i = 0; i < SIZE;) _Dat = core( _Dat,Keys[i++] );
         for(iint_t i = SIZE; i > 0;) _Dat = core( _Dat,Keys[--i] );
         for(iint_t i = SIZE; i > 0;) _Dat = core( _Dat,Keys[--i] );
         for(iint_t i = SIZE; i > 0;) _Dat = core( _Dat,Keys[--i] );

         //final exchange
         return swap( _Dat );
         }

   quad_t
      insert( quad_t _Dat )
         {//signature of 8 bytes
         for(iint_t i = 0; i < SIZE;) _Dat = core( _Dat,Keys[i++] );
         for(iint_t i = 0; i < SIZE;) _Dat = core( _Dat,Keys[i++] );

         //signature
         return _Dat;
         }

   void_t
      keydel()
         {//clear keys
         for(uint_t i = 0; i < SIZE; i++)
            Keys[i] = 0;
         }

   //-------------------------------
   // Base step
   //-------------------------------
private:
   quad_t
      swap( quad_t _Dat )
         {//swap low and high part of date
         return ((_Dat & 0xffffffff) << 32) | (_Dat >> 32);
         }

   quad_t
      core( quad_t _Dat,uint_t _Key )
         {//base cryptography step
         static uint_t 
            Bent_functions[] = //bent-functions [8*16]
               {
   #ifndef _BENT_FUNCTIONS_ARTICLE
               /*
                0,  1,  9, 14, 13, 11,  7,  6, 15,  2, 12,  5, 10,  4,  3,  8,
                0,  1, 11, 13,  9, 14,  6,  7, 12,  5,  8,  3, 15,  2,  4, 10,
                0,  1,  2,  4,  3,  5,  8, 10,  7,  9,  6, 13, 11, 14, 12, 15,
                0,  1, 11,  2,  8,  6, 15,  3, 14, 10,  4,  9, 13,  5,  7, 12,
                0,  1, 11,  2,  8,  3, 15,  6, 14, 10,  4,  9, 13,  5,  7, 12,
                0,  4, 11,  2,  8,  6, 10,  1, 14, 15,  3,  9, 13,  5,  7, 12,
                0,  4, 11,  2,  8,  3, 15,  1, 14, 10,  6,  9, 13,  5,  7, 12,
                0, 11, 15,  9,  1,  5,  6,  8,  3, 10,  4, 12, 14, 13,  7,  2,
                0,  7, 10, 14,  9,  1, 13,  8, 12,  2, 11, 15,  3,  5,  4,  6,
                */
                4, 10,  9,  2, 13,  8,  0, 14,  6, 11,  1, 12,  7, 15,  5,  3,
                8,  2, 11, 13,  4,  1, 14,  7,  5, 15,  0,  3, 10,  6,  9, 12,
               10,  5,  3, 15, 12,  9,  0,  6,  1,  2,  8,  4, 11, 14,  7, 13,
                5, 10, 12,  6,  0, 15,  3,  9,  8, 13, 11,  1,  7,  2, 14,  4,
                3,  9, 15,  0,  6, 10,  5, 12, 14,  2,  1,  7, 13,  4,  8, 11,
               15,  0, 10,  9,  3,  5,  4, 14,  8, 11,  1,  7,  6, 12, 13,  2,
               12,  6,  3,  9,  0,  5, 10, 15,  2, 13,  4, 14,  7, 11,  1,  8,
               13, 10,  0,  7,  3,  9, 14,  4,  2, 15, 12,  1,  5,  6, 11,  8,
   #else
               4, 10,  9,  2, 13,  8,  0, 14,  6, 11,  1, 12,  7, 15,  5,  3,
              14, 11,  4, 12,  6, 13, 15, 10,  2,  3,  8,  1,  0,  7,  5,  9,
               5,  8,  1, 13, 10,  3,  4,  2, 14, 15, 12,  7,  6,  0,  9, 11,
               7, 13, 10,  1,  0,  8,  9, 15, 14,  4,  6, 12, 11,  2,  5,  3,
               6, 12,  7,  1,  5, 15, 13,  8,  4, 10,  9, 14,  0,  3, 11,  2,
               4, 11, 10,  0,  7,  2,  1, 13,  3,  6,  8,  5,  9, 12, 15, 14,
              13, 11,  4,  1,  3, 15,  5,  9,  0, 10, 14,  7,  6,  8,  2, 12,
               1, 15, 13,  0,  5,  7, 10,  4,  9,  2,  3, 14,  6, 11,  8, 12
   #endif
               };

         //balanced Feistel network
         uint_t _Sum = uint_t( _Dat ) + _Key;

                _Sum = Bent_functions[( _Sum        & 0xf)      ]        | //0
                      (Bent_functions[((_Sum >>  4) & 0xf) +  16] <<  4) | //1
                      (Bent_functions[((_Sum >>  8) & 0xf) +  32] <<  8) | //2
                      (Bent_functions[((_Sum >> 12) & 0xf) +  48] << 12) | //3
                      (Bent_functions[((_Sum >> 16) & 0xf) +  64] << 16) | //4
                      (Bent_functions[((_Sum >> 20) & 0xf) +  80] << 20) | //5
                      (Bent_functions[((_Sum >> 24) & 0xf) +  96] << 24) | //6
                      (Bent_functions[ (_Sum >> 28)        + 112] << 28);  //7

         //left rotate, xor then swap
         return ((_Dat & 0xffffffff) << 32) | (((_Sum >> 21) |
                                                (_Sum << 11)) ^ uint_t( _Dat >> 32 ));
         }

   //-------------------------------
   // Generator
   //-------------------------------
public:
   void_t
      random( quad_t _Syn )
         {//set synchronous parcel
         _Syn = encryp( _Syn ); Lgen = _Syn &  0xffffffff;
                                Hgen = _Syn >> 32;
         }

   quad_t
      random()
         {//new states of registers
         Lgen += 0x1010101;
         Hgen += 0x1010104;
         Hgen  = (Hgen + ((Hgen >> 32) > 0)) & 0xffffffff;

         //next value
         return  (Lgen |  (Hgen << 32));
         }

private:
   uint_t //secret keys
      Keys[SIZE];
   quad_t //high register
      Hgen;
   uint_t //low register
      Lgen;

   };//Crypto

_ESK_END
#pragma pack(pop)
#endif//CRYPTO_H
