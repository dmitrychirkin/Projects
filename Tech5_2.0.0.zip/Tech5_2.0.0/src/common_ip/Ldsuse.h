/**************************************
					LDSUSE.H
	Dactyloscopic system adjustment.

        Copyright (c) 1994-2004.
        Copyright (c) 2005-2012.
**************************************/
#pragma		once
#ifndef		LDSUSE_H
#define		LDSUSE_H

//	Use project headers
#include		"Ldsdef.h"

#pragma pack(push,_LDS_PACKING)
_LDS_BEGIN
//-------------------------------------
// Name of lays
//-------------------------------------
enum FAMILIES
	{//hash value
	SAMPLE =	 00,
	SOURCE,
	REFINE,
	SKELET,
	DIFFER,
	PROPHE,
   BINARY,
   THPATH,
   MODULE,
	CANVAS,
   ROTATE,
	LIGHTS,

	//reconstruction
   STRIPS = LIGHTS + 04,
   SMOOTH = STRIPS + 04,
	SHADED,
   SHADEV,
	PHOTOL,
   PHOTOH,
   MORPHD,
   MORPHE,
   STYLUS,
	STYLUD,
   STYLUV,
	RIVERL,
   RIVERH,
	SATURN,
	
	//flow
	FLOW_L,
	FLOW_P,
	FLOW_I,
	FLOW_W,
	FLOW_V,
	FLOW_A,
	FLOWsI,
	FLOWsW = FLOWsI + 04,
	FLOWsV = FLOWsW + 04,

	//probability
	PROB_L =	FLOWsV + 04,
	PROB_P,
	PROB_I,
	PROB_W,
	PROB_V,
	PROB_A,
	PROB_H,
	PROBsI,
	PROBsW = PROBsI + 04,
	PROBsV = PROBsW + 04,
	
	//curvature
	ARCH_D =	PROBsV + 04,
	ARCH_V,
	ARCH_T,

	//concordance
	CONC_F,
	CONC_H,

   //gradient
   GRAD_A,
   GRAD_M,

   //tensor
   TENS_A,
   TENS_M,
   TENS_C,
   TARGET,

	//density
	DENSIT,
	DENS_M,
	INTRAR,

	//spectrum
	SPEC_O,
	SPEC_C = SPEC_O + 20,

	//class field
	CCLASS = SPEC_C + 20,
   REGION,
	TYPE_F,
	BETA_F,

	//operator's order
	MORDER,
	DORDER,
	RAWROI,

	//quality
	QUAL_E,
	QUAL_M,
   QUAL_F,

	//goals
	GOAL_F,
	GOAL_I,
	GOAL_M,

	//values
	VORTEX,
	SUMMIT,

	//processing
	PROC_F,
	PROC_S,

	//lists
	LIST_M,
	LIST_S,
	LIST_A,
	LIST_L,
	LIST_T,
	LIST_R,
   LIST_G,
   LIST_V,
	
	//temporary must be the highest
	TEMP_T
	};

//-------------------------------------
// Processing queue
//-------------------------------------
enum QUEUE
	{
	SAMple = 00,
	RELoad,
   SOUrce,
   TENsor,
   STRips,

   //first processing
	LIGhtf,
	STReam,
	PICkup,
	MAPing,

   //second processing
	LIGhts,
	SUMmit,
	ATTrac,
	DEPict,
	SWElls,
	FLOwin,
	CURves,
	FURiew,
	SCHist,
	HARmon,
	FIXing,
	LAYing,
	FILter,
	SKElet,
	LINker,
   DELone,
	EPIlog,

	//segmentation
	TARget,
	FRAmes,
	SLApin,
	THUmbs,
	LATent,

	//learning by instruction
	RATing
	};

//-------------------------------------
// System constants
//-------------------------------------
enum RESOLUTION
   {
   TPLPPI =  500,    //template PPI
   STDPPI =  500,    //standard PPI
   DEFPPI = 1000     //kernal processing PPI
   };

enum LOCALIZATION
   {
   DEFDIR =	   0,    //default image orientation
   DEFTOL =	  20,    //default tolerance
   MAXPPI = 2000,    //maximum dot per inch
   MINPPI =  250,    //minimum dot per inch
   MAXLEN = 8192,    //maximum image size for 1000 PPI
   MINLEN =   96,    //minimum image size for 1000 PPI
   ITEFOR =   32,    //capacity of iterators
   AREA_C =  512,    //default room of differences for area
   LINE_C =   33,    //default room of differences for line
   SING_C =   80,    //default room of singularities
   MINT_C =  266,    //default room of minutiae
   GEAR_C =  512     //constant room of super accelerators
   };

enum VERSIONS
   {
   WIZARD =	  73,    //type of header
   ISSUER =	 100,    //current version
   };

const iint_t   
   /*
   Integrity limits
   */
   ST =   48,		   //number of steps
   MO	=  127,		   //module
   MI	= 2147483647,
   /*
   Quants in byte
   */
   BT =    8,        //bits
   /*
   Directions
   */
   MD =    8,		   //directions
   OX =	  9,	      //ox-eye daisy
   /*
   Angles
   */
   AC	=	 23,		   //
   AQ	=	 45,		   //quarta angle
   AG	=	 60,		   //
   AR	=	 90,		   //right angle
   AS	=  120,		   //
   AW	=  135,		   //
   AH	=  180,		   //open angle
   AO	=  225,		   //
   AL	=  270,		   //
   AU	=  315,		   //
   AF	=  360,  	   //full angle
   /*
   Class interpreter
   */
   C0 =    0,		   //nothing
   C1 =    1,	      //empty
   C2 =    2,	      //steady flow
   C3 =    4,	      //other steady flow
   C4 =    8,	      //empty
   C5 =   16,	      //model flow
   C6 =   32,	      //informative area
   C7 =   64,        //unreadable area
   C8 =  128,	      //helpfull
   /*
   Class combinations
   */
   CG = C2 | C3,     //groop of steady flow
   CA = C7 | C6,	   //groop of areas
   /*
   Work interpreter
   */
   W0 =    0,
   W1 =    1,	      //empty
   W2 =    2,	      //active area
   W3 =    4,	      //empty
   W4 =    8,	      //empty
   W5 =   16,	      //empty
   W6 =   32,	      //informative active area
   W7 =   64,        //unreadable active area
   W8 =  128,	      //empty
   /*
   Mask minutiae interpreter
   */
   M0 =    0,		   //nothing
   M1 =    1,	      //empty
   M2 =    2,	      //minutae
   M3 =    4,	      //doubtfull
   M4 =    8,	      //rupture
   /*
   Singularities
   */
   FN =    0,		   //nothing
   FW	=    1,	      //whorl
   FL	=    2,	      //loop
   FA	=    4,	      //arch
   FD	=    8,	      //delta
   FX	=   16,	      //axes
   FV	=  128,	      //veil
   /*
   Combination of singularities
   */
   FF	= FW | FL | FD | FA,
   /*
   Byte constants
   */
   BB =	  0,		   //bifurcation
   BE	=    1,		   //ending
   BI	=    3,		   //rupture
   BU	=    4,		   //hidrance
   BP	=    5,		   //projection
   BL	=    6,		   //left branch
   BR	=    7,		   //right branch
   BS	=   16,		   //skeleton
   BV	=	 32,		   //veil of skeleton
   BX	=	 64,		   //mark
   BG	=	128,		   //skeleton gap
   BQ	=	256,		   //levels of quantization
   BA	=  127,        //byte median
   BM	=  255,        //byte supremum
   /*
   Quality
   */
   QH	=	 63,		   //maximum value
   QD	=	 64,		   //default
   QU	=	100,		   //percentage
   /*
   Curve
   */
   CL	=	  0,		   //minimum value
   CH	=	 63,		   //maximum value
   /*
   Poincare index
   */
   IW = +220,		   //whorl
   IL = +140,		   //loop
   ID = -140,		   //delta
   /*
   Harmonics
   */
   HM =   11,		   //mean period
   HD =   17,		   //dimension
   HL	=	  1,		   //minimum period
   HH	=	 17,		   //maximum period
   HP	=	  8,		   //multiplier
   /*
   Ridge count
   */
   RM =	 31,		   //maximum ridge count
   RT	=	  3,        //tolerance band
   /*
   Nonentity
   */
   NO	=	 -1;		   //as nothing

enum HIERARCHY
   {
   H0 =	  0,		   //base 1000 PPI
   H1,		         //mul 2
   H2,		         //mul 4
   H3,		         //mul 8
   H4,		         //mul 16
   H5,		         //mul 32
   PY,               //height of pyramid
   HB =    1         //base hierarchy
   };

enum SEGMENTATION
	{
	SHOT = 300
	};

const bool_t NOmp =  0;

_LDS_END
#pragma pack(pop)
#endif//LDSUSE_H
/*
All rights reserved. Consult your license regarding permissions and restrictions.
*/