#pragma		once
#ifndef		UTILIES_H
#define		UTILIES_H

//	Use project header
#include		"Except.h"
#include		"Traits.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
				Swapping
**************************************/
template<class _Ty>
struct Swap
	{//functor to swap two objects
	void_t 
      operator()( _Ty &_Lft,_Ty &_Rht ) const _NOTHROW
		   {
	      const _Ty 
            _Tmp = _Lft; _Lft = _Rht; _Rht = _Tmp;
		   }
	};

template<class _Ty> inline void_t 
   swap( _Ty &_Lft,_Ty &_Rht ) _NOTHROW
	   {//template function to swap two objects
	   Swap<_Ty>()( _Lft,_Rht );
	   }

/**************************************
			Sort algorithms
**************************************/
template<class _Fn,class _Li> inline _Li 
   sort( _Li _List,iint_t _Last,iint_t _First,_Fn _Op = _Fn()) _NOTHROW
	   {//insert sorting
		     register iint_t j;
	   for (register iint_t i = _First+1; i <= _Last; i++)
		   {//sort into boundaries
         const typename _Fn::farg_t 
            _Tmp = _List[i];

		   for (j = i-1; j >= _First && _Op( _Tmp,_List[j] ); j--)
			   {
            _List[j+1] = _List[j];
			   }
         _List[j+1] = _Tmp;
		   }
	   return (_List);
	   }	

template<class _Fn,class _Li> inline _Li 
   sort( _Li _List ) _NOTHROW
	   {//default sorting
	   return sort<_Fn>( _List,8,0 );
	   }

template<class _Fn,class _Li> inline void_t
   insert_sort( _Li _List,iint_t _Last,iint_t _First,_Fn _Op = _Fn()) _NOTHROW
	   {//insert sorting
		     register iint_t j;
	   for (register iint_t i = _First+1; i <= _Last; i++)
		   {//sort into boundaries
         const typename _Li::item_t
            _Tmp = _List[i];

		   for (j = i-1; j >= _First && _Op( _Tmp,_List[j] ); j--)
			   {
            _List[j+1] = _List[j];
			   }
         _List[j+1] = _Tmp;
		   }
	   }	

template<class _Fn,class _Li> inline typename _Li::item_t
   element( const _Li &_List,iint_t _Last,iint_t _First,_Fn _Op = _Fn()) _NOTHROW
	   {//find element into boundaries
	   typename _Li::item_t _Tmp = _List[_First];
	   for (register iint_t i = _First+1; i <= _Last; i++)
		   {
		   if (_Op( _List[i],_Tmp )) _Tmp = _List[i];
		   }
	   return _Tmp;
	   }	

template<class _Fn,class _Li> inline typename _Fn::farg_t
   find( const _Li &_List,iint_t _Last,iint_t _First,_Fn _Op = _Fn()) _NOTHROW
	   {//find element into boundaries
	   typename _Fn::farg_t _Tmp = _List[_First];
	   for (register iint_t i = _First+1; i <= _Last; i++)
		   {
		   if (_Op( _List[i],_Tmp )) _Tmp = _List[i];
		   }
  	   return _Tmp;
	   }	

/**************************************
           Template Pair
**************************************/
template<class _Ty,class _Tp>
struct Pair_base
	{//store a pair of values
	typedef Pair_base<_Ty,_Tp> Self_t;
	typedef _Ty first_type;
	typedef _Tp second_type;

	Pair_base() : First(),Second()
		{//construct from defaults
		}

	Pair_base( const Pair_base<_Ty,_Tp> &_Rht ) : First(_Rht.First),Second(_Rht.Second)
		{//construct by copying
		}

	Pair_base( const _Ty &_Lft,const _Tp &_Rht ) : First(_Lft),Second(_Rht)
		{//construct from specified values
		}

	_Ty First;	//the first stored value
	_Tp Second;	//the second stored value

	};//Pair_base

template<class _Ty,class _Tp>
struct Pair	: public Pair_base<_Ty,_Tp>
	{	// store a pair of values
	typedef Pair_base<_Ty,_Tp> Base_t;
	typedef Pair     <_Ty,_Tp> Self_t;
	typedef _Ty first_type;
	typedef _Tp second_type;

	Pair() : Base_t()
		{//construct from defaults
		}

	Pair( const _Ty &_Lft,const _Tp &_Rht ) : Base_t( _Lft,_Rht )
		{//construct from specified values
		}

	template<class _Lty,class _Rty>
	Pair( Pair<_Lty,_Rty> &_Rht ) : Base_t( _Rht.First,_Rht.Second )
		{	// construct from compatible pair
		}

	template<class _Lty,class _Rty>
	Pair( const Pair<_Lty,_Rty> &_Rht ) : Base_t( _Rht.First,_Rht.Second )
		{//construct from compatible pair
		}

	Self_t& 
      operator=( const Self_t &_Rht )
		   {//assign from copied pair
		   this->First  = _Rht.First;
		   this->Second = _Rht.Second;
		   return (*this);
		   }

	void_t 
      swap( Self_t &_Rht )
		   {//exchange contents with _Rht
		   if (this != &_Rht)
			   {//different, worth swapping
			   swap( this->First ,_Rht.First  );
			   swap( this->Second,_Rht.Second );
			   }
		   }

	};//Pair

//-------------------------------------
//		Pair template operators
//-------------------------------------
template<class _Ty,class _Tp> inline bool_t
   operator==( const Pair<_Ty,_Tp> &_Lft,const Pair<_Ty,_Tp> &_Rht )
	   {//test for pair equality
	   return (_Lft.First == _Rht.First && _Lft.Second == _Rht.Second);
	   }

template<class _Ty,class _Tp> inline bool_t
   operator!=( const Pair<_Ty,_Tp> &_Lft,const Pair<_Ty,_Tp> &_Rht )
	   {//test for pair inequality
	   return (!(_Lft == _Rht));
	   }

template<class _Ty,class _Tp> inline bool_t
   operator<( const Pair<_Ty,_Tp> &_Lft,const Pair<_Ty,_Tp> &_Rht )
	   {//test if _Lft < _Rht for pairs
	   return (_Lft.First < _Rht.First ||
		      !(_Rht.First < _Lft.First) && _Lft.Second < _Rht.Second);
	   }															

template<class _Ty,class _Tp> inline bool_t
   operator>( const Pair<_Ty,_Tp> &_Lft,const Pair<_Ty,_Tp> &_Rht )
	   {//test if _Lft > _Rht for pairs
	   return (_Rht < _Lft);
	   }

template<class _Ty,class _Tp> inline bool_t
   operator<=( const Pair<_Ty,_Tp> &_Lft,const Pair<_Ty,_Tp> &_Rht )
	   {//test if _Lft <= _Rht for pairs
	   return (!(_Rht < _Lft));
	   }

template<class _Ty,class _Tp> inline bool_t
   operator>=( const Pair<_Ty,_Tp> &_Lft,const Pair<_Ty,_Tp> &_Rht )
	   {//test if _Lft >= _Rht for pairs
	   return (!(_Lft < _Rht));
	   }

template<class _Ty,class _Tp> inline Pair<_Ty,_Tp> 
   make_pair( const _Ty &_Key,const _Tp &_Val )
	   {//return pair composed from arguments
	   return (Pair<_Ty,_Tp>( _Key,_Val ));
	   }

template<class _Ty,class _Tp> inline void_t
   swap( Pair<_Ty,_Tp> &_Lft,Pair<_Ty,_Tp> &_Rht )
	   {//swap _Lft and _Rht pairs
	   _Lft.swap( _Rht );
	   }

_ESK_END
#pragma pack(pop)
#endif//UTILIES_H
