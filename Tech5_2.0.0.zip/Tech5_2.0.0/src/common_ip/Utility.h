/**************************************
					UTILITY.H
		 Modified utility header.

        Copyright (c) 1994-2004.
        Copyright (c) 2005-2012.		
**************************************/
#pragma		once
#ifndef		UTILITY_H
#define		UTILITY_H

//	Use project header
#include		"Traits.h"

#pragma pack(push,_LDS_PACKING)
_LDS_BEGIN
/**************************************
       Identify type as movable
**************************************/
template<class _Ty>
struct Identity
	{//map _Ty to type unchanged
	typedef _Ty type;

	const _Ty& 
      operator()( const _Ty &_Left ) const
		   {//apply identity operator to operand
		   return (_Left);
		   }
	};

template<class _Ty> inline	_Ty& 
   forward( typename Identity<_Ty>::type &_Arg) throw()
	   {//forward _Arg, given explicitly specified type parameter
	   return ((_Ty&)_Arg);
	   }

template<class _Ty> inline typename Remove_reference<_Ty>::type&
   movable( _Ty &_Arg ) throw()
	   {//forward _Arg as movable
	   return ((typename Remove_reference<_Ty>::type&)_Arg);
	   }

/**************************************
				Swapping
**************************************/
template<class _Ty>
struct Swap
	{//functor to swap two objects
	void_t 
      operator()( _Ty &_Lft,_Ty &_Rht )
		   {
	      _Ty _Tmp = movable( _Lft );
	          _Lft = movable( _Rht );
	          _Rht = movable( _Tmp );
		   }
	};

template<class _Ty> inline void_t 
   swap( _Ty &_Lft,_Ty &_Rht )
	   {//template function to swap two objects
	   Swap<_Ty>()( _Lft,_Rht );
	   }

/**************************************
			Sort algorithms
**************************************/
template<class _Fn,class _Ty> inline _Ty 
   sort( _Ty _List,iint_t _Last,iint_t _First,_Fn _Op = _Fn())
	   {//insert sorting
		     register iint_t j;
	   for (register iint_t i = _First+1; i <= _Last; i++)
		   {//sort into boundaries
		   typename _Fn::farg_type _Tmp = movable( _List[i] );
		   for (j = i-1; j >= _First && _Op( _Tmp,_List[j] ); j--)
			   {
			   _List[j+1] = movable( _List[j] );
			   }
		   _List[j+1] = movable( _Tmp );
		   }
	   return (_List);
	   }	

template<class _Fn,class _Ty> inline _Ty 
   sort( _Ty _List )
	   {//default sorting
	   return sort<_Fn>( _List,8,0 );
	   }

template<class _Fn,class _Ty> inline void_t
   insert_sort( _Ty _List,iint_t _Last,iint_t _First,_Fn _Op = _Fn())
	   {//insert sorting
		     register iint_t j;
	   for (register iint_t i = _First+1; i <= _Last; i++)
		   {//sort into boundaries
		   typename _Ty::value_type _Tmp = movable( _List[i] );
		   for (j = i-1; j >= _First && _Op( _Tmp,_List[j] ); j--)
			   {
			   _List[j+1] = movable( _List[j] );
			   }
		   _List[j+1] = movable( _Tmp );
		   }
	   }	

template<class _Fn,class _Ty> inline _Ty
   quick_sort( _Ty _List,iint_t _Last,iint_t _First,_Fn _Op = _Fn())
	   {//quick sorting
	   for (register iint_t b = _First,t = _Last; b < t;)
		   {//look upper list
		   for (;b < t; t--)
			   if (_Op( _List[t],_List[b] ))
				   {
				   swap( _List[t],_List[b] ); break;
				   }
		   //look down list
		   for (;b < t; b++)
			   if (_Op( _List[t],_List[b] ))
				   {
				   swap( _List[t],_List[b] ); break;
				   }

		   //sort upper list
		   if (_First < b-1)
			   quick_sort<_Fn>( _List,b-1,_First );
		   //sort down list
		   if (_Last > b+1)
			   quick_sort<_Fn>( _List,_Last,b+1 );
		   }
      return (_List);
	   }	

template<class _Fn,class _Li> inline typename _Li::value_type 
   element( const _Li &_List,iint_t _Last,iint_t _First,_Fn _Op = _Fn())
	   {//find element into boundaries
	   typename _Li::value_type _Tmp = _List[_First];
	   for (register iint_t i = _First+1; i <= _Last; i++)
		   {
		   if (_Op( _List[i],_Tmp )) _Tmp = _List[i];
		   }
	   return _Tmp;
	   }	

/**************************************
           Template Pair
**************************************/
template<class _Ty,class _Tp>
struct Pair_base
	{//store a pair of values
	typedef Pair_base<_Ty,_Tp> Self_t;
	typedef _Ty first_type;
	typedef _Tp second_type;

	Pair_base() : First(_Ty()),Second(_Tp())
		{//construct from defaults
		}

	Pair_base( const Pair_base<_Ty,_Tp> &_Rht ) : First(_Rht.First),Second(_Rht.Second)
		{//construct by copying
		}

	Pair_base( const _Ty &_Lft,const _Tp &_Rht ) : First(_Lft),Second(_Rht)
		{//construct from specified values
		}

	typedef typename Remove_reference<_Ty>::type _Tyx;
	typedef typename Remove_reference<_Tp>::type _Tpx;

	Pair_base( _Tyx &_Lft,_Tpx &_Rht ) : First(movable(_Lft)),Second(movable(_Rht))
		{//construct from specified values
		}

	Pair_base( const _Tyx &_Lft,_Tpx &_Rht ) : First(_Lft),Second(movable(_Rht))
		{//construct from specified values
		}

	Pair_base( _Tyx &_Lft,const _Tpx &_Rht ) : First(movable(_Lft)),Second(_Rht)
		{//construct from specified values
		}

	template<class _Lty,class _Rty>
	Pair_base( _Lty &_Lft,_Rty &_Rht ) : First(forward<_Lty>(_Lft)),Second(forward<_Rty>(_Rht))
		{//construct from moved values
		}

	_Ty First;	//the first stored value
	_Tp Second;	//the second stored value

	};//Pair_base

template<class _Ty,class _Tp>
struct Pair	: public Pair_base<_Ty,_Tp>
	{	// store a pair of values
	typedef Pair_base<_Ty,_Tp> Base_t;
	typedef Pair     <_Ty,_Tp> Self_t;
	typedef _Ty first_type;
	typedef _Tp second_type;

	Pair() : Base_t()
		{//construct from defaults
		}

	Pair( const _Ty &_Lft,const _Tp &_Rht ) : Base_t( _Lft,_Rht )
		{//construct from specified values
		}

	template<class _Lty,class _Rty>
	Pair( Pair<_Lty,_Rty> &_Rht ) : Base_t( _Rht.First,_Rht.Second )
		{	// construct from compatible pair
		}

	template<class _Lty,class _Rty>
	Pair( const Pair<_Lty,_Rty> &_Rht ) : Base_t( _Rht.First,_Rht.Second )
		{//construct from compatible pair
		}

	void_t 
      swap( Self_t &_Rht )
		   {//exchange contents with _Rht
		   if (this != &_Rht)
			   {//different, worth swapping
			   swap( this->First ,_Rht.First  );
			   swap( this->Second,_Rht.Second );
			   }
		   }

	Self_t& 
      operator=( const Self_t &_Rht )
		   {//assign from copied pair
		   this->First  = _Rht.First;
		   this->Second = _Rht.Second;
		   return (*this);
		   }

	typedef typename Remove_reference<_Ty>::type _Tyx;
	typedef typename Remove_reference<_Tp>::type _Tpx;

	Pair( _Tyx &_Lft,_Tpx &_Rht ) : Base_t(moveable(_Lft),movable(_Rht))
		{//construct from specified values
		}

	Pair( const _Tyx &_Lft,_Tpx &_Rht ) : Base_t(_Lft,movable(_Rht))
		{//construct from specified values
		}

	Pair( _Tyx &_Lft,const _Tpx &_Rht ) : Base_t(movable(_Lft),_Rht )
		{	// construct from specified values
		}

	template<class _Lty,class _Rty>
	Pair( _Lty &_Lft,_Rty &_Rht ) : Base_t(forward<_Lty>(_Lft),forward<_Rty>(_Rht))
		{//construct from moved values
		}


	Pair& 
      operator=( Pair<_Ty,_Tp> &_Rht )
		   {//assign from moved pair
		   this->First  = movable( _Rht.First  );
		   this->Second = movable( _Rht.Second );
		   return (*this);
		   }

	};//Pair

//-------------------------------------
//		Pair template operators
//-------------------------------------
template<class _Ty,class _Tp> inline bool_t
   operator==( const Pair<_Ty,_Tp> &_Lft,const Pair<_Ty,_Tp> &_Rht )
	   {//test for pair equality
	   return (_Lft.First == _Rht.First && _Lft.Second == _Rht.Second);
	   }

template<class _Ty,class _Tp> inline bool_t
   operator!=( const Pair<_Ty,_Tp> &_Lft,const Pair<_Ty,_Tp> &_Rht )
	   {//test for pair inequality
	   return (!(_Lft == _Rht));
	   }

template<class _Ty,class _Tp> inline bool_t
   operator<( const Pair<_Ty,_Tp> &_Lft,const Pair<_Ty,_Tp> &_Rht )
	   {//test if _Lft < _Rht for pairs
	   return (_Lft.First < _Rht.First ||
		      !(_Rht.First < _Lft.First) && _Lft.Second < _Rht.Second);
	   }															

template<class _Ty,class _Tp> inline bool_t
   operator>( const Pair<_Ty,_Tp> &_Lft,const Pair<_Ty,_Tp> &_Rht )
	   {//test if _Lft > _Rht for pairs
	   return (_Rht < _Lft);
	   }

template<class _Ty,class _Tp> inline bool_t
   operator<=( const Pair<_Ty,_Tp> &_Lft,const Pair<_Ty,_Tp> &_Rht )
	   {//test if _Lft <= _Rht for pairs
	   return (!(_Rht < _Lft));
	   }

template<class _Ty,class _Tp> inline bool_t
   operator>=( const Pair<_Ty,_Tp> &_Lft,const Pair<_Ty,_Tp> &_Rht )
	   {//test if _Lft >= _Rht for pairs
	   return (!(_Lft < _Rht));
	   }

template<class _Ty,class _Tp> inline Pair<_Ty,_Tp> 
   make_pair( _Ty &_Key,_Tp &_Val )
	   {//return pair composed from arguments
	   return (Pair<_Ty,_Tp>( forward<_Ty>(_Key),forward<_Tp>(_Val)));
	   }

template<class _Ty,class _Tp> inline Pair<_Ty,_Tp> 
   make_pair( const _Ty &_Key,_Tp &_Val )
	   {//return pair composed from arguments
	   return (Pair<_Ty,_Tp>( _Key,forward<_Tp>(_Val)));
	   }

template<class _Ty,class _Tp> inline Pair<_Ty,_Tp> 
   make_pair( _Ty &_Key,const _Tp &_Val )
	   {//return pair composed from arguments
	   return (Pair<_Ty,_Tp>( forward<_Ty>(_Key),_Val ));
	   }

template<class _Ty,class _Tp> inline Pair<_Ty,_Tp> 
   make_pair( const _Ty &_Key,const _Tp &_Val )
	   {//return pair composed from arguments
	   return (Pair<_Ty,_Tp>( _Key,_Val ));
	   }

template<class _Ty,class _Tp> inline void_t
   swap( Pair<_Ty,_Tp> &_Lft,Pair<_Ty,_Tp> &_Rht )
	   {//swap _Lft and _Rht pairs
	   _Lft.swap( _Rht );
	   }



_LDS_END
#pragma pack(pop)
#endif//UTILITY_H
/*
All rights reserved. Consult your license regarding permissions and restrictions.
*/