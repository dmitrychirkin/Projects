#pragma		once
#ifndef		RANDOM_H
#define		RANDOM_H

//	Use project headers
#include		"Eskdef.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
			Random generator
**************************************/
template<class _Ty = uint_t>
struct Random
	{//standard random generator [0..32767]
	_Ty 
      operator()( _Ty _Init = 0)
		   {
		   static _Ty _Rand = 253101137;
		   if (_Init)
			   {
			   _Rand = _Init;
			   }
		   return _Ty(((_Rand = _Rand*214013 + 2531011) >> 8) & 0x7fff);//double sigma
		   }
	};

template<class _Ty = iint_t>
struct Randos : public Random<_Ty>
	{//standard random generator [-16384..16383]
	_Ty 
      operator()( _Ty _Init = 0)
		   {
		   return Random<_Ty>::operator()( _Init ) - 0x3fff;
		   }
	};

template<class _Ty> inline _Ty
   random( _Ty _Init = 0 )
	   {//adapter
	   return (Random<_Ty>()( _Init ));
	   }

template<class _Ty> inline _Ty
   randos( _Ty _Init = 0 )
	   {//adapter
	   return (Randos<_Ty>()( _Init ));
	   }

template<class _Ty> inline _Ty
   mingle( _Ty _Size )
	   {//adapter
      while(--_Size) Random<>()(); return Random<>()();
	   }

template<class _Ty> inline _Ty
   urnd( _Ty _Module )
	   {//unsigned random by module
	   return (random<_Ty>()%_Module);
	   }

template<class _Ty> inline _Ty 
   srnd( _Ty _Module )
	   {//signed random by module
	   return (randos<_Ty>()%_Module);
	   }

inline byte_t 
   brnd()
	   {//random boolean
	   return (random<uint_t>() & 01);
	   }

inline byte_t 
   ornd()
	   {//random octal
	   return (random<uint_t>() & 07);
	   }

inline byte_t 
   hrnd()
	   {//random hexadecimal
	   return (random<uint_t>() & 15);
	   }

inline byte_t
   frnd()
	   {//random fetch bit
	   return (random<uint_t>() & 31);
	   }

/**************************************
			Unicum random generator
**************************************/
template<class _Ty = uint_t>
struct Unicum
	{//pseudo-random generator [0..255]
   Unicum() {}

	_Ty 
      operator()( _Ty _Idx )
		   {//unicum random value
         static const byte_t 
            Tb_Unicum[] = 
               {
                98,  6, 85,150, 36, 23,112,164,135,207,169,  5, 26, 64,165,219,
                61, 20, 68, 89,130, 63, 52,102, 24,229,132,245, 80,216,195,115,
                90,168,156,203,177,120,  2,190,188,  7,100,185,174,243,162, 10,
               237, 18,253,225,  8,208,172,244,255,126,101, 79,145,235,228,121,
               123,251, 67,250,161,  0,107, 97,241,111,181, 82,249, 33, 69, 55,
                59,153, 29,  9,213,167, 84, 93, 30, 46, 94, 75,151,114, 73,222,
               197, 96,210, 45, 16,227,248,202, 51,152,252,125, 81,206,215,186,
                39,158,178,187,131,136,  1, 49, 50, 17,141, 91, 47,129, 60, 99,
               154, 35, 86,171,105, 34, 38,200,147, 58, 77,118,173,246, 76,254,
               133,232,196,144,198,124, 53,  4,108, 74,223,234,134,230,157,139,
               189,205,199,128,176, 19,211,236,127,192,231, 70,233, 88,146, 44,
               183,201, 22, 83, 13,214,116,109,159, 32, 95,226,140,220, 57, 12,
               221, 31,209,182,143, 92,149,184,148, 62,113, 65, 37, 27,106,166,
                 3, 14,204, 72, 21, 41, 56, 66, 28,193, 40,217, 25, 54,179,117,
               238, 87,240,155,180,170,242,212,191,163, 78,218,137,194,175,110,
                43,119,224, 71,122,142, 42,160,104, 48,247,103, 15, 11,138,239 
               };
         //pseudo-random value
         return Tb_Unicum[_Idx & 255];
		   }
	};

template<class _Ty> inline _Ty
   unicum( _Ty _Idx )
	   {//adapter
	   return (Unicum<_Ty>()( _Idx ));
	   }


_ESK_END
#pragma pack(pop)
#endif//RANDOM_H

