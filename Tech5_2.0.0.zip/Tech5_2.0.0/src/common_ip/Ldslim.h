/**************************************
					LDSLIM.H
Standard limits header for the library.

        Copyright (c) 1994-2004.
        Copyright (c) 2005-2012.
**************************************/
#pragma		once
#ifndef		LDSLIM_H
#define		LDSLIM_H

//	Use project headers
#include		"Ldsdef.h"

#pragma pack(push,_LDS_PACKING)
_LDS_BEGIN
/**************************************
	Template class Numeric_limits
		with specializations
**************************************/
template<class _Ty>
class Numeric_limits
	{//numeric limits for arbitrary type _Ty
public:
	 _Ty _min() const throw()
		{//return minimum value
		return (_Ty(0));
		}

	 _Ty _max() const throw()
		{//return maximum value
		return (_Ty(0));
		}

	 _Ty epsilon() const throw()
		{//return smallest effective increment from 1.0
		return (_Ty(0));
		}

	 _Ty round_error() const throw()
		{//return largest rounding error
		return (_Ty(0));
		}
	};
 
template<class _Ty>
class Numeric_limits<const _Ty> : public Numeric_limits<_Ty>
	{//numeric limits for const types
	};

template<> 
class Numeric_limits<bool>
	{//limits for type bool
public:
	typedef bool _Ty;

	 _Ty _min() const throw()
		{//return minimum value
		return (false);
		}

	 _Ty _max() const throw()
		{//return maximum value
		return (true);
		}

	 _Ty epsilon() const throw()
		{//return smallest effective increment from 1.0
		return (0);
		}

	 _Ty round_error() const throw()
		{//return largest rounding error
		return (0);
		}
	};

template<> 
class Numeric_limits<signed char>
	{//limits for type signed char
public:
	typedef signed char _Ty;

	 _Ty _min() const throw()
		{//return minimum value
		return (-127-1);
		}

	 _Ty _max() const throw()
		{//return maximum value
		return (127);
		}

	 _Ty epsilon() const throw()
		{//return smallest effective increment from 1.0
		return (0);
		}

	 _Ty round_error() const throw()
		{//return largest rounding error
		return (0);
		}
	};

template<> 
class Numeric_limits<unsigned char>
	{//limits for type unsigned char
public:
	typedef unsigned char _Ty;

	 _Ty _min() const throw()
		{//return minimum value
		return (0);
		}

	 _Ty _max() const throw()
		{//return maximum value
		return (0xff);
		}

	 _Ty epsilon() const throw()
		{//return smallest effective increment from 1.0
		return (0);
		}

	 _Ty round_error() const throw()
		{//return largest rounding error
		return (0);
		}
	};

template<> 
class Numeric_limits<signed short>
	{//limits for type short
public:
	typedef signed short _Ty;

	 _Ty _min() const throw()
		{//return minimum value
		return (-32767-1);
		}

	 _Ty _max() const throw()
		{//return maximum value
		return (32767);
		}

	 _Ty epsilon() const throw()
		{//return smallest effective increment from 1.0
		return (0);
		}

	 _Ty round_error() const throw()
		{//return largest rounding error
		return (0);
		}
	};

template<> 
class Numeric_limits<unsigned short>
	{//limits for type unsigned short
public:
	typedef unsigned short _Ty;

	 _Ty _min() const throw()
		{//return minimum value
		return (0);
		}

	 _Ty _max() const throw()
		{//return maximum value
		return (0xffff);
		}

	 _Ty epsilon() const throw()
		{//return smallest effective increment from 1.0
		return (0);
		}

	 _Ty round_error() const throw()
		{//return largest rounding error
		return (0);
		}
	};

template<> 
class Numeric_limits<signed int>
	{//limits for type int
public:
	typedef signed int _Ty;

	 _Ty _min() const throw()
		{//return minimum value
		return (-2147483647-1);
		}

	 _Ty _max() const throw()
		{//return maximum value
		return (2147483647);
		}

	 _Ty epsilon() const throw()
		{//return smallest effective increment from 1.0
		return (0);
		}

	 _Ty round_error() const throw()
		{//return largest rounding error
		return (0);
		}
	};

template<> 
class Numeric_limits<unsigned int>
	{//limits for type unsigned int
public:
	typedef unsigned int _Ty;

	 _Ty _min() const throw()
		{//return minimum value
		return (0);
		}

	 _Ty _max() const throw()
		{//return maximum value
		return (0xffffffff);
		}

	 _Ty epsilon() const throw()
		{//return smallest effective increment from 1.0
		return (0);
		}

	 _Ty round_error() const throw()
		{//return largest rounding error
		return (0);
		}
	};

template<> 
class Numeric_limits<signed long>
	{//limits for type long
public:
	typedef signed long _Ty;

	 _Ty _min() const throw()
		{//return minimum value
		return (-2147483647L-1);
		}

	 _Ty _max() const throw()
		{//return maximum value
		return (2147483647L);
		}

	 _Ty epsilon() const throw()
		{//return smallest effective increment from 1.0
		return (0);
		}

	 _Ty round_error() const throw()
		{//return largest rounding error
		return (0);
		}
	};

template<> 
class Numeric_limits<unsigned long>
	{//limits for type unsigned long
public:
	typedef unsigned long _Ty;

	 _Ty _min() const throw()
		{//return minimum value
		return (0UL);
		}

	 _Ty _max() const throw()
		{//return maximum value
		return (0xffffffffUL);
		}

	 _Ty epsilon() const throw()
		{//return smallest effective increment from 1.0
		return (0);
		}

	 _Ty round_error() const throw()
		{//return largest rounding error
		return (0);
		}
	};

template<> 
class Numeric_limits<signed long long>
	{//limits for type long
public:
	typedef signed long long _Ty;

	 _Ty _min() const throw()
		{//return minimum value
		return (-9223372036854775807 - 1);
		}

	 _Ty _max() const throw()
		{//return maximum value
		return (9223372036854775807);
		}

	 _Ty epsilon() const throw()
		{//return smallest effective increment from 1.0
		return (0);
		}

	 _Ty round_error() const throw()
		{//return largest rounding error
		return (0);
		}
	};

template<> 
class Numeric_limits<unsigned long long>
	{//limits for type long
public:
	typedef unsigned long long _Ty;

	 _Ty _min() const throw()
		{//return minimum value
		return (0);
		}

	 _Ty _max() const throw()
		{//return maximum value
		return (0xffffffffffffffff);
		}

	 _Ty epsilon() const throw()
		{//return smallest effective increment from 1.0
		return (0);
		}

	 _Ty round_error() const throw()
		{//return largest rounding error
		return (0);
		}
	};

template<> 
class Numeric_limits<float>
	{//limits for type float
public:
	typedef float _Ty;

	 _Ty _min() const throw()
		{//return minimum value
		return (1.175494351e-38F);
		}

	 _Ty _max() const throw()
		{//return maximum value
		return (3.402823466e+38F);
		}

	 _Ty epsilon() const throw()
		{//return smallest effective increment from 1.0
		return (1.192092896e-07F);
		}

	 _Ty round_error() const throw()
		{//return largest rounding error
		return (0.5);
		}
	};

template<> 
class Numeric_limits<double>
	{//limits for type double
public:
	typedef double _Ty;

	 _Ty _min() const throw()
		{//return minimum value
		return (2.2250738585072014e-308);
		}

	 _Ty _max() const throw()
		{//return maximum value
		return (1.7976931348623158e+308);
		}

	 _Ty epsilon() const throw()
		{//return smallest effective increment from 1.0
		return (2.2204460492503131e-016);
		}

	 _Ty round_error() const throw()
		{//return largest rounding error
		return (0.5);
		}
	};

template<> 
class Numeric_limits<long double>
	{//limits for type long double
public:
	typedef long double _Ty;

	 _Ty _min() const throw()
		{//return minimum value
		return (2.2250738585072014e-308);
		}

	 _Ty _max() const throw()
		{//return maximum value
		return (1.7976931348623158e+308);
		}

	 _Ty epsilon() const throw()
		{//return smallest effective increment from 1.0
		return (2.2204460492503131e-016);
		}

	 _Ty round_error() const throw()
		{//return largest rounding error
		return (0.5);
		}
	};

_LDS_END
#pragma pack(pop)
#endif//LDSLIM_H
