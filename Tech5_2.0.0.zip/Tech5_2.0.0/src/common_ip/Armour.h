#pragma		once
#ifndef		ARMOUR_H
#define		ARMOUR_H

//	Use project headers
#include		"Crypto.h"
#include		"Trigon.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
			Interface with OS
**************************************/
#if _ESK_GUARD == 1
class	Iosstd
	{//shell for file system
public:
    Iosstd();
	~Iosstd();

	bool_t   fopen (  const  char   *_Name,
                     const  char   *_Mode );     //open my file
	bool_t   fwrite(  /* */  void_p  _From,
                            size_t  _Size,
                            size_t  _Coin );     //write data
	bool_t   fread (  /* */  void_p  _Dest,
                            size_t  _Size,
                            size_t  _Coin );     //read data
   bool_t   fseek (  /* */  uint_t  _Move );     //moves the file pointer
	void_t   fclose();                            //close my file

public:
   void_p   //file pointer
      File;

	};//Iosstd

class	Intrin
	{//shell for intrinsic functions
public:
#if defined (linux)
   typedef  uint_t   info_t;
#else
   typedef  iint_t   info_t;
#endif

   quad_t   timeid();                            //read time value
   void_t   cpu_id(  /* */  info_t *_Info,
                            iint_t  _Call );     //read CPU code

	};//Intrin
#endif

/**************************************
         Simple protectors
**************************************/
#if _ESK_GUARD == 1
inline quad_t
   hacker( uint_t _Pop )
	   {//stop hacker, return zero if OK
      uint_t 
         _Jmp = 1,
         _Flg = 2;

isa:  switch((++_Jmp) & 31)
         {
         case 13: goto isd;
         default: goto isa;
         }
isb:  switch((++_Jmp) & 31)
         {
         case 17: goto ise;
         default: goto isb;
         }
isc:  switch((++_Jmp) & 31)
         {
         case 19: goto out;
         default: goto isc;
         }
isd:  switch((++_Jmp) & 31)
         {
         case 23: goto isb;
         default: goto isd;
         }
ise:  switch((++_Jmp) & 31)
         {
         case 29: goto isc;
         default: goto ise;
         }
out:
         _Flg = popcnt( _Jmp ) < _Pop;
      if(_Flg)
         goto isa;

      //norma equal to zero
      return _Flg;
	   }

inline quad_t 
   differ( quad_t _Lgu,quad_t _Rgu )
		{//test genuine keys, return zero if _Lgu ==  ~_Rgu
      quad_t 
         _Tmp = ~_Rgu; return (2*(_Lgu & _Rgu)) - (_Lgu ^ _Tmp) + (_Lgu + _Rgu + 1);
		}

//-------------------------------------
// CPU & Time implementation
//-------------------------------------
class CpuTic : public Intrin
	{//generate CPU code
public:
   CpuTic()
      {//default constructor
      Cpuv = hacker(6) - ~cpuvid() - 1;
      Time = hacker(5) - ~timeid() - 1;
      }

	inline uint_t 
      randtm( uint_t _Pop )
		   {//get random time
         return (timeid() & 7) + _Pop;
		   }

private:
	inline quad_t 
      cpuvid()
		   {//read CPU parameter, exclude platform's bits
         info_t _Info[4] = {0,0,0,0};
         quad_t _Cpuv(7);

         cpu_id(_Info,0 );                         cpumix( _Info,_Cpuv );
         cpu_id(_Info,1 ); _Info[1] &= 0x00ffffff; cpumix( _Info,_Cpuv );
         cpu_id(_Info,2 );                         cpumix( _Info,_Cpuv );

         //genuine key
         return _Cpuv;
         }

   inline void_t 
      cpumix( const info_t *_Info,quad_t &_Cpuv ) const
         {
         _Cpuv ^= ((quad_t)_Info[0] + 1) *
                  ((quad_t)_Info[1] + 3) *
                  ((quad_t)_Info[2] + 5) * 
                  ((quad_t)_Info[3] + 7);
         }

public:
   quad_t   //CPU, time
      Cpuv,
      Time;

   };//CpuTic

//-------------------------------------
// Sentry implementation
//-------------------------------------
class	Sentry : public CpuTic,public Iosstd
	{//singleton sentry
   Sentry()
		{//private constructor
      hacker( randtm(11)); reread();
		};

public:
   static Sentry& instance()
      {//entry
      static Sentry 
         ThisSentry; hacker(5); return ThisSentry;
      }

private:
   inline void_t
      reread()
         {//read licence or ask about it
         quad_t
            _Temp[] = {0,1,2,3,
                       4,5,6,7,
                       8,9,0,1,
                       2,3,4,5,
                       6,7,8,9}, _Cpuv = Cpuv,
                                 _Test = Time;
         char
            _File[] = "LocusGuard_000000000.txt";  iint_t k = finame( _File,_Cpuv );
         Crypto 
            _Ocry( O_CRYPTO_KEY),
            _Ccry( C_CRYPTO_KEY);

         for(iint_t i = 0; i < 20; i++)
            {//shuffle up open keys
            ++_Test; _Ocry.encryp( &_Temp[i],&_Test,8 );
            }

         if (fopen( _File,"rb"  ))
            {//read close keys
            for(iint_t i = 0; i < 20; i++)
               {//read codes
               if (!fread(&_Temp[i],1,8 )) break;
               }
            for(iint_t i = 0; i < 20; i++)
               {//decript with close key
               _Ccry.decryp( &_Temp[i],&_Temp[i],8 );
               }
            Cpuv = ~_Temp[0]; fclose(); return;
            }

         //rename file
         _File[k+1] = 'c';
         _File[k+2] = 'p';
         _File[k+3] = 'u';

         //save secret data
         _Temp[0] = _Cpuv;

         if (fopen( _File,"wb"  ))
            {//write open keys
            for(iint_t i = 0; i < 20; i++)
               {//encript with open key
               _Ocry.encryp( &_Temp[i],&_Temp[i],8 );
               }
            for(iint_t i = 0; i < 20; i++)
               {//write codes
               if(!fwrite(&_Temp[i],1,8 )) break;
               }
            //accidental means
            Cpuv = _Temp[0]; fclose(); return;
            }
         }

   inline iint_t
      finame( char *_Src,quad_t _Cpu )
         {//add suffix to file name
         uint_t i = 0,
                k = 1;

         //start position
         for( ;_Src[i] != '_'; i++);

         for( ; k < 10; k++)
            {//set signature
            _Src[i+k] = '0' + _Cpu % 10; _Cpu /= 10;
            }
         return (i+k);
         }

   };//Sentry
#endif

#if _ESK_GUARD == 1
//-------------------------------------
// Library interface
//-------------------------------------
inline quad_t 
   invalid_key()
	   {//return non zero if key or session time invalid
      Sentry &
         _Sen = Sentry::instance();
      CpuTic 
         _Now;

      //test permission
      return (_Now.Time < _ESK_TM)*differ( _Now.Cpuv,_Sen.Cpuv )+ 
                                   differ( _Now.Cpuv,_Sen.Cpuv )*(_Now.Time > (_ESK_TM  + 89*24*3600));
	   }

#else //simple stubs

inline quad_t 
   invalid_key()
	   {//CPU key is OK
      return 0;
	   }

#endif

_ESK_END
#pragma pack(pop)
#endif//ARMOUR_H
