﻿#pragma     once
#ifndef		TRIGON_H
#define		TRIGON_H

//	System library header
#include		<math.h>

//	Use project headers
#include		"Assert.h"
#include		"Except.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
      Standard mathimatic utility
**************************************/
inline iint_t
   sqri( guar_t _Lft ) _NOTHROW
      {//api root
      return iint_t(::sqrt( double(_Lft)) + 0.5);
      }

inline iint_t
   sqrm( guar_t _Lft ) _NOTHROW
      {//api truncated root
      return iint_t(::sqrt( double(_Lft)));
      }

/**************************************
        Get amount of 1-bits
**************************************/
inline uint_t
   popcnt( uint_t _Val ) _NOTHROW
      {//get amount of 1-bits in a 32-word
      _Val =  _Val - ((_Val >> 1) & 0x55555555);
      _Val =         ((_Val >> 2) & 0x33333333) + (0x33333333 & _Val);
      //quick result
      return((_Val +  (_Val >> 4))& 0x0f0f0f0f) *  0x01010101 >>  24;
      }

inline uint_t 
   popcnt( quad_t _Val ) _NOTHROW
      {//get amount of 1-bits in a 64-word
      _Val =  _Val - ((_Val >> 1) & 0x5555555555555555UL);
      _Val =         ((_Val >> 2) & 0x3333333333333333UL) + (0x3333333333333333UL & _Val);
      //quick result
      return((_Val +  (_Val >> 4))& 0x0f0f0f0f0f0f0f0fUL) *  0x0101010101010101UL >>  56;
      }

/**************************************
			Pow functors
**************************************/
const
struct _LNX_PACKING Struct_Leul
	{//Leonhard Euler part <for thousand>
   Struct_Leul()
      {//default constructor
      }

	template<class _Ty> byte_t inline
      operator[]( const _Ty &_Lft ) const _NOTHROW
		   {//main call
		   AFFIRM( _Lft >= 0x00);
         AFFIRM( _Lft <= 0xff);

         if (_Lft <= 0xff)
			   return kernal( _Lft );
         else
            return kernal( 0xff );
		   }

private:
	template<class _Ty> byte_t inline
      kernal( const _Ty &_Lft ) const _NOTHROW
		   {//tabulate value	
         static const byte_t 
            TbLeul[] =
			      {//up to 255
                 0,  1,  2,  3,  3,  4,  5,  5,  6,  7,  7,  8,  8,  9, 10, 10,
                11, 11, 12, 12, 13, 14, 14, 15, 15, 16, 16, 17, 17, 18, 18, 19,
                19, 20, 20, 21, 21, 22, 22, 23, 23, 24, 24, 25, 25, 26, 26, 27,
                27, 28, 28, 29, 29, 30, 30, 31, 31, 32, 32, 33, 33, 34, 34, 35,
                35, 36, 36, 37, 37, 37, 38, 38, 39, 39, 40, 40, 41, 41, 42, 42,
                42, 43, 43, 44, 44, 45, 45, 46, 46, 47, 47, 47, 48, 48, 49, 49,
                50, 50, 51, 51, 51, 52, 52, 53, 53, 54, 54, 54, 55, 55, 56, 56,
                57, 57, 58, 58, 58, 59, 59, 60, 60, 61, 61, 61, 62, 62, 63, 63,
                64, 64, 64, 65, 65, 66, 66, 66, 67, 67, 68, 68, 69, 69, 69, 70,
                70, 71, 71, 72, 72, 72, 73, 73, 74, 74, 74, 75, 75, 76, 76, 76,
                77, 77, 78, 78, 79, 79, 79, 80, 80, 81, 81, 81, 82, 82, 83, 83,
                83, 84, 84, 85, 85, 85, 86, 86, 87, 87, 87, 88, 88, 89, 89, 89,
                90, 90, 91, 91, 91, 92, 92, 93, 93, 93, 94, 94, 95, 95, 95, 96,
                96, 97, 97, 97, 98, 98, 99, 99, 99,100,100,101,101,101,102,102,
               103,103,103,104,104,104,105,105,106,106,106,107,107,108,108,108,
               109,109,110,110,110,111,111,111,112,112,113,113,113,114,114,115,
               };
         return TbLeul[_Lft];
         }
   } Leul;

/**************************************
     Periodic trigonometry functors
**************************************/
template<class _Fn>
struct _LNX_PACKING Trigon
	{//approximation for trigonomety
   typedef iint_t trig_t;

   Trigon()
      {//default
      }

   explicit Trigon( trig_t _Val ) : Value(_Val)
      {//assign
      }

   trig_t
      operator()() const _NOTHROW
		   {//trigonometric functor
		   return Value;
		   }

   template<class _Ty> trig_t
      operator[]( const _Ty &_Lft ) const _NOTHROW
		   {//subscript
		   return _Fn()[ _Lft ];
		   }

   template<class _Ty> const Trigon<_Fn> &
      operator()( const _Ty &_Lft ) _NOTHROW
		   {//basic functor
		   Value = _Fn()[ _Lft ];
		   return (*this);
		   }

   template<class _Ty,class _Tp> const	Trigon<_Fn> &
      operator()( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
		   {//restricted functor
		   AFFIRM(_Rht > 0);

		   if (_Lft >= 0)
			   {//positive value
			   if (_Rht > _Lft)
				   Value = _Fn()[ 64*_Lft/_Rht ];
			   else
				   Value = _Fn()[ 64 ];
			   }
		   else
			   {//negative value
			   if (_Rht > -_Lft)
				   Value = _Fn()[ 64*_Lft/_Rht ];
			   else
				   Value = _Fn()[192 ];
			   }
		   return (*this);
		   }

	uint_t 
      size() const _NOTHROW
		   {//length of sequence
		   return 0x0100; 
		   }

	trig_t 
      max() const _NOTHROW
		   {//maximum value
		   return 0x1000; 
		   }

private:
   trig_t //the value
      Value;

	};//Trigon

template<class _Fn,class _Ty> inline _Ty
   operator>>( const Trigon<_Fn> &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//shift right
      return _Lft() >> _Rht;
	   }

template<class _Fn,class _Ty> inline _Ty
   operator*( const Trigon<_Fn> &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//test int div
      AFFIRM( _Rht < +524287);
      AFFIRM( _Rht > -524287);
      //multiply
      iint_t _Tmp = _Rht*_Lft(); return _Ty(_Tmp/0x1000);
	   }

template<class _Fn,class _Ty> inline _Ty
   operator*( const _Ty &_Lft,const Trigon<_Fn> &_Rht ) _NOTHROW
	   {//inverse multiply
	   return operator*( _Rht,_Lft );
	   }

template<class _Fn,class _Ty> inline _Ty&
   operator*=( _Ty &_Lft,const Trigon<_Fn> &_Rht ) _NOTHROW
	   {//multiplication assignment
	   return (_Lft = operator*( _Rht,_Lft ));
	   }

template<class _Fn,class _Ty> inline _Ty
   operator/( const Trigon<_Fn> &_Lft,const _Ty &_Rht )
	   {//multiply
      return _Rht*_Lft.max()/_Lft();
	   }

template<class _Fn,class _Ty> inline _Ty
   operator/( const _Ty &_Lft,const Trigon<_Fn> &_Rht )
	   {//inverse multiply
	   return operator/( _Rht,_Lft );
	   }

template<class _Ty> inline _Ty 
   pihalf( const _Ty &_Lft,const _Ty &_Rht )
	   {//scaled right angle
	   return (64*_Lft/_Rht);
	   }

//-------------------------------------
//	List of periodic functors
//-------------------------------------
struct _LNX_PACKING My_Cod
	{//functor - third root cosine
   My_Cod()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {//table is optimized	
		   static const shrt_t 
            Tb_Cod[] =
			      {
                4096, 4096, 4094, 4092, 4089, 4086, 4081, 4076, 4070, 4063, 4055, 4046, 4036, 4026, 4015, 4002,
                3989, 3975, 3960, 3945, 3928, 3910, 3892, 3872, 3852, 3830, 3807, 3784, 3759, 3733, 3706, 3678,
                3649, 3619, 3587, 3554, 3519, 3484, 3446, 3408, 3367, 3325, 3281, 3236, 3188, 3138, 3086, 3031,
                2974, 2914, 2850, 2783, 2712, 2637, 2556, 2469, 2376, 2273, 2160, 2034, 1889, 1716, 1500, 1190,
                   0,-1190,-1500,-1716,-1889,-2034,-2160,-2273,-2376,-2469,-2556,-2637,-2712,-2783,-2850,-2914,
               -2974,-3031,-3086,-3138,-3188,-3236,-3281,-3325,-3367,-3408,-3446,-3484,-3519,-3554,-3587,-3619,
               -3649,-3678,-3706,-3733,-3759,-3784,-3807,-3830,-3852,-3872,-3892,-3910,-3928,-3945,-3960,-3975,
               -3989,-4002,-4015,-4026,-4036,-4046,-4055,-4063,-4070,-4076,-4081,-4086,-4089,-4092,-4094,-4096,
               -4096,-4096,-4094,-4092,-4089,-4086,-4081,-4076,-4070,-4063,-4055,-4046,-4036,-4026,-4015,-4002,
               -3989,-3975,-3960,-3945,-3928,-3910,-3892,-3872,-3852,-3830,-3807,-3784,-3759,-3733,-3706,-3678,
               -3649,-3619,-3587,-3554,-3519,-3484,-3446,-3408,-3367,-3325,-3281,-3236,-3188,-3138,-3086,-3031,
               -2974,-2914,-2850,-2783,-2712,-2637,-2556,-2469,-2376,-2273,-2160,-2034,-1889,-1716,-1500,-1190,
                   0, 1190, 1500, 1716, 1889, 2034, 2160, 2273, 2376, 2469, 2556, 2637, 2712, 2783, 2850, 2914,
                2974, 3031, 3086, 3138, 3188, 3236, 3281, 3325, 3367, 3408, 3446, 3484, 3519, 3554, 3587, 3619,
                3649, 3678, 3706, 3733, 3759, 3784, 3807, 3830, 3852, 3872, 3892, 3910, 3928, 3945, 3960, 3975,
                3989, 4002, 4015, 4026, 4036, 4046, 4055, 4063, 4070, 4076, 4081, 4086, 4089, 4092, 4094, 4096,
			      };
         return Tb_Cod[_Lft & 255];
		   }
	};//My_Cod

struct _LNX_PACKING My_Sid
	{//functor - third root sine
   My_Sid()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {	
		   return My_Cod()[ _Lft - 64 ];
		   }
	};//My_Sid

struct _LNX_PACKING My_Cor
	{//functor - root cosine
   My_Cor()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {//table is optimized	
		   static const shrt_t 
            Tb_Cor[] =
			      {
                4096, 4095, 4094, 4090, 4086, 4081, 4074, 4066, 4056, 4046, 4034, 4021, 4007, 3991, 3974, 3956,
                3937, 3916, 3894, 3871, 3847, 3821, 3793, 3765, 3735, 3704, 3671, 3637, 3601, 3564, 3526, 3486,
                3444, 3401, 3357, 3310, 3262, 3213, 3161, 3108, 3053, 2996, 2937, 2876, 2812, 2746, 2678, 2607,
                2534, 2457, 2377, 2294, 2207, 2115, 2019, 1917, 1809, 1694, 1569, 1433, 1282, 1111,  907,  642,
                   0, -642, -907,-1111,-1282,-1433,-1569,-1694,-1809,-1917,-2019,-2115,-2207,-2294,-2377,-2457,
               -2534,-2607,-2678,-2746,-2812,-2876,-2937,-2996,-3053,-3108,-3161,-3213,-3262,-3310,-3357,-3401,
               -3444,-3486,-3526,-3564,-3601,-3637,-3671,-3704,-3735,-3765,-3793,-3821,-3847,-3871,-3894,-3916,
               -3937,-3956,-3974,-3991,-4007,-4021,-4034,-4046,-4056,-4066,-4074,-4081,-4086,-4090,-4094,-4095,
               -4096,-4095,-4094,-4090,-4086,-4081,-4074,-4066,-4056,-4046,-4034,-4021,-4007,-3991,-3974,-3956,
               -3937,-3916,-3894,-3871,-3847,-3821,-3793,-3765,-3735,-3704,-3671,-3637,-3601,-3564,-3526,-3486,
               -3444,-3401,-3357,-3310,-3262,-3213,-3161,-3108,-3053,-2996,-2937,-2876,-2812,-2746,-2678,-2607,
               -2534,-2457,-2377,-2294,-2207,-2115,-2019,-1917,-1809,-1694,-1569,-1433,-1282,-1111, -907, -642,
                   0,  642,  907, 1111, 1282, 1433, 1569, 1694, 1809, 1917, 2019, 2115, 2207, 2294, 2377, 2457,
                2534, 2607, 2678, 2746, 2812, 2876, 2937, 2996, 3053, 3108, 3161, 3213, 3262, 3310, 3357, 3401,
                3444, 3486, 3526, 3564, 3601, 3637, 3671, 3704, 3735, 3765, 3793, 3821, 3847, 3871, 3894, 3916,
                3937, 3956, 3974, 3991, 4007, 4021, 4034, 4046, 4056, 4066, 4074, 4081, 4086, 4090, 4094, 4095,
			      };
         return Tb_Cor[_Lft & 255];
		   }
	};//My_Cor

struct _LNX_PACKING My_Sir
	{//functor - root sine
   My_Sir()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {	
		   return My_Cor()[ _Lft - 64 ];
		   }
	};//My_Sir

struct _LNX_PACKING My_Cos
	{//functor - cosine
   My_Cos()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {//table is optimized	
		   static const shrt_t 
            Tb_Cos[] =
			      {
                4096, 4095, 4091, 4085, 4076, 4065, 4052, 4036, 4017, 3996, 3973, 3948, 3920, 3889, 3857, 3822,
                3784, 3745, 3703, 3659, 3612, 3564, 3513, 3461, 3406, 3349, 3290, 3229, 3166, 3102, 3035, 2967,
                2896, 2824, 2751, 2675, 2598, 2520, 2440, 2359, 2276, 2191, 2106, 2019, 1931, 1842, 1751, 1660,
                1567, 1474, 1380, 1285, 1189, 1092,  995,  897,  799,  700,  601,  501,  401,  301,  201,  101,
                   0, -101, -201, -301, -401, -501, -601, -700, -799, -897, -995,-1092,-1189,-1285,-1380,-1474,
               -1567,-1660,-1751,-1842,-1931,-2019,-2106,-2191,-2276,-2359,-2440,-2520,-2598,-2675,-2751,-2824,
               -2896,-2967,-3035,-3102,-3166,-3229,-3290,-3349,-3406,-3461,-3513,-3564,-3612,-3659,-3703,-3745,
               -3784,-3822,-3857,-3889,-3920,-3948,-3973,-3996,-4017,-4036,-4052,-4065,-4076,-4085,-4091,-4095,
               -4096,-4095,-4091,-4085,-4076,-4065,-4052,-4036,-4017,-3996,-3973,-3948,-3920,-3889,-3857,-3822,
               -3784,-3745,-3703,-3659,-3612,-3564,-3513,-3461,-3406,-3349,-3290,-3229,-3166,-3102,-3035,-2967,
               -2896,-2824,-2751,-2675,-2598,-2520,-2440,-2359,-2276,-2191,-2106,-2019,-1931,-1842,-1751,-1660,
               -1567,-1474,-1380,-1285,-1189,-1092, -995, -897, -799, -700, -601, -501, -401, -301, -201, -101,
                   0,  101,  201,  301,  401,  501,  601,  700,  799,  897,  995, 1092, 1189, 1285, 1380, 1474,
                1567, 1660, 1751, 1842, 1931, 2019, 2106, 2191, 2276, 2359, 2440, 2520, 2598, 2675, 2751, 2824,
                2896, 2967, 3035, 3102, 3166, 3229, 3290, 3349, 3406, 3461, 3513, 3564, 3612, 3659, 3703, 3745,
                3784, 3822, 3857, 3889, 3920, 3948, 3973, 3996, 4017, 4036, 4052, 4065, 4076, 4085, 4091, 4095,
			      };
         return Tb_Cos[_Lft & 255];
		   }
	};//My_Cos

struct _LNX_PACKING My_Sin
	{//functor - sine
   My_Sin()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {	
		   return My_Cos()[ _Lft - 64 ];
		   }
	};//My_Sin

struct _LNX_PACKING My_Cog
	{//functor - cosine^2
   My_Cog()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {//table is optimized	
		   static const shrt_t 
            Tb_Cog[] =
			      {
                4096, 4094, 4086, 4074, 4057, 4035, 4008, 3976, 3940, 3899, 3854, 3805, 3751, 3693, 3631, 3565,
                3496, 3423, 3347, 3268, 3186, 3101, 3013, 2924, 2832, 2738, 2643, 2546, 2448, 2349, 2249, 2148,
                2048, 1948, 1847, 1747, 1648, 1550, 1453, 1358, 1264, 1172, 1083,  995,  910,  828,  749,  673,
                 600,  531,  465,  403,  345,  291,  242,  197,  156,  120,   88,   61,   39,   22,   10,    2,
                   0,   -2,  -10,  -22,  -39,  -61,  -88, -120, -156, -197, -242, -291, -345, -403, -465, -531,
                -600, -673, -749, -828, -910, -995,-1083,-1172,-1264,-1358,-1453,-1550,-1648,-1747,-1847,-1948,
               -2048,-2148,-2249,-2349,-2448,-2546,-2643,-2738,-2832,-2924,-3013,-3101,-3186,-3268,-3347,-3423,
               -3496,-3565,-3631,-3693,-3751,-3805,-3854,-3899,-3940,-3976,-4008,-4035,-4057,-4074,-4086,-4094,
               -4096,-4094,-4086,-4074,-4057,-4035,-4008,-3976,-3940,-3899,-3854,-3805,-3751,-3693,-3631,-3565,
               -3496,-3423,-3347,-3268,-3186,-3101,-3013,-2924,-2832,-2738,-2643,-2546,-2448,-2349,-2249,-2148,
               -2048,-1948,-1847,-1747,-1648,-1550,-1453,-1358,-1264,-1172,-1083, -995, -910, -828, -749, -673,
                -600, -531, -465, -403, -345, -291, -242, -197, -156, -120,  -88,  -61,  -39,  -22,  -10,   -2,
                   0,    2,   10,   22,   39,   61,   88,  120,  156,  197,  242,  291,  345,  403,  465,  531,
                 600,  673,  749,  828,  910,  995, 1083, 1172, 1264, 1358, 1453, 1550, 1648, 1747, 1847, 1948,
                2048, 2148, 2249, 2349, 2448, 2546, 2643, 2738, 2832, 2924, 3013, 3101, 3186, 3268, 3347, 3423,
                3496, 3565, 3631, 3693, 3751, 3805, 3854, 3899, 3940, 3976, 4008, 4035, 4057, 4074, 4086, 4094,
			      };
         return Tb_Cog[_Lft & 255];
		   }
	};//My_Cog

struct _LNX_PACKING My_Sig
	{//functor - sine^2
   My_Sig()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {	
		   return My_Cog()[ _Lft - 64 ];
		   }
	};//My_Sig

struct _LNX_PACKING My_Cot
	{//functor - cosine^3
   My_Cot()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {//table is optimized	
		   static const shrt_t 
            Tb_Cot[] =
			      {
                4096, 4092, 4081, 4063, 4037, 4004, 3964, 3918, 3864, 3805, 3739, 3667, 3589, 3507, 3419, 3327,
                3230, 3130, 3026, 2919, 2810, 2698, 2585, 2470, 2355, 2239, 2122, 2007, 1892, 1778, 1666, 1556,
                1448, 1343, 1241, 1141, 1046,  954,  866,  782,  702,  627,  557,  490,  429,  372,  320,  273,
                 230,  191,  157,  126,  100,   78,   59,   43,   30,   20,   13,    8,    4,    2,    0,    0,
                   0,    0,    0,   -2,   -4,   -8,  -13,  -20,  -30,  -43,  -59,  -78, -100, -126, -157, -191,
                -230, -273, -320, -372, -429, -490, -557, -627, -702, -782, -866, -954,-1046,-1141,-1241,-1343,
               -1448,-1556,-1666,-1778,-1892,-2007,-2122,-2239,-2355,-2470,-2585,-2698,-2810,-2919,-3026,-3130,
               -3230,-3327,-3419,-3507,-3589,-3667,-3739,-3805,-3864,-3918,-3964,-4004,-4037,-4063,-4081,-4092,
               -4096,-4092,-4081,-4063,-4037,-4004,-3964,-3918,-3864,-3805,-3739,-3667,-3589,-3507,-3419,-3327,
               -3230,-3130,-3026,-2919,-2810,-2698,-2585,-2470,-2355,-2239,-2122,-2007,-1892,-1778,-1666,-1556,
               -1448,-1343,-1241,-1141,-1046, -954, -866, -782, -702, -627, -557, -490, -429, -372, -320, -273,
                -230, -191, -157, -126, -100,  -78,  -59,  -43,  -30,  -20,  -13,   -8,   -4,   -2,    0,    0,
                   0,    0,    0,    2,    4,    8,   13,   20,   30,   43,   59,   78,  100,  126,  157,  191,
                 230,  273,  320,  372,  429,  490,  557,  627,  702,  782,  866,  954, 1046, 1141, 1241, 1343,
                1448, 1556, 1666, 1778, 1892, 2007, 2122, 2239, 2355, 2470, 2585, 2698, 2810, 2919, 3026, 3130,
                3230, 3327, 3419, 3507, 3589, 3667, 3739, 3805, 3864, 3918, 3964, 4004, 4037, 4063, 4081, 4092,
			      };
         return Tb_Cot[_Lft & 255];
		   }
	};//My_Cot

struct _LNX_PACKING My_Sit
	{//functor - sine^3
   My_Sit()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {	
		   return My_Cot()[ _Lft - 64 ];
		   }
	};//My_Sit

struct _LNX_PACKING My_Coq
	{//functor - cosine^4
   My_Coq()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {//table is optimized	
		   static const shrt_t 
            Tb_Coq[] =
			      {
                4096, 4091, 4076, 4052, 4018, 3974, 3922, 3860, 3790, 3712, 3627, 3534, 3435, 3330, 3219, 3104,
                2984, 2861, 2735, 2607, 2478, 2348, 2217, 2087, 1958, 1830, 1705, 1582, 1463, 1347, 1235, 1127,
                1024,  926,  833,  746,  663,  587,  516,  450,  390,  336,  286,  242,  202,  167,  137,  110,
                  88,   69,   53,   40,   29,   21,   14,    9,    6,    3,    2,    1,    0,    0,    0,    0,
                   0,    0,    0,    0,    0,   -1,   -2,   -3,   -6,   -9,  -14,  -21,  -29,  -40,  -53,  -69,
                 -88, -110, -137, -167, -202, -242, -286, -336, -390, -450, -516, -587, -663, -746, -833, -926,
               -1024,-1127,-1235,-1347,-1463,-1582,-1705,-1830,-1958,-2087,-2217,-2348,-2478,-2607,-2735,-2861,
               -2984,-3104,-3219,-3330,-3435,-3534,-3627,-3712,-3790,-3860,-3922,-3974,-4018,-4052,-4076,-4091,
               -4096,-4091,-4076,-4052,-4018,-3974,-3922,-3860,-3790,-3712,-3627,-3534,-3435,-3330,-3219,-3104,
               -2984,-2861,-2735,-2607,-2478,-2348,-2217,-2087,-1958,-1830,-1705,-1582,-1463,-1347,-1235,-1127,
               -1024, -926, -833, -746, -663, -587, -516, -450, -390, -336, -286, -242, -202, -167, -137, -110,
                 -88,  -69,  -53,  -40,  -29,  -21,  -14,   -9,   -6,   -3,   -2,   -1,    0,    0,    0,    0,
                   0,    0,    0,    0,    0,    1,    2,    3,    6,    9,   14,   21,   29,   40,   53,   69,
                  88,  110,  137,  167,  202,  242,  286,  336,  390,  450,  516,  587,  663,  746,  833,  926,
                1024, 1127, 1235, 1347, 1463, 1582, 1705, 1830, 1958, 2087, 2217, 2348, 2478, 2607, 2735, 2861,
                2984, 3104, 3219, 3330, 3435, 3534, 3627, 3712, 3790, 3860, 3922, 3974, 4018, 4052, 4076, 4091,
			      };
         return Tb_Coq[_Lft & 255];
		   }
	};//My_Coq

struct _LNX_PACKING My_Siq
	{//functor - sine^4
   My_Siq()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {	
		   return My_Coq()[ _Lft - 64 ];
		   }
	};//My_Siq

struct _LNX_PACKING My_Cof
	{//functor - cosine^5
   My_Cof()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {//table is optimized	
		   static const shrt_t 
            Tb_Cof[] =
			      {
                4096, 4090, 4071, 4041, 3998, 3944, 3879, 3803, 3717, 3622, 3518, 3406, 3287, 3162, 3031, 2896,
                2757, 2616, 2473, 2329, 2185, 2043, 1902, 1763, 1628, 1496, 1369, 1247, 1131, 1020,  915,  816,
                 724,  638,  559,  487,  421,  361,  307,  259,  217,  180,  147,  119,   95,   75,   59,   45,
                  34,   25,   18,   12,    8,    6,    3,    2,    1,    1,    0,    0,    0,    0,    0,    0,
                   0,    0,    0,    0,    0,    0,    0,   -1,   -1,   -2,   -3,   -6,   -8,  -12,  -18,  -25,
                 -34,  -45,  -59,  -75,  -95, -119, -147, -180, -217, -259, -307, -361, -421, -487, -559, -638,
                -724, -816, -915,-1020,-1131,-1247,-1369,-1496,-1628,-1763,-1902,-2043,-2185,-2329,-2473,-2616,
               -2757,-2896,-3031,-3162,-3287,-3406,-3518,-3622,-3717,-3803,-3879,-3944,-3998,-4041,-4071,-4090,
               -4096,-4090,-4071,-4041,-3998,-3944,-3879,-3803,-3717,-3622,-3518,-3406,-3287,-3162,-3031,-2896,
               -2757,-2616,-2473,-2329,-2185,-2043,-1902,-1763,-1628,-1496,-1369,-1247,-1131,-1020, -915, -816,
                -724, -638, -559, -487, -421, -361, -307, -259, -217, -180, -147, -119,  -95,  -75,  -59,  -45,
                 -34,  -25,  -18,  -12,   -8,   -6,   -3,   -2,   -1,   -1,    0,    0,    0,    0,    0,    0,
                   0,    0,    0,    0,    0,    0,    0,    1,    1,    2,    3,    6,    8,   12,   18,   25,
                  34,   45,   59,   75,   95,  119,  147,  180,  217,  259,  307,  361,  421,  487,  559,  638,
                 724,  816,  915, 1020, 1131, 1247, 1369, 1496, 1628, 1763, 1902, 2043, 2185, 2329, 2473, 2616,
                2757, 2896, 3031, 3162, 3287, 3406, 3518, 3622, 3717, 3803, 3879, 3944, 3998, 4041, 4071, 4090,
			      };
         return Tb_Cof[_Lft & 255];
		   }
	};//My_Cof

struct _LNX_PACKING My_Sif
	{//functor - sine^5
   My_Sif()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {	
		   return My_Cof()[ _Lft - 64 ];
		   }
	};//My_Sif

struct _LNX_PACKING My_Cox
	{//functor - cosine^6
   My_Cox()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {//table is optimized	
		   static const shrt_t 
            Tb_Cox[] =
			      {
                4096, 4089, 4066, 4030, 3979, 3915, 3837, 3747, 3646, 3534, 3413, 3283, 3145, 3002, 2854, 2702,
                2547, 2391, 2235, 2080, 1927, 1777, 1631, 1490, 1353, 1223, 1100,  983,  874,  772,  678,  591,
                 512,  440,  376,  318,  267,  222,  183,  149,  120,   96,   76,   59,   45,   34,   25,   18,
                  13,    9,    6,    4,    2,    1,    1,    0,    0,    0,    0,    0,    0,    0,    0,    0,
                   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,   -1,   -1,   -2,   -4,   -6,   -9,
                 -13,  -18,  -25,  -34,  -45,  -59,  -76,  -96, -120, -149, -183, -222, -267, -318, -376, -440,
                -512, -591, -678, -772, -874, -983,-1100,-1223,-1353,-1490,-1631,-1777,-1927,-2080,-2235,-2391,
               -2547,-2702,-2854,-3002,-3145,-3283,-3413,-3534,-3646,-3747,-3837,-3915,-3979,-4030,-4066,-4089,
               -4096,-4089,-4066,-4030,-3979,-3915,-3837,-3747,-3646,-3534,-3413,-3283,-3145,-3002,-2854,-2702,
               -2547,-2391,-2235,-2080,-1927,-1777,-1631,-1490,-1353,-1223,-1100, -983, -874, -772, -678, -591,
                -512, -440, -376, -318, -267, -222, -183, -149, -120,  -96,  -76,  -59,  -45,  -34,  -25,  -18,
                 -13,   -9,   -6,   -4,   -2,   -1,   -1,    0,    0,    0,    0,    0,    0,    0,    0,    0,
                   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    1,    1,    2,    4,    6,    9,
                  13,   18,   25,   34,   45,   59,   76,   96,  120,  149,  183,  222,  267,  318,  376,  440,
                 512,  591,  678,  772,  874,  983, 1100, 1223, 1353, 1490, 1631, 1777, 1927, 2080, 2235, 2391,
                2547, 2702, 2854, 3002, 3145, 3283, 3413, 3534, 3646, 3747, 3837, 3915, 3979, 4030, 4066, 4089,
			      };
         return Tb_Cox[_Lft & 255];
		   }
	};//My_Cox

struct _LNX_PACKING My_Six
	{//functor - sine^6
   My_Six()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {	
		   return My_Cox()[ _Lft - 64 ];
		   }
	};//My_Six

struct _LNX_PACKING My_Caw
	{//functor - saw cosine
   My_Caw()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {//table is optimized	
		   static const shrt_t 
            Tb_Caw[] =
			      {
                4096, 4032, 3968, 3904, 3840, 3776, 3712, 3648, 3584, 3520, 3456, 3392, 3328, 3264, 3200, 3136,
                3072, 3008, 2944, 2880, 2816, 2752, 2688, 2624, 2560, 2496, 2432, 2368, 2304, 2240, 2176, 2112,
                2048, 1984, 1920, 1856, 1792, 1728, 1664, 1600, 1536, 1472, 1408, 1344, 1280, 1216, 1152, 1088,
                1024,  960,  896,  832,  768,  704,  640,  576,  512,  448,  384,  320,  256,  192,  128,   64,
                   0,  -64, -128, -192, -256, -320, -384, -448, -512, -576, -640, -704, -768, -832, -896, -960,
               -1024,-1088,-1152,-1216,-1280,-1344,-1408,-1472,-1536,-1600,-1664,-1728,-1792,-1856,-1920,-1984,
               -2048,-2112,-2176,-2240,-2304,-2368,-2432,-2496,-2560,-2624,-2688,-2752,-2816,-2880,-2944,-3008,
               -3072,-3136,-3200,-3264,-3328,-3392,-3456,-3520,-3584,-3648,-3712,-3776,-3840,-3904,-3968,-4032,
               -4096,-4032,-3968,-3904,-3840,-3776,-3712,-3648,-3584,-3520,-3456,-3392,-3328,-3264,-3200,-3136,
               -3072,-3008,-2944,-2880,-2816,-2752,-2688,-2624,-2560,-2496,-2432,-2368,-2304,-2240,-2176,-2112,
               -2048,-1984,-1920,-1856,-1792,-1728,-1664,-1600,-1536,-1472,-1408,-1344,-1280,-1216,-1152,-1088,
               -1024, -960, -896, -832, -768, -704, -640, -576, -512, -448, -384, -320, -256, -192, -128,  -64,
                   0,   64,  128,  192,  256,  320,  384,  448,  512,  576,  640,  704,  768,  832,  896,  960,
                1024, 1088, 1152, 1216, 1280, 1344, 1408, 1472, 1536, 1600, 1664, 1728, 1792, 1856, 1920, 1984,
                2048, 2112, 2176, 2240, 2304, 2368, 2432, 2496, 2560, 2624, 2688, 2752, 2816, 2880, 2944, 3008,
                3072, 3136, 3200, 3264, 3328, 3392, 3456, 3520, 3584, 3648, 3712, 3776, 3840, 3904, 3968, 4032,
			      };
         return Tb_Caw[_Lft & 255];
		   }
	};//My_Caw

struct _LNX_PACKING My_Saw
	{//functor - saw sine
   My_Saw()
      {//default constructor
      }

	template<class _Tp> shrt_t
      operator[]( const _Tp &_Lft ) const _NOTHROW
		   {	
		   return My_Caw()[ _Lft - 64 ];
		   }
	};//My_Saw

//-------------------------------------
//	Trigonometry list of periodic types
//-------------------------------------
typedef  Trigon<My_Cod>   _Cod;
typedef  Trigon<My_Sid>   _Sid;
typedef  Trigon<My_Cor>   _Cor;
typedef  Trigon<My_Sir>   _Sir;
typedef  Trigon<My_Cos>   _Cos;
typedef  Trigon<My_Sin>   _Sin;
typedef  Trigon<My_Cog>   _Cog;
typedef  Trigon<My_Sig>   _Sig;
typedef  Trigon<My_Cot>   _Cot;
typedef  Trigon<My_Sit>   _Sit;
typedef  Trigon<My_Coq>   _Coq;
typedef  Trigon<My_Siq>   _Siq;
typedef  Trigon<My_Cof>   _Cof;
typedef  Trigon<My_Sif>   _Sif;
typedef  Trigon<My_Cox>   _Cox;
typedef  Trigon<My_Six>   _Six;
typedef  Trigon<My_Caw>   _Caw;
typedef  Trigon<My_Saw>   _Saw;

//-------------------------------------
//	Trigonometry adapters
//-------------------------------------
template<class _Ty> inline _Cod
   _cod( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Cod()( _Lft );
	   }

template<class _Ty> inline _Sid
   _sid( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Sid()( _Lft );
	   }

template<class _Ty> inline _Cor
   _cor( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Cor()( _Lft );
	   }

template<class _Ty> inline _Sir
   _sir( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Sir()( _Lft );
	   }

template<class _Ty> inline _Cos
   _cos( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Cos()( _Lft );
	   }

template<class _Ty> inline _Sin
   _sin( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Sin()( _Lft );
	   }

template<class _Ty> inline _Cog
   _cog( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Cog()( _Lft );
	   }

template<class _Ty> inline _Sig
   _sig( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Sig()( _Lft );
	   }

template<class _Ty> inline _Cot
   _cot( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Cot()( _Lft );
	   }

template<class _Ty> inline _Sit
   _sit( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Sit()( _Lft );
	   }

template<class _Ty> inline _Coq
   _coq( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Coq()( _Lft );
	   }

template<class _Ty> inline _Siq
   _siq( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Siq()( _Lft );
	   }

template<class _Ty> inline _Cof
   _cof( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Cof()( _Lft );
	   }

template<class _Ty> inline _Sif
   _sif( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Sif()( _Lft );
	   }

template<class _Ty> inline _Cox
   _cox( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Cox()( _Lft );
	   }

template<class _Ty> inline _Six
   _six( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Six()( _Lft );
	   }

template<class _Ty> inline _Caw
   _caw( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Caw()( _Lft );
	   }

template<class _Ty> inline _Saw
   _saw( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return _Saw()( _Lft );
	   }

//-------------------------------------
//	Trigonometry restricted adapters
//-------------------------------------
template<class _Ty,class _Tp> inline _Cod
   _cod( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Cod()( _Lft,_Rht );
	   }

template<class _Ty,class _Tp> inline _Sid
   _sid( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Sid()( _Lft,_Rht );
	   }

template<class _Ty,class _Tp> inline _Cor
   _cor( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Cor()( _Lft,_Rht );
	   }

template<class _Ty,class _Tp> inline _Sir
   _sir( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Sir()( _Lft,_Rht );
	   }

template<class _Ty,class _Tp> inline _Cos
   _cos( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Cos()( _Lft,_Rht );
	   }

template<class _Ty,class _Tp> inline _Sin
   _sin( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Sin()( _Lft,_Rht );
	   }

template<class _Ty,class _Tp> inline _Cog
   _cog( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Cog()( _Lft,_Rht );
	   }

template<class _Ty,class _Tp> inline _Sig
   _sig( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Sig()( _Lft,_Rht );
	   }

template<class _Ty,class _Tp> inline _Cot
   _cot( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Cot()( _Lft,_Rht );
	   }

template<class _Ty,class _Tp> inline _Sit
   _sit( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Sit()( _Lft,_Rht );
	   }

template<class _Ty,class _Tp> inline _Coq
   _coq( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Coq()( _Lft,_Rht );
	   }

template<class _Ty,class _Tp> inline _Siq
   _siq( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Siq()( _Lft,_Rht );
	   }

template<class _Ty,class _Tp> inline _Cof
   _cof( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Cof()( _Lft,_Rht );
	   }

template<class _Ty,class _Tp> inline _Sif
   _sif( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Sif()( _Lft,_Rht );
	   }

template<class _Ty,class _Tp> inline _Cox
   _cox( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Cox()( _Lft,_Rht );
	   }

template<class _Ty,class _Tp> inline _Six
   _six( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Six()( _Lft,_Rht );
	   }

template<class _Ty,class _Tp> inline _Caw
   _caw( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Caw()( _Lft,_Rht );
	   }

template<class _Ty,class _Tp> inline _Saw
   _saw( const _Ty &_Lft,const _Tp &_Rht ) _NOTHROW
	   {//adapter
	   return _Saw()( _Lft,_Rht );
	   }

/**************************************
   Aperiodic trigonometric functors
**************************************/
struct _LNX_PACKING Logdc
	{//decimal logarithm functor
   Logdc()
      {//default constructor
      }

	template<class _Ty> shrt_t
      operator()( const _Ty &_Lft,const _Ty &_Rht ) const _NOTHROW
		   {
		   AFFIRM(_Lft >= _Ty());
         AFFIRM(_Lft <= _Rht );

		   static const shrt_t 
            Tb_Log[] = // [0..256]
			      {
			         0,  256,  406,  512,  594,  662,  719,  768,  812,  850,  886,  918,  947,  975, 1000, 1024,
               1046, 1068, 1087, 1106, 1124, 1142, 1158, 1174, 1189, 1203, 1217, 1231, 1244, 1256, 1268, 1280,
               1291, 1302, 1313, 1324, 1334, 1343, 1353, 1362, 1372, 1380, 1389, 1398, 1406, 1414, 1422, 1430,
               1437, 1445, 1452, 1459, 1466, 1473, 1480, 1487, 1493, 1500, 1506, 1512, 1518, 1524, 1530, 1536,
               1542, 1547, 1553, 1558, 1564, 1569, 1574, 1580, 1585, 1590, 1595, 1599, 1604, 1609, 1614, 1618,
			      1623, 1628, 1632, 1636, 1641, 1645, 1649, 1654, 1658, 1662, 1666, 1670, 1674, 1678, 1682, 1686, 
               1690, 1693, 1697, 1701, 1705, 1708, 1712, 1715, 1719, 1722, 1726, 1729, 1733, 1736, 1739, 1743,
               1746, 1749, 1752, 1756, 1759, 1762, 1765, 1768, 1771, 1774, 1777, 1780, 1783, 1786, 1789, 1792,
               1795, 1798, 1801, 1803, 1806, 1809, 1812, 1814, 1817, 1820, 1822, 1825, 1828, 1830, 1833, 1836,
               1838, 1841, 1843, 1846, 1848, 1851, 1853, 1855, 1858, 1860, 1863, 1865, 1867, 1870, 1872, 1874,
			      1877, 1879, 1881, 1884, 1886, 1888, 1890, 1892, 1895, 1897, 1899, 1901, 1903, 1905, 1908, 1910,
               1912, 1914, 1916, 1918, 1920, 1922, 1924, 1926, 1928, 1930, 1932, 1934, 1936, 1938, 1940, 1942,
               1944, 1946, 1947, 1949, 1951, 1953, 1955, 1957, 1959, 1961, 1962, 1964, 1966, 1968, 1970, 1971,
               1973, 1975, 1977, 1978, 1980, 1982, 1984, 1985, 1987, 1989, 1990, 1992, 1994, 1995, 1997, 1999,
               2000, 2002, 2004, 2005, 2007, 2008, 2010, 2012, 2013, 2015, 2016, 2018, 2020, 2021, 2023, 2024,
			      2026, 2027, 2029, 2030, 2032, 2033, 2035, 2036, 2038, 2039, 2041, 2042, 2044, 2045, 2047, 2048,
               2048,
			      };
		   return shrt_t(Tb_Log[at( _Lft,_Rht )]*_Rht >> 11);
		   }

private:
	uint_t
      at( uint_t _Left,uint_t _Right ) const _NOTHROW
		   {//calculate index
         AFFIRM (_Left <  0xffffff); return uint_t(_Left << 8)/_Right;
		   }

	};//Logdc

struct _LNX_PACKING Arctg
	{//functor
   Arctg()
      {//default constructor
      }

   template<class _Ty> shrt_t
      operator()( const _Ty &_Dfx,const _Ty &_Dfy ) const _NOTHROW
		   {//arctangent <x,y>
		   static const char_t 
            TbArctg[] = //[0..256]
			      {
	              0,  0,  0,  1,  1,  1,  1,  1,  1,  2,  2,  2,  2,  2,  2,  2,
	              3,  3,  3,  3,  3,  3,  4,  4,  4,  4,  4,  4,  5,  5,  5,  5,
	              5,  5,  5,  6,  6,  6,  6,  6,  6,  7,  7,  7,  7,  7,  7,  7,
	              8,  8,  8,  8,  8,  8,  9,  9,  9,  9,  9,  9,  9, 10, 10, 10,
	             10, 10, 10, 11, 11, 11, 11, 11, 11, 11, 12, 12, 12, 12, 12, 12,
	             12, 13, 13, 13, 13, 13, 13, 13, 14, 14, 14, 14, 14, 14, 14, 15,
	             15, 15, 15, 15, 15, 15, 16, 16, 16, 16, 16, 16, 16, 16, 17, 17,
	             17, 17, 17, 17, 17, 18, 18, 18, 18, 18, 18, 18, 18, 19, 19, 19,
	             19, 19, 19, 19, 19, 20, 20, 20, 20, 20, 20, 20, 20, 21, 21, 21,
	             21, 21, 21, 21, 21, 22, 22, 22, 22, 22, 22, 22, 22, 22, 23, 23,
	             23, 23, 23, 23, 23, 23, 23, 24, 24, 24, 24, 24, 24, 24, 24, 24,
	             25, 25, 25, 25, 25, 25, 25, 25, 25, 26, 26, 26, 26, 26, 26, 26,
	             26, 26, 26, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 28, 28, 28,
	             28, 28, 28, 28, 28, 28, 28, 29, 29, 29, 29, 29, 29, 29, 29, 29,
	             29, 29, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 31, 31,
	             31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 32, 32, 32, 32, 32, 32,
	             32,
			      };

         register uint_t 
            _Abx = _Dfx >= _Ty() ? _Dfx : -_Dfx,
            _Aby = _Dfy >= _Ty() ? _Dfy : -_Dfy;
         
         if(_Abx + _Aby ==  0)
            {
            AFFBUG; return -1;
            }
         
		   switch(((_Dfy < 0) << 2) + ((_Dfx < 0) << 1) + (_Aby > _Abx))
			   {
            default: return (      TbArctg[at( _Aby,_Abx )]);
            case  1: return ( 64 - TbArctg[at( _Abx,_Aby )]);
            case  2: return (128 - TbArctg[at( _Aby,_Abx )]);
			   case  3: return ( 64 + TbArctg[at( _Abx,_Aby )]);
            case  4: return (256 - TbArctg[at( _Aby,_Abx )]) & 255;
			   case  5: return (192 + TbArctg[at( _Abx,_Aby )]);
            case  6: return (128 + TbArctg[at( _Aby,_Abx )]);
			   case  7: return (192 - TbArctg[at( _Abx,_Aby )]);
			   }
		   }

private:	
   uint_t
      at( uint_t _Left,uint_t _Right ) const _NOTHROW
		   {//get index
         AFFIRM (_Left <  0xffffff); return uint_t(_Left << 8)/_Right;
		   }

	};//Arctg

//-------------------------------------
//	Aperiodic trigonometry adapters
//-------------------------------------
template<class _Ty> inline shrt_t
   logdc( const _Ty &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//logarithm adapter
	   return Logdc()( _Lft,_Rht );
	   }

template<class _Ty> inline shrt_t
   arctg( const _Ty &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//adapter
	   return Arctg()( _Lft,_Rht );
	   }

/**************************************
			Mathimatic functors
**************************************/
struct _LNX_PACKING Max
	{//functor 
   template<class _Ty> _Ty
      operator ()( const _Ty &_Lft,const _Ty &_Rht ) const _NOTHROW
         {//return larger
         return (_Lft < _Rht ? _Rht : _Lft);
         }
	};

struct _LNX_PACKING Min
	{//functor
   template<class _Ty> _Ty
      operator ()( const _Ty &_Lft,const _Ty &_Rht ) const _NOTHROW
         {//return smaller
	      return (_Lft > _Rht ? _Rht : _Lft);            
         }
	};

template<class _Ty>
struct _LNX_PACKING SqS
	{//functor
	_Ty 
      operator()( const _Ty &_Lft,const _Ty &_Rht ) const _NOTHROW
		   {//squares sum
		   return (_Lft*_Lft + _Rht*_Rht);
		   }
	};

struct _LNX_PACKING Sgn
	{//functor
	template<class _Ty> _Ty
      operator()( const _Ty &_Lft ) const _NOTHROW
		   {//signum of value
         return (_Lft > _Ty()) - (_Lft < _Ty());
		   }
	};

struct _LNX_PACKING Leaf
	{//functor
   enum
      {//fictitious position
      _ = -1
      };

	template<class _Ty> byte_t 
      operator()( const _Ty &_Lft ) const _NOTHROW
		   {//transform angle to leaf
         return ((_Lft + 16) & 255) >> 5;
		   }

	template<class _Ty> shrt_t
      operator()( const _Ty &_Dfx,const _Ty &_Dfy ) const _NOTHROW
		   {//transform differences to leaf
         return operator()( Arctg()( _Dfx,_Dfy ));
		   }

	template<class _Ty> char_t
      operator()( const _Ty &_Dfx,const _Ty &_Dfy,bool_t ) const _NOTHROW
         {//quick transform differences to leaf
         static const char_t
            TbLeaf[] = //number of leaf
               {
               5,6,7,_,4,_,0,_,3,2,1,_
               };
         return TbLeaf[Sgn()( _Dfx ) + (Sgn()( _Dfy ) << 2) + 5];
         }
	};

struct _LNX_PACKING X_rotate
	{//rotate x coordinate
	template<class _Ty> _Ty 
      operator()( const _Ty &_Psx,const _Ty &_Psy,const _Ty &_Ang ) const _NOTHROW
		   {//positive for clockwize rotation
         _Cos _Cs;
         _Sin _Sn; return (_Psx*_Cs[_Ang] - _Psy*_Sn[_Ang])/_Cs.max();
		   }
	};

struct _LNX_PACKING Y_rotate
	{//rotate y coordinate
	template<class _Ty> _Ty 
      operator()( const _Ty &_Psx,const _Ty &_Psy,const _Ty &_Ang ) const _NOTHROW
		   {//positive for clockwize rotation
         _Cos _Cs;
         _Sin _Sn; return (_Psy*_Cs[_Ang] + _Psx*_Sn[_Ang])/_Cs.max();
		   }
	};

//-------------------------------------
//	Template adapters
//-------------------------------------
template<class _Ty> inline atom_t
   leul( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return Leul[ _Lft ];
      }

template<class _Ty> inline iint_t
   sqs( const _Ty &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//adapter
	   return SqS<_Ty>()( _Lft,_Rht );
	   }

template<class _Ty> inline _Ty
   abs( const _Ty &_Lft ) _NOTHROW
	   {//absolute value
      return (_Lft >= _Ty() ? _Lft : -_Lft);
	   }

template<> inline char_t
   abs( const char_t &_Lft ) _NOTHROW
	   {//absolute value
      register char_t 
         _Tmp = _Lft >> 07; return (_Lft ^ _Tmp) - _Tmp;
	   }

template<> inline iint_t
   abs( const iint_t &_Lft ) _NOTHROW
	   {//absolute value
      register iint_t 
         _Tmp = _Lft >> 31; return (_Lft ^ _Tmp) - _Tmp;
	   }

template<> inline guar_t
   abs( const guar_t &_Lft ) _NOTHROW
	   {//absolute value
      register guar_t
         _Tmp = _Lft >> 63; return (_Lft ^ _Tmp) - _Tmp;
	   }

template<class _Ty> inline _Ty
   doz( const _Ty &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//sub in first class
      return (_Lft > _Rht) ? (_Lft - _Rht) : 0;
	   }

template<class _Ty> inline _Ty
   cmp( const _Ty &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//compare two values
      return (_Lft > _Rht) - (_Lft < _Rht);
	   }

template<class _Ty> inline _Ty
   max( const _Ty &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//return larger
      return (_Lft > _Rht ? _Lft : _Rht);
	   }

template<class _Ty> inline _Ty
   max( const _Ty &_Lft,const _Ty &_Med,const _Ty &_Rht ) _NOTHROW
	   {//adapter
      return max( _Med,max( _Lft,_Rht ));
	   }

template<class _Ty> inline _Ty
   min( const _Ty &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//return smaller
      return (_Lft < _Rht ? _Lft : _Rht);
	   }

template<class _Ty> inline _Ty
   min( const _Ty &_Lft,const _Ty &_Med,const _Ty &_Rht ) _NOTHROW
	   {//adapter
      return min( _Med,min( _Lft,_Rht ));
	   }

template<class _Ty> inline _Ty
   med( const _Ty &_Lft,const _Ty &_Rht,const _Ty &_Med ) _NOTHROW
	   {//return median
	   if(_Lft < _Med)
		   return _Med < _Rht ? _Med : _Lft < _Rht ? _Rht : _Lft;
	   else
		   return _Lft < _Rht ? _Lft : _Med < _Rht ? _Rht : _Med;
	   };

template<class _Ty> inline _Ty
   mes( const _Ty &_Lft,const _Ty &_Val,const _Ty &_Rht ) _NOTHROW
	   {//metric
		if (_Lft + _Val + _Rht > _Ty())
         return max( _Lft,_Rht,_Val );
      if (_Lft + _Val + _Rht < _Ty())
         return min( _Lft,_Rht,_Val );
      
      return _Ty();
	   }

template<class _Ty> inline _Ty
   geav( const _Ty &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//geometric average
      return sqrm( _Lft*_Rht );
	   }

template<class _Ty> inline _Ty
   haav( const _Ty &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//harmonic average
      _Ty _Sum = _Lft + _Rht; return (_Sum ? _Lft*2*_Rht/_Sum : 0);
	   }

template<class _Ty> inline _Ty
   into( const _Ty &_Val,const _Ty &_Min,const _Ty &_Max ) _NOTHROW
	   {//limits
      return (_Val >= _Min ? _Val <= _Max ? _Val : _Max : _Min);
   	}

template<class _Ty> inline _Ty
   inbt( const _Ty &_Val ) _NOTHROW
	   {//adapter
	   return into( _Val,_Ty(),_Ty(255));
	   }

template<class _Ty> inline _Ty
   inhf( const _Ty &_Val ) _NOTHROW
	   {//adapter
	   return into( _Val,_Ty(),_Ty(127));
	   }

template<class _Ty> inline _Ty
   inpc( const _Ty &_Val ) _NOTHROW
	   {//adapter
	   return into( _Val,_Ty(),_Ty(100));
	   }

template<class _Ty> inline _Ty
   inqt( const _Ty &_Val ) _NOTHROW
	   {//adapter
	   return into( _Val,_Ty(),_Ty( 63));
	   }

template<class _Ty> inline _Ty
   sign( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return Sgn()( _Lft );
	   }

template<class _Ty> inline byte_t
   dndg( const _Ty &_Lft ) _NOTHROW
      {//from 360 to 256 degree
      AFFIRM(_Lft >= _Ty()); return byte_t(365*_Lft >> 9);
      }

template<class _Ty> inline twin_t
   updg( const _Ty &_Lft ) _NOTHROW
      {//from 256 to 360 degree
      AFFIRM(_Lft >= _Ty()); return twin_t( 90*_Lft >> 6);
      }

template<class _Ty> inline twin_t
   dudg( const _Ty &_Lft ) _NOTHROW
      {//duple degree
      AFFIRM(_Lft >= _Ty()); return twin_t(    _Lft << 1);
      }

template<class _Ty> inline byte_t
   updi( const _Ty &_Lft ) _NOTHROW
	   {//normalize direction
	   return byte_t(_Lft & 7);
	   }

template<class _Ty> inline byte_t
   diin( const _Ty &_Lft ) _NOTHROW
	   {//invert positive direction
	   return updi(_Lft + 4);
	   }

template<class _Ty> inline byte_t
   toci( const _Ty &_Lft ) _NOTHROW
	   {//normalize to 256 degree
      return (_Lft & 255);
	   }

template<class _Ty> inline byte_t
   topi( const _Ty &_Lft ) _NOTHROW
	   {//normalize to 128 degree
      return (_Lft & 127);
	   }

template<class _Ty> inline byte_t
   leaf( const _Ty &_Lft ) _NOTHROW
	   {//adapter
	   return Leaf()( _Lft );
	   }

template<class _Ty> inline shrt_t
   leaf( const _Ty &_Dfx,const _Ty &_Dfy ) _NOTHROW
	   {//adapter
	   return Leaf()( _Dfx,_Dfy );
	   }

template<class _Ty> inline char_t
   leaf( const _Ty &_Dfx,const _Ty &_Dfy,bool_t ) _NOTHROW
	   {//adapter
	   return Leaf()( _Dfx,_Dfy,true );
	   }

template<class _Ty> inline char_t
   sscis( const _Ty &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//scissors from _Rht to _Lft
      register char_t 
         _Tmp = (_Lft - _Rht) & 127; return _Tmp - ((_Tmp & 64) << 1);
	   }

template<class _Ty> inline byte_t
   uscis( const _Ty &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//scissors from _Rht to _Lft
      return abs( sscis( _Lft,_Rht ));
	   }

template<class _Ty> inline char_t
   sturn( const _Ty &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//signed nearest turn _Rht to _Lft
      register  char_t 
         _Tmp = char_t(_Lft - _Rht); return _Tmp;
	   }

template<class _Ty> inline byte_t
   uturn( const _Ty &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//unsigned nearest turn _Rht to _Lft
      return abs( sturn( _Lft,_Rht ));
	   }

template<class _Ty> inline byte_t
   watch( const _Ty &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//turn _Rht clockwize to _Lft
      register  byte_t
         _Tmp = byte_t(_Lft - _Rht); return _Tmp;
	   }

template<class _Ty> inline bool_t
   phase( const _Ty &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//test if vectors in phase
      register  byte_t 
         _Tmp = byte_t(_Lft - _Rht); return (_Tmp < 64) | (_Tmp > 192);
	   }

template<class _Ty> inline iint_t
   range( const _Ty &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//adapter
      return sqri( SqS<guar_t>()( _Lft,_Rht ));
	   }

template<class _Ty> inline iint_t
   isize( const _Ty &_Lft,const _Ty &_Rht ) _NOTHROW
	   {//adapter
      return sqrm( SqS<guar_t>()( _Lft,_Rht ));
	   }

template<class _Ty,class _Tp> inline _Ty
   x_rot( const _Ty &_Psx,const _Ty &_Psy,const _Tp &_Ang ) _NOTHROW
	   {////positive for clockwize rotation
	   return X_rotate()( _Psx,_Psy,(_Ty)_Ang );
	   }

template<class _Ty,class _Tp> inline _Ty
   y_rot( const _Ty &_Psx,const _Ty &_Psy,const _Tp &_Ang ) _NOTHROW
	   {//positive for clockwize rotation
	   return Y_rotate()( _Psx,_Psy,(_Ty)_Ang );
	   }

//-------------------------------------
// Object's adapters
//-------------------------------------
template<class _Ty,class _Tp> inline shrt_t
   cs_arctg( const _Ty &_Dst,const _Tp &_Src ) _NOTHROW
	   {//get ray from src to dst
	   return arctg( _Dst.Movx - _Src.Movx,_Dst.Movy - _Src.Movy );
	   }

template<class _Ty,class _Tp> inline byte_t
   cs_watch( const _Ty &_Dst,const _Tp &_Src ) _NOTHROW
	   {//rotate beta of src clockwize to ray from src to dst
	   return watch( cs_arctg( _Dst,_Src ),_Src.Beta );
	   }

template<class _Ty,class _Tp> inline iint_t
   cs_range( const _Ty &_Dst,const _Tp &_Src ) _NOTHROW
	   {//Euclid distance between objects
	   return range<iint_t>( _Dst.Movx - _Src.Movx,_Dst.Movy - _Src.Movy );
	   }

template<class _Ty,class _Tp> inline iint_t
   cs_isize( const _Ty &_Dst,const _Tp &_Src ) _NOTHROW
	   {//Euclid distance between objects
	   return isize<iint_t>( _Dst.Movx - _Src.Movx,_Dst.Movy - _Src.Movy );
	   }

template<class _Ty,class _Tp> inline iint_t
   cs_force( const _Ty &_Dst,const _Tp &_Src ) _NOTHROW
	   {//Euclid distance between objects
	   return sqs  ( _Dst.Movx - _Src.Movx,_Dst.Movy - _Src.Movy );
	   }

template<class _Td,class _Ts> inline char_t
   cs_sturn( const _Td &_Dst,const _Ts &_Src ) _NOTHROW
	   {//turn beta of src to ray from src to dst
	   return sturn( cs_arctg( _Dst,_Src ),_Src.Beta );
	   }

template<class _Td,class _Ts> inline byte_t
   cs_uturn( const _Td &_Dst,const _Ts &_Src ) _NOTHROW
	   {//turn beta of src to ray from src to dst
	   return uturn( cs_arctg( _Dst,_Src ),_Src.Beta );
	   }

template<class _Td,class _Ts> inline char_t
   cs_sbeta( const _Td &_Dst,const _Ts &_Src ) _NOTHROW
	   {//turn beta of src to beta of dst
	   return sturn( _Dst.Beta,_Src.Beta );
	   }

template<class _Td,class _Ts> inline byte_t
   cs_ubeta( const _Td &_Dst,const _Ts &_Src ) _NOTHROW
	   {//turn beta of src to beta of dst
	   return uturn( _Dst.Beta,_Src.Beta );
	   }

_ESK_END
#pragma pack(pop)
#endif//TRIGON_H
