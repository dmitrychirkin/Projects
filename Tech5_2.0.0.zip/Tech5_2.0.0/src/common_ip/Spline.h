#pragma		once
#ifndef		SPLINE_H
#define		SPLINE_H

//	Header project file
#include		"Eskdef.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
     Lagrange interpolation method 
**************************************/
template<class _Ty = double>
struct _LNX_PACKING Lagwin
	{//list of the knots {n,[x,y]}
	template<class _Other> _Other 
      operator()( const _Other *_Tbl,_Other _Idx ) const
		   {
		   _Ty sum = _Ty(),
			    num,
			    den;
		
		   for (_Other j = _Tbl[0]; j > 0; j--)
			   {//use any number of nots in _Tbl[0]
			   num = den = 1;
			
			   for (_Other n = _Tbl[0]; n > 0; n--)
				   if (n != j) num *= _Idx - _Tbl[2*n-1];//numerator
			
			   for (_Other d = _Tbl[0]; d > 0; d--)
				   if (d != j) den *= _Tbl[2*j-1] - _Tbl[2*d-1];//denominator

			   sum += _Tbl[2*j]*num/den;//collector
			   }
		   return _Other((sum > 0) ? sum+0.5 : sum-0.5);
		   }

	template<class _Other> _Other
      operator()( const _Other *_Tbl,_Other _Idx,_Other _Min,_Other _Max ) const
		   {//use any number of nots in Tbl[0], select nearest
         _Other _Val = operator()( _Tbl,_Idx ); return (_Val < _Max ?
                                                        _Val > _Min ? _Val : _Min : _Max);
         }

	};//Lagwin

template<class _Ty> inline _Ty
   lagwin( const _Ty *_Tbl,_Ty _Idx )
	   {//adapter
	   return Lagwin<>()( _Tbl,_Idx );
	   }

template<class _Ty> inline _Ty
   lagwin( const _Ty *_Tbl,_Ty _Idx,_Ty _Min,_Ty _Max )
	   {//adapter
      return Lagwin<>()( _Tbl,_Idx,_Min,_Max );
	   }

/**************************************
     Spline interpolation method 
**************************************/
template<class _Ty = double>
struct _LNX_PACKING Gudwin
	{//list of the knots {n,[x,y,t]}
	template<class _Other> _Other
      operator()( const _Other *_Tbl,_Other _Idx ) const
		   {//use any number of nots in Tbl[0], select nearest
		   _Other n = 1,
				    v = 2;

         //verify start
         if(_Idx < _Tbl[1])
            return _Other(0);

		   for (; v < _Tbl[0] && _Tbl[n+3] < _Idx;)
			   {//find interval
			   n += 3;
			   v += 1;
			   }

         //verify end
         if(_Idx > _Tbl[n+3])
            return _Other(0);

		   //from the start not
         _Ty   frx = _Ty(_Tbl[n+0]),
				   fry = _Ty(_Tbl[n+1]),
				   frt = _Ty(_Tbl[n+2]),
				   //to final not
				   fix = _Ty(_Tbl[n+3]),
				   fiy = _Ty(_Tbl[n+4]),
				   fit = _Ty(_Tbl[n+5]);

		   //temporary data..
		   _Ty   tan  =(( frx-fix)*  frt/32	 -( fry-fiy))*
						    (_Idx-fix)*(_Idx-fix)*(_Idx-frx) +
						   (( frx-fix)*  fit/32	 -( fry-fiy))*
						    (_Idx-frx)*(_Idx-frx)*(_Idx-fix) ;
				   tan /=(( frx-fix)*( frx-fix)*( frx-fix));
		
		   _Ty   ton  = fry*(_Idx-fix);	ton /=(frx-fix) ;
		   _Ty   end  = fiy*(_Idx-frx);	end /=(fix-frx) ;
				   //interpolation
				   tan += ton+end;
		
		   return _Other((tan > 0) ? tan+0.5 : tan-0.5);
		   }

	template<class _Other> _Other
      operator()( const _Other *_Tbl,_Other _Idx,_Other _Min,_Other _Max ) const
		   {//use any number of nots in Tbl[0], select nearest
         _Other _Val = operator()( _Tbl,_Idx ); return (_Val < _Max ?
                                                        _Val > _Min ? _Val : _Min : _Max);
         }

	};//Gudwin

template<class _Ty> inline _Ty
   gudwin( const _Ty *_Tbl,_Ty _Idx )
	   {//adapter
	   return Gudwin<>()( _Tbl,_Idx );
	   }

template<class _Ty> inline _Ty
   gudwin( const _Ty *_Tbl,_Ty _Idx,_Ty _Min,_Ty _Max )
	   {//adapter
      return Gudwin<>()( _Tbl,_Idx,_Min,_Max );
	   }

_ESK_END
#pragma pack(pop)
#endif//SPLINE_H
