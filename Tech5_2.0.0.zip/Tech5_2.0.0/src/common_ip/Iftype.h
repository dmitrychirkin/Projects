/**************************************
					IFTYPE.H
				Type promotion.

        Copyright (c) 1994-2004.
        Copyright (c) 2005-2012.
**************************************/
#pragma		once
#ifndef		IFTYPE_H
#define		IFTYPE_H

//	Use project headers
#include		"Ldsdef.h"

#pragma pack(push,_LDS_PACKING)
_LDS_BEGIN
/**************************************
		Promotion for composition
**************************************/
#define PIF( _Ty,_Tp,Name )   typename Promotion<typename _Ty::##Name,typename _Tp::##Name>::Ifty
#define BIF( _Ty,_Tp )			typename Promotion<_Ty,_Tp>::Ifty

/**************************************
			Phase compilation
**************************************/
template<bool,typename,typename>
struct Iftype;

template<typename _Ty,typename _Tp>
struct Iftype<true,typename _Ty,typename _Tp>
	{//promotion if true
	typedef _Ty Ifty;
	};

template<typename _Ty,typename _Tp>
struct Iftype<false,typename _Ty,typename _Tp>
	{//promotion if false
	typedef _Tp Ifty;
	};

template<typename _Ty,typename _Tp>
struct Promotion
	{//the promotion
	typedef typename Iftype<(sizeof(_Ty) > sizeof(_Tp)),_Ty,_Tp>::Ifty Ifty;
	};

_LDS_END
#pragma pack(pop)
#endif//IFTYPE_H
/*
All rights reserved. Consult your license regarding permissions and restrictions.
*/
