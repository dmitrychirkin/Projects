#pragma		once
#ifndef		BIMSET_H
#define		BIMSET_H

//	Header project file
#include		"Bitree.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
		Template class Set_traits
**************************************/
template<class _Ty,class _Pr,class _Alloc,bool_t _Mfl>
class Set_traits
	{//traits required to make Tree behave like a set
public:
	typedef _Ty key_type;
	typedef _Ty item_t;
	typedef _Pr key_compare;
	typedef key_compare value_compare;

	typedef typename _Alloc::template rebind<item_t>::other					_Alty;
	typedef typename _Alty ::template rebind<item_t>::other::pointer		_ITptr;
	typedef typename _Alty ::template rebind<item_t>::other::reference	_IReft;

	enum
		{//make multi parameter visible as an enumeration constant
		MULTIF = _Mfl
		};

	Set_traits() : Comp()
		{//construct with default comparator
		}

	Set_traits( _Pr _Parg ) : Comp(_Parg)
		{//construct with specified comparator
		}

	static const _Ty& 
      _Kfn( const item_t &_Val )
		   {//extract key from element value
		   return (_Val);
		   }

	_Pr      //the comparator predicate for keys
      Comp;

	};//Set_traits

/**************************************
			Template class Set
**************************************/
template<class _Ty,class _Pr = Greater<_Ty>,class _Alloc = Allocator<_Ty> >
class Set : public Tree<Set_traits<_Ty,_Pr,_Alloc,false> >
	{//ordered red-black tree of key values, unique keys
public:
	typedef             Set<_Ty, _Pr, _Alloc>       Self_t;
	typedef Tree<Set_traits<_Ty,_Pr,_Alloc,false> > Base_t;
	typedef _Ty key_type;
	typedef _Pr key_compare;
	typedef typename Base_t::value_compare value_compare;
	typedef typename Base_t::_Alty _Alty;
	typedef typename Base_t::size_t size_t;
	typedef typename Base_t::diff_t diff_t;
	typedef typename Base_t::pointer pointer;
	typedef typename Base_t::const_pointer const_pointer;
	typedef typename Base_t::reference reference;
	typedef typename Base_t::const_reference const_reference;
	typedef typename Base_t::iterator iterator;
	typedef typename Base_t::const_iterator const_iterator;
	typedef typename Base_t::reverse_iterator reverse_iterator;
	typedef typename Base_t::const_reverse_iterator	const_reverse_iterator;
	typedef typename Base_t::item_t item_t;

	Set() : Base_t( key_compare(),_Alty())
		{//construct empty set from defaults
		}

	explicit Set( const key_compare &_Pred ) : Base_t( _Pred,_Alty())
		{//construct empty set from comparator
		}

	Set( const key_compare &_Pred,const _Alty &_Al ) : Base_t( _Pred,_Al )
		{//construct empty set from comparator and allocator
		}

	template<class _Iter>
	Set( _Iter _First,_Iter _Last ) : Base_t( key_compare(),_Alty())
		{//construct set from [_First, _Last), defaults
		for (; _First != _Last; ++_First)
			this->insert(*_First );
		}

	template<class _Iter>
	Set( _Iter _First,_Iter _Last,const key_compare &_Pred ) : Base_t( _Pred,_Alty())
		{//construct set from [_First, _Last), comparator
		for (; _First != _Last; ++_First)
			this->insert(*_First );
		}

	template<class _Iter>
	Set( _Iter _First,_Iter _Last,const key_compare &_Pred,const _Alty &_Al ) : Base_t( _Pred,_Al )
		{//construct set from [_First, _Last), defaults, and allocator
		for (; _First != _Last; ++_First)
			this->insert(*_First );
		}

	};//Set

template<class _Ty,class _Pr,class _Alloc>
class Move_operation_category<Set<_Ty, _Pr, _Alloc> >
	{//set implements a performant swap
public:
	typedef Swap_move_tag Move_cat;
	};

template<class _Ty,class _Pr,class _Alloc> inline void_t 
   swap( Set<_Ty,_Pr,_Alloc> &_Left,Set<_Ty,_Pr,_Alloc> &_Right )
	   {//swap _Left and _Right sets
	   _Left.swap( _Right );
	   }

/**************************************
		Template class Mipset
**************************************/
template<class _Ty,class _Pr = Greater<_Ty>,class _Alloc = Allocator<_Ty> >
class Mipset : public Tree<Set_traits<_Ty,_Pr,_Alloc,true> >
	{//ordered red-black tree of key values, non-unique keys
public:
	typedef          Mipset<_Ty,_Pr,_Alloc>        Self_t;
	typedef Tree<Set_traits<_Ty,_Pr,_Alloc,true> > Base_t;
	typedef _Ty key_type;
	typedef _Pr key_compare;
	typedef typename Base_t::value_compare value_compare;
	typedef typename Base_t::_Alty _Alty;
	typedef typename Base_t::diff_t diff_t;
	typedef typename Base_t::pointer pointer;
	typedef typename Base_t::const_pointer const_pointer;
	typedef typename Base_t::reference reference;
	typedef typename Base_t::const_reference const_reference;
	typedef typename Base_t::iterator iterator;
	typedef typename Base_t::const_iterator const_iterator;
	typedef typename Base_t::reverse_iterator reverse_iterator;
	typedef typename Base_t::const_reverse_iterator	const_reverse_iterator;
	typedef typename Base_t::item_t item_t;

	Mipset() : Base_t( key_compare(),_Alty())
		{//construct empty set from defaults
		}

	explicit Mipset( const key_compare &_Pred ) : Base_t( _Pred,_Alty())
		{//construct empty set from comparator
		}

	Mipset( const key_compare &_Pred, const _Alty &_Al ) : Base_t( _Pred,_Al )
		{//construct empty set from comparator and allocator
		}

	template<class _Iter>
	Mipset( _Iter _First,_Iter _Last ) : Base_t( key_compare(),_Alty())
		{//construct set from [_First, _Last)
		for (; _First != _Last; ++_First)
			this->insert(*_First );
		}

	template<class _Iter>
	Mipset( _Iter _First,_Iter _Last,const key_compare &_Pred ) : Base_t( _Pred,_Alty())
		{//construct set from [_First, _Last), comparator
		for (; _First != _Last; ++_First)
			this->insert(*_First );
		}

	template<class _Iter>
	Mipset( _Iter _First,_Iter _Last,const key_compare &_Pred,const _Alty &_Al ) : Base_t( _Pred,_Al )
		{//construct set from [_First, _Last), comparator, and allocator
		for (; _First != _Last; ++_First)
			this->insert(*_First );
		}

 	iterator 
      insert( const item_t &_Val )
		   {//insert a key value
		   return (Base_t::insert( _Val ).first);
		   }

	iterator 
      insert( iterator _Where,const item_t &_Val )
		   {//insert a key value, with hint
		   return (Base_t::insert( _Where,_Val ));
		   }

	template<class _Iter> void_t 
      insert( _Iter _First,_Iter _Last )
		   {//insert [_First, _Last)
 		   for (; _First != _Last; ++_First)
			   this->insert(*_First );
		   }

	};//Mipset
	
template<class _Ty,class _Pr,class _Alloc>
class Move_operation_category<Mipset<_Ty,_Pr,_Alloc> >
	{//multiset implements a performant swap
public:
	typedef Swap_move_tag Move_cat;
	};

template<class _Ty,class _Pr,class _Alloc> inline void_t 
   swap( Mipset<_Ty,_Pr,_Alloc> &_Left,Mipset<_Ty,_Pr,_Alloc> &_Right )
	   {//swap _Left and _Right multisets
	   _Left.swap( _Right );
	   }

_ESK_END
#pragma pack(pop)
#endif//BITREE_H
