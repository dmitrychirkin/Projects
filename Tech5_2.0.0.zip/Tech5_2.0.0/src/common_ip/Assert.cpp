#ifdef _UPBUG

//	Header system files
#include		<windows.h>

//	Header project file
#include		"Assert.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
			Affirmation utility
**************************************/
template<int SIZE>
class Affirmation
	{
public:
	template<class _Other> void_t
      operator()( bool_t _Expr,char *_File,iint_t _Line,_Other Func,iint_t i = 0 ) const
		   {//out bags to screen
		   if (_Expr == false) 
			   {
			   char_t _Msgf[] = "Trap: file ",
				       _Msgl[] = ",  line "	 ,
				       _Name[] = "No time to dicker!", _Message[SIZE];
			
			   //generates temporary message
			   for (		   i = 0; _Msgf[i]; i++) 
					   _Message[i  ] = _Msgf[i];
			   for (iint_t j = 0; _File[j]; j++) 
					   _Message[i++] = _File[j];
			   for (iint_t	j = 0; _Msgl[j]; j++) 
					   _Message[i++] = _Msgl[j];

			   //complete line number
			   pdbody( _Message,i,_Line );
			   wrbyte( _Message,i,'.'   );
			   wrbyte( _Message,i, 0    );

			   Func( NULL,(char*)_Message,(char*)_Name,MB_APPLMODAL ); //show message
			   }
		   }

private:
	void_t 
      wrbyte( char_t *_Msg,iint_t &_Ind,char_t Symb ) const
		   {//store character
		   if (_Ind < SIZE) _Msg[_Ind++] = Symb;
		   }

	void_t 
      pdbody( char_t *_Msg,iint_t &_Ind,iint_t _Val ) const
		   {//convert integer to list of char
		   if(_Val)
			   {//parse transformation to write
			   pdbody( _Msg,_Ind,_Val/10		  );
			   wrbyte( _Msg,_Ind,_Val%10 + '0' );
			   }
		   }
	};//Affirmation

void_t 
   affirmation( bool_t _Expr,char *_File,iint_t _Line )
	   {//adapter
	   Affirmation<80>()( _Expr,_File,_Line,::MessageBox );
	   }

_ESK_END
#pragma pack(pop)
#endif

