#pragma		once
#ifndef		BITREE_H
#define		BITREE_H

//	Header project file
#include		"Except.h"
#include		"Fnctnl.h"
#include		"Memory.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
      Template class Bitree
**************************************/
template<class _Traits>
class Tree_nod	: public _Traits
	{//base class for Tree_ptr to hold allocator _Alnod
protected:
			 struct Node;
	friend struct Node;

	typedef typename _Traits::_Alty _Alty;
	typedef typename _Traits::key_compare key_compare;
	typedef typename _Traits::item_t item_t;
	typedef typename _Alty::template	rebind<Node>::other::pointer _Geptr;
			  typename _Alty::template rebind<Node>::other			  _Alnod;

	struct Node
		{	// tree node
		Node( _Geptr _Larg, _Geptr _Parg,_Geptr _Rarg,const item_t &_Val,char_t _Color ) : 
				  Left(_Larg),Parent(_Parg),Right(_Rarg),		   Value(_Val),Color(_Color),Isnil(false)
			{//construct a node with value
			}

		_Geptr 
         Parent,
			Right,
			Left;

		item_t   //stored value, unused if head
			Value;	

		char_t	 
         Color, //Red or Black, Black if head
			Isnil; //true only if head (also nil) node
		};

	Tree_nod( const key_compare &_Parg,_Alty _Al ) : _Traits(_Parg),_Alnod(_Al)
		{//construct traits from _Parg and allocator from _Al
		}

	};//Tree_nod

template<class _Traits>
class Tree_ptr : public Tree_nod<_Traits>
	{//base class for Tree_val to hold allocator _Alptr
protected:
	typedef typename Tree_nod<_Traits>::Node Node;
	typedef typename _Traits::_Alty _Alty;
	typedef typename _Traits::key_compare key_compare;
	typedef typename _Alty::template rebind<Node>::other::pointer _Ndptr;
			  typename _Alty::template rebind<_Ndptr>::other		  _Alptr;

	Tree_ptr( const key_compare &_Parg,_Alty _Al ) : Tree_nod<_Traits>(_Parg,_Al),_Alptr(_Al)
		{//construct base, and allocator from _Al
		}
	};

template<class _Traits>
class Tree_val : public Tree_ptr<_Traits>
	{//base class for Tree to hold allocator _Alval
protected:
	typedef typename _Traits::_Alty _Alty;
	typedef typename _Traits::key_compare key_compare;

	Tree_val( const key_compare &_Parg,_Alty _Al ) : Tree_ptr<_Traits>(_Parg,_Al),_Alval(_Al)
		{//construct base, and allocator from _Al
		}

	_Alty 
      _Alval; //allocator object for values stored in nodes
	};

template<class _Traits>
class Tree	: public Tree_val<_Traits>
	{//ordered red-black tree for [multi_]{map set}
public:
	typedef Tree<_Traits> Self_t;
	typedef Tree_val<_Traits> Base_t;
	typedef typename _Traits::key_type key_type;
	typedef typename _Traits::key_compare key_compare;
	typedef typename _Traits::value_compare value_compare;
	typedef typename _Traits::item_t item_t;
	typedef typename _Traits::_Alty _Alty;
	typedef typename _Traits::_ITptr _ITptr;
	typedef typename _Traits::_IReft _IReft;

protected:
	enum Colour_tree
		{//colors for link to parent
		_Red,
		_Black
		};

	typedef typename Tree_nod<_Traits>::_Geptr _Geptr;
	typedef typename Tree_nod<_Traits>::Node Node;
	typedef typename _Alty::template rebind<Node>::other::pointer _Ndptr;
	typedef typename _Alty::template rebind<_Ndptr>::other::reference _Nodepref;
	typedef typename _Alty::template rebind<key_type>::other::const_reference _Keyref;
	typedef typename _Alty::template rebind<char_t>::other::reference _Charref;
	typedef typename _Alty::template rebind<item_t>::other::reference _Vref;

	static _Charref 
      color( _Ndptr _Pnode )
		   {//return reference to color in node
		   return ((_Charref)(*_Pnode).Color);
		   }

	static _Charref 
      isnil( _Ndptr _Pnode )
		   {//return reference to nil flag in node
		   return ((_Charref)(*_Pnode).Isnil);
		   }

	static _Keyref 
      _key( _Ndptr _Pnode )
		   {//return reference to key in node
		   return (Base_t::_Kfn(value(_Pnode)));
		   }

	static _Nodepref 
      left( _Ndptr _Pnode )
		   {//return reference to left pointer in node
		   return ((_Nodepref)(*_Pnode).Left);
		   }

	static _Nodepref 
      parent( _Ndptr _Pnode )
		   {//return reference to parent pointer in node
		   return ((_Nodepref)(*_Pnode).Parent);
		   }

	static _Nodepref 
      right( _Ndptr _Pnode )
		   {//return reference to right pointer in node
		   return ((_Nodepref)(*_Pnode).Right);
		   }

	static _Vref 
      value( _Ndptr _Pnode )
		   {//return reference to value in node
		   return ((_Vref)(*_Pnode).Value);
		   }

public:
	typedef typename _Alty::diff_t _Dift;
	typedef typename _Alty::template rebind<item_t>::other::pointer _Tptr;
	typedef typename _Alty::template rebind<item_t>::other::const_pointer _Ctptr;
	typedef typename _Alty::template rebind<item_t>::other::reference _Reft;
	typedef typename _Alty::template rebind<item_t>::other::const_reference const_reference;

	typedef _Dift  diff_t;
	typedef _Tptr  pointer;
	typedef _Ctptr const_pointer;
	typedef _Reft  reference;

			 class Const_iterator;
	friend class Const_iterator;

	class Const_iterator : public Bidit<item_t,_Dift,_Ctptr,const_reference>
		{//iterator for nonmutable Tree
	public:
		friend class Tree<_Traits>;
		typedef Bidirectional_iterator_tag iterator_category;
		typedef _Dift diff_t;
		typedef _Ctptr pointer;
		typedef const_reference reference;

		Const_iterator() : Cursor(0)
			{//construct with null node pointer
			}

		Const_iterator( _Ndptr _Pnode ) : Cursor(_Pnode)
			{//construct with node pointer _Pnode
			}
 
		const_reference 
         operator*() const
			   {//return designated value
			   return (value(Cursor));
			   }

		_Ctptr 
         operator->() const
			   {//return pointer to class object
			   return (&**this);
			   }

		Const_iterator& 
         operator++()
			   {//preincrement
			   inc();
			   return (*this);
			   }

		Const_iterator 
         operator++(int)
			   {//postincrement
			   Const_iterator _Tmp = *this;
			   ++*this;
			   return (_Tmp);
			   }

		Const_iterator& 
         operator--()
			   {//predecrement
			   dec();
			   return (*this);
			   }

		Const_iterator 
         operator--(int)
			   {//postdecrement
			   Const_iterator _Tmp = *this;
			   --*this;
			   return (_Tmp);
			   }

	private:
		void_t 
         dec()
			   {//move to node with next smaller value
  			   if (isnil( Cursor ))
				   {//largest of right subtree
   			   if (isnil( right( Cursor )))
					   return;
				   }
			   else 
			   if(!isnil( left( Cursor )))
				   {//largest of left subtree
				   Cursor = rmax( left( Cursor ));	
				   }
			   else
				   {//climb looking for left subtree
				   _Ndptr 
                  _Pnode;
               //parent while left subtree
				   while(!isnil(_Pnode = parent( Cursor )) && Cursor == left( _Pnode ))
					   Cursor = _Pnode;
				   if (isnil( Cursor ))
					   ; //begin() shouldn't be decremented, don't move
				   else
					   Cursor = _Pnode;	//parent if not head
				   }
			   }

		void_t 
         inc()
			   {//move to node with next larger value
			   if (isnil( Cursor ))
               ;//end() shouldn't be incremented, don't move
			   else
			   if(!isnil( right( Cursor )))
				   {//smallest of right subtree
				   Cursor = lmin( right( Cursor ));
				   }
			   else
				   {//climb looking for right subtree
				   _Ndptr 
                  _Pnode;
               //parent while right subtree
				   while(!isnil(_Pnode = parent( Cursor )) && Cursor == right( _Pnode ))
					   Cursor = _Pnode;
				   //parent, head if end()
					   Cursor = _Pnode;
				   }
			   }
   public:
		bool_t 
         operator==( const Const_iterator &_Right ) const
			   {//test for iterator equality
  			   return (Cursor == _Right.Cursor);
			   }

		bool_t 
         operator!=( const Const_iterator &_Right ) const
			   {//test for iterator inequality
			   return (!(*this == _Right));
			   }

		_Ndptr 
         node() const
			   {//return node pointer
			   return (Cursor);
			   }

	private:
		_Ndptr 
         Cursor; //pointer to node

		};//Const_iterator

			 class Iterator;
	friend class Iterator;

	class Iterator	: public Const_iterator
		{//iterator for mutable Tree
	public:
		typedef Bidirectional_iterator_tag iterator_category;
		typedef _Dift  diff_t;
		typedef _ITptr pointer;
		typedef _IReft reference;

		Iterator()
			{//construct with null node pointer
			}

		Iterator( _Ndptr _Pnode ) : Const_iterator(_Pnode)
			{//construct with node pointer _Pnode
			}

		reference 
         operator*() const
			   {//return designated value
			   return ((reference)**(Const_iterator *)this);
			   }

		pointer 
         operator->() const
			   {//return pointer to class object
			   return (&**this);
			   }

		Iterator& 
         operator++()
			   {//preincrement
			   ++(*(Const_iterator *)this);
			   return (*this);
			   }

		Iterator 
         operator++(int)
			   {//postincrement
			   Iterator _Tmp = *this;
			   ++*this;
			   return (_Tmp);
			   }

		Iterator& 
         operator--()
			   {//predecrement
			   --(*(Const_iterator *)this);
			   return (*this);
			   }

		Iterator 
         operator--(int)
			   {//postdecrement
			   Iterator _Tmp = *this;
			   --*this;
			   return (_Tmp);
			   }
		};

   typedef Const_iterator const_iterator;
   typedef Iterator iterator;

   typedef Reverse_iterator<const_iterator> const_reverse_iterator;
	typedef Reverse_iterator<iterator> reverse_iterator;

	typedef Pair<iterator,bool_t> _Pairib;
	typedef Pair<iterator,iterator> _Pairii;
	typedef Pair<const_iterator,const_iterator> _Paircc;

	explicit Tree( const key_compare &_Parg,const _Alty &_Al ) : Base_t(_Parg,_Al)
		{//construct empty tree
		init();
		}

	Tree( const item_t *_First,const item_t *_Last,const key_compare &_Parg,const _Alty &_Al ) : Base_t(_Parg,_Al)
		{//construct tree from [_First, _Last) array
		init();
		try
			{
			insert( _First,_Last );
			}
		catch(...)
			{
			tidy();
			throw;
			}
		}

	Tree( const Self_t &_Right ) : Base_t(_Right.key_comp(),_Right.get_allocator())
		{//construct tree by copying _Right
		init();
		try
			{
			_copy( _Right );
			}
		catch(...)
			{
			tidy();
			throw;
			}
		}

	~Tree() _NOTHROW
		{//destroy tree
		tidy();
		}

	Self_t& 
      operator=( const Self_t &_Right )
		   {//replace contents from _Right
		   if (this != &_Right)
			   {//worth doing
			   erase( begin(),end());
			   this->Comp = _Right.Comp;
			   _copy( _Right );
			   }
		   return (*this);
		   }

	iterator 
      begin() _NOTHROW
		   {//return iterator for beginning of mutable sequence
		   return (iterator( lmost()));
		   }

	const_iterator 
      begin() const _NOTHROW
		   {//return iterator for beginning of nonmutable sequence
		   return (const_iterator(lmost()));
		   }

	iterator 
      end() _NOTHROW
		   {//return iterator for end of mutable sequence
		   return (iterator(Head));
		   }

	const_iterator 
      end() const _NOTHROW
		   {//return iterator for end of nonmutable sequence
		   return (const_iterator(Head));
		   }

	reverse_iterator 
      rbegin() _NOTHROW
		   {//return iterator for beginning of reversed mutable sequence
		   return (reverse_iterator(end()));
		   }

	const_reverse_iterator
      rbegin() const _NOTHROW
		   {//return iterator for beginning of reversed nonmutable sequence
		   return (const_reverse_iterator(end()));
		   }

	reverse_iterator 
      rend() _NOTHROW
		   {//return iterator for end of reversed mutable sequence
		   return (reverse_iterator(begin()));
		   }

	const_reverse_iterator 
      rend() const _NOTHROW
		   {//return iterator for end of reversed nonmutable sequence
		   return (const_reverse_iterator(begin()));
		   }

	size_t 
      size() const _NOTHROW
		   {//return length of sequence
		   return (Size);
		   }

	size_t 
      max_size() const _NOTHROW
		   {//return maximum possible length of sequence
		   return (this->_Alval.max_size());
		   }

	bool_t 
      empty() const _NOTHROW
		   {//return true only if sequence is empty
		   return (size() == 0);
		   }

	_Alty 
      get_allocator() const _NOTHROW
		   {//return allocator object for values
		   return (this->_Alval);
		   }

	key_compare 
      key_comp() const
		   {//return object for comparing keys
		   return (this->Comp);
		   }

   value_compare//value_compare 
      value_comp() const
		   {//return object for comparing values
		   return (value_compare(key_comp()));
		   }

	_Pairib 
      insert( const item_t &_Val )
		   {//try to insert node with value _Val
		   _Ndptr 
            _Trynode   = root(),
				_Wherenode = Head;	
		   bool_t
            _Addleft	= true;	//add to left of head if tree empty

		   while (!isnil( _Trynode ))
			   {//look for leaf to insert before (_Addleft) or after
			   _Wherenode = _Trynode;
			   _Addleft = this->Comp( this->_Kfn( _Val ),_key( _Trynode ));
			   _Trynode = _Addleft ? left( _Trynode ) : right( _Trynode );
			   }

		   if (bool_t _Mfl = this->MULTIF)
			   return (_Pairib( _insert( _Addleft,_Wherenode,_Val ),true ));
		   else
			   {//insert only if unique
			   iterator _Where = iterator( _Wherenode );

			   if(!_Addleft)
				   ;			 //need to test if insert after is okay
			   else 
			   if (_Where == begin())
				   return (_Pairib( _insert( true,_Wherenode,_Val),true ));
			   else
				   --_Where; //need to test if insert before is okay

			   if (this->Comp( _key( _Where.node()),this->_Kfn(_Val)))
				   return (_Pairib( _insert( _Addleft,_Wherenode,_Val ),true ));
			   else
				   return (_Pairib( _Where,false ));
			   }
		   }

	iterator 
      insert( iterator _Where,const item_t &_Val )
		   {//try to insert node with value _Val using _Where as a hint
  		   iterator 
            _Next;

		   if (size() == 0)
			   return (_insert( true,Head,_Val ));
		   else 
		   if (bool_t _Mfl = this->MULTIF)
			   {//insert even if duplicate
			   if (_Where == begin())
				   {//at beginning if before first element
				   if (!this->Comp( _key( _Where.node()),this->_Kfn( _Val )))
					   return (_insert( true,_Where.node(),_Val ));
				   }
			   else 
			   if (_Where == end())
				   {//at end if after last element
				   if (!this->Comp( this->_Kfn( _Val ),_key( rmost())))
					   return (_insert( false,rmost(),_Val ));
				   }
			   else 
			   if(!this->Comp( _key( _Where.node()),this->_Kfn( _Val )) && 
				   !this->Comp( this->_Kfn( _Val ),_key((--(_Next = _Where)).node())))
				   {//before _Where
				   if (isnil( right( _Next.node())))
					   return (_insert( false,_Next.node(),_Val ));
				   else
					   return (_insert( true,_Where.node(),_Val ));
				   }
			   else 
			   if(!this->Comp( this->_Kfn( _Val ),_key( _Where.node()))	&& (++(_Next = _Where) == end() || 
				   !this->Comp( _key( _Next.node()),this->_Kfn( _Val ))))
				   {//after _Where
				   if (isnil( right( _Where.node())))
					   return (_insert( false,_Where.node(),_Val ));
				   else
					   return (_insert( true,_Next.node(),_Val ));
				   }
			   }
		   else
			   {//insert only if unique
			   if (_Where == begin())
				   {//at beginning if before first element
				   if (this->Comp( this->_Kfn( _Val ),_key( _Where.node())))
					   return (_insert( true,_Where.node(),_Val ));
				   }
			   else if (_Where == end())
				   {//at end if after last element
				   if (this->Comp( _key( rmost()),this->_Kfn( _Val )))
					   return (_insert( false,rmost(),_Val ));
				   }
			   else 
			   if(this->Comp( this->_Kfn( _Val ),_key( _Where.node()))	&& 
				   this->Comp( _key((--(_Next = _Where)).node()),this->_Kfn( _Val )))
				   {//before _Where
				   if (isnil( right( _Next.node())))
					   return (_insert( false,_Next.node(),_Val ));
				   else
					   return (_insert( true,_Where.node(),_Val ));
				   }
			   else 
			   if(this->Comp( _key( _Where.node()),this->_Kfn( _Val )) && (++(_Next = _Where) == end() || 
				   this->Comp( this->_Kfn( _Val ),_key( _Next.node()))))
				   {//after _Where
				   if (isnil( right( _Where.node())))
					   return (_insert( false,_Where.node(),_Val ));
				   else
					   return (_insert( true,_Next.node(),_Val ));
				   }
			   }
		   //try insert if all else fails
		   return (insert( _Val ).first); 
		   }

	template<class _Iter> void_t 
      insert( _Iter _First,_Iter _Last )
		   {//insert [_First,_Last) one at a time
		   for (; _First != _Last; ++_First)
			   insert(*_First );
		   }

	iterator 
      erase( iterator _Where )
		   {//erase element at _Where
		   if (isnil(_Where.node()))
			   _xran();

		   _Ndptr _Erasednode = _Where.node();
		   ++_Where;	//successor for return

		   _Ndptr _Fixnode,
				    _Fixnodeparent,
				    _Pnode = _Erasednode;

		   if (isnil( left( _Pnode )))
			   _Fixnode = right( _Pnode ); 
		   else 
		   if (isnil( right( _Pnode )))
			   _Fixnode = left( _Pnode );
		   else
			   {//two subtrees, must lift successor node to replace erased
			   _Pnode = _Where.node();
			   _Fixnode = right( _Pnode );
			   }

		   if (_Pnode == _Erasednode)
			   {//at most one subtree, relink it
			   _Fixnodeparent = parent( _Erasednode );
			   if (!isnil( _Fixnode ))
				   parent( _Fixnode ) = _Fixnodeparent; //link up

			   if (root() == _Erasednode)
				   root() = _Fixnode; //link down from root
			   else 
			   if (left( _Fixnodeparent ) == _Erasednode)
				   left( _Fixnodeparent ) = _Fixnode; //link down to left
			   else
				   right( _Fixnodeparent ) = _Fixnode;	//link down to right

			   if(lmost() == _Erasednode)
				   lmost() = isnil( _Fixnode ) ? _Fixnodeparent	: lmin(_Fixnode);

			   if(rmost() == _Erasednode)
				   rmost() = isnil(_Fixnode)	? _Fixnodeparent : rmax(_Fixnode);
			   }
		   else
			   {//erased has two subtrees, _Pnode is successor to erased
			   parent( left( _Erasednode )) = _Pnode;	// link left up
			   left( _Pnode ) = left( _Erasednode );	// link successor down

			   if (_Pnode == right( _Erasednode ))
				   _Fixnodeparent = _Pnode;
			   else
				   {//successor further down, link in place of erased
				   _Fixnodeparent = parent( _Pnode );
				   if (!isnil( _Fixnode ))
					   parent( _Fixnode ) = _Fixnodeparent;	//link fix up

				   left( _Fixnodeparent ) = _Fixnode;			//link fix down
				   right( _Pnode ) = right( _Erasednode );	//link successor down
				   parent( right( _Erasednode )) = _Pnode;	//link right up
				   }

			   if (root() == _Erasednode)
				   root() = _Pnode;	//link down from root
			   else 
			   if (left( parent( _Erasednode )) == _Erasednode)
				   left( parent( _Erasednode )) = _Pnode;	//link down to left
			   else
				   right( parent( _Erasednode)) = _Pnode;	//link down to right

			   parent( _Pnode ) = parent( _Erasednode );	// link successor up
			   ESK::swap( color( _Pnode ),color( _Erasednode ));
			   }

		   if (color( _Erasednode ) == _Black)
			   {//erasing black link, must recolor/rebalance tree
			   for (; _Fixnode != root() && color( _Fixnode ) == _Black; _Fixnodeparent = parent( _Fixnode ))
				   if (_Fixnode == left(_Fixnodeparent))
					   {//fixup left subtree
					   _Pnode = right( _Fixnodeparent );
					   if (color( _Pnode ) == _Red)
						   {//rotate red up from right subtree
						   color( _Pnode ) = _Black;
						   color( _Fixnodeparent ) = _Red;
						   _lrotate( _Fixnodeparent );
						   _Pnode = right( _Fixnodeparent );
						   }

					   if (isnil( _Pnode ))
						   _Fixnode = _Fixnodeparent;	//shouldn't happen
					   else 
					   if (color( left( _Pnode )) == _Black && color( right( _Pnode )) == _Black)
						   {//redden right subtree with black children
						   color( _Pnode ) = _Red;
						   _Fixnode = _Fixnodeparent;
						   }
					   else
						   {//must rearrange right subtree
						   if (color( right( _Pnode )) == _Black)
							   {//rotate red up from left sub-subtree
							   color( left( _Pnode )) = _Black;
							   color( _Pnode ) = _Red;
							   _rrotate( _Pnode );
							   _Pnode = right( _Fixnodeparent );
							   }

						   color( _Pnode ) = color( _Fixnodeparent );
						   color( _Fixnodeparent ) = _Black;
						   color( right( _Pnode )) = _Black;
						   _lrotate( _Fixnodeparent );
						   break; //tree rebalanced
						   }
					   }
				   else
					   {//fixup right subtree
					   _Pnode = left( _Fixnodeparent );
					   if (color( _Pnode ) == _Red)
						   {//rotate red up from left subtree
						   color( _Pnode ) = _Black;
						   color( _Fixnodeparent ) = _Red;
						   _rrotate( _Fixnodeparent );
						   _Pnode = left( _Fixnodeparent );
						   }
					   if (isnil(_Pnode))
						   _Fixnode = _Fixnodeparent;	//shouldn't happen
					   else 
					   if (color( right( _Pnode )) == _Black && color( left( _Pnode )) == _Black)
						   {//redden left subtree with black children
						   color( _Pnode ) = _Red;
						   _Fixnode = _Fixnodeparent;
						   }
					   else
						   {//must rearrange left subtree
						   if (color( left( _Pnode )) == _Black)
							   {//rotate red up from right sub-subtree
							   color( right( _Pnode )) = _Black;
							   color( _Pnode ) = _Red;
							   _lrotate( _Pnode );
							   _Pnode = left( _Fixnodeparent );
							   }

						   color( _Pnode ) = color( _Fixnodeparent );
						   color( _Fixnodeparent ) = _Black;
						   color( left( _Pnode )) = _Black;
						   _rrotate( _Fixnodeparent );
						   break; //tree rebalanced
						   }
					   }
			   //ensure stopping node is black
			   color( _Fixnode ) = _Black;
			   }

		   this->_Alnod.destroy( _Erasednode );
		   this->_Alnod.deallocate( _Erasednode,1 );

		   if (0 < Size)
				   --Size;

		   return (_Where);
		   }

	iterator 
      erase( iterator _First,iterator _Last )
		   {//erase [_First, _Last)
		   if (_First == begin() && _Last == end())
			   {//erase all
			   clear();
			   return (begin());
			   }
		   else
			   {//partial erase, one at a time
			   while (_First != _Last)
				   erase(_First++);
			   return (_First);
			   }
		   }

	size_t 
      erase( const key_type &_Keyval )
		   {//erase and count all that match _Keyval
		   _Pairii _Where = equal_range( _Keyval );
		   size_t  _Num = 0;
		   _distance( _Where.first,_Where.second,_Num );
		   erase( _Where.first,_Where.second );
		   return (_Num);
		   }

	void_t 
      erase( const key_type *_First,const key_type *_Last )
		   {//erase all that match array of keys [_First, _Last)
		   while (_First != _Last)
			   erase(*_First++);
		   }

	void_t 
      clear() _NOTHROW
		   {//erase all
		   _erase( root());
		   root()  = Head; 
		   lmost() = Head; 
		   rmost() = Head; Size = 0;
		   }

	iterator 
      find( const key_type &_Keyval )
		   {//find an element in mutable sequence that matches _Keyval
		   iterator _Where =  lower_bound( _Keyval );
		   return  (_Where == end() || this->Comp( _Keyval,_key( _Where.node())) ? end() : _Where);
		   }

	const_iterator 
      find( const key_type &_Keyval ) const
		   {//find an element in nonmutable sequence that matches _Keyval
		   const_iterator _Where = lower_bound( _Keyval );
		   return (_Where == end() || this->Comp( _Keyval,_key( _Where.node())) ? end() : _Where);
		   }

	size_t 
      count( const key_type &_Keyval ) const
		   {//count all elements that match _Keyval
		   _Paircc _Ans = equal_range( _Keyval );
		   size_t  _Num = 0;
		   _distance( _Ans.first,_Ans.second,_Num );
		   return (_Num);
		   }

	iterator 
      lower_bound( const key_type &_Keyval )
		   {//find leftmost node not less than _Keyval in mutable tree
		   return (iterator( lbound( _Keyval )));
		   }

	const_iterator 
      lower_bound( const key_type &_Keyval ) const
		   {//find leftmost node not less than _Keyval in nonmutable tree
		   return (const_iterator( lbound( _Keyval )));
		   }

	iterator 
      upper_bound( const key_type &_Keyval )
		   {//find leftmost node greater than _Keyval in mutable tree
		   return (iterator( ubound( _Keyval )));
		   }

	const_iterator 
      upper_bound( const key_type &_Keyval ) const
		   {//find leftmost node greater than _Keyval in nonmutable tree
		   return (const_iterator( ubound( _Keyval )));
		   }

	_Pairii 
      equal_range( const key_type &_Keyval )
		   {//find range equivalent to _Keyval in mutable tree
		   return (_Pairii( lower_bound( _Keyval ),upper_bound( _Keyval )));
		   }

	_Paircc 
      equal_range( const key_type &_Keyval ) const
		   {//find range equivalent to _Keyval in nonmutable tree
		   return (_Paircc( lower_bound( _Keyval ),upper_bound( _Keyval )));
		   }

	void_t 
      swap( Self_t &_Right )
		   {//exchange contents with _Right
		   if (get_allocator() == _Right.get_allocator())
			   {//same allocator, swap control information
			   swap( this->Comp,_Right.Comp );
			   swap( Head,_Right.Head );
			   swap( Size,_Right.Size );
			   }
		   else
			   {//different allocator, do multiple assigns
			   Self_t _Tmp = *this; *this = _Right, _Right = _Tmp;
			   }
		   }

public:
	void_t 
      _copy( const Self_t &_Right )
		   {//copy entire tree from _Right
		   root() = _copy( _Right.root(),Head );
		   Size   =        _Right.size();

		   if (!isnil(root()))
			   {//nonempty tree, look for new smallest and largest
			   lmost() = lmin( root());
			   rmost() = rmax( root());
			   }
		   else
			   lmost() = Head, 
			   rmost() = Head; //empty tree
		   }

	_Ndptr 
      _copy( _Ndptr _Rootnode,_Ndptr _Wherenode )
		   {//copy entire subtree, recursively
		   _Ndptr 
            _Newroot = Head;

		   if (!isnil(_Rootnode))
			   {//copy a node, then any subtrees
			   _Ndptr 
               _Pnode = buy_node( Head,_Wherenode,Head,value( _Rootnode ),color( _Rootnode ));

			   if (isnil(_Newroot))
				   _Newroot = _Pnode; //memorize new root

			   try
				   {
				   left ( _Pnode ) = _copy( left ( _Rootnode ),_Pnode );
				   right( _Pnode ) = _copy( right( _Rootnode ),_Pnode );
				   }
			   catch(...)
				   {//subtree copy failed, bail out
				   _erase( _Newroot ); 
				   throw;
				   }
			   }
		   //newly constructed tree
		   return (_Newroot);
		   }

	void_t 
      _erase( _Ndptr _Rootnode )
		   {//free entire subtree, recursively
		   for (_Ndptr _Pnode = _Rootnode; !isnil( _Pnode ); _Rootnode = _Pnode)
			   {//free subtrees, then node
			   _erase( right( _Pnode ));
			   _Pnode = left( _Pnode );
			   this->_Alnod.destroy( _Rootnode );
			   this->_Alnod.deallocate( _Rootnode,1 );
			   }
		   }

	void_t 
      init()
		   {//create head/nil node and make tree empty
		   Head = buy_node();
		   isnil( Head ) = true;
		   root()  = Head;
		   lmost() = Head, 
		   rmost() = Head;
                   Size = 0;
		   }

	iterator 
      _insert( bool_t _Addleft,_Ndptr _Wherenode,const item_t &_Val )
		   {//add node with value next to _Wherenode, to left if _Addnode
		   if (max_size() - 1 <= Size)
			   _xlen();

		   _Ndptr 
            _Newnode = buy_node( Head,_Wherenode,Head,_Val,_Red );
				++Size;

		   if (_Wherenode == Head)
			   {//first node in tree, just set head values
			   root()  = _Newnode;
			   lmost() = _Newnode, 
			   rmost() = _Newnode;
			   }
		   else 
		   if (_Addleft)
			   {//add to left of _Wherenode
			   left( _Wherenode ) = _Newnode;
			   if ( _Wherenode == lmost())
				   lmost() = _Newnode;
			   }
		   else
			   {//add to right of _Wherenode
			   right( _Wherenode ) = _Newnode;
			   if (_Wherenode == rmost())
				   rmost() = _Newnode;
			   }

		   for (_Ndptr _Pnode = _Newnode; color( parent( _Pnode )) == _Red;)
			   if (parent( _Pnode ) == left( parent( parent( _Pnode ))))
				   {//fixup red-red in left subtree
				   _Wherenode = right( parent( parent( _Pnode )));
				   if (color( _Wherenode ) == _Red)
					   {//parent has two red children, blacken both
					   color( parent( _Pnode )) = _Black;
					   color( _Wherenode ) = _Black;
					   color( parent( parent( _Pnode ))) = _Red;
					   _Pnode = parent( parent( _Pnode ));
					   }
				   else
					   {//parent has red and black children
					   if (_Pnode == right( parent( _Pnode )))
						   {//rotate right child to left
						   _Pnode = parent( _Pnode );
						   _lrotate( _Pnode );
						   }
					   color( parent( _Pnode )) = _Black; //propagate red up
					   color( parent( parent( _Pnode ))) = _Red;
					   _rrotate( parent( parent( _Pnode )));
					   }
				   }
			   else
				   {//fixup red-red in right subtree
				   _Wherenode = left( parent( parent( _Pnode )));
				   if (color( _Wherenode ) == _Red)
					   {//parent has two red children, blacken both
					   color( parent( _Pnode )) = _Black;
					   color( _Wherenode ) = _Black;
					   color( parent( parent( _Pnode ))) = _Red;
					   _Pnode = parent( parent( _Pnode ));
					   }
				   else
					   {//parent has red and black children
					   if (_Pnode == left( parent( _Pnode )))
						   {//rotate left child to right
						   _Pnode = parent( _Pnode );
						   _rrotate( _Pnode );
						   }
					   color( parent( _Pnode )) = _Black;	// propagate red up
					   color( parent( parent( _Pnode ))) = _Red;
					   _lrotate( parent( parent( _Pnode )));
					   }
				   }
		   // root is always black
		   color( root()) = _Black; 
		   return (iterator( _Newnode ));
		   }

	_Ndptr 
      lbound( const key_type &_Keyval ) const
		   {//find leftmost node not less than _Keyval
		   _Ndptr 
            _Pnode = root(),
		      _Wherenode = Head;

		   while (!isnil( _Pnode ))
			   if (this->Comp( _key( _Pnode ),_Keyval ))
				   _Pnode = right(_Pnode ); //descend right subtree
			   else
				   {//remember it
				   _Wherenode =	_Pnode;
				   _Pnode = left( _Pnode ); //descend left subtree
				   }
		   //best remembered candidate
		   return (_Wherenode);	
		   }

	_Ndptr& 
      lmost() const
		   {//leftmost node in nonmutable tree
		   return (left( Head ));
		   }

	void_t 
      _lrotate( _Ndptr _Wherenode )
		   {//promote right node to root of subtree
		   _Ndptr 
            _Pnode = right( _Wherenode );
		               right( _Wherenode ) = left( _Pnode );

		   if(!isnil( left( _Pnode )))
			   parent( left( _Pnode )) =         _Wherenode;
		      parent(       _Pnode )  = parent( _Wherenode );

		   if(root() == _Wherenode)
			   root() =  _Pnode;
		   else 
		   if(left( parent( _Wherenode )) == _Wherenode)
			   left( parent( _Wherenode )) =  _Pnode;
		   else
			   right(parent( _Wherenode )) =  _Pnode;

		   left( _Pnode ) = _Wherenode;
		            parent( _Wherenode ) = _Pnode;
		   }

	static _Ndptr 
      rmax( _Ndptr _Pnode )
		   {//return rightmost node in subtree at _Pnode
		   while ( !isnil( right( _Pnode )))
			       _Pnode = right( _Pnode );
		   return _Pnode;
		   }

	static _Ndptr 
      lmin( _Ndptr _Pnode)
		   {//return leftmost node in subtree at _Pnode
		   while ( !isnil( left( _Pnode )))
			       _Pnode = left( _Pnode );
		   return _Pnode;
		   }

	_Ndptr& 
      rmost() const
		   {//return rightmost node in nonmutable tree
		   return right( Head );
		   }

	_Ndptr& 
      root() const
		   {//return root of nonmutable tree
		   return parent( Head );
		   }

	void_t 
      _rrotate( _Ndptr _Wherenode )
		   {//promote left node to root of subtree
		   _Ndptr 
            _Pnode = left( _Wherenode );
		               left( _Wherenode ) = right( _Pnode );

		   if(!isnil( right( _Pnode )))
			   parent( right( _Pnode )) =         _Wherenode;
		      parent(        _Pnode )  = parent( _Wherenode );

		   if(root() == _Wherenode)
			   root() = _Pnode;
		   else 
		   if(right( parent( _Wherenode )) == _Wherenode)
			   right( parent( _Wherenode )) =  _Pnode;
		   else
			   left(  parent( _Wherenode )) =  _Pnode;

		   right( _Pnode ) = _Wherenode;
		             parent( _Wherenode )  =  _Pnode;
		   }

	_Ndptr 
      ubound( const key_type &_Keyval ) const
		   {//find leftmost node greater than _Keyval
		   _Ndptr _Pnode = root();
		   _Ndptr _Wherenode = Head;

		   while (!isnil( _Pnode ))
			   if (this->Comp( _Keyval,_key(_Pnode)))
				   {//_Pnode greater than _Keyval, remember it
				   _Wherenode =	_Pnode;
				   _Pnode = left( _Pnode ); //descend left subtree
				   }
			   else
				   _Pnode = right(_Pnode ); //descend right subtree
		   //best remembered candidate
		   return (_Wherenode);	
		   }

 	_Ndptr 
      buy_node()
		   {//allocate a head/nil node
		   _Ndptr 
            _Wherenode = this->_Alnod.allocate(1);
		   iint_t _Linkcnt = 0;

		   try
			   {
			   this->_Alptr.construct(  &left( _Wherenode ),0 );
			   ++_Linkcnt;
			   this->_Alptr.construct(&parent( _Wherenode ),0 );
			   ++_Linkcnt;
			   this->_Alptr.construct( &right( _Wherenode ),0 );
			   }
		   catch(...)
			   {
			   if (1 < _Linkcnt)
				   this->_Alptr.destroy(&parent(_Wherenode ));
			   if (0 < _Linkcnt)
				   this->_Alptr.destroy(  &left(_Wherenode ));
			   this->_Alnod.deallocate( _Wherenode,1 );
			   throw;
			   }
		   color( _Wherenode ) = _Black;
		   isnil( _Wherenode ) = false;
		   return(_Wherenode );
		   }

	_Ndptr 
      buy_node( _Ndptr _Larg,_Ndptr _Parg,_Ndptr _Rarg,const item_t &_Val,char_t _Carg )
		   {//allocate a node with pointers, value, and color
		   _Ndptr _Wherenode = this->_Alnod.allocate(1);
		   try
			   {
			   new (_Wherenode) Node( _Larg,_Parg,_Rarg,_Val,_Carg );
			   }
		   catch(...)
			   {
			   this->_Alnod.deallocate( _Wherenode,1 );
			   throw;
			   }
		   return (_Wherenode);
		   }

	void_t 
      tidy()
		   {//free all storage
         if (Head != Null)
            {
		      erase( begin(),end());
		      this->_Alptr.destroy(  &left( Head ));
		      this->_Alptr.destroy(&parent( Head ));
		      this->_Alptr.destroy( &right( Head ));
		      this->_Alnod.deallocate(      Head,1); 
            Head = 0; 
            Size = 0;
            }
		   }

	static void_t 
      _xran()
		   {//report an out of range error
		   throw Out_of_range( "invalid map/set<T> iterator" );
		   }

	static void_t 
      _xlen()
		   {//report a length error
		   throw Length_error( "map/set<T> too long" );
		   }

	static void_t 
      _Xinvarg()
		   {//report an invalid argument error
		   throw Invalid_argument( "invalid map/set<T> argument" );
		   }

	_Ndptr	 
      Head; //pointer to head node
	size_t 
      Size; //number of elements
	};

//Tree implements a performant swap
template <class _Traits>
class Move_operation_category<Tree<_Traits> >
	{
public:
	typedef Swap_move_tag _Move_cat;
	};

template<class _Traits> inline bool_t
   operator==( const Tree<_Traits> &_Left,const Tree<_Traits> &_Right )
	   {//test for Tree equality
	   return (_Left.size() == _Right.size() && equal( _Left.begin(),_Left.end(),_Right.begin()));
	   }

template<class _Traits> inline bool_t
   operator!=( const Tree<_Traits> &_Left,const Tree<_Traits> &_Right )
	   {//test for Tree inequality
	   return (!(_Left == _Right));
	   }

template<class _Traits> inline bool_t
   operator<( const Tree<_Traits> &_Left,const Tree<_Traits> &_Right )
	   {//test if _Less < _Right for Trees
	   return (lexicographical_compare( _Left.begin(),_Left.end(),_Right.begin(),_Right.end()));
	   }

template<class _Traits> inline bool_t 
   operator>( const Tree<_Traits> &_Left,const Tree<_Traits> &_Right)
	   {//test if _Less > _Right for Trees
	   return (_Right < _Left);
	   }

template<class _Traits> inline bool_t
   operator<=( const Tree<_Traits> &_Left,const Tree<_Traits> &_Right )
	   {//test if _Less <= _Right for Trees
	   return (!(_Right < _Left));
	   }

template<class _Traits> inline bool_t
   operator>=( const Tree<_Traits> &_Left,const Tree<_Traits> &_Right)
	   {//test if _Less >= _Right for Trees
	   return (!(_Left < _Right));
	   }

_ESK_END
#pragma pack(pop)
#endif//BITREE_H
