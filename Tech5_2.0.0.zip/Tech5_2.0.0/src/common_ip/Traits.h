#pragma		once
#ifndef		TRAITS_H
#define		TRAITS_H

//	Use project header
#include		"Eskdef.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
     Templates to add const
**************************************/
template<class _Ty>
struct Add_const
	{//add top level const qualifier
	typedef const _Ty type;
	};

template<class _Ty>
struct Add_const<_Ty&>
	{//add top level const qualifier
	typedef _Ty& type;
	};

/**************************************
     Templates to remove reference
**************************************/
template<class _Ty>
struct Remove_reference
	{//remove reference
	typedef _Ty type;
	};

template<class _Ty>
struct Remove_reference<_Ty&>
	{//remove reference
	typedef _Ty type;
	};

template<class _Ty>
struct Remove_rvalue_reference
	{//remove rvalue reference
	typedef _Ty type;
	};

/**************************************
      Templates to add reference
**************************************/
template<class _Ty>
struct Add_reference
	{//add reference
	typedef typename Remove_reference<_Ty>::type& type;
	};

template<>
struct Add_reference<void_t>
	{//add reference
	typedef void_t type;
	};

template<>
struct Add_reference<const void_t>
	{//add reference
	typedef const void_t type;
	};

template<class _Ty>
struct Add_lvalue_reference
	{//add lvalue reference
	typedef typename Add_reference<_Ty>::type type;
	};

template<class _Ty>
	struct Add_rvalue_reference
	{//add rvalue reference
	typedef typename Remove_reference<_Ty>::type type;
	};

template<class _Ty>
struct Add_rvalue_reference<_Ty&>
	{//add rvalue reference to reference
	typedef _Ty& type;
	};

template<>
struct Add_rvalue_reference<void_t>
	{//add reference
	typedef void_t type;
	};

template<>
struct Add_rvalue_reference<const void_t>
	{//add reference
	typedef const void_t type;
	};

/**************************************
    Template class remove pointer
**************************************/
template<class _Ty>
struct Remove_pointer
	{//remove pointer
	typedef _Ty type;
	};

template<class _Ty>
struct Remove_pointer<_Ty *>
	{//remove pointer
	typedef _Ty type;
	};

template<class _Ty>
struct Remove_pointer<_Ty *const>
	{//remove pointer
	typedef _Ty type;
	};

/**************************************
    Template class add pointer
**************************************/
template<class _Ty>
struct Add_pointer
	{//add pointer
	typedef typename Remove_reference<_Ty>::type *type;
	};

/**************************************
	  Templates for type promotion
**************************************/
template<bool,typename,typename>
struct Typesize;

template<typename _Ty,typename _Tp>
struct Typesize<true,_Ty,_Tp>
	{//promotion if true
	typedef _Ty type;
	};

template<typename _Ty,typename _Tp>
struct Typesize<false,_Ty,_Tp>
	{//promotion if false
	typedef _Tp type;
	};

template<typename _Ty,typename _Tp>
struct Promotion
	{//the promotion
	typedef typename Typesize<(sizeof(_Ty) > sizeof(_Tp)),_Ty,_Tp>::type type;
	};

_ESK_END
#pragma pack(pop)
#endif//TRAITS_H
