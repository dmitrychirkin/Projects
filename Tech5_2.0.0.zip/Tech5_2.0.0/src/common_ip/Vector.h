#pragma		once
#ifndef		VECTOR_H
#define		VECTOR_H

//	Header project file
#include		"Memory.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
		Target template class Vector
**************************************/
template<class _Ty,class _Ax = Allocator<_Ty> >                                           
class Vector;

template<class _Ty,class _Alloc>
class Vector_const_iterator : public Ranit<_Ty, typename _Alloc::diff_t,
																typename _Alloc::const_pointer, 
																typename _Alloc::const_reference>
	{//iterator for nonmutable Vector
public:
	typedef Vector_const_iterator<_Ty,_Alloc> Self_t;
	typedef Random_access_iterator_tag iterator_category;

   typedef typename _Alloc::item_t item_t;
	typedef typename _Alloc::diff_t diff_t;
   typedef typename _Alloc::pointer _Tptr;
	typedef typename _Alloc::const_pointer pointer;
	typedef typename _Alloc::const_reference reference;

	Vector_const_iterator() : Cursor()
		{//construct with null pointer
		}

	Vector_const_iterator( _Tptr _Ptr ) : Cursor(_Ptr)
		{//construct with pointer _Ptr
		}

	reference 
      operator*() const
		   {//return designated object
		   return (*Cursor);
		   }

	pointer 
      operator->() const
		   {//return pointer to class object
		   return (&**this);
		   }

	Self_t& 
      operator++()
		   {//preincrement
		   ++Cursor;
		   return (*this);
		   }

	Self_t 
      operator++(int)
		   {//postincrement
		   Self_t _Tmp = *this;
		   ++*this;
		   return (_Tmp);
		   }

	Self_t& 
      operator--()
		   {//predecrement
		   --Cursor;
		   return (*this);
		   }

	Self_t 
      operator--(int)
		   {//postdecrement
		   Self_t _Tmp = *this;
		   --*this;
		   return (_Tmp);
		   }

	Self_t&
      operator+=( diff_t _Off )
		   {//increment by integer
		   Cursor += _Off;
		   return (*this);
		   }

	Self_t 
      operator+( diff_t _Off ) const
		   {//return this + integer
		   Self_t _Tmp = *this;
		   return (_Tmp += _Off);
		   }

	Self_t&
      operator-=( diff_t _Off )
		   {//decrement by integer
		   return (*this += -_Off);
		   }

	Self_t
      operator-( diff_t _Off ) const
		   {//return this - integer
		   Self_t _Tmp = *this;
		   return (_Tmp -= _Off);
		   }

	diff_t
      operator-( const Self_t &_Right) const
		   {//return difference of iterators
         return (Cursor - _Right.Cursor);
		   }

	reference
      operator[]( diff_t _Off ) const
		   {//subscript
		   return (*(*this + _Off));
		   }

	bool_t
      operator==( const Self_t &_Right ) const
		   {//test for iterator equality
		   return (Cursor == _Right.Cursor);
		   }

	bool_t
      operator!=( const Self_t &_Right ) const
		   {//test for iterator inequality
		   return (!(*this == _Right));
		   }

	bool_t
      operator<( const Self_t &_Right ) const
		   {//test if this < _Right
		   return (Cursor < _Right.Cursor);
		   }

	bool_t
      operator>( const Self_t &_Right ) const
		   {//test if this > _Right
		   return (_Right < *this);
		   }

	bool_t
      operator<=( const Self_t &_Right ) const
		   {//test if this <= _Right
		   return (!(_Right < *this));
		   }

	bool_t
      operator>=( const Self_t &_Right ) const
		   {//test if this >= _Right
		   return (!(*this < _Right));
		   }

	bool_t
      exist() const
		   {//test if pointer alive
		   return (Cursor != 0);
		   }

	_Tptr //pointer to element in vector
      Cursor; 

	};//Vector_const_iterator

template<class _Ty,class _Alloc> inline Vector_const_iterator<_Ty,_Alloc> 
   operator+( typename Vector_const_iterator<_Ty,_Alloc>::diff_t _Off,Vector_const_iterator<_Ty,_Alloc> _Next)
	   {//add offset to iterator
	   return (_Next += _Off);
	   }

template<class _Ty,class _Alloc>
class Vector_iterator : public Vector_const_iterator<_Ty,_Alloc>
	{//iterator for mutable vector
public:
	typedef Vector_iterator<_Ty,_Alloc> Self_t;
	typedef Vector_const_iterator<_Ty,_Alloc> Base_t;
	typedef Random_access_iterator_tag iterator_category;

   typedef typename _Alloc::item_t item_t;
	typedef typename _Alloc::diff_t diff_t;
	typedef typename _Alloc::pointer pointer;
	typedef typename _Alloc::reference reference;

	Vector_iterator()
		{//construct with null vector pointer
		}

	Vector_iterator( pointer _Ptr ) : Base_t( _Ptr )
		{//construct with pointer _Ptr
		}

	reference 
      operator*() const
		   {//return designated object
		   return ((reference)**(Base_t*)this);
		   }

	pointer 
      operator->() const
		   {//return pointer to class object
		   return (&**this);
		   }

	Self_t& 
      operator++()
		   {//preincrement
		   ++*(Base_t*)this;
		   return (*this);
		   }

	Self_t 
      operator++(int)
		   {//postincrement
		   Self_t _Tmp = *this;
		   ++*this;
		   return (_Tmp);
		   }

	Self_t& 
      operator--()
		   {//predecrement
		   --*(Base_t*)this;
		   return (*this);
		   }

	Self_t 
      operator--(int)
		   {//postdecrement
		   Self_t _Tmp = *this;
		   --*this;
		   return (_Tmp);
		   }

	Self_t&
      operator+=( diff_t _Off )
		   {//increment by integer
		   *(Base_t*)this += _Off;
		   return (*this);
		   }

	Self_t
      operator+( diff_t _Off ) const
		   {//return this + integer
		   Self_t _Tmp = *this;
		   return (_Tmp += _Off);
		   }

	Self_t&
      operator-=( diff_t _Off )
		   {//decrement by integer
		   return (*this += -_Off);
		   }

	Self_t
      operator-( diff_t _Off ) const
		   {//return this - integer
		   Self_t _Tmp = *this;
		   return (_Tmp -= _Off);
		   }

	diff_t
      operator-( const Base_t &_Right ) const
		   {//return difference of iterators
		   return (*(Base_t*)this - _Right);
		   }

   reference
      operator[]( diff_t _Off ) const
		   {//subscript
		   return (*(*this + _Off));
		   }

	};//Vector_iterator

template<class _Ty,class _Alloc> inline Vector_iterator<_Ty, _Alloc>
   operator+( typename Vector_iterator<_Ty,_Alloc>::diff_t _Off,Vector_iterator<_Ty,_Alloc> _Next )
	   {//add offset to iterator
	   return (_Next += _Off);
	   }

template<class _Ty,class _Alloc>
class Vector_base
	{//base class for vector to hold allocator allocator_value
protected:
	Vector_base( _Alloc _Al = _Alloc()) : _Alval(_Al)
		{//construct allocator from _Al
		}
	typedef typename _Alloc::template rebind<_Ty>::other _Alty;

	_Alty //allocator object for values
      _Alval;
	};

template<class _Ty,class _Ax>
class Vector : public Vector_base<_Ty,_Ax>
	{//various size array of objects or values
public:
	typedef Vector<_Ty,_Ax> Self_t;
	typedef Vector_base<_Ty,_Ax> Base_t;
	typedef typename Base_t::_Alty _Alloc;

	typedef _Alloc allocator_type;
   typedef typename _Alloc::item_t item_t;
	typedef typename _Alloc::diff_t diff_t;
	typedef typename _Alloc::pointer pointer;
   typedef typename _Alloc::reference reference;
	typedef typename _Alloc::const_pointer const_pointer;
	typedef typename _Alloc::const_reference const_reference;

	typedef Vector_iterator<_Ty,_Alloc> iterator;
	typedef Vector_const_iterator<_Ty, _Alloc> const_iterator;

	//----------------------------------
	//	Constructors and destructor
	//----------------------------------
	Vector()	: Base_t()
		{//construct empty vector
		buy(0);
		}

	explicit Vector( const _Alloc &_Al ) : Base_t(_Al)
		{//construct empty vector with allocator
		buy(0);
		}

	explicit Vector( size_t _Count ) : Base_t()
		{//construct from _Count * _Ty()
      construct_n( _Count,_Ty());
		}

	Vector( size_t _Count,const _Ty &_Val) : Base_t()
		{//construct from _Count * _Val
      construct_n( _Count,_Val );
		}

	Vector( size_t _Count,const _Ty &_Val,const _Alloc &_Al ) : Base_t(_Al)
		{//construct from _Count * _Val, with allocator
		construct_n( _Count,_Val );
		}

	Vector( const Self_t &_Right ) : Base_t( _Right._Alval )
		{//construct by copying _Right
		if (buy(_Right.size()))
         {//nonzero, copy it
		   try
            {
            Last = u_copy( _Right.begin(),_Right.end(),First );
			   }
		   catch(...)
			   {
			   tidy(); 
			   throw;
			   }
         }
		}

	template<class _Iter>
	Vector( _Iter _First,_Iter _Last ) : Base_t()
		{//construct from [_First,_Last)
		construct( _First,_Last,_iter_cat( _First ));
		}

	template<class _Iter>
	Vector( _Iter _First,_Iter _Last,const _Alloc &_Al ) : Base_t(_Al)
		{//construct from [_First, _Last), with allocator
		construct( _First,_Last,_iter_cat( _First ));
		}

	~Vector() _NOTHROW
		{// destroy the object
		tidy();
		}

	template<class _Iter> void_t
      construct( _Iter _Count,_Iter _Val,Int_iterator_tag )
		   {//initialize with _Count * _Val
		   construct_n((size_t)_Count,(_Ty)_Val );
		   }

	template<class _Iter> void_t
      construct( _Iter _First,_Iter _Last,Input_iterator_tag )
		   {//initialize with [_First, _Last), input iterators
         buy(0);
		   try
            {
			   insert( begin(),_First,_Last );
			   }
		   catch(...)		
			   {
			   tidy(); 
			   throw;
			   }
		   }

	void_t 
      construct_n( size_t _Count,const _Ty &_Val)
		   {//construct from _Count * _Val
		   if (buy( _Count ))
			   {//nonzero, fill it
			   try
               {
				   Last = u_fill( First,_Count,_Val );
				   }
			   catch(...)
				   {
				   tidy(); 
				   throw;
				   }
			   }
		   }

	Self_t&
      operator=( const Self_t &_Right )
		   {//assign _Right
		   if (this != &_Right)
			   {// worth doing
			   if (_Right.size() == 0)
				   clear();	// new sequence empty, free storage
			   else 
			   if (_Right.size() <= size())
				   {// enough elements, copy new then destroy old
				   pointer _Ptr = _copy( _Right.First,_Right.Last,First );
				   destroy( _Ptr,Last );
				   Last = First + _Right.size();
				   }
			   else 
			   if (_Right.size() <= capacity())
				   {//enough room, copy and construct new
				   pointer _Ptr = _Right.First + size();
				   _copy( _Right.First,_Ptr,First );
				   Last = u_copy( _Ptr,_Right.Last,Last );
				   }
			   else
				   {// not enough room, allocate new array and construct new
				   if (First != 0)
					   {//discard old array
					   destroy( First,Last );
					   this->_Alval.deallocate( First,End - First );
					   }
				   if (buy(_Right.size()))
					   Last = u_copy( _Right.First,_Right.Last,First );
				   }
			   }
		   return (*this);
		   }

	void_t
      reserve( size_t _Count )
		   {//determine new minimum length of allocated storage
		   if (max_size() < _Count)
			   _xlen();
		   else
		   if (capacity() < _Count)
			   {//not enough room
			   pointer 
               _Ptr = this->_Alval.allocate( _Count );

			   try
               {
				   u_move( First,Last,_Ptr );
				   }
			   catch(...)
				   {
				   this->_Alval.deallocate( _Ptr,_Count ); 
				   throw;
				   }
			   size_t 
               _Size = size();

			   if (First != pointer())
				   {// destroy and deallocate old array
				   destroy( First,Last );
				   this->_Alval.deallocate( First,End - First );
				   }
			   End   = _Ptr + _Count;
			   Last  = _Ptr + _Size;
			   First = _Ptr;
			   }
		   }

	iterator
      begin() _NOTHROW
		   {//return iterator for beginning of mutable sequence
		   return iterator( First );
		   }

	const_iterator
      begin() const _NOTHROW
		   {//return iterator for beginning of nonmutable sequence
		   return const_iterator( First );
		   }

	iterator
      end() _NOTHROW
		   {//return iterator for end of mutable sequence
		   return iterator( Last );
		   }

	const_iterator
      end() const _NOTHROW
		   {//return iterator for end of nonmutable sequence
		   return const_iterator( Last );
		   }

	iterator
      it( size_t _Pos ) _NOTHROW
		   {//subscript mutable sequence
		   return (iterator( First ) + _Pos);
		   }

	const_iterator
      it( size_t _Pos ) const _NOTHROW
		   {//subscript nonmutable sequence
		   return (const_iterator( First ) + _Pos);
		   }

	iterator 
      make_iter( const_iterator _Where ) const
		   {//make iterator from const_iterator
		   return (iterator( _Where.Cursor ));
		   }

	void_t
      resize( size_t _Newsize )
		   {//determine new length, padding with _Ty() elements as needed
         resize( _Newsize,_Ty());
		   }

	void_t
      resize( size_t _Newsize,_Ty _Val )
		   {//determine new length, padding with _Val elements as needed
         if (size() > _Newsize)
			   erase( begin() + _Newsize,end());
         else
		   if (size() < _Newsize)
			   insert_n( end(),_Newsize - size(),_Val );
		   }

	uint_t 
      size() const _NOTHROW
		   {//return length of sequence
		   return uint_t(Last - First);
		   }

	uint_t
      capacity() const _NOTHROW
		   {//return current length of allocated storage
		   return uint_t(End - First);
		   }

	size_t
      max_size() const _NOTHROW
		   {//return maximum possible length of sequence
		   return (this->_Alval.max_size());
		   }

	bool_t
      empty() const _NOTHROW
		   {//test if sequence is empty
		   return (First == Last);
		   }

	_Alloc 
      get_allocator() const _NOTHROW
		   {	// return allocator object for values
         return (this->_Alval);
		   }

	const_reference
      at( size_t _Pos ) const
		   {//subscript nonmutable sequence with checking
		   if (size() <= _Pos)
			   _xran();

		   return (*(First + _Pos));
		   }

	reference 
      at( size_t _Pos )
		   {//subscript mutable sequence with checking
		   if (size() <= _Pos)
			   _xran();

		   return (*(First + _Pos));
		   }

	const_reference 
      operator[]( size_t _Pos ) const _NOTHROW
		   {//subscript nonmutable sequence
		   return (*(First + _Pos));
		   }

	reference 
      operator[]( size_t _Pos ) _NOTHROW
		   {//subscript mutable sequence
		   return (*(First + _Pos));
		   }

	pointer 
      data() _NOTHROW
		   {//get address of first element
		   return First;
		   }

	const_pointer 
      data() const _NOTHROW
		   {//get address of first element
		   return First;
		   }

	reference
      front()
		   {//get first element of mutable sequence
		   return (*begin());
		   }

	const_reference
      front() const
		   {//get first element of nonmutable sequence
		   return (*begin());
		   }

	reference
      back()
		   {//return last element of mutable sequence
		   return (*(end() - 1));
		   }

	const_reference
      back() const
		   {//return last element of nonmutable sequence
		   return (*(end() - 1));
		   }

	void_t 
      push_back( const _Ty &_Val )
		   {//push back a non-element
   #pragma omp critical (CS_vector_push_back)
            {
			   if(Last == End)
				   room(1);

			   _construct_val( this->_Alval,Last,_Val ); ++Last;
            }
		   }

	void_t 
      pop_back()
		   {//erase element at end
         if (!empty())
   #pragma omp critical (CS_vector_pop_back)
            {
		      if (!empty())
			      {
			      _destroy_val( this->_Alval,Last - 1 ); --Last;
			      }
            }
		   }

	template<class _Iter> void_t
      assign( _Iter _First,_Iter _Last )
		   {//assign [_First, _Last)
		   assign_opt( _First,_Last,_iter_cat( _First ));
		   }

	template<class _Iter> void_t
      assign_opt( _Iter _Count,_Iter _Val,Int_iterator_tag )
		   {//assign _Count * _Val
		   assign_n((size_t)_Count,(_Ty)_Val );
		   }

	template<class _Iter> void_t
      assign_opt( _Iter _First,_Iter _Last,Input_iterator_tag )
		   {// assign [_First,_Last), input iterators
		   erase( begin(),end());
		   insert( begin(),_First,_Last);
		   }

	void_t
      assign( size_t _Count,const _Ty &_Val )
		   {//assign _Count * _Val
		   assign_n( _Count,_Val );
		   }

	iterator
      insert( const_iterator _Where,const _Ty &_Val )
		   {//insert _Val at _Where
		   size_t _Off = size() == 0 ? 0 : _Where - begin();
		   insert_n( _Where,(size_t)1,_Val );
		   return (begin() + _Off);
		   }

	void_t
      insert( const_iterator _Where,size_t _Count,const _Ty &_Val )
		   {//insert _Count * _Val at _Where
		   insert_n( _Where,_Count,_Val );
		   }

	template<class _Iter> void_t
      insert( const_iterator _Where,_Iter _First,_Iter _Last )
		   {//insert [_First,_Last) at _Where
		   insert_opt( _Where,_First,_Last,_iter_cat( _First ));
		   }

	template<class _Iter> void_t
      insert_opt( const_iterator _Where,_Iter _First,_Iter _Last,Int_iterator_tag )
		   {//insert _Count * _Val at _Where
		   insert_n( _Where,(size_t)_First,(_Ty)_Last );
		   }

	template<class _Iter> void_t
      insert_opt( const_iterator _Where,_Iter _First,_Iter _Last,Input_iterator_tag )
		   {//insert [_First, _Last) at _Where, input iterators
         size_t _Off = _Where - this->_Myfirst;

		   if (_First != _Last)
			   {//worth doing, gather at end and rotate into place
			   size_t _Oldsize = size();

            try
               {//append
			      for (; _First != _Last; ++_First)
				      push_back( *_First );
               }
			   catch(...)
               {
               erase( begin() + _Oldsize,end());
               throw;
               }
			   _rotate( begin() + _Off,begin() + _Oldsize,end());
			   }
		   }

	template<class _Iter> void_t
      insert_opt( const_iterator _Where,_Iter _First,_Iter _Last,Forward_iterator_tag )
		   {//insert [_First, _Last) at _Where, forward iterators
		   size_t 
            _Count = 0; _distance(_First, _Last, _Count);

		   if (_Count == 0)
			   ;
		   else 
         if (max_size() - size() < _Count)
			   _xlen(); //result too long
		   else 
         if (capacity() < size() + _Count)
			   {//not enough room, reallocate
			   size_t _Capacity = grow( size() + _Count );
			   pointer _Newvec = this->_Alval.allocate( _Capacity );
			   pointer _Ptr = _Newvec;

			   try
               {
               _Ptr = u_move( First,_Where.Cursor,_Newvec ); //copy prefix
               _Ptr = u_copy( _First,_Last,_Ptr );	//add new stuff
               u_move( _Where.Cursor,Last,_Ptr ); //copy suffix
               }
            catch(...)
               {
               destroy( _Newvec,_Ptr );
               this->_Alval.deallocate( _Newvec,_Capacity );
               throw;
               }

			   _Count += size();
			   if (First != 0)
				   {	// destroy and deallocate old array
				   destroy( First,Last );
				   this->_Alval.deallocate( First,End - First );
				   }

			   End = _Newvec + _Capacity;
			   Last = _Newvec + _Count;
			   First = _Newvec;
			   }
		   else
			   {//new stuff fits, append and rotate into place
			   u_copy( _First,_Last,Last );
			   _rotate( _Where.Cursor,Last,Last + _Count);
			   Last += _Count;
			   }
		   }

	iterator
      erase( const_iterator _Where )
		   {//erase element at where
		   _move( _Where.Cursor + 1,Last,_Where.Cursor );
		   destroy( Last - 1,Last );
		   --Last;
		   return (make_iter( _Where ));
		   }

	iterator
      erase( const_iterator _First_arg,const_iterator _Last_arg )
		   {//erase [_First, _Last)
		   iterator _First = make_iter( _First_arg ),
		            _Last  = make_iter( _Last_arg );

		   if (_First != _Last)
			   {	// worth doing, copy down over hole
			   pointer _Ptr = _move( _Last.Cursor,Last,_First.Cursor );

			   destroy( _Ptr,Last );
			   Last = _Ptr;
			   }
		   return (make_iter( _First ));
		   }

	void_t
      clear() _NOTHROW
		   {//erase all and deallocate
         if (!empty())
   #pragma omp critical (CS_vector_clear)
            {
            if (!empty())
               {
               destroy( First,Last ); Last = First;
               }
            }
		   }

	void_t
      swap( Self_t &_Right )
         {//exchange contents with _Right
		   if (this == &_Right)
			   ;
		   else 
         if (this->_Alval == _Right._Alval)
			   {//same allocator, swap control information
			   swap( First,_Right.First );
			   swap( Last,_Right.Last );
			   swap( End,_Right.End );
			   }
		   else
			   {//different allocator, do multiple assigns
            Self_t 
               _Ts = *this; 
                     *this = _Right;
                             _Right = _Ts;
			   }
		   }

	void_t
      mail( pointer _Dest )
		   {//delictual liability to export [_First,_Last), using allocator
         if(_Dest)
		      u_copy( First,Last,_Dest );
		   }

	void_t
      mail( const_pointer _Src,size_t _Count )
		   {//delictual liability to import [_First,_First+_Count) elements, using allocator
         if(_Src)
		      assign( _Src,_Src + _Count );
		   }

private:
	void_t
      assign_n( size_t _Count,const _Ty &_Val )
		   {//assign _Count * _Val
		   _Ty _Tmp = _Val;
		   erase( begin(),end());
		   insert( begin(),_Count,_Tmp );
		   }

	bool_t
      buy( size_t _Capacity )
		   {//allocate array with _capacity elements
		   First = pointer();
         Last  = pointer();
         End   = pointer();

		   if(_Capacity == 0)
			   return false;

         if(_Capacity > max_size())
			   _xlen();
		   else
			   {//nonempty array, allocate storage
			   First = this->_Alval.allocate( _Capacity );
			   Last  = First;
			   End   = First + _Capacity;
			   }
		   return true;
		   }

	void_t
      destroy( pointer _First,pointer _Last )
		   {//destroy [_First, _Last) using allocator
         _destroy_range( _First,_Last,this->_Alval );
		   }

	size_t
      grow( size_t _Count ) const
		   {//grow by 50% or at least to _Count
		   size_t 
            _Capacity = capacity();
		      _Capacity = max_size() - _Capacity/2 < _Capacity ? 0 : _Capacity + _Capacity/2;

		   if(_Capacity < _Count)
			   _Capacity = _Count; return _Capacity;
         }

	bool_t
      inside( const _Ty *_Ptr ) const
		   {//test if _Ptr points inside vector
		   return (_Ptr < Last && First <= _Ptr);
		   }

	void_t
      room( size_t _Count )
		   {//ensure room for _Count new elements, grow exponentially
		   size_t 
            _Size = size();

		   if(_Size > max_size() - _Count)
			   _xlen();
		   else
         if((_Size += _Count) <= capacity())
			   ;
		   else
			   reserve( grow( _Size ));
		   }

public:
	void_t
      tidy()
		   {//free all storage
		   if (First != pointer())
			   {//something to free, destroy and deallocate it
			   destroy( First,Last ); this->_Alval.deallocate( First,End - First );
			   }
		   First = pointer();
         Last  = pointer();
         End   = pointer();
		   }

private:
	template<class _Iter> pointer
      u_copy( _Iter _First,_Iter _Last,pointer _Ptr )
		   {//copy initializing [_First,_Last), using allocator
		   return (_uninitialized_copy( _First,_Last,_Ptr,this->_Alval ));
		   }

	template<class _Iter> pointer
      u_move( _Iter _First,_Iter _Last,pointer _Ptr )
		   {//move initializing [_First, _Last), using allocator
		   return (_uninitialized_move( _First,_Last,_Ptr,this->_Alval ));
		   }

	void_t
      insert_n( const_iterator _Where,size_t _Count,const _Ty &_Val )
		   {//insert _Count * _Val at _Where
		   if (_Count == 0)
			   ;
		   else 
         if (max_size() - size() < _Count)
			   _xlen(); //result too long
		   else 
         if (capacity() < size() + _Count)
			   {//not enough room, reallocate
			   size_t _Capacity = grow( size() + _Count );
			   pointer _Newvec = this->_Alval.allocate( _Capacity );
			   size_t _Whereoff = _Where.Cursor - First;
			   int _Ncopied = 0;

			   try
               {
               u_fill( _Newvec + _Whereoff,_Count,_Val ); //add new stuff
			      ++_Ncopied;
			      u_move( First,_Where.Cursor,_Newvec ); //copy prefix
			      ++_Ncopied;
			      u_move( _Where.Cursor,Last,_Newvec + (_Whereoff + _Count)); //copy suffix
               }
            catch(...)
               {
			      if (1 < _Ncopied)
				      destroy( _Newvec,_Newvec + _Whereoff );
			      if (0 < _Ncopied)
				      destroy( _Newvec + _Whereoff,_Newvec + _Whereoff + _Count );
			      this->_Alval.deallocate( _Newvec,_Capacity );
               throw;
               }

			   _Count += size();
			   if (First != 0)
				   {	// destroy and deallocate old array
				   destroy( First,Last );
				   this->_Alval.deallocate( First,End - First );
				   }

			   End = _Newvec + _Capacity;
			   Last = _Newvec + _Count;
			   First = _Newvec;
			   }
		   else 
         if ((size_t)(Last - _Where.Cursor) < _Count)
			   {//new stuff spills off end
			   _Ty _Tmp = _Val;
			   u_move( _Where.Cursor,Last,_Where.Cursor + _Count ); //copy suffix

			   try
               {
               u_fill( Last,_Count - (Last - _Where.Cursor),_Tmp ); //insert new stuff off end
               }
            catch(...)
               {
			      destroy( _Where.Cursor + _Count,Last + _Count );
               throw;
               }

			   Last += _Count;
			   _fill( _Where.Cursor,Last - _Count,_Tmp ); //insert up to old end
			   }
		   else
			   {//new stuff can all be assigned
			   _Ty _Tmp = _Val;
			   pointer _Oldend = Last;
			   Last = u_move( _Oldend - _Count,_Oldend,Last );//copy suffix

			   _copy_backward( _Where.Cursor,_Oldend - _Count,_Oldend ); //copy hole
			   _fill( _Where.Cursor,_Where.Cursor + _Count,_Tmp ); //insert into hole
			   }
		   }

	pointer
      u_fill( pointer _Ptr,size_t _Count,const _Ty &_Val )
		   {//copy initializing _Count * _Val, using allocator
		   _uninitialized_fill_n( _Ptr,_Count,_Val,this->_Alval );
		   return (_Ptr + _Count);
		   }

	static void_t
      _xlen()
		   {//report a length_error
		   throw Length_error( "Vector<T> too long" );
		   }

	static void_t 
      _xran()
		   {//report an out_of_range error
		   throw Out_of_range( "Invalid Vector<T> subscript" );
		   }

private:
	pointer 
      First, // pointer to beginning of array
	   Last,  // pointer to current end of sequence
	   End;   // pointer to end of array
	};

/**************************************
			Vector operators
**************************************/
template<class _Ty,class _Alloc> inline bool_t
   operator==( const Vector<_Ty,_Alloc> &_Left,const Vector<_Ty,_Alloc> &_Right )
	   {//test for vector equality
	   return (_Left.size() == _Right.size() && equal(_Left.begin(),_Left.end(),_Right.begin()));
	   }

template<class _Ty,class _Alloc> inline bool_t
   operator!=( const Vector<_Ty,_Alloc> &_Left,const Vector<_Ty,_Alloc> &_Right )
	   {//test for vector inequality
	   return (!(_Left == _Right));
	   }

template<class _Ty,class _Alloc> inline bool_t
   operator<( const Vector<_Ty,_Alloc> &_Left,const Vector<_Ty,_Alloc> &_Right )
	   {// test if _Left < _Right for vectors
	   return (lexicographical_compare( _Left.begin(),_Left.end(),_Right.begin(),_Right.end()));
	   }

template<class _Ty,class _Alloc> inline bool_t
   operator>( const Vector<_Ty,_Alloc> &_Left,const Vector<_Ty,_Alloc> &_Right )
	   {//test if _Left > _Right for vectors
	   return (_Right < _Left);
	   }

template<class _Ty,class _Alloc> inline bool_t
   operator<=( const Vector<_Ty,_Alloc> &_Left,const Vector<_Ty,_Alloc> &_Right )
	   {//test if _Left <= _Right for vectors
	   return (!(_Right < _Left));
	   }

template<class _Ty,class _Alloc> inline bool_t
   operator>=( const Vector<_Ty,_Alloc> &_Left,const Vector<_Ty,_Alloc> &_Right )
	   {//test if _Left >= _Right for vectors
	   return (!(_Left < _Right));
	   }

template<class _Ty,class _Alloc> inline void_t
   swap( Vector<_Ty,_Alloc> &_Left,Vector<_Ty,_Alloc> &_Right )
	   {//swap _Left and _Right vectors
	   _Left.swap(_Right);
	   }

_ESK_END
#pragma pack(pop)
#endif//VECTOR_H
