#pragma		once
#ifndef		ANONIM_H
#define		ANONIM_H

//	Use project headers
#include		"Eskdef.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
         Anonymous constants
**************************************/
const
struct Struct_null
	{//advance null
   Struct_null()
      {//default constructor
      }

	template<class _Ty>
	   operator _Ty*() const
		   {//zero pointer to any non-member
		   return 0;
		   }
	
	template<class _Cl,class _Ty>
	   operator _Ty _Cl::*() const
		   {//zero pointer to any member
		   return 0;
		   }
   } Null;

const
struct Struct_fint
	{//advance transformation
   Struct_fint()
      {//default constructor
      }

	iint_t 
      operator()( float _Right ) const
		   {//transform float to int
		   return iint_t(_Right > 0.f ? _Right+0.5f : _Right-0.5f);
		   }

	iint_t 
      operator()( double _Right ) const
		   {//transform double to int
		   return iint_t(_Right > 0.l ? _Right+0.5l : _Right-0.5l);
		   }
	} Fint;

_ESK_END
#pragma pack(pop)
#endif//ANONIM_H
