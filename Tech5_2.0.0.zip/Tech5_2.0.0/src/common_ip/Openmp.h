#pragma		once
#ifndef		OPENMP_H
#define		OPENMP_H

// Detect parallal technology
#ifdef _OPENMP
   #pragma message( "OMP is supported" )
#else
   #pragma message( "OMP is not supported" )
#endif

#ifdef _OPENMP
   #include         <omp.h>
#else

inline int
   omp_get_num_procs()
      {//stub for number of processors 
      return 1;
      }

inline int
   omp_get_thread_num()
      {//stub for thread number within its thread team
      return 0;
      }

inline void
   omp_set_dynamic( int )
      {//dynamic threads change
      }

inline int
   omp_get_dynamic()
      {//read permisable to dynamic threads
      return 0;
      }

#endif
#endif//OPENMP_H
