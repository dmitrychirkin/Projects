/**************************************
					UTILIZE.H
		 Analog of iterator stuff 
			of standard library.

        Copyright (c) 1994-2004.
        Copyright (c) 2005-2012.
**************************************/
#pragma		once
#ifndef		UTILIZE_H
#define		UTILIZE_H

//	Use project headers
#include		"Strings.h"
#include		"Utility.h"

#pragma pack(push,_LDS_PACKING)
_LDS_BEGIN
//-------------------------------------
// Iterator tags
//-------------------------------------
struct Input_iterator_tag
	{//identifying tag for input iterators
	};

struct Output_iterator_tag
	{//identifying tag for output iterators
	};

struct Forward_iterator_tag : public Input_iterator_tag
	{//identifying tag for forward iterators
	};

struct Bidirectional_iterator_tag : public Forward_iterator_tag
	{//identifying tag for bidirectional iterators
	};

struct Random_access_iterator_tag : public Bidirectional_iterator_tag
	{//identifying tag for random-access iterators
	};

struct Int_iterator_tag
	{//identifying tag for integer types, not an iterator
	};

struct Nonscalar_ptr_iterator_tag
	{//pointer to unknown type
	};

struct Scalar_ptr_iterator_tag
	{//pointer to scalar type
	};

//-------------------------------------
// Template classes for iterators
//-------------------------------------
template<class _Category,class _Ty,class _Diff = Ptrdiff_t,class _Pointer = _Ty*,class _Reference = _Ty&>
struct Iterator
	{//base type for all iterator classes
	typedef _Category iterator_category;
	typedef _Ty value_type;
	typedef _Diff difference_type;
	typedef _Diff distance_type;	//retained
	typedef _Pointer pointer;
	typedef _Reference reference;
	};

template<class _Ty,class _Diff,class _Pointer,class _Reference>
struct Bidit : public Iterator<Bidirectional_iterator_tag,_Ty,_Diff,_Pointer,_Reference>
	{//base for bidirectional iterators
	};

template<class _Ty,class _Diff,class _Pointer,class _Reference>
struct Ranit : public Iterator<Random_access_iterator_tag,_Ty,_Diff,_Pointer,_Reference>
	{//base for random-access iterators
	};

struct Outit : public Iterator<Output_iterator_tag,void_t,void_t,void_t,void_t>
	{//base for output iterators
	};

//-------------------------------------
// Template classes for iterator traits
//-------------------------------------
template<class _Iter>
struct Iterator_traits
	{//get traits from iterator _Iter
	typedef typename _Iter::iterator_category iterator_category;
	typedef typename _Iter::value_type value_type;
	typedef typename _Iter::difference_type difference_type;
	typedef difference_type distance_type;	// retained
	typedef typename _Iter::pointer pointer;
	typedef typename _Iter::reference reference;
	};

template<class _Ty>
struct Iterator_traits<_Ty*>
	{//get traits from pointer
	typedef Random_access_iterator_tag iterator_category;
	typedef _Ty value_type;
	typedef Ptrdiff_t difference_type;
	typedef Ptrdiff_t distance_type;	// retained
	typedef _Ty* pointer;
	typedef _Ty& reference;
	};

template<class _Ty>
struct Iterator_traits<const _Ty*>
	{//get traits from const pointer
	typedef Random_access_iterator_tag iterator_category;
	typedef _Ty value_type;
	typedef Ptrdiff_t difference_type;
	typedef Ptrdiff_t distance_type;	// retained
	typedef const _Ty* pointer;
	typedef const _Ty& reference;
	};

template<> struct Iterator_traits<bool_t>
	{//get traits from integer type
	typedef Int_iterator_tag iterator_category;
	};

template<> struct Iterator_traits<char>
	{//get traits from integer type
	typedef Int_iterator_tag iterator_category;
	};

template<> struct Iterator_traits<signed char>
	{//get traits from integer type
	typedef Int_iterator_tag iterator_category;
	};

template<> struct Iterator_traits<unsigned char>
	{//get traits from integer type
	typedef Int_iterator_tag iterator_category;
	};

template<> struct Iterator_traits<short>
	{//get traits from integer type
	typedef Int_iterator_tag iterator_category;
	};

template<> struct Iterator_traits<unsigned short>
	{//get traits from integer type
	typedef Int_iterator_tag iterator_category;
	};

template<> struct Iterator_traits<int>
	{//get traits from integer type
	typedef Int_iterator_tag iterator_category;
	};

template<> struct Iterator_traits<unsigned int>
	{//get traits from integer type
	typedef Int_iterator_tag iterator_category;
	};

template<> struct Iterator_traits<long>
	{//get traits from integer type
	typedef Int_iterator_tag iterator_category;
	};

template<> struct Iterator_traits<unsigned long>
	{//get traits from integer type
	typedef Int_iterator_tag iterator_category;
	};

template<> struct Iterator_traits<long long>
	{	// get traits from integer type
	typedef Int_iterator_tag iterator_category;
	};

template<> struct Iterator_traits<unsigned long long>
	{	// get traits from integer type
	typedef Int_iterator_tag iterator_category;
	};

struct Undefined_move_tag
	{//default move operation tag
	};

struct Swap_move_tag
	{//default swap move operation tag
	};

template<class _Ty>
class Move_operation_category
	{//default swap move operation tag
public:
	typedef Undefined_move_tag _Move_cat;
	};

//-------------------------------------
// Template function _iter_cat
//-------------------------------------
template<class _Iter> inline typename Iterator_traits<_Iter>::iterator_category 
   _iter_cat( const _Iter& )
      {//return category from iterator argument
      typename Iterator_traits<_Iter>::iterator_category _Cat;
      return (_Cat);
      }

//-------------------------------------
// Template functions _ptr_cat
//-------------------------------------
template<class _Ty,class _Tp> inline Nonscalar_ptr_iterator_tag 
   _ptr_cat( _Ty&,_Tp& )
	   {//return pointer category from arbitrary arguments
	   Nonscalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

template<class _Ty> inline Scalar_ptr_iterator_tag 
   _ptr_cat( _Ty**,_Ty** )
	   {//return pointer category from pointer to pointer arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

template<class _Ty> inline Scalar_ptr_iterator_tag 
   _ptr_cat( _Ty**,const _Ty** )
	   {//return pointer category from pointer to pointer arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

template<class _Ty> inline Scalar_ptr_iterator_tag 
   _ptr_cat( _Ty* const*,_Ty** )
	   {//return pointer category from pointer to pointer arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

template<class _Ty> inline Scalar_ptr_iterator_tag 
   _ptr_cat( _Ty* const*,const _Ty** )
	   {//return pointer category from pointer to pointer arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

//-------------------------------------
// Integer functions _ptr_cat
//-------------------------------------
inline Scalar_ptr_iterator_tag 
   _ptr_cat( bool_t*,bool_t* )
	   {//return pointer category from pointer to bool_t arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( const bool_t*,bool_t* )
	   {//return pointer category from pointer to bool_t arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( char*,char* )
	   {//return pointer category from pointer to char arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( const char*,char* )
	   {//return pointer category from pointer to char arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( signed char*,signed char* )
	   {//return pointer category from pointer to signed char arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( const signed char*,signed char* )
	   {//return pointer category from pointer to signed char arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( unsigned char*,unsigned char* )
	   {//return pointer category from pointer to unsigned char arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( const unsigned char*,unsigned char* )
	   {//return pointer category from pointer to unsigned char arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( short*,short* )
	   {//return pointer category from pointer to short arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( const short*,short* )
	   {//return pointer category from pointer to short arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( unsigned short*,unsigned short* )
	   {//return pointer category from pointer to unsigned short arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( const unsigned short*,unsigned short* )
	   {//return pointer category from pointer to unsigned short arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( int*,int* )
	   {//return pointer category from pointer to int arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( const int*,int* )
	   {//return pointer category from pointer to int arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( unsigned int*,unsigned int* )
	   {//return pointer category from pointer to unsigned int arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( const unsigned int*,unsigned int* )
	   {//return pointer category from pointer to unsigned int arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( long*,long* )
	   {//return pointer category from pointer to long arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( const long*,long* )
	   {//return pointer category from pointer to long arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( unsigned long*,unsigned long* )
	   {//return pointer category from pointer to unsigned long arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( const unsigned long*,unsigned long* )
	   {//return pointer category from pointer to unsigned long arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( float*,float* )
	   {//return pointer category from pointer to float arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( const float*,float* )
	   {//return pointer category from pointer to float arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( double*,double* )
	   {//return pointer category from pointer to double arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( const double*,double* )
	   {//return pointer category from pointer to double arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( long double*,long double* )
	   {//return pointer category from pointer to long double arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

inline Scalar_ptr_iterator_tag 
   _ptr_cat( const long double*,long double* )
	   {//return pointer category from pointer to long double arguments
	   Scalar_ptr_iterator_tag _Cat;
	   return (_Cat);
	   }

//-------------------------------------
// Template function _val_type
//-------------------------------------
template<class _Iter> inline typename Iterator_traits<_Iter>::value_type* 
   _val_type( _Iter )
	   {//return value type from arbitrary argument
	   return (0);
	   }

//-------------------------------------
// Template function advance
//-------------------------------------
template<class _InIt,class _Diff> inline void_t 
   _advance( _InIt &_Where,_Diff _Off )
	   {//increment iterator by offset, arbitrary iterators
	   _advance_opt( _Where,_Off,_iter_cat(_Where));
	   }

template<class _InIt,class _Diff> inline void_t 
   _advance_opt( _InIt &_Where,_Diff _Off,Input_iterator_tag )
	   {//increment iterator by offset, input iterators
	   for (; 0 < _Off; --_Off)
		   ++_Where;
	   }

template<class _FoIt,class _Diff> inline void_t 
   _advance_opt( _FoIt &_Where,_Diff _Off,Forward_iterator_tag )
	   {//increment iterator by offset, forward iterators
	   for (; 0 < _Off; --_Off)
         ++_Where;
	   }

template<class _BiIt,class _Diff> inline void_t 
   _advance_opt( _BiIt &_Where,_Diff _Off,Bidirectional_iterator_tag )
	   {//increment iterator by offset, bidirectional iterators
	   for (; 0 < _Off; --_Off)
		   ++_Where;
	   for (; _Off < 0; ++_Off)
		   --_Where;
	   }

template<class _RaIt,class _Diff> inline void_t 
   _advance_opt( _RaIt &_Where,_Diff _Off,Random_access_iterator_tag )
	   {//increment iterator by offset, random-access iterators
	   _Where += _Off;
	   }

//-------------------------------------
// Template function _dist_type
//-------------------------------------
template<class _Iter> inline typename Iterator_traits<_Iter>::difference_type* 
   _dist_type( _Iter )
	   {//return distance type from arbitrary argument
	   return (0);
	   }

//-------------------------------------
// Template function distance
//-------------------------------------
template<class _InIt> inline typename Iterator_traits<_InIt>::difference_type 
   _distance( _InIt _First,_InIt _Last )
	   {//return distance between iterators
	   typename Iterator_traits<_InIt>::difference_type _Off = 0;
	   _distance_opt( _First,_Last,_Off,_iter_cat( _First ));
	   return (_Off);
	   }

template<class _InIt,class _Diff> inline void_t 
   _distance( _InIt _First,_InIt _Last,_Diff &_Off )
	   {//add to _Off distance between iterators
	   _distance_opt( _First,_Last,_Off,_iter_cat( _First ));
	   }

template<class _InIt,class _Diff> inline void_t 
   _distance_opt( _InIt _First,_InIt _Last,_Diff &_Off,Input_iterator_tag )
	   {//add to _Off distance between input iterators
	   for (; _First != _Last; ++_First)
		   ++_Off;
	   }

template<class _FwdIt,class _Diff> inline void_t 
   _distance_opt( _FwdIt _First,_FwdIt _Last,_Diff &_Off,Forward_iterator_tag )
	   {//add to _Off distance between forward iterators (redundant)
	   for (; _First != _Last; ++_First)
		   ++_Off;
	   }

template<class _BidIt,class _Diff> inline void_t 
   _distance_opt( _BidIt _First,_BidIt _Last,_Diff &_Off,Bidirectional_iterator_tag )
	   {//add to _Off distance between bidirectional iterators (redundant)
      for (; _First != _Last; ++_First)
		   ++_Off;
	   }

template<class _RanIt,class _Diff> inline void_t 
   _distance_opt( _RanIt _First,_RanIt _Last,_Diff &_Off,Random_access_iterator_tag )
	   {//add to _Off distance between random-access iterators
	   _Off += _Last - _First;
	   }

/**************************************
			Class Reverse_iterator
**************************************/
template<class _RanIt>
class Reverse_iterator : public Iterator<typename Iterator_traits<_RanIt>::iterator_category,
													  typename Iterator_traits<_RanIt>::value_type,
													  typename Iterator_traits<_RanIt>::difference_type,
													  typename Iterator_traits<_RanIt>::pointer,
													  typename Iterator_traits<_RanIt>::reference>
	{//wrap iterator to run it backwards
public:
	typedef Reverse_iterator<_RanIt> self;
 	typedef typename Iterator_traits<_RanIt>::difference_type difference_type;
	typedef typename Iterator_traits<_RanIt>::pointer pointer;
	typedef typename Iterator_traits<_RanIt>::reference reference;
	typedef _RanIt Iterator_type;

	Reverse_iterator()
		{//construct with default wrapped iterator
		}

	explicit Reverse_iterator( _RanIt _Rht ) : _R_ptr(_Rht)
		{//construct wrapped iterator from _Rht
		}

	template<class _Other>
	Reverse_iterator( const Reverse_iterator<_Other>& _Rht) : _R_ptr(_Rht.base())
		{//initialize with compatible base
		}

	_RanIt 
      base() const
		   {//return wrapped iterator
		   return (_R_ptr);
		   }

	reference 
      operator*() const
		   {//return designated value
		   _RanIt _tmp = _R_ptr;
		   return (*--_tmp);
		   }

	pointer 
      operator->() const
		   {//return pointer to class object
		   return (&**this);
		   }

	self& 
      operator++()
		   {//preincrement
		   --_R_ptr;
		   return (*this);
		   }

	self 
      operator++(int)
		   {//postincrement
		   self _tmp = *this;
		   --_R_ptr;
		   return (_tmp);
		   }

	self& 
      operator--()
		   {//predecrement
		   ++_R_ptr;
		   return (*this);
		   }

	self 
      operator--(int)
		   {//postdecrement
		   self _tmp = *this;
		   ++_R_ptr;
		   return (_tmp);
		   }

	bool_t 
      equal( const self &_Rht ) const
		   {//test for iterator equality
		   return (_R_ptr == _Rht._R_ptr);
		   }

	self& 
      operator+=( difference_type _Off )
		   {//increment by integer
		   _R_ptr -= _Off;
		   return (*this);
		   }

	self 
      operator+( difference_type _Off ) const
		   {//return this + integer
		   return (self( _R_ptr - _Off ));
		   }

	self& 
      operator-=( difference_type _Off )
		   {//decrement by integer
		   _R_ptr += _Off;
		   return (*this);
		   }

	self 
      operator-( difference_type _Off ) const
		   {//return this - integer
		   return (self(_R_ptr + _Off));
		   }

	reference 
      operator[]( difference_type _Off ) const
		   {// subscript
		   return (*(*this + _Off));
		   }

	bool_t 
      less( const self &_Rht ) const
		   {//test if this < _Rht
		   return (_Rht._R_ptr < _R_ptr);
		   }

	difference_type 
      minus( const self &_Rht) const
		   {//return difference of iterators
		   return (_Rht._R_ptr - _R_ptr);
		   }

protected:
	_RanIt //the wrapped iterator
      _R_ptr;	
	};

//-------------------------------------
// Reverse_iterator operators
//-------------------------------------
template<class _RanIt,class _Diff> inline Reverse_iterator<_RanIt> 
   operator+( _Diff _Off,const Reverse_iterator<_RanIt> &_Rht )
	   {//return reverse_iterator + integer
	   return (_Rht + _Off);
	   }

template<class _RanIt> inline typename Reverse_iterator<_RanIt>::difference_Type 
   operator-( const Reverse_iterator<_RanIt> &_Lft,const Reverse_iterator<_RanIt> &_Rht )
	   {//return difference of reverse_iterators
	   return (_Lft.minus( _Rht ));
	   }

template<class _RanIt> inline bool_t 
   operator==( const Reverse_iterator<_RanIt> &_Lft,const Reverse_iterator<_RanIt> &_Rht )
	   {//test for reverse_iterator equality
	   return (_Lft.equal( _Rht ));
	   }

template<class _RanIt> inline bool_t 
   operator!=( const Reverse_iterator<_RanIt> &_Lft,const Reverse_iterator<_RanIt> &_Rht )
	   {//test for reverse_iterator inequality
	   return (!(_Lft == _Rht));
	   }

template<class _RanIt> inline bool_t 
   operator<( const Reverse_iterator<_RanIt> &_Lft,const Reverse_iterator<_RanIt> &_Rht )
	   {//test for reverse_iterator < reverse_iterator
	   return (_Lft.less(_Rht));
	   }

template<class _RanIt> inline bool_t 
   operator>( const Reverse_iterator<_RanIt> &_Lft,const Reverse_iterator<_RanIt> &_Rht )
	   {//test for reverse_iterator > reverse_iterator
	   return (_Rht < _Lft);
	   }

template<class _RanIt> inline bool_t 
   operator<=( const Reverse_iterator<_RanIt> &_Lft,const Reverse_iterator<_RanIt> &_Rht )
	   {//test for reverse_iterator <= reverse_iterator
	   return (!(_Rht < _Lft));
	   }

template<class _RanIt> inline bool_t 
   operator>=( const Reverse_iterator<_RanIt> &_Lft,const Reverse_iterator<_RanIt> &_Rht )
	   {//test for reverse_iterator >= reverse_iterator
	   return (!(_Lft < _Rht));
	   }

//-------------------------------------
// Template function swap iterators
//-------------------------------------
template<class _FwdInIt,class _FwdOutIt> inline	void_t
   _iter_swap( _FwdInIt _Left,_FwdOutIt _Right )
	   {//swap *_Left and *_Right
	   swap( *_Left,*_Right );
	   }

//-------------------------------------
// Template function copy
//-------------------------------------
template<class _InIt,class _OutIt> inline _OutIt 
   _copy( _InIt _First,_InIt _Last,_OutIt _Dest )
	   {//copy [_First,_Last) to [_Dest, ...)
	   return (_copy_opt( _First,_Last,_Dest,_ptr_cat( _First,_Dest )));
	   }

template<class _InIt,class _OutIt> inline _OutIt 
   _copy_opt( _InIt _First,_InIt _Last,_OutIt _Dest,Nonscalar_ptr_iterator_tag )
	   {//copy [_First,_Last) to [_Dest, ...), arbitrary iterators
	   for (; _First != _Last; ++_Dest, ++_First)
		   *_Dest = *_First;
	   return (_Dest);
	   }

template<class _InIt,class _OutIt> inline _OutIt 
   _copy_opt( _InIt _First,_InIt _Last,_OutIt _Dest,Scalar_ptr_iterator_tag )
	   {//copy [_First,_Last) to [_Dest, ...), pointers to scalars
	   Ptrdiff_t _Count = _Last - _First;
	   return ((_OutIt)_mem_move( &*_Dest,&*_First,_Count*sizeof(*_First)) + _Count);
	   }

//-------------------------------------
// Template function copy_backward
//-------------------------------------
template<class _InIt,class _OutIt> inline _OutIt 
   _copy_backward( _InIt _First,_InIt _Last,_OutIt _Dest)
	   {//copy [_First,_Last) backwards to [..., _Dest)
	   return (_copy_backward_opt( _First,_Last,_Dest,_ptr_cat( _First,_Dest )));
	   }

template<class _InIt,class _OutIt> inline _OutIt 
   _copy_backward_opt( _InIt _First,_InIt _Last,_OutIt _Dest,Nonscalar_ptr_iterator_tag )
	   {//copy [_First,_Last) backwards to [..., _Dest), arbitrary iterators
	   while (_First != _Last)
		   *--_Dest = *--_Last;
	   return (_Dest);
	   }

template<class _InIt,class _OutIt> inline _OutIt 
   _copy_backward_opt( _InIt _First,_InIt _Last,_OutIt _Dest,Scalar_ptr_iterator_tag )
	   {//copy [_First,_Last) backwards to [..., _Dest), pointers to scalars
	   Ptrdiff_t _Off = _Last - _First;
	   return ((_OutIt)_mem_move( &*_Dest - _Off,&*_First,_Off*sizeof(*_First)));
	   }

//-------------------------------------
// Template function _move
//-------------------------------------
template<class _InIt,class _OutIt> inline _OutIt
   _move( _InIt _First,_InIt _Last,_OutIt _Dest )
	   {//move [_First, _Last) to [_Dest, ...), unchecked
	   return (_move_opt( _First,_Last,_Dest,_ptr_cat( _First,_Dest )));
	   }

template<class _InIt,class _OutIt> inline _OutIt
   _move_opt( _InIt _First,_InIt _Last,_OutIt _Dest,Nonscalar_ptr_iterator_tag )
	   {//move [_First, _Last) to [_Dest, ...), arbitrary iterators
	   for (; _First != _Last; ++_Dest, ++_First)
		   *_Dest = movable(*_First);
	   return (_Dest);
	   }

template<class _InIt,class _OutIt> inline _OutIt 
   _move_opt( _InIt _First,_InIt _Last,_OutIt _Dest,Scalar_ptr_iterator_tag )
	   {//move [_First, _Last) to [_Dest, ...), pointers to scalars
	   Ptrdiff_t _Count = _Last - _First;
	   return ((_OutIt)_mem_move( &*_Dest,&*_First,_Count*sizeof(*_First)) + _Count);
	   }

//-------------------------------------
// Template function _mismatch
//-------------------------------------
template<class _InIt,class _OutIt> inline Pair<_InIt,_OutIt> 
   _mismatch( _InIt _First_left,_InIt _Last_left,_OutIt _First_right )
	   {//return [_First_left,_Last_left) and [_First_right,_Last_right) mismatch
	   for (; _First_left != _Last_left && *_First_left == *_First_right; )
		   ++_First_left,++_First_right;
	   return (Pair<_InIt,_OutIt>( _First_left,_First_right ));
	   }

template<class _InIt,class _OutIt,class _Pr> inline Pair<_InIt,_OutIt> 
   _mismatch( _InIt _First_left,_InIt _Last_left,_OutIt _First_right,_Pr _Pred)
	   {//return [_First_left,_Last_left) and [_First_right,_Last_right) mismatch using _Pred
	   for (; _First_left != _Last_left && _Pred( *_First_left,*_First_right );)
		   ++_First_left,++_First_right;
	   return (Pair<_InIt,_OutIt>( _First_left,_First_right ));
	   }

//-------------------------------------
// Template function _equal
//-------------------------------------
template<class _InIt,class _OutIt> inline bool_t 
   _equal( _InIt _First_left,_InIt _Last_left,_OutIt _First_right)
	   {//compare [_First_left,_Last_left) to [first2, ...)
	   return (mismatch( _First_left,_Last_left,_First_right).First == _Last_left);
	   }

template<class _InIt,class _OutIt,class _Pr> inline bool_t 
   _equal( _InIt _First_left,_InIt _Last_left,_OutIt _First_right,_Pr _Pred)
	   {//compare [_First_left,_Last_left) to [first2, ...) using _Pred
	   return (mismatch( _First_left,_Last_left,_First_right,_Pred ).First == _Last_left );
	   }

//-------------------------------------
// Template function _fill
//-------------------------------------
template<class _FwdIt,class _Ty> inline void_t
   _fill( _FwdIt _First,_FwdIt _Last,const _Ty &_Val )
	   {//copy _Val through [_First, _Last)
	   for (; _First != _Last; ++_First)
		   *_First = _Val;
	   }

inline void_t
   _fill( char_t *_First,char_t *_Last,iint_t _Val )
	   {//copy char _Val through [_First, _Last)
	   type_init( _First,(char_t)_Val,_Last - _First );
	   }

inline void_t
   _fill( byte_t *_First,byte_t *_Last,iint_t _Val )
	   {//copy unsigned char _Val through [_First, _Last)
      type_init( _First,(byte_t)_Val,_Last - _First );
	   }

//-------------------------------------
// Template function _fill_n
//-------------------------------------
template<class _OutIt,class _Diff,class _Ty> inline void_t 
   _fill_n( _OutIt _First,_Diff _Count,const _Ty &_Val )
	   {//copy _val _count times through [_First,...)
	   for (; 0 < _Count; --_Count,++_First)
         *_First = _Val;
	   }

inline void_t 
   _fill_n( char_t *_Dest,size_t _Count,iint_t _Val )
	   {//copy char _Val _Count times through [_Dest, ...)
      type_init( _Dest,(char_t)_Val,_Count );
	   }

inline void_t 
   _fill_n( byte_t *_Dest,size_t _Count,uint_t _Val )
	   {//copy char _Val _Count times through [_Dest, ...)
      type_init( _Dest,(byte_t)_Val,_Count );
	   }

//-------------------------------------
// Template function _lexicographical_compare
//-------------------------------------
template<class _InIt,class _OutIt> inline bool_t 
   _lexicographical_compare( _InIt _First_left,_InIt _Last_left,_OutIt _First_right,_OutIt _Last_right )
	   {//order [_First_left,_Last_left) vs. [first2,last2)
	   for (; _First_left != _Last_left && _First_right != _Last_right; ++_First_left,++_First_right)
		   if (*_First_left < *_First_right)
			   return (true);
		   if (*_First_right < *_First_left)
			   return (false);
	   return (_First_left == _Last_left && _First_right != _Last_right);
	   }

template<class _InIt,class _OutIt,class _Pr> inline bool_t 
   _lexicographical_compare( _InIt _First_left,_InIt _Last_left,_OutIt _First_right,_OutIt _Last_right,_Pr _Pred )
	   {//order [_First_left,_Last_left) vs.[first2,last2) using _Pred
	   for (; _First_left != _Last_left && _First_right != _Last_right; ++_First_left,++_First_right)
		   if (_Pred( *_First_left,*_First_right ))
			   return (true);
		   if (_Pred( *_First_right,*_First_left ))
			   return (false);
	   return (_First_left == _Last_left && _First_right != _Last_right);
	   }

//-------------------------------------
// Template function reverse
//-------------------------------------
template<class _BidIt> inline	void_t
   _reverse( _BidIt _First,_BidIt _Last )
	   {//reverse elements in [_First, _Last)
	   _reverse_opt( _First,_Last,_iter_cat( _First ));
	   }

template<class _BidIt> inline void_t
   _reverse_opt( _BidIt _First,_BidIt _Last,Bidirectional_iterator_tag )
	   {//reverse elements in [_First, _Last), bidirectional iterators
	   for (; _First != _Last && _First != --_Last; ++_First)
		   _iter_swap( _First,_Last );
	   }

//-------------------------------------
// Template function rotate
//-------------------------------------
template<class _FwdIt> inline _FwdIt 
   _rotate( _FwdIt _First,_FwdIt _Mid,_FwdIt _Last )
	   {//rotate [_First, _Last)
	   if (_First != _Mid && _Mid != _Last)
		   {//rotate and compute new first iterator
		   _rotate_opt( _First,_Mid,_Last,_iter_cat( _First ));
		   _advance( _First,_distance( _Mid,_Last ));
		   }
	   return (_First);
	   }

template<class _FwdIt> inline void_t 
   _rotate_opt( _FwdIt _First,_FwdIt _Mid,_FwdIt _Last,Forward_iterator_tag )
	   {//rotate [_First, _Last), forward iterators
	   for (_FwdIt _Next = _Mid; ; )
		   {//swap [_First, ...) into place
		   _iter_swap( _First,_Next );

		   if (++_First == _Mid)
			   if (++_Next == _Last)
				   break; //done, quit
			   else
				   _Mid = _Next; //mark end of next interval
		   else 
         if (++_Next == _Last)
			   _Next = _Mid; //wrap to last end
		   }
	   }

template<class _BidIt> inline	void_t 
   _rotate_opt( _BidIt _First,_BidIt _Mid,_BidIt _Last,Bidirectional_iterator_tag )
	   {//rotate [_First, _Last), bidirectional iterators
	   _reverse( _First,_Mid );
	   _reverse( _Mid,_Last );
	   _reverse( _First,_Last );
	   }

template<class _RanIt,class _Diff,class _Ty> inline void_t 
   _rotate_opt( _RanIt _First,_RanIt _Mid,_RanIt _Last,_Diff*,_Ty* )
	   {	// rotate [_First, _Last), random-access iterators
	   _Diff _Shift = _Mid - _First;
	   _Diff _Count = _Last - _First;

	   for (_Diff _Factor = _Shift; _Factor != 0; )
		   {	// find subcycle count as GCD of shift count and length
		   _Diff _Tmp = _Count % _Factor;
		   _Count = _Factor;
		   _Factor = _Tmp;
		   }

	   if (_Count < _Last - _First)
		   for (; 0 < _Count; --_Count)
			   {//rotate each subcycle
			   _RanIt _Hole = _First + _Count;
			   _RanIt _Left = _Hole;
			   _RanIt _Next = _Left + _Shift == _Last ? _First : _Left + _Shift;
			   for (; ; )
				   {//percolate elements back around subcycle
				   _iter_swap( _Left,_Next );
				   _Left = _Next;
				   _Next = _Shift < _Last - _Next ? _Next + _Shift : _First + (_Shift - (_Last - _Next));
				   if (_Next == _Hole)
					   break;
				   }
			   }
	   }

template<class _RanIt> inline	void_t 
   _rotate_opt( _RanIt _First,_RanIt _Mid,_RanIt _Last,Random_access_iterator_tag )
	   {//rotate [_First, _Last), random-access iterators
	   _rotate_opt( _First,_Mid,_Last,_dist_type( _First ),_val_type( _First ));
	   }

//-------------------------------------
// Template selector
//-------------------------------------
template<class _Ty> inline const _Ty & 
   max( const _Ty &_Lft,const _Ty &_Rht = _Ty())
	   {//return larger of _Lft and _Rht
	   return (_Lft < _Rht ? _Rht : _Lft);
	   }

template<class _Ty,class _Pr> inline const _Ty & 
   max_opt( const _Ty &_Lft,const _Ty &_Rht,_Pr _Pred )
	   {//return larger of _Lft and _Rht using _Pred
	   return (_Pred( _Lft,_Rht ) ? _Rht : _Lft);
	   }

template<class _Ty> inline const _Ty & 
   min( const _Ty &_Lft,const _Ty &_Rht = _Ty())
	   {//return smaller of _Lft and _Rht
	   return (_Rht < _Lft ? _Rht : _Lft);
	   }

template<class _Ty,class _Pr> inline const _Ty & 
   min_opt( const _Ty &_Lft,const _Ty &_Rht,_Pr _Pred )
	   {//return smaller of _Lft and _Rht using _Pred
	   return (_Pred( _Rht,_Lft ) ? _Rht : _Lft);
	   }

template<class _Ty> inline const _Ty & 
   med( const _Ty &_Lft,const _Ty &_Rht,const _Ty &_Med = _Ty())
	   {//return median of _Lft, _Rht and _Med
	   if(_Lft < _Med)
		   return _Med < _Rht ? _Med : _Lft < _Rht ? _Rht : _Lft;
	   else
		   return _Lft < _Rht ? _Lft : _Med < _Rht ? _Rht : _Med;
	   };

template<class _Ty,class _Pr> inline const _Ty & 
   med_opt( const _Ty &_Lft,const _Ty &_Rht,const _Ty &_Med,_Pr _Pred )
	   {//return median of _Lft, _Rht and _Med using _Pred
	   if(Pred( _Lft,_Med ))
		   return Pred( _Med,_Rht ) ? _Med : Pred( _Lft,_Rht ) ? _Rht : _Lft;
	   else
		   return Pred( _Lft,_Rht ) ? _Lft : Pred( _Med,_Rht ) ? _Rht : _Med;
	   };

_LDS_END
#pragma pack(pop)
#endif//UTILIZE_H
/*
All rights reserved. Consult your license regarding permissions and restrictions.
*/
