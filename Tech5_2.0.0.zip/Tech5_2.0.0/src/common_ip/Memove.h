#pragma		once
#ifndef		MEMOVE_H
#define		MEMOVE_H

//	Use project headers
#include		"Eskdef.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
    Functions to initialize memory
**************************************/
template<class _Ty> inline void_t
   _mem_init_up( _Ty *_Dst,_Ty _Val,size_t _Count )
	   {//initialize memory by _Val
      for(register size_t i = 0; i < _Count; i++) _Dst[i] = _Val;
	   }

inline void_t
   _mem_init( void_t *_Dst,size_t _Count,quad_t _Val = 0 )
	   {//initialize _Count bytes default
         _mem_init_up((quad_p)_Dst,quad_t(_Val),_Count >> 3 );
      if(_Count & 7)
         _mem_init_up((byte_p)_Dst +           (_Count & ~7 ),
                                   byte_t(_Val),_Count &  7 );
	   }

template<class _Ty> inline void_t
   type_init( _Ty *_Dst,_Ty _Val,size_t _Count )
	   {//initialize buffer
      _mem_init_up( _Dst,_Val,_Count );
	   }

template<class _Ty> inline void_t
   type_init( _Ty *_Dst,size_t _Count )
	   {//initialize memory default
      _mem_init( _Dst,_Count*sizeof(_Ty));
	   }

/**************************************
      Functions to move memory
**************************************/
template<class _Ty> inline void_t
   _mem_move_dn( _Ty *_Dst,const _Ty *_Src,size_t _Count )
	   {//copies _Ty's left to right
      for(register size_t i = _Count; i--;) _Dst[i] = _Src[i]; 
	   }

template<class _Ty> inline void_t
   _mem_move_up( _Ty *_Dst,const _Ty *_Src,size_t _Count )
	   {//copies _Ty's right to left
      for(register size_t i = 0; i < _Count; i++) _Dst[i] = _Src[i]; 
	   }

inline void_p
   _mem_move( void_t *_Dst,const void_t *_Src,size_t _Count )
	   {//moves _Count bytes from _Src to _Dst, return _Dst
      byte_t *_Ptd = (byte_p)_Dst + (_Count & ~7),
             *_Pts = (byte_p)_Src + (_Count & ~7);

      if(_Dst > _Src)
         {//copy left to right
         _mem_move_dn((byte_p)_Ptd,(byte_p)_Pts,_Count &  7 );
         _mem_move_dn((quad_p)_Dst,(quad_p)_Src,_Count >> 3 );
         }
      else
      if(_Dst < _Src)
         {//copy right to left
         _mem_move_up((quad_p)_Dst,(quad_p)_Src,_Count >> 3 );
         _mem_move_up((byte_p)_Ptd,(byte_p)_Pts,_Count &  7 );
         }
      return _Dst;
	   }

template<class _Ty> inline void_p
   type_copy( _Ty *_Dst,const _Ty *_Src,size_t _Count )
	   {//copies _Ty's between buffers, return _Dst
      return (void_p)_mem_move( _Dst,_Src,_Count*sizeof(_Ty));
	   }

inline void_p 
   byte_copy( void_t *_Dst,const void_t *_Src,size_t _Count )
	   {//copies _Count bytes from _Src to _Dst, return _Dst
      return (void_p)_mem_move( _Dst,_Src,_Count );
	   }

inline void_p 
   byte_copy_jump( void_t *_Dst,const void_t *_Src,size_t _Count )
	   {//copies bytes between buffers and jump to the end
      return (byte_p)_mem_move( _Dst,_Src,_Count ) + _Count;
	   }

_ESK_END
#pragma pack(pop)
#endif//MEMOVE_H

