#pragma		once
#ifndef		BIMMAP_H
#define		BIMMAP_H

//	Header project file
#include		"Bitree.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
      Template class Map_traits
**************************************/
template<class _Kt,class _Ty,class _Pr,class _Alloc,bool_t _Mfl>
class Map_traits
	{//traits required to make _Tree behave like a map
public:
	typedef _Kt key_type;
	typedef Pair<_Kt,_Ty> item_t;
	typedef _Pr key_compare;
   typedef key_compare value_compare;
	typedef _Alloc allocator_type;

   typedef typename _Alloc::template rebind<item_t>::other					_Alty;
	typedef typename _Alty ::template rebind<item_t>::other::pointer		_ITptr;
	typedef typename _Alty ::template rebind<item_t>::other::reference	_IReft;

	enum
		{//make multi parameter visible as an enum constant
      MULTIF = _Mfl
      };

   Map_traits() : Comp()
	   {//construct with specified predicate
	   }

   Map_traits( key_compare _Pred ) : Comp(_Pred)
	   {//construct with specified predicate
	   }

   bool_t 
      operator()( const item_t &_Lft,const item_t &_Rht ) const
         {//test if _Lft precedes _Rht by comparing just keys
         return (comp( _Lft.First,_Rht.First ));
         }

	template<class _Tl,class _Tr> static const _Kt &
      _Kfn( const Pair<_Tl,_Tr> &_Val )
		   {//extract key from element value
		   return (_Val.First);
		   }

	_Pr      //the comparator predicate for keys
      Comp;

   };//Map_traits

/**************************************
			Template class Map
**************************************/
template<class _Kt,class _Ty,class _Pr = Greater<_Kt>,class _Alloc = Allocator<Pair<_Kt,_Ty> > >
class Map : public Tree<Map_traits<_Kt,_Ty,_Pr,_Alloc,false> >
	{//ordered red-black tree of {key, mapped} values, unique keys
public:
   typedef             Map<_Kt,_Ty,_Pr,_Alloc>         Self_t;
   typedef Tree<Map_traits<_Kt,_Ty,_Pr,_Alloc,false> > Base_t;
   typedef _Kt key_type;
   typedef _Ty mapped_type;
   typedef _Ty referent_type;	// retained
   typedef _Pr key_compare;
   typedef typename Base_t::value_compare value_compare;
   typedef typename Base_t::allocator_type allocator_type;
   typedef typename Base_t::diff_t diff_t;
   typedef typename Base_t::pointer pointer;
   typedef typename Base_t::const_pointer const_pointer;
   typedef typename Base_t::reference reference;
   typedef typename Base_t::const_reference const_reference;
   typedef typename Base_t::iterator iterator;
   typedef typename Base_t::const_iterator const_iterator;
   typedef typename Base_t::reverse_iterator reverse_iterator;
   typedef typename Base_t::const_reverse_iterator const_reverse_iterator;
   typedef typename Base_t::item_t item_t;

   Map(): Base_t( key_compare(),allocator_type())
      {//construct empty map from defaults
      }

   explicit Map( const allocator_type &_Al ) : Base_t( key_compare(),_Al )
      {//construct empty map from defaults, allocator
      }

   Map( const Self_t &_Rht ) : Base_t( _Rht,_Rht._Getal())
      {//construct map by copying _Rht
      }

   Map( const Self_t &_Rht,const allocator_type &_Al ) : Base_t( _Rht,_Al )
      {//construct map by copying _Rht, allocator
      }

   explicit Map(const key_compare& _Pred) : Base_t( _Pred,allocator_type())
      {//construct empty map from comparator
      }

   Map( const key_compare& _Pred,const allocator_type &_Al ) : Base_t( _Pred,_Al )
      {//construct empty map from comparator and allocator
      }

   template<class _Iter>
   Map( _Iter _First,_Iter _Last ) : Base_t( key_compare(),allocator_type())
      {//construct map from [_First, _Last), defaults
      Base_t::insert( _First,_Last );
      }

   template<class _Iter>
   Map( _Iter _First,_Iter _Last,const key_compare &_Pred ) : Base_t( _Pred,allocator_type())
      {//construct map from [_First, _Last), comparator
      Base_t::insert( _First,_Last );
      }

   template<class _Iter>
   Map( _Iter _First, _Iter _Last,const key_compare &_Pred,const allocator_type &_Al ) : Base_t( _Pred,_Al )
      {//construct map from [_First, _Last), comparator, and allocator
      Base_t::insert( _First,_Last );
      }

	Self_t& 
      operator=( const Self_t &_Rht )
		   {//assign by copying _Right
		   Base_t::operator=(_Rht);
		   return (*this);
		   }

	void_t 
      swap( Self_t &_Rht )
		   {	// exchange contents with non-movable _Right
		   Base_t::swap( _Rht );
		   }

   mapped_type& 
      operator[]( const key_type &_Keyval )
         {//find element matching _Keyval or insert with default mapped
         iterator _Where = this->lower_bound( _Keyval );
         if(_Where == this->end() || this->_Getcomp()( _Keyval,this->_Key( _Where._Mynode())))
            {
	         _Where = this->insert( _Where,Pair<key_type,mapped_type>( _Keyval,mapped_type()));
            }
         return (_Where->second);
         }

	};//Map

template<class _Kt,class _Ty,class _Pr,class _Alloc> inline void_t 
   swap( Map<_Kt,_Ty,_Pr,_Alloc> &_Lft,Map<_Kt,_Ty,_Pr,_Alloc> &_Rht)
	   {//swap _Lft and _Rht maps
	   _Lft.swap(_Rht);
	   }

/**************************************
			Template class Mipmap
**************************************/
template<class _Kt,class _Ty,class _Pr = Greater<_Kt>,class _Alloc = Allocator<Pair<_Kt,_Ty> > >
class Mipmap : public Tree<Map_traits<_Kt,_Ty,_Pr,_Alloc,true> >
	{//ordered red-black tree of {key, mapped} values, non-unique keys
public:
	typedef          Mipmap<_Kt,_Ty,_Pr,_Alloc>        Self_t;
	typedef Tree<Map_traits<_Kt,_Ty,_Pr,_Alloc,true> > Base_t;
	typedef _Kt key_type;
	typedef _Ty mapped_type;
	typedef _Ty referent_type;	// retained
	typedef _Pr key_compare;
	typedef typename Base_t::value_compare value_compare;
	typedef typename Base_t::allocator_type allocator_type;
	typedef typename Base_t::diff_t diff_t;
	typedef typename Base_t::pointer pointer;
	typedef typename Base_t::const_pointer const_pointer;
	typedef typename Base_t::reference reference;
	typedef typename Base_t::const_reference const_reference;
	typedef typename Base_t::iterator iterator;
	typedef typename Base_t::const_iterator const_iterator;
	typedef typename Base_t::reverse_iterator reverse_iterator;
	typedef typename Base_t::const_reverse_iterator const_reverse_iterator;
	typedef typename Base_t::item_t item_t;

   Mipmap() : Base_t( key_compare(),allocator_type())
      {//construct empty map from defaults
      }

   explicit Mipmap( const allocator_type &_Al ) : Base_t( key_compare(),_Al )
      {//construct empty map from defaults, allocator
      }

   Mipmap( const Self_t &_Rht) : Base_t( _Rht,_Rht.Getal())
      {//construct map by copying _Right
      }

   Mipmap( const Self_t &_Rht,const allocator_type &_Al ) : Base_t( _Rht,_Al )
		{//construct map by copying _Right, allocator
		}

   explicit Mipmap( const key_compare &_Pred ) : Base_t( _Pred,allocator_type())
      {//construct empty map from comparator
      }

   Mipmap( const key_compare &_Pred,const allocator_type &_Al ) : Base_t( _Pred,_Al )
      {//construct empty map from comparator and allocator
      }

   template<class _Iter>
   Mipmap( _Iter _First,_Iter _Last ) : Base_t( key_compare(),allocator_type())
      {//construct map from [_First, _Last), defaults
      Base_t::insert( _First,_Last );
      }

   template<class _Iter>
   Mipmap( _Iter _First,_Iter _Last,const key_compare &_Pred ) : Base_t( _Pred,allocator_type())
      {//construct map from [_First, _Last), comparator
      Base_t::insert( _First,_Last );
      }

   template<class _Iter>
   Mipmap( _Iter _First,_Iter _Last,const key_compare &_Pred,const allocator_type &_Al ) : Base_t( _Pred,_Al )
      {//construct map from [_First, _Last), comparator, and allocator
      Base_t::insert( _First,_Last );
      }

   Self_t& operator=( const Self_t &_Rht )
      {//assign by copying _Right
      Base_t::operator=(_Rht);
      return (*this);
      }

   void_t 
      swap( Self_t &_Rht )
         {//exchange contents with non-movable _Right
         Base_t::swap( _Rht );
         }

   iterator 
      insert( const item_t &_Val )
         {//insert a {key, mapped} value
         return (Base_t::insert(_Val).First);
         }

   iterator 
      insert( const_iterator _Where,const item_t &_Val )
         {//insert a {key, mapped} value, with hint
         return (Base_t::insert(_Where, _Val));
         }

   template<class _Iter> void_t 
      insert( _Iter _First,_Iter _Last )
         {//insert [_First, _Last), arbitrary iterators
         Base_t::insert( _First, _Last );
         }

	};//Mipmap

template<class _Kt,class _Ty,class _Pr,class _Alloc> inline void_t
   swap(Mipmap<_Kt,_Ty,_Pr,_Alloc> &_Lft,Mipmap<_Kt,_Ty,_Pr,_Alloc> &_Rht)
      {//swap _Lft and _Rht Mipmaps
      _Lft.swap(_Rht);
      }

_ESK_END
#pragma pack(pop)
#endif//BIMMAP_H
