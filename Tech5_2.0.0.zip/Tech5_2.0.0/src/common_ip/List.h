#pragma		once
#ifndef		LIST_H
#define		LIST_H

//	Header project file
#include		"Except.h"
#include		"Memory.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
		   Template class List
**************************************/
template<class _Ty,class _Alloc>
class List_nod
	{//base class for List_ptr to hold allocator _Alnod
protected:
			  struct _Node;
	friend  struct _Node;
	typedef typename _Alloc::template rebind<_Node>::other::pointer _Geptr;
			  typename _Alloc::template rebind<_Node>::other			 _Alnod;

	struct _Node
		{//list node
		_Geptr 
         Next,
			Prev;
		_Ty	 
         Nval;
		};

	List_nod( _Alloc _Al ) : _Alnod(_Al)
		{//construct allocator from _Al
		}

	};

template<class _Ty,class _Alloc>
class List_ptr : public List_nod<_Ty,_Alloc>
	{//base class for List_val to hold allocator _Alptr
protected:
	typedef typename List_nod<_Ty,_Alloc>::_Node _Node;
	typedef typename _Alloc::template rebind<_Node >::other::pointer _Ndptr;
			  typename _Alloc::template rebind<_Ndptr>::other			  _Alptr;

	List_ptr(_Alloc _Al)	: List_nod<_Ty,_Alloc>(_Al),_Alptr(_Al)
		{//construct base, use allocator from _Al
		}
	};

template<class _Ty,class _Alloc>
class List_val : public List_ptr<_Ty,_Alloc>
	{//base class for list to hold allocator _Alval
public:
	typedef typename _Alloc::template rebind<_Ty>::other _Alty;

	List_val( _Alloc _Al = _Alloc()) : List_ptr<_Ty,_Alloc>(_Al),_Alval(_Al)
		{//construct allocator from _Al
		}

	_Alty //allocator object for values
      _Alval;
	};

template<class _Ty,class _Ax = Allocator<_Ty> >
class List : public List_val<_Ty,_Ax>
	{//bidirectional linked list
public:
	typedef List    <_Ty, _Ax> Self_t;
	typedef List_val<_Ty, _Ax> Base_t;
	typedef typename Base_t::_Alty _Alloc;

protected:
	typedef typename List_nod<_Ty,_Ax>::_Geptr _Geptr;
	typedef typename List_nod<_Ty,_Ax>::_Node  _Node;

	typedef typename _Alloc::template rebind<_Node >::other::pointer	 _Ndptr;
	typedef typename _Alloc::template rebind<_Ndptr>::other::reference _Ndref;
	typedef typename _Alloc::reference											 _Vlref;

	static _Ndref 
      next_node( _Ndptr _Pnode )
		   {//return reference to successor pointer in node
		   return ((_Ndref)(*_Pnode).Next);
		   }

	static _Ndref 
      prev_node( _Ndptr _Pnode )
		   {//return reference to predecessor pointer in node
		   return ((_Ndref)(*_Pnode).Prev);
		   }

	static _Vlref 
      nval_node( _Ndptr _Pnode )
		   {//return reference to value in node
		   return ((_Vlref)(*_Pnode).Nval);
		   }

public:
	typedef _Alloc allocator_type;
   typedef typename _Alloc::item_t item_t;
	typedef typename _Alloc::diff_t diff_t;
	typedef typename _Alloc::pointer pointer;
   typedef typename _Alloc::reference reference;
	typedef typename _Alloc::const_pointer const_pointer;
	typedef typename _Alloc::const_reference const_reference;

			 class Const_iterator;
	friend class Const_iterator;

   class Const_iterator : public Bidit<_Ty,diff_t,const_pointer,const_reference>
	   {//iterator for nonmutable list
   public:
      typedef Const_iterator Self_t;
	   typedef Bidirectional_iterator_tag iterator_category;

      typedef typename _Alloc::item_t item_t;
	   typedef typename _Alloc::diff_t diff_t;
      typedef typename _Alloc::pointer _Tptr;
	   typedef typename _Alloc::const_pointer pointer;
	   typedef typename _Alloc::const_reference reference;

	   Const_iterator() : Cursor()
		   {//construct with null node pointer
		   }

	   Const_iterator( _Ndptr _Pnode ) : Cursor(_Pnode)
		   {//construct with node pointer _Pnode
		   }

	   reference 
         operator*() const
		      {//return designated value
		      return (nval_node(Cursor));
		      }

	   pointer 
         operator->() const
		      {//return pointer to class object
		      return (&**this);
		      }

	   Self_t& 
         operator++()
		      {//preincrement
		      Cursor = next_node(Cursor);
		      return (*this);
		      }

	   Self_t 
         operator++(int)
		      {//postincrement
		      Self_t _Tmp = *this;
		      ++*this;
		      return (_Tmp);
		      }

	   Self_t& 
         operator--()
		      {//predecrement
		      Cursor = prev_node(Cursor);
		      return (*this);
		      }

	   Self_t 
         operator--(int)
		      {	// postdecrement
		      Self_t _Tmp = *this;
		      --*this;
		      return (_Tmp);
		      }

	   bool_t 
         operator==(const Self_t& _Right) const
		      {//test for iterator equality
		      return (Cursor == _Right.Cursor);
		      }

	   bool_t 
         operator!=(const Self_t& _Right) const
		      {//test for iterator inequality
		      return (!(*this == _Right));
		      }

	   _Ndptr 
         node_ptr() const
		      {//return node pointer
		      return (Cursor);
		      }

   private:
	   _Ndptr //pointer to node
         Cursor;

	   };//Const_iterator

			 class Iterator;
	friend class Iterator;

   class Iterator	: public Const_iterator
	   {//iterator for mutable list
   public:
      typedef Iterator Self_t;
	   typedef Const_iterator Base_t;
	   typedef Bidirectional_iterator_tag iterator_category;

      typedef typename _Alloc::item_t item_t;
	   typedef typename _Alloc::diff_t diff_t;
	   typedef typename _Alloc::pointer pointer;
	   typedef typename _Alloc::reference reference;

	   Iterator()
		   {//construct with null node
		   }

 	   Iterator(_Ndptr _Pnode) : Base_t(_Pnode)
		   {//construct with node pointer _Pnode
		   }

	   reference 
         operator*() const
		      {//return designated value
		      return ((reference)**(Base_t *)this);
		      }

	   pointer
         operator->() const
		      {//return pointer to class object
		      return (&**this);
		      }

	   Self_t& 
         operator++()
		      {//preincrement
		      ++(*(Base_t *)this);
		      return (*this);
		      }

	   Self_t 
         operator++(int)
		      {//postincrement
		      Self_t _Tmp = *this;
		      ++*this;
		      return (_Tmp);
		      }

	   Self_t& 
         operator--()
		      {//predecrement
		      --(*(Base_t *)this);
		      return (*this);
		      }

	   Self_t 
         operator--(int)
		      {//postdecrement
		      Self_t _Tmp = *this;
		      --*this;
		      return (_Tmp);
		      }

	   };//Iterator

   typedef Const_iterator const_iterator;
   typedef Iterator iterator;

   typedef Reverse_iterator<const_iterator> const_reverse_iterator;
	typedef Reverse_iterator<iterator> reverse_iterator;

	List() : Base_t(),Head(buy_node()),Size()
		{//construct empty list
		}

	explicit List( const _Alloc &_Al ) : Base(_Al),Head(buy_node()),Size()
		{//construct empty list, allocator
		}

	explicit List( size_t _Count ) : Base(),Head(buy_node()),Size()
		{//construct list from _Count * _Ty()
		construct_n( _Count,_Ty());
		}

	List( size_t _Count,const _Ty &_Val ) : Base(),Head(buy_node()),Size()
		{//construct list from _Count * _Val
		construct_n( _Count,_Val );
		}

	List( size_t _Count,const _Ty &_Val,const _Alloc &_Al) : Base(_Al),Head(buy_node()),Size()
		{//construct list, allocator from _Count * _Val
		construct_n( _Count,_Val );
		}

	List( const Self_t &_Right ) : Base(_Right._Alval),Head(buy_node()),Size()
		{// construct list by copying _Right
		try{
			insert( begin(),_Right.begin(),_Right.end());
			}
		catch(...)
			{
			tidy();
			throw;
			}
		}

	template<class _Iter>
	List( _Iter _First,_Iter _Last ) : Base(),Head(buy_node()),Size()
		{//construct list from [_First, _Last)
		construct( _First,_Last,Iter_cat(_First));
		}

	template<class _Iter>
	List( _Iter _First,_Iter _Last,const _Alloc &_Al) : Base(_Al),Head(buy_node()),Size()
		{//construct list, allocator from [_First, _Last)
		construct( _First,_Last,Iter_cat(_First));
		}

	template<class _Iter> void_t
      construct( _Iter _Count,_Iter _Val,Int_iterator_tag )
		   {//construct list from _Count * _Val
		   construct_n((size_t)_Count,(_Ty)_Val );
		   }

	template<class _Iter> void_t
      construct( _Iter _First,_Iter _Last,Input_iterator_tag )
		   {//construct list from [_First, _Last), input iterators
		   try{
			   insert( begin(),_First,_Last );
			   }
		   catch(...)
			   {
			   tidy();
			   throw;
			   }
		   }

	void_t 
      construct_n( size_t _Count,const _Ty &_Val )
		   {//construct from _Count * _Val
		   try{
			   insert_n( begin(),_Count,_Val );
			   }
		   catch(...)
			   {
			   tidy();
			   throw;
			   }
		   }

	~List() _THROW
		{//destroy the object
		tidy();
		}

	Self_t& 
      operator=( const Self_t &_Right )
		   {//assign _Right
		   if (this != &_Right)
			   assign( _Right.begin(),_Right.end());
		   return (*this);
		   }

	iterator 
      begin() _THROW
		   {//return iterator for beginning of mutable sequence
		   return (iterator( next_node( Head )));
		   }

	const_iterator 
      begin() const _THROW
		   {//return iterator for beginning of nonmutable sequence
		   return (const_iterator( next_node( Head )));
		   }

	iterator 
      end() _THROW
		   {//return iterator for end of mutable sequence
		   return (iterator( Head ));
		   }

	const_iterator 
      end() const _THROW
		   {//return iterator for end of nonmutable sequence
		   return (const_iterator( Head ));
		   }

	reverse_iterator 
      rbegin() _THROW
		   {//return iterator for beginning of reversed mutable sequence
		   return (reverse_iterator( end()));
		   }

	const_reverse_iterator 
      rbegin() const _THROW
		   {//return iterator for beginning of reversed nonmutable sequence
		   return (const_reverse_iterator( end()));
		   }

	reverse_iterator 
      rend() _THROW
		   {//return iterator for end of reversed mutable sequence
		   return (reverse_iterator( begin()));
		   }

	const_reverse_iterator 
      rend() const _THROW
		   {//return iterator for end of reversed nonmutable sequence
		   return (const_reverse_iterator( begin()));
		   }

	void_t 
      resize( size_t _Newsize )
		   {//determine new length, padding with _Ty() elements as needed
		   resize( _Newsize,_Ty());
		   }

	void_t 
      resize( size_t _Newsize,_Ty _Val )
		   {//determine new length, padding with _Val elements as needed
		   if (Size < _Newsize)
			   insert_n( end(),_Newsize - Size,_Val );
		   else
			   while( _Newsize < Size )
				   pop_back();
		   }

	size_t 
      size() const _THROW
		   {//return length of sequence
		   return (Size);
		   }

	size_t 
      max_size() const _THROW
		   {//return maximum possible length of sequence
		   return (this->_Alval.max_size());
		   }

	bool_t 
      empty() const _THROW
		   {//test if sequence is empty
		   return (size() == 0);
		   }

	allocator_type 
      get_allocator() const _THROW
		   {//return allocator object for values
		   return (this->_Alval);
		   }

	reference 
      front()
		   {//return first element of mutable sequence
		   return (*begin());
		   }

	const_reference 
      front() const
		   {//return first element of nonmutable sequence
		   return (*begin());
		   }

	reference 
      back()
		   {//return last element of mutable sequence
		   return (*(--end()));
		   }

	const_reference 
      back() const
		   {//return last element of nonmutable sequence
		   return (*(--end()));
		   }

	void_t 
      push_front( const _Ty &_Val )
		   {//insert element at beginning
		   layout( begin(),_Val );
		   }

	void_t 
      pop_front()
		   {//erase element at beginning
		   erase( begin());
		   }

	void_t 
      push_back( const _Ty &_Val )
		   {//insert element at end
		   layout( end(),_Val );
		   }

	void_t 
      pop_back()
		   {//erase element at end
		   erase(--end());
		   }

	template<class _Iter> void_t
      assign( _Iter _First,_Iter _Last )
		   {//assign [_First, _Last)
		   assign( _First,_Last,Iter_cat(_First));
		   }

	template<class _Iter> void_t
      assign( _Iter _Count,_Iter _Val,Int_iterator_tag )
		   {//assign _Count * _Val
		   assign_n((size_t)_Count,(_Ty)_Val );
		   }

	template<class _Iter> void_t
      assign( _Iter _First,_Iter _Last,Input_iterator_tag )
		   {//assign [_First, _Last), input iterators
		   clear();
		   insert( begin(),_First,_Last );
		   }

	void_t 
      assign( size_t _Count,const _Ty &_Val )
		   {//assign _Count * _Val
		   assign_n( _Count,_Val );
		   }

	iterator 
      insert( iterator _Where,const _Ty &_Val )
		   {//insert _Val at _Where
		   layout(  _Where,_Val );
		   return(--_Where);
		   }

	void_t 
      layout( iterator _Where,const _Ty &_Val )
		   {//insert _Val at _Where
		   _Ndptr _Pnode	 =				 _Where.node_ptr();
		   _Ndptr _Newnode = buy_node( _Pnode,prev_node(_Pnode),_Val );

		   incsize(1);	prev_node( _Pnode ) = _Newnode;
						   next_node( prev_node( _Newnode)) = _Newnode;
		   }

	void_t 
      insert( iterator _Where,size_t _Count,const _Ty &_Val )
		   {//insert _Count * _Val at _Where
		   insert_n( _Where,_Count,_Val );
		   }

	template<class _Iter> void_t
      insert( iterator _Where,_Iter _First,_Iter _Last )
		   {//insert [_First, _Last) at _Where
		   layout( _Where,_First,_Last,Iter_cat(_First));
		   }

	template<class _Iter> void_t
      layout( iterator _Where,_Iter _Count,_Iter _Val,Int_iterator_tag )
		   {//insert _Count * _Val at _Where
		   insert_n( _Where,(size_t)_Count,(_Ty)_Val );
		   }

	template<class _Iter> void_t
      layout( iterator _Where,_Iter _First,_Iter _Last,Input_iterator_tag )
		   {//insert [_First, _Last) at _Where, input iterators
		   size_t 
            _Num = 0;

		   try{
			   for (; _First != _Last; ++_First,++_Num )
				   layout( _Where,*_First );
			   }
		   catch(...)
			   {
			   for(; 0 < _Num; --_Num)
				   {//undo inserts
				   iterator _Before = _Where;
				   erase( --_Before );
				   }
			   throw;
			   }
		   }

	template<class _Iter> void_t
      layout( iterator _Where,_Iter _First,_Iter _Last,Forward_iterator_tag )
		   {//insert [_First, _Last) at _Where, forward iterators
		   _Iter 
            Next = _First;

		   try{
			   for (; _First != _Last; ++_First)
				   layout( _Where,*_First );
			   }
		   catch(...)
			   {
			   for (; Next != _First; ++Next)
				   {//undo inserts
				   iterator _Before = _Where;
				   erase( --_Before );
				   }
			   throw;
			   }
		   }

	iterator 
      erase( iterator _Where )
		   {//erase element at _Where
		   _Ndptr _Pnode = (_Where++).node_ptr();
		   if (_Pnode != Head)
			   {	// not list head, safe to erase
			   next_node( prev_node(_Pnode)) = next_node(_Pnode);
			   prev_node( next_node(_Pnode)) = prev_node(_Pnode);
			   this->_Alnod.destroy(_Pnode);
			   this->_Alnod.deallocate(_Pnode,1 );
			   --Size;
			   }
		   return (_Where);
		   }

	iterator 
      erase( iterator _First,iterator _Last )
		   {//erase [_First, _Last)
		   if (_First == begin() && _Last == end())
			   {//erase all and return fresh iterator
			   clear();
			   return (end());
			   }
		   else
			   {//erase subrange
			   while( _First != _Last )
				   _First = erase(_First);
			   return (_Last);
			   }
		   }

	void_t 
      clear() _THROW
		   {//erase all
		   _Ndptr _Pnext;
		   _Ndptr _Pnode = next_node( Head );
							    next_node( Head ) = Head;
							    prev_node( Head ) = Head;	Size = 0;

		   for(; _Pnode != Head; _Pnode = _Pnext)
			   {//delete an element
			   _Pnext =   next_node( _Pnode );
			   this->_Alnod.destroy( _Pnode );
			   this->_Alnod.deallocate( _Pnode,1 );
			   }
		   }

	void_t 
      swap( Self_t &_Right )
		   {//exchange contents with _Right
		   if (this->_Alval == _Right._Alval)
			   {//same allocator, swap control information
			   swap( Head,_Right.Head );
			   swap( Size,_Right.Size );
			   }
		   else
			   {//different allocator, do splices
			   iterator _Where = begin();
			   splice(  _Where,_Right );
			   _Right.splice( _Right.begin(),*this,_Where,end());
			   }
		   }

	void_t 
      splice( iterator _Where, Self_t &_Right )
		   {//splice all of _Right at _Where
		   if (this != &_Right && !_Right.empty())
			   {//worth splicing, do it
			   spliceing( _Where,_Right,_Right.begin(),_Right.end(),_Right.Size );
			   }
		   }

	void_t 
      splice( iterator _Where,Self_t &_Right,iterator _First )
		   {//splice _Right [_First, _First + 1) at _Where
		   if (_First != _Right.end())
			   {//element exists, try splice
			   iterator _Last = _First;
					    ++_Last;

			   if (this != &_Right || (_Where != _First && _Where != _Last))
				   spliceing( _Where,_Right,_First,_Last,1 );
			   }
		   }

	void_t 
      splice( iterator _Where,Self_t &_Right,iterator _First,iterator _Last )
		   {//splice _Right [_First, _Last) at _Where
		   if (_First != _Last && (this != &_Right || _Where != _Last))
			   {//worth splicing, do it
			   size_t 
               _Count = 0;
			   if (this == &_Right)
				   ;//just rearrange this list
			   else 
			   if (_First == _Right.begin() && _Last == _Right.end())
				   _Count = _Right.Size;	// splice in whole list
			   else
				   _distance( _First,_Last,_Count );	// splice in partial list

			   spliceing( _Where,_Right,_First,_Last,_Count );
			   }
		   }

	void_t 
      remove( const _Ty &_Val )
		   {//erase each element matching _Val
		   iterator _Last = end();
		   for(iterator _First = begin(); _First != _Last; )
			   if (*_First == _Val)
				     _First = erase( _First );
			   else
				   ++_First;
		   }

	template<class _Pr> void_t 
      remove_if( _Pr _Pred )
		   {//erase each element satisfying _Pr
		   iterator _Last = end();
		   for(iterator _First = begin(); _First != _Last; )
			   if ( _Pred( *_First ))
				     _First = erase( _First );
			   else
				   ++_First;
		   }

	void_t 
      unique()
		   {//erase each element matching previous
		   if (2 <= Size)
			   {//worth doing
			   iterator _First = begin();
			   iterator _After = _First;

			   for (++_After; _After != end(); )
				   if(*_First == *_After)
					    _After = erase( _After );
				   else
					    _First = _After++;
			   }
		   }

	template<class _Pr> void_t
      unique(_Pr _Pred)
		   {//erase each element satisfying _Pred with previous
		   if (2 <= Size)
			   {//worth doing
			   iterator _First = begin();
			   iterator _After = _First;

			   for(++_After; _After != end(); )
				   if(_Pred( *_First,*_After ))
					   _After = erase( _After );
				   else
					   _First = _After++;
			   }
		   }

	void_t 
      merge( Self_t &_Right )
		   {//merge in elements from _Right, both ordered by operator<
		   if (&_Right != this)
			   {//safe to merge, do it
			   iterator _First1 = begin(), _Last1 = end();
			   iterator _First2 = _Right.begin(), _Last2 = _Right.end();
			   AFFIRM( _First1 < _Last1 );
			   AFFIRM( _First2 < _Last2 );

			   while(_First1 != _Last1 && _First2 != _Last2)
				   if (*_First2 < *_First1)
					   {	// splice in an element from _Right
					   iterator _Mid2 = _First2;
					   spliceing( _First1,_Right,_First2,++_Mid2,1 );
					   _First2 = _Mid2;
					   }
				   else
					   ++_First1;

			   if (_First2 != _Last2)
				   spliceing( _Last1,_Right,_First2,_Last2,_Right.Size );	// splice remainder of _Right
			   }
		   }

	template<class _Pr> void_t 
      merge( Self_t &_Right,_Pr _Pred )
		   {//merge in elements from _Right, both ordered by _Pred
		   if (&_Right != this)
			   {	// safe to merge, do it
			   iterator _First1 = begin(), _Last1 = end();
			   iterator _First2 = _Right.begin(), _Last2 = _Right.end();

			   while(_First1 != _Last1 && _First2 != _Last2)
				   if (_Pred( *_First2, *_First1 ))
					   {//splice in an element from _Right
					   iterator _Mid2 = _First2;
					   spliceing( _First1,_Right,_First2,++_Mid2,1 );
					   _First2 = _Mid2;
					   }
				   else
					   ++_First1;

			   if (_First2 != _Last2)
				   spliceing( _Last1,_Right,_First2,_Last2,_Right.Size );	// splice remainder of _Right
			   }
		   }

	void_t 
      sort()
		   {// order sequence, using operator<
		   if (2 <= Size)
			   {//worth sorting, do it
			   const size_t 
               _MAXBINS = 25;
			   Self_t 
               _Templist(this->_Alval),
				   _Binlist[_MAXBINS + 1];
			   size_t 
               _Maxbin = 0;

			   while(!empty())
				   {//sort another element, using bins
				   _Templist.spliceing(_Templist.begin(), *this, begin(),++begin(),1,true );	// don't invalidate iterators

				   size_t 
                   _Bin;
				   for(_Bin = 0; _Bin < _Maxbin && !_Binlist[_Bin].empty(); ++_Bin )
					   {	// merge into ever larger bins
					   _Binlist[_Bin].merge(_Templist);
					   _Binlist[_Bin].swap(_Templist);
					   }
				   if (_Bin == _MAXBINS)
					   _Binlist[_Bin - 1].merge( _Templist );
				   else
					   {	// spill to new bin, while they last
					   _Binlist[_Bin].swap( _Templist );
					   if (_Bin == _Maxbin)
						   ++_Maxbin;
					   }
				   }

			   for (size_t _Bin = 1; _Bin < _Maxbin; ++_Bin)
				   _Binlist[_Bin].merge( _Binlist[_Bin - 1] );	// merge up
			   splice( begin(),_Binlist[_Maxbin - 1] );	// result in last bin
			   }
		   }

	template<class _Pr> void_t
      sort(_Pr _Pred)
		   {	// order sequence, using _Pred
		   if (2 <= Size)
			   {	// worth sorting, do it
			   const size_t 
               _MAXBINS = 25;
			   Self_t 
               _Templist(this->_Alval), 
				   _Binlist[_MAXBINS + 1];
			   size_t 
               _Maxbin = 0;

			   while(!empty())
				   {//sort another element, using bins
				   _Templist.spliceing(_Templist.begin(), *this, begin(),++begin(),1,true );	// don't invalidate iterators

				   size_t 
                   _Bin;
				   for(_Bin = 0; _Bin < _Maxbin && !_Binlist[_Bin].empty(); ++_Bin)
					   {//merge into ever larger bins
					   _Binlist[_Bin].merge( _Templist,_Pred );
					   _Binlist[_Bin].swap( _Templist );
					   }

				   if (_Bin == _MAXBINS)
					   _Binlist[_Bin - 1].merge( _Templist,_Pred );
				   else
					   {//spill to new bin, while they last
					   _Binlist[_Bin].swap( _Templist );
					   if (_Bin == _Maxbin)
						   ++_Maxbin;
					   }
				   }

			   for (size_t _Bin = 1; _Bin < _Maxbin; ++_Bin)
				   _Binlist[_Bin].merge(_Binlist[_Bin - 1],_Pred );	// merge up
			   splice(begin(), _Binlist[_Maxbin - 1]);	// result in last bin
			   }
		   }

	void_t 
      reverse() _THROW
		   {//reverse sequence
		   if (2 <= Size)
			   {//worth doing
			   iterator _Last = end();
			   for(iterator Next = ++begin(); Next != _Last; )
				   {//move next element to beginning
				   iterator _Before = Next;
				   spliceing( begin(),*this,_Before,++Next,1 );
				   }
			   }
		   }

	void_t 
      spliceing( iterator _Where,Self_t &_Right,iterator _First,iterator _Last,size_t _Count )
		   {//splice _Right [_First, _Last) before _Where
		   if (this->_Alval == _Right._Alval)
			   {//same allocator, just relink
			   if (this != &_Right)
				   {//splicing from another list, adjust counts
				   incsize(_Count);
				   _Right.Size -= _Count;
				   }
			   next_node( prev_node( _First.node_ptr())) = _Last.node_ptr();
			   next_node( prev_node( _Last.node_ptr()))  = _Where.node_ptr();
			   next_node( prev_node( _Where.node_ptr())) = _First.node_ptr();
			   _Ndptr _Pnode = prev_node( _Where.node_ptr());
			   prev_node( _Where.node_ptr()) = prev_node(_Last.node_ptr());
			   prev_node( _Last.node_ptr()) = prev_node(_First.node_ptr());
			   prev_node( _First.node_ptr()) = _Pnode;
			   }
		   else
			   {//different allocator, copy nodes then erase source
			   insert( _Where,_First,_Last );
			   _Right.erase( _First,_Last );
			   }
		   }

	void_t 
      assign_n( size_t _Count,const _Ty &_Val )
		   {//assign _Count *_Val
		   _Ty _Tmp = _Val;
		   clear();
		   insert_n( begin(),_Count,_Tmp );
		   }

	_Ndptr 
      buy_node()
		   {//allocate a head node and set links
		   _Ndptr 
            _Pnode = this->_Alnod.allocate(1);
		   iint_t 
            _Linkcnt = 0;

		   try{
			   this->_Alptr.construct( &next_node(_Pnode ),_Pnode );
			   ++_Linkcnt;
			   this->_Alptr.construct( &prev_node(_Pnode ),_Pnode );
			   }
		   catch(...)
			   {
			   if (0 < _Linkcnt)
				   this->_Alptr.destroy( &next_node(_Pnode ));
			   this->_Alnod.deallocate( _Pnode,1 );
			   throw;
			   }
		   return (_Pnode);
		   }

	_Ndptr 
      buy_node( _Ndptr Next,_Ndptr Prev,const _Ty &_Val )
		   {//allocate a node and set links and value
		   _Ndptr 
            _Pnode = this->_Alnod.allocate(1);
		   iint_t 
            _Linkcnt = 0;

		   try{
			   this->_Alptr.construct( &next_node(_Pnode ),Next );
			   ++_Linkcnt;
			   this->_Alptr.construct( &prev_node(_Pnode ),Prev );
			   ++_Linkcnt;
			   this->_Alval.construct( &nval_node(_Pnode ),_Val );
			   }
		   catch(...)
			   {
			   if (1 < _Linkcnt)
				   this->_Alptr.destroy( &prev_node(_Pnode ));
			   if (0 < _Linkcnt)
				   this->_Alptr.destroy( &next_node(_Pnode ));
			   this->_Alnod.deallocate( _Pnode,1 );
			   throw;
			   }
		   return (_Pnode);
		   }

	void_t 
      tidy()
		   {//free all storage
         if (Head != Null)
            {
		      clear();
		      this->_Alptr.destroy( &next_node(Head ));
		      this->_Alptr.destroy( &prev_node(Head ));
		      this->_Alnod.deallocate( Head,1 );
		      Head = Null;
            }
		   }

	void_t 
      insert_n( iterator _Where,size_t _Count,const _Ty &_Val )
		   {//insert _Count * _Val at _Where
		   size_t _Countsave = _Count;

		   try{
			   for (; 0 < _Count; --_Count)
				   layout( _Where,_Val );
			   }
		   catch(...)
			   {
			   for (; _Count < _Countsave; ++_Count)
				   {//undo inserts
				   iterator _Before = _Where;
				   erase( --_Before);
				   }
			   throw;
			   }
		   }

	void_t 
      incsize( size_t _Count )
		   {//alter element count, with checking
		   if (max_size() - Size < _Count)
			   throw Length_error( "list<T> too long" );
		   Size += _Count;
		   }

	static void_t 
      _xran()
		   {//report an out_of_range error
		   throw Out_of_range( "invalid list<T> subscript" );
		   }

	static void_t 
      _xinvarg()
		   {//report an invalid_argument error
		   throw Invalid_argument( "invalid list<T> argument" );
		   }
 
	_Ndptr    //pointer to head node
      Head;
	size_t    //number of elements
      Size;
	};

template<class _Ty,class _Ax>
class Move_operation_category<List<_Ty,_Ax> >
	{// list implements a performant swap
public:
	typedef Swap_move_tag _Move_cat;
	};

template<class _Ty,class _Alloc> inline void_t
   swap( List<_Ty,_Alloc> &_Left,List<_Ty,_Alloc> &_Right )
	   {//swap _Left and _Right lists
	   _Left.swap( _Right );
	   }

template<class _Ty,class _Alloc> inline bool_t
   operator==( const List<_Ty, _Alloc> &_Left,const List<_Ty,_Alloc> &_Right )
	   {//test for list equality
	   return (_Left.size() == _Right.size() && equal( _Left.begin(),_Left.end(),_Right.begin()));
	   }

template<class _Ty,class _Alloc> inline bool_t
   operator!=( const List<_Ty,_Alloc> &_Left,const List<_Ty,_Alloc> &_Right)
	   {//test for list inequality
	   return (!(_Left == _Right));
	   }

template<class _Ty,class _Alloc> inline bool_t
   operator<( const List<_Ty, _Alloc> &_Left,const List<_Ty,_Alloc> &_Right )
	   {//test if _Left < _Right for lists
	   return (lexicographical_compare( _Left.begin(),_Left.end(),_Right.begin(),_Right.end()));
	   }

template<class _Ty,class _Alloc> inline bool_t
   operator>( const List<_Ty,_Alloc> &_Left,const List<_Ty,_Alloc> &_Right )
	   {//test if _Left > _Right for lists
	   return (_Right < _Left);
	   }

template<class _Ty,class _Alloc> inline bool_t
   operator<=( const List<_Ty,_Alloc> &_Left,const List<_Ty,_Alloc> &_Right )
	   {//test if _Left <= _Right for lists
	   return (!(_Right < _Left));
	   }

template<class _Ty,class _Alloc> inline bool_t
   operator>=( const List<_Ty,_Alloc> &_Left,const List<_Ty,_Alloc> &_Right )
	   {//test if _Left >= _Right for lists
	   return (!(_Left < _Right));
	   }

_ESK_END
#pragma pack(pop)
#endif//LIST_H
