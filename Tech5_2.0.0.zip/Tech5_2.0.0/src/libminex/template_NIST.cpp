/*
   template_INCITS_378.cpp - implement the  function for work with template in 
   INCITS 378 format
   NOTE: in fact this implemetation have some restriction in compare of 
   INCITS 378 format (according to MINEX requirements):
   - number of view always = 1
   - impression type 0 or 2
   - CBEFF Product Identifier Owner always = 0
   - CBEFF Product Identifier Type  always = 0
   - Capture Equipment Compliance   always = 0
   - Capture Equipment ID           always = 0
   - resolution is always 197 pixel/cm (500 DPI)
   - the minutiae quality is always set 0
   - maximum number of minutiae 128
   - the template doesn't have the extented data block
   
*/
#include <assert.h>
#include <memory.h>

#include "libMinexFull.h"
#include "template_NIST.h"
#include "integrTrig.h"

#define DEF_RESOLUTION           197         // 500 dpi
#define FORMAT_ID                0x464D5200
#define STANDARD_VERSION         0x20323000
#define MAX_NIST_MINUTIAE       255// 128 by standard 


int getAlowsNumMinutiaeNIST(unsigned int numFingers, unsigned int maxSize)
{
   if (numFingers > MAX_FINGERS)
      numFingers = MAX_FINGERS;
   maxSize -= sizeof (NIST_header) +  sizeof (NIST_extendedHeader) + sizeof (NIST_viewHeader) * numFingers;
   return maxSize / sizeof (NIST_minutiae);
}


int calcNISTtemplSize(unsigned int numFingers, unsigned int numMinutiae[MAX_FINGERS])
{
   if (numFingers > MAX_FINGERS)
      numFingers = MAX_FINGERS;
   int size = sizeof (NIST_header) +  sizeof (NIST_extendedHeader);
   for(unsigned int i = 0; i < numFingers; i++)
      size += sizeof (NIST_viewHeader) + sizeof (NIST_minutiae) * numMinutiae[i];
   return size;
}

int calcFullNISTtemplSize(unsigned int numFingers)
{
   unsigned int numMinutiae[MAX_FINGERS];
   for(unsigned int i = 0; i < MAX_FINGERS; i++)
      numMinutiae[i] = MAX_NIST_MINUTIAE;
   return calcNISTtemplSize (numFingers, numMinutiae);
}

int getMinNISTtemplateSize(unsigned int numFingers)
{
   unsigned int numMinutiae[MAX_FINGERS];
   for(int i = 0; i < MAX_FINGERS; i++)
      numMinutiae[i] = MIN_MINUTIAE;
   return calcNISTtemplSize (numFingers, numMinutiae);
}

int getNISTtemplateSize(const BYTE *templ)
{
   return swapWORD( ((NIST_header*)templ)->m_length );
}

void setNISTtemplateSize (int templSize, BYTE* templ)
{
   NIST_header *header = (NIST_header*)templ;
   header->m_length = swapWORD (templSize);
}

// check parameters
inline int checkNISTParameters(const RawImage &rawImage, BYTE quality, BYTE *moTemplate)
{
   if (quality > QUAL_EXCELLENT)
      return SME_WRONG_PARAM;
   if (rawImage.finger > FINGPOS_LL)
      return SME_WRONG_PARAM;
   if (rawImage.impression_type != IMPTYPE_LP && rawImage.impression_type != IMPTYPE_NP)
      return SME_IMPRESSION_TYPE;
   if (!moTemplate)
      return SME_WRONG_POINTER;
   if (!rawImage.width || !rawImage.height)
      return SME_IMAGE_SIZE;
   return SME_OK;
}

/*
   fill INCITS 378 header
   certifiedSensor - is capture_Equipment comply with Appendix F IAFIS IQS
                      (should be 0 for PIV certification)
   sensorID - Capture Equipment ID, 12 bits(0 for PIV certification)
*/
inline void fill_NIST_Header(const RawImage &rawImage, BYTE **pos, 
                             int templSize, bool certifiedSensor, 
                             WORD sensorID, unsigned int numFingers)
{
   NIST_header *header = (NIST_header*)*pos;
   header->m_formatID = swapDWORD (FORMAT_ID);
   header->m_version  = swapDWORD (STANDARD_VERSION);
   header->m_length = swapWORD (templSize);
#ifndef PIV_CERTIFICATION
   header->m_PID    = swapDWORD (EXTRACTOR_CBEFF_PID);
   WORD temp = sensorID;
   if(certifiedSensor)
      temp |= 1 << 15; 
   header->m_capture_e = swapWORD(temp);
#endif
   header->m_width  = swapWORD (rawImage.width);
   header->m_height = swapWORD (rawImage.height);
   header->m_resolutionX = swapWORD (DEF_RESOLUTION); 
   header->m_resolutionY = swapWORD (DEF_RESOLUTION);
   header->m_numView = numFingers;
   *pos += sizeof(NIST_header);
}

// fill minutiae information
void fill_NIST_view (BYTE **pos, const RawImage &rawImage, BYTE quality, BYTE numMinutiae,
                         Minutiae minutiae[MAX_MINUTIAE], Frame &frame)
{
   NIST_viewHeader *viewHeader = (NIST_viewHeader*)*pos;
   viewHeader->m_position = rawImage.finger;
   viewHeader->m_viewNumber = 0;
   viewHeader->m_impressionType = rawImage.impression_type;
   viewHeader->m_quality = quality;
   viewHeader->m_numMinutiae = numMinutiae;
   *pos += sizeof(NIST_viewHeader);

   NIST_minutiae *min = (NIST_minutiae*)*pos;
   // fill minutiae
   int  type = 0, angle = 0, add = 0, dx = 0, dy = 0, curX = 0 , curY = 0, x = 0, y = 0;
   bool isTooClose = false;
   int count = 0;
   for (unsigned int i = 0; i < numMinutiae; i++)
   {
      isTooClose = false;                                                           // Eliminate minutiae
      for( unsigned int j = 0; j < i && !isTooClose; j ++ )                         // sitting too close to
         isTooClose = ( dist( ( int )( minutiae[ i ].x - minutiae[ j ].x ),         // one another which is a 
                              ( int )( minutiae[ i ].y - minutiae[ j ].y ) ) < 2 ); // mistake in fingerprint 
                                                                                    // processing
      if( isTooClose ) continue;

      type = (minutiae[count].type == ENDING) ? 
                        ISO_NIST_ENDING : ISO_NIST_BIFURCATION;
      if (type == ISO_NIST_ENDING)
      {
         angle = normAngle(minutiae[count].angle - 180);
         add = (minutiae[count].density + 1) / 4 + 2;
         dx = cosm(add, angle);
         dy = sinm(add, angle);
      }
      else
         dx = dy = 0;
      
      x = minutiae[count].x + frame.left + dx;
      y = minutiae[count].y + frame.top  - dy;
      if      (x <               0) x = 0;
      else if (x >= rawImage.width) x = rawImage.width   - 1;
      if      (y <                0) y = 0;
      else if (y >= rawImage.height) y = rawImage.height - 1;

      min[count].m_x       = x & 0x3fff;
      min[count].m_x      += (type & 0x3) << 14;
      min[count].m_y       = y & 0x3fff;
      min[count].m_x = swapWORD(min[count].m_x);
      min[count].m_y = swapWORD(min[count].m_y);
#ifndef PIV_CERTIFICATION
      min[count].m_quality = minutiae[count].prob;
#endif
      if (minutiae[count].angle > 0)
         minutiae[count].angle -= 360;
      min[count].m_angle = -minutiae[count].angle / 2;
      count++;
   }
   *pos += sizeof(NIST_minutiae) * count;
   // correct number of minutiae
   viewHeader->m_numMinutiae = count;
}

// build INCITS 378 template
int buildNISTtemplate (unsigned int numFingers, const RawImage *rawImage, 
                       BYTE *quality,
                       BYTE *moTemplate,
                       unsigned int *numMinutiae,
                       Minutiae minutiae[MAX_FINGERS][MAX_MINUTIAE], 
                       Frame *srcFrame, 
                       bool certifiedSensor, WORD sensorID,
                       unsigned int *size)
{
   // check parameters
   int result = SME_OK;
   if (numFingers > MAX_FINGERS)
      numFingers = MAX_FINGERS;
   Frame frame[MAX_FINGERS];
   memset(frame, 0, sizeof(frame));
   if (srcFrame)
      memcpy(frame, srcFrame, sizeof(frame));

   for(unsigned int i = 0; i < numFingers; i++)
   {
      if ((result = checkNISTParameters (rawImage[i], quality[i], moTemplate)) != SME_OK) 
         return result;
      if (numMinutiae[i] > MAX_NIST_MINUTIAE)
         numMinutiae[i] = MAX_NIST_MINUTIAE;
   }
   int templSize = calcNISTtemplSize(numFingers, numMinutiae);
   memset (moTemplate, 0, templSize);
   
   BYTE *pos = (BYTE*)moTemplate;
   // fill INCITS 378 header
   fill_NIST_Header (rawImage[0], &pos, templSize, certifiedSensor, sensorID, numFingers);
   
   if (numFingers > MAX_FINGERS) 
      numFingers = MAX_FINGERS;
   // fill finger view
   for(unsigned int i = 0; i < numFingers; i++)
      fill_NIST_view (&pos, rawImage[i], quality[i], numMinutiae[i], minutiae[i], frame[i]);

   templSize = (int)(pos - moTemplate) + sizeof (NIST_extendedHeader);
   setNISTtemplateSize(templSize, moTemplate);
   if (size)
      *size = templSize; 

   return SME_OK;
}

bool checkNISTtemplate (unsigned int &numFingers, const BYTE *moTemplate, float &kx, float &ky)
{
   // check parameters
   if (!moTemplate)
      return false;
   NIST_header *header = (NIST_header*)moTemplate;
   if (header->m_formatID != swapDWORD (FORMAT_ID) ||
       header->m_version  != swapDWORD (STANDARD_VERSION))  
      return false;
#ifdef PIV_CERTIFICATION
   if (header->m_PID || header->m_capture_e)
      return false;
   if (header->m_resolutionX != swapWORD (DEF_RESOLUTION) || 
      header->m_resolutionY != swapWORD (DEF_RESOLUTION))
      return false;
   if (header->m_numView != 1)
      return false;
#endif
   kx = (float)swapWORD(header->m_resolutionX) / DEF_RESOLUTION;
   ky = (float)swapWORD(header->m_resolutionY) / DEF_RESOLUTION;
   
   // check all views
   if (numFingers > header->m_numView) 
      numFingers = header->m_numView;
   BYTE *pos = (BYTE*)moTemplate + sizeof (NIST_header);
   for(unsigned int i = 0; i < numFingers; i++)
   {
       NIST_viewHeader *viewHeader = (NIST_viewHeader*)pos;
       if (viewHeader->m_position > FINGPOS_LL) 
          return false;
       if (viewHeader->m_viewNumber != 0)
          return false;
   #ifdef PIV_CERTIFICATION
       if (viewHeader->m_impressionType != IMPTYPE_LP && 
           viewHeader->m_impressionType != IMPTYPE_NP)
          return false;
   #else
       int impression_type = viewHeader->m_impressionType;
       if ((impression_type < IMPTYPE_LP || impression_type > IMPTYPE_NR) 
            && impression_type != IMPTYPE_SW)
          return false;
   #endif
       if (viewHeader->m_quality > QUAL_EXCELLENT)
          return false;
       if (viewHeader->m_numMinutiae > MAX_NIST_MINUTIAE)
          return false;
       pos += sizeof (NIST_viewHeader);
       pos += sizeof (NIST_minutiae) * viewHeader->m_numMinutiae;
   }
    return true;
}

   // read minutiae information
bool readNISTminutiae (BYTE **pos, BYTE numMinutiae,
                      Minutiae minutiae[MAX_MINUTIAE],
                      WORD width, WORD height, float kx, float ky)
{
   if (!pos)
      return false;
   NIST_minutiae *min = (NIST_minutiae*)*pos;
   int type = 0;
   for (unsigned int i = 0; i < numMinutiae; i++)
   {
      minutiae[i].x = swapWORD (min[i].m_x);
      type = (minutiae[i].x >> 14) & 0x3;
      minutiae[i].x = minutiae[i].x & 0x3fff;
      minutiae[i].x = int(minutiae[i].x / kx + 0.5);
      minutiae[i].y = swapWORD (min[i].m_y) & 0x3fff;;
      minutiae[i].y = int(minutiae[i].y / ky + 0.5);
#ifndef PIV_CERTIFICATION
      minutiae[i].prob  =  min[i].m_quality;
#endif
      switch (type)
      {
      case ISO_NIST_OTHER:
      case ISO_NIST_ENDING:
         minutiae[i].type = ENDING;
         break;
      case ISO_NIST_BIFURCATION:
         minutiae[i].type = BIFURCATION;
         break;
      default:
         assert(false);
      }
      if (minutiae[i].x >= width ||
          minutiae[i].y >= height)
          return false;
      minutiae[i].angle = normAngle(-min[i].m_angle * 2);
   }
   *pos += sizeof(NIST_minutiae) * numMinutiae;
   return true;
}


int readNISTtemplate (unsigned int &numFingers,
                       const BYTE *moTemplate, BYTE numMinutiae[MAX_FINGERS],
                       Minutiae minutiae[MAX_FINGERS][MAX_MINUTIAE], 
                       WORD &width, WORD &height, BYTE quality[MAX_FINGERS],
                       BYTE finger[MAX_FINGERS])
{
   if (numFingers > MAX_FINGERS)
      numFingers = MAX_FINGERS;
   if (!moTemplate)
      return SME_WRONG_POINTER;
   
   try
   {
      // check parameters
      float kx = 1, ky = 1;
      if (!checkNISTtemplate (numFingers, moTemplate, kx, ky))
         return SME_PARSE_TEMPL;

      // read image size
      NIST_header *header = (NIST_header*)moTemplate;
      width  = swapWORD (header->m_width);
      height = swapWORD (header->m_height);
      BYTE *pos = (BYTE*)moTemplate + sizeof (NIST_header);
      for(unsigned int i = 0; i < numFingers; i++)
      {
         // read quality and finger position
         NIST_viewHeader *viewHeader = (NIST_viewHeader*)pos;
         quality[i] = viewHeader->m_quality;
         finger[i]  = viewHeader->m_position;
         pos += sizeof(NIST_viewHeader);     
         // read minutiae
         numMinutiae[i] = viewHeader->m_numMinutiae;
         if (!readNISTminutiae (&pos, numMinutiae[i], minutiae[i], width, height, kx, ky))
            return SME_PARSE_TEMPL;
      }
   }
   catch(...)
   {
      return SME_UNKN_ERR;
   }
   return SME_OK;
}

int getNumFingers_NIST (unsigned int &numFingers, const BYTE *moTemplate, FINGERS *finger)
{
   if (numFingers > MAX_FINGERS)
      numFingers = MAX_FINGERS;
   if (!moTemplate || !finger)
      return SME_WRONG_POINTER;
   try
   {
      // check parameters
      float kx = 1, ky = 1;
      if (!checkNISTtemplate (numFingers, moTemplate, kx, ky))
         return SME_PARSE_TEMPL;

      // read image size
      NIST_header *header = (NIST_header*)moTemplate;
      BYTE *pos = (BYTE*)moTemplate + sizeof (NIST_header);
      for(unsigned int i = 0; i < numFingers; i++)
      {
         // read quality and finger position
         NIST_viewHeader *viewHeader = (NIST_viewHeader*)pos;
         finger[i]  = (FINGERS)viewHeader->m_position;
         pos += sizeof(NIST_viewHeader) + sizeof (NIST_minutiae) * viewHeader->m_numMinutiae;     
      }
   }
   catch(...)
   {
      return SME_UNKN_ERR;
   }
   return SME_OK;

}
