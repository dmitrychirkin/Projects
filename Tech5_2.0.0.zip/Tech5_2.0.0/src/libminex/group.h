/*
   group.h - declare the Group class that keep information 
                    about minutiae group

*/
#ifndef  INCITS_378_GROUP_H_
#define INCITS_378_GROUP_H_

#include <memory.h>
#include "coreSdk.h"
#include "libminex.h"

//////////////////////////////////////////////////////////////////////////
//
//                     GROUP CLASS DECLARATION
//
//////////////////////////////////////////////////////////////////////////

class Group
{
   public:
   int   m_num[MAX_MINEX_MINUTIAE];
   float m_similarity;
   int   m_numItems;     
   int   m_angle;          // rotation angle for combine probe and gallery 
                           // minutiae of the group
   int   m_mainGroupSize;

public:
                 Group       ()               { clear();  }
                 operator int()               { return m_numItems; }
   inline Group& operator=   ( const Group& g);
 
   inline void clear();
   inline void setMainGroupSize();
   inline int  getMainGroupSize();
   inline int  getProbe (int i);
   inline int  getGallery (int i);
   inline bool getPair (int i, int &numP, int &numG);
   inline void add (int numP, int numG, float similarity );
   inline int  checkPresence( int numP, int numG );
   inline bool find (int numP, int numG);
   inline bool findProbe (int numP);
   inline bool isExtendableWith( int iP, int iG, int jP, int jG );
//   inline int  findProbeEx ( int numP );
   inline bool findGallery (int numG);
//   inline int  findGalleryEx ( int numG );
//   inline bool removePair( int i );
};


//////////////////////////////////////////////////////////////////////////
//
//                     GROUP CLASS INLINE IMPLEMENTATION 
//
//////////////////////////////////////////////////////////////////////////

Group& Group::operator= (const Group& g)
{
   this->m_numItems      = g.m_numItems;
   this->m_mainGroupSize = g.m_mainGroupSize;
   this->m_angle         = g.m_angle;
   this->m_similarity    = g.m_similarity;
   memcpy( this->m_num, &g.m_num, sizeof( this->m_num[ 0 ] ) * m_numItems );
   return *this;
}
void   Group::clear()
{
   this->m_numItems      = 0;
   this->m_mainGroupSize = 0;
   this->m_angle         = 0;
   this->m_similarity    = 0;
}

void   Group::add (int numP, int numG, float similarity )
{
   m_similarity += similarity; 
   m_num [m_numItems] = (numP << 8) + numG;
   m_numItems++;
}

bool   Group::find (int numP, int numG)
{
   int val = (numP << 8) + numG;
   for(int i = 0; i < m_numItems; i++)
   {
      if (m_num[i] == val)
         return true;
   }
   return false;
}

bool   Group::findProbe (int numP)
{
   for (int i = 0; i < m_numItems; i++)
   {
      if ( m_num[i] >> 8 == numP ) return true;
   }
   return false;
}


bool   Group::findGallery (int numG)
{
   for (int i = 0; i < m_numItems; i++)
   {
      if ( ( m_num[i] & 0xff ) == numG ) return true;
   }
   return false;
}

int    Group::getProbe (int i)
{
   if( i < 0 || i > m_numItems ) return -1;
   return (m_num[i] >> 8);
}
int    Group::getGallery (int i)
{
   if( i < 0 || i > m_numItems ) return -2;
   return (m_num[i] & 0xff);
}
bool   Group::getPair (int i, int &numP, int &numG)
{
   if (i >= m_numItems)
      return false;
   numP = m_num[i] >> 8;
   numG = m_num[i] & 0xff;
   return true;
}

void   Group::setMainGroupSize()
{
   m_mainGroupSize = m_numItems;
}
int    Group::getMainGroupSize()
{
   return m_mainGroupSize;
}
bool   Group::isExtendableWith( int iP, int iG, int jP, int jG )
{
   int curP = 0, curG = 0;
   bool hasNode = false;
   for (int i = 0; i < m_numItems; i++)
   {
      curP = m_num[i] >> 8;
      curG = m_num[i] & 0xff;
      if( !hasNode && curP == iP && curG == iG ) hasNode = true;
      if(             curP == jP || curG == jG ) return false;
   }
   return hasNode;
}
// keep information about set of minutiae numbers
class NumMinutiaeStore
{
public:
   int    m_numItems;     
   // arrays of minutiae numbers
   BYTE   m_index[MAX_MINEX_MINUTIAE];  

public:
   NumMinutiaeStore() { m_numItems = 0; }

   inline void add  (  int i  )
   {
      if( i < 0 || i >= MAX_MINEX_MINUTIAE ) return;
      m_index[ i ] = 1;
      m_numItems++;
   }

   inline void clear(         ) { 
      m_numItems = 0; 
      memset( m_index, 0, MAX_MINEX_MINUTIAE  );
   }

   inline bool find ( int num )
   {
      if( num < 0 || num >= MAX_MINEX_MINUTIAE ) return false;
      return ( m_index[ num ] != 0 );
   }
};
#endif // INCITS_378_GROUP_H_
