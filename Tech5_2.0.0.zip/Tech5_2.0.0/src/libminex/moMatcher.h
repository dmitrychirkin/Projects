/*
   moMatcher.h - declare the MoMatcher class that is supposed to compare the 
                 fingerprints on minutiae only information (x, y, angle, type)

*/
#ifndef MO_MATCHER_H_
#define MO_MATCHER_H_

#define BEST_DISTANCE 100
//#define FAST_LEN

#include <list>
#include <vector>
#include <algorithm>
#include <functional>
#include "scoreMinexParameters.h"

using namespace std;

#include "coreSdk.h"
#include "libMinexFull.h"
#include "minutiaePair.h"
#include "group.h"

// default search parameters
#define DEF_MAX_MO_ANGLE         80 
#define DEF_MAX_MO_DISTANCE      1024

#define MAX_NEIGHBOURS           8
#define MIN_TOPOLOGY_SIM        -5   // minimum topology similarity  for two minutiae
#define MIN_REL_TOPOLOGY_SIM     1   // minimum of reliable topology similarity
                                     //                        for two minutiae
#define GROUP_ANGLE_TOL         22   // tolerance for group angle, degree
#define LOCAL_CHECK_RADIUS      50   // radius for local check the neighbors minutiae

#pragma pack (push, 1)
struct Minutiae378
{
   int      x;				            // x position from top-left corner, pixels
   int      y;				            // y position from top-left corner, pixels
   int      angle;                  // direction (clockwise from OX axis),
                                    // degree (-180...180)
   MINUTIAE_TYPE  type;		   		// type

   Minutiae378& operator= (Minutiae378& min)
   {
      x     = min.x;
      y     = min.y;
      angle = min.angle;
      type  = min.type;

      return *this;
   }
};

struct Neighbour
{
   int m_position;
   int m_dx;
   int m_dy;
   int m_direction;
};

struct Neighbours
{
   int       m_num;
   Neighbour m_neighbour[MAX_NEIGHBOURS];
};

//#ifdef NEW_NEIGHBOURS

struct NewNeighbour
{
   int m_dir;
   int m_ori;
   int m_dis;
   int m_index  :8;
   int m_weight :8;
//   int m_direction;
};

struct Neighbourhood 
{
   int            m_num;
   NewNeighbour   m_neighbour[MAX_NEIGHBOURS];

   int            m_minIndex;
   int            m_radius;
   bool           m_isByCore;
   bool           m_isByDelta;
   bool           m_isDiverged;
};
//#endif


struct Frame378
{
	int left;
	int right;
	int top;
	int bottom;
};
#pragma pack (pop)



class MoMatcher
{
   // search parameters
   int         m_maxMinAngle;      // minutiae angle tolerance, degree
   int         m_maxDistance;      // minutiae displacement tolerance,%
   int         m_maxAngle;         // fingerprint rotation angle tolerance, degree
//   int         m_maxDisp;          // fingerprint displacement tolerance, pixels
//   int         m_maxDispEx;        // = m_maxDisp + ddisp(m_maxDisp)     
//   int         m_maxDispEx2;       // = m_maxDispEx * m_maxDispEx
   int         m_maxGroupAngle;    
   // minutiae data
   BYTE        m_numMinutiae[2];   // number of minutiae
   WORD        m_width[2];         // image width
   WORD        m_height[2];        // image height
   Frame378    m_frame[2];         // the smallest frame around the 
                                   // all minutiae
   BYTE        m_quality[2];       // image quality 
   // minutiae array
   Minutiae378  m_minutiae[2][MAX_MINEX_MINUTIAE];  

   // minutiae neighbours
   //Neighbours   m_minNeighbours[2][MAX_MINEX_MINUTIAE];  
   // minutiae pair arrays 
   MinutiaePair m_pairs[2][MAX_MINEX_MINUTIAE][MAX_MINEX_MINUTIAE];
   // topology error for all possible minutiae pairs
   float        m_topologySim [MAX_MINEX_MINUTIAE][MAX_MINEX_MINUTIAE];
   float        m_topologyMax [2][MAX_MINEX_MINUTIAE];
   float        m_topologyAvg;
//#ifdef NEW_NEIGHBOURS
   Neighbourhood  m_minNeighbourhood[2][MAX_MINEX_MINUTIAE];  
//#endif
   //MinutiaePairLen  m_pairLength[2][MAX_MINEX_MINUTIAE * MAX_MINEX_MINUTIAE / 2 ];
   //int              m_farIndex[2];
   //int              m_closeIndex[2];
   //int              m_pairLenCount[2];
   // group container
   vector<Group> m_groups;
   vector < MinutiaePairLen > m_pairLen[2];
   vector < MinutiaePairLen > m_pairLenFar[2];
   //vector < MinutiaePairEx  > m_bestPairs;
   // vector of pairs for expand group
   vector<int> m_fitMinutiae;//, m_oppositeMinutiae, m_perpMinutiae;

   // data for work with current group 
   // current group
   Group       m_curGroup;
   // current minutiae (gallery minutiae after rotate and shift 
   // combine the gallery minutiae with probe minutiae
   Minutiae378 m_curMinutiae[MAX_MINEX_MINUTIAE];  
   // the frame around current minutiae
   Frame378    m_curFrame[2];   
   // exclude probe and galery minutiae
   NumMinutiaeStore m_exclude[2];
   bool        m_quick;       // quick matching
   float       m_minTopology;
   // current distance tolerance
   int         *m_curDdist;

public:
   MoMatcher();
   ~MoMatcher();
   // load probe template
   void loadProbe (BYTE numMinutiae, Minutiae minutiae[MAX_MINUTIAE], WORD width, WORD height, BYTE quality)
   { 
      loadtemplate (0, numMinutiae, minutiae, width, height, quality); 
   }

   // load gallery template
   void loadGallery (BYTE numMinutiae, Minutiae minutiae[MAX_MINUTIAE], WORD width, WORD height, BYTE quality)
   { 
      loadtemplate (1, numMinutiae, minutiae, width, height, quality); 
   }

   // compare templates
   bool match (MatchResult &result);
   // set matching parameters
   void setParameters ( int maxAngle    = DEF_MAX_MO_ANGLE, 
                        int maxDistance = DEF_MAX_MO_DISTANCE )
   {
      m_maxAngle    = maxAngle;
      m_maxDistance = maxDistance;
   }
private:
   // load template
   void loadtemplate (int index, BYTE numMinutiae, Minutiae minutiae[MAX_MINUTIAE], WORD width, WORD height, BYTE quality);
   // get frame around minutiae
   void getFrame(Frame378 &frame, BYTE num, Minutiae378 *min);
   // fill information about all pairs
   void fillPairsArray (int index);
   // fill pairs length array
   void fillPairsLenArray (int index, int minDist, int maxDist);
   void setPair           (int index, int num1, int num2, int dist, int angle, int angleDif, int angle1, int angle2)
   {
      MinutiaePair &pair = m_pairs[index][num1][num2];
      pair.m_dist     = dist;
      pair.m_angle    = angle;
      pair.m_angleDif = angleDif;
      pair.m_angle1   = angle1;
      pair.m_angle2   = angle2;
   }
   // check if two pairs are similar
   inline bool compPairs (MinutiaePair &p1, MinutiaePair &p2, float *err = NULL);
   // compare all pairs and form group of similar pairs
   void buildGroups ( bool isRel );
   inline void add2Group(int iP, int jP, int iG, int jG);
   // calculate maximum similarity for all found groups
   void calcAllGroupScore(MatchResult &matchRes);
   // calculate similarity index for current minutiae group
   int calcGroupScore();
   // calculate similarity of probe and transferred minutiae group
   int calcScore();
   // add in the current group the minutiae, those locate the similar
   // returns number of added minutiae
   int expandCurGroup(int xc[2], int yc[2]);
   // perform the one pass of the expand current group of minutiae pairs
   // perform the one pass of the expand current group of minutiae pairs
   int passExpandCurGroup(int maxDist);
   // calculate center of minutiae group for current group
   bool calcGroupCenters(Group &g, Minutiae378 *min1, Minutiae378 *min2, int xc[2], int yc[2]);
   /*
      calculate angle rotation for combine probe and gallery minutiae for 
      current group
      reliable - if true, only minutia, those far enough from center 
                 are used in calculation
   */
   bool calcRotationAngle(Group &g, int &angle, bool reliable, int xc[2], int yc[2]);
   // rotate and shift the gallery minutiae to combine with probe minutiae
   bool transferMinutiae(Minutiae378 *srcMin, Minutiae378 *dstMin, int num,
                   int xc[2], int yc[2], int angle);
   // find minutiae those behind the image of another fingerprint
   void findExclude(int num, Minutiae378 *min, Frame378 &frame, 
                    NumMinutiaeStore &exclude);
   // find minutiae those behind the image for both probe and gallery minutiae
   void findExcludeBoth(int xc[2], int yc[2]);
   // inflate frame around minutiae to distance tolerance 
   void expandBothFrame(int xc[2], int yc[2]);
   void expandFrame(WORD width, WORD height, int xc, int yc, Frame378 &frame);
   /*
      Calculate pair differences (location and angle differences for all 
      possible minutiae pairs from current group)
      *distErr     (output) - average % of distance between minutiae error
      *relAngleErr (output) - average relative angle error  (difAngle)
   */
   void calcPairDif (float &distErr, float &relAngleErr);
   // calculate minutiae angle between pairs from current group
   void calcPairAngleDif(float &angleErr);
   // calculate minutiae position error for the current group
   void calcMinutiaePosDif(float &posErr);

   // calculate minutiae angle differences for all minutiae from current group
   void calcAngleDif(float &angleErr);
   // calculate minutiae type differences for all minutiae from current group
   void calcTypeDif(float &typeErr);
   /*
      check if (iP, iG) or (jP, jG) minutiae pair can be add to the group
      return:
      0 - if cannot
      1 - (iP, iG) can be added  
      2 - (jP, jG) can be added  
   */
   inline int checkGroup ( Group & g, int iP, int jP, int iG, int jG );
   inline int checkGroup ( vector<Group>::iterator p, int iP, int jP, int iG, int jG);
   // check if (nP, nG) minutiae pair can be add to the group
   // return distance tolerance for given distance
   // check the local group (group minutiae those near the given minutiae)
   // for compatible
   bool checkLocalGroup(Group &g);
   // find the best gallery minutiae for given probe minutiae
   // find the best gallery minutiae for given probe minutiae
   int  findBestG(int &pos, int np, bool local, int maxDist);
   // find the best probe minutiae for given gallery minutiae
   int  findBestP(int ng, bool local, int maxDist);
   inline int  getDist2Group(Group &g, int np);
   void removeFoundPair(vector<int> &v, int np, int ng);
   // create the local group that include only minutiae from current group, 
   // those near minutiae number 'numItem'
   void createLocalGroup (int numItem, int maxDist);
   // try to add new minutiae to the local group
   int expandLocalGroup (int maxDist);
   // compare two minutiae by its topology information
   // return penalty

   inline 
   bool compareMinutiae(int nP, int nG);

   float compareMinutiaeTopology   ( int nP, int nG );
   int   findNeighbours            ( int index, int curMinutiae, int maxDist );
   void  fillNeighbours            ( MinutiaePair    pairs[MAX_MINEX_MINUTIAE][MAX_MINEX_MINUTIAE], 
                                     int             numArray[MAX_NEIGHBOURS + 1], 
                                     int             num, 
                                     Neighbourhood & neighbours );
   void  fillTopologySim();

   bool  isCompatibleWithGroup(Group &g, int nP, int nG, float &err, bool local = false, int maxDist = 0);
   /*
   find the best pair for probe neighbour from gallery of neighbours
   return number of best neighbour or -1 if nothing were found
   and penalty for found pair
   */
   void  calcTopologySim( float & topologySim );
   void  prepareScoreParameters(ScoreMinexParameters &param);
   // combine all compatible groups
   void  joinCompatibleGroups();
   void  tryCombineGroups(Group &g1, Group &g2);
   int   getMainGroupSquare();
   void  setTolerance(int tolerance);
   void  calcSizes( ScoreMinexParameters & param );
   // check if either np1 or np2 is near group g (not far then maxDist from one of group's minutiae) 
   inline bool isNearGroup(Group &g, int np, int maxDist);

   inline bool getBestPairs( bool isNear );
//////////////////////////////////////////////////////////////////////////
//
//                    Acceleration tools
//
//////////////////////////////////////////////////////////////////////////
   bool  getGroupFast( MatchResult& matchRes );
   bool  buildGroupTA();
   bool  isSameTemplate( int       index, 
                         BYTE      numMinutiae, 
                         Minutiae  minutiae[MAX_MINUTIAE], 
                         WORD      width, 
                         WORD      height, 
                         BYTE      quality );
   
   // distance tolerance managment functions
   void setDdist(int mode)
   {
      m_curDdist = g_ddist[mode - 1];
   }
   int ddist(int dist)
   {
      if (dist < DDIST_SIZE)
         return m_curDdist[dist];
      return ddist(dist - DDIST_SIZE + 1) + m_curDdist[DDIST_SIZE - 1];
   }
};
#endif // MO_MATCHER_H_
