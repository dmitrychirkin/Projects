#include <stdlib.h>
#include <memory.h>
#include "compressTemplate.h"
#include "integrTrig.h"

#define DEF_QUALITY_THRESHOLD    20        // default threshold for minutiae quality

struct MinutiaeDist : public Minutiae
{
   unsigned int dist;         // distance from minutiae center
   MinutiaeDist() : Minutiae()
   {
      dist = 0;
   }
   MinutiaeDist(const MinutiaeDist& dist)
   {
      *this = dist;
   }
   MinutiaeDist& operator= (const MinutiaeDist& minDist)
   {
      x        = minDist.x;
      y        = minDist.y;
      prob     = minDist.prob;
      angle    = minDist.angle;
      density  = minDist.density;
      type     = minDist.type;
      dist     = minDist.dist; 

      return *this;
   }
   MinutiaeDist& operator= (const Minutiae& min)
   {
      x        = min.x;
      y        = min.y;
      prob     = min.prob;
      angle    = min.angle;
      density  = min.density;
      type     = min.type;

      return *this;
   }
};

int compareVer (const void *arg1, const void *arg2)
{
   Minutiae *min1 = (Minutiae*)arg1;
   Minutiae *min2 = (Minutiae*)arg2;
   if      (min1->prob == min2->prob) return  0;
   else if (min1->prob  < min2->prob) return  1;
   else                               return -1;

}

int compareNum (const void *arg1, const void *arg2)
{
   unsigned int *num1 = (unsigned int*)arg1;
   unsigned int *num2 = (unsigned int*)arg2;
   if      (*num1 == *num2) return  0;
   else if (*num1  < *num2) return -1;
   else                     return  1;

}

int compareDist (const void *arg1, const void *arg2)
{
   MinutiaeDist *dist1 = (MinutiaeDist*)arg1;
   MinutiaeDist *dist2 = (MinutiaeDist*)arg2;
   if      (dist1->dist == dist2->dist) return  0;
   else if (dist1->dist  < dist2->dist) return -1;
   else                                 return  1;

}


int eliminateLowQualityPoints (unsigned int numFingers, unsigned int* numMinutiae, Minutiae minutiae[MAX_FINGERS][MAX_MINUTIAE], 
                               unsigned int maxNum, int qualityThreshold)
{
   unsigned int restNum = 0;
   for(unsigned int i = 0; i < numFingers; i++)
      qsort (&minutiae[i][0], numMinutiae[i], sizeof(Minutiae), compareVer); 

   int minQuality = 0;
   while (++minQuality <= qualityThreshold)
   {
      for(unsigned int i = 0; i < numFingers; i++)
      {
         for(unsigned int j = numMinutiae[i] - 1; j >= 0; j--)
         {
            if (minutiae[i][j].prob >= minQuality)
               break;
            if (--numMinutiae[i] <= MIN_MINUTIAE_NUMBER)
               break;
         }
      }
      restNum = 0;
      for(unsigned int i = 0; i < numFingers; i++)
         restNum += numMinutiae[i];
      if (restNum <= maxNum)
         break;
   }

   return restNum;
}

bool calcGroupCenters (unsigned int numMinutiae, Minutiae *min, int &xc, int &yc)
{
   if (!numMinutiae)
      return false;
   xc = yc = 0;
   for (unsigned int i = 0; i < numMinutiae; i++)
   {
      xc += min[i].x;
      yc += min[i].y;
   }
   xc  /= numMinutiae;
   yc  /= numMinutiae;
   
   return true;
}



// eliminate far points from one finger view, return number of rest minutiae
int eliminateViewFarPoints (unsigned int &numMinutiae, Minutiae minutiae[MAX_MINUTIAE], unsigned int maxNum)
{
   if (numMinutiae <= maxNum)
      return numMinutiae; 
   int eliminatedNum = 0;
   int xc = 0, yc = 0;
   if (!calcGroupCenters (numMinutiae, minutiae, xc, yc))
      return numMinutiae;
   MinutiaeDist minDist[MAX_MINUTIAE];
   for(unsigned int i = 0; i < numMinutiae; i++)
   {
      minDist[i] = minutiae[i];
      minDist[i].dist = dist(int(minutiae[i].x - xc), int(minutiae[i].y - yc));
   }
   qsort (&minDist[0], numMinutiae, sizeof(MinutiaeDist), compareDist); 

   // copy nearest maxNum minutiae to sourse array
   numMinutiae = maxNum;
   for(unsigned int i = 0; i < maxNum; i++)
   {
      minutiae[i].x        = minDist[i].x;
      minutiae[i].y        = minDist[i].y;
      minutiae[i].prob     = minDist[i].prob;
      minutiae[i].angle    = minDist[i].angle;
      minutiae[i].density  = minDist[i].density;
      minutiae[i].type     = minDist[i].type;
   }
   return numMinutiae;
}

// calculate maximum number minutiae in one finger view
int calcMaxNumViewMin(unsigned int numFingers, unsigned int *numMinutiae, unsigned int maxNum)
{
   unsigned int num[MAX_FINGERS];
   memset(num, 0, sizeof(num));
   memcpy(num, numMinutiae, sizeof(numMinutiae[0]) * numFingers);
   qsort (&num[0], numFingers, sizeof(num[0]), compareNum); 
   unsigned int sum = 0;
   unsigned int lastNumMinutiae = 0, i = 0;
   while (num[i] < MIN_MINUTIAE_NUMBER)
   {
      sum += num[i];
      lastNumMinutiae = num[i];
      if (++i >= numFingers)
         break;
   }
   for(; i < numFingers; i++)
   {
      if (sum + num[i] * (numFingers - i) > maxNum)
         break;
      sum += num[i];
      lastNumMinutiae = num[i];
   }
   return (maxNum - sum) / (numFingers - i) + lastNumMinutiae;
}

// eliminate far points from all finger views, return number of rest minutiae in whole template
int eliminateFarPoints (unsigned int numFingers, unsigned int *numMinutiae, Minutiae minutiae[MAX_FINGERS][MAX_MINUTIAE], 
                        unsigned int maxNum)
{
   int maxNumViewMin = calcMaxNumViewMin(numFingers, numMinutiae, maxNum);
   int sum = 0;
   for (unsigned int i = 0; i < numFingers; i++)
      sum += eliminateViewFarPoints (numMinutiae[i], minutiae[i], maxNumViewMin);

   return sum;
}

void compressTemplate (unsigned int numFingers, unsigned int *numMinutiae, Minutiae minutiae[MAX_FINGERS][MAX_MINUTIAE], unsigned int maxNum)
{
   int result = SME_OK;
   if (numFingers > MAX_FINGERS)
      numFingers = MAX_FINGERS;
   // does any compression needs?
   unsigned int sum = 0;
   for(unsigned int i = 0; i < numFingers; i++)
      sum += numMinutiae[i];
   if (sum < maxNum)
      return;

   // at first eliminate low quality minutiae
   unsigned int restNum = eliminateLowQualityPoints (numFingers, numMinutiae, minutiae, maxNum, DEF_QUALITY_THRESHOLD);
   if (restNum <= maxNum)
      return;

   // eliminate far minutiae
   restNum = eliminateFarPoints (numFingers, numMinutiae, minutiae, maxNum);
}
