#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <assert.h>
//#include <varargs.h>

#include "adjustMinexParams.h"
#include "scoreMinexParameters.h"


#ifdef ADJUST

//LP_IS_GENUINE_PAIR g_lpIsGenuinePair    = NULL;
//bool               g_flagOK             = false;
//bool               g_isHistogrammNeeded = false;

//FILE *g_log_minex         = NULL;
//int   g_numGroup_minex = 0;
//int   g_num_finger_minex[2];
//int   g_num_impression_minex[2];
//
//FILE *   g_curiousLog   = NULL;
//char  g_pName[ 256 ] = { 0 };
//char  g_gName[ 256 ] = { 0 };
//
//// name of files for parameters value statistic
//const char * g_histName_minex[] = 
//{
//   "topologySimMain",     // 0
//   "topologySim",         // 1
//   "angleErrMain",        // 2
//   "angleErr",            // 3
//   "pairAngleErrMain",    // 4
//   "pairAngleErr",        // 5
//   "posErrMain",          // 6
//   "posErr",              // 7
//   "typeErrMain",         // 8
//   "typeErr",             // 9
//   "distErrMain",         // 10 
//   "relAngleErrMain",     // 11
//   "distErr_1",           // 12
//   "distErr_2",           // 13
//   "distErr_3",           // 14
//   "distErr_4",           // 15
//
//   "scoreTemplate01",     // 16
//   "scoreTemplate02",     // 17
//   "scoreTemplate03",     // 18
//   "scoreTemplate04",     // 19
//   "scoreTemplate05",     // 20
//   "scoreTemplate06",     // 21
//   "scoreTemplate07",     // 22
//   "scoreTemplate08",     // 23
//   "scoreTemplate09",     // 24
//   "scoreTemplate10",     // 25
//   "scoreTemplate11",     // 26
//   "scoreTemplate12",     // 27
//   "scoreTemplate13",     // 28
//   "scoreTemplate14",     // 29
//   "scoreTemplate15",     // 30
//   "scoreTemplate16",     // 31
//   "scoreTemplate17",     // 32
////   L"scoreTemplate18",     // 33
//};
//
//const int g_numHist = sizeof(g_histName_minex) / sizeof(g_histName_minex[0]);
//
//FILE * g_histLog_minex  [NUM_HIST_NAME];
//int    g_hist_minex     [NUM_HIST_NAME][101];
//int    g_bestHist_minex [NUM_HIST_NAME][101];
//int    g_allHist_minex  [NUM_HIST_NAME][101];
//
//FILE * g_histLog_minexT [ 2 ][NUM_HIST_NAME];
//int    g_bestHist_minexT[ 2 ][NUM_HIST_NAME][101];
//int    g_allHist_minexT [ 2 ][NUM_HIST_NAME][101];
//int    g_hist_minexT    [ 2 ][NUM_HIST_NAME][101];

bool   g_isGenuine = false;
#endif

// Adjusted to minimaze FRR@FAR=1% in 2-finger matching (minex certification)
#ifdef PIV_CERTIFICATION
int g_k_scoreMinex[] = 
{
//   0      1        2       3        4        5        6        7        8        9    

 12000,     0,       0,      0,       0,   18000,       0,       0,       0,    -740,    //  0...9
     0,  -320,       0,      0,       0,       0,    -280,   30000,       0,    -300,    // 10...19
 -3000,     0,     150,      0,       0,       0,       0,       0,       0,       0,    // 20...29
    

};
#else
// Adjusted to minimaze FRR@FAR=10-4% (ZeroFMR in fact)
int g_k_scoreMinex[] = 
{
//   0      1        2       3        4        5        6        7        8        9    

  5800,     0,       0,      0,       0,   15000,       0,       0,       0,       0,    //  0...9
     0,  -240,       0,      0,       0,       0,    -280,   32000,       0,    -300,    // 10...19
 -3000,     0,     450,      0,       0,       0,       0,       0,       0,       0,    // 20...29
 
};
#endif

int g_k_speedMinex[][10] = 
{
   {  0,   0,    50,    0,    5,    3,    1,    0,    0,    0},       // speed 0
   { 10,  10,    30,   10,    5,    3,    1,    0,    0,    0},       // speed 1
   { 70,  20,    10,   60,    5,    5,    0,    0,    0,    0},       // speed 2

   { 30,  30,    20,   30,    5,    5,    1,    0,    0,    0},       // speed 3
   { 40,  40,    15,   40,    5,    7,    1,    0,    0,    0},       // speed 4

   { 90,  60,     3,   60,    5,    5,    0,    0,    0,    0},       // speed 5

   { 60,  60,     5,   60,   10,   12,    0,    0,    0,    0},       // speed 6
   { 70,  70,     4,   70,   12,   15,    0,    0,    0,    0},       // speed 7
   { 80,  80,     3,   80,   14,   20,    0,    0,    0,    0},       // speed 8
   { 90,  90,     2,   90,   15,   25,    0,    0,    0,    0},       // speed 9
   { 95, 100,     1,  100,   25,   32,    0,    0,    0,    0},       // speed 10
};

#ifdef ADJUST

int g_minexProbeId = 0, g_minexGalleryId = 0, g_minexNumGroup = 0, g_minexFingerP = 0, g_minexFingerG = 0;

FILE *g_minexAdjustFile = NULL;

bool openLog(const char *name, bool forRead)
{
   g_minexAdjustFile = NULL;
   if (!name)
      return false;
   if (forRead)
      g_minexAdjustFile = fopen(name, "rb");
   else
      g_minexAdjustFile = fopen(name, "wb");
   return (g_minexAdjustFile != NULL);
}

void closeLog()
{
   if (!g_minexAdjustFile)
      return;
   fclose(g_minexAdjustFile);
   g_minexAdjustFile = NULL;
}

bool saveMinexParameters(ScoreMinexParameters &param)
{
   if (!g_minexAdjustFile)
      return false;
   char marker[] = "$$$";
   size_t size = strlen(marker);
   if (fwrite (marker, 1, size, g_minexAdjustFile) != size)
      return false;
   size = sizeof(g_minexProbeId);
   //if (g_probeId >= 6000 ||  g_galleryId >= 6000)
   //   return false;

   if (fwrite (&g_minexProbeId, 1, size, g_minexAdjustFile) != size)
      return false;
   if (fwrite (&g_minexGalleryId, 1, size, g_minexAdjustFile) != size)
      return false;
   if (fwrite (&g_minexFingerP, 1, size, g_minexAdjustFile) != size)
      return false;
   if (fwrite (&g_minexFingerG, 1, size, g_minexAdjustFile) != size)
      return false;
   if (fwrite (&g_minexNumGroup, 1, size, g_minexAdjustFile) != size)
      return false;
   size = sizeof(ScoreMinexParameters);
   if (fwrite (&param, 1, size, g_minexAdjustFile) != size)
      return false;
   size = strlen(marker);
   if (fwrite (marker, 1, size, g_minexAdjustFile) != size)
      return false;

   return true;
}

bool readMinexParameters(int &minexProbeId, int &minexGalleryId, int &minexFingerP, int &minexFingerG, int &minexNumGroup, ScoreMinexParameters &param)
{
   if (!g_minexAdjustFile)
      return false;
   char marker[] = "$$$";
   char buffer[20];
   memset(buffer, 0, sizeof(buffer));
   size_t size = strlen(marker);
   if (fread (buffer, 1, size, g_minexAdjustFile) != size)
      return false;
   if (strcmp (buffer, marker))
      return false;
   size = sizeof(minexProbeId);
   if (fread (&minexProbeId, 1, size, g_minexAdjustFile) != size)
      return false;
   if (fread (&minexGalleryId, 1, size, g_minexAdjustFile) != size)
      return false;
   if (fread (&minexFingerP, 1, size, g_minexAdjustFile) != size)
      return false;
   if (fread (&minexFingerG, 1, size, g_minexAdjustFile) != size)
      return false;
   if (fread (&minexNumGroup, 1, size, g_minexAdjustFile) != size)
      return false;
   size = sizeof(ScoreMinexParameters);
   if (fread (&param, 1, size, g_minexAdjustFile) != size)
      return false;
   size = strlen(marker);
   if (fread (buffer, 1, size, g_minexAdjustFile) != size)
      return false;
   if (strcmp (buffer, marker))
      return false;
   return true;
}



//const int g_maxScoreMinex = sizeof( g_k_scoreMinex );
//bool openLogMinex(const char *name, bool forRead)
//{
//   g_log_minex = NULL;
//   if (!name)
//      return false;
//
//   g_log_minex = fopen(name, forRead ? "rb" : "wb");
////   g_log_minex = _wfopen(name, forRead ? L"r" : L"w");
//
//   if (!g_log_minex)  return false;
//   
//   g_numGroup_minex = 0;
//   for(int i = 0; i < 2; i++)
//      g_num_finger_minex[i] = g_num_impression_minex[i] = 0;
//   return true;
//}
//
//void closeLogMinex()
//{
//   if (!g_log_minex)   return;
//   fclose (g_log_minex);
//   g_log_minex = NULL;
//}
//
//void logStartMatchMinex()
//{
//}
//void logFinishMatchMinex()
//{
//   g_numGroup_minex = 0;
//}
//
//bool logScoreParametersMinex_OLD (ScoreMinexParameters &param)
//{
//   if ( !g_log_minex )  return false;
//
//   fprintf(g_log_minex, "\n%4d%3d%4d%3d%3d\n", 
//      g_num_finger_minex[0], g_num_impression_minex[0], 
//      g_num_finger_minex[1], g_num_impression_minex[1],
//      g_numGroup_minex++);
//
//   fprintf(g_log_minex, "%d\n", param.m_foundNum);
//
//   fprintf(g_log_minex, "%d\n", param.m_maxPossibleP);
//   fprintf(g_log_minex, "%d\n", param.m_maxPossibleG);
//
//   fprintf(g_log_minex, "%d\n", param.m_qualityP);
//   fprintf(g_log_minex, "%d\n", param.m_qualityG);
//   fprintf(g_log_minex, "%f\n", param.m_distErr       );
//   fprintf(g_log_minex, "%f\n", param.m_relAngleErr   );
//   fprintf(g_log_minex, "%f\n", param.m_angleErr      );
//   fprintf(g_log_minex, "%f\n", param.m_typeErr       );
//   fprintf(g_log_minex, "%f\n", param.m_pairAngleErr  );
//   fprintf(g_log_minex, "%f\n", param.m_posErr        );
//
//   fprintf(g_log_minex, "%f\n", param.m_topologySim   );
//   fprintf(g_log_minex, "%d\n", param.m_mainGroupSize);
//   fprintf(g_log_minex, "%d\n", param.m_mainGroupSquare);
//
//   //   fflush(g_log_minex);
//   return true;
//}
//
//bool readScoreParametersMinex_OLD(ScoreMinexParameters &param, int numFinger[2], int numImpression[2], int &numGroup)
//{
//
//   if (!g_log_minex)
//      return false;
//   if (fscanf (g_log_minex, "\n%4d%3d%4d%3d%3d\n", 
//      &numFinger[0], &numImpression[0], 
//      &numFinger[1], &numImpression[1],
//      &numGroup) != 5
//      )return false;
//   fscanf(g_log_minex, "%d\n", &param.m_foundNum);
//
//   fscanf(g_log_minex, "%d\n", &param.m_maxPossibleP);
//   fscanf(g_log_minex, "%d\n", &param.m_maxPossibleG);
//
//   fscanf(g_log_minex, "%d\n", &param.m_qualityP);
//   fscanf(g_log_minex, "%d\n", &param.m_qualityG);
//   fscanf(g_log_minex, "%f\n", &param.m_distErr       );
//   fscanf(g_log_minex, "%f\n", &param.m_relAngleErr   );
//   fscanf(g_log_minex, "%f\n", &param.m_angleErr      );
//   fscanf(g_log_minex, "%f\n", &param.m_typeErr       );
//   fscanf(g_log_minex, "%f\n", &param.m_pairAngleErr  );
//   fscanf(g_log_minex, "%f\n", &param.m_posErr        );
//
//   fscanf(g_log_minex, "%f\n", &param.m_topologySim   );
//   fscanf(g_log_minex, "%d\n", &param.m_mainGroupSize);
//   fscanf(g_log_minex, "%d\n", &param.m_mainGroupSquare);
//
//   return true;
//}
//
//bool logScoreParametersMinex_SPD (ScoreMinexParameters &param)
//{
//   if ( !g_log_minex )  return false;
//
//   fwrite ( &g_num_finger_minex    [ 0 ], 1, sizeof( g_num_finger_minex    [ 0 ] ), g_log_minex );
//   fwrite ( &g_num_impression_minex[ 0 ], 1, sizeof( g_num_impression_minex[ 0 ] ), g_log_minex );
//   fwrite ( &g_num_finger_minex    [ 1 ], 1, sizeof( g_num_finger_minex    [ 1 ] ), g_log_minex );
//   fwrite ( &g_num_impression_minex[ 1 ], 1, sizeof( g_num_impression_minex[ 1 ] ), g_log_minex );
//   fwrite ( &g_numGroup_minex           , 1, sizeof( g_numGroup_minex            ), g_log_minex );
//   fwrite ( &param                      , 1, sizeof( ScoreMinexParameters )       , g_log_minex );
//
//   g_numGroup_minex++;
//
////   fflush(g_log_minex);
//   return true;
//}
//
//bool readScoreParametersMinex_SPD(ScoreMinexParameters &param, int numFinger[2], int numImpression[2], int &numGroup)
//{
//   if (!g_log_minex) return false;
//
//   return fread ( &numFinger    [ 0 ] , 1, sizeof( g_num_finger_minex    [ 0 ] ), g_log_minex ) &&
//          fread ( &numImpression[ 0 ] , 1, sizeof( g_num_impression_minex[ 0 ] ), g_log_minex ) &&
//          fread ( &numFinger    [ 1 ] , 1, sizeof( g_num_finger_minex    [ 1 ] ), g_log_minex ) &&
//          fread ( &numImpression[ 1 ] , 1, sizeof( g_num_impression_minex[ 1 ] ), g_log_minex ) &&
//          fread ( &numGroup           , 1, sizeof( g_numGroup_minex            ), g_log_minex ) &&
//          fread ( &param              , 1, sizeof( ScoreMinexParameters )       , g_log_minex );
//   
//}
//void saveParamMinex (int index, int val, int numP , int numG )
//{
//   if ( val < 0   ) val = 0;
//   if ( val > 100 ) val = 100;
//   bool isGen = g_isGenuine;
//
//   g_hist_minex              [index][val]++;
//   if( isGen && g_lpIsGenuinePair && numP >= 0 && numG >= 0 )
//      isGen &= g_lpIsGenuinePair( numP, numG );
//
//   g_hist_minexT[ isGen ][index][val]++;
//}
//void saveParamMinex (int index, float v,  int numP , int numG )
//{
//   return saveParamMinex(index, (int)v, numP, numG );
//}
//
//void saveHistMinex  (int index, int val,  int numP , int numG )
//{
//   if ( val < 0   ) val = 0;
//   if ( val > 100 ) val = 100;
//   bool isGen = g_isGenuine;
//
//   if( isGen && g_lpIsGenuinePair )
//      isGen &= g_lpIsGenuinePair( numP, numG );
//
//   g_allHist_minexT[ isGen ][index][val]++;
//}
//bool openAllHistMinex (char *templDir, char *suffix)
//{
//   wchar_t name[_MAX_PATH];
//   int num = sizeof(g_histName_minex) / sizeof(g_histName_minex[0]);
//   memset (g_allHist_minex, 0, sizeof(g_allHist_minex));
//   clearHistMinex();
//
//   for(int n = 0; n < num; n++)
//   {
//      g_histLog_minex[n] = NULL;
//      sprintf_s (name, _MAX_PATH, "%s%s%s", templDir, g_histName_minex[n], suffix);
//      errno_t err = fopen_s (&g_histLog_minex[n], name, L"w");
//      if (!g_histLog_minex[n])
//         return false;
//   }
//   return true;
//}
//
//void closeAllHistMinex()
//{
//   int num = sizeof(g_histName_minex) / sizeof(g_histName_minex[0]);
//   for(int n = 0; n < num; n++)
//   {
//      int sum = 0;
//      if (g_histLog_minex[n])
//      {
//         for( int i = 0; i <= 100; i++ )
//            sum += g_allHist_minex[n][i];
//         double val = 0;
//         for(int i = 0; i <= 100; i++)
//         {
//            val = sum ? ((double)g_allHist_minex[ n ][ i ] * 100 / sum ) : 0;
//            fwprintf (g_histLog_minex[n], L"%3d\t%10f\n", i, (float)val);
//         }
//         fclose (g_histLog_minex[n]);
//      }
//   }
//}
//void clearHistMinex ()
//{
//   memset (g_hist_minex, 0, sizeof(g_hist_minex));
//
//   clearHistMinexT();
//}
//
//
//void updateBestHistMinex ()
//{
//   int num = sizeof(g_histName_minex) / sizeof(g_histName_minex[0]);
//
//   for(int n = 0; n < num; n++)
//      memcpy(g_bestHist_minex[n], g_hist_minex[n], sizeof(g_hist_minex[n]));
//
//   updateBestHistMinexT();
//}
//
//void updateAllHistMinex ()
//{
//   int num = sizeof(g_histName_minex) / sizeof(g_histName_minex[0]);
//
//   for(int n = 0; n < num; n++)
//      for(int i = 0; i <= 100; i++)
//         g_allHist_minex[n][i] += g_bestHist_minex[n][i];
//
//   updateHistMinexT();
//}
////////////////////////////////////////////////////////////////////////////
////
////
////
////////////////////////////////////////////////////////////////////////////
//
//bool openHistMinexT ( char *templDir )
//{
//   char genName[_MAX_PATH];
//   char impName[_MAX_PATH];
//
//   errno_t err = 0;
//
//   int num = sizeof(g_histName_minex) / sizeof(g_histName_minex[0]);
//   
//   memset (g_allHist_minexT, 0, sizeof(g_allHist_minexT));
//   clearHistMinexT();
//
//   for(int n = 0; n < num; n++)
//   {
//      g_histLog_minexT[0][n] = NULL;
//      g_histLog_minexT[1][n] = NULL;
//      swprintf_s ( genName, _MAX_PATH, L"%s%s%s", templDir, g_histName_minex[n], L"Gen.txt" );
//      swprintf_s ( impName, _MAX_PATH, L"%s%s%s", templDir, g_histName_minex[n], L"Imp.txt" );
//      err = _wfopen_s ( &g_histLog_minexT[1][n], genName, L"w" );
//      err = _wfopen_s ( &g_histLog_minexT[0][n], impName, L"w" );
//      if ( !g_histLog_minexT[0][n] || !g_histLog_minexT[1][n])  return false;
//   }
//   return true;
//}
//
//void closeHistMinexT()
//{
//   int num = sizeof(g_histName_minex) / sizeof(g_histName_minex[0]);
//   for( int j = 0; j < 2; j++ )
//   for( int n = 0; n < num; n++)
//   {
//      int sum = 0;
//      if ( g_histLog_minexT[j][n] )
//      {
//         for( int i = 0; i <= 100; i++ )
//            sum += g_allHist_minexT[j][n][i];
//
//         double val = 0;
//         for(int i = 0; i <= 100; i++)
//         {
//            val = sum ? ((double)g_allHist_minexT[j][n][ i ] * 100 / sum ) : 0;
//            fwprintf (g_histLog_minexT[j][n], L"%3d\t%10f\n", i, (float)val );
//         }
//         fclose ( g_histLog_minexT[j][n] );
//      }
//   }
//}
//void clearHistMinexT ()
//{
//   memset (g_hist_minexT, 0, sizeof(g_hist_minexT));
//}
//
//
//void updateBestHistMinexT ()
//{
//   int num = sizeof(g_histName_minex) / sizeof(g_histName_minex[0]);
//
//   for(int n = 0; n < num; n++)
//   {
//      memcpy(g_bestHist_minexT[ 0 ][n], g_hist_minexT[ 0 ][n], sizeof(g_hist_minexT[ 0 ][n]));
//      memcpy(g_bestHist_minexT[ 1 ][n], g_hist_minexT[ 1 ][n], sizeof(g_hist_minexT[ 1 ][n]));
//   }
//}
//
//void updateHistMinexT ()
//{
//   int num = sizeof(g_histName_minex) / sizeof(g_histName_minex[0]);
//
//   for( int gen = 0; gen < 2; gen++ )
//      for(int n = 0; n < num; n++)
//         for(int i = 0; i <= 100; i++)
//            g_allHist_minexT[ gen ][n][i] += g_bestHist_minexT[ gen ][n][i];
//}
////////////////////////////////////////////////////////////////////////////
////
////
////
////////////////////////////////////////////////////////////////////////////
//void openCuriousPairsLog( const char * name )
//{
//   if( !name ) return;
//
//   g_curiousLog = fopen( name, "w" );
//}
//void saveCuriousPair( char * format, ... )
//{
//   if( !g_curiousLog ) return;
//
//   va_list  args;
//   va_start ( args, format );
//
//   fprintf( g_curiousLog, "\t%s\t%s\t", g_pName, g_gName );
//   vfprintf( g_curiousLog, format, args );
//   fprintf( g_curiousLog, "\n" );
//}
//void closeCuriousPairsLog()
//{
//   if( g_curiousLog ) fclose( g_curiousLog );
//}
////////////////////////////////////////////////////////////////////////////
#endif




