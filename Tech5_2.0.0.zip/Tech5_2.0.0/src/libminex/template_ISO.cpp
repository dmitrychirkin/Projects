/*
   template_ISO_19794_2.cpp - implement the  function for work with template in 
   ISO 19794-2 format
*/

#include <assert.h>
#include <memory.h>

#include "libMinexFull.h"
#include "template_ISO.h"
#include "integrTrig.h"

#define DEF_RESOLUTION           197         // 500 dpi
#define FORMAT_ID                0x464D5200
#define STANDARD_VERSION         0x20323000


int getAlowsNumMinutiaeISO(unsigned int numFingers, unsigned int maxSize)
{
   if (numFingers > MAX_FINGERS)
      numFingers = MAX_FINGERS;
   maxSize -= sizeof (ISO_header) +  sizeof (ISO_extendedHeader) + sizeof (ISO_viewHeader) * numFingers;
   return maxSize / sizeof (ISO_minutiae);
}


int calcISOtemplSize(unsigned int numFingers, unsigned int numMinutiae[MAX_FINGERS])
{
   if (numFingers > MAX_FINGERS)
      numFingers = MAX_FINGERS;
   int size = sizeof (ISO_header) +  sizeof (ISO_extendedHeader);
   for(unsigned int i = 0; i < numFingers; i++)
      size += sizeof (ISO_viewHeader) + sizeof (ISO_minutiae) * numMinutiae[i];
   return size;
}

int calcFullISOtemplSize(unsigned int numFingers)
{
   unsigned int numMinutiae[MAX_FINGERS];
   for(unsigned int i = 0; i < MAX_FINGERS; i++)
      numMinutiae[i] = MAX_ISO_MINUTIAE;
   return calcISOtemplSize (numFingers, numMinutiae);
}

int getMinISOtemplateSize(unsigned int numFingers)
{
   unsigned int numMinutiae[MAX_FINGERS];
   for(int i = 0; i < MAX_FINGERS; i++)
      numMinutiae[i] = MIN_MINUTIAE;
   return calcISOtemplSize (numFingers, numMinutiae);
}

int getISOtemplateSize(const BYTE *templ)
{
   return swapDWORD( ((ISO_header*)templ)->m_length );
}

void setISOtemplateSize (int templSize, BYTE* templ)
{
   ISO_header *header = (ISO_header*)templ;
   header->m_length = swapDWORD (templSize);
}

// check parameters
inline int checkISOParameters(const RawImage &rawImage, BYTE quality, BYTE *moTemplate)
{
   if (quality > QUAL_EXCELLENT)
      return SME_WRONG_PARAM;
   if (rawImage.finger > FINGPOS_LL)
      return SME_WRONG_PARAM;
   if ((rawImage.impression_type < IMPTYPE_LP || rawImage.impression_type > IMPTYPE_NR) 
      && rawImage.impression_type != IMPTYPE_SW)
      return SME_IMPRESSION_TYPE;
   if (!moTemplate)
      return SME_WRONG_POINTER;
   if (!rawImage.width || !rawImage.height)
      return SME_IMAGE_SIZE;
   return SME_OK;
}

// fill ISO 19794-2 header
inline void fill_ISO_Header(const RawImage &rawImage, BYTE **pos, 
                            int templSize, 
                            bool certifiedSensor, WORD sensorID,
                            unsigned int numFingers)
{
   ISO_header *header = (ISO_header*)*pos;
   header->m_formatID = swapDWORD (FORMAT_ID);
   header->m_version  = swapDWORD (STANDARD_VERSION);
   header->m_length   = swapDWORD (templSize);
   WORD temp = sensorID;
   if(certifiedSensor)
      temp |= 1 << 15; 
   header->m_capture_e = swapWORD(temp);
   header->m_width  = swapWORD (rawImage.width);
   header->m_height = swapWORD (rawImage.height);
   header->m_resolutionX = swapWORD (DEF_RESOLUTION); 
   header->m_resolutionY = swapWORD (DEF_RESOLUTION);
   header->m_numView = numFingers;
   *pos += sizeof(ISO_header);
}

// fill finger view
void fill_ISO_view (BYTE **pos, const RawImage &rawImage, BYTE quality, BYTE numMinutiae, 
                        Minutiae minutiae[MAX_MINUTIAE], Frame &frame)
{
   ISO_viewHeader *viewHeader = (ISO_viewHeader*)*pos;
   viewHeader->m_position        = rawImage.finger;
   viewHeader->m_viewNumber      = 0;
   viewHeader->m_impressionType  = rawImage.impression_type;
   viewHeader->m_quality         = quality;
   viewHeader->m_numMinutiae     = numMinutiae;
   *pos += sizeof(ISO_viewHeader);

   ISO_minutiae *min = (ISO_minutiae*)*pos;
   // fill minutiae
   int  type = 0, angle = 0, add = 0, dx = 0, dy = 0, curX = 0 , curY = 0, x = 0, y = 0;
   bool isTooClose = false;
   int count = 0;
   int temp = 0;
   for (unsigned int i = 0; i < numMinutiae; i++)
   {
      isTooClose = false;                                                           // Eliminate minutiae
      for( unsigned int j = 0; j < i && !isTooClose; j ++ )                         // sitting too close to
         isTooClose = ( dist( ( int )( minutiae[ i ].x - minutiae[ j ].x ),         // one another which is a 
                              ( int )( minutiae[ i ].y - minutiae[ j ].y ) ) < 2 ); // mistake in fingerprint 
                                                                                    // processing
      if( isTooClose ) continue;

      type = (minutiae[count].type == ENDING) ? ISO_NIST_ENDING : ISO_NIST_BIFURCATION;
      if (type == ISO_NIST_ENDING)
      {
         angle = normAngle(minutiae[count].angle - 180);
         add = (minutiae[count].density + 1) / 4 + 2;
         dx = cosm(add, angle);
         dy = sinm(add, angle);
      }
      else
         dx = dy = 0;
      x = minutiae[count].x + frame.left + dx;
      y = minutiae[count].y + frame.top  - dy;
      if      (x <               0) x = 0;
      else if (x >= rawImage.width) x = rawImage.width   - 1;
      if      (y <                0) y = 0;
      else if (y >= rawImage.height) y = rawImage.height - 1;

      min[count].m_x       = x & 0x3fff;
      min[count].m_x      += (type & 0x3) << 14;
      min[count].m_y       = y & 0x3fff;
      min[count].m_x       = swapWORD(min[count].m_x);
      min[count].m_y       = swapWORD(min[count].m_y);
#ifndef PIV_CERTIFICATION
      min[count].m_quality = minutiae[count].prob;
#endif
      if (minutiae[count].angle > 0)
         minutiae[count].angle -= 360;
      temp = (int)(-minutiae[i].angle / 1.40625 + 0.5);
      if      (temp <= 0  ) min[i].m_angle = 0;
      else if (temp >= 255) min[i].m_angle = 255;
      else                  min[i].m_angle = (BYTE)temp;
      count++;
   }
   *pos += sizeof(ISO_minutiae) * count;
   // correct number of minutiae
   viewHeader->m_numMinutiae = count;
}



// build ISO 19794-2 template
int buildISOtemplate ( unsigned int numFingers, const RawImage *rawImage, 
                       BYTE *quality,
                       BYTE *moTemplate,
                       unsigned int *numMinutiae,
                       Minutiae minutiae[MAX_FINGERS][MAX_MINUTIAE], 
                       Frame *frame, 
                       bool certifiedSensor, WORD sensorID,
                       unsigned int *size)
{
   // check parameters
   int result = SME_OK;
   if (numFingers > MAX_FINGERS)
      numFingers = MAX_FINGERS;
   for(unsigned int i = 0; i < numFingers; i++)
   {
      if ((result = checkISOParameters (rawImage[i], quality[i], moTemplate)) != SME_OK) 
         return result;
      if (numMinutiae[i] > MAX_ISO_MINUTIAE)
         numMinutiae[i] = MAX_ISO_MINUTIAE;
   }
   int templSize = calcISOtemplSize(numFingers, numMinutiae);
   memset (moTemplate, 0, templSize);
   
   BYTE *pos = (BYTE*)moTemplate;
   // fill ISO header
   fill_ISO_Header (rawImage[0], &pos, templSize, certifiedSensor, sensorID, numFingers);
   
   if (numFingers > MAX_FINGERS) 
      numFingers = MAX_FINGERS;
   // fill finger view
   for(unsigned int i = 0; i < numFingers; i++)
      fill_ISO_view (&pos, rawImage[i], quality[i], numMinutiae[i], minutiae[i], frame[i]);

   templSize = (int)(pos - moTemplate) + sizeof (ISO_extendedHeader); 
   setISOtemplateSize (templSize, moTemplate);
   if (size)
      *size = templSize;
   return SME_OK;
}

bool checkISOtemplate (unsigned int &numFingers, const BYTE *moTemplate, float &kx, float &ky)
{
   // check parameters
   if (!moTemplate)
      return false;
   ISO_header *header = (ISO_header*)moTemplate;
   if (header->m_formatID != swapDWORD (FORMAT_ID) 
//#ifdef STRONG_CHECK
      || header->m_version  != swapDWORD (STANDARD_VERSION)
//#endif
      )  
      return false;
//   if (header->m_capture_e_c || header->m_capture_e_id)
//      return false;
//   if (header->m_resolutionX != swapWORD (DEF_RESOLUTION) || 
//       header->m_resolutionY != swapWORD (DEF_RESOLUTION))
//      return false;
     kx = (float)swapWORD(header->m_resolutionX) / DEF_RESOLUTION;
     ky = (float)swapWORD(header->m_resolutionY) / DEF_RESOLUTION;
   // check all views
   if (numFingers > header->m_numView) 
      numFingers = header->m_numView;
   BYTE *pos = (BYTE*)moTemplate + sizeof (ISO_header);
   for(unsigned int i = 0; i < numFingers; i++)
   {
       ISO_viewHeader *viewHeader = (ISO_viewHeader*)pos;
//#ifdef STRONG_CHECK
       if (viewHeader->m_position > FINGPOS_LL) 
          return false;
       if (viewHeader->m_viewNumber != 0)
          return false;
       int impression_type = viewHeader->m_impressionType;
       if ((impression_type < IMPTYPE_LP || impression_type > IMPTYPE_NR) 
            && impression_type != IMPTYPE_SW)
          return false;
       if (viewHeader->m_quality > QUAL_EXCELLENT)
          return false;
       if (viewHeader->m_numMinutiae > MAX_ISO_MINUTIAE)
          return false;
//#endif
       pos += sizeof (ISO_viewHeader);
       pos += sizeof (ISO_minutiae) * viewHeader->m_numMinutiae;
   }
    return true;
}


// read minutiae information
bool readISOminutiae (BYTE **pos, BYTE numMinutiae,
                      Minutiae minutiae[MAX_MINUTIAE],
                      WORD width, WORD height, float kx, float ky)
{
   if (!pos)
      return false;
   ISO_minutiae *min = (ISO_minutiae*)*pos;
   int type = 0;
   for (unsigned int i = 0; i < numMinutiae; i++)
   {
      minutiae[i].x = swapWORD (min[i].m_x);
      type = (minutiae[i].x >> 14) & 0x3;
      minutiae[i].x     = minutiae[i].x & 0x3fff;
      minutiae[i].x     = int(minutiae[i].x / kx + 0.5);
      minutiae[i].y     = swapWORD (min[i].m_y) & 0x3fff;;
      minutiae[i].y     = int(minutiae[i].y / ky + 0.5);
#ifndef PIV_CERTIFICATION
      minutiae[i].prob  =  min[i].m_quality;
#endif

      switch (type)
      {
      case ISO_NIST_OTHER:
      case ISO_NIST_ENDING:
         minutiae[i].type = ENDING;
         break;
      case ISO_NIST_BIFURCATION:
         minutiae[i].type = BIFURCATION;
         break;
      default:
         assert(false);
      }
      if (minutiae[i].x >= width ||
          minutiae[i].y >= height)
          return false;
      minutiae[i].angle = normAngle((int)(-(min[i].m_angle * 1.40625  + 0.5)));
   }
   *pos += sizeof(ISO_minutiae) * numMinutiae;
   return true;
}


int readISOtemplate (unsigned int &numFingers, 
                      const BYTE *moTemplate, BYTE numMinutiae[MAX_FINGERS],
                      Minutiae minutiae[MAX_FINGERS][MAX_MINUTIAE], 
                      WORD &width, WORD &height, BYTE quality[MAX_FINGERS],
                      BYTE finger[MAX_FINGERS])
{
   if (numFingers > MAX_FINGERS)
      numFingers = MAX_FINGERS;
   if (!moTemplate)
      return SME_WRONG_POINTER;
   try
   {
      // check parameters
      float kx = 1, ky = 1;
      if (!checkISOtemplate (numFingers, moTemplate, kx, ky))
         return SME_PARSE_TEMPL;

      // read image size
      ISO_header *header = (ISO_header*)moTemplate;
      width  = swapWORD (header->m_width);
      height = swapWORD (header->m_height);
      BYTE *pos = (BYTE*)moTemplate + sizeof (ISO_header);
      for(unsigned int i = 0; i < numFingers; i++)
      {
         // read quality and finger position
         ISO_viewHeader *viewHeader = (ISO_viewHeader*)pos;
         quality[i] = viewHeader->m_quality;
         finger[i]  = viewHeader->m_position;
         pos += sizeof(ISO_viewHeader);     
         // read minutiae
         numMinutiae[i] = viewHeader->m_numMinutiae;
         if (!readISOminutiae (&pos, numMinutiae[i], minutiae[i], width, height, kx, ky))
            return SME_PARSE_TEMPL;
      }
   }
   catch(...)
   {
      return SME_UNKN_ERR;
   }
   return SME_OK;
}

int getNumFingers_ISO (unsigned int &numFingers, const BYTE *moTemplate, FINGERS *finger)
{
   if (numFingers > MAX_FINGERS)
      numFingers = MAX_FINGERS;
   if (!moTemplate || !finger)
      return SME_WRONG_POINTER;
   
   try
   {
      // check parameters
      float kx = 1, ky = 1;
      if (!checkISOtemplate (numFingers, moTemplate, kx, ky))
         return SME_PARSE_TEMPL;

      // read image size
      ISO_header *header = (ISO_header*)moTemplate;
      BYTE *pos = (BYTE*)moTemplate + sizeof (ISO_header);
      for(unsigned int i = 0; i < numFingers; i++)
      {
         // read quality and finger position
         ISO_viewHeader *viewHeader = (ISO_viewHeader*)pos;
         finger[i]  = (FINGERS)viewHeader->m_position;
         pos += sizeof(ISO_viewHeader) + sizeof (ISO_minutiae) * viewHeader->m_numMinutiae;     
      }
   }
   catch(...)
   {
      return SME_UNKN_ERR;
   }
   return SME_OK;

}
