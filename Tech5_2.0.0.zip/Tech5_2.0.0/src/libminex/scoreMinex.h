/*
   scoreMinex.h - declare function for score calculation for minex matching

*/
#ifndef  SCORE_MINEX_H_
#define  SCORE_MINEX_H_
#include "scoreMinexParameters.h"

extern int g_k_score_minex[];

bool  isLookImpostor     ( float topologyAVG );
bool  isLookGenuine      ( float topologyAVG );
int calculateScoreMinex( ScoreMinexParameters &param );

#endif // SCORE_MINEX_H_
