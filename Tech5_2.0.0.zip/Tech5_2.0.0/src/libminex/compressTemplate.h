/*
   compressTemplate.h - declare the functions that compress NIST or ISO template 
                        to corresponded size

*/
#ifndef COMPRESS_TEMPLATE_H_
#define COMPRESS_TEMPLATE_H_

#include "libMinexFull.h"

#define MIN_MINUTIAE_NUMBER      52        // minumum number of minutiae in one finger view


// rest only maxNum minutiae in template, all others are eliminated
void compressTemplate (unsigned int numFingers, unsigned int *numMinutiae, Minutiae minutiae[MAX_FINGERS][MAX_MINUTIAE], 
              unsigned int maxNum);

#endif // COMPRESS_TEMPLATE_H_
