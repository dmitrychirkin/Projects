/*
   minutiaePair.cpp - implements the MinutiaePair class that kepp information 
                    about one pair of minutiae
*/
#define  _USE_MATH_DEFINES
#include <math.h>

#include "minutiaePair.h"
//#include "MatLab.h"

// distance tolerance table
int g_ddist[3][DDIST_SIZE];

