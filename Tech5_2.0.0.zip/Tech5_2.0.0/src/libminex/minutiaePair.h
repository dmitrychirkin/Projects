/*
   minutiaePair.h - declare the MinutiaePair class that keep information 
                    about one pair of minutiae

*/
#ifndef  INCITS_378_MINUTIAE_PAIR_H_
#define INCITS_378_MINUTIAE_PAIR_H_

#include <functional>
#include "coreSdk.h"
#include "libminex.h"

#define DDIST_SIZE                  256  // size of ddist array

// distance tolerance table
extern int g_ddist[3][DDIST_SIZE];

// fill g_ddist array
inline void calcDdist()
{
   int a = 0;
   for(int i = 0; i < DDIST_SIZE; i++)
   {
      a = i * 26 / 256 + 6;
      g_ddist[0][i] = a;  
      g_ddist[1][i] = a + 6;  
      g_ddist[2][i] = a * 2 + 20;  
   }
}


struct MinutiaePairEx
{
   int      m_nP ;         // index of first probe minutiae
   int      m_mP ;         // index of second probe minutiae
   int      m_nG ;         // index of first gallery minutiae
   int      m_mG ;         // index of second gallery minutiae
   int      m_topologySim; // summary topology similarity for both pairs

public:
   MinutiaePairEx()
   {
      m_nP = m_nG = m_mP = m_mG = -1;
      m_topologySim = -100;
   }
   
   MinutiaePairEx( int nP, int nG, int mP, int mG, int topologySim )
   {
      m_nP = nP;
      m_nG = nG;
      m_mP = mP;
      m_mG = mG;
      m_topologySim = topologySim;
   }
   operator int() { return m_topologySim; }
};

struct MinutiaePairLen
{
   int      m_num1;       // index of first minutiae
   int      m_num2;       // index of second minutiae
   int      m_dist;       // distance between minutiae

public:
   MinutiaePairLen()
   {
      m_num1 = m_num2 = -1;
      m_dist = -1;
   }
   MinutiaePairLen(int num1, int num2, int dist)
   {
      m_num1 = num1;
      m_num2 = num2;
      m_dist = dist;
   }
   //operator int() const { return m_dist; }

   inline int  getDist() const { return m_dist; }
   inline int  getNum1() const { return m_num1; }
   inline int  getNum2() const { return m_num2; }
   inline void set(int num1, int num2, int dist)
   {
      m_num1 = num1;
      m_num2 = num2;
      m_dist = dist;
   }
   bool operator>( const MinutiaePairLen & pairB ) const
   {
       if( m_dist > pairB.m_dist ) return true;
       if( m_num1 > pairB.m_num1 ) return true;
       if( m_num2 > pairB.m_num2 ) return true;
       return true;
   }
   bool operator<( const MinutiaePairLen & pairB ) const
   {
       if( m_dist < pairB.m_dist ) return true;
       if( m_num1 < pairB.m_num1 ) return true;
       if( m_num2 < pairB.m_num2 ) return true;
       return false;
   }
};


struct MinutiaePair 
{
   int      m_dist;       // distance between minutiae
   int      m_angle;      // angle between pair and oX axis
   int      m_angleDif;   // difference between minutiae angles
   int      m_angle1;     // angle between first minutiae and 
                          // direction to the second minutiae
   int      m_angle2;     // angle between second minutiae and 
                          // direction to the first minutiae
};
/*
class ComparePred: std::binary_function<const MinutiaePairLen&, const MinutiaePairLen&, bool>
{
private:
   int (&topologySim)[MAX_MINEX_MINUTIAE][MAX_MINEX_MINUTIAE];

public:
   ComparePred(int (&topology)[MAX_MINEX_MINUTIAE][MAX_MINEX_MINUTIAE] ):topologySim( topology ){}
   bool operator()(const MinutiaePairLen& f, const MinutiaePairLen& s)
   {
      return topologySim[f.m_num1][f.m_num2] > topologySim[s.m_num1][s.m_num2];
   }
};
*/

#endif // INCITS_378_MINUTIAE_PAIR_H_
