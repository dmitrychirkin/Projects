//////////////////////////////////////////////////////////////////////////
//
// This code implements group expansion functions of the moMathcher class
//
//////////////////////////////////////////////////////////////////////////
#include "moMatcher.h"
#include "integrTrig.h"

// add in the current group the minutiae, those locate the similar
// returns number of added minutiae
int   MoMatcher::expandCurGroup(int xc[2], int yc[2])
{
   int num = 0;
   m_fitMinutiae.clear();
//   m_oppositeMinutiae.clear();
//   m_perpMinutiae.clear();
   int numP = m_numMinutiae[0];
   int numG = m_numMinutiae[1];
   int len = 0, maxLen = 0, radius = 0, angle = 0, dist2Group = 0;

   setTolerance (3);
   for(int np = 0; np < numP; np++)
   {
      if (m_curGroup.findProbe (np) || m_exclude[0].find (np))
         continue;
      radius = dist(m_minutiae[0][np].x, m_minutiae[0][np].y, xc[0], yc[0]);
      maxLen = ddist(radius);
      for(int ng = 0; ng < numG; ng++)
      {
         if (m_curGroup.findGallery (ng) || m_exclude[1].find (ng))
            continue;
         len = dist(m_minutiae[0][np].x, m_minutiae[0][np].y, m_curMinutiae[ng].x, m_curMinutiae[ng].y);
         if (len > maxLen)
            continue;
         angle = abs(normAngle(m_minutiae[0][np].angle - m_curMinutiae[ng].angle));
/*
         if (angle >= 70)
         {
            if(len > 256)
               len = 256;
            if (angle > 150 && len <= 10)
               m_oppositeMinutiae.push_back((len << 24) + (angle << 16) + (np << 8) + ng);
            if (abs(angle - 90) < 30 && len < 20)
               m_perpMinutiae.push_back((len << 24) + (angle << 16) + (np << 8) + ng);
            continue;
         }
*/
         if (m_topologySim[np][ng] < MIN_TOPOLOGY_SIM)
            continue;
         if (angle >= m_maxGroupAngle)
            continue;
         dist2Group = getDist2Group(m_curGroup, np);
         m_fitMinutiae.push_back((dist2Group << 16) + (np << 8) + ng);
      }
   }
   sort (m_fitMinutiae.begin(), m_fitMinutiae.end(),  less<int>());
   //   int numFitPairs = m_fitMinutiae.size(); 
   //   int numOppositeMinutiae = m_oppositeMinutiae.size();
   //   int numPerpMinutiae = m_perpMinutiae.size();

   int count = 0;
   for (int mode = 1; mode <= 2; mode++)
   {
      setTolerance (mode);
      count += passExpandCurGroup (LOCAL_CHECK_RADIUS * 16);
      count += passExpandCurGroup (LOCAL_CHECK_RADIUS * 4);
      count += passExpandCurGroup (LOCAL_CHECK_RADIUS * 2);
      count += passExpandCurGroup (LOCAL_CHECK_RADIUS);
   }
   setTolerance (1);

   return count;
}
// perform the one pass of the expand current group of minutiae pairs
int   MoMatcher::passExpandCurGroup(int maxDist)
{
   int count = 0;
   size_t num = m_fitMinutiae.size(), start = 0;
   int np = 0, ng = 0, len = 0, item = 0;
   for(int i = 0; i < num; i++)
   {
      item = m_fitMinutiae[i];
      if (item == -1)
         continue;
      np  = (item >> 8) & 0xff;
      start = i;
      ng = findBestG(i, np, true, maxDist);
      if ( ng == -1)
         continue;
      if (findBestP(ng, true, maxDist) == np)
      {
         m_curGroup.add (np, ng, m_topologySim[ np ][ ng ] );
         removeFoundPair(m_fitMinutiae, np, ng); 
//         removeFoundPair(m_oppositeMinutiae, np, ng); 
//         removeFoundPair(m_perpMinutiae, np, ng); 
         count++;
      }
   }
   return count;
}
int   MoMatcher::findBestG(int &pos, int np, bool local, int maxDist)
{
   int bestG = -1;
   float err = 0, minErr = 1000;
   size_t num = m_fitMinutiae.size();
   int ng = 0, item = 0;

   for( ; pos < num; pos++)
   {
      item = m_fitMinutiae[pos];
      if (item == -1)
         continue;
      if (((item >> 8) & 0xff) != np)
      {
         pos--;
         break;
      }
      ng  = item & 0xff;

      if (!isCompatibleWithGroup (m_curGroup, np, ng, err, local, maxDist) 
         ) continue;
      if (err > 0 && minErr > err)
      {
         minErr = err;
         bestG = ng; 
      }
   }
   return bestG;
}
// find the best probe minutiae for given gallery minutiae
int   MoMatcher::findBestP(int ng, bool local, int maxDist)
{
   int bestP = -1;
   float err = 0, minErr = 1000;
   size_t num = m_fitMinutiae.size();
   int np = 0, item = 0;

   for(int pos = 0; pos < num; pos++)
   {
      item = m_fitMinutiae[pos];
      if (item == -1)
         continue;
      if ((item & 0xff) != ng)
         continue;
      np = (item >> 8) & 0xff;
      if (!isCompatibleWithGroup (m_curGroup, np, ng, err, local, maxDist) 
         ) continue;
      if (err > 0 && minErr > err)
      {
         minErr = err;
         bestP = np;
      }
   }
   return bestP;
}

// remove all pairs with given np or ng
void  MoMatcher::removeFoundPair(vector<int> &v, int np, int ng)
{
   int item = 0;
   size_t num = v.size();
   for(int i = 0; i < num; i++)
   {
      item = v[i];
      if ((item & 0xff) == ng || ((item >> 8) & 0xff) == np)
         v[i] = -1;
   }
}
// get distance to group(distance to the nearest minutiae)
inline 
int   MoMatcher::getDist2Group(Group &g, int np)
{
   int n = 0, dist = 0, minDist = 1000;
   int num = g.m_numItems;
   for (int i = 0; i < num; i++)
   {
      n = g.getProbe(i);
      dist = m_pairs[0][np][n].m_dist;
      if (dist < minDist)
         minDist = dist;
   }
   return minDist;
}
