/*
   adjustMinexParmams.h - declare function for adjusting score calculation parameters for minex matching

*/
#ifndef  ADJUST_MINEX_PARAMS_H_
#define  ADJUST_MINEX_PARAMS_H_

#include <stdio.h>
#include "scoreMinexParameters.h"

extern int g_k_scoreMinex[];
extern int g_k_speedMinex[][10];

#ifdef ADJUST

extern int g_minexProbeId, g_minexGalleryId, g_minexNumGroup, g_minexFingerP, g_minexFingerG;
extern FILE *g_minexAdjustFile;

bool openLog(const char *name, bool forRead);
void closeLog();

bool saveMinexParameters(ScoreMinexParameters &param);
bool readMinexParameters(int &minexProbeId, int &minexGalleryId, int &minexFingerP, int &minexFingerG, int &minexNumGroup, ScoreMinexParameters &param);

//extern bool                g_isHistogrammNeeded;
//extern const int           g_numHist;
//extern const wchar_t *     g_histName_minex[];
//extern const int           g_maxScoreMinex;
//#define COR_OFFSET 20
//#define NUM_HIST_NAME  g_numHist
//
//typedef bool ( *LP_IS_GENUINE_PAIR )( int numP, int numG );
//extern  bool g_flagOK;
//
//#define SPEED_UP
//
//#ifdef SPEED_UP
//#define logScoreParametersMinex logScoreParametersMinex_SPD
//#define readScoreParametersMinex readScoreParametersMinex_SPD
//#else
//#define logScoreParametersMinex logScoreParametersMinex_OLD
//#define readScoreParametersMinex readScoreParametersMinex_OLD
//#endif
//
//extern wchar_t g_pName[];
//extern wchar_t g_gName[];
//extern bool    g_isGenuine;
//extern LP_IS_GENUINE_PAIR g_lpIsGenuinePair;
//
//// functions for save score calculation source data
//bool openLogMinex(const wchar_t *name, bool forRead);
//void closeLogMinex();
//void logStartMatchMinex();
//void logFinishMatchMinex();
//bool logScoreParametersMinex(ScoreMinexParameters &param);
//bool readScoreParametersMinex(ScoreMinexParameters &param, int numFinger[2], 
//                              int numImpression[2], int &numGroup);
//
//// functions for save parameters statistic data
//bool openAllHistMinex (wchar_t *templDir, wchar_t *suffix);
//void closeAllHistMinex();
//void saveParamMinex (int index, int v  , int numP = -1, int numG = -1 );
//void saveParamMinex (int index, float v, int numP = -1, int numG = -1 );
//void saveHistMinex  (int index, int val, int numP = -1, int numG = -1 );
//void clearHistMinex ();
//void updateBestHistMinex ();
//void updateAllHistMinex ();
//
//bool openHistMinexT ( wchar_t *templDir );
//void closeHistMinexT();
//void clearHistMinexT ();
//void updateBestHistMinexT ();
//void updateHistMinexT ();
//
//void openCuriousPairsLog ( const wchar_t * name );
//void saveCuriousPair     ( char * format, ... );
//void closeCuriousPairsLog();

#endif  // ADJUST

#endif // ADJUST_MINEX_PARAMS_H_
