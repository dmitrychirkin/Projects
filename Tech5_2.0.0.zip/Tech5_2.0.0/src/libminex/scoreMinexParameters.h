/*
   scoreMinexParameters.h - declare the parameters, those are used in score calculation
                            for minex matching

*/


#ifndef  SCORE_MINEX_PARAMETERS_H_
#define  SCORE_MINEX_PARAMETERS_H_

#include <memory.h>
#include <math.h>

#include "win2lin.h"

#pragma pack (push, 1)
struct P_PACKED_1 ScoreMinexParametersShort
{
   int   m_foundNum      : 8;
   int   m_maxPossibleP  : 8;
   int   m_maxPossibleG  : 8;
   int   m_qualityP      : 8;
   int   m_qualityG      : 8;
   int   m_mainGroupSize : 8;
   int   m_numMinutiaeP  : 8;
   int   m_numMinutiaeG  : 8;
   
   float m_distErr      ;
   float m_relAngleErr  ;
   float m_angleErr     ;
   float m_typeErr      ;
   float m_pairAngleErr ;
   float m_posErr       ;
   float m_topologySim  ;
   float m_topologyAvg;

   int m_reserved[8];
/*   
   int   m_mainGroupSquare;

   short m_combWidth;
   short m_combHeight;  
   short m_pWidth;
   short m_gWidth;
   short m_pHeight;
   short m_gHeight;
*/
};
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
struct ScoreMinexParameters
{
   int   m_foundNum;
   int   m_maxPossibleP;
   int   m_maxPossibleG;
   int   m_qualityP;
   int   m_qualityG;

   float m_distErr      ;
   float m_relAngleErr  ;
   float m_angleErr     ;
   float m_typeErr      ;
   float m_pairAngleErr ;
   float m_posErr       ;
   float m_topologySim  ;
   float m_topologyAvg  ;

   int   m_mainGroupSize;
   int   m_mainGroupSquare;
   int   m_numMinutiae[2];
/*
   int   m_combWidth;
   int   m_combHeight;  
   short m_pWidth;
   short m_gWidth;
   short m_pHeight;
   short m_gHeight;
*/
   int   m_reserved   [20];

   ScoreMinexParameters()
   {
      memset( this, 0, sizeof ( ScoreMinexParameters ) );
   }
   ScoreMinexParameters (const ScoreMinexParameters& param)
   {
      *this = param;
   }

   ScoreMinexParameters& operator= (const ScoreMinexParameters& param)
   {
      memcpy( this, &param, sizeof( ScoreMinexParameters ) );
      
      return *this;
   }

   ScoreMinexParameters& operator= (const ScoreMinexParametersShort& param)
   {
      m_foundNum         = param.m_foundNum;
      m_maxPossibleP     = param.m_maxPossibleG;
      m_maxPossibleG     = param.m_maxPossibleP;
      m_qualityP         = param.m_qualityP;
      m_qualityG         = param.m_qualityG;
      m_distErr          = param.m_distErr;
      m_relAngleErr      = param.m_relAngleErr;
      m_angleErr         = param.m_angleErr;
      m_typeErr          = param.m_typeErr;
      m_pairAngleErr     = param.m_pairAngleErr;
      m_posErr           = param.m_posErr;
      m_topologySim      = param.m_topologySim;
      
      m_topologyAvg      = param.m_topologyAvg;
      m_mainGroupSize    = param.m_mainGroupSize;
//      m_mainGroupSquare  = param.m_mainGroupSquare;
/*
      m_combWidth        = param.m_combWidth;
      m_combHeight       = param.m_combHeight;     
      m_pWidth           = param.m_pWidth;
      m_gWidth           = param.m_gWidth;
      m_pHeight          = param.m_pHeight;
      m_gHeight          = param.m_gHeight;
*/

      m_numMinutiae[ 0 ] = param.m_numMinutiaeP;
      m_numMinutiae[ 1 ] = param.m_numMinutiaeG;

      memcpy( m_reserved, param.m_reserved, sizeof( param.m_reserved ) );
      return *this;
   }

   ScoreMinexParametersShort& toShort( ScoreMinexParametersShort& param)
   {
      param.m_foundNum         = m_foundNum;
      param.m_maxPossibleP     = m_maxPossibleG;
      param.m_maxPossibleG     = m_maxPossibleP;
      param.m_qualityP         = m_qualityP;
      param.m_qualityG         = m_qualityG;
      param.m_distErr          = m_distErr;
      param.m_relAngleErr      = m_relAngleErr;
      param.m_angleErr         = m_angleErr   ;
      param.m_typeErr          = m_typeErr    ;
      param.m_pairAngleErr     = m_pairAngleErr;
      param.m_posErr           = m_posErr      ;
      param.m_topologyAvg      = m_topologyAvg;
      param.m_topologySim      = m_topologySim;

      param.m_mainGroupSize   = m_mainGroupSize;
/*      
      param.m_mainGroupSquare = m_mainGroupSquare;

      param.m_combWidth       = m_combWidth;
      param.m_combHeight      = m_combHeight;     
      param.m_pWidth          = m_pWidth;
      param.m_gWidth          = m_gWidth;
      param.m_pHeight         = m_pHeight;
      param.m_gHeight         = m_gHeight;
*/
      param.m_numMinutiaeP    = m_numMinutiae[0];
      param.m_numMinutiaeG    = m_numMinutiae[1];

      memcpy( param.m_reserved, m_reserved, sizeof( param.m_reserved ) );

      return param;
   }
};

struct P_PACKED_1 ScoreMinexParametersEx
{
   int numGroup;
   ScoreMinexParameters *scoreParam;
   ScoreMinexParametersEx()
   {
      memset(this, 0, sizeof(ScoreMinexParametersEx));
   }
   ~ScoreMinexParametersEx()
   {
      if (scoreParam)
         delete scoreParam;
   }
};

#pragma pack (pop)

#endif // SCORE_MINEX_PARAMETERS_H_
