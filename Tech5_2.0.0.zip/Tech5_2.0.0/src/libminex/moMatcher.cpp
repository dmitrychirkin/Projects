/*
   moMatcher.cpp - implement the MoMatcher class that is supposed to compare the 
                 fingerprints on minutiae only information (x, y, angle, type)
*/
#include <time.h>

#define  _USE_MATH_DEFINES
#include <math.h>
//#include <CRTDBG.H>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>

//#include "MatLab.h"
#include "moMatcher.h"
#include "integrTrig.h"
#include "adjustMinexParams.h"
#include "scoreMinex.h"
//using namespace ma80;


// search parameters
#define MIN_FOUND_MINUTIAE      4    // minimum number of minutiae, when score > 0  
#define MIN_ROT_DIST            20   // minimum distance from minutiae to center, when 
                                     // the minutiae is used for angle rotation calculation
#define MAX_PAIR_LEN            50   // maximum and minumum distance between minutiae
#define MIN_PAIR_LEN            20   // for keeping minutiae pair in m_pairLen array

#define MAX_FOUND_GROUPS         5   // maxinum number of group, for thouse similarity 
                                     //                       will be calculated
#define MINUTIAE_ANGLE_TOL      25   // tolerance for minutiae angle, degree
#define MAX_GROUPS              180  // maximum number of groups

#define RELIABLE_GROUP_SIZE     12    // number of minutiae in a group, when we stop 
                                      // look through another minutiae 
#define QUICK_LIMIT        40 * 40    // number of minutiae in probe and gallery fingerprint, 
                                      //  when switch to quick mode 

#ifdef _DEBUG
int catchPairs[][2] = {
   4, 6,
   11, 13
};
#define CATCH_SIZE sizeof( catchPairs ) / sizeof( catchPairs[ 0 ] )

bool isWatch( int nP, int nG )
{
   for( int i = 0; i < CATCH_SIZE; i++ )
      if( nP == catchPairs[ i ][ 0 ] && nG == catchPairs[ i ][ 1 ] )
         return true;

   return false;
}
#endif


MoMatcher::MoMatcher()
{
   memset (m_numMinutiae, 0, sizeof (m_numMinutiae));
   memset (m_width, 0, sizeof (m_width));
   memset (m_height, 0, sizeof (m_height));
   memset (m_frame, 0, sizeof (m_frame));
   memset (m_quality, 0, sizeof(m_quality));
   memset (m_minutiae, 0, sizeof (m_minutiae));
   memset (m_pairs, 0, sizeof(m_pairs));
   memset (m_curMinutiae, 0, sizeof (m_curMinutiae));
   memset (m_curMinutiae, 0, sizeof(m_curMinutiae));
   memset (m_curFrame, 0, sizeof (m_curFrame));
   memset (m_exclude, 0, sizeof(m_exclude));
   memset (m_topologySim, 0, sizeof(m_topologySim));

   m_maxAngle    = DEF_MAX_MO_ANGLE;
   m_maxDistance = DEF_MAX_MO_DISTANCE;
   m_quick    = false;
   m_topologyAvg = 0;

   setTolerance (1);

   m_groups.reserve (MAX_GROUPS);   
}

MoMatcher::~MoMatcher()
{
}

void MoMatcher::setTolerance(int tolerance)
{
   if (tolerance == 1)
   {
      m_maxGroupAngle   = GROUP_ANGLE_TOL;
      m_maxMinAngle     = MINUTIAE_ANGLE_TOL;
   }
   else
   {
      m_maxGroupAngle   = GROUP_ANGLE_TOL * 2;
      m_maxMinAngle     = MINUTIAE_ANGLE_TOL * 2;
   }
   setDdist(tolerance);
}

bool isGreater_Sim( const Group & g1, const Group & g2 )
{
   if( g1.m_numItems  > g2.m_numItems  ) return true;
   if( g1.m_numItems == g2.m_numItems && 
      g1.m_similarity > g2.m_similarity ) return true;

   return false;
}
bool isReliableGroup( const Group & g )
{
   if( g.m_numItems > RELIABLE_GROUP_SIZE ) return true;
   else                                     return false;
}
int comp (const void *v1, const void *v2)
{
   MinutiaePairLen *p1 = (MinutiaePairLen*)v1;
   MinutiaePairLen *p2 = (MinutiaePairLen*)v2;
   if ( p1->m_dist == p2->m_dist) return 0;
   if ( p1->m_dist < p2->m_dist ) return -1;
   return 1;
}
// fill information about all pairs
void MoMatcher::fillPairsArray (int index)
{
   BYTE num = m_numMinutiae[index];
   Minutiae378 *min = m_minutiae[index];
   int dist = 0, dx = 0, dy = 0, dDist = 0;
   int angle = 0, angleDif = 0, angle1 = 0, angle2 = 0;
   
//   int count = 0;
//   int sumDist = 0;
   for (BYTE i = 0; i < num; i++)
      for (BYTE j = i + 1; j < num; j++)
      {
//         if (i == j)
//            continue;
         dx = min[j].x - min[i].x;
         dy = min[j].y - min[i].y;
         dist = (int)(sqrt((float)dx * dx + (float)dy * dy) + 0.5);
         // % from distance + average distance between two ridges
 //        dDist = ddist (dist);   
         angleDif = normAngle(min[i].angle - min[j].angle);
         angle = (int)iAtan2(dy, dx);
         angle1 = normAngle (min[i].angle - angle);
         angle2 = normAngle (min[j].angle - angle);
         setPair(index, i, j, dist, angle, angleDif,  angle1,  angle2);
         setPair(index, j, i, dist, normAngle (180 + angle), -angleDif, 
                     normAngle(angle2 + 180), normAngle(angle1 + 180));
         //sumDist += dist;
         //count++;
      }
}
//////////////////////////////////////////////////////////////////////////
// predicates to sort pairs length arrays
//////////////////////////////////////////////////////////////////////////

bool greater_ex( const MinutiaePairLen & pairA, const MinutiaePairLen & pairB ) 
{
   int cmp = pairA.getDist() - pairB.getDist();
   if( cmp == 0 )
   {
      cmp = pairB.getNum1() - pairA.getNum1();
      if( cmp == 0 )
      {
         cmp = pairB.getNum2() - pairA.getNum2();
         if( cmp == 0 ) cmp = 1;
      }
   }
   
   return cmp > 0;
}

bool less_ex( const MinutiaePairLen & pairA, const MinutiaePairLen & pairB )
{
   int cmp = pairA.getDist() - pairB.getDist();
   if( cmp == 0 )
   {
      cmp = pairA.getNum1() - pairB.getNum1();
      if( cmp == 0 )
      {
         cmp = pairA.getNum2() - pairB.getNum2();
         if( cmp == 0 ) cmp = 1;
      }
   }
   
   return cmp < 0;
}

//////////////////////////////////////////////////////////////////////////
// fill pairs length array
//////////////////////////////////////////////////////////////////////////
void MoMatcher::fillPairsLenArray (int index, int minDist, int maxDist)
{
   int maxDistBig = ( index == 0 ? maxDist : maxDist - ddist (maxDist) );
   int dist = 0;

   BYTE num = m_numMinutiae[index];
   m_pairLen[index].clear();
   m_pairLenFar[index].clear();
   m_pairLen[index].reserve(num * num / 8);
   m_pairLenFar[index].reserve (num * num / 2);

   for (BYTE i = 0; i < num; i++)
   {
      if( m_topologyMax[index][i] < m_minTopology ) continue;

      for (BYTE j = i + 1; j < num; j++)
      {
         if( m_topologyMax[index][j] < m_minTopology ) continue;
         dist = m_pairs[index][i][j].m_dist;
         if (dist < minDist    ) continue;
         if (dist > 200        ) continue;
         if (dist <= maxDist   ) m_pairLen[index].push_back (MinutiaePairLen (i, j, dist));
         if (dist > maxDistBig ) m_pairLenFar[index].push_back (MinutiaePairLen (i, j, dist));
      }
   }
   // sort m_pairLen by decrease and m_pairLenFar by increase m_dist
   sort (m_pairLen[index].begin(), m_pairLen[index].end(),       greater_ex );
   sort (m_pairLenFar[index].begin(), m_pairLenFar[index].end(), less_ex    );
}
// check if template is the same 
bool MoMatcher::isSameTemplate( int       index, 
                                BYTE      numMinutiae, 
                                Minutiae  minutiae[MAX_MINUTIAE], 
                                WORD      width, 
                                WORD      height, 
                                BYTE      quality )
{
   if( numMinutiae != m_numMinutiae[ index ] ||
       width       != m_width      [ index ] || 
       height      != m_height     [ index ] ||
       quality     != m_quality    [ index ]    ) return false;

   for(int i = 0; i < numMinutiae; i++)
   {
      if( m_minutiae[index][i].x     != minutiae[i].x      ||
          m_minutiae[index][i].y     != minutiae[i].y      ||
          m_minutiae[index][i].angle != minutiae[i].angle  ||
          m_minutiae[index][i].type  != minutiae[i].type     ) return false;
   }

   return true;
}
// load template
void MoMatcher::loadtemplate (int index, 
                              BYTE numMinutiae, Minutiae minutiae[MAX_MINUTIAE], 
                              WORD width, WORD height, BYTE quality)
{
   //if( isSameTemplate( index, numMinutiae, minutiae, width, height, quality ) ) return;

   m_quality[index] = quality;
   m_numMinutiae[index] = numMinutiae;
   for(int i = 0; i < numMinutiae; i++)
   {
      m_minutiae[index][i].x     = minutiae[i].x;
      m_minutiae[index][i].y     = minutiae[i].y;
      m_minutiae[index][i].angle = minutiae[i].angle;
      m_minutiae[index][i].type  = minutiae[i].type;
   }

   m_width[index]  = width;
   m_height[index] = height;
   
   // get frame around minutiae
   getFrame(m_frame[index], m_numMinutiae[index], m_minutiae[index]);
   // fill information about minutiae pairs 
   fillPairsArray(index);
   // find neighbors for each minutiae

   int maxDist = 2 * ( index ? LOCAL_CHECK_RADIUS + ddist(LOCAL_CHECK_RADIUS) : LOCAL_CHECK_RADIUS );
   for(int i = 0; i < numMinutiae; i++)
      findNeighbours ( index, i, maxDist );
}


// calculate minutiae topology for each pair 
void MoMatcher::fillTopologySim()
{
   for(int i = 0; i < MAX_MINEX_MINUTIAE; i++)
   {
      m_topologyMax[0][i] = -10;
      m_topologyMax[1][i] = -10;
   }
      
   memset (m_topologySim, 0, sizeof (m_topologySim));

   for(int i = 0; i < m_numMinutiae[0]; i++)
      for(int j = 0; j < m_numMinutiae[1]; j++)
      {
         m_topologySim[i][j] = compareMinutiaeTopology( i, j );
         if( m_topologySim[i][j] > m_topologyMax[0][i] ) m_topologyMax[0][i] = m_topologySim[i][j];
         if( m_topologySim[i][j] > m_topologyMax[1][j] ) m_topologyMax[1][j] = m_topologySim[i][j];
      }
   m_topologyAvg = 0;
   if( m_numMinutiae[ 0 ] < m_numMinutiae[ 1 ] )
   {
      for(int i = 0; i < m_numMinutiae[0]; i++ )
         m_topologyAvg += m_topologyMax[0][i];
      m_topologyAvg /= m_numMinutiae[0];
   } 
   else
   {
      for(int i = 0; i < m_numMinutiae[1]; i++ )
         m_topologyAvg += m_topologyMax[1][i];
      m_topologyAvg /= m_numMinutiae[1];
   }
}
// get frame around minutiae
void  MoMatcher::getFrame(Frame378 &frame, BYTE num, Minutiae378 *min)
{
   frame.left = MAX_WIDTH - 1;
   frame.top  = MAX_HEIGHT - 1;
   frame.right = frame.bottom = 0;
   for(unsigned int i = 0; i < num; i++)
   {
      if (min[i].x < frame.left)
         frame.left = min[i].x;
      if (min[i].x > frame.right)
         frame.right = min[i].x;
      if (min[i].y < frame.top)
         frame.top = min[i].y;
      if (min[i].y > frame.bottom)
         frame.bottom = min[i].y;
   }
}

// compare templates
bool  MoMatcher::match (MatchResult &matchRes)
{
   setTolerance (1);
   memset (&matchRes, 0, sizeof (matchRes));
   int minDist = MIN_PAIR_LEN;
   int maxDist = MAX_PAIR_LEN;
   if (m_numMinutiae[0] * m_numMinutiae[1] > QUICK_LIMIT)  {
      m_quick       = true;
      m_minTopology = MIN_REL_TOPOLOGY_SIM;
   } else {
      m_quick       = false;
      m_minTopology = MIN_TOPOLOGY_SIM;
   }  

   fillTopologySim();

#if ( !defined( ADJUST ) && !defined( _DEBUG ) )
   if( isLookImpostor( m_topologyAvg ) ) return true;
#endif
//   if( isLookGenuine ( m_topologyAvg ) ) return getGroupFast( matchRes );
   
   fillPairsLenArray (0, minDist, maxDist);
   minDist -= ddist(minDist);
   maxDist += ddist(maxDist);
   fillPairsLenArray (1, minDist, maxDist);

   // compare all pairs and form group of similar pairs
   buildGroups( true );
   // sorting group by number of items

   size_t numGroups = m_groups.size();

   //FILE* m_ff = fopen("e:\\temp\\minex.log","w");
   //for(int i = 0; i < numGroups; i++)
   //{
	  // fprintf(m_ff,"Number %d\n", i);
   //   int numItems = m_groups.at(i).m_numItems;
	  // for(int j = 0; j < numItems; j++)
		 //  fprintf(m_ff,"%d\n",m_groups.at(i).m_num[j]);
   //}
   //fclose(m_ff);

   sort (m_groups.begin(), m_groups.end(), isGreater_Sim );

   //m_ff = fopen("e:\\temp\\minex_1.log","w");
   //for(int i = 0; i < numGroups; i++)
   //{
	  // fprintf(m_ff,"Number %d\n", i);
   //   int numItems = m_groups.at(i).m_numItems;
	  // for(int j = 0; j < numItems; j++)
		 //  fprintf(m_ff,"%d\n",m_groups.at(i).m_num[j]);
   //}
   //fclose(m_ff);


   calcAllGroupScore(matchRes);

   return true;
}

// calculate maximum similarity for all found groups
void  MoMatcher::calcAllGroupScore(MatchResult &matchRes)
{
   int score = 0;
   // combine all compatible groups
   
   joinCompatibleGroups(); 
   sort (m_groups.begin(), m_groups.end(), isGreater_Sim );

   size_t numGroups = minAB( MAX_FOUND_GROUPS, m_groups.size() );
   vector<Group>::iterator p = m_groups.begin();
  
   if ( m_quick && m_groups.size() && p->m_numItems > RELIABLE_GROUP_SIZE ) numGroups = 1;

#ifdef ADJUST
//   logStartMatchMinex();
   g_minexNumGroup = 0;
#endif
   for(int i = 0; i < numGroups; i++, p++)
   {
      if ( p->m_numItems < MIN_FOUND_MINUTIAE ) break;
#ifdef ADJUST
//      clearHistMinex();
#endif
      
      m_curGroup = *p;
      score = calcGroupScore();
      if (matchRes.similarity < score)
      {
         matchRes.similarity = score;
         // copy the found points to m_result
         int nP = 0, nG = 0;
         matchRes.numPairs = m_curGroup.m_numItems;
         for (int i = 0; i < m_curGroup.m_numItems; i++)
         {
            m_curGroup.getPair (i, nP, nG);
            matchRes.minutiaeNum[i][0] = nP;
            matchRes.minutiaeNum[i][1] = nG;
         }
#ifdef ADJUST
//         updateBestHistMinex();
#endif
      }
   }
#ifdef ADJUST
//      updateAllHistMinex();
//      logFinishMatchMinex();
#endif
}

// check the local group (group minutiae those near the given minutiae)
// for compatible
bool  MoMatcher::checkLocalGroup(Group &g)
{
   int iP = 0, jP = 0, iG = 0, jG = 0;
   int localGroupSize = g.m_numItems;
   // check the all pairs from local group
   for (int k = 0; k < localGroupSize; k++)
   {
      g.getPair (k, iP, iG);
      for (int m = k + 1; m < localGroupSize; m++)
      {
         g.getPair (m, jP, jG);
         if (!compPairs(m_pairs[0][iP][jP], m_pairs[1][iG][jG]))
            return false;
      }
   }
   // if number of minutiae in the group more than 2, try to combine it
   // and 
   return true;
}

// calculate similarity index for current minutiae group
int MoMatcher::calcGroupScore()
{
   // combine fingerprints:
   // find minutiae center, rotation angle and
   // transfer gallery minutiae to coordinate system of probe
   int angle = 0;
   int xc[2], yc[2];
   if (!calcGroupCenters(m_curGroup, m_minutiae[0], m_minutiae[1], xc, yc))
      return 0; 
   if (!calcRotationAngle (m_curGroup, angle, true, xc, yc) &&
       !calcRotationAngle (m_curGroup, angle, false, xc, yc)
       ) return 0;
   m_curGroup.m_angle = angle;
   m_curGroup.setMainGroupSize();

   // if shift or rotation angle more than tolerance, return
   if( abs ( xc[0] - xc[1] )  > m_maxDistance ) return 0;
   if( abs ( angle         )  > m_maxAngle    ) return 0;
   if( abs ( yc[0] - yc[1] )  > m_maxDistance ) return 0;
   
   if (!transferMinutiae(m_minutiae[1], m_curMinutiae, m_numMinutiae[1], xc, yc, angle))
      return 0;

   // find minutiae those behind of the  another fingerprint location
   findExcludeBoth(xc, yc);

   // add in the current group the minutiae, those locate the similar
   int numAdded = expandCurGroup(xc, yc);

   return calcScore();
}
void  MoMatcher::joinCompatibleGroups()
{
   vector<Group>::iterator p =  m_groups.begin(), p1;
   vector<Group>::iterator groupsEnd =  m_groups.end();
   for(; p != groupsEnd; p++)
   {
      if (p->m_numItems <= 2)
         break;
      for(p1 = p + 1; p1 != groupsEnd; p1++)
         tryCombineGroups (*p, *p1);
   }
}

void  MoMatcher::tryCombineGroups(Group &g1, Group &g2)
{
   if (abs(normAngle(g1.m_angle - g2.m_angle)) >= GROUP_ANGLE_TOL)
      return;
   int num =  g2.m_numItems;
   if (!num)
      return;
   int np = 0, ng = 0;
   float err = 0;
   for (int i = 0; i < num; i++)
   {
      g2.getPair(i, np, ng);
      if ( g1.findProbe (np) || g1.findGallery (ng) ) continue;
      if ( !isCompatibleWithGroup (g1, np, ng, err) ) return;
      g1.add (np, ng, m_topologySim[ np ][ ng ] );
   }
   g2.clear();
}


// calculate similarity score
int MoMatcher::calcScore()
{
   ScoreMinexParameters param;
   prepareScoreParameters(param);

#ifdef ADJUST
   saveMinexParameters (param);
   g_minexNumGroup++;
#endif

   return calculateScoreMinex(param);
}

//////////////////////////////////////////////////////////////////////////
//
//                        All kinds of corrections 
//
//////////////////////////////////////////////////////////////////////////
inline float getDistErrCorrection   ( MinutiaePair &p1, MinutiaePair& p2 )
{
   return ( upri( p1.m_angle1 ) 
          + upri( p1.m_angle2 ) 
          + upri( p2.m_angle1 ) 
          + upri( p2.m_angle2 ) ) / 360.0F;
}
inline float getDistanceCorrection ( MinutiaePair &p1, MinutiaePair& p2 )
{
   float corr = 1.5F - getDistErrCorrection( p1, p2 );
   return corr;
}
inline int   getAngleCorrection      ( int minDist )
{
   if( minDist < 6  ) return 15;
   if( minDist < 10 ) return 10;
   if( minDist < 15 ) return  5;
   return 0;
}
//////////////////////////////////////////////////////////////////////////
//
//                        Score calculation functions
//
//////////////////////////////////////////////////////////////////////////
#define VAR_COUNT 2
void  MoMatcher::prepareScoreParameters(ScoreMinexParameters &param)
{
   param.m_mainGroupSize = m_curGroup.getMainGroupSize();
   // calculate pair, angle and type differences
   calcPairDif       ( param.m_distErr, param.m_relAngleErr  );
   calcAngleDif      ( param.m_angleErr                      ); 
   calcTypeDif       ( param.m_typeErr                       );
   calcPairAngleDif  ( param.m_pairAngleErr                  );
   calcMinutiaePosDif( param.m_posErr                        );
   calcTopologySim   ( param.m_topologySim                   );

   param.m_topologyAvg  = m_topologyAvg;

   param.m_foundNum     = m_curGroup.m_numItems;
   param.m_maxPossibleP = m_numMinutiae[0] - m_exclude[0].m_numItems;
   param.m_maxPossibleG = m_numMinutiae[1] - m_exclude[1].m_numItems;

   param.m_qualityP        = m_quality[0];
   param.m_qualityG        = m_quality[1];
   param.m_mainGroupSquare = 0; //getMainGroupSquare();
   // get combined size
   //calcSizes( param );
   // get sizes
   param.m_numMinutiae[ 0 ] = this->m_numMinutiae[ 0 ];
   param.m_numMinutiae[ 1 ] = this->m_numMinutiae[ 1 ];
}
// calculate bounding rectangle coordinates for given set of minutiae
void             getBoundingRectangle( Minutiae378 * pMinutiae, 
                                       int           minCount, 
                                       int         & left, 
                                       int         & top, 
                                       int         & right, 
                                       int         & bottom )
{
   int x = 0, y = 0;
   top   = left   = INT_MAX, 
   right = bottom = 0; 

   for(int np = 0; np < minCount ; np++)
   {
      x = pMinutiae[ np ].x;
      y = pMinutiae[ np ].y;
      if ( x < left   ) left   = x;
      if ( x > right  ) right  = x;
      if ( y < top    ) top    = y;
      if ( y > bottom ) bottom = y;
   }
}
// find the borders of points for combined fingerprint
void  MoMatcher::calcSizes( ScoreMinexParameters & param ) 
{
   int pTop, pLeft, pRight, pBottom; 
   int gTop, gLeft, gRight, gBottom; 
   // find borders for probe fingerprint
   getBoundingRectangle( m_minutiae[0], m_numMinutiae[0], pLeft, pTop, pRight, pBottom );
   // find borders for gallery fingerprint
   getBoundingRectangle( m_minutiae[1], m_numMinutiae[1], gLeft, gTop, gRight, gBottom );
   // get combined sizes 
/*
   param.m_pWidth     = ( short )( pRight  - pLeft );
   param.m_gWidth     = ( short )( gRight  - gLeft );
   param.m_pHeight    = ( short )( pBottom - pTop  );
   param.m_gHeight    = ( short )( gBottom - gTop  );
   param.m_combWidth  = max( pRight,  gRight  ) - min( pLeft, gLeft );
   param.m_combHeight = max( pBottom, gBottom ) - min( pTop , gTop  );
*/
}

// find size of area that main group is taken
int   MoMatcher::getMainGroupSquare()
{
   int num = m_curGroup.getMainGroupSize();
   int diag[2];
   memset (diag, 0, sizeof(diag));
   // find the first diagonal
   int maxP1 = 0, maxP2 = 0;
   int np1 = 0, np2 = 0;
   int lenP = 0;
   for (int i = 0; i < num; i++)
   {
      np1 = m_curGroup.getProbe (i);
      for (int j = i + 1; j < num; j++)
      {
         np2 = m_curGroup.getProbe (j);
         lenP = m_pairs[0][np1][np2].m_dist;
         if (lenP > diag[0])
         {
            diag[0] = lenP;
            maxP1 = np1;
            maxP2 = np2;
         }
      }
   }
   // find the second diagonal
   int a1 = m_pairs[0][maxP1][maxP2].m_angle;
   int maxDist = 0;
   for (int i = 0; i < num; i++)
   {
      np1 = m_curGroup.getProbe (i);
      if (np1 == maxP1 || np1 == maxP2)
         continue;
      maxDist = abs(sinm (m_pairs[0][maxP2][np1].m_dist, a1 - m_pairs[0][maxP2][np1].m_angle));
      if (maxDist > diag[1])
      {
         diag[1] = maxDist;
      }
   }
   return diag[0] * (diag[1] ? diag[1] : 10);
}


void  MoMatcher::calcTopologySim( float & topologySim )
{
   topologySim = 0;

   int   nP = 0, nG = 0;
   int   groupSize     = m_curGroup.m_numItems;
   
   for(int n = 0; n < groupSize; n++)
   {
      m_curGroup.getPair (n, nP, nG);
      topologySim += m_topologySim[ nP ][ nG ];

      //compareMinutiaeTopologyEx_NEW( nP, nG, match, miss, power );
#ifdef ADJUST
      //saveParamMinex (0, m_topologySim[nP][nG] + 50, nP, nG );
      //saveParamMinex (1, m_topologySim[nP][nG] + 50         );
#endif
   }

   topologySim /= groupSize;
 }

// calculate minutiae angle differences for all minutiae from current group
void  MoMatcher::calcAngleDif(float &angleErr )
{
   angleErr = 0;
   int err = 0;
   int groupSize = m_curGroup.m_numItems;
   int nP = 0, nG = 0;
   for(BYTE k = 0; k < groupSize; k++)
   {
      m_curGroup.getPair (k, nP, nG);
      err = abs(normAngle(m_minutiae[0][nP].angle - m_curMinutiae[nG].angle));
#ifdef ADJUST
//      saveParamMinex (2, err);
#endif
      angleErr += err;
   }
   angleErr = abs (angleErr / groupSize);
}

// calculate minutiae angle between pairs from current group
void  MoMatcher::calcPairAngleDif(float &angleErr)
{
   angleErr = 0;
   int count = 0;
   int err = 0;
   int groupSize = m_curGroup.m_numItems;
   int iP = 0, iG = 0, jP = 0, jG = 0, kP = 0, kG = 0;
   int angleP = 0, angleG = 0; 

   bool isClose = false;

   for(BYTE i = 0; i < groupSize; i++)
   {
      m_curGroup.getPair (i, iP, iG);
      for(BYTE j = i + 1; j < groupSize; j++)
      {

         m_curGroup.getPair (j, jP, jG);
/*
#if defined( NEW_PAIR_ANGLE_DIF ) && !defined( GOOD_OLD_VERSION )
         isClose = ( m_pairs[0][iP][jP].m_dist < MIN_PAIR_LEN ||
                     m_pairs[0][iG][jG].m_dist < MIN_PAIR_LEN    );
#endif
*/
         for(BYTE k = j + 1; k < groupSize; k++)
         {
/*
#if defined( NEW_PAIR_ANGLE_DIF ) && !defined( GOOD_OLD_VERSION )
            isClose |= ( m_pairs[0][iP][kP].m_dist < MIN_PAIR_LEN ||
                         m_pairs[0][iG][kG].m_dist < MIN_PAIR_LEN    );
#endif
*/
            m_curGroup.getPair (k, kP, kG);
            angleP = m_pairs[0][iP][jP].m_angle - m_pairs[0][iP][kP].m_angle;
            angleG = m_pairs[1][iG][jG].m_angle - m_pairs[1][iG][kG].m_angle;
            err    = abs(normAngle(angleP - angleG));
            angleErr += err;
            count++;
/*
#if defined( NEW_PAIR_ANGLE_DIF ) && !defined( GOOD_OLD_VERSION )
            if( !isClose )
            {
               angleErr[1] += err;
               count[1] ++;
            }
#endif
*/
#ifdef ADJUST
//      saveParamMinex (4, err);
#endif
        }
      }
   }
   angleErr = count ? angleErr / count : 0;
//   angleErr[1] = count[1] ? angleErr[1] / count[1] : 0;
}

// calculate minutiae position error for the current group
void  MoMatcher::calcMinutiaePosDif(float &posErr )
{
   posErr = 0;
   
   int dx = 0, dy = 0;
   int err = 0;
   int nP = 0, nG = 0;
   int groupSize = m_curGroup.m_numItems;

   int distance = 0;
   int angle    = 0;
   int dAngle   = 0;

   for(BYTE n = 0; n < groupSize; n++)
   {

      m_curGroup.getPair (n, nP, nG);
      dx         = abs(m_minutiae[0][nP].x - m_curMinutiae[nG].x);
      dy         = abs(m_minutiae[0][nP].y - m_curMinutiae[nG].y);

      distance   = dist  ( dx, dy );
//      angle      = iAtan2( dy, dx );
//      dAngle     = abs( uppi( angle - m_minutiae[0][nP].angle ) );
/*      
      posErr[1] += distance;
      if( distance > 8 && dAngle > 45 && dAngle < 135 ) 
         posErr[1] += ( distance >> 1 );
*/      
      posErr += ( dx + dy );

#ifdef ADJUST
      //saveParamMinex (6, dx + dy );
      //saveParamMinex (7, distance );
#endif
   }

   posErr = posErr / groupSize;

/*
   for(BYTE n = 0; n < mainGroupSize; n++)
   {
      m_curGroup.getPair (n, nP, nG);
      dx = abs(m_minutiae[0][nP].x - m_curMinutiae[nG].x);
      dy = abs(m_minutiae[0][nP].y - m_curMinutiae[nG].y);
      err = dx + dy;//sqrt((float)dx * dx + (float)dy * dy);
      posErr[0] += err;
#ifdef ADJUST
      saveParamMinex (6, err);
#endif
   } 
   for(BYTE n = mainGroupSize; n < groupSize; n++)
   {
      m_curGroup.getPair (n, nP, nG);
      dx = abs(m_minutiae[0][nP].x - m_curMinutiae[nG].x);
      dy = abs(m_minutiae[0][nP].y - m_curMinutiae[nG].y);
      err = dx + dy;//sqrt((float)dx * dx + (float)dy * dy);
      posErr[1] += err;
#ifdef ADJUST
      saveParamMinex (7, err);
#endif
   } 
   int num = groupSize - mainGroupSize;
   posErr[0] = posErr[0] / mainGroupSize;
   posErr[1] = num ? posErr[1] / num : 0;
*/
}


// calculate minutiae type differences for all minutiae from current group
void  MoMatcher::calcTypeDif(float &typeErr )
{
   typeErr = 0;
   int groupSize = m_curGroup.m_numItems;
   int nP = 0, nG = 0;
   for(BYTE k = 0; k < groupSize; k++)
   {
      m_curGroup.getPair (k, nP, nG);
      if (m_minutiae[0][nP].type != m_curMinutiae[nG].type)
         typeErr++; 
   }
#ifdef ADJUST
//   saveParamMinex (8, typeErr );
#endif
   typeErr = typeErr / groupSize;
/*
   int groupSize = m_curGroup.m_numItems;
   int mainGroupSize = m_curGroup.getMainGroupSize();
   int nP = 0, nG = 0;
   for(BYTE k = 0; k < mainGroupSize; k++)
   {
      m_curGroup.getPair (k, nP, nG);
      if (m_minutiae[0][nP].type != m_curMinutiae[nG].type)
         typeErr[0]++; 
#ifdef ADJUST
      saveParamMinex (8, (m_minutiae[0][nP].type != m_curMinutiae[nG].type) ? 100 : 0);
#endif
   }
   for(BYTE k = mainGroupSize; k < groupSize; k++)
   {
      m_curGroup.getPair (k, nP, nG);
      if (m_minutiae[0][nP].type != m_curMinutiae[nG].type)
         typeErr[1]++; 
#ifdef ADJUST
      saveParamMinex (9, (m_minutiae[0][nP].type != m_curMinutiae[nG].type) ? 100 : 0);
#endif
   }
   int num = groupSize - mainGroupSize;
   typeErr[0] = typeErr[0] / mainGroupSize;
   typeErr[1] = num ? typeErr[1] / num : 0;
*/
}

//////////////////////////////////////////////////////////////////////////
//    dipols represent two points located nearby, but not too close. 
//    That gives me reason to expect that flows near this dipols 
//    are relatively predictable and I can rely on
//    angle - distance - position information instead of just
//    using distance to estimate similarity.  
//////////////////////////////////////////////////////////////////////////
int              getArea       ( Minutiae378 * minutiae , int n0, int n1, int n2 ) 
{
   int x0 = minutiae[ n0 ].x;
   int x1 = minutiae[ n1 ].x;
   int x2 = minutiae[ n2 ].x;
   int y0 = minutiae[ n0 ].y;
   int y1 = minutiae[ n1 ].y;
   int y2 = minutiae[ n2 ].y;

   return ( ( abs( ( x0 - x2 ) * ( y1 - y2) - ( x1 - x2 ) * ( y0 - y2 ) ) ) >> 1 );
}
/*
   Calculate pair differences (location and angle differences for all 
   possible minutiae pairs from current group)
   *distErr     (output) - average % of distance between minutiae error
   *relAngleErr (output) - average relative angle error  (difAngle)
*/
void MoMatcher::calcPairDif(float &distErr, float &relAngleErr )
{
   distErr = relAngleErr = 0;
      
   int   angleErr = 0,
         count    = 0;
   int   groupSize = m_curGroup.m_numItems;
   int   nP1 = 0, nG1 = 0, nP0 = 0, nG0 = 0, nP = 0, nG = 0;
   int   maxDist  = 0,
         minDist  = 0,
         pArea    = 0,
         gArea    = 0;
   float dDist    = 0;

   for(BYTE k = 0; k < groupSize; k++)
   {
      m_curGroup.getPair (k, nP0, nG0);
      for(BYTE i = k +1; i < groupSize; i++)
      {
         m_curGroup.getPair (i, nP, nG);
         // calculate errors
         angleErr  = abs( normAngle( m_pairs[0][nP][nP0].m_angleDif - m_pairs[1][nG][nG0].m_angleDif));

         maxDist   = max( m_pairs[0][nP][nP0].m_dist,  m_pairs[1][nG][nG0].m_dist );
         minDist   = min( m_pairs[0][nP][nP0].m_dist,  m_pairs[1][nG][nG0].m_dist );

         if( maxDist < MIN_PAIR_LEN ) continue;

         distErr     += ( 1 - ( float )minDist/ maxDist );
         count       ++;
         relAngleErr += angleErr;
      }
   }

   distErr     = count ? 100 * distErr / count : 0;
   relAngleErr = count ? relAngleErr   / count : 0;
}
inline 
void MoMatcher::add2Group(int iP, int jP, int iG, int jG)
{
   int count = 0;

   vector<Group>::iterator p = m_groups.begin();
   bool wasAdd = false;
   for(; p != m_groups.end(); p++)
   {
      Group & curGroup = *p;
      count++;
      switch ( checkGroup ( curGroup, iP, jP, iG, jG ) )
      {
      case 1:
         curGroup.add (iP, iG, m_topologySim[ iP ][ iG ] );
         wasAdd = true;
         break;
      case 2:
         curGroup.add (jP, jG, m_topologySim[ jP ][ jG ]);
         wasAdd = true;
         break;
      default:
         continue;
      }
   }
   // no one group fit - create the new one
   if ( wasAdd )  return;
   Group g;
   g.add (iP, iG, m_topologySim[ iP ][ iG ]);
   g.add (jP, jG, m_topologySim[ jP ][ jG ]);
   g.m_angle = normAngle(m_pairs[0][iP][jP].m_angle - 
                         m_pairs[1][iG][jG].m_angle);
   m_groups.push_back (g);
   size_t num = m_groups.size();
}

/*
   check if (iP, iG) or (jP, jG) minutiae pair can be add to the group
   return:
   0 - if cannot
   1 - (iP, iG) can be added  
   2 - (jP, jG) can be added  
*/
inline 
int  MoMatcher::checkGroup ( Group & g, int iP, int jP, int iG, int jG )
{
   float err = 0;
   if ( g.isExtendableWith( iP, iG, jP, jG ) && isCompatibleWithGroup (g, jP, jG, err) ) return 2;
   if ( g.isExtendableWith( jP, jG, iP, iG ) && isCompatibleWithGroup (g, iP, iG, err) ) return 1;
   return 0;
}
inline 
int  MoMatcher::checkGroup ( vector<Group>::iterator p, int iP, int jP, int iG, int jG )
{
   float err = 0;
   if (p->find (iP, iG) 
       && !p->findProbe (jP) 
       && !p->findGallery (jG)
       && isCompatibleWithGroup (*p, jP, jG, err) 
      )
      return 2;
   if (p->find (jP, jG) 
       && !p->findProbe (iP) 
       && !p->findGallery (iG)
       && isCompatibleWithGroup (*p, iP, iG, err)
       )
       return 1;
   return 0;
}

// check if (nP, nG) minutiae pair can be add to the group
// compare all pairs and form group of similar pairs
void MoMatcher::buildGroups( bool isRel )
{
   m_groups.clear();

   int iP, jP, iG, jG;
   int dist = 0, minDist = 0, maxDist = 0, dDist = 0;
   int distG = 0;

   vector<MinutiaePairLen>::iterator pP = m_pairLen[0].begin();
   vector<MinutiaePairLen>::iterator pG;

   while (pP != m_pairLen[0].end() && pP->m_dist > MAX_PAIR_LEN)
      pP++;
   for( ; pP != m_pairLen[0].end(); pP++)
   {
      dist     = pP->m_dist;
      dDist    = ddist(dist);
      minDist  = dist - dDist;
      maxDist  = dist + dDist;
      iP       = pP->m_num1;
      jP       = pP->m_num2;
      pG       = m_pairLen[1].begin();

      for (; pG != m_pairLen[1].end(); pG++)
      {
         distG = pG->m_dist;
         if ( distG > maxDist ) continue;
         if ( distG < minDist ) break;
         iG = pG->m_num1;
         jG = pG->m_num2;

         if      (compareMinutiae (iP, iG) &&
                  compareMinutiae (jP, jG) &&
                  compPairs (m_pairs[0][iP][jP], m_pairs[1][iG][jG])) add2Group(iP, jP, iG, jG);
         else if (compareMinutiae (iP, jG) &&
                  compareMinutiae (jP, iG) &&
                  compPairs (m_pairs[0][iP][jP], m_pairs[1][jG][iG])) add2Group(iP, jP, jG, iG);  
      }

      if ( m_quick && 
         m_groups.size() && 
         find_if( m_groups.begin(), m_groups.end(), isReliableGroup ) != m_groups.end() ) 
         return;

      if ( m_groups.size() >= MAX_GROUPS ) 
         return;
   }
   // resort by increase the m_dist
   pP = m_pairLenFar[0].begin();
   for( ; pP != m_pairLenFar[0].end(); pP++)
   {
      dist  = pP->m_dist;
      dDist = ddist(dist);
      minDist = dist - dDist;
      maxDist = dist + dDist;
      iP = pP->m_num1;
      jP = pP->m_num2;

      pG = m_pairLenFar[1].begin();
      for (; pG != m_pairLenFar[1].end(); pG++)
      {
         distG = pG->m_dist;
         if ( distG < minDist ) continue;
         if ( distG > maxDist ) break;
         iG = pG->m_num1;
         jG = pG->m_num2;

         if      (compareMinutiae (iP, iG) &&
                  compareMinutiae (jP, jG) &&
                  compPairs (m_pairs[0][iP][jP], m_pairs[1][iG][jG])) add2Group(iP, jP, iG, jG); 
         else if (compareMinutiae (iP, jG) &&
                  compareMinutiae (jP, iG) &&
                  compPairs (m_pairs[0][iP][jP], m_pairs[1][jG][iG])) add2Group(iP, jP, jG, iG); 
      }

      if ( m_quick && 
           m_groups.size() && 
           find_if( m_groups.begin(), m_groups.end(), isReliableGroup ) != m_groups.end() ) return;
         
      if ( m_groups.size() >= MAX_GROUPS ) 
         return;
   }
}
// check if two pairs are similar
inline bool MoMatcher::compPairs (MinutiaePair &p1, MinutiaePair &p2, float *err)
{
   int dist1        = p1.m_dist;
   int dist2        = p2.m_dist;
   int minDist      = min( dist1, dist2 );
   int dDist        = ( int )( ddist( minDist ) * getDistanceCorrection( p1, p2 ) );
  
   if ( abs (            dist1         - dist2          ) > dDist                 )  return false;

   int aCorrect     = getAngleCorrection( minDist );

   if ( abs ( normAngle (p1.m_angleDif - p2.m_angleDif) ) >   m_maxMinAngle              ) return false;
   if ( abs ( normAngle (p1.m_angle1   - p2.m_angle1  ) ) > ( m_maxMinAngle + aCorrect ) ) return false;
   if ( abs ( normAngle (p1.m_angle2   - p2.m_angle2  ) ) > ( m_maxMinAngle + aCorrect ) ) return false;

   if ( err )
      *err = ( (float)abs ( normAngle(p1.m_angleDif - p2.m_angleDif))   
             + (float)abs ( normAngle(p1.m_angle1   - p2.m_angle1))     
             + (float)abs ( normAngle(p1.m_angle2   - p2.m_angle2))  ) / m_maxMinAngle
             + (float)abs ( dist1                   - dist2       )    / dDist;

   return true;
}
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
bool MoMatcher::isCompatibleWithGroup       ( Group &g, int nP, int nG, float &err, bool local, int maxDist)
{
   // compare all new pairs (those appears because the new minutiae pair added)
#ifdef _DEBUG
   for( int i = 0; i < CATCH_SIZE; i++ )
      if( catchPairs[i][0] == nP && catchPairs[i][1] == nG )
         break;

#endif
   err = 0;
   float e = 0;
   int count = 0;
   int angle = 0;
   int num = g.m_numItems;
   int gP = 0, gG = 0;
   for (int i = 0; i < num; i++)
   {
      g.getPair (i, gP, gG);
      if ( local && m_pairs[0][gP][nP].m_dist > maxDist ) continue;

      angle = normAngle(m_pairs[0][gP][nP].m_angle - m_pairs[1][gG][nG].m_angle);

      if ( abs(normAngle(angle - g.m_angle)) >= m_maxGroupAngle    ) return false;
      if ( !compPairs (m_pairs[0][gP][nP], m_pairs[1][gG][nG], &e) ) return false;
      
      err += e;
      err += (float)abs(angle) / GROUP_ANGLE_TOL;
      count++;
   }
   err = count ? err / count : -1;
   return (count > 0);
}   
// calculate center of minutiae group for current group
bool MoMatcher::calcGroupCenters(Group &g, Minutiae378 *min1, Minutiae378 *min2,
                                 int xc[2], int yc[2])
{
   int n1 = 0, n2 = 0;
   xc[0] = xc[1] = yc[0] = yc[1] = 0;
   int numPair = g.m_numItems;
   if (!numPair) 
      return false;
   for (int i = 0; i < numPair; i++)
   {
      g.getPair (i, n1, n2);
      xc[0] += min1[n1].x;
      yc[0] += min1[n1].y;
      xc[1] += min2[n2].x;
      yc[1] += min2[n2].y;
   }
   xc[0]  /= numPair;
   yc[0]  /= numPair;
   xc[1] /= numPair;
   yc[1] /= numPair;
   
   return true;
}

// calculate angle rotation for combine probe and gallery minutiae for current group
bool MoMatcher::calcRotationAngle(Group &g, int &angle, bool reliable,
                                  int xc[2], int yc[2])
{
   int n1 = 0, n2 = 0;
   int numPair = g.m_numItems;

   int count=0;
   int x1 = 0, y1 = 0;   // distance from center of 1st group
   int x2 = 0, y2 = 0;   // distance from center of 2nd group
   int ang1 = 0, ang2 = 0, difAngle = 0; 
   float sum = 0;
//   float minAngle = 1000, maxAngle = -1000;
   bool around180 = false;
   float distP = 0, distG = 0, sumDistP = 0;

   for (int i = 0; i < numPair; i++ )
   {
      g.getPair (i, n1, n2);
      x1 = m_minutiae[0][n1].x - xc[0];
      y1 = m_minutiae[0][n1].y - yc[0];
      x2 = m_minutiae[1][n2].x - xc[1];
      y2 = m_minutiae[1][n2].y - yc[1];
      // don't use minutiae those close to the center
      distP = (float)sqrt ((float)x1 * x1 + (float)y1 * y1);
      distG = (float)sqrt ((float)x2 * x2 + (float)y2 * y2);
      bool smallR1 = distP < MIN_ROT_DIST;
      bool smallR2 = distG < MIN_ROT_DIST;
      if (reliable && (smallR1 || smallR2)
          ) continue;              
      ang1 = iAtan2(y1, x1);
      ang2 = iAtan2(y2, x2);
      difAngle = normAngle(ang1 - ang2);
      if (!i && abs(abs(difAngle) - 180) < GROUP_ANGLE_TOL + 10)  // around 180
         around180 = true;
      if (around180)
         difAngle += (difAngle > 0 ? -1 : 1) * 180;

      sum += difAngle * distP;
      sumDistP += distP;
      count++;
/*
      if (minAngle > difAngle)
         minAngle = difAngle;
      if (maxAngle < difAngle)
         maxAngle = difAngle;
*/
   }
   if( count <= 2)
      return false;

   angle = (int)normAngle(sum / sumDistP);
   if (around180)
      angle = normAngle(angle + 180);
   return true;
}

// rotate and shift the gallery minutiae to combine with probe minutiae
bool MoMatcher::transferMinutiae(Minutiae378 *srcMin, Minutiae378 *dstMin, int num,
                                 int xc[2], int yc[2], int angle)
{
   if (!srcMin || !dstMin)
      return false;
   angle = normAngle(angle);
   int x = 0, y = 0;
   float r = 0;
   int ang = 0;

   for (int i = 0; i < num; i++ )
   {
      x = srcMin[i].x - xc[1];
      y = srcMin[i].y - yc[1];
      r =  (float)sqrt ((float)x * x + (float)y * y);
      ang = iAtan2(y, x);
      dstMin[i].x = xc[0] + (int)(iCos(ang + angle) * r + 0.5);
      dstMin[i].y = yc[0] + (int)(iSin(ang + angle) * r + 0.5);
      dstMin[i].angle = normAngle( srcMin[i].angle + angle );
      dstMin[i].type = srcMin[i].type;
   }
   return true;
}

// find minutiae those behind the image for both probe and gallery minutiae
void MoMatcher::findExcludeBoth(int xc[2], int yc[2])
{
   // calculate frame around transferred minutiae
   memcpy(&m_curFrame[0], &m_frame[0], sizeof(m_frame[0]));
   getFrame(m_curFrame[1], m_numMinutiae[1], m_curMinutiae);
   expandBothFrame(xc, yc);
   // find exclude minutiae (check minutiae one image by Frame another image)
   findExclude(m_numMinutiae[0], m_minutiae[0], m_curFrame[1], m_exclude[0]);
   findExclude(m_numMinutiae[1], m_curMinutiae, m_curFrame[0], m_exclude[1]);
}

// find minutiae those behind the image of another fingerprint
void MoMatcher::findExclude(int num, Minutiae378 *min, Frame378 &frame, 
                            NumMinutiaeStore &exclude)
{
   exclude.clear();
   for (BYTE i = 0; i < num; i++)
   {
      if (min[i].x < frame.left  ||
          min[i].x > frame.right ||
          min[i].y < frame.top   ||
          min[i].y > frame.bottom
          ) exclude.add (i);
   }
}

// inflate frame around minutiae to distance tolerance
void MoMatcher::expandBothFrame(int xc[2], int yc[2])
{
   // image already combine, so they have the same rotation center
   expandFrame(m_width[0], m_height[0], xc[0], yc[0], m_curFrame[0]);
   expandFrame(m_width[1], m_height[1], xc[0], yc[0], m_curFrame[1]);
}

void MoMatcher::expandFrame(WORD width, WORD height, int xc, int yc, Frame378 &frame)
{
   // calculate maximum distance tolerance
   int w = frame.right  - frame.left + 1;
   int h = frame.bottom - frame.top  + 1;
   int dw = ddist(w );
   int dh = ddist(h);
   // expand frame
   frame.left   -= dw;
   frame.right  += dw;
   frame.top    -= dh;
   frame.bottom += dh;
}

// compare two minutiae by its topology information
// return penalty
inline 
bool MoMatcher::compareMinutiae(int nP, int nG)
{
   return (m_topologySim[nP][nG] >= m_minTopology );
}

//////////////////////////////////////////////////////////////////////////
//
//                    Acceleration tools
//
//////////////////////////////////////////////////////////////////////////
bool MoMatcher::getGroupFast( MatchResult& matchRes )
{
   if( buildGroupTA() )
   {
      size_t numGroups = m_groups.size();
      sort (m_groups.begin(), m_groups.end(), isGreater_Sim );
      calcAllGroupScore(matchRes);
      if( matchRes.similarity <= 0 ) return false;
   }
   else
   {
      return false;
   }

   return true;
}
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
bool MoMatcher::buildGroupTA()
{
   /*
   int count = 0, i = 0, j = 0, iP = 0, iG = 0, jP = 0, jG = 0;
      
      m_groups.clear();
      m_curGroup.clear();
   
      m_pairLenCount[ 0 ] = 0;
      m_pairLenCount[ 1 ] = 0;
   
      for( int i = 0; i < m_numMinutiae[ 0 ]; i++ )
         for( int j = 0; j < m_numMinutiae[ 1 ]; j++ )
            m_pairLength[ 0 ][ count++ ].set( i, j, ( int )( m_topologySim[ i ][ j ] * 1000 ) );
   
      qsort( m_pairLength[ 0 ], count, sizeof( m_pairLength[ 0 ][ 0 ]  ), comp );
      int minTopology = m_pairLength[ 0 ][ count ];
      int maxTopology = m_pairLength[ 0 ][ 0     ];
      int limTopology = max( ( int )( ( maxTopology - minTopology ) * 0.8F ) + minTopology, m_minTopology );
         
      i = 0;
      while( m_pairLength[ 0 ][ i ].m_dist > limTopology )
      {
         iP = m_pairLength[ 0 ][ i ].m_num1;
         jP = m_pairLength[ 0 ][ i ].m_num2;
         j = i + 1;
         while( m_pairLength[ 0 ][ j ].m_dist > limTopology )
         {
            iG = m_pairLength[ 0 ][ j ].m_num1;
            jG = m_pairLength[ 0 ][ j ].m_num2;
            if      ( compPairs (m_pairs[0][iP][jP], m_pairs[1][iG][jG] ) ) add2Group(iP, jP, iG, jG);
            else if ( compPairs (m_pairs[0][iP][jP], m_pairs[1][jG][iG] ) ) add2Group(iP, jP, jG, iG);
            j++;
         }
         if ( m_quick && 
            m_groups.size() && 
            find_if( m_groups.begin(), m_groups.end(), isReliableGroup ) != m_groups.end() ) return true;
   
         if ( m_groups.size() >= MAX_GROUPS ) return true;
         i++;
      }*/
   

   return true;
}