//////////////////////////////////////////////////////////////////////////
//
//   THIS .CPP CONTAINS IMPLEMENTATION OF MINEX NEIGHBOURS RELATED 
//          MEMBER FUNCTIONS OF THE MoMatcher CLASS
//
//////////////////////////////////////////////////////////////////////////
#include "moMatcher.h"
#include "integrTrig.h"

#define SINGULAR_RADIUS      80
#define MIN_NEIGHBOUR_DIST   5    // minimal distance to the neighbour minutiae 
#define USE_NEIGHBOURS       8

#define DST_MAX              30
#define DST_WEIGHT           45
#define DIR_WEIGHT           31
#define ORI_WEIGHT           7
#define MATCHING_WEIGHT      0.27F
#define MISSING_WEIGHT       0.03F

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
inline void  placeNeighbor( int * distArr, int * numArr, int count, int newNum, int newDist, int * maxDist = NULL)
{
   int * pDist  = ( distArr + count - 1 );
   int * pNum   = ( numArr  + count - 1 );
   
   while( *pDist >= newDist )
   {
      *( pDist + 1 ) = *pDist;
      *( pNum  + 1 ) = *pNum ;
         pDist --;
         pNum  --;
   } 
      
   *( pDist + 1 ) = newDist;
   *( pNum  + 1 ) = newNum;

   if( maxDist )
      *maxDist = *( distArr + count - 1 );
}
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
inline int   getNeighbourWeight         ( Neighbourhood * neighbourhood, int i )
{
   int aOri = abs( neighbourhood->m_neighbour[ i ].m_ori );

   if( neighbourhood->m_isByCore || neighbourhood->m_isByDelta || neighbourhood->m_isDiverged )
   {
      if( aOri < 45  ) return 7;
      if( aOri < 90  ) return 14;
      if( aOri < 135 ) return 13;
      else             return 24;
   } else {
      if( aOri < 45  ) return 14;
      if( aOri < 90  ) return 24;
      if( aOri < 135 ) return 24;
      else             return 28;
   }
}
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
inline int   checkBestNeighbour          ( NewNeighbour  * bestG,
                                           int             bestP,
                                           Neighbourhood * nbrP,
                                           bool          * taken,
                                           int           & bestErr )
{
   int   curDist =  0,
         curDir  =  0,
         curOri  =  0,
         curErr  =  0,
         countP  = nbrP->m_num,
         i       =  bestP;

   for( int i = bestP - 1; i >= 0; i-- )
   {
      if ( taken[ i ] ) continue;
      if ( ( curDist = abs( bestG->m_dis - nbrP->m_neighbour[ i ].m_dis ) ) > DST_MAX  ) break;
      if ( ( curDir  = abs( bestG->m_dir - nbrP->m_neighbour[ i ].m_dir ) ) > 45       ) continue;
      if ( ( curOri  = abs( bestG->m_ori - nbrP->m_neighbour[ i ].m_ori ) ) > 100      ) continue;

      curErr = DST_WEIGHT * curDist + DIR_WEIGHT * curDir + ORI_WEIGHT * curOri;
      if( curErr > bestErr ) continue;

      bestP    = i;
      bestErr  = curErr;
   }

   for( int i = bestP + 1; i < countP; i++ )
   {
      if ( taken[ i ] ) continue;
      if ( ( curDist = abs( bestG->m_dis - nbrP->m_neighbour[ i ].m_dis ) ) > DST_MAX  ) break;
      if ( ( curDir  = abs( bestG->m_dir - nbrP->m_neighbour[ i ].m_dir ) ) > 45       ) continue;
      if ( ( curOri  = abs( bestG->m_ori - nbrP->m_neighbour[ i ].m_ori ) ) > 100      ) continue;

      curErr = DST_WEIGHT * curDist + DIR_WEIGHT * curDir + ORI_WEIGHT * curOri;
      if( curErr > bestErr ) continue;

      bestP    = i;
      bestErr  = curErr;
   }

   return bestP;
}
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
inline int   findBestNeighbour           ( NewNeighbour  * probe, 
                                           Neighbourhood * nbrG, 
                                           bool  * taken , 
                                           int   & bestErr )
{
   int   bestG   = -1,
         curDist =  0,
         curDir  =  0,
         curOri  =  0,
         curErr  =  0,
         countG  = nbrG->m_num,
         i       =  0;
   
   bestErr = 1000;

   while( ( abs( probe->m_dis - nbrG->m_neighbour[ i ].m_dis ) > DST_MAX ) && i < countG )
      i++;

   for( ; i < countG; i++)
   {
      if ( taken[ i ] ) continue;
      if ( ( curDist = abs( probe->m_dis - nbrG->m_neighbour[ i ].m_dis ) ) > DST_MAX  ) break;
      if ( ( curDir  = abs( probe->m_dir - nbrG->m_neighbour[ i ].m_dir ) ) > 45       ) continue;
      if ( ( curOri  = abs( probe->m_ori - nbrG->m_neighbour[ i ].m_ori ) ) > 100      ) continue;
         
      curErr = DST_WEIGHT * curDist + DIR_WEIGHT * curDir + ORI_WEIGHT * curOri;
      if( curErr > bestErr ) continue;

      bestG    = i;
      bestErr  = curErr;
   }

   return bestG;
}
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
       float MoMatcher::compareMinutiaeTopology ( int nP, int nG )
{
   if( abs( normAngle( m_minutiae[ 0 ][ nP ].angle - m_minutiae[ 1 ][ nG ].angle ) ) > m_maxMinAngle + m_maxAngle )
      return MIN_TOPOLOGY_SIM - 1;

   Neighbourhood * nbrP = &m_minNeighbourhood[ 0 ][ nP ];
   Neighbourhood * nbrG = &m_minNeighbourhood[ 1 ][ nG ];

   int   bestP    = -1, 
         bestG    = -1,
         curP     =  0,
         err      =  0,
         numP     =  nbrP->m_num,//min( nbrP->m_num, USE_NEIGHBOURS ),
         numG     =  nbrG->m_num,//min( nbrG->m_num, USE_NEIGHBOURS ),
         bOri     =  0,
         curWeight = 0,
         matchTopology = 0, missTopology = 0;

   bool  takenG[MAX_NEIGHBOURS], 
         takenP[MAX_NEIGHBOURS];
   
   memset (takenG, 0, sizeof (takenG));
   memset (takenP, 0, sizeof (takenP));

   while( curP < numP )
   {
      if ( !takenP[ curP ] )
      {
         if ( ( bestG = findBestNeighbour  ( &nbrP->m_neighbour[ curP  ], nbrG, takenG, err       ) ) >= 0 &&
              ( bestP = checkBestNeighbour ( &nbrG->m_neighbour[ bestG ], curP, nbrP, takenP, err ) ) >= 0    )
         {
            takenG [ bestG  ] = true;
            takenP [ bestP  ] = true;
            curWeight         = nbrP->m_neighbour[ bestP ].m_weight + nbrG->m_neighbour[ bestG ].m_weight;
            matchTopology    += curWeight * ( 1000 - err );
            
            if( curP == bestP ) 
               curP ++;
         }
         else
         {
            takenP[ curP ] = true;
            if( nbrP->m_neighbour[ curP ].m_dis <= nbrG->m_radius ) 
               missTopology += nbrP->m_neighbour[ curP ].m_weight;
            curP ++;
         }
      }
      else
         curP ++;
   }

   for (int j = 0; j < numG; j++)
   {
      if ( takenG[ j ]        ||
         nbrG->m_neighbour[ j ].m_dis > nbrP->m_radius ) continue;

      missTopology += nbrG->m_neighbour[ j ].m_weight;
   }

   return ( float )( MATCHING_WEIGHT * matchTopology / 1000 - MISSING_WEIGHT * missTopology );
}
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
       int   MoMatcher::findNeighbours          ( int index, int curMinutiae, int maxDist )
{
   int            numMin = this->m_numMinutiae[ index ];
   memset (&this->m_minNeighbourhood[ index ][ curMinutiae ], 0, sizeof ( Neighbourhood ) );

   // find close minutiae
   int          distArray [ MAX_NEIGHBOURS + 2 ];
   int          numArray  [ MAX_NEIGHBOURS + 2 ];

   numArray [ 0 ] = curMinutiae;
   distArray[ 0 ] = 0;
   int dist  = 0;
   int count = 1;
   for (int i = 0; i < numMin; i++)
   {
      if ( curMinutiae == i ) continue;
      dist = this->m_pairs[ index ][ curMinutiae ][ i ].m_dist; 
      if ( dist >= MIN_NEIGHBOUR_DIST && dist <= maxDist )
      {
         if ( count <= MAX_NEIGHBOURS ) placeNeighbor( distArray, numArray, count++, i, dist );
         else                           placeNeighbor( distArray, numArray, count  , i, dist, &maxDist );
      }
   }
   if ( count == 1 ) return 0;
   // fill neighbors
   fillNeighbours( m_pairs[ index ], numArray, count, this->m_minNeighbourhood[ index ][ curMinutiae ] );

   return count - 1;
}
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
       void  MoMatcher::fillNeighbours              ( MinutiaePair   pairs   [ MAX_MINEX_MINUTIAE ][ MAX_MINEX_MINUTIAE ], 
                                                      int            numArray[ MAX_NEIGHBOURS + 1 ], 
                                                      int            num, 
                                                      Neighbourhood &neighbourhood )
{
   if ( num > MAX_NEIGHBOURS + 1 ) num = MAX_NEIGHBOURS + 1;

   neighbourhood.m_num = num - 1;
   int  count        = 0;
   int  centralNum   = neighbourhood.m_minIndex = numArray[ 0 ];

   int streightOrientation = 0,
       oppositOrientation  = 0,
       coreOrientation     = 0,
       deltaOrientation    = 0,
       aOri                = 0,
       curDist             = 0;

   for (int i = 1; i < num; i++, count ++ )
   {
      curDist = pairs[ centralNum ][ numArray[ i ] ].m_dist;
      neighbourhood.m_neighbour[ count ].m_dis   =   curDist;
      neighbourhood.m_neighbour[ count ].m_dir   = - pairs[ centralNum ][ numArray[ i ] ].m_angle1;
      neighbourhood.m_neighbour[ count ].m_ori   = - pairs[ centralNum ][ numArray[ i ] ].m_angleDif;
      neighbourhood.m_neighbour[ count ].m_index =   numArray[ i ];

      if( curDist < SINGULAR_RADIUS )
      {
         aOri = abs( neighbourhood.m_neighbour[ count ].m_ori );
         if     ( aOri <  35  ) streightOrientation ++;
         else if( aOri <  60  ) deltaOrientation    ++;
         else if( aOri < 120  ) coreOrientation     ++;
         else if( aOri < 145  ) deltaOrientation    ++;
         else                   oppositOrientation  ++;
      }

      if( neighbourhood.m_radius < curDist ) neighbourhood.m_radius = curDist;
   }

        if ( coreOrientation > 1 && (coreOrientation + deltaOrientation) > 4  ) neighbourhood.m_isByCore   = true;
   else if ( deltaOrientation > 3                                             ) neighbourhood.m_isByDelta  = true;
   else if ( streightOrientation > 3 && !oppositOrientation                   ) neighbourhood.m_isDiverged = true;

   for ( int i = 0; i < neighbourhood.m_num; i++ )
      neighbourhood.m_neighbour[ i ].m_weight = getNeighbourWeight( &neighbourhood, i );
}
