// libminex.cpp : Defines the entry point for the DLL application.
//
#ifdef _WINDOWS
#include <windows.h>
#endif


#ifdef PIV_CERTIFICATION
//   #define  TIME_PROTECT
#endif


#include <stdio.h>
//#include <shlwapi.h>
#include <time.h>

#include "coreSdk.h"
#include "ip.h"
#include "sfsDef.h"
#include "ti.h"

#include "libMinexFull.h"
#include "template_NIST.h"
#include "template_ISO.h"
#include "moMatcher.h"
#include "adjustMinexParams.h"
#include "nistQualityTools.h"
#include "compressTemplate.h"
#include "fileUtl.h"
#include "wizard73.h"

// process parameters
#define MAX_PROCESS_WIDTH     0//480
#define MAX_PROCESS_HEIGHT    0//480

volatile bool g_initialized = false;

/*
   Initialize library.
   MUST BE CALLED ONE TIME WHILE PROCESS ATTACH
*/
void initialize()
{
   if (g_initialized)
      return;
   calcDdist();
   g_initialized = true;
}

//////////////////////////////////////////////////////////////////////////
#if !defined(_LIB) && defined(_WINDOWS)
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
                       )
{

   switch (ul_reason_for_call)
   {
   case DLL_PROCESS_ATTACH:
      initialize();
      break;
   case DLL_THREAD_ATTACH:
      break;
   case DLL_THREAD_DETACH:
      break;
   case DLL_PROCESS_DETACH:
      break;
   }
    return TRUE;
}

#endif


void set_null_MO_template (RawImage &rawImage, BYTE quality, BYTE *moTemplate, bool nistTemplate, unsigned int *templSize)
{
   Minutiae min[MAX_FINGERS][MAX_MINUTIAE];
   unsigned int numMinutiae = 0;
   if (nistTemplate)
      buildNISTtemplate (1, &rawImage, &quality, moTemplate, &numMinutiae, min, 0, false, 0, templSize);
   else
      buildISOtemplate (1, &rawImage, &quality, moTemplate, &numMinutiae, min, 0, false, 0, templSize);
}

BYTE getFpQuality (BYTE *fpTemplate)
{
   unsigned char quality = 0;
   Ti ti;
   if (ti.getQuality(fpTemplate, quality) != TI_OK)  return 0;
   
   if (quality <= QUAL_POOR)
      quality = QUAL_POOR;
   else if (quality <= QUAL_FAIR)
      quality = QUAL_FAIR;
   else if (quality <= QUAL_GOOD)
      quality = QUAL_GOOD;
   else if (quality <= QUAL_VGOOD)
      quality = QUAL_VGOOD;
   else
      quality = QUAL_EXCELLENT;

   return quality;
}

int getAlowsNumMinutiae (unsigned int numFingers, unsigned int maxSize, bool nistTemplate)
{
   if (nistTemplate)
      return getAlowsNumMinutiaeNIST (numFingers, maxSize);
   else
      return getAlowsNumMinutiaeISO  (numFingers, maxSize);
}

int convertToMoTemplate (unsigned int numFingers, RawImage *rawImage, BYTE *fpTemplate[MAX_FINGERS], 
                         BYTE *moTemplate, BYTE * quality, bool nistTemplate, unsigned int maxTemplateSize = 0, 
                         Frame *pFrame = NULL, bool certifiedSensor = false, WORD sensorID = 0, unsigned int *templSize = NULL)
{
   int result = SME_OK;
   if (numFingers > MAX_FINGERS)
      numFingers = MAX_FINGERS;
   // check required template size
   unsigned int maxNum = 0;
   if (maxTemplateSize)
   {
      maxNum = getAlowsNumMinutiae (numFingers, maxTemplateSize, nistTemplate);
      if (maxNum < numFingers * MIN_MINUTIAE_NUMBER)
         return SME_SMALL_REQUIRED_SIZE;
   }

   unsigned int numMinutiae[MAX_FINGERS];
   Minutiae minutiae[MAX_FINGERS][MAX_MINUTIAE];
   memset(minutiae, 0, sizeof(minutiae));
   Frame frame[MAX_FINGERS];
   if (pFrame)
      for(unsigned int i = 0; i < numFingers; i++)
         memcpy(&frame[i], &pFrame[i], sizeof(frame[0]));
   else
      memset(&frame, 0, sizeof(frame));

   try
   {
      // get minutiae
      Ti ti;
      for (unsigned int i = 0; i < numFingers; i++)
      {
         if (ti.getMinutiae (fpTemplate[i], numMinutiae[i], minutiae[i]) != TI_OK)
            throw SME_PROCESS;
      }
      if (maxTemplateSize)
         compressTemplate (numFingers, numMinutiae, minutiae, maxNum);

      // build template
      if (nistTemplate)
         result = buildNISTtemplate (numFingers, rawImage, quality, moTemplate, numMinutiae, minutiae, 
                                       frame, certifiedSensor, sensorID, templSize);
      else
         result = buildISOtemplate (numFingers, rawImage, quality, moTemplate, numMinutiae, minutiae, 
                                       frame, certifiedSensor, sensorID, templSize);
      if (result != SME_OK)
         throw result;
   }
   catch (int &errNum)
   {
      set_null_MO_template (rawImage[0], quality[0], moTemplate, nistTemplate, templSize);
      return errNum;
   }
   return SME_OK;
}

int tech5_2_iso_nist (BYTE *fpTemplate, BYTE *moTemplate, bool nistTemplate)
{
   if (!fpTemplate || !moTemplate)
      return SME_WRONG_POINTER;
   try
   {
      Ti ti;
      RawImage rawImage;
      BYTE *templ[MAX_FINGERS];
      templ[0] = fpTemplate;
      // get TECH5 quality
      BYTE quality = getFpQuality (fpTemplate);
      // get image size
      int width = 0, height = 0;
      if (ti.getImageSize (fpTemplate, width, height) != TI_OK)  throw SME_PROCESS;
      FINGERS fingerPos= FINGPOS_UK;
      if (ti.getFingerPos (fpTemplate, fingerPos) != TI_OK)  throw SME_PROCESS;
      rawImage.width  = width;
      rawImage.height = height;
      rawImage.finger = fingerPos;

      return convertToMoTemplate (1, &rawImage, templ, moTemplate, &quality, nistTemplate);
   }
   catch(...)
   {
      return SME_UNKN_ERR;
   }
}

int convertToNIST (BYTE *fpTemplate, BYTE *templ)
{
   return tech5_2_iso_nist (fpTemplate, templ, true);
}

int convertToISO (BYTE *fpTemplate, BYTE *templ)
{
   return tech5_2_iso_nist (fpTemplate, templ, false);
}

/*
   check source image parameters:
   - all fingers shold be different 
   - image size should be the same for all fingers
*/
int checkImageParameters(int numFingers, RawImage *rawImage)
{
   for(int i = 0; i < numFingers; i++)
      for(int j = i + 1; j < numFingers; j++)
      {
         if (rawImage[i].finger == rawImage[j].finger)
            return SME_SAME_FING;
         if (rawImage[i].width != rawImage[j].width)
            return SME_DIF_FING_SIZE;
         if (rawImage[i].height != rawImage[j].height)
            return SME_DIF_FING_SIZE;
      }
   return SME_OK;
}

int create_templateEx (unsigned int numFingers, RawImage *rawImage, BYTE *moTemplate, 
                     bool nistTemplate, unsigned int *templSize, BYTE *quality_out, unsigned int maxTemplateSize, 
                     BYTE *quality_in, bool certifiedSensor, WORD sensorID)
{
   int result = SME_OK;
   if (numFingers > MAX_FINGERS)
      numFingers = MAX_FINGERS;
   if (!rawImage || !moTemplate || !templSize || !quality_out)
      return SME_WRONG_POINTER;

#ifdef TIME_PROTECT
   bool timeProtect = true;
	time_t t;	
	time(&t);
	struct tm* pTime = localtime(&t);  
	if (pTime->tm_year + 1900 > PROTECT_YEAR) 
			timeProtect = false;
	else if(pTime->tm_year + 1900 == PROTECT_YEAR)
	{
	   if (pTime->tm_mon + 1  > PROTECT_MONTH)
		   timeProtect = false;
	   else if(pTime->tm_mon + 1 == PROTECT_MONTH && 
				pTime->tm_mday >= PROTECT_DAY)
		timeProtect = false;
	 }
   if (!timeProtect)
      return SME_TRIAL_EXPIRED;
#endif


   // check source image parameters
   result = checkImageParameters(numFingers, rawImage);
   if (result != SME_OK)
      return result;

   static int count = 0;
   BYTE *templ[MAX_FINGERS];
   // check parameters
   if (!moTemplate || !templSize)
      return SME_WRONG_POINTER;
   
   if (quality_in) memcpy(quality_out, quality_in, sizeof(quality_out[0]) * numFingers);
   else            memset(quality_out,          0, sizeof(quality_out[0]) * numFingers);

   try
   {
      // process image
      Ip ip; 

      if (ip.init() != IP_OK)  
         throw SME_PROCESS;
      ProcessParam param;
#ifdef PIV_CERTIFICATION
      param.maxHeight = MAX_PROCESS_HEIGHT;
      param.maxWidth  = MAX_PROCESS_WIDTH;
#endif
      Frame frame[MAX_FINGERS];
      unsigned int tmpSize = 0;
      for(unsigned int i = 0; i < numFingers; i++)
      {
         if (!rawImage[i].image || !rawImage[i].width || !rawImage[i].height)
            throw SME_NULL_IMAGE;
         templ[i] = new BYTE [MAX_TEMPLATE_SIZE];
         if (!templ[i])
            throw SME_LOW_MEMORY;
         memset(templ[i], 0, MAX_TEMPLATE_SIZE);
         int quality = 0;
         if (ip.processRaw (NULL, rawImage[i].image, rawImage[i].width, rawImage[i].height, templ[i], 
                           &tmpSize,  &quality,  &param, &frame[i]) != IP_OK ) 
            throw SME_PROCESS;

         if (!quality_in)
            quality_out[i] = getNistQuality( rawImage[i].image, rawImage[i].width, rawImage[i].height);
      }
//      saveFile("/sdcard/TECH5/1.tpl", templ[0], tmpSize);
      // build INCITS 378 template
      result = convertToMoTemplate (numFingers, rawImage, templ, moTemplate, 
                                       quality_out, nistTemplate, maxTemplateSize, frame, certifiedSensor, sensorID, templSize);
      if (result != SME_OK)
         throw result;
   }
   catch (int &numErr)
   {
      result = numErr;
   }
   catch (...)
   {
      result = SME_PROCESS;
   }
   if (result != SME_OK)
       set_null_MO_template (rawImage[0], quality_out[0], moTemplate, nistTemplate, templSize);
   
   for(unsigned int i = 0; i < numFingers; i++)
      if (templ[i]) delete [] templ[i];

   return result;
}


int create_NIST_template (unsigned int   numFingers, 
                          RawImage      *raw_image, 
                          unsigned char *moTemplate, 
                          unsigned int  *templSize, 
                          unsigned char *quality_out,   
                          unsigned int   maxTemplateSize, 
                          unsigned char *quality_in, 
                          bool certifiedSensor,
                          WORD sensorID                     )
{
   return create_templateEx (numFingers, raw_image, moTemplate, true, templSize, quality_out, maxTemplateSize, quality_in, certifiedSensor, sensorID);
}

int create_ISO_template (unsigned int   numFingers, 
                         RawImage      *raw_image, 
                         BYTE          *moTemplate, 
                         unsigned int  *templSize, 
                         unsigned char *quality_out,   
                         unsigned int   maxTemplateSize, 
                         BYTE          *quality_in, 
                         bool           certifiedSensor, 
                         WORD           sensorID)
{
   return create_templateEx (numFingers, raw_image, moTemplate, false, templSize, quality_out, maxTemplateSize, quality_in, certifiedSensor, sensorID);
}

int create_template (const BYTE* image, BYTE finger_quality,
                     BYTE finger_position, BYTE impression_type,
                     WORD height, WORD width, BYTE *moTemplate)
{
   RawImage rawImage;
   rawImage.width  = width;
   rawImage.height = height;
   rawImage.image = (BYTE*)image;
   rawImage.finger = finger_position;
   rawImage.impression_type = impression_type;
   unsigned int templSize = 0;
   BYTE quality_out = 0;
   return create_NIST_template ((int)1, &rawImage, moTemplate, (unsigned int *)&templSize, &quality_out, 
                        0, &finger_quality);
}

int readTemplate (unsigned int &numFingers,
                    const BYTE *moTemplate, BYTE numMinutiae[MAX_FINGERS],
                    Minutiae minutiae[MAX_FINGERS][MAX_MINUTIAE], 
                    WORD &width, WORD &height, BYTE quality[MAX_FINGERS],
                    BYTE finger[MAX_FINGERS], bool nistTemplates)
{
   if (nistTemplates)
      return readNISTtemplate (numFingers, moTemplate, numMinutiae, minutiae, 
                                 width, height, quality, finger);
   else
      return readISOtemplate (numFingers, moTemplate, numMinutiae, minutiae, 
                              width, height, quality, finger);
}



int match_templatesEx (const BYTE *probeTemplate, const BYTE *galleryTemplate, int maxAngle,
                       MatchResult matchResult[MAX_FINGERS][MAX_FINGERS], bool nistTemplates,
                       int *score)
{
   MoMatcher   *matcher = NULL;
   *score = 0;
   int result = SME_OK;
#ifdef TIME_PROTECT
   bool timeProtect = true;
	time_t t;	
	time(&t);
	struct tm* pTime = localtime(&t);  
	if (pTime->tm_year + 1900 > PROTECT_YEAR) 
			timeProtect = false;
	else if(pTime->tm_year + 1900 == PROTECT_YEAR)
	{
	   if (pTime->tm_mon + 1  > PROTECT_MONTH)
		   timeProtect = false;
	   else if(pTime->tm_mon + 1 == PROTECT_MONTH && 
				pTime->tm_mday >= PROTECT_DAY)
		timeProtect = false;
	 }
   if (!timeProtect)
      return SME_TRIAL_EXPIRED;
#endif
   try
   {
      if (!g_initialized)
         initialize();
      if (!probeTemplate || !galleryTemplate || !score)
         return SME_WRONG_POINTER;

      // read probe template
      BYTE probeNumMinutiae[MAX_FINGERS];
      Minutiae probeMinutiae[MAX_FINGERS][MAX_MINUTIAE];
      BYTE probeFinger[MAX_FINGERS];
      WORD probeWidth = 0, probeHeight = 0;
      BYTE probeQuality[MAX_FINGERS];
      unsigned int probeNumFingers = MAX_FINGERS;
      // read probe template
      if (readTemplate (probeNumFingers, probeTemplate, probeNumMinutiae, probeMinutiae, 
                              probeWidth, probeHeight, probeQuality, probeFinger, nistTemplates) != SME_OK) 
         throw SME_PROBE_PARSE;
      if (!probeNumMinutiae[0]) 
         throw SME_NULL_TEMPLATE;

      // read gallery template
      BYTE galleryNumMinutiae[MAX_FINGERS];
      Minutiae galleryMinutiae[MAX_FINGERS][MAX_MINUTIAE];
      BYTE galleryFinger[MAX_FINGERS];
      WORD galleryWidth = 0, galleryHeight = 0;
      BYTE galleryQuality[MAX_FINGERS];
      unsigned int galleryNumFingers = MAX_FINGERS;
      if (readTemplate (galleryNumFingers, galleryTemplate, galleryNumMinutiae, galleryMinutiae, 
                              galleryWidth, galleryHeight, galleryQuality, galleryFinger, nistTemplates) != SME_OK) 
            throw SME_GALLERY_PARSE;
      if (!galleryNumMinutiae[0]) 
         throw SME_NULL_TEMPLATE;

      // match possible pairs
      matcher = new MoMatcher;
      if (!matcher)
         throw SME_LOW_MEMORY;
      matcher->setParameters(maxAngle);
      int count = 0;
      *score = 0;
      for (unsigned int i = 0; i < probeNumFingers; i++)
      {
         for (unsigned int j = 0; j < galleryNumFingers; j++)
         {
            memset(&matchResult[i][j], 0, sizeof(MatchResult));
            if (probeFinger[i] != galleryFinger[j])
               continue;
            count++;
            matcher->loadProbe (probeNumMinutiae[i], probeMinutiae[i], 
                                    probeWidth, probeHeight, probeQuality[i]);
            matcher->loadGallery (galleryNumMinutiae[j], galleryMinutiae[j], 
                                    galleryWidth, galleryHeight, galleryQuality[i]);
            if (!matcher->match (matchResult[i][j]))
               continue;
            *score += matchResult[i][j].similarity;
         }
      }
      if (!count)
         throw SME_DIF_FING;
      *score /= count;
   }
   catch (int &e)
   {
      *score = 0;
      result = e;

#if defined PIV_CERTIFICATION
      if (e == SME_DIF_FING)
      {
         *score = 0;
         result = SME_OK;
      }
      else
         *score = -1;
#endif

   }
   catch (...)
   {
      *score = 0;
      result = SME_MATCH;

#if defined PIV_CERTIFICATION
      *score = -1;
#endif

   }
   if (matcher) delete matcher;
   return result;
}

int match_NIST_templates (const BYTE *probe_template, const BYTE *gallery_template,
                     int maxAngle, int *score)
{
   MatchResult matchResult[MAX_FINGERS][MAX_FINGERS];
   bool nistTemplates = true;
   return  match_templatesEx (probe_template, gallery_template, maxAngle,
                       matchResult, nistTemplates, score);
}

int match_ISO_templates (const BYTE *probe_template, const BYTE *gallery_template,
                     int maxAngle, int *score)
{
   MatchResult matchResult[MAX_FINGERS][MAX_FINGERS];
   bool nistTemplates = false;
   return  match_templatesEx (probe_template, gallery_template, maxAngle,
                       matchResult, nistTemplates, score);
}


int match_templates (const BYTE *probe_template, const BYTE *gallery_template, float *score)
{
   int sco = 0;   
   int result = match_NIST_templates (probe_template, gallery_template, DEF_MAX_MO_ANGLE, &sco);
   *score = (float)sco / MAX_SCORE;
   return result;
}


int get_pids (DWORD *feature_extractor, DWORD *matcher)
{
   if (!feature_extractor || !matcher)
      return SME_WRONG_POINTER;
   *feature_extractor = swapDWORD(EXTRACTOR_CBEFF_PID);
   *matcher           = swapDWORD(MATCHER_CBEFF_PID);
   return SME_OK;
}

bool saveFile (const char *name, unsigned char *buffer, int size)
{
   FILE *f = fopen (name, "wb");
   if (!f)
      return false;
   bool result = (fwrite (buffer, 1, size, f) == size);
   fclose (f);
   return result;
}

bool saveNISTtemplate (const char *name, const BYTE *templ)
{
   try
   {
      int size = getNISTtemplateSize(templ);
      return saveFile (name, (BYTE*)templ, size);
   }
   catch(...)
   {
      return false;
   }
}

bool saveISOtemplate (const char *name, const BYTE *templ)
{
   try
   {
      int size = getISOtemplateSize(templ);
      return saveFile (name, (BYTE*)templ, size);
   }
   catch(...)
   {
      return false;
   }
}


int allocateTemplate (unsigned int numFingers, BYTE **templ, bool nistTemplate)
{
   if (!templ)
      return SME_WRONG_POINTER;
   try
   {
      int size = nistTemplate ? calcFullNISTtemplSize(numFingers) : calcFullISOtemplSize(numFingers);
      *templ = NULL;
      *templ = new BYTE[size];
      if (!*templ)
         return SME_LOW_MEMORY;
      memset(*templ, 0, size);
   }
   catch(...)
   {
      return SME_UNKN_ERR;
   }
   return SME_OK;
}

int allocateNISTtemplate (unsigned int numFingers, BYTE **nistTempl)
{
   bool nistTemplates = true;
   return allocateTemplate(numFingers, nistTempl, nistTemplates);
}

int allocateISOtemplate (unsigned int numFingers, BYTE **isoTempl)
{
   bool nistTemplates = false;
   return allocateTemplate(numFingers, isoTempl, nistTemplates);
}

int freeTemplate (BYTE **templ)
{
   if (!*templ) return SME_OK;
   try
   {
      delete [] *templ;
      *templ = NULL;
   }
   catch(...)
   {
      return SME_UNKN_ERR;
   }
   return SME_OK;
}

int freeNISTtemplate  (BYTE **templ)
{
   return freeTemplate(templ);
}

int freeISOtemplate  (BYTE **templ)
{
   return freeTemplate(templ);
}
 
int getTemplateSize(const BYTE *templ, bool nistTemplate)
{
   if (!templ) 
      return SME_OK;
   try
   {
      if (nistTemplate) return getNISTtemplateSize(templ);
      else              return getISOtemplateSize (templ);
   }
   catch(...)
   {
      return SME_UNKN_ERR;
   }
}

int getMinTemplateSize(unsigned int numFingers, bool nistTemplate)
{
   try
   {
      if (nistTemplate) return getMinNISTtemplateSize(numFingers);
      else              return getMinISOtemplateSize (numFingers);
   }
   catch(...)
   {
      return SME_UNKN_ERR;
   }
}

