#include <math.h>

#include "win2lin.h"
#include "scoreMinex.h"
#include "adjustMinexParams.h"
#include "libMinexFull.h"
#include "moMatcher.h"
#include "sfsDef.h"



//////////////////////////////////////////////////////////////////////////
bool isLookImpostor( float topologyAVG )
{
   if( topologyAVG * 100 < ( float )0 ) return true;
   else                                                   return false;
}
bool isLookGenuine( float topologyAVG )
{
   if( topologyAVG * 10  > ( float )200 ) return true;
   else                                                   return false;
}
//////////////////////////////////////////////////////////////////////////


int calculateScoreMinex(ScoreMinexParameters &param)
{
   int similarity = 0;
   int minQ = min (param.m_qualityP, param.m_qualityG);
   

   int foundNum      = param.m_foundNum;
   int mainGroupSize = param.m_mainGroupSize;
   int restGroupSize = foundNum - mainGroupSize;
   int minP          = min (param.m_maxPossibleP, param.m_maxPossibleG);
   int maxP          = max (param.m_maxPossibleP, param.m_maxPossibleG);
   int dP            = maxP - minP;
   int numMinutiaeP  = param.m_numMinutiae [0];
   int numMinutiaeG  = param.m_numMinutiae [1];
   int maxMinutiae   = max( numMinutiaeP, numMinutiaeG );
   int minMinutiae   = min( numMinutiaeP, numMinutiaeG );

   //if( isLookImpostor( param.m_topologyAvg ) ) return 0;


   similarity   =   (g_k_scoreMinex[0] + g_k_scoreMinex[1] * minQ / 100) * mainGroupSize  / minP 
                  + g_k_scoreMinex[5] * restGroupSize  / minP
                  + g_k_scoreMinex[9] * param.m_relAngleErr / 100
//                  + g_k_scoreMinex[10]  * param.m_typeErr / 100
                  + (g_k_scoreMinex[11] + g_k_scoreMinex[12] * minQ / 100) * param.m_angleErr   
//                  + (g_k_scoreMinex[13] + g_k_scoreMinex[14] * minQ / 100)* param.m_posErr / 100
                  + (g_k_scoreMinex[15] + g_k_scoreMinex[16] * minQ  / 100) * param.m_distErr
                  + param.m_topologySim * g_k_scoreMinex[17] / 100
                  + g_k_scoreMinex[19] * param.m_pairAngleErr
                  + g_k_scoreMinex[20]
                  + g_k_scoreMinex[21] * minQ / 100
                  + g_k_scoreMinex[22] * mainGroupSize;


   if ( similarity < 0         ) similarity = 0;
   if ( similarity > MAX_SCORE ) similarity = MAX_SCORE;
   
   return similarity;
}