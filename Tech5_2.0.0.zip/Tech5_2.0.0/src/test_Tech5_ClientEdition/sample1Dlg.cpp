// sample1Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "sample1.h"
#include "sample1Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

#define TIME_OUT   10					// timeout capture fingerprint image (sec)
#define MAX_IMAGE_SIZE   1280 * 1280 *10    // maximum of image size (1 MB)
/////////////////////////////////////////////////////////////////////////////
void drawImage (unsigned char* dib, HWND parent)
{
	if (!dib)
		return ;

	LPBITMAPINFO bi            = (LPBITMAPINFO)dib;
	LPBITMAPINFOHEADER bih     = (LPBITMAPINFOHEADER)dib;
	const unsigned char *image = dib + bih->biSize + sizeof(RGBQUAD) * 256;

	// get the drawing area context and size
	RECT rect;
	HWND hWnd = (HWND)parent; 
	HDC hDc = GetDC (hWnd);
	GetClientRect (hWnd, &rect);
	int width = abs(rect.right - rect.left);
	int height = abs(rect.bottom - rect.top);


	// calculate new size of drawing area for stretch image proportionally
	if( (float)abs(bih->biHeight) / bih->biWidth > (float)height / width) 
		width = int((float)bih->biWidth * height / abs(bih->biHeight));
	else
		height = int((float)abs(bih->biHeight) * width / bih->biWidth);

	::SetStretchBltMode(hDc, COLORONCOLOR);

	::StretchDIBits(hDc, 0, 0, width, height, 0, 0, 
		bih->biWidth, abs(bih->biHeight), image, bi, 
		DIB_RGB_COLORS, SRCCOPY ); 
}

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSample1Dlg dialog

CSample1Dlg::CSample1Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSample1Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSample1Dlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_fpTemplate = NULL;
	m_fpTemplate_NIST = NULL;
	m_fpTemplate_ISO  = NULL;
	m_dib = NULL;
	m_isCapture = false;
	m_sdk = NULL;
}


void CSample1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSample1Dlg)
	DDX_Control(pDX, IDC_SAVE, m_saveBtn);
	DDX_Control(pDX, IDC_PROCESS, m_processBtn);
	DDX_Control(pDX, IDC_PROCESS_NIST,m_process_NISTBtn);
	DDX_Control(pDX, IDC_FINGER, m_finger);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_PROCESS_ISO, processISO);
}

BEGIN_MESSAGE_MAP(CSample1Dlg, CDialog)
	//{{AFX_MSG_MAP(CSample1Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_MATCH, OnMatch)
	ON_BN_CLICKED(IDC_PROCESS, OnProcess)
	ON_BN_CLICKED(IDC_SAVE, OnSave)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_READ, OnRead)
	ON_BN_CLICKED(IDC_PROCESS_NIST, &CSample1Dlg::OnBnClickedProcessNist)
	ON_BN_CLICKED(IDC_MATCH_NIST, &CSample1Dlg::OnBnClickedMatchNist)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_PROCESS_ISO, &CSample1Dlg::OnBnClickedProcessIso)
	ON_BN_CLICKED(IDC_MATCH_ISO, &CSample1Dlg::OnBnClickedMatchIso)
	ON_BN_CLICKED(IDC_MATCH_TECH5_NIST, &CSample1Dlg::OnBnClickedMatchTECH5Nist)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSample1Dlg message handlers

BOOL CSample1Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	try
	{

		// initialize Tech5 SDK
		if (initSDK(&m_sdk,0)!= SE_OK || !m_sdk)
		{
			MessageBox ("initSDK failed", "Error", MB_OK | MB_ICONERROR);
			throw "error";
		}

		// set license path and specific data


		char license_filename[MAX_PATH];
		int result = SE_OK;
		if( getLicenseFileName(license_filename) )
		{
			result = setLicense(m_sdk,license_filename,0);
			if (result != SE_OK)
			{
				MessageBox (getLastErrorMsg(m_sdk), "Error", MB_OK | MB_ICONERROR);
				throw "error";
			}
		}
		else
		{
			throw "License file did not located";
		}
		// allocate memory for fingerprint image and template
		clear();
		m_dib = new BYTE [MAX_IMAGE_SIZE];
		allocate_Template_Tech5(m_sdk, &m_fpTemplate);
		allocate_Template_NIST (m_sdk, 1, &m_fpTemplate_NIST);
		allocate_Template_ISO  (m_sdk, 1, &m_fpTemplate_ISO );
		UpdateData (FALSE);
	}
	catch (CMemoryException* e)
	{
		e->ReportError();
		EndDialog (IDCANCEL);
	}
	catch(...)
	{
		MessageBoxA("Error. Sample terminated.",0,MB_OK | MB_ICONHAND);
		EndDialog(IDCANCEL);
	}
	return TRUE;  
}


void CSample1Dlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// release allocated memory
	clear();
	// uninitialize Tech5 SDK
	if(m_sdk)
		closeSDK(&m_sdk); m_sdk = NULL;
}




void CSample1Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSample1Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
		// call drawImage() SDK function if there is captured image
		if (m_isCapture)
			drawImage (m_dib, m_finger.GetSafeHwnd());
		else
			clearArea();
	}
}

void CSample1Dlg::clearArea()
{
	CDC* pDc = m_finger.GetDC();
	CRect rect;
	m_finger.GetClientRect(&rect);
	pDc->FillSolidRect (&rect, RGB(255, 255, 255));
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSample1Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

// release allocated memory
void CSample1Dlg::clear()
{
	if (m_dib)
	{
		delete m_dib;
		m_dib = NULL;
	}
	if(m_fpTemplate)
	{
		free_Template_Tech5(m_sdk, &m_fpTemplate);
		m_fpTemplate = NULL;
	}
	if(m_fpTemplate_NIST)
	{
		free_Template_NIST(m_sdk, &m_fpTemplate_NIST);
		m_fpTemplate_NIST = NULL;
	}
	if(m_fpTemplate_ISO)
	{
		free_Template_ISO(m_sdk, &m_fpTemplate_ISO);
		m_fpTemplate_ISO = NULL;
	}
}



// save saving captured image in BMP file
void CSample1Dlg::OnSave() 
{
	CFileDialog dlg (FALSE, "bmp", NULL, NULL,
		"Bitmap files|*.bmp;*.dib|WSQ files|*.wsq||", this);
	if (dlg.DoModal() != IDOK)
		return;
	CString name = dlg.GetPathName();
	int result = SE_OK;
	// call save2Bmp() SDK function for saving captured image to BMP file
	if( dlg.GetFileExt() == "wsq")
		result = save2Wsq(m_sdk, (LPTSTR)(LPCTSTR)name.GetBuffer(_MAX_PATH), m_dib);
	else if( (dlg.GetFileExt() == "bmp") || (dlg.GetFileExt() == "dib"))
		result = save2Bmp(m_sdk, (LPTSTR)(LPCTSTR) name.GetBuffer(_MAX_PATH), m_dib);
	if (result == SE_OK)
		MessageBox("Fingerprint image saved successfully","Success",MB_OK | MB_ICONINFORMATION);
	else
		MessageBox (getLastErrorMsg(m_sdk), "fingerprint image save error", MB_OK | MB_ICONERROR);
}

/*
	read fingerprint image from BMP file, that was scanned with 500 DPI resolution
*/
void CSample1Dlg::OnRead() 
{
	CFileDialog dlg (TRUE, "wsq", NULL, NULL,
		"Bitmap, WSQ files|*.wsq;*.dib;*.bmp||", this);
	if (dlg.DoModal() != IDOK)
		return;
	CString name = dlg.GetPathName();

	// call readBmp() SDK function 
	int result = SE_OK;
	unsigned int size = MAX_IMAGE_SIZE;
	if(dlg.GetFileExt().MakeLower() == "wsq")
		result = readWsq (m_sdk, name.GetBuffer(_MAX_PATH), &size, m_dib);
	else if( (dlg.GetFileExt().MakeLower() == "bmp") || (dlg.GetFileExt().MakeLower() == "dib") )
		result = readBmp(m_sdk, name.GetBuffer(_MAX_PATH), &size, m_dib);
	else
		return;
	if (result != SE_OK)
	{
		MessageBox (getLastErrorMsg(m_sdk), "Fingerprint image read error", MB_OK | MB_ICONERROR);
		return;
	}
	// display read fingerprint image 
	m_isCapture = true;
	Invalidate();

	// enable 'process' and 'save' buttons because there is captured image now
	m_processBtn.EnableWindow();
	m_process_NISTBtn.EnableWindow();
	processISO.EnableWindow();
	m_saveBtn.EnableWindow();

}



// get template from captured fingerprint image and save it to file
void CSample1Dlg::OnProcess() 
{
	unsigned int templSize = 0;		// template size
	BYTE quality = 0;				// fingerprint quality


	// call process() SDK function
	DIBImage dib_str;
	dib_str.finger = FINGPOS_RT;
	dib_str.image = m_dib;

	long start_time = GetTickCount();
	int result = create_Template_Tech5Ex(m_sdk,dib_str, m_fpTemplate, &templSize, &quality,0,0);
	long stop_time = GetTickCount();
	if (result != SE_OK)
	{
		MessageBox (getLastErrorMsg(m_sdk), "Processing error", MB_OK | MB_ICONERROR);
		return;
	}
	// ask for saving template to file 
	CString msg;
	msg.Format("Template size = %d quality = %d time = %d ms\nSave to file?", templSize, quality, stop_time - start_time);
	if (MessageBox (msg, "Processing successful", MB_YESNO | MB_ICONQUESTION) == IDYES)
			saveTemplateTech5(m_fpTemplate, templSize);
}

// compare two templates, those early saved in two files
void CSample1Dlg::OnMatch() 
{
	CString name1, name2;						// template file names
	CString msg;
	BYTE* fpTemplate1 = NULL;
	BYTE* fpTemplate2 = NULL;

	try
	{
		// Select the first template file
		CFileDialog fileDlg (TRUE, "tpl", NULL, NULL,
						"Tech5 template files (*.tpl)|*.tpl||", this);
		fileDlg.m_ofn.lpstrTitle = "First template file selection";   
		if (fileDlg.DoModal() != IDOK)
			return;
		name1 = fileDlg.GetPathName();
		
		// Select the second template file
		CFileDialog fileDlg_2 (TRUE, "tpl", NULL, NULL,
			"Tech5 template files (*.tpl)|*.tpl||", this);
		fileDlg_2.m_ofn.lpstrTitle = "Second template file selection";   
		if (fileDlg_2.DoModal() != IDOK)
			return;
		name2 = fileDlg_2.GetPathName();

		// read templates into pTemplate1 and pTemplate2
		CFile f;
		f.Open(name1, CFile::modeRead | CFile::typeBinary);   
		int sizeCode = (int)f.GetLength();
		fpTemplate1 = new BYTE[sizeCode];
		f.Read (fpTemplate1, sizeCode);
		f.Close();
		f.Open(name2, CFile::modeRead | CFile::typeBinary);
		sizeCode = (int)f.GetLength();
		fpTemplate2 = new BYTE[sizeCode];
		f.Read (fpTemplate2, sizeCode); 
		f.Close();
		
		// call match SDK function
		BYTE score = 0;
		int result = match_Templates_Tech5 (m_sdk, fpTemplate1, fpTemplate2, &score);
		if (result != SE_OK)
		{
			MessageBox (getLastErrorMsg(m_sdk), "Match error", MB_OK | MB_ICONERROR);
		}
		else
		{
			msg.Format (_T("score = %d"), score);
			MessageBox (msg, _T("Success"));
		}
	}
	catch( CFileException* e )
	{
		msg.Format("File %s could not be opened: %s", e->m_strFileName, e->m_cause);
		MessageBox (msg);
	}
	catch(CException* e)
	{
		e->ReportError();
	}
	catch(...)
	{
		msg.Format("Error");
		MessageBox (msg);
	}
	if (fpTemplate1) delete fpTemplate1;
	if (fpTemplate2) delete fpTemplate2;
}



/*
	save template to file 
	pTemplate - a pointer to the buffer that contains template
	size - size of template
*/
void CSample1Dlg::saveTemplateTech5 (BYTE *fpTemplate, int size)
{
	// select file name
	CFileDialog fileDlg (FALSE, "tpl", NULL, NULL,
					"Template files (*.tpl)|*.tpl||", this);
	fileDlg.m_ofn.lpstrTitle = "Template file selection";   
	if (fileDlg.DoModal() != IDOK) return;
	CString name = fileDlg.GetPathName();
   return saveTemplate(name, fpTemplate, size);
}

void CSample1Dlg::saveTemplateNIST (BYTE *fpTemplate, int size)
{
	// select file name
	CFileDialog fileDlg (FALSE, "nist", NULL, NULL,
					"Template files (*.nist)|*.nist||", this);
	fileDlg.m_ofn.lpstrTitle = "NIST template file selection";   
	if (fileDlg.DoModal() != IDOK) return;
	CString name = fileDlg.GetPathName();
   return saveTemplate(name, fpTemplate, size);
}

void CSample1Dlg::saveTemplateISO (BYTE *fpTemplate, int size)
{
	// select file name
	CFileDialog fileDlg (FALSE, "iso", NULL, NULL,
					"Template files (*.iso)|*.iso||", this);
	fileDlg.m_ofn.lpstrTitle = "ISO template file selection";   
	if (fileDlg.DoModal() != IDOK) return;
	CString name = fileDlg.GetPathName();
   return saveTemplate(name, fpTemplate, size);
}


// save data to file
void CSample1Dlg::saveTemplate (CString &name, BYTE *fpTemplate, int size)
{
	try
	{
		CFile f;
		f.Open(name, CFile::modeCreate | CFile::modeWrite );
		f.Write (fpTemplate, size);
		f.Close();
	}
	catch( CFileException* e )
	{
		CString msg;
		msg.Format("File %s could not be opened\n%s", name, e->m_cause);
		MessageBox ( msg, e->m_strFileName, MB_OK);
	}
}

void CSample1Dlg::copyDib(BYTE *dstDIB, BYTE *srcDIB)
{
	LPBITMAPINFOHEADER bih = (LPBITMAPINFOHEADER)srcDIB;
	int size = bih->biSizeImage + bih->biSize + sizeof(RGBQUAD) * 256;
	memcpy(dstDIB, srcDIB, size);
}

bool CSample1Dlg::getLicenseFileName(char* license_filename)
{
	bool status = false;
	FILE *ff = NULL;
	const char* defExt = "*.lic;*.bin";
	char filename[MAX_PATH];
	char filter[MAX_PATH];

	try
	{
		strcpy(license_filename,"");
		memset(filename,0,MAX_PATH*sizeof(char));
		OPENFILENAME ofn;

		memset(filter,0,MAX_PATH*sizeof(char));
		strcpy(filter,"license files");
		size_t len = strlen(filter);
		memcpy(filter+(len+1),defExt,strlen(defExt)*sizeof(char));
		memset(&ofn,0,sizeof(ofn));

		ofn.lStructSize = sizeof(ofn);
		ofn.lpstrFile = filename;
		ofn.nMaxFile = MAX_PATH;
		ofn.lpstrFilter = filter;
		ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST;
		if( !GetOpenFileName(&ofn))
			throw 1;
		strcpy(license_filename,filename);
		status = true;
	}
	catch(...)
	{
		status = false;
	}
	return status;
}
void CSample1Dlg::OnBnClickedProcessNist()
{
	// TODO: Add your control notification handler code here
	int templSize = 0;		// template size
	BYTE quality = 0;				// fingerprint quality


	// call process() SDK function
	DIBImage dibImage[1];
	dibImage[0].finger = FINGPOS_RT;
	dibImage[0].image = m_dib;
	long start_time = GetTickCount();
	int result = create_Template_NIST(m_sdk,1,dibImage,m_fpTemplate_NIST,&quality,&templSize,false,0);
	long stop_time = GetTickCount();
	if (result != SE_OK)
	{
		MessageBox (getLastErrorMsg(m_sdk), "Processing error", MB_OK | MB_ICONERROR);
		return;
	}
	// ask for saving template to file 
	CString msg;
	msg.Format("Template size = %d quality = %d time = %d ms\nSave to file?", templSize, quality, (stop_time - start_time));
	if (MessageBox (msg, "Processing successful", MB_YESNO | MB_ICONQUESTION) == IDYES)
		saveTemplateNIST(m_fpTemplate_NIST, templSize);
}

void CSample1Dlg::OnBnClickedMatchNist()
{
	// TODO: Add your control notification handler code here
	CString name1, name2;						// template file names
	CString msg;
	BYTE* fpTemplate1 = NULL;
	BYTE* fpTemplate2 = NULL;

	try
	{
		// Select the first template file
		CFileDialog fileDlg (TRUE, "nist", NULL, NULL,
			"NIST template files (*.nist)|*.nist||", this);
		fileDlg.m_ofn.lpstrTitle = "First nist template file selection";   
		if (fileDlg.DoModal() != IDOK)
			return;
		name1 = fileDlg.GetPathName();

		// Select the second template file
		CFileDialog fileDlg2 (TRUE, "nist", NULL, NULL,
			"NIST template files (*.nist)|*.nist||", this);
		fileDlg2.m_ofn.lpstrTitle = "Second nist template file selection";   
		if (fileDlg2.DoModal() != IDOK)
			return;
		name2 = fileDlg2.GetPathName();

		// read templates into pTemplate1 and pTemplate2
		CFile f;
		f.Open(name1, CFile::modeRead | CFile::typeBinary);   
		int sizeCode = (int)f.GetLength();
		fpTemplate1 = new BYTE[sizeCode];
		f.Read (fpTemplate1, sizeCode);
		f.Close();
		f.Open(name2, CFile::modeRead | CFile::typeBinary);
		sizeCode = (int)f.GetLength();
		fpTemplate2 = new BYTE[sizeCode];
		f.Read (fpTemplate2, sizeCode); 
		f.Close();

		// call match SDK function
		BYTE similarity = 0;
		int result = match_Templates_NIST (m_sdk, fpTemplate1, fpTemplate2, &similarity);
		if (result != SE_OK)
		{
			MessageBox (getLastErrorMsg(m_sdk), "Match error", MB_OK | MB_ICONERROR);
			return;
		}
		msg.Format (_T("similarity = %d"), similarity);
		MessageBox (msg, _T("Success"));
	}
	catch( CFileException* e )
	{
		msg.Format("File %s could not be opened: %s", e->m_strFileName, e->m_cause);
		MessageBox (msg);
	}
	catch(CException* e)
	{
		e->ReportError();
	}
	if (fpTemplate1) delete fpTemplate1;
	if (fpTemplate2) delete fpTemplate2;
}


void CSample1Dlg::OnBnClickedProcessIso()
{
	// TODO: Add your control notification handler code here
	int templSize = 0;		// template size
	BYTE quality[1];				// fingerprint quality


	// call process() SDK function
	DIBImage dibImage[1];
	dibImage[0].finger = FINGPOS_RT;
	dibImage[0].image = m_dib;
	quality[0] = 0;

	long start_time = GetTickCount();
	int result = create_Template_ISO(m_sdk,1,dibImage,m_fpTemplate_ISO,quality,&templSize,false,0);
	long stop_time = GetTickCount();
	if (result != SE_OK)
	{
		MessageBox (getLastErrorMsg(m_sdk), "Processing error", MB_OK | MB_ICONERROR);
		return;
	}
	// ask for saving template to file 
	CString msg;
	msg.Format("Template size = %d quality = %d time = %d ms\nSave to file?", templSize, quality[0], stop_time - start_time);
	if (MessageBox (msg, "Processing successful", MB_YESNO | MB_ICONQUESTION) == IDYES)
		saveTemplateISO(m_fpTemplate_ISO, templSize);
}


void CSample1Dlg::OnBnClickedMatchIso()
{
	// TODO: Add your control notification handler code here
	CString name1, name2;						// template file names
	CString msg;
	BYTE* fpTemplate1 = NULL;
	BYTE* fpTemplate2 = NULL;

	try
	{
		// Select the first template file
		CFileDialog fileDlg (TRUE, "iso", NULL, NULL,
			"ISO template files (*.iso)|*.iso||", this);
		fileDlg.m_ofn.lpstrTitle = "First iso template file selection";   
		if (fileDlg.DoModal() != IDOK)
			return;
		name1 = fileDlg.GetPathName();

		// Select the second template file
		CFileDialog fileDlg2 (TRUE, "iso", NULL, NULL,
			"ISO template files (*.iso)|*.iso||", this);
		fileDlg2.m_ofn.lpstrTitle = "Second iso template file selection";   
		if (fileDlg2.DoModal() != IDOK)
			return;
		name2 = fileDlg2.GetPathName();

		// read templates into pTemplate1 and pTemplate2
		CFile f;
		f.Open(name1, CFile::modeRead | CFile::typeBinary);   
		int sizeCode = (int)f.GetLength();
		fpTemplate1 = new BYTE[sizeCode];
		f.Read (fpTemplate1, sizeCode);
		f.Close();
		f.Open(name2, CFile::modeRead | CFile::typeBinary);
		sizeCode = (int)f.GetLength();
		fpTemplate2 = new BYTE[sizeCode];
		f.Read (fpTemplate2, sizeCode); 
		f.Close();

		// call match SDK function
		BYTE similarity = 0;
		int result = match_Templates_ISO (m_sdk, fpTemplate1, fpTemplate2, &similarity);
		if (result != SE_OK)
		{
			MessageBox (getLastErrorMsg(m_sdk), "Match error", MB_OK | MB_ICONERROR);
			return;
		}
		msg.Format (_T("similarity = %d"), similarity);
		MessageBox (msg, _T("Success"));
	}
	catch( CFileException* e )
	{
		msg.Format("File %s could not be opened: %s", e->m_strFileName, e->m_cause);
		MessageBox (msg);
	}
	catch(CException* e)
	{
		e->ReportError();
	}
	if (fpTemplate1) delete fpTemplate1;
	if (fpTemplate2) delete fpTemplate2;
}


void CSample1Dlg::OnBnClickedMatchTECH5Nist()
{
	CString name1, name2;						// template file names
	CString msg;
	BYTE* fpTemplate1 = NULL;
	BYTE* fpTemplate2 = NULL;

	try
	{
		// Select the first template file
		CFileDialog fileDlg (TRUE, "tpl", NULL, NULL,
			"Tech5 template files (*.tpl)|*.tpl||", this);
		fileDlg.m_ofn.lpstrTitle = "Tech5 template selection";   
		if (fileDlg.DoModal() != IDOK)
			return;
		name1 = fileDlg.GetPathName();

		// Select the second template file
		CFileDialog fileDlg2 (TRUE, "nist", NULL, NULL,
			"NIST template files (*.nist)|*.nist||", this);
		fileDlg2.m_ofn.lpstrTitle = "NIST template file selection";   
		if (fileDlg2.DoModal() != IDOK)
			return;
		name2 = fileDlg2.GetPathName();

		// read templates into pTemplate1 and pTemplate2
		CFile f;
		f.Open(name1, CFile::modeRead | CFile::typeBinary);   
		int sizeCode = (int)f.GetLength();
		fpTemplate1 = new BYTE[sizeCode];
		f.Read (fpTemplate1, sizeCode);
		f.Close();
		f.Open(name2, CFile::modeRead | CFile::typeBinary);
		sizeCode = (int)f.GetLength();
		fpTemplate2 = new BYTE[sizeCode];
		f.Read (fpTemplate2, sizeCode); 
		f.Close();

		// call match SDK function
		BYTE similarity = 0;
		int result = match_Tech5_NIST (m_sdk, fpTemplate1, fpTemplate2, &similarity);
		if (result != SE_OK)
		{
			MessageBox (getLastErrorMsg(m_sdk), "Match error", MB_OK | MB_ICONERROR);
			return;
		}
		msg.Format (_T("similarity = %d"), similarity);
		MessageBox (msg, _T("Success"));
	}
	catch( CFileException* e )
	{
		msg.Format("File %s could not be opened: %s", e->m_strFileName, e->m_cause);
		MessageBox (msg);
	}
	catch(CException* e)
	{
		e->ReportError();
	}
	if (fpTemplate1) delete[] fpTemplate1;
	if (fpTemplate2) delete[] fpTemplate2;
}
