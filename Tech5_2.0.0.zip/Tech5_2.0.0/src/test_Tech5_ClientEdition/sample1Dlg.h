// sample1Dlg.h : header file
//

#if !defined(AFX_SAMPLE1DLG_H__F39FB0BA_2C26_4B72_B7CF_9750AC06FECE__INCLUDED_)
#define AFX_SAMPLE1DLG_H__F39FB0BA_2C26_4B72_B7CF_9750AC06FECE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#define SDK_LITE

/////////////////////////////////////////////////////////////////////////////
// CSample1Dlg dialog
#include "Tech5_ClientEdition.h"
#include "afxwin.h"

class CSample1Dlg : public CDialog
{
	TECH5_CLIENT   m_sdk;
	BYTE	        *m_dib;			      // capture data 
	BYTE		     *m_fpTemplate;	      // pointer to the proprietary fingerprint template
	BYTE		     *m_fpTemplate_NIST;	// pointer to the NIST template
	BYTE		     *m_fpTemplate_ISO ;	// pointer to the NIST template
	bool		      m_isCapture;	      // true if fingerprint image is captured

public:
	CSample1Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSample1Dlg)
	enum { IDD = IDD_SAMPLE1_DIALOG };
	CButton	m_saveBtn;
	CButton	m_processBtn;
	CButton	m_process_NISTBtn;
	CButton processISO;
	CStatic	m_finger;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSample1Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	bool getLicenseFileName(char* license_filename);

	// Generated message map functions
	//{{AFX_MSG(CSample1Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnMatch();
	afx_msg void OnProcess();
	afx_msg void OnSave();
	afx_msg void OnDestroy();
	afx_msg void OnRead();
	//}}AFX_MSG

private:
	/*
		save template to file 
		pTemplate - a pointer to the buffer that contains template
		size - size of template
	*/
	void saveTemplateTech5 (BYTE *fpTemplate, int templSize);
	void saveTemplateNIST (BYTE *fpTemplate, int templSize);
	void saveTemplateISO (BYTE *fpTemplate, int templSize);
	void saveTemplate (CString &name, BYTE *fpTemplate, int templSize);

   // release allocated memory
	void clear();
	// clear image area
	void clearArea();
   void copyDib(BYTE *dstDIB, BYTE *srcDIB);

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedProcessNist();
	afx_msg void OnBnClickedMatchNist();
	afx_msg void OnBnClickedProcessIso();
	afx_msg void OnBnClickedMatchIso();
	afx_msg void OnBnClickedMatchTECH5Nist();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SAMPLE1DLG_H__F39FB0BA_2C26_4B72_B7CF_9750AC06FECE__INCLUDED_)
