/*****************************************************************************
	processBase.cpp - implementation of 'processBase' class

*******************************************************************************/
#include <time.h>
#include <assert.h>

#include "processBase.h"
#include "ImageUtl.h"
#include "stretch.h"
#include "FSeg.h"
#include "dib.h"

#undef ROCKEY
#ifdef	ROCKEY
	#include "key_func.h"
#endif	//	ROCKEY

#pragma pack(push, _CORE_PACKING)

//void save2Bmp(char *name, BYTE *src, unsigned int width, unsigned int height)
//{
//   CDib dib;
//   dib.create8BitGray (src, width, height);
//   dib.setResolutionX (500);
//   dib.setResolutionY (500);
//   dib.save2Bmp (name);
//}


ProcessBase::ProcessBase()
{
   memset (this, 0, sizeof(*this));
   m_firstBuffer  = true      ;
   setSegmentationParameters (0, MAX_WIDTH, 0, MAX_HEIGHT, 4, 1);
}

ProcessBase::~ProcessBase()
{
   release();
#ifdef	ROCKEY
	KEY_CLOSE
#endif	//	ROCKEY

}

void ProcessBase::setSegmentationParameters(unsigned int minWidth  , unsigned int maxWidth, 
                                            unsigned int minHeight , unsigned int maxHeight,
                                            unsigned int alignmentX, unsigned int alignmentY)
{
   assert (minWidth  <= maxWidth && minHeight <= maxHeight);
   if (alignmentX < 4) alignmentX = 4;
   if (alignmentY < 1) alignmentX = 1;
   if (!maxWidth  || maxWidth  > MAX_WIDTH ) maxWidth  = MAX_WIDTH ;
   if (!maxHeight || maxHeight > MAX_HEIGHT) maxHeight = MAX_HEIGHT;
   if (minWidth  > maxWidth ) minWidth  = maxWidth;
   if (minHeight > maxHeight) minHeight = maxHeight;
   minWidth  = minWidth  / alignmentX * alignmentX;
   maxWidth  = maxWidth  / alignmentX * alignmentX;
   minHeight = minHeight / alignmentY * alignmentY;
   maxHeight = maxHeight / alignmentY * alignmentY;
   m_minWidth   = minWidth;
   m_maxWidth   = maxWidth;
   m_minHeight  = minHeight;
   m_maxHeight  = maxHeight;
   m_alignmentX = alignmentX;
   m_alignmentY = alignmentY;
}

void ProcessBase::release()
{
	if (m_buffer[0]) delete [] m_buffer[0], m_buffer[0] = NULL;
	if (m_buffer[1]) delete [] m_buffer[1], m_buffer[1] = NULL;
	if (m_bih)       delete    m_bih      , m_bih       = NULL;
}


bool ProcessBase::alloc(int num_threads)
{
   release();
	m_buffer[0] = new unsigned char[MAX_WIDTH * MAX_HEIGHT];
	m_buffer[1] = new unsigned char[MAX_WIDTH * MAX_HEIGHT];
	m_bih       = new BITMAPINFOHEADER;
	return ((m_buffer[0] != NULL) && (m_buffer[1] != NULL) && (m_bih != NULL)); 
}


int ProcessBase::common_init(int num_threads)
{
#ifdef ROCKEY
	KEY_FIND
	KEY_OPEN(MODULE_APISDK_ID)
	KEY_CHECKMODULE(0) ;
	KEY_PREPARECOMPARE ;
	int result = KEY_FUNCCALCULATE1(1, &lp2_1, &p1_1, &p2_1, &p3_1, &p4_1) ;
	KEY_CALCULATE1(1, &lp2_2, &p1_2, &p2_2, &p3_2, &p4_2) ;
	result = KEY_COMPARE(p1_1, p1_2)
	if (result != IP_OK) return result ;
#endif // ROCKEY

	if (m_init) return IP_OK;
	// allocation memory
   if (!alloc(num_threads)) return IP_LOW_MEMORY;
	return IP_OK;
}

int ProcessBase::init(int numThreads)
{
   if (m_init) return IP_OK;
   int result = common_init(numThreads);
   if (result != IP_OK) 
      return result;

   // set default protection
   BYTE protect[MAX_PROTECT_LEN];
   getProtect (protect);
   setProtect(protect);

   m_init = true;
	return IP_OK;
}

int ProcessBase::initEx (BYTE protect[MAX_PROTECT_LEN], int numThreads)
{
   if (m_init) return IP_OK;
   if (!protect) 
      return IP_WRONG_POINTER;
   int result = common_init(numThreads);   
   if (result != IP_OK) 
      return result;

   // set protection
   setProtect(protect);

   m_init = true;
	return IP_OK;
}
 


// allocate memory for data[] templates
int ProcessBase::allocateTemplates(unsigned int numFingers, TemplateData data[], int maxTemplateSize)
{
	if (numFingers <= 0 || numFingers > 10) return IP_WRONG_FINGER_NUMBER;
	if (!data)								       return IP_WRONG_POINTER;
	try
	{
		memset (data, 0, sizeof(TemplateData) * numFingers);
		for(unsigned int i = 0; i < numFingers; i++)
		{
			data[i].fpTemplate = new unsigned char[maxTemplateSize];
			if (!data[i].fpTemplate)
			{
				freeTemplates(numFingers, data);
				return IP_LOW_MEMORY;
			}
			memset (data[i].fpTemplate, 0, maxTemplateSize);
		}
	}
	catch(...)
	{
		return IP_UNKNOWN_EXCEPTION;
	}

	return IP_OK;
}

// free memery that was earlier allocate templates
int ProcessBase::freeTemplates(unsigned int numFingers, TemplateData data[])
{
	if (numFingers <= 0 || numFingers > 10)	return IP_WRONG_FINGER_NUMBER;
	if (!data) return IP_WRONG_POINTER;

	try
	{
		for(unsigned int i = 0; i < numFingers; i++)
		{
			if (data[i].fpTemplate)
			{
				delete [] data[i].fpTemplate;
				data[i].fpTemplate = NULL;
			}
		}
	}
	catch(...)
	{
		return IP_UNKNOWN_EXCEPTION;
	}
	return IP_OK;
}

// check the input image and read the resolution
int ProcessBase::checkImage()
{
	assert (m_bih);
	// check input parameters
	if (m_bih->biWidth <= 0 || !m_bih->biHeight || m_bih->biBitCount != 8 ||
		m_bih->biPlanes  != 1 || m_bih->biCompression != BI_RGB ||
		(m_bih->biClrUsed != 0 && m_bih->biClrUsed != 256) 
		) return IP_WRONG_DIB;
	return IP_OK;
}
// flip image if it is necessary
int ProcessBase::flipImage()
{
	assert (m_bih && m_src && m_dst);
	if (m_bih->biHeight > 0)        // need flip
	{
		flipH (m_src, m_dst, (m_bih->biWidth + 3) / 4 * 4, abs(m_bih->biHeight));
		m_bih->biHeight = -m_bih->biHeight;
      changeBuffers();
	}
	
	return IP_OK;
}

// transform DIB to standart RGB color table if it's necessary
int ProcessBase::correctRGB(RGBQUAD *rgb)
{
	assert (rgb); 

	// analyse RGB
	bool needCorrect = false;
	int i = 0;
	for(i = 0; i < 256; i++)
	{
		if (rgb[i].rgbBlue != i || rgb[i].rgbGreen != i || rgb[i].rgbRed != i)
		{
			needCorrect = true;
			break;
		}
	}
	if (!needCorrect) 
      return IP_OK;
	// correct bitmap
	assert (m_bih && m_src); 
	int rowLen = ((m_bih->biWidth + 3) >> 2) << 2;
	int imageSize = abs(m_bih->biHeight) * rowLen;
	for(i = 0; i < imageSize; i++)
	{
		m_src[i] = rgb[m_src[i]].rgbGreen;
	}
   return IP_OK;
}


// strech image if it is necessary
int  ProcessBase::strechImage(ProcessParam &param, BYTE *dib)
{
	assert (m_bih);

	DWORD resolutionX = M2INCH(m_bih->biXPelsPerMeter);
	DWORD resolutionY = M2INCH(m_bih->biYPelsPerMeter);
	
	float kx = 1.0;
	float ky = 1.0;
	unsigned int width  = (unsigned int)m_bih->biWidth;
	unsigned int height = (unsigned int)(abs(m_bih->biHeight));
   unsigned int rowLen = (width + 3) / 4 * 4;

	if (resolutionX < MIN_RESOLUTION || resolutionX > MAX_RESOLUTION ||
		resolutionY < MIN_RESOLUTION || resolutionY > MAX_RESOLUTION) 
		return IP_WRONG_RESOLUTION;
	if (abs((int)resolutionX - DEF_DPI) <= DPI_TOL &&
		abs((int)resolutionY - DEF_DPI) <= DPI_TOL)
	{
		if (width > MAX_WIDTH || height > MAX_HEIGHT) return IP_IMAGE_TOO_BIG;
      BYTE *image = dib + m_bih->biSize + 256 * sizeof (RGBQUAD);
      if (param.allowsIncreaseFrame)
         memcpy(m_buffer[0], image, rowLen * height);
      else
      {
      	unsigned int newWidth  = width  / m_alignmentX * m_alignmentX;
	      unsigned int newHeight = height / m_alignmentY * m_alignmentY;
         cut (image, rowLen, height, 0, 0, newWidth, newHeight, m_buffer[0]); 
         m_bih->biWidth = newWidth; 
         m_bih->biHeight = m_bih->biHeight < 0 ? -(int)newHeight : newHeight;
      }
      initBuffers (m_buffer[0]);
		return IP_OK;
	}
	kx = (float)DEF_DPI / resolutionX;
	ky = (float)DEF_DPI / resolutionY;
   // check if the new size is too big
	unsigned int newWidth  = (int)(width * kx);
	unsigned int newHeight = (int)(height * ky);
	newWidth  = newWidth   / m_alignmentX * m_alignmentX;
	newHeight  = newHeight / m_alignmentY * m_alignmentY;
	if (newWidth > MAX_WIDTH || newHeight > MAX_HEIGHT) 
      return IP_IMAGE_TOO_BIG;

	BYTE *image = dib + m_bih->biSize + 256 * sizeof (RGBQUAD);
	initBuffers(image);
   assert (m_src && m_dst);
	stretch (width, height, rowLen, m_src, kx, ky, &newWidth, &newHeight, m_dst);
//#ifdef _DEBUG
//   save2Bmp ("e:/temp/d.bmp", m_dst, newWidth, newHeight);
//#else
//   save2Bmp ("e:/temp/r.bmp", m_dst, newWidth, newHeight);
//#endif
   changeBuffers();

	m_bih->biWidth = newWidth;
	if (m_bih->biHeight > 0) m_bih->biHeight = newHeight;   
	else	                   m_bih->biHeight = -((int)newHeight);


	return IP_OK;
}

// white padding pixels if necessary
void ProcessBase::whitePadding()
{
 	assert (m_bih && m_src);

   int width = m_bih->biWidth;
   int strLen = (width + 3) / 4 * 4;
   int paddingLen = strLen - width;
   if (!paddingLen) // already fine
      return;

   int hight = abs(m_bih->biHeight);
   BYTE* p = m_src;
   p += width;
   for (int row = 0; row < hight; row++)
   {
      memset (p, 0xff, paddingLen);
      p += strLen;
   }
}
// prepare image before processing
int ProcessBase::prepareImage(BYTE *dib, ProcessParam &param, Frame &frame)
{
	int result = IP_OK;
	memcpy (m_bih, dib, sizeof (BITMAPINFOHEADER));
	// check the characteristics of the input image
	result = checkImage();
	if (result != IP_OK) 
      return result;
   // strech image if it is necessary
	result = strechImage(param, dib);
	if (result != IP_OK) 
      return result;
	// white padding pixels if necessary
	whitePadding();
   // transform DIB to standart RGB color table if it's necessary
   result = correctRGB((RGBQUAD*)(dib + m_bih->biSize));
  	if (result != IP_OK) 
      return result;
	// flip image if it is necessary
	result = flipImage();
	if (result != IP_OK) 
      return result;

	// find figerprint image in source image and cut it
	frame.left   = 0;
   frame.top    = 0;
	frame.right  =     m_bih->biWidth   - 1;
	frame.bottom = abs(m_bih->biHeight) - 1;

   return IP_OK;
}

bool ProcessBase::onPreProcessComplete(const LPVOID pContext, ON_PRE_PROCESS onPreprocess, FINGERS finger, Frame &frame)
{
   if (!onPreprocess)
      return true;
   return onPreprocess (pContext, finger, frame);
}

bool ProcessBase::onGetQualityComplete(const LPVOID pContext, ON_GET_QUALITY onGetQuality, FINGERS finger, int quality)
{
   if (!onGetQuality)
      return true;
   return onGetQuality (pContext, finger, quality);
}

bool ProcessBase::onSkeletonComplete(const LPVOID pContext, ON_SKELETON onSkeleton, FINGERS finger, BYTE *skeleton, int skeletonSize)
{
   if (!onSkeleton)
      return true;
   return onSkeleton (pContext, finger, skeleton, skeletonSize);
}


int ProcessBase::process  ( 
                         const LPVOID          pContext,   
                         const CaptureData     data, 
                               TemplateData   &templ, 
                               unsigned int   *templSize,
                               int            *quality,
                               ProcessParam   *processParam, 
                             ::Frame          *fingerFrame,
                               ON_PRE_PROCESS  onPreprocess, 
                               ON_GET_QUALITY  onGetQuality, 
                               ON_PROCESS_1    onProcessing1,
                               ON_SKELETON     onSkeleton,
                               bool            qualityOnly)
{
   if (!m_init) 
      return IP_NOT_INITIALIZED;
	int result = IP_OK;
   ProcessParam param;
   if (processParam)
      param = *processParam;
   Frame frame;
   if (fingerFrame)
      frame = *fingerFrame;

   if (!data.dib || !quality) 
      return IP_WRONG_POINTER;
   if (!param.maxWidth  || param.maxWidth  > MAX_WIDTH)  
      param.maxWidth  = MAX_WIDTH;
	if (!param.maxHeight || param.maxHeight > MAX_HEIGHT) 
      param.maxHeight = MAX_HEIGHT;

	// prepare image
   result = prepareImage(data.dib, param, frame);
	if (result != IP_OK) 
      return result;

   templ.numFinger = data.numFinger;
   unsigned int width  = (unsigned int)m_bih->biWidth;
   width = (width + 3) / 4 * 4;
   unsigned int height = (unsigned int)(abs(m_bih->biHeight));
   result = processRaw (pContext, m_src, width, height,      
                        templ.fpTemplate, templSize, quality, &param, &frame, templ.numFinger, 
                        NULL, NULL, onPreprocess, onGetQuality, onProcessing1, onSkeleton, qualityOnly);

   if (fingerFrame)
      *fingerFrame = frame;

   return result;
}

int ProcessBase::processRaw (
                       const LPVOID          pContext,   
                             unsigned char  *image, 
                             unsigned int    width, 
                             unsigned int    height, 
                             unsigned char  *fpTemplate, 
                             unsigned int   *templSize, 
                             int            *quality,   
                             ProcessParam   *processParam,
                             Frame          *fingerFrame,
                             FINGERS         finger,
                             BYTE           *skeleton,
                             int            *skeletonSize,
                             ON_PRE_PROCESS  onPreprocess, 
                             ON_GET_QUALITY  onGetQuality, 
                             ON_PROCESS_1    onProcess1,
                             ON_SKELETON     onSkeleton,
                             bool            qualityOnly)
{
   int result = IP_OK;
   if (!m_init) 
      return IP_NOT_INITIALIZED;
#ifdef ROCKEY
	KEY_PREPARECOMPARE ;
	WORD rr ;
	KEY_RANDOM(rr)
	lp2_1 = lp2_2 = rr ;	
	result = KEY_FUNCCALCULATE1(2, &lp2_1, &p1_1, &p2_1, &p3_1, &p4_1) ;
	KEY_CALCULATE1(2, &lp2_2, &p1_2, &p2_2, &p3_2, &p4_2) ;
	result = KEY_COMPARE(p1_1, p1_2)
	if (result != IP_OK) 
      return result ;
#endif // ROCKEY
#ifdef TIME_PROTECT
   bool timeProtect = true;
	time_t t;	
	time(&t);
	struct tm* pTime = localtime(&t);  
	if (pTime->tm_year + 1900 > PROTECT_YEAR) 
			timeProtect = false;
	else if(pTime->tm_year + 1900 == PROTECT_YEAR)
	{
	   if (pTime->tm_mon + 1  > PROTECT_MONTH)
		   timeProtect = false;
	   else if(pTime->tm_mon + 1 == PROTECT_MONTH && 
				pTime->tm_mday >= PROTECT_DAY)
		timeProtect = false;
	 }
   if (!timeProtect)
      throw -1;
#endif // TIME_PROTECT

   ProcessParam param;
   if (processParam)
      param = *processParam;
   // check input paramenters
   if (!image) 
      return IP_WRONG_POINTER;
	if (!width || !height)
      return IP_NO_IMAGE;
   if (width > MAX_WIDTH || height > MAX_HEIGHT)
      return IP_IMAGE_TOO_BIG;

   if (!param.maxWidth  || param.maxWidth  > MAX_WIDTH ) param.maxWidth  = MAX_WIDTH;
	if (!param.maxHeight || param.maxHeight > MAX_HEIGHT) param.maxHeight = MAX_HEIGHT;

   Frame frame;
   if (fingerFrame)
      frame = *fingerFrame;
   frame.left    = 0;
   frame.top     = 0;
   frame.right   = width  - 1;
   frame.bottom  = height - 1;
	
	// find figerprint image in source image and cut it
   initBuffers(image);
   if ((result = cutImage(width, height, param, frame) != IP_OK))
      return result;
   // build the template
   width  = frame.right  - frame.left  + 1;
   height = frame.bottom - frame.top   + 1;
//   save2Bmp ("e:/1.bmp", m_src, width, height);
//   printf ("frame.left = %d, frame.right = %d, frame.top = %d, frame.bottom = %d\n", frame.left, frame.right, frame.top, frame.bottom);
   result = wizardWork (pContext, m_src, width, height, fpTemplate, templSize, quality, frame, finger, 
                           skeleton, skeletonSize, param.ISO_compatible,
                           onPreprocess, onGetQuality, onProcess1, onSkeleton, qualityOnly);
   if (fingerFrame)
      *fingerFrame = frame;
   return result;
}



// find figerprint image in source image and cut it
int ProcessBase::cutImage(unsigned int width, unsigned int height, 
                        ProcessParam  &param, Frame &frame)
{
   if (!width || !height) return IP_NO_IMAGE;

   int left = 0, right = 0, top = 0, bottom = 0;
   right  = (int)width  - 1;
   bottom = (int)height - 1;
   if (param.doSegmentation)
   {
//   setSrcDst(); it shouldn't be here!!!!, because of m_src set to the image, not on m_buffer[0]
      SgmRect rect[2];
      unsigned int rectsCount = 2;
      int result = FSeg (m_src, NULL, width, height, 500, SGM_TYPE_FINGER, SGM_HAND_UNKNOWN, IMP_TYPE_UNKNOWN, false, NULL, 0, rect, rectsCount);
      if (result == SGM_RES_SUCCESS && (rect[1].coords[2][1] - rect[1].coords[0][1] >= 64) && (rect[1].coords[1][0] - rect[1].coords[0][0] >= 64))
      {
         left   = rect[1].coords[0][0];
         top    = rect[1].coords[0][1];
         right  = rect[1].coords[1][0];
         bottom = rect[1].coords[2][1];
         int add = 22;
         left   -= add; 
         right  += add; 
         top    -= add; 
         bottom += add; 
      }
   }
   if ((width < m_minWidth || height < m_minHeight) && !param.allowsIncreaseFrame)
      return IP_WRONG_IMAGE_SIZE;
	if (correctImageSize(width, height, left, top, right, bottom, param))
   {
	   // prepare to cutting
	   if (right <= left || bottom <= top) return IP_NO_IMAGE;
	
      // cutting
      unsigned int newWidth  = right  - left + 1;
      unsigned int newHeight = bottom - top  + 1;
      int result = Get3Rect (m_src, width, height, left, top, right, top, left, bottom, m_dst, newWidth, newHeight);
      assert (result == SGM_RES_SUCCESS);
		changeBuffers();
      frame.left   += (unsigned int)left;
	   frame.top    += (unsigned int)top;
	   frame.right  = frame.left + newWidth  - 1;
	   frame.bottom = frame.top  + newHeight - 1;
   }

	return IP_OK;
}

// be sure that new image size is satisfy the requirements
bool ProcessBase::correctImageSize(unsigned int width, unsigned int height,
                                   int &left, int &top, int &right,  int &bottom,
                                   ProcessParam &param)
{
   unsigned int maxWidth  = minAB(param.maxWidth , m_maxWidth );
   unsigned int maxHeight = minAB(param.maxHeight, m_maxHeight);

   assert(!(maxWidth    % m_alignmentX));
   assert(!(maxHeight   % m_alignmentY));
   assert(!(m_minWidth  % m_alignmentX));
   assert(!(m_minHeight % m_alignmentY));
      
   unsigned int newWidth  = right  - left + 1;
   unsigned int newHeight = bottom - top  + 1;
   newWidth  = newWidth  / m_alignmentX * m_alignmentX;
   newHeight = newHeight / m_alignmentY * m_alignmentY;
 	if (newWidth > maxWidth)
	{
		left += (newWidth - maxWidth) / 2;
		newWidth = maxWidth;
	}
	if (newHeight > maxHeight)
	{
		top += (newHeight - maxHeight) / 2;
		newHeight = maxHeight;
	}

   if (newWidth < m_minWidth )
   {
      left -= (m_minWidth - newWidth) / 2;
      right = left + m_minWidth - 1;
      newWidth = m_minWidth;
   }
   if (newHeight  < m_minHeight) 
   {
      top -= (m_minHeight - newHeight) / 2;
      bottom = top + m_minHeight - 1;
      newHeight = m_minHeight;
   }
   if (!param.allowsIncreaseFrame)
   {
      assert(width >= m_minWidth && height >= m_minHeight);
      if (left   <                0) left   = 0;
      if (top    <                0) top    = 0;
      if (right  >   (int)width - 1) right  = (int)width  - 1;
      if (bottom >  (int)height - 1) bottom = (int)height - 1;
      newWidth  = right  - left + 1; 
      newHeight = bottom - top  + 1; 
      newWidth  = newWidth  / m_alignmentX * m_alignmentX;
      newHeight = newHeight / m_alignmentY * m_alignmentY;

      if (newWidth < m_minWidth )
      {
         if (left == 0) right = left  + m_minWidth - 1;
         else           left  = right - m_minWidth + 1;
         newWidth = m_minWidth;
      }
      if (newHeight < m_minHeight) 
      {
         if (top == 0) bottom = top    + m_minHeight - 1;
         else          top    = bottom - m_minHeight + 1;
         newHeight = m_minHeight;
      }
   }
   right  = left + newWidth  - 1;
   bottom = top  + newHeight - 1;

   return (left || top || newHeight != height || newWidth != width);
}

#pragma pack(pop)
