/*****************************************************************************
	processing.cpp - implementation of 'FpProcess' class
	    
*******************************************************************************/
#include "processing.h"

#undef ROCKEY
#ifdef	ROCKEY
	#include "key_func.h"
#endif	//	ROCKEY

#pragma pack(push, _CORE_PACKING)


FpProcess::FpProcess() : ProcessBase()
{
	m_codex = NULL;
   setSegmentationParameters (0, MAX_WIDTH, 0, MAX_HEIGHT, 4, 1);
}

FpProcess::~FpProcess()
{
   release();
}

void FpProcess::release()
{
   ProcessBase::release();
	if (m_codex) delete m_codex, m_codex = NULL;
}

bool FpProcess::alloc(int num_threads)
{
   if (!ProcessBase::alloc(num_threads))
      return false;
	m_codex     = new Codex();
	return (m_codex != NULL);
}

// set protection code
void FpProcess::setProtect(BYTE protect[MAX_PROTECT_LEN])
{
   memcpy (skeletMask, protect, sizeof(skeletMask));
}

// get protection code
void FpProcess::getProtect(BYTE protect[MAX_PROTECT_LEN])
{
   memset (protect, 0, sizeof(protect));
	BYTE temp[]	=	
   {
	   1, 12, 12, 36, 12,  1,  4,  1, 12,  9, 42,  0, 68,  1,  1,  1, //   0
      12,  9,  9,  0,  1,  1,  1,  1, 36,  0,  0,  0,  1,  1,  1,  1, //  16
      12,  9,  9,  0,  9, 66,  0,  0, 74,  8,  8,  0,  0, 66, 66,  0, //  32
      100,  0,  0,  0,  1,  1,  1,  0,  1,  0, 34,  0,  1,  1,  1,  0, //  48
      12,  1,  9,  1,  9,  1,  0,  1,  9, 66,  8, 34,  0,  1,  0,  1, //  64
	   1,  1, 34,  1,  1,  1,  1,  0,  1,  1, 34,  1,  1,  0,  1,  0, //  80
      68,  1,  0,  1,  0,  1,  0,  0,  0, 66,  0,  0,  0,  1,  0,  0, //  96
	   1,  1,  0,  0,  1,  0,  0,  0,  1,  1,  0,  0,  1,  0,  0,  0, // 112
      12,100, 10,  1,  9,  1,  0,  1,  9,  0,  8, 34,  0,  1,  2,  1, // 128
      9,  0,  8,  0, 98,  1,  2,  1,  0,  0,  0,  0,  0,  0,  0,  0, // 144
      106,  0,  8, 98,  8, 98,  0,  0,  8,  0,  1,  0,  0,  0,  0,  0, // 160
	   0,  0,  0,  0, 98,  1,  0,  0, 98,  0,  0,  0,  0,  0,  0,  0, // 176
	   4,  1,  0,  1,  0,  1,  0,  1,  0,  0,  0,  0,  0,  0,  0,  0, // 192
	   1,  1,  2,  1,  1,  0,  1,  0,  1,  0,  0,  0,  0,  0,  0,  0, // 208
	   1,  1,  2,  1,  0,  1,  0,  0, 66,  0,  0,  0,  0,  0,  0,  0, // 224
	   1,  1,  0,  0,  1,  0,  0,  0,  1,  0,  0,  0,  0,  0,  0,  0, // 240
   };
   memcpy (protect, temp, sizeof(temp));
}


static unsigned short status_image( unsigned char *buf, int size ) 
{
	if (!buf) return 0;
   unsigned short w;
   w = 0;
	for( int i = 0; i < size - 255; i++ ) {
		w += buf[ i += buf[i] ];
   }
   return w;
}
static void XaosImage( unsigned char *buf, int Maxx, int Maxy ) 
{
   if (!buf) return;
   int Gist[256], len, i, j, j3, max;

   memset( Gist, 0, sizeof( Gist ) );
   len = Maxx * Maxy;
   for( i = 0; i < len; i++ ) {
      j = buf[i];   Gist[j]++;
   }
   for( i = 0, max = 0, j3 = 0; i < 256; i++ ) {
      if( Gist[i] > max ) {
         max = Gist[i];   j3 = i;
      }
   }
   if( max > len / 2 ) {
      srand( 1101 );
      for( i = 0; i < len; i++ ) {
         j = buf[i];
         if( j == j3 ) {
            j = j - 5 + (rand() % 10);
            if( j < 0 ) j = 0; if( j > 255 ) j = 255;
            buf[i] = (unsigned char) j;
         }
      }
   }
}
// callback function (after preprocess1 complete)
bool FpProcess::onProcess1Complete(const LPVOID pContext, ON_PROCESS_1 onProcess1, FINGERS finger)
{
   if (!onProcess1)
      return true;
   Singular singular[MAX_SINGULAR];
   memset (singular, 0, sizeof(singular));

   SSign indi[MAX_SINGULAR];
   int numSingularity = 0;
   int numIndi = -1;
   m_codex->ExIndi ((BYTE*)indi, numIndi);
   int pattern = m_codex->ImMask;
   for (int i = 0; i < numIndi; i++)
   {
      switch (indi[i].Type)
      {
      case FW:
         singular[numSingularity].type = WHORL;
         break;
      case FL:
         singular[numSingularity].type = LOOP;
         break;
      case FD:
         singular[numSingularity].type = DELTA;
         break;
      default:
         continue;
      }
      if (indi[i].Type == FX)
         continue;
      singular[numSingularity].x = (int)indi[i].Movx;
      singular[numSingularity].y = (int)indi[i].Movy;
      singular[numSingularity].angle = indi[i].Beta * 2;
      singular[numSingularity].prob = (indi[i].Prob & 0x3f) * 100 / 64;
      if (indi[i].Prob & 0x80)
         singular[numSingularity].prob /= 2;
      numSingularity++;
   }
   return onProcess1 (pContext, finger, pattern, numSingularity, singular);
}

//#include "fileUtl.h"
int FpProcess::wizardWork (
                     const LPVOID         pContext,   
                           unsigned char *image, 
                           unsigned int   width, 
                           unsigned int   height, 
                           unsigned char *fpTemplate, 
                           unsigned int  *templSize, 
                           int           *quality, 
                         ::Frame           &frame,   
                           FINGERS        finger,  
                           BYTE          *skeleton, 
                           int           *skeletonSize, 
                           bool           ISO_compatible,
                           ON_PRE_PROCESS onPreprocess, 
                           ON_GET_QUALITY onGetQuality, 
                           ON_PROCESS_1   onProcess1,
                           ON_SKELETON    onSkeleton,
                           bool           qualityOnly)
{
	if (!image || !quality)                          return IP_WRONG_POINTER;
   if (!qualityOnly && (!fpTemplate || !templSize)) return IP_WRONG_POINTER;
	if (!width || !height)						          return IP_NO_IMAGE;
	if (width > MAX_WIDTH || height > MAX_HEIGHT)    return IP_IMAGE_TOO_BIG;

	int result = IP_OK;
	int err = 0;
   if (templSize) *templSize = 0;
   *quality = 0;
   struct SData data;
	memset (&data, 0, sizeof(SData));
	data.ImgDPI = 500;
	data.ImType = 'F';
	data.ManDPI = 500;
	data.TipNet = 17;
	data.Size_X = (short)width;     
	data.Size_Y = (short)height;
	data.Irefer = image;
	data.Number = finger;
//   save2Bmp ("e:/temp/1.bmp", image, width, height);
	try
	{
      if (!onPreProcessComplete(pContext, onPreprocess, finger, frame)) 
         return IP_CANCEL;
		// process image
		data.Status = status_image (data.Irefer, data.Size_X * data.Size_Y);
	   m_codex->DelDoc();  
      m_codex->ResDoc();   
      m_codex->Resume();  
      m_codex->DelTab();
		err = m_codex->Loader (data, m_codex->PyrL, ISO_compatible);
		if( err == -4 ) 
		{
			XaosImage (data.Irefer, data.Size_X, data.Size_Y );
			data.Status = status_image (data.Irefer, data.Size_X * data.Size_Y);
			err = m_codex->Loader (data, m_codex->PyrL, ISO_compatible);
		}
		if( err != 0 ) 
      {
         if (err == STUMPS || err == NOTIMG) throw IP_NO_IMAGE;
         else                                throw IP_PROCESSING;
      }
      m_codex->Pickup (PickuP);
      *quality = m_codex->getQuality();
      if (!onGetQualityComplete(pContext, onGetQuality, finger, *quality))
         throw IP_CANCEL;
      if (qualityOnly)
         throw IP_OK;
      m_codex->Xfocus( XfocuS );
      if (!onProcess1Complete(pContext, onProcess1, finger))
         throw IP_CANCEL;
		m_codex->Epilog(EpiloG );
		int size = 0;
		m_codex->GetSize (size);
		if (size > MAX_TEMPLATE_SIZE || size < 0) throw IP_PROCESSING;
		// copy template
		unsigned char *templ = fpTemplate + sizeof(TemplHeader);
		m_codex->ExGold(templ);

		// fill the TemplHeader
		*templSize = size + sizeof(TemplHeader);
		TemplHeader *header = (TemplHeader*)fpTemplate;
		memset (header, 0, sizeof(TemplHeader));
		header->size = *templSize;
		header->checkIntegral = 1;       // automation integral
		header->points = m_codex->Nmin;  
		//calculate number of reliable points
      if (header->points)
      {
		   SSign *sign = m_codex->Sign;
		   for (int j = 0; j < header->points; j++)
			   if (!(sign[j].Prob & 0x80)) header->relPoints++;
      }
	   SItem * item = (SItem*)templ;
      *quality = item->Qualit;
	   header->quality = *quality;

      if (!onSkeletonComplete (pContext, onSkeleton, finger, m_codex->GetLay (SKELET, 0), m_codex->Size[0]))
          throw IP_CANCEL;
		// copy sceleton 
		if (skeleton && skeletonSize)
      {
         *skeletonSize = m_codex->Size[0];
			memcpy (skeleton, m_codex->GetLay (SKELET, 0), *skeletonSize);
      }
      frame.right  = frame.left + item->Size_X - 1;
      frame.bottom = frame.top  + item->Size_Y - 1;
	}
	catch (int e)
	{
		result = e;
	}
	catch (...)
	{
		result =  IP_UNKNOWN_EXCEPTION;
	}
	//m_codex->DelDoc();  
   //m_codex->ResDoc();   
   //m_codex->Resume();  
   //m_codex->DelTab();

	return result;
}

#pragma pack(pop)
