#include "ip.h"
#include "processing.h"

#pragma pack(push, _CORE_PACKING)


Ip::Ip()
{
	m_process = NULL;
}

Ip::~Ip()
{
	if (m_process)	
   {
      delete m_process;
      m_process = NULL;
   }
}


/* 
	initialize work with Ip class funtion
	this function should be called first before call any other function
	function returns 'true' if initialization is successfull, false otherwise
*/
int Ip::init()
{
	if (!m_process)
	   m_process = new FpProcess;
	if (!m_process) 
      return IP_LOW_MEMORY;

   return m_process->init(0);
}

int Ip::initEx(BYTE protect [MAX_PROTECT_LEN])
{
	if (!m_process)
	   m_process = new FpProcess;
	if (!m_process) 
      return IP_LOW_MEMORY;

   return m_process->initEx(protect, 0);
}

int Ip::allocateTemplates(unsigned int numFingers, TemplateData data[])
{
	return FpProcess::allocateTemplates (numFingers, data, MAX_TEMPLATE_SIZE);
}

int Ip::freeTemplates(unsigned int numFingers, TemplateData data[])
{
	return FpProcess::freeTemplates(numFingers, data);
}


int Ip::process ( const LPVOID         pContext,
                  const CaptureData    data, 
                       TemplateData   &fpTemplate, 
                       unsigned int   *templateSize,
                       int            *quality,   
                       ProcessParam   *param,
                       Frame          *frame,
                       ON_PRE_PROCESS  onPreprocess, 
                       ON_GET_QUALITY  onGetQuality, 
                       ON_PROCESS_1    onProcess1,
                       ON_SKELETON     onSkeleton)
{
	if (!m_process) 
      return IP_NOT_INITIALIZED;
	return m_process->process (pContext, data, fpTemplate, templateSize, quality, param, frame, 
                              onPreprocess, 
                              onGetQuality,
                              onProcess1,
                              onSkeleton);
}


int Ip::getQuality  (const CaptureData  data, 
                     int                *quality, 
                     ProcessParam       *param,
                     ::Frame            *frame)

{
	if (!m_process) 
      return IP_NOT_INITIALIZED;
   TemplateData templ;
   unsigned int templSize = 0;
	return m_process->process (NULL, data, templ, &templSize, quality, param, frame, NULL, NULL, NULL, NULL, true);
}

int Ip::processRaw ( 
              const LPVOID          pContext,
                    BYTE           *image,
                    WORD            width,
                    WORD            height,
                    BYTE           *fpTemplate, 
                    unsigned int   *templSize, 
                    int            *quality, 
                    ProcessParam   *param,
                  ::Frame          *frame,
                    FINGERS         finger, 
                    BYTE           *skeleton,
                    int            *skeletonSize,
                    ON_PRE_PROCESS  onPreprocess,
                    ON_GET_QUALITY  onGetQuality, 
                    ON_PROCESS_1    onProcess1,
                    ON_SKELETON     onSkeleton)
{

	if (!m_process) 
      return IP_NOT_INITIALIZED;
	int result = m_process->processRaw (pContext, image, width, height, 
	                  fpTemplate, templSize, quality, param, frame, finger, skeleton, skeletonSize,
                     onPreprocess, onGetQuality, onProcess1, onSkeleton);

   return result;
}

#pragma pack(pop)
