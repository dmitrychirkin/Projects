#include "Tech5_GalleryMatcher_ServerE.h"
#include "Unwrap.h"

namespace Tech5Finger {



class TemplateChecker : public FpTemplateChecker
{
   ESK::Unwrap *m_unwrap;
   bool         m_init;
   
public:
   // create object of FpTemplateChecker. Return NULL in case of error
   static FpTemplateChecker*	create();                        
   
   // delete object of FpTemplateChecker
   static void cancel(FpTemplateChecker *&checker);	

   TemplateChecker()
   {
      m_init   = false;
      m_unwrap = NULL;
   }
   virtual ~TemplateChecker()
   {
      if (m_unwrap) ESK::Unwrap::cancel (m_unwrap);
   }

   /*
   Function check  fingerprint template - if it has a right format and good health
   Parameters:
   fpTemplate   ( input) - fingerprint template for checking
   Return value:
   true if template is OK and false  otherwise
   */
   virtual bool check (BYTE *fpTemplate);
private:
   bool init ();    
};

FpTemplateChecker* FpTemplateChecker::create()
{
   FpTemplateChecker *checker = NULL;
   try
	{
      checker = new TemplateChecker();
      if (!checker)
         return NULL;
      
      return checker;
	}
   catch(...)
	{
      delete checker; 
      return NULL;
	}
}

void FpTemplateChecker::cancel (FpTemplateChecker *&checker)
{
   if (checker)
      delete checker, checker = NULL;
}

bool TemplateChecker::init()
{
   if (m_init)
      return true;
   m_unwrap = ESK::Unwrap::create();
   m_init = (m_unwrap != NULL); 
   m_unwrap->versor (_ESK_ID);
   return m_init;
}

bool TemplateChecker::check (BYTE *fpTemplate)
{
   if (!fpTemplate)
      return false;
   if (!init())
      return UNPACK_INIT_FAILED;
   BYTE *templ = fpTemplate + sizeof(TemplHeader);
   if (!m_unwrap->verify (templ) ) 
      return false;
   if (!m_unwrap->defend (templ) ) 
      return false;
   //if (!m_unwrap->hasher (templ) ) 
   //   return false;
   return true;
}


} // namespace Tech5Finger {
