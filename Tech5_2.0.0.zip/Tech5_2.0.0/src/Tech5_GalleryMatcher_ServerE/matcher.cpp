#include <string>
#include <list>
#include <algorithm>

#include <omp.h>
#include <assert.h>

#include "Unwrap.h"

#include "Tech5_GalleryMatcher_ServerE.h"
#include "licenseRoutine.h"
#include "accelMatchEx.h"
#include "ma100_TT.h"
#include "stringToNumeric.h"


using namespace       std;
using namespace accelMatch;

namespace Tech5Finger {

const uint32_t g_use_db_size_restriction  =     1;
const uint32_t g_max_db_size              =  5400;

char * getVersion()
{
   return "2.0.0";
}


class RealMatcher : public Matcher
{
   bool                        m_valid_license     ;          // is license valid?
   bool                        m_initMa            ;          // is m_ma initialized?
   Ma100_TT                    m_ma                ;          
   list <GalleryItem>          m_gallery           ;     
   void                       *m_accelHandle       ;           // accelMatch lirary handle 
   uint32_t                    m_max_num_threads   ;           // maxinum number of threads that can be used in matching  
   BYTE                       *m_accelBuffer       ;           // buffer for accel calculation 
   uint64_t                    m_maxGallerySize    ;           // maximum gallery size, memory allocated for
   bool                        m_galleryChanged    ;
   ESK::Unwrap                *m_unwrap            ;           // unwrap object for check templates

public:
   RealMatcher()
   {
      m_valid_license     = false;
      m_initMa            = false;
      m_accelHandle       = NULL ;
      m_max_num_threads   = 0    ;
      m_accelBuffer       = NULL ;
      m_maxGallerySize    = 0    ;
      m_galleryChanged    = false;
      m_unwrap            = NULL ;
   }
   virtual ~RealMatcher()
   {
      closeAccelLib (&m_accelHandle);
      freeGallery();
      if (m_accelBuffer) delete [] m_accelBuffer       , m_accelBuffer = NULL;
      if (m_unwrap     ) ESK::Unwrap::cancel (m_unwrap), m_unwrap      = NULL;
   }
   virtual bool     initLicense        (const char *licensePath                                 );  
	virtual uint32_t verify_record      (MatchingParameters &matchingParameters, 
                                        TpTemplate &tpTemplate1, 
                                        TpTemplate &tpTemplate2, 
                                        double &score                                           );
   virtual uint32_t insertRecord       (std::string &id,TpTemplate &tpTemplate                  );
   virtual uint32_t deleteRecord       (std::string &id                                         );
   virtual uint64_t getFinalGallerySize(                                                        );
   virtual uint32_t identify_record    (MatchingParameters             &matchingParameters    , 
                                        TpTemplate                     &probe                 , 
                                        const uint32_t                  numberOfThreads       , 
                                        const uint32_t                  candidate_list_length , 
                                        std::vector<candidates_string> &candidate_list          );
private:
   // initialize Ma100 library
   uint32_t initMa                  (                                            );                

   // initialize accel matching library
   uint32_t initAccelMatching       (uint32_t numThreads, uint32_t maxGallerySize);                
   uint32_t initAccel_1st_stage     (uint32_t numThreads                         );                
   uint32_t initUnwrap              (                                            );
   
   // release memory
   void freeGallery();
   void releaseGalleryItem(GalleryItem &item);

   // auxilary functions
   uint32_t createGalleryItem (uint64_t id, TpTemplate &tpTemplatem , GalleryItem &item);
   
   bool allocAccel(BYTE *&accel, uint32_t accelSize);
   void freeAccel (BYTE *&accel);
   uint32_t allocAccelBuffer();
   
   // check return codes
   uint32_t checkMaResult         (int result);
   uint32_t checkAccelMatchResult (int result);
   
   // find record with specified ID
   list <GalleryItem>::iterator findItem(uint64_t id);
   
   // check if gallery already has record with such ID
   bool checkDouble(uint64_t id);
   // check if template is valid
   bool check (TpTemplate &tpTemplate);

   uint32_t calculateAccelerator(GalleryItem &item, TpTemplate &tpTemplate);
};

Matcher*	Matcher::create()
{
   Matcher *matcher = NULL;
   try
	{
      matcher = new RealMatcher();
      if (!matcher)
         return NULL;

	}
   catch(...)
	{
      delete matcher; 
      return NULL;
	}
   return matcher;
}

void Matcher::cancel (Matcher *&matcher)
{
   if (matcher)
      delete matcher, matcher = NULL;
}


bool RealMatcher::initLicense(const char *licensePath)
{
   m_valid_license = checkLicense (licensePath);
   return m_valid_license;
}

/**************************************************************************
   Ma100 routine
*************************************************************************/
uint32_t RealMatcher::initMa()
{
   if (m_initMa)
      return SUCCESS;

   // initialize m_ma
   int result = m_ma.init ();
   m_initMa = (result == MA_OK);

   return checkMaResult(m_ma.init ());
}

uint32_t RealMatcher::verify_record(MatchingParameters &matchingParameters, TpTemplate &tpTemplate1, TpTemplate &tpTemplate2, double &score)
{
   if (!m_valid_license)
      return NO_LICENSE;

   score = 0;
   int result = initMa();
   if (result != SUCCESS)
      return result;
   
   MatchResultTT  matchResultTT;
   SearchParam param;
   param.maxAngle       = matchingParameters.maxAngle;
   param.maxAngleThumbs = matchingParameters.maxAngleThumbs;
   param.matchingMode   = matchingParameters.matchingMode;
   result = m_ma.matchTT (param, tpTemplate1, tpTemplate2, matchResultTT);
   if (result == MA_OK) 
      score = (double)matchResultTT.fusionScore / MAX_SCORE;
   
   return checkMaResult(result);
}

/**************************************************************************
   AccelMatching routine
*************************************************************************/
uint32_t RealMatcher::initUnwrap()
{
   if (m_unwrap)
      return SUCCESS;
   m_unwrap = ESK::Unwrap::create();
   if (!m_unwrap)
      return LOW_MEMORY;
   m_unwrap->versor (_ESK_ID);
   return SUCCESS;
}

uint32_t RealMatcher:: initAccel_1st_stage (uint32_t numThreads)              
{
   uint32_t result = allocAccelBuffer();
   if (result != SUCCESS) 
      return result;
   
   result = initUnwrap();
   if (result != SUCCESS) 
      return result;

   if (!numThreads)
      numThreads = omp_get_num_procs();
   if (m_accelHandle && m_max_num_threads >= numThreads)
      return SUCCESS;


   closeAccelLib (&m_accelHandle);
   int rs = initAccelLib (&m_accelHandle, numThreads);
  if (rs != SA_OK)
     return checkAccelMatchResult(rs);
   m_max_num_threads = numThreads;

   return SUCCESS;
}


uint32_t RealMatcher::initAccelMatching(uint32_t numThreads, uint32_t maxGallerySize)
{
   uint32_t result = initAccel_1st_stage (numThreads);
   if (result != SUCCESS) 
      return result;
   
   // 2nd stage initializition
   if (!m_maxGallerySize && m_maxGallerySize >= maxGallerySize)
      return SUCCESS;
   int rs = initFinalMatching (m_accelHandle, maxGallerySize);
  if (rs != SA_OK)
     return checkAccelMatchResult(rs);
  m_maxGallerySize = maxGallerySize;

   return SUCCESS;
}

uint32_t RealMatcher::identify_record    (MatchingParameters             &matchingParameters     , 
                                         TpTemplate                      &probe                  , 
                                         const uint32_t                   numberOfThreads        , 
                                         const uint32_t                   candidate_list_length  , 
                                         std::vector<candidates_string>  &candidate_list          )
{
   candidate_list.clear();

   if (!m_valid_license)
      return NO_LICENSE;

   uint32_t result = initAccelMatching (numberOfThreads, (uint32_t)m_gallery.size());
   if (result != SUCCESS)
      return result;

   RL         *outRl           = NULL;
   try
   {
      outRl = new RL [candidate_list_length];
      if (!outRl)
         throw LOW_MEMORY;
      int rs = SA_OK;
      if (m_galleryChanged)
         rs = uploadDb (m_accelHandle, m_gallery);
     if (rs != SA_OK)
        return checkAccelMatchResult(rs);
      m_galleryChanged = false;

      // do indentification
      AccelSearchParam param;
      param.matchingMode    = matchingParameters.matchingMode  ;
      param.maxAngle        = matchingParameters.maxAngle      ;
      param.maxAngleThumbs  = matchingParameters.maxAngleThumbs;
      param.searchSpeed     = matchingParameters.searchSpeed   ;
      rs = completeIdentifyTP (m_accelHandle, param, probe, outRl, candidate_list_length, NULL);
   
      // fill recommended list
      candidates_string resultItem;
      for(uint32_t i = 0; i < candidate_list_length; i++)
      {
         if (!outRl[i].score)
            break;
         resultItem.score = (float)outRl[i].score / MAX_SCORE;
         resultItem.uid   = uint64ToString (outRl[i].regNum);
         candidate_list.push_back (resultItem);
      }
   }
   catch(uint32_t &e)
   {
      result = e;
   }
   if (outRl          ) delete [] outRl          , outRl           = NULL;

   return SUCCESS;
}

/**************************************************************************
   Gallery db routine
*************************************************************************/


uint32_t RealMatcher::insertRecord (std::string &ID, TpTemplate &tpTemplate)
{
   if (!m_valid_license)
      return NO_LICENSE;

   uint64_t id = getIdFromString(ID); 
   if (checkDouble(id))
      return DOUBLE_ID;

   uint32_t result = SUCCESS;
   if ((result = initAccel_1st_stage (0)) != SUCCESS)
      return result;

   // check templates
   if (!check(tpTemplate))
      return WRONG_TEMPLATE;

   // check gallery size
   if (g_use_db_size_restriction && m_gallery.size() >= g_max_db_size)
      return MAX_GALLERY_SIZE_REACHED;
   
   GalleryItem item;
   if ((result = createGalleryItem (id, tpTemplate, item)) != SUCCESS)
      return result;

   // calculate accelerator
   if ((result = calculateAccelerator (item, tpTemplate)) != SUCCESS)
      return result;
   
   // put record in container
   m_gallery.push_back (item);
   m_galleryChanged = true;

   return SUCCESS;
}

uint32_t RealMatcher::deleteRecord (std::string &ID)
{
   if (!m_valid_license)
      return NO_LICENSE;

   uint64_t id = getIdFromString(ID); 
   list <GalleryItem>::iterator p = findItem(id);
   if (p == m_gallery.end())
      return NO_SUCH_RECORD;
   
   releaseGalleryItem(*p);
   m_gallery.erase   (p);

   return SUCCESS;
}
uint64_t RealMatcher::getFinalGallerySize()
{
   return m_gallery.size();
}

/**************************************************************************
   Auxilary functions
*************************************************************************/

bool RealMatcher::allocAccel(BYTE *&accel, uint32_t accelSize)
{
#ifdef _WINDOWS
   accel = (BYTE*) _aligned_malloc(accelSize, 16);
#else 
   if(posix_memalign((void**)&accel, 16, accelSize))
      accel = NULL;
#endif 
   return (accel != NULL);
}
void RealMatcher::freeAccel(BYTE *&accel)
{
   if (!accel)
      return;
#if defined(_WINDOWS)
   _aligned_free (accel), accel = NULL;
#else 
   ::free (accel), accel = NULL;
#endif 
}

uint32_t RealMatcher::createGalleryItem (uint64_t id, TpTemplate &tpTemplate, GalleryItem &item)
{
   item.m_id         = id;
   for (int finger = 0; finger < 10; finger++)
   {
      if (!tpTemplate.templ[finger])
         continue;
      uint32_t templateSize = ((TemplHeader*)tpTemplate.templ[finger])->size;
      item.m_tpTemplate.templ[finger] = new BYTE [templateSize];
      if (!item.m_tpTemplate.templ[finger])
         return LOW_MEMORY;
      memcpy(item.m_tpTemplate.templ[finger], tpTemplate.templ[finger], templateSize);
   }
   return SUCCESS;
}

uint32_t RealMatcher:: allocAccelBuffer ()              
{
   if (m_accelBuffer)
      return SUCCESS;
   // allocate memory for accel calculation
   m_accelBuffer = new BYTE [getMaximumAccelSize (10)]; 
   return m_accelBuffer ? SUCCESS :LOW_MEMORY;
}
uint32_t RealMatcher::checkMaResult (int result)
{
   switch(result)
   {
   case MA_OK                       :  return SUCCESS             ;
   case MA_LOW_MEMORY               :  return LOW_MEMORY          ;
   case MA_UNKNOWN_EXCEPTION        :  return UNKNOWN_EXCEPTION   ;
   case MA_WRONG_PROBE_TEMPLATE     :  return WRONG_TEMPLATE      ;
   case MA_WRONG_GALLERY_TEMPLATE   :  return WRONG_TEMPLATE      ;
   case MA_NO_FINGERS               :  return NO_SAME_FINGERS     ;
   case MA_WRONG_PARAMETRS          :  return WRONG_PARAMETRS     ;
   case MA_NOT_SUPPORT_SSE4_2       :  return NOT_SUPPORT_SSE4_2  ;   
   default:
      return VERIFICATION_FAILED;
   }
}

uint32_t RealMatcher::checkAccelMatchResult (int result)
{
   switch(result)
   {
   case SA_OK                 :   return SUCCESS                     ;
   case SA_UNPACK_INIT        :   return UNPACK_INIT_FAILED          ;
   case SA_UNPACK_ERR         :   return WRONG_TEMPLATE              ;
   case SA_LOW_MEMORY         :   return LOW_MEMORY                  ;
   case SA_ACCEL_CORRUPT      :   return ACCEL_CORRUPT               ;
   case SA_NOT_SUPPORT_SSSE3  :   return NOT_SUPPORT_SSSE3           ;
   case SA_WRONG_TEMPLATE     :   return WRONG_TEMPLATE              ;
   case SA_ACCEL_CALC_ERR     :   return ACCEL_CALC_ERR              ;
   case SA_NO_FINGERS         :   return NO_FINGERS_GOOD_FOR_ACCEL   ;

//   case SA_NULL_POINTER           2   // one of the pointer passed to the function is NULL
//   case SA_NULL_TEMPLATE          3   // pointer to template is NULL
//   case SA_NOT_INITIALIZED        6   // library is not initialized. Call 'initAccelLib' function first


   default:
      return IDENTIFICATION_FAILED;
   }
}
list <GalleryItem>::iterator RealMatcher::findItem(uint64_t id)
{
   GalleryItem item;
   item.m_id = id;
   return  find(m_gallery.begin(), m_gallery.end(), item);
}

bool RealMatcher::checkDouble(uint64_t id)
{
   GalleryItem item;
   item.m_id = id;
   return (findItem(item) != m_gallery.end());
}

bool RealMatcher::check (TpTemplate &tpTemplate)
{
   assert(m_unwrap);
   for(int finger = 0; finger < 10; finger++)
   {
      if (!tpTemplate.templ[finger])
         continue;
      BYTE *templ = tpTemplate.templ[finger] + sizeof(TemplHeader);
      if (!m_unwrap->verify (templ) ) 
         return false;
      if (!m_unwrap->defend (templ) ) 
         return false;
      //if (!m_unwrap->hasher (templ) ) 
      //   return false;
   }
   return true;
}
uint32_t RealMatcher::calculateAccelerator (GalleryItem &item, TpTemplate &tpTemplate)
{
   // calculate accelerator
   DWORD accelSize = NULL;
   int rs = calcAccel (m_accelHandle, tpTemplate, m_accelBuffer, accelSize);
   if (rs != SA_OK)
      return checkAccelMatchResult (rs);
   if (!allocAccel (item.m_accel, accelSize))
      return LOW_MEMORY;
   memcpy(item.m_accel, m_accelBuffer, accelSize);
   return SUCCESS;
}

void RealMatcher::freeGallery()
{
   list <GalleryItem>::iterator p    = m_gallery.begin();
   list <GalleryItem>::iterator pEnd = m_gallery.end  ();
   for(p; p != pEnd; p++)
   {
      releaseGalleryItem (*p);
   }
   m_gallery.clear();
}
void RealMatcher::releaseGalleryItem(GalleryItem &item)
{
   for(int finger = 0; finger < 10; finger++)
      if (item.m_tpTemplate.templ[finger])
         delete [] item.m_tpTemplate.templ[finger], item.m_tpTemplate.templ[finger] = NULL;
   if (item.m_accel) freeAccel (item.m_accel);
}


} // namespace Tech5Finger {
