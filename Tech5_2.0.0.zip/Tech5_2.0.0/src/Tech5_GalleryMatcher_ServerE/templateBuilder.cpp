#include <stdio.h>

#include "Tech5_GalleryMatcher_ServerE.h"
#include "licenseRoutine.h"
#include "ip.h"
#include "wsq31.h"

namespace Tech5Finger {


class TemplateBuilder : public TemplateCreator
{
   bool     m_valid_license;          // is license valid?
   bool     m_init         ;          // is m_ip initialized?
   Ip       m_ip           ;
   BYTE    *m_template     ;          // fingerprint template buffer  
   void    *m_wsqHandle    ;

public:
   TemplateBuilder()
   {
      m_valid_license = false; 
      m_init          = false; 
      m_template      = NULL;
      m_wsqHandle     = NULL;
   }
   virtual ~TemplateBuilder()
   {
      if (m_wsqHandle) cancel_instance (m_wsqHandle), m_wsqHandle = NULL;
      if (m_template ) delete [] m_template         , m_template  = NULL;  
   }
   static TemplateCreator*	create();                //create object of TemplateCreator
   static void cancel(TemplateCreator*& _Obj );		 //delete object of TemplateCreator
      
   virtual bool     initLicense    (const char *licensePath                                  );  
   virtual uint32_t createTemplate (RawImage &image, uint32_t &templateSize, uint8_t& quality);
   virtual uint32_t createTemplate (WsqImage &image, uint32_t &templateSize, uint8_t& quality);
   virtual void     getTemplate    (unsigned char *fpTemplate                                );

private:
   uint32_t init ();    // initialize m_ip and allocate momory for template buffer
   uint32_t checkIpResult (int result);
   uint32_t checkWsqResult (int result);
};


TemplateCreator*	TemplateCreator::create()
{
   TemplateCreator *templateCreator = NULL;
   try
	{
      templateCreator = new TemplateBuilder();
      if (!templateCreator)
         return NULL;
      
      return templateCreator;
	}
   catch(...)
	{
      delete templateCreator; 
      return NULL;
	}
}

void TemplateCreator::cancel (TemplateCreator *&templateCreator)
{
   if (templateCreator)
      delete templateCreator, templateCreator = NULL;
}


bool TemplateBuilder::initLicense(const char *licensePath)
{
   m_valid_license = checkLicense (licensePath);
   return m_valid_license;
}

uint32_t TemplateBuilder::checkIpResult (int result)
{
   switch(result)
   {
   case IP_OK:
      return SUCCESS;
   case IP_LOW_MEMORY:
      return LOW_MEMORY;
   case IP_UNKNOWN_EXCEPTION:
      return UNKNOWN_EXCEPTION;
   case IP_IMAGE_TOO_BIG:
      return IMAGE_TOO_BIG;
   case IP_NO_IMAGE:
      return NO_IMAGE;
   case IP_PROCESSING:
      return IMAGE_PROCESSING_FAILED;
   default:
      return IMAGE_PROCESSING_FAILED;
   }
}

uint32_t TemplateBuilder::checkWsqResult (int result)
{
   switch(result)
   {
   case 0:
      return SUCCESS;
   case ERROR_CHECK_SUM:
      return WRONG_WSQ_IMAGE;
   default:
      return WSQ_FAILED;
   }
}


uint32_t TemplateBuilder::init()
{
   if (m_init)
      return SUCCESS;

   // allocate memory for template buffer
   TemplateData data;
   int result = Ip::allocateTemplates (1, &data);
   if (result != IP_OK)
      return checkIpResult(result);
   m_template = data.fpTemplate;

   // initialize m_ip
   result = m_ip.init();
   m_init = (result == IP_OK);
   return checkIpResult(result);
}

uint32_t TemplateBuilder::createTemplate (RawImage &image, uint32_t &templateSize, uint8_t& quality)
{
   if (!m_valid_license)
      return NO_LICENSE;

   int result = init();
   if (result != SUCCESS) 
      return result;

   if (!image.m_width || !image.m_height || !image.m_image)
      return NO_IMAGE;
   if (image.m_finger < FINGPOS_UK || image.m_finger > FINGPOS_LL)
      return WRONG_FINGER_POS;

   ::Frame  frame;
   int qual = 0;
   result = m_ip.processRaw (NULL, image.m_image, image.m_width, image.m_height, m_template, &templateSize, &qual,  
                              NULL, &frame, image.m_finger);
   quality = (uint8_t)qual;
   return checkIpResult(result);
}

int wsqCheckSum (BYTE *src,  int imageSize)
{
   int sum=0;
   for (int i = 0; i < imageSize; i+=10)
       sum += (*(src+i) + (i << 1));
   return sum;
}



uint32_t TemplateBuilder::createTemplate (WsqImage &image, uint32_t &templateSize, uint8_t& quality)
{
   if (!image.m_size || !image.m_wsq)
      return NO_IMAGE;
   if (!m_valid_license)
      return NO_LICENSE;

   // decompress WSQ
   if (!m_wsqHandle) m_wsqHandle = init_instance();
   if (!m_wsqHandle) 
      return WSQ_INIT_FAILED;
   int width = 0, height = 0;
   int result = wsq_decode(m_wsqHandle, NULL, image.m_wsq, image.m_size, &width, &height, wsqCheckSum(image.m_wsq, image.m_size));
   if (result < 0 && result != EMPTY_SOURCE) return checkWsqResult (result);
   if (!width || !height)
      return NO_IMAGE;
   BYTE *imageBuffer = new BYTE [width * height];
   if (!imageBuffer)
      return LOW_MEMORY;
   result = wsq_decode(m_wsqHandle, imageBuffer, image.m_wsq, image.m_size, &width, &height, wsqCheckSum(image.m_wsq, image.m_size));
   if (result < 0) return checkWsqResult (result);

   RawImage raw;
   raw.m_finger = image.m_finger;
   raw.m_width  = width;
   raw.m_height = height;
   raw.m_image  = imageBuffer;
   result = createTemplate (raw, templateSize, quality);

   delete [] imageBuffer, imageBuffer = NULL;
   return result;
}

void TemplateBuilder::getTemplate (unsigned char *fpTemplate)
{
   int sizeTemplate = ((TemplHeader*)m_template)->size;
   memcpy(fpTemplate, m_template, sizeTemplate);
}



} // namespace Tech5Finger {
