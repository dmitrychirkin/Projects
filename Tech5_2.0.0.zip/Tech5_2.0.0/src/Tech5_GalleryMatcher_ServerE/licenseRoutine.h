#ifndef LICENSE_ROUTINE_H_
#define LICENSE_ROUTINE_H_

#include "Tech5_GalleryMatcher_ServerE.h"

namespace Tech5Finger {

bool checkLicense(const char *licensePath);

} // namespace Tech5Finger {


#endif // LICENSE_ROUTINE_H_