#include "licenseRoutine.h"
#include "hardware_common.h"
#include "hardwarebind.h"
#include "common.h"

namespace Tech5Finger {


#define HARDWARE_PROTECT

wchar_t* ToWide1(wchar_t *destination, const char *source)
{
	int cchWideChar = mbstowcs(0, source, 0);
	mbstowcs(destination, source, cchWideChar);
   destination[cchWideChar] = 0;
	return destination;
}


bool checkLicense(const char *licensePath)
{
   bool valid_license = true;
#ifndef HARDWARE_PROTECT	
      valid_license = true;
#else
   valid_license = false;
   if (!licensePath)
      return LICENSE_FILE_NAME_INVALID;
  	wchar_t licensePath_wide[MAX_PATH];
   ToWide1(licensePath_wide, licensePath);
   Tech5_Hardware_Protect *protect = new Tech5_Hardware_Protect(TECH5_SDK_GALLERY_MATCHER);
   if (protect)
   {
      if(protect->initLicense(licensePath_wide))
         valid_license = protect->check_protect(false);
   }
#endif
   return valid_license;
}

} // namespace Tech5Finger {
