//////////////////////////////////////////////////////////////////////////
//
//
//////////////////////////////////////////////////////////////////////////

#ifndef DEFINITIONS_H
#define DEFINITIONS_H

#define MAXIMUM_CLOSE_DISTANCE       2500
#define DISTANCE_STEP       /*1 << */2
#define MAX_DISTANCE_TABLE_VALUES    ( MAXIMUM_CLOSE_DISTANCE >> DISTANCE_STEP )

#define MAX_ANGLE_TABLE_VALUES       90
#define MAX_DISTANCE_TO_BAD_AREA     11
#define ANGLE_STEP          /*1 << */0

#define MAX_LOG                      64000
#define MAX_BAD_AREA_HITS            3
#define LOOKING_AT_EACH_OTHER        1 << 5
#define LOOKING_SAME_WAY             0
#define STRICT_ANGLE                 1 << 6
#define NOT_STRICT_ANGLE             0
#define PI	                         3.141592653589F
#define PI_2                         6.283185307178F
#define ON_SEARCH_LATENT             SEARCH_LATENT
#define ON_QUERY_LATENT              QUERY_LATENT
#define MAX_BAD_AREA_RADIUS          64
#define NOT_FOUND                    false
#define FOUND                        true

#define CORRECTION_IDENTIFIER        ( 1 << 8 )

#define NOT_FOUND_INDEX              1

#define VALUE_THRESHOLD              ( float )( 0.70 )

#define PARAMETERS_PATH              "Parameters"
#define PARAM_NAMES_FILE_NAME        "names.dat"
#define PARAM_LIMITS_FILE_NAME       "limits.dat"
#define PARAM_RESEARCH_SET_FILE_NAME "research.dat"
#define LAST_PARAMS_FILE_NAME        "last.dat"
#define HISTORY_STORAGE_FILE_NAME    "history.list"
#define MAX_PARAMS                   100

#define INFO_FILE_NAME               "info.txt"
#define SEARCH_RES_FILE_NAME         "SearchResults.sr"
#define TEMPLATE_SET_FILE_NAME       "TemplateSet.tps"
#define SEARCH_RES_FOLDER_NAME       "All_RESULTS_FOLDER"
#define ROOT_KEY_NAME                "SondaLtd\\ParametersTuning\\"
#define BASE_FOLDER_KEY              "Base Folder"
#define PARAMS_FOLDER_KEY            "Parameters Folder"
#define HISTORY_FOLDER_KEY           "History Folder"
#define STATISTICS_FOLDER_KEY        "Statistics Folder"

#define ROOT_FOLDER_DEF              "F:\\Parameters Tuner\\"
#define BASE_FOLDER_DEF              ROOT_FOLDER_DEF + "Bases"
#define PARAMS_FOLDER_DEF            ROOT_FOLDER_DEF + "Parameters"
#define HISTORY_FOLDER_DEF           ROOT_FOLDER_DEF + "History"
#define STATISTICS_FOLDER_DEF        ROOT_FOLDER_DEF + "Statistics"

#define RESULTS_FOLDER_NAME          "Results"

#define ON_ERROR( a )                if( a )
//#define NO_ERROR                     false
//#define ERROR                        true

#define ALL_TO_ALL_LIST_NAME         "AllToAll.list"
#define FVC_LIST_NAME                "FVC.list"

#define SDK_CHART                    5
#define MY_CHART                     4

#define TUNE_FOR_BEST_RESULTS        10
#define TUNE_FOR_BEST_VIEW           12

#define STATISTICS_SIZE              600
#define STATISTICS_SET_COUNT         100

#define STATIST_POCKET_FILE_NAME     "pocket.txt"

//#define max(a,b)                     (((a)>(b))?(a):(b))
//#define min(a,b)                     (((a)<(b))?(a):(b))

#endif