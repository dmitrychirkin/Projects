/*****************************************************************************
	compare100_TT.cpp - implementation of Compare100_TT class.
	Compare100_TT implements theTP-TP matching algorithm of Core Matching SDK
                 using ma100 algorithm   
*******************************************************************************/
#include <algorithm>
#include <functional>
#include <vector>

#include <math.h>

#include "compare100_TT.h"
#include "sfsDef.h"
#include "Matcher100.h"
#include "getFusedScore.h"
#include "mixFingerMatching.h"

#ifdef	ROCKEY
	#include "key_func.h"
#endif	//	ROCKEY

namespace accelMatch{
#pragma pack(push,_CORE_PACKING)

static BYTE scoreCoeff[] = {8, 4, 2, 1};

int Compare100_TT::calcFusionScore(SearchParam &searchParam, unsigned int numItems, unsigned int numRealScore,
                    int *score)
{
   if (!score)
      return MA_WRONG_POINTER;
   if (searchParam.fusionMode == OPTIMAL_FUSION_MODE)
      return getFusedScore_100 (numItems, numRealScore, score);      

	// binPos iterator points to the first vector element not located in the required bin.
   vector<int> sim;
   size_t i = 0;
   for(; i < numItems; i++)
      if (score[i])
         sim.push_back (score[i]);
   i= sim.size();
   for(; i < numRealScore; i++)
      sim.push_back (0);
	
   vector<int>::iterator pos, binPos;
	int symScore = 0;
	int symCoeff = 0;
	i = 0;
	
	switch (searchParam.fusionMode)
	{
		case LOW_BINNING_FUSION_MODE:
			sort(sim.begin(), sim.end(), less<int>());
			binPos = upper_bound(sim.begin(), sim.end(), searchParam.lowThreshold);

			if (binPos == sim.begin())
			{
				binPos = upper_bound(sim.begin(), sim.end(), searchParam.highThreshold);
				if (binPos == sim.begin())
					binPos = sim.end();
			}
			break;
		case HIGH_BINNING_FUSION_MODE:
			sort(sim.begin(), sim.end(), greater<int>());
			binPos = upper_bound(sim.begin(), sim.end(), searchParam.highThreshold, greater<int>());

			if (binPos == sim.begin())
			{
				binPos = upper_bound(sim.begin(), sim.end(), searchParam.lowThreshold, greater<int>());
				if (binPos == sim.begin())
					binPos = sim.end();
			}

			break;
	}

	for (pos = sim.begin(); pos < binPos && i < 4; pos++, i++)
	{
		symScore += *pos * scoreCoeff[i];
		symCoeff += scoreCoeff[i];
	}

	return (symScore / symCoeff);
}


Compare100_TT::Compare100_TT()
{
	m_matcher   = NULL;
   m_fs        = NULL;
   m_init      = false;
   m_isProbeLoaded = false;

}

Compare100_TT::~Compare100_TT()
{
   free();
}

int Compare100_TT::alloc()
{
   free();
   try
   {
      m_matcher = new(std::nothrow) Matcher100[10];
      m_fs      = new(std::nothrow) Fs;
   }
   catch(int &e)
   {
      return e;
   }
   if (!m_matcher || !m_fs)
      return MA_LOW_MEMORY;
   return MA_OK;
 }


void Compare100_TT::free()
{
	if (m_matcher  ) delete [] m_matcher  , m_matcher   = NULL;
	if (m_fs       ) delete    m_fs       , m_fs        = NULL;
}


int Compare100_TT::init (void *accelHandle)
{
   if (m_init) return MA_OK;
   int protect[MAX_PROTECT_LEN];
   memset (protect, 0, sizeof(protect));
   int pp[TL_3][MAX_NUM_LINKS] = 
   {
      {  // NT - no transition
   //    0     1     2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29    30    31    32    33    34
         0,    1,    2,    3,    4,    5,    6,    7,    8,    9,    10,   11,   12,   13,   14,   15,   16,   17,   18,   19,   20,   21,   22,   23,   24,   25,   26,   27,   28,   29,   30,   31,   32,   33,   34 
      },  
      { // E2LB_1   - endian to left bifurcation
   //    0     1     2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29    30    31    32    33    34
         1,    2,    0,    5,    6,    3,    4,    9,   10,    7,    8,    13,   14,   11,   12,   17,   18,   15,   16,   21,   22,   19,   20,   25,   26,   23,   24,   29,   30,   27,   28,   33,   34,   -1,   -1 
         },  

      {  // E2RB_1   - endian to right bifurcation
   //    0     1     2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29    30    31    32    33    34
         2,    3,    4,    0,    1,    7,    8,    5,    6,   11,    12,    9,   10,   15,   16,   13,   14,   19,   20,   17,   18,   23,   24,   21,   22,   27,   28,   25,   26,   31,   32,   29,   30,   -1,   -1 
         },

      {  // B2RE_1 -bifurcation right leg to endian
   //    0     1     2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29    30    31    32    33    34
         2,    0,    1,    5,    6,    3,    4,    9,   10,    7,     8,   13,   14,   11,   12,   17,   18,   15,   16,   21,   22,   19,   20,   25,   26,   23,   24,   29,   30,   27,   28,   -1,   -1,   31,   32 
         },    

      {  // B2LE_1  bifurcation left leg to endian 
   //    0     1     2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29    30    31    32    33    34
         3,    4,    0,    1,    2,    7,    8,    5,    6,   11,    12,    9,   10,   15,   16,   13,   14,   19,   20,   17,   18,   23,   24,   21,   22,   27,   28,   25,   26,   31,   32,   29,   30,   -1,   -1 
         },   

      {  // B2LB_2  - bifurcation left leg to bifurcation  
   //    0     1     2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29    30    31    32    33    34
         5,    6,    1,    2,    0,    9,   10,    3,    4,   13,    14,    7,    8,   17,   18,   11,   12,   21,   22,   15,   16,   25,   26,   19,   20,   29,   30,   23,   24,   33,   34,   27,   28,   -1,   -1 
         },  

      {  // B2RB_2 - bifurcation right leg to bifurcation 
   //    0     1     2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29    30    31    32    33    34
         4,    2,    3,    7,    8,    0,    1,   11,   12,    5,     6,   15,   16,    9,   10,   19,   20,   13,   14,   23,   24,   17,   18,   27,   28,   21,   22,   31,   32,   25,   26,   -1,   -1,   29,   30 
         },   
   };
   memcpy(protect, pp, sizeof(pp));
   return initEx(accelHandle, protect);
}

int Compare100_TT::initEx(void *accelHandle, int protect[MAX_PROTECT_LEN])
{
    if (m_init) return MA_OK;
    int result = MA_OK;
    memcpy (TransitionMatrix, protect, sizeof(TransitionMatrix));
    if ((result = alloc()) != MA_OK)
       return result;
    //for(int i = 0; i < 10; i++)
    //   if ((result = m_matcher[i].init (accelHandle)) != MA_OK)
    //      return result;
    m_isProbeLoaded = false;
    m_init = true;
	return MA_OK;
}

int Compare100_TT::loadTT (TpTemplate &probe, FP_TYPE typeG, BYTE **areaP, int *areaWidth, int *areaHeight)
{
   int result = MA_OK, rs = MA_OK;
   m_isProbeLoaded = false;
   if (!m_init || !m_matcher || !m_fs)
      return MA_NOT_INITIALIZED;

   TemplateData data[10];
   TemplHeader *header = NULL;
   int successCount = 0, faultCount = 0, count = 0;
	try
	{
      for(int finger = 0; finger < 10; finger++)
      {
         data[finger].numFinger = FINGERS(finger + 1);
         if (!probe.templ[finger])
            continue;
         count++;
         data[finger].fpTemplate = probe.templ[finger];
         rs = m_matcher[finger].loadProbe(data[finger].fpTemplate, typeG, 
                                       areaP      ? areaP     [finger] : NULL,
                                       areaWidth  ? areaWidth [finger] : NULL,
                                       areaHeight ? areaHeight[finger] : NULL);
         if (rs == MA_OK) successCount++;
         else             faultCount++, result = rs;
      }
      if (!count       ) return MA_NO_FINGERS;
      if (!successCount) return result;

      result = m_fs->loadTemplate1(10, data);
      if (result != MA_OK) 
         return result;
	}
	catch(...)
	{
		return MA_UNKNOWN_EXCEPTION;
	}
   m_isProbeLoaded = true;
   return faultCount ? MA_NOT_ALL_FINGES_LOADED : MA_OK;
}


int Compare100_TT::matchTTEx (SearchParam &param, TpTemplate &gallery, MatchResultTT &matchResultTT, FP_TYPE typeG)
{
   int result = MA_OK;
	if (!checkSearchParam (param)) 
      return MA_WRONG_PARAMETRS;
   if (!m_init || !m_matcher || !m_fs)
      return MA_NOT_INITIALIZED;
   
   if (!m_isProbeLoaded)
      return MA_NO_LOAD;

   if (param.matchingMode == CHECK_MIX_SLAP_MATCHING_MODE  ) 
      return slapMixMatchTTex (param, gallery, typeG, matchResultTT);
   if (param.matchingMode == CHECK_MIX_HAND_MATCHING_MODE  ) 
      return handMixMatchTTex (param, gallery, typeG, matchResultTT);

   TemplateData templSet[10];
   for (int finger = 0; finger < 10; finger++)
   {
      templSet[finger].fpTemplate = gallery.templ[finger]; 
      templSet[finger].numFinger  = (FINGERS)(finger + 1);
   }
   if (param.matchingMode == CHECK_MIX_FINGER_MATCHING_MODE) 
      return fingerMixMatchTTex (param, templSet, typeG, matchResultTT);
   // normal matching mode
   return compareTT (param, templSet, matchResultTT, typeG);
}

int Compare100_TT::compareTT (SearchParam &param, TemplateData templSet[10], MatchResultTT &matchResultTT, FP_TYPE typeG)
{
   assert(m_init && m_matcher && m_fs);
   matchResultTT.clear();
   int result = m_fs->loadTemplate2(10, templSet);
	if (result != MA_OK) 
      return result;
   	
	//	define minimum and maximum number of finger pairs for matching
	unsigned int numFinger[10];
	unsigned int numPairs = m_fs->getBestPairs (numFinger, param.matchingMode);
	if (!numPairs)           
      return MA_NO_FINGERS; 

	// perform matching
	FINGERS finger = FINGPOS_RT;
   MatchResult matchResult;

   for (unsigned int i = 0; i < numPairs; i++)
	{
		finger = (FINGERS)numFinger[i];
		if (finger < 1 || finger > 10) 
         continue;
      if (!templSet[finger - 1].fpTemplate)
         continue;
      result = m_matcher[finger - 1].loadGallery(templSet[finger - 1].fpTemplate, typeG);
      if (result != MA_OK)
         return result;
      if (finger== FINGPOS_RT || finger == FINGPOS_LT)
         result = m_matcher[finger - 1].match (matchResult, param.maxAngleThumbs, param.searchSpeed, false, NULL, NULL, 0, false);
      else
         result = m_matcher[finger - 1].match (matchResult, param.maxAngle      , param.searchSpeed, false, NULL, NULL, 0, false);

      if (result != MA_OK) 
         return result;
      if (matchResult.similarity)
      {
         matchResultTT.score      [finger - 1] = matchResult.similarity;
         matchResultTT.galleryPair[finger - 1] = finger - 1;
      }
      matchResultTT.numMatched++;
      matchResultTT.fusionScore = calcFusionScore (param, 10, matchResultTT.numMatched, matchResultTT.score);      
      
      // if minimal required number of matchs already done and it is enough for make decision than return
      if (matchResultTT.numMatched >= param.maxMatch || (matchResultTT.numMatched >= param.minMatch && 
         (matchResultTT.fusionScore >= param.highThreshold || matchResultTT.fusionScore<= param.lowThreshold)))
         break;
	}

	return MA_OK;
}



int Compare100_TT::fingerMixMatchTTex (SearchParam &param, TemplateData templSet[10], FP_TYPE typeG, MatchResultTT &matchResultTT)
{
   assert(m_init && m_matcher && m_fs);
   int result = MA_OK;
   matchResultTT.clear();
   if (!m_isProbeLoaded)
      return MA_NO_LOAD;

   unsigned int maxMatchedG = 0;
   for (int i = 0; i < 10; i++)
      if (templSet[i].fpTemplate)
         maxMatchedG++;

   result = m_fs->loadTemplate2(10, templSet);
	if (result != MA_OK) 
      return result;
   	
	//	define minimum and maximum number of finger pairs for matching
	unsigned int numFinger[10];
	unsigned int numPairs = m_fs->getBestPairs (numFinger, param.matchingMode);
	if (!numPairs || !maxMatchedG)           
      return MA_NO_FINGERS; 

	// perform matching
	FINGERS fingerP = FINGPOS_RT;
   MatchResult matchResult;
   PairScore score[100];
   unsigned int numPairScore = 0;

   for (unsigned int i = 0; i < numPairs; i++)
	{
		fingerP = (FINGERS)numFinger[i];
		if (fingerP > 10 || fingerP < 1) 
         continue;
   	bool matchedP = false;
	   for(int fingerG = 1; fingerG <= 10; fingerG++)
      {
         if (!templSet[fingerG - 1].fpTemplate)
            continue;
         result = m_matcher[fingerP - 1].loadGallery(templSet[fingerG - 1].fpTemplate, typeG);
         if (result != MA_OK)
            return result;
         if (fingerP== FINGPOS_RT || fingerP == FINGPOS_LT)
            result = m_matcher[fingerP - 1].match (matchResult, param.maxAngleThumbs, param.searchSpeed, false, NULL, NULL, 0, false);
         else
            result = m_matcher[fingerP - 1].match (matchResult, param.maxAngle      , param.searchSpeed, false, NULL, NULL, 0, false);
         if (result != MA_OK) 
            return result;
         if (matchResult.similarity)
            score[numPairScore++].set(fingerP - 1, fingerG - 1, matchResult.similarity);
         matchedP = true;
         if (matchResultTT.score[fingerP - 1] < matchResult.similarity)
         {
            matchResultTT.score      [fingerP - 1] = matchResult.similarity;
            matchResultTT.galleryPair[fingerP - 1] = fingerG - 1;
         }
      }
      if (matchedP)
         matchResultTT.numMatched++;
      if (matchResultTT.numMatched > maxMatchedG)
         matchResultTT.numMatched = maxMatchedG;
      chooseBestMatchedPairs (score, numPairScore, matchResultTT);
      matchResultTT.fusionScore = calcFusionScore (param, 10, matchResultTT.numMatched, matchResultTT.score);      
     
	}

	return MA_OK;
}

int Compare100_TT::slapMixMatchTTex (SearchParam &param, TpTemplate &gallery, FP_TYPE typeG, MatchResultTT &matchResultTT)
{
   TemplateData templSet[10], templSet_mix[10];       
   for (unsigned int finger = 0; finger < 10; finger++)
      templSet_mix[finger].numFinger  = templSet[finger].numFinger = (FINGERS)(finger + 1);
   for (unsigned int finger = 0; finger < 10; finger++)
   {
      if (finger == 0 || finger == 5)
      {
         templSet_mix[finger].fpTemplate = templSet[finger].fpTemplate = gallery.templ[finger]; 
         continue;
      }
      unsigned int newFinger = getMixHandFinger (finger);
      templSet_mix[newFinger].fpTemplate = templSet[finger].fpTemplate = gallery.templ[finger]; 
   }
   // do matching for not mixed slaps
   int result1 = compareTT (param, templSet, matchResultTT, typeG);
   if (result1 != MA_OK && result1 != MA_NO_FINGERS) return result1;
   // do matching for mixed slaps
   MatchResultTT matchResultTT_mix;
   int result2 = compareTT (param, templSet_mix, matchResultTT_mix, typeG);
   if (result2 != MA_OK && result2 != MA_NO_FINGERS) return result2;
   if (result1 == MA_NO_FINGERS && result2 == MA_NO_FINGERS)
      return MA_NO_FINGERS;
   // take the best results (for mixed or not mixed slaps):
   if (isFirstMatchResultTT_better(matchResultTT, matchResultTT_mix)) 
      return MA_OK;
   memcpy(&matchResultTT, &matchResultTT_mix, sizeof(MatchResultTT));
   for(unsigned int finger = 0; finger < 10; finger++)
   {
      if (finger == 0 || finger == 5 || matchResultTT.galleryPair[finger] == -1)
         continue;
      matchResultTT.galleryPair[finger] = getMixHandFinger(finger);
   }
    
	return MA_OK;
}


int Compare100_TT::handMixMatchTTex (SearchParam &param, TpTemplate &gallery, FP_TYPE typeG, MatchResultTT &matchResultTT)
{
   int result = MA_OK;
   TemplateData templSet_8[10]    , templSet_2[10];      // not mixed hands
   TemplateData templSet_8_mix[10], templSet_2_mix[10];  //     mixed hands 
   for (unsigned int finger = 0; finger < 10; finger++)
   {
      unsigned int newFinger = getMixHandFinger (finger);
      if (finger == 0 || finger == 5)
      {
         templSet_2 [finger].fpTemplate = templSet_2_mix[newFinger].fpTemplate = gallery.templ[finger]; 
         templSet_2 [finger].numFinger  = templSet_2_mix[finger].numFinger  = (FINGERS)(finger + 1);
         continue;
      }
      templSet_8[finger].fpTemplate = templSet_8_mix[newFinger].fpTemplate = gallery.templ[finger]; 
      templSet_8[finger].numFinger  = templSet_8_mix[finger].numFinger  = (FINGERS)(finger + 1);
   }
   // do matching for not mixed slaps
   MatchResultTT matchResultTT_8;
   int result1 = compareTT (param, templSet_8, matchResultTT_8, typeG);
   if (result1 != MA_OK && result1 != MA_NO_FINGERS) return result1;
   // do matching for mixed slaps
   MatchResultTT matchResultTT_8_mix;
   int result2 = compareTT (param, templSet_8_mix, matchResultTT_8_mix, typeG);
   if (result2 != MA_OK && result2 != MA_NO_FINGERS) return result2;
   if (result1 == MA_NO_FINGERS && result2 == MA_NO_FINGERS) result = MA_NO_FINGERS;
   // take the best results
   if (isFirstMatchResultTT_better(matchResultTT_8, matchResultTT_8_mix)) 
      memcpy(&matchResultTT, &matchResultTT_8, sizeof(MatchResultTT));
   else         
   {
      memcpy(&matchResultTT, &matchResultTT_8_mix, sizeof(MatchResultTT));
      for(unsigned int finger = 0; finger < 10; finger++)
      {
         if (finger == 0 || finger == 5 || matchResultTT.galleryPair[finger] == -1)
            continue;
         matchResultTT.galleryPair[finger] = getMixHandFinger (finger);
      }
   }
   // if minimal required number of matchs already done and it is enough for make decision than return
   if (result != MA_NO_FINGERS && matchResultTT.numMatched >= param.maxMatch || (matchResultTT.numMatched >= param.minMatch && 
      (matchResultTT.fusionScore >= param.highThreshold || matchResultTT.fusionScore<= param.lowThreshold)))
      return MA_OK;

   // do matching for not mixed thumbs
   MatchResultTT matchResultTT_2;
   int result3 = compareTT (param, templSet_2, matchResultTT_2, typeG);
   if (result3 != MA_OK && result3 != MA_NO_FINGERS) return result3;
   // do matching for mixed thumbs
   MatchResultTT matchResultTT_2_mix;
   int result4 = compareTT (param, templSet_2_mix, matchResultTT_2_mix, typeG);
   if (result4 != MA_OK && result4 != MA_NO_FINGERS) return result;
   if (result == MA_NO_FINGERS && result3 == MA_NO_FINGERS && result4 == MA_NO_FINGERS) 
      return MA_NO_FINGERS;
   // add the best result to final result
   if (isFirstMatchResultTT_better(matchResultTT_2, matchResultTT_2_mix)) 
   {
      matchResultTT.score      [0] = matchResultTT_2.score[0];
      matchResultTT.score      [5] = matchResultTT_2.score[5];
      if (matchResultTT_2.galleryPair[0] != -1) matchResultTT.galleryPair[0] = 0;
      if (matchResultTT_2.galleryPair[5] != -1) matchResultTT.galleryPair[5] = 5;
      matchResultTT.numMatched += matchResultTT_2.numMatched;
   }
   else                                                          
   {
      matchResultTT.score      [0] = matchResultTT_2_mix.score[0];
      matchResultTT.score      [5] = matchResultTT_2_mix.score[5];
      if (matchResultTT_2_mix.galleryPair[0] != -1) matchResultTT.galleryPair[0] = 5;
      if (matchResultTT_2_mix.galleryPair[5] != -1) matchResultTT.galleryPair[5] = 0;
      matchResultTT.numMatched += matchResultTT_2_mix.numMatched;
   }
   // calculate final fusion score
   matchResultTT.fusionScore = calcFusionScore (param, 10, matchResultTT.numMatched, matchResultTT.score);      
	return MA_OK;
}

int Compare100_TT::matchEx (SearchParam &param, BYTE *templG,
                        int &similarity, FINGERS fingerP, MatchResult *matchResult,
                        FP_TYPE typeG,
                        bool useCombineData, BYTE *np, BYTE *ng, BYTE accelGroupSize, bool quickAccelMatch)
{
   int result = MA_OK;
	if (!checkSearchParam (param)) 
      return MA_WRONG_PARAMETRS;
   if (!m_init || !m_matcher)
      return MA_NOT_INITIALIZED;
	if (!templG) 
      return MA_WRONG_POINTER;
   if (fingerP < FINGPOS_RT || fingerP > FINGPOS_LL)
      return MA_WRONG_FINGER_NUM;
	similarity = 0;

	try
	{
      if (matchResult)
      {
         memset (matchResult, 0, sizeof (MatchResult));
         matchResult->fingerP = matchResult->fingerG = fingerP;
      }

      result = m_matcher[fingerP - 1].loadGallery(templG, typeG);
      if (result != MA_OK)
         return result;
      MatchResult matchResult_a;
      if (fingerP== FINGPOS_RT || fingerP == FINGPOS_LT)
         result = m_matcher[fingerP - 1].match (matchResult_a, param.maxAngleThumbs, param.searchSpeed, useCombineData, np, ng, accelGroupSize, quickAccelMatch);
      else
         result = m_matcher[fingerP - 1].match (matchResult_a, param.maxAngle      , param.searchSpeed, useCombineData, np, ng, accelGroupSize, quickAccelMatch);
		if (result == MA_OK)
      {
         similarity = matchResult_a.similarity;
         if (matchResult)
            memcpy (matchResult, &matchResult_a, sizeof (MatchResult));
         return MA_OK;
      }
      else
         similarity = 0;
	}
	catch(...)
	{
		return MA_UNKNOWN_EXCEPTION;
	}

	return MA_MATCH;
}

bool Compare100_TT::checkSearchParam(SearchParam &param)
{
   if (param.highThreshold  >           MAX_SCORE) return false;
   if (param.lowThreshold   >            MAX_SCORE) return false;
   if (param.maxAngle       >                  180) return false;
   if (param.maxAngleThumbs >                  180) return false;
   if (param.maxMatch       >                   10) return false;
   if (param.minMatch       >                   10) return false;
   if (param.searchSpeed    >  HIGHEST_MATCH_SPEED) return false;

   return true;
}


#pragma pack(pop)
} // namespace accelMatch{

