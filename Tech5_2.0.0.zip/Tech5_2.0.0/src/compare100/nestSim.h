#ifndef NEST_SIM_H_
#define NEST_SIM_H_

#include <assert.h>
#include <stdlib.h>

#include "coreSdk.h"


namespace accelMatch{
#pragma pack(push, 1) 

struct NestSim
{
   BYTE         m_np;  
   BYTE         m_ng;  
   WORD         m_sim;
   NestSim() 
   { 
      clear();
   }
   NestSim (BYTE np, BYTE ng, WORD sim) 
   { 
      m_np         = np;
      m_ng         = ng;
      m_sim        = sim; 
   }
   void clear()
   {
      memset(this, 0, sizeof(NestSim));
   }
};
static inline int compareNestSim (const void *val1, const void *val2) 
{
   return (int)(((NestSim*)val2)->m_sim) - (int)(((NestSim*)val1)->m_sim);  
} 
struct NestSimSet
{
   NestSim     m_nestSimArray[MAX_MINUTIAE * MAX_MINUTIAE];
   size_t      m_numItems;
   
   NestSimSet ()
   {
      clear();
   }
   void clear()
   {
      m_numItems = 0;
   }
   size_t size()
   {
      return m_numItems;
   }
   void insert (BYTE np, BYTE ng, WORD sim)
   {
      m_nestSimArray[m_numItems].m_np  = np;
      m_nestSimArray[m_numItems].m_ng  = ng;
      m_nestSimArray[m_numItems].m_sim = sim;
      m_numItems++;
   }
   int find (BYTE np, BYTE ng)
   {
      for (size_t i = 0; i < m_numItems; i++)
      {
         if (m_nestSimArray[i].m_sim && m_nestSimArray[i].m_np == np && m_nestSimArray[i].m_ng == ng)
            return (int)i;
      }
      return -1;
   }
   void remove (int pos)
   {
      m_nestSimArray[pos].clear();
   }
   WORD getSim (int pos)
   {
      return m_nestSimArray[pos].m_sim;
   }
   void sort()
   {
      qsort(m_nestSimArray, m_numItems, sizeof(m_nestSimArray[0]), compareNestSim); 
   }
   NestSim* getItem(size_t pos)
   {
      return &m_nestSimArray[pos];
   }
};



#pragma pack(pop) 
} // namespace accelMatch{

#endif  // NEST_SIM_H_



