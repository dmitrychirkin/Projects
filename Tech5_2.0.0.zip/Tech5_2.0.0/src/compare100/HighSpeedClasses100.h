#pragma once
#define HERE -1

#pragma pack(push, _CORE_PACKING)

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
namespace SondaLtd{
   namespace Containers{
      enum OptionStartFrom
      {
         FirstItem,
         LastItem
      };
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
      template< class T>
      class ChainContainer {
      public:
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
         class ChainLink
         {
         public:
            ChainLink* prevLink;
            ChainLink* nextLink;
            T*         thisItem;

            ChainLink()
            {
               prevLink = 0;
               nextLink = 0;
               thisItem = 0;
            }

            ~ChainLink() {};

            T* GetItem()
            {
               return thisItem;
            }
         };
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
         class ChainLinkContainer {
         private:
            ChainLink * chainLinksStack;
            int         topFreeLink;
            int         maxLinks;

         public:
            ChainLinkContainer( int size )
            {
               chainLinksStack = new ChainLink [ size ];
               topFreeLink = 0;
               maxLinks = size;
            }

            ~ChainLinkContainer()
            {
               if ( chainLinksStack ) delete [] chainLinksStack;
            }

         public:
            ChainLink * GetLink()
            {
               if ( topFreeLink >= maxLinks ) return 0;
               ChainLink * retLink = &chainLinksStack[ topFreeLink ];
               retLink->nextLink = NULL;
               retLink->prevLink = NULL;
               retLink->thisItem = NULL;
               topFreeLink ++;
               return retLink;
            }

            void FreeLink( ChainLink * link )
            {
            }

            void Reset()
            {
               topFreeLink = 0;
            }
         };
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
      private:
         int          linksCount;
         ChainLink*   firstLink;
         ChainLink*   lastLink;
         ChainLink*   thisLink;
         ChainLinkContainer*  unusedLinksStack;

      public:
         ChainContainer( int size ) 
         {
            unusedLinksStack = new ChainLinkContainer( size );
            Clean();
         }

         ~ChainContainer() 
         {
            Clean();
            if ( unusedLinksStack ) delete    unusedLinksStack;
         }
      public:
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
         ChainLink* GetFirst()
         {
            return this->firstLink;
         }
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
         ChainLink* GetLast()
         {
            return this->lastLink;
         }
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
         ChainLink* GetNext( ChainLink* link)
         {
            if ( link )  return link->nextLink;
            return 0;
         }
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
         ChainLink* GetPrev( ChainLink* link )
         {
            if ( link ) return link->prevLink;
            return 0;
         }
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
         void Add( T* typeObject ) 
         {
            InsertAfterLink( lastLink, typeObject );
            thisLink = lastLink;
         }
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
         void Del( ChainLink* link )
         {
            RemoveLink( link );
         }
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
         void InsertAt( T* typeObject, int position = HERE ) 
         {
            if ( position >= linksCount ) return;
            if ( position >= 0 ) {
               thisLink = firstLink;
               for ( int i = 0; i < position; i++)
                  thisLink = thisLink->nextLink;
            }

            InsertAfterLink( thisLink, typeObject );
         }
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
         void RemoveAt( int position = HERE )
         {
            if ( position >= linksCount ) return;
            if ( position >= 0 ) {
               thisLink = firstLink;
               for ( int i = 0; i < position; i++)
                  thisLink = thisLink->nextLink;
            }

            RemoveLink( thisLink );
         }
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
         T* operator[] ( int position ) 
         {
            ChainLink * tmpLink = firstLink;
            
            if ( position < 0 ) return thisLink->thisItem;
            else
               for ( int i = 0 ; i < position; i++ )
                  tmpLink = tmpLink->nextLink;
            
            return tmpLink->thisItem;
         }
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
         void Clean()
         {
            firstLink   = 0;
            thisLink    = 0;
            lastLink    = 0;
            linksCount  = 0;
            unusedLinksStack->Reset();
         }
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
      private:
         void InsertAfterLink( ChainLink * link, T* typeObject )
         {
            ChainLink* newItem = unusedLinksStack->GetLink();
            if ( !newItem ) return;

            newItem->thisItem = typeObject;
            newItem->prevLink = link;
            newItem->nextLink = 0;

            if ( link ) { 
               link->nextLink = newItem;
               link = newItem;
            } 
            else {
               if ( !this->firstLink ) this->firstLink = newItem;
               if ( !this->lastLink ) this->lastLink = newItem;
               link = newItem;
            }
            while ( this->lastLink->nextLink )
               this->lastLink = this->lastLink->nextLink;

            this->linksCount ++;
         }
//////////////////////////////////////////////////////////////////////////
//       After removing current Item - current Item becomes NULL.
//       Use MoveNext  or MovePrev to set
//////////////////////////////////////////////////////////////////////////
         void RemoveLink( ChainLink * link )
         {
            if ( link ) {
               if ( link->nextLink ) link->nextLink->prevLink = link->prevLink;
               if ( link->prevLink ) link->prevLink->nextLink = link->nextLink;
               if ( link == this->lastLink ) lastLink = link->prevLink;
               if ( link == this->firstLink ) firstLink = link->nextLink;

               link->thisItem   = 0;
               this->linksCount --;
            }
         }
      };
   }
}
#pragma pack(pop)
