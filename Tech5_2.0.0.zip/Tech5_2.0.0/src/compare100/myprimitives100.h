/*************************************************************************************************************************************



*************************************************************************************************************************************/
#ifndef MY_PRIMITIVES_H
#define MY_PRIMITIVES_H

#include "mathem100.h"


#define MY_MAX_MINUTIAE   500
#define MY_MAX_SINGULAR   16
#define MY_MAX_BAD_AREA   100*100
#define AVRAGE_PAIR_COUNT 6

typedef unsigned char BYTE;

namespace Primitive {
#pragma pack(push, _CORE_PACKING)

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
   enum Singular_Types {
      WHORL_TYPE  =	1 << 0,
      LOOP_TYPE	=  1 << 1,
      ARCH_TYPE	=  1 << 2,
      DELTA_TYPE	=  1 << 3,
      CENTRE_TYPE	=  1 << 4,
      ANY_TYPE    =  0xF
   };
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
   enum Params {                        //   fields marked with '*' do not affect result while parameters tuning 
      _CloseDistance              = 0,  // * Square distance below which signs consider to be either close or matching 250 ... 3000
      _AngleThreshold             = 1,  // * Angle difference below which signs considered to be genuine 0 ... 180
      _BadAreaRadius              = 2,  // * If there is a bad area within that Radius around sign - sign considered to be within bad area 
                                        //   value is multiple of 8
      _BestMatchCost              = 3,  //   Maximum reward for full match 0 ... 1
      _WorstMismatchCost          = 4,  //   Maximum penalty for mismatch  0 ... 1
      _ToIndexCorrection          = 5,  //   Maximum index possible        0 ... 1
      _TooBigDensity              = 6,  // * If density is greater than his parameter correction is applied 0 ... 15
      _DistanceNearbySingular     = 7,  // *
      _AllowOnly                  = 8,  //   -1 allow only minus correction; 1 allow only plus correction; 0 allow everithing 
      _CloseForNonsense           = 9,  // * 
      _ScaleErrBoundry            = 10, //   Scale error in percents above which latents are considered to be impostor 
      _ApplyDistortionCorrection  = 11, // * apply Distortion correction if not 0
      _DistMinIndexThreshold      = 12, //   Distance similarity threshold for most likely impostor pair 0 ... 1
      _DistMaxIndexThreshold      = 13, //   Distance similarity threshold for most likely genuine  pair 0 ... 1
      _BadAreaIndexThreshold      = 14, //   Distance to Bad Area parameter similarity threshold         0 ... 1
      _AngleMinIndexThreshold     = 15, //   Angle similarity threshold for most likely impostor pair 0 ... 1
      _AngleMaxIndexThreshold     = 16, //   Angle similarity threshold for most likely impostor pair 0 ... 1
      _StrictAngleThreshold       = 17, //   Angle threshold for cases where strict angle match is required
      _MinQualityThreshold        = 18, //   Latents with quality lower than this parameter are not processed.
      _UseMainGroupSizeField      = 19,
      _ScaleMismatchPenalty       = 20,
      _USER_PARAMETER_COUNT       = 21, // ** Internal 

      _WorstIndex                 = 21, // ** Internal 
      _DistanceWeightNormalized   = 22, // ** Internal
      _AngleWeightNormalized      = 23, // ** Internal
      _MAXIMUM_PARAMETER_COUNT    = 24  // ** Internal 
   };
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
   struct CompareResults {

      float posIndex, negIndex;
      float posCount, negCount, nulCount;

      CompareResults()
      {
         posIndex = 0;
         negIndex = 0;
         nulCount = 0;
         posCount = 0;
         negCount = 0;
      }
//////////////////////////////////////////////////////////////////////////
      inline void AccumulateIndex( float index )
      {
         if      ( index > 0 ) { posIndex +=  index; posCount ++; }
         else if ( index < 0 ) { negIndex += -index; negCount ++; }
         else                  {                     nulCount ++; }
      }
//////////////////////////////////////////////////////////////////////////
      inline float GetResultingIndex()
      {
         if ( posCount == 1 ) return 0; 
         float res = (( posCount + negCount ) ? ( ( posIndex - negIndex ) / ( posCount + negCount ) ) : 0 );

         if ( res > 1  ) res =  1;
         if ( res < -1 ) res = -1;

         return res ;
      }
   };
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
   template <class T> 
   struct pairOf {
      T One;
      T Two;
   };
//////////////////////////////////////////////////////////////////////////
//		Structure for holding Integral and minutiae coordinates
//////////////////////////////////////////////////////////////////////////
   struct Coordinate {
      int   X;
      int   Y;
      int   Angle;

      Coordinate () {
         X     = 0;
         Y     = 0;
         Angle = 0;
      }

      Coordinate  operator+  ( Coordinate coord );
      void        operator+= ( Coordinate coord );
      Coordinate  operator-  ( Coordinate coord );
      void        operator-= ( Coordinate coord );

      int         DistanceTo   ( const Coordinate tmp );
      int         SqrDistanceTo( const Coordinate tmp );
      int         AngleTo      ( const Coordinate tmp );
   };
   inline int Coordinate::SqrDistanceTo( const Coordinate tmp )
   {
      return accelMatch::EVK( (tmp.X - this->X ), ( tmp.Y - this->Y ) );
   }
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
   struct MySign : public Coordinate
   {
      BYTE	Type;
      BYTE	Probability;
      BYTE	distanceToBadArea;
      BYTE	Density;
      bool  isReliable;  

      MySign () 
      {
         Angle             =   0;
         X                 =   0;
         Y                 =   0;
         Type              =   ANY_TYPE;
         Probability       =   0;
         distanceToBadArea =   10;
         Density           =   0;
         isReliable        =   true;
      }

      MySign   operator- ( const Coordinate & coord );
      MySign   operator- ( const MySign &     coord );
      MySign & operator= ( const MySign &     tmp   );
   };
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
   struct MappingMatrix
   {
      float Elements[ 2 ][ 3 ];
      MappingMatrix()
      {
         Elements[0][0] = 1;
         Elements[0][1] = 0;
         Elements[0][2] = 0;
         Elements[1][0] = 0;
         Elements[1][1] = 1;
         Elements[1][2] = 0;
      }

      void Rotate ( Coordinate &coord ) {  
         float X   = ( float )coord.X;
         coord.X = int( X * Elements[0][0] + ( float )coord.Y * Elements[0][1] + Elements[0][2] );
         coord.Y = int( X * Elements[1][0] + ( float )coord.Y * Elements[1][1] + Elements[1][2] );
      }

      void Rotate ( MySign &sign ) { 
         float X   = ( float )sign.X;
         sign.X = int( X * Elements[0][0] + ( float )sign.Y * Elements[0][1] + Elements[0][2] );
         sign.Y = int( X * Elements[1][0] + ( float )sign.Y * Elements[1][1] + Elements[1][2] );
      }
   };
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
   struct MyObject
   {
   public:
      BYTE       *   m_BadArea;                    // Holds pointer to pre-allocated memory block destined to have Bad Area info
      Coordinate *   m_MinutiaeRefArr;
      MySign     *   m_SingularRefArr;

   public:
      unsigned short MaxX;
      unsigned short MaxY;
      float          Scale;					         // Scale of latent print image
      BYTE           PatternType;				      // Pattern Type which can combine different pattern types
                                                   // Such as Arch, Rocket, Tented Arch and so on
      BYTE           Quality;					         // Quality of a latent print image
      BYTE           CountInts[ MY_MAX_SINGULAR ];	// An array of values holding count of Integral signs 
      int            CountMinutiae;                // Number of minutiae signs of fingerprint
      int 	         CountSingular;                // Count total number of integrals 
      int            BadAreaSize;            
      BYTE           PapillarDensity;
      
      Coordinate     Vector;
      MySign     *   SingularArr;
      MySign     *   MinutiaeArr;
      MySign     *   SingularRefArr;
      Coordinate *   MinutiaeRefArr;
      BYTE       *   BadArea;


      MyObject ();

      MyObject ( MyObject * tmp );

      ~MyObject ();

      void Clean();
      void operator= ( const MyObject & tmp );
   };

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
   struct Err {
      int  dX, dY, dA;
      int  avgX, avgY, avgA;

      Err () { Clean(); }

      void Clean() 
      { 
         dX   = dY   = dA   = 0;
         avgX = avgY = avgA = 0;
      }
   };
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
   struct PairDescription {
      int      dist;
      int      angle;
      int      density;
      bool     isFound;
      bool     isInTransition;
      bool     isProcessingError;

      MySign * qSign;
      MySign * sSign;

      PairDescription () { Clean(); }

      void Clean();
   };
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
   struct AllResults  {
      int               pairCount              ;
      bool              areWhorlsOnOppositSides;
      Err               measureErrors          ;
      BYTE              matches                ;
      BYTE              qMainDensity           ;
      BYTE              sMainDensity           ;
      BYTE              qTotalDensity          ;
      BYTE              sTotalDensity          ;
      
      PairDescription   pairRes[ MY_MAX_SINGULAR * 2 ];
      
      AllResults () { Clean(); }

      void Clean();

      PairDescription * GetCurrentPair() { return &( this->pairRes[ pairCount - 1 ] ); }

      void AddNewPair()     { pairCount ++ ; }
      void RemoveLastPair() { pairCount -- ; }
      void operator= ( AllResults tmp_AllResults );
   };
#pragma pack(pop)
}

#endif