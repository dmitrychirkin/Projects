#include "matcher100.h"
#include "accelDeal.h"
#include "staticData100.h"

namespace accelMatch{

// distance border for each of 4 levels - right border, ddist 
#define DIST_BORDER_SIZE   (sizeof(g_distBorders) / sizeof(g_distBorders[0]))
unsigned int g_distBorders[][2] = 
{
   {  20,  5 },   // level 0, len = 20, 
   {  42,  5 },   // level 1, len = 22
   {  66,  6 },   // level 2, len = 24
   {  92,  6 },   // level 3, len = 26
   { 121,  7 },   // level 4, len = 29
   { 153,  8 },   // level 5, len = 32
   { 188,  8 },   // level 6, len = 35
   { 227,  9 },   // level 7, len = 39

};

int getDistLevel (unsigned int dist)
{
   for(int level = 0; level < DIST_BORDER_SIZE; level++)
      if (dist <= g_distBorders[level][0]) 
         return level;
   return -1;
}

unsigned int getAddDistLevel (unsigned int dist, unsigned int level, unsigned int addDistLevel[2])
{
   unsigned int numAdd = 0;
   unsigned int dist2top    = level * g_distBorders[level][0] - dist;
   if (dist2top < g_distBorders[level][1] && level < DIST_BORDER_SIZE - 1)
      addDistLevel[numAdd++] = level + 1;
   if (!level)
      return numAdd;
   unsigned int dist2bottom = dist - level * g_distBorders[level - 1][0];
   if (dist2bottom < g_distBorders[level][1])
      addDistLevel[numAdd++] = level - 1;

   return numAdd;
}

void freeNestAccel(NestAccel *&nestAccel)
{
#if defined(_WINDOWS) && defined(SSE_SUPPORT) 
      if (nestAccel) _aligned_free (nestAccel), nestAccel = NULL;
#else
      if (nestAccel) ::free (nestAccel), nestAccel = NULL;
#endif
}

void allocNestAccel(NestAccel *&nestAccel, unsigned int n)
{
   freeNestAccel(nestAccel);
#ifdef SSE_SUPPORT
   #ifdef _WINDOWS
   nestAccel = (NestAccel*) _aligned_malloc(sizeof(NestAccel) * n, 16);
   #else 
   if(posix_memalign((void**)&nestAccel, 16, sizeof(NestAccel) * n))
      nestAccel = NULL;
   #endif // _WINDOWS
#else
   nestAccel = (NestAccel*) malloc (sizeof(NestAccel) * n);
#endif // SSE_SUPPORT

}

void setBit2Accel(NestAccel &accel, unsigned int rc, unsigned int distLevel, unsigned int quadrant,  bool sameDir)
{
   assert (rc <= 3);
//   accel.accel.m128i_u8[quadrant * 4 + rc] |= 0x01 << (sameDir ? distLevel : distLevel + 4);
   if (sameDir) accel.accel[0].m128i_u8[quadrant * 4 + rc] |= 0x01 << distLevel;
   else         accel.accel[1].m128i_u8[quadrant * 4 + rc] |= 0x01 << distLevel;
 }


void calcNestAccel(bool isProbe, NestAccel &accel, ESK::Sign *minutiae, ESK::Link *links, unsigned int numNests, unsigned int n0, MinutiaePairSet &pairSet)
{
   memset (&accel, 0, sizeof(NestAccel));

   int maxLink = links[n0].Cage;
   if (!maxLink)
      return;

   ESK::byte_t  type = minutiae[n0].Type; 
   ESK::twin_t n = 0;

   for (int link = 0; link < maxLink; link++)   // go through links
   {
      ESK::byte_t deal = links[n0].Knot[link].Deal;
      if (!deal)
          continue;      
      n = links[n0].Knot[link].Item;
      if (n == n0)
         continue;
      int dist = pairSet.getLen (n0, n);
      int distLevel = getDistLevel(dist);
      if (distLevel < 0)
         continue;
      unsigned int quadrant = 0;
      int rc = abs(calcRidgeCount (type, link, links[n0].Knot[link].Deal, quadrant)) / 2;
      if (rc > 3)
         continue;
      bool sameDir = isSameDirection (deal, (MINUTIAE_TYPE)type, link);
      setBit2Accel (accel, rc, distLevel, quadrant, sameDir);
      // check if there are another events on this link after this event
      // ..

      if (!isProbe)
         continue;
      unsigned int addDistLevel[2];
      unsigned int numAdd = getAddDistLevel (dist, distLevel, addDistLevel);
      for(unsigned int i = 0; i < numAdd; i++)
         setBit2Accel (accel, rc, addDistLevel[i], quadrant, sameDir);
   }
}


void calcAllNestAccel(bool isProbe, NestAccel *accel, ESK::Sign *minutiae, ESK::Link *links, unsigned int numNests, MinutiaePairSet &pairSet)
{
   for(unsigned int n = 0; n < numNests; n++)
      calcNestAccel(isProbe, accel[n], minutiae, links, numNests, n, pairSet);
}


int compNestAccel(NestAccel &accelP, NestAccel &accelG)
{
   m128i_my res1 = my_mm_and_si128 (&accelP.accel[0], &accelG.accel[0]);
   m128i_my res2 = my_mm_and_si128 (&accelP.accel[1], &accelG.accel[1]);
   return calcSum_1_Bits(res1) + calcSum_1_Bits(res2);
//      (int)_mm_popcnt_u64(((m128i_my*)&res1)->m128i_u64[0]) + (int)_mm_popcnt_u64(((m128i_my*)&res1)->m128i_u64[1]) + 
//          (int)_mm_popcnt_u64(((m128i_my*)&res2)->m128i_u64[0]) + (int)_mm_popcnt_u64(((m128i_my*)&res2)->m128i_u64[1]);
}

int Matcher100::compareAllNestAccel()
{
   BYTE sim = 0;
   int angleDif= 0;
   memset(m_simHist, 0, sizeof(m_simHist));

   for(int np = 0; np < m_numNestP; np++)
   {
      for(int ng = 0; ng < m_numNestG; ng++)
      {
         angleDif = normAngle((int)m_minutiaeP[np].Beta - (int)m_minutiaeG[ng].Beta);
         m_nestCompResult[np][ng].setAngleDif (angleDif);
         if (!checkAngle(np, ng, m_maxAngle, angleDif))
            continue;
         sim = compNestAccel (m_nestAccelP[np], m_nestAccelG[ng]);
         m_accelSim[np][ng] = sim;
         assert (sim <= MAX_NEST_ACCEL_SIM);
         m_simHist[sim]++;
      }
   }
   return m_numNestP * m_numNestG; 
}

} // namespace accelMatch{
