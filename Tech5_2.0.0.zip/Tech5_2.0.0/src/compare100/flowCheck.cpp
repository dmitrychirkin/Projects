#include "matcher100.h"

namespace accelMatch{

//void Matcher100::checkFlowConcordance()
//{
//   int flowAverangeErr = 0;
//   for(int np = 0; np < m_numNestP; np++)
//   {
//      if (m_curGroup->findProbe (np) != -1)
//         continue;
//      if (m_excludeP[np])
//         continue;
//      int angleP = normAngle90(m_minutiaePR[np].m_angle);
//      int angleG = 0;
//      if (!getGalleryFlowDirection (m_minutiaePR[np].m_x, m_minutiaePR[np].m_y, angleG))
//         continue;
//      int angleDif = abs(normAngle90(angleP - angleG));
//      if (angleDif > 45)
//      {
//         flowAverangeErr += angleDif;
//         m_param.m_numFlowError++;
//      }
//   }
//   m_param.m_flowAverangeErr = m_param.m_numFlowError ? (BYTE)(flowAverangeErr / m_param.m_numFlowError) : 0;
//}

bool Matcher100::getGalleryFlowDirection (int x0, int y0, int &angle)
{
   angle = 0;
   struct MinDist
   {
      int angle; 
      int dist;
      MinDist()
      {
         angle =  0   ;
         dist  =  1024;
      }
   };
   MinDist minDist[4];
   /* find minutiae on gallery, those nearest to (x0, y0) and have:
      x > x0 && y > y0  - save in minDist[0]
      x > x0 && y < y0  - save in minDist[1] 
      x < x0 && y > y0  - save in minDist[2]
      x < x0 && y < y0  - save in minDist[3]
      and check if they have a similar flow angle
   */
   int maxDist = 200, distance = 0; 
   for(int ng = 0; ng < m_numNestG; ng++)
   {
      if (abs(m_minutiaeG[ng].Movx - x0) > maxDist || abs(m_minutiaeG[ng].Movy - y0) > maxDist)
         continue;
      distance = dist (m_minutiaeG[ng].Movx, m_minutiaeG[ng].Movy, x0, y0);
      if (m_minutiaeG[ng].Movx - x0 > 0)
      {
         if (m_minutiaeG[ng].Movy - y0 > 0)
         {
            if (distance < minDist[0].dist) minDist[0].dist = distance, minDist[0].angle = m_minutiaeG[ng].Beta;
         }
         else
         {
            if (distance < minDist[1].dist) minDist[1].dist = distance, minDist[1].angle = m_minutiaeG[ng].Beta;
         }
      }
      else
      {
         if (m_minutiaeG[ng].Movy - y0 > 0)
         {
            if (distance < minDist[2].dist) minDist[2].dist = distance, minDist[2].angle = m_minutiaeG[ng].Beta;
         }
         else
         {
            if (distance < minDist[3].dist) minDist[3].dist = distance, minDist[3].angle = m_minutiaeG[ng].Beta;
         }
      }
   }
   // make dicision only if we found all 4 minutiae and flow direction in all these minutiae are similar
   for(int i = 0; i < 4; i++)           
      if (minDist[i].dist == 1024)
         return false;                                         
   int angle1 = normAngle90(minDist[0].angle - minDist[1].angle);
   int angle2 = normAngle90(minDist[2].angle - minDist[3].angle);
   int angle3 = normAngle90(minDist[0].angle - minDist[3].angle);
   int angleTol = 45;
   if (abs(angle1) > angleTol || abs(angle2) > angleTol|| abs(angle3) > angleTol)   
      return false;
   // claculate averange angle
   for(int i = 0; i < 4; i++)           
      angle += normAngle90(minDist[i].angle);
   angle = normAngle90 (angle / 4);
   return true;
}


/*
// check the flows deverging for the first group
BYTE Matcher100::findDivergingFlowsArea()
{
   // check only first group
   int num = m_curGroup->getMarker(0);
   BYTE sumSameDir = 1, sumOppositeDir = 0;
   int np = m_curGroup->getProbe (0);
   //int angle = (int)m_minutiaeP[np].Beta;
   //int angleDif = 0;
   for(int i = 1; i < num; i++)
   {
      np = m_curGroup->getProbe(i);
      //angleDif = abs(normAngle ((int)m_minutiaeP[np].Beta - angle));
      //if (angleDif > 30 && abs (angleDif - 180) > 30)
      //   continue;
      if (m_curGroup->isSameDir(i))
         sumSameDir++;
      else
         sumOppositeDir++;
   }
   return abs(sumSameDir - sumOppositeDir);
}
*/

// get flow diverging in point that correspond to not found minutiae
int Matcher100::getAreaFlowDiverging(bool isProbe, int n1)
{
   assert((isProbe && n1 < m_numNestP) || (!isProbe && n1 < m_numNestG));  
   MinutiaeShort *min      = isProbe ?  m_minutiaePR     :  m_minutiaeGR   ;  
   ESK::Sign     *minutiae = isProbe ? &m_minutiaeP[n1]  : &m_minutiaeG[n1];

   // get flow diverging for "n1"
   int flowDivDif1 = getNotFoundFlowDiverging ( isProbe, n1);
   // get closest minutiae in the point to where "n1" is projected
   int maxDist = 100;
   int n2 = getClosestMinutiae (!isProbe, min[n1].m_x, min[n1].m_y, maxDist);
   if (n2 == -1)           // no not found minutiae close to point to where "n1" is projected
      return flowDivDif1;
   // get flow diverging for "n2"
   int flowDivDif2 = getNotFoundFlowDiverging (!isProbe, n2);
   if (!flowDivDif1 || !flowDivDif2)
      return abs(flowDivDif1 - flowDivDif2);

   bool dir1 = true, dir2 = true;
   if (!getDirection(isProbe, n1, dir1) || !getDirection(!isProbe, n2, dir2))
      return 0;

   if (dir1 == dir2) return abs(flowDivDif1 - flowDivDif2);
   else              return abs(flowDivDif1 + flowDivDif2);
}

// get flow diverging for not found minutiae, taking into account only not found minutiae
int Matcher100::getNotFoundFlowDiverging(bool isProbe, int n)
{
   assert((isProbe && n < m_numNestP) || (!isProbe && n < m_numNestG));  
   ESK::Sign *minutiae    = isProbe ? &m_minutiaeP[n] : &m_minutiaeG[n];
   ESK::Link *links       = isProbe ? &m_linkP    [n] : &m_linkG    [n];
   bool      *exclude = isProbe ?  m_excludeP : m_excludeG ;
   int       *taken   = isProbe ?  m_takenP   : m_takenG   ;

   int maxLink = links->Cage;
   if (!maxLink)
      return -1;
   int n1 = 0;
   MINUTIAE_TYPE type = (MINUTIAE_TYPE)minutiae->Type;

   bool isSameDir = false;         // does minutiae has the same direction as central minutiae?
   NumSet<int> sameDir, difDir;    // numSet for links with same and different direction regarding to central point
   sameDir.init(MAX_LINK, true), difDir.init(MAX_LINK, true);
   if (!exclude[n] && !taken[n])
      sameDir.add (n); 

   for (int link = 0; link < maxLink; link++)
   {
      ESK::byte_t deal = links->Knot[link].Deal;
      if(!deal)
         continue;
      n1  = links->Knot[link].Item;   
      assert((isProbe && n1 < m_numNestP) || (!isProbe && n1 < m_numNestG));  
      if (exclude[n1] || taken[n1])
         continue;
      isSameDir = isSameDirection(deal, type, link);
     if  (isSameDir) sameDir.add (n1);
     else            difDir.add  (n1);
   }

   return abs((int)sameDir.getNumItems() - (int)difDir.getNumItems());
}

// get minutiae that closest to (x, y) point
int Matcher100::getClosestMinutiae(bool isProbe, int x, int y, int maxDist)
{
   ESK::Sign *minutiae = isProbe ? m_minutiaeP    : m_minutiaeG   ;
   int       &numNests = isProbe ? m_numNestP : m_numNestG;
   int minDist = maxDist + 1, size = 0;
   int nearestMin = -1;
   for(int n = 0; n < numNests; n++)
   {
      size = dist(minutiae[n].Movx, minutiae[n].Movy, x, y); 
      if (size > maxDist)
         continue;
      if (size < minDist) minDist = size, nearestMin = n;
   }
   return nearestMin;
}

// try to define how direction of n" correspond direction minutiae in m_curGroup
bool Matcher100::getDirection(bool isProbe, int n, bool &sameDir)
{
   assert((isProbe && n < m_numNestP) || (!isProbe && n < m_numNestG));  
   ESK::Sign     *minutiae = isProbe ? m_minutiaeP : m_minutiaeG ;
   if (getDirectionByNest (isProbe, n, sameDir))
      return true;
   int maxDist = 100;
   int pos = getClosestCurGroupMinutiae (isProbe, minutiae[n].Movx, minutiae[n].Movy, maxDist);
   if (pos == -1)
      return false;
   int n1 = isProbe ? m_curGroup->getProbe(pos) : m_curGroup->getGallery(pos);
 //  sameDir = m_curGroup->isSameDir(pos);
   int angle = abs(normAngle (minutiae[n].Beta - minutiae[n1].Beta));
   if (angle < 60) 
      return true;
   else if (abs(normAngle(angle - 180)) < 60  )
   {
      sameDir = !sameDir;
      return true;
   }

   return false;
}


// return true if find "n" among nest links
// and set sameDir to true if "n" has same direction as central point of m_curGroup
bool Matcher100::getDirectionByNest (bool isProbe, int n, bool &sameDir)
{
   sameDir = true;
   ESK::Sign     minutiae = isProbe ? m_minutiaeP[n] : m_minutiaeG[n];
   ESK::Link     link     = isProbe ? m_linkP    [n] : m_linkG    [n];
   MINUTIAE_TYPE type = (MINUTIAE_TYPE)minutiae.Type;
   int cage = link.Cage;
   int pos = 0;
   int n1 = 0;
   for (int i = 0; i < cage; i++)
   {
      ESK::byte_t deal = link.Knot[i].Deal;
      if (!deal)
         continue;
      n1 = link.Knot[i].Item;
      if (!n1)
         continue;
      if (isProbe ? (pos = m_curGroup->findProbe (n1)) == -1 : (pos = m_curGroup->findGallery(n1)) == -1)
         continue;
      sameDir = isSameDirection (deal, type, i);
   //   if (!m_curGroup->isSameDir (pos))
     //    sameDir = !sameDir;
      return true;
   }
   return false;
}

// get minutiae from m_curGroup that closest to (x, y) point
int Matcher100::getClosestCurGroupMinutiae(bool isProbe, int x, int y, size_t maxDist)
{
   ESK::Sign  *minutiae    = isProbe ? m_minutiaeP    : m_minutiaeG;
   size_t minDist = maxDist + 1, size = 0;
   int nearestMinPos = -1;
   size_t numItems = m_curGroup->getNumItems();
   int n = -1;
   for(size_t i = 0; i < numItems; i++)
   {
      n = isProbe ? m_curGroup->getProbe(i) : m_curGroup->getGallery (i); 
      size = dist(minutiae[n].Movx, minutiae[n].Movy, x, y); 
      if (size > maxDist)
         continue;
      if (size < minDist) minDist = size, nearestMinPos = (int)i;
   }
   return nearestMinPos;
}


} // namespace accelMatch{

