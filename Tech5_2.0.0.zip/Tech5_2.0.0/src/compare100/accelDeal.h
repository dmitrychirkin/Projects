#ifndef ACCEL_DEAL_G_H_
#define ACCEL_DEAL_G_H_

#include <assert.h>

#include "sse_proxy.h"
#include "minutiaePair100.h"
#include "Unwrap.h"

namespace accelMatch{

struct NestAccel
{
   m128i_my accel[2];
};

void allocNestAccel(NestAccel *&nestAccel, unsigned int n);
void freeNestAccel (NestAccel *&nestAccel);

void calcAllNestAccel (bool isProbe, NestAccel *accel, ESK::Sign *minutiae, ESK::Link *link, unsigned int numNests, MinutiaePairSet &pairSet);

int compNestAccel(NestAccel &accelP, NestAccel &accelG);



} // namespace accelMatch{

#endif  // ACCEL_DEAL_G_H_



