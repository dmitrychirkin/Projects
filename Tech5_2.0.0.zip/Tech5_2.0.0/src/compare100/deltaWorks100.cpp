/*
   deltaWorks.cpp - implement the functions for work with delta

   Copyright (C) 2008 Sonda Technologies Ltd.
   Author A.Mosunov
   18.06.2008
*/

#include <assert.h>

#include "matcher100.h"
#include "mathem100.h"
#include "Eskuse.h"
#include "win2lin.h"


#define MAX_DELTA_DIST      120            // maximum distance from delta, when point can belong to delta area
#define MIN_DELTA_DIST       40            // maximum distance from delta, when point certainly belong to delta area

namespace accelMatch{
#pragma pack(push,_CORE_PACKING)


bool isMinutiaeNearDelta (ESK::Sign *delta, ESK::Sign *minutiae)
{
   int maxDist = MAX_DELTA_DIST;
   int minDist = MIN_DELTA_DIST;
   int len = dist ((int)delta->Movx - (int)minutiae->Movx, (int)delta->Movy - (int)minutiae->Movy);
   if (len > maxDist) 
      return false;
   if (len < minDist)
      return true;
   // does minutiae look to delta?
   int angle = atan ((int)delta->Movx - (int)minutiae->Movx, (int)delta->Movy - (int)minutiae->Movy);
   int dAngle = abs(normAngle((int)minutiae->Beta - angle));
   if (dAngle > 30)
      return false;;
   // does minutiae looks to same direction as delta rays?
   dAngle = normAngle((int)minutiae->Beta - (int)delta->Beta * 2);
   if (abs(dAngle - 180) < 30)
      return true;
   if (abs(dAngle - 60) < 30)
      return true;
   if (abs(dAngle + 60) < 30)
      return true;
   return false;
}

bool Matcher100::getNumMinutiaeAroundDelta (bool isProbe, BYTE numMinNearDelta[3], BYTE numDelta, ESK::Sign *delta[3])
{
   ESK::Sign *minutiae = isProbe ? m_minutiaeP : m_minutiaeG;
   int maxNum = 0;
   NumSet<int> deltaMin;
   size_t allGroupSize   = m_curGroup->getNumItems();
   size_t mainGroupSize  = m_curGroup->getMainGroupSize();
   size_t firstGroupSize = m_curGroup->getFirstGroupSize();//getMarker(0);
   int n = 0, count = 0;
   BYTE num[3];
   int minNumbers[3][MAX_MINUTIAE];

   for(BYTE i = 0; i < numDelta; i++)
   {
      memset (num, 0, sizeof(num[0]) * 3);
      memset (minNumbers, 0, sizeof(minNumbers));
      for(size_t j = 0; j < allGroupSize; j++)
      {
         n = isProbe ? m_curGroup->getProbe(j) : m_curGroup->getGallery(j);
         if (!isMinutiaeNearDelta (delta[i], &minutiae[n]))
            continue;
         if      (j < firstGroupSize) minNumbers[0][num[0]] = n, num[0]++;
         else if (j < mainGroupSize)  minNumbers[1][num[1]] = n, num[1]++;
         else                         minNumbers[2][num[2]] = n, num[2]++;
         count++;
      }
      if (count > maxNum)
      {
         maxNum = count;
         memcpy(numMinNearDelta, num, sizeof(numMinNearDelta[0]) * 3);
      }
   }

   return (maxNum > 0);
}

int getNumDelta(int numSingular, ESK::Sign *singular)
{
   int count = 0;
   for(int i = 0; i < numSingular; i++)
   {
      if (singular[i].Type == ESK::FD)
         count++;
   }
   return count;
}



#pragma pack(pop)
} // namespace accelMatch{

