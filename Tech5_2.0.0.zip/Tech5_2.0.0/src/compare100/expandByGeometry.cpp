#include "matcher100.h"

namespace accelMatch{


// calculate similarity index for current minutiae group
bool Matcher100::expandCurGroupByGeometry(bool quickAccelMatch)
{
   // combine fingerprints
   int angle = combineFingerprintsByCurGroup(m_curGroup, true, true, true);
   // if rotation angle more than tolerance - it's impostor group
   if (abs(normAngle(angle + m_rotation)) > m_maxAngle)
      return false;
   // find minutiae thouse with hight probability behind of clear area of another fingerprint 
   findExclude();
   BYTE numExcludedP = countExcluded(m_numNestP, m_excludeP);
   BYTE numExcludedG = countExcluded(m_numNestG, m_excludeG);
   BYTE numFound = (BYTE)m_curGroup->getNumItems();
   BYTE numNotFound = minAB(m_numNestP - numFound - numExcludedP, m_numNestG - numFound- numExcludedG);
   if (numNotFound > numFound * 8)
      return false;
   findStrongExclude();
  
   // add into current group the minutiae, thouse locate the similar
   if(expandCurGroup(quickAccelMatch))
      ;//combineFingerprintsByCurGroup(m_curGroup, true, false, false);
   return true;
}

size_t Matcher100::expandCurGroup(bool quickAccelMatch)
{
   // fill m_takenP and m_takenG arrays
   memset (m_takenP, 0, sizeof(m_takenP[0]) * m_numNestP);
   memset (m_takenG, 0, sizeof(m_takenG[0]) * m_numNestG);
   short np = 0, ng = 0;
   size_t startNum = m_curGroup->getNumItems();
   for(size_t i = 0; i < startNum; i++)
   {
      m_curGroup->getPair(i, np, ng);
      m_takenP[np] = 1;
      m_takenG[ng] = 1;
   }
   if (quickAccelMatch)
      return 0;
   findAllCompatiblePairs();
   size_t numExpandGroups = buildExpandGroups();
   if (!numExpandGroups) 
      return 0;
   if (m_p_expandGroups[0]->getNumItems() <= 1 && m_p_expandGroups[0]->getConflictPos() != -1)
      return 0;

   Transition transition    =   NT;
   //short      transitionDif =    0;
   short      conflictPos   =   -1;   
   for(size_t i = 0; i < m_p_expandGroups[0]->getNumItems(); i++)
   {
      m_p_expandGroups[0]->getPair(i, np, ng);
      conflictPos = m_p_expandGroups[0]->getConflictPos();
      if (conflictPos != -1)
      {
         m_takenP[m_curGroup->getProbe  (conflictPos)] = 0;
         m_takenG[m_curGroup->getGallery(conflictPos)] = 0;
         m_curGroup->remove (conflictPos);
         //m_curGroup->compress();
      }
      transition    = m_p_expandGroups[0]->getTransition    (i);
      //transitionDif = m_p_expandGroups[0]->getTransitionDif (i);
      m_curGroup->add (np, ng, transition);//, transitionDif);
      calcScaleForNewPair (m_curGroup, m_curGroup->getNumItems() - 1);
      m_takenP[np] = 1;
      m_takenG[ng] = 1;
   }

   bool useScale   = true;
   int  scaleX     = 0, scaleY = 0;
   //calcScale(m_curGroup);
   size_t startCheckPos = m_curGroup->getMainGroupSize();
   int *err = NULL;
   size_t maxAcceptableError = 0;
   NumSet <size_t> errorPos, skipPos;
   errorPos.init (1, true);
   skipPos.init  (1, true);
   for(size_t i = 1; i < numExpandGroups; i++)
   {
      for(size_t j = 0; j < m_p_expandGroups[i]->getNumItems(); j++)
      {
         m_p_expandGroups[i]->getPair(j, np, ng);
         if (m_curGroup->findProbe (np) != -1 || m_curGroup->findGallery (ng) != -1)
            continue;
         getAreaScaleP(m_curGroup, np, scaleX, scaleY);
         errorPos.clear();
         if (!m_curGroup->isCompatible(np, ng, m_errorLevel, errorPos, maxAcceptableError, err, skipPos, useScale, scaleX, scaleY, startCheckPos))
            continue;
         if (!checkQuadrants(m_curGroup, np, ng, transition, skipPos, startCheckPos, errorPos, maxAcceptableError))
            continue;
         transition    = m_p_expandGroups[i]->getTransition    (j);
         //transitionDif = m_p_expandGroups[i]->getTransitionDif (j);
         m_curGroup->add (np, ng, transition);//, transitionDif);
         calcScaleForNewPair (m_curGroup, m_curGroup->getNumItems() - 1);
         m_takenP[np] = 1;
         m_takenG[ng] = 1;
      }
   }
   return m_curGroup->getNumItems() - startNum;
}


BYTE Matcher100::countExcluded (int num, bool *exclude)
{
   BYTE count = 0;
   for (int i = 0; i < num; i++)
      if (exclude[i])
         count++;
   return count;
}

// find minutiae thouse behind of clear area of another fingerprint with hight probability
void Matcher100::findStrongExclude()
{
   for (size_t i = 0; i < m_numNestP; i++)
      m_strongExcludeP[i] = false;
   for (size_t i = 0; i < m_numNestG; i++)
      m_strongExcludeG[i] = false;

   int reach = 3;
   int tol = 1; 
   checkBadArea(m_minutiaePR, m_numNestP, m_areaG, m_areaWidthG, m_areaHeightG, 
                     reach, tol, m_strongExcludeP);
   checkBadArea(m_minutiaeGR, m_numNestG, m_areaP, m_areaWidthP, m_areaHeightP, 
                     reach, tol, m_strongExcludeG);
   // remove found minutiae from exclude arrays 
   size_t num = m_curGroup->getNumItems();
   short np = 0, ng = 0;
   for (size_t i = 0; i < num; i++)
   {
      m_curGroup->getPair(i, np, ng);
      m_strongExcludeP[np] = false;
      m_strongExcludeG[ng] = false;
   }
}
// find minutiaes thouse can be behind of clear area of another fingerprint
void Matcher100::findExclude()
{
   for (size_t i = 0; i < m_numNestP; i++)
      m_excludeP[i] = false;
   for (size_t i = 0; i < m_numNestG; i++)
      m_excludeG[i] = false;

   int reachP = (m_typeP == LATENT) ? 2: 2;
   int reachG = (m_typeG == LATENT) ? 2: 2;
   int tolP = (2 * reachP + 1) * (2 * reachP + 1) * 5 / 6; 
   int tolG = (2 * reachG + 1) * (2 * reachG + 1) * 5 / 6; 
   checkBadArea(m_minutiaePR, m_numNestP, m_areaG, m_areaWidthG, m_areaHeightG, reachP, tolP, m_excludeP);
   checkBadArea(m_minutiaeGR, m_numNestG, m_areaP, m_areaWidthP, m_areaHeightP, reachG, tolG, m_excludeG);

   // add to exclude minutiae with low probability
   //for(int np = 0; np < m_numNestP; np++)
   //{
   //   if (m_probP[np] < 4)
   //      m_excludeP[np] = true;
   //}
   //for(int ng = 0; ng < m_numNestG; ng++)
   //{
   //   if (m_probG[ng] < 4)
   //      m_excludeG[ng] = true;
   //}

   // remove found minutiae from exclude arrays 
   size_t num = m_curGroup->getNumItems();
   short np = 0, ng = 0;
   for (size_t i = 0; i < num; i++)
   {
      m_curGroup->getPair(i, np, ng);
      m_excludeP[np] = false;
      m_excludeG[ng] = false;
   }
}


} // namespace accelMatch{
