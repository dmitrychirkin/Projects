#include "matcher100.h"

namespace accelMatch{

void Matcher100::calcScale(GroupEx *g)
{
   if (!g || !g->getNumItems())
      return;
   combineFingerprintsByCurGroup(g, false, true, false);
   g->calcScale(m_minutiaeGR);
   g->clearChangesCount();
}

void Matcher100::calcScaleForNewPair(GroupEx *g, size_t pos)
{
   assert (g && pos < g->getNumItems());
   // calculate m_minutiaeGR for the new point
   short np = 0, ng = 0;
   g->getPair(pos, np, ng);
   int xcP = 0, ycP = 0, xcG = 0, ycG = 0, angle = 0;
   g->getRotation(xcP, ycP, xcG, ycG, angle, false);
   int scaleXc = 0, scaleYc = 0;
   getAreaScale (g, xcG, ycG, scaleXc, scaleYc, false);
   transferPoint ((int)m_minutiaeG[ng].Movx, (int)m_minutiaeG[ng].Movy, (int)m_minutiaeG[ng].Beta, 
                  m_minutiaeGR[ng].m_x, m_minutiaeGR[ng].m_y, m_minutiaeGR[ng].m_angle, 
                  xcG, ycG, xcP, ycP, angle, g->getScaleX(pos), g->getScaleY(pos), scaleXc, scaleYc, false);
   // calc scale for this point
   g->calcScaleForNewPair (m_minutiaeGR, pos);
}

// return scale in area around minutiae  with coordinates (x0, y0)
void Matcher100::getAreaScale(GroupEx *curGroup, int x0, int y0, int &averScaleX, int &averScaleY, bool isProbe)
{
   assert(curGroup);
   size_t num = curGroup->getNumItems();
   short     np            = 0, ng           = 0;
   int       len_x         = 0, len_y        = 0;
   int       scaleX        = 0, scaleY       = 0;
   long long sumScaleX     = 0, sumScaleY    = 0; 
   int       weight_x      = 0, weight_y     = 0;
   int       sumWeight_x   = 0, sumWeight_y  = 0;
   for(size_t i = 0; i < num; i++)
   {
      if (isProbe)
      {
         np = curGroup->getProbe(i);
         len_x = abs(m_minutiaeP[np].Movx - x0);
         len_y = abs(m_minutiaeP[np].Movy - y0);
      }
      else
      {
         ng = curGroup->getGallery (i);
         len_x = abs(m_minutiaeG[ng].Movx - x0);
         len_y = abs(m_minutiaeG[ng].Movy - y0);
      }
      scaleX = curGroup->getScaleX (i);
      if (len_x > CALC_SCALE_MIN_DIST && scaleX)
      {
         weight_x     = len_x <= CALC_SCALE_MAX_DIST ? 256 : CALC_SCALE_MAX_DIST * 256 / len_x;  
         sumScaleX   += scaleX * weight_x;
         sumWeight_x += weight_x;
      }
      scaleY = curGroup->getScaleY (i);
      if (len_y > CALC_SCALE_MIN_DIST && scaleY)
      {
         weight_y     = len_y <= CALC_SCALE_MAX_DIST ? 256 : CALC_SCALE_MAX_DIST * 256 / len_y;  
         sumScaleY   += scaleY * weight_y;
         sumWeight_y += weight_y;
      }
   }
   averScaleX = sumWeight_x ? (int)(sumScaleX  / sumWeight_x) : 256;
   averScaleY = sumWeight_y ? (int)(sumScaleY  / sumWeight_y) : 256;
}


} // namespace accelMatch{
