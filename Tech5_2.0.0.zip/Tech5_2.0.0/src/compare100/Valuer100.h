//////////////////////////////////////////////////////////////////////////
//  Valuer holds pre-calculated similarity values for every characteristics 
//   used to compare two fingerprints
//
//////////////////////////////////////////////////////////////////////////

#ifndef VALUER_H
#define VALUER_H

namespace Comparator {
#pragma pack(push, 8)

class Valuer
{
private:
   static float _MinimumIndexThreshold;
   static float _MaximumIndexThreshold;
   
   static float _AngleMinT;
   static float _AngleMaxT;

   static float _DistMinT;
   static float _DistMaxT;

   static float _DistanceValueTab[];

   static float _DeltasAngleValueTab[];

   static float _LoopsAngleValueTab[];

   static float _DistToBadValueTab[];
/*
   static float _ConcludeValueTab[];
public:
   static float GetConclusion        ( float distValue, float angleValue );
*/
public:
   static void  SetIndexThresholds   ( float _minThreshold, float _maxThreshold );
//////////////////////////////////////////////////////////////////////////
   static void  SetDistanceThresholds( float _minT, float _maxT );
//////////////////////////////////////////////////////////////////////////
   static void  SetAngleThresholds   ( float _minT, float _maxT );
//////////////////////////////////////////////////////////////////////////
   static float GetValueFromDistance ( int distance  );
//////////////////////////////////////////////////////////////////////////
   static float GetValueFromAngle    ( int type, int angle );
//////////////////////////////////////////////////////////////////////////
   static float GetValueFromDistToBad( int distToBad );
//////////////////////////////////////////////////////////////////////////
   static float getReliableValue     ( float val, float _minThreshold = -1, float _maxThreshold = -1 );
//////////////////////////////////////////////////////////////////////////
   static float GetFoundIndexCorrection( int distToBad );
};
#pragma pack(pop)
}

#endif // VALUER_H
