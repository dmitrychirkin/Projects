/*
   group.h - declare the Group class that keep information 
                    about minutiae group

   Copyright (C) 2006 Sonda Technologies Ltd.
   Author A.Mosunov
   22.05.2006
*/
#ifndef  GROUP_100_H_
#define  GROUP_100_H_

#define _USE_MATH_DEFINES
#include <math.h>
#include <assert.h>
using namespace std;

#include "Unwrap.h"
#include "coreSdk.h"
#include "core_err.h"
#include "staticData100.h"   
#include "mathem100.h"
#include "minutiaePair100.h"
#include "win2lin.h"
#include "MyException.h"


namespace accelMatch{
#pragma pack(push,_CORE_PACKING)

#define MAX_GROUP_MINUTIAE       128
// default parameters
#define DEF_MINUTIAE_ANGLE_TOL   25   
#define DEF_GROUP_ANGLE_TOL      25       // default tolerance for angle between direction from center group to minutiae and OX
#define DENSITY_DEF              11       // default distance between two ridges  
#define MAX_LINK                 35
#define MAX_LINK_GROUP_SIZE      8
#define DIST_TOL_SIZE            512     // size of ddist tolerance table
#define MAX_ERROR_LEVEL          6//2
#define CALC_SCALE_MIN_DIST    40//20
#define CALC_SCALE_MAX_DIST    100//50
#define MAX_ERROR_POS            2  

bool checkMinAngles(int angle1, int angle2, int groupAngle, bool nearSingularP, bool nearSingularG, 
                     int dAngle, int dAngle1, short *err = NULL);
bool checkMinAngles(int angle1, int angle2, int groupAngle, int dAngle, short *err);

extern int s_distTolTab[MAX_ERROR_LEVEL][DIST_TOL_SIZE];

static inline int getDistTol (int dist, int errorLevel)
{
   assert(errorLevel < MAX_ERROR_LEVEL);
   if (dist < DIST_TOL_SIZE)
      return s_distTolTab[errorLevel][dist];
   return s_distTolTab[errorLevel][DIST_TOL_SIZE - 1];
}


struct MinutiaeShort
{
   int m_x;
   int m_y;
   int m_angle;
};



#pragma pack (push, 4)
template<class T>
class NumSet
{
   size_t       m_numItems;     
   size_t       m_maxSize; 
   bool         m_manageMemory;
public:
   T          *m_n;
   NumSet() 
   { 
      memset(this, 0, sizeof(*this));
   }
   void init(size_t size, bool allocMemory) 
   { 
      m_manageMemory = false;
      m_maxSize   = size;
      m_numItems  = 0; 
      m_n         = NULL;
      if (allocMemory)
         alloc();
   }
   void alloc()
   {
      if (!m_maxSize)
         return;
      m_manageMemory = true;
      if (m_n)
         release();
      m_n = new(std::nothrow) T[m_maxSize];
      if (!m_n)
         throw MA_LOW_MEMORY;
      memset (m_n, 0, sizeof(m_n[0]) * m_maxSize);
   }
   ~NumSet() 
   {
      release();
   }
   void release()
   {
      if (m_manageMemory && m_n) 
         delete [] m_n;
      m_n = NULL;
   }
   size_t getNumItems() const { return m_numItems;}
   size_t getMaxSize()  const { return m_maxSize; }
   void clear()
   {
      m_numItems = 0; 
   }
   T& getItem (size_t i) const 
   {
      return m_n[i];
   }
   bool add (T n)
   {
      if (find(n) != -1)
         return false;
      return addWoCheck(n);
   }
   bool addWoCheck (T &n)
   {
      if (m_numItems >= m_maxSize)
         return false;
      if (!m_n)
         alloc();
      m_n [m_numItems++] = n;
      return true;
   }

//   operator int() { return m_numItems; }

   void add (const NumSet& v)
   {
      *this += v;
   }
   NumSet (const NumSet& v)
   {
      *this = v;
   }

   NumSet& operator= (const NumSet& v)
   {
      clear();
      *this += v;
      return *this;
   }
   NumSet& operator+= (const NumSet& v)
   {
      if (!m_n)
         init(v.getMaxSize(), true);
      size_t num = v.getNumItems();
      if (m_maxSize < m_numItems + num)
         num = m_maxSize - m_numItems;
      T n;
      for(size_t i = 0; i < num; i++)
      {
         n = v.getItem(i);
         if (n != -1)
            add(n);
      }
      return *this;
   }
   int find (T &n)
   {
      if (n == -1)
         return -1;
      for(size_t i = 0; i < m_numItems; i++)
      {
         if (m_n[i] == n)
            return (int)i;
      }
      return -1;
   }
   bool replace (size_t n, T val)
   {
      if (n >= m_numItems)
         return false;
      m_n[n] = val;
      return true;
   }
   void remove (size_t n)
   {
      size_t num = m_numItems;
      m_numItems = 0;
      for(size_t i = 0; i < num; i++)
      {
         if (i == n)
            continue;
         m_n[m_numItems++] = m_n[i];
      }
   }
   void remove (size_t *n, size_t num)
   {
      size_t numItems = m_numItems;
      m_numItems = 0;
      for(size_t i = 0; i < numItems; i++)
      {
         bool found = false;
         for (size_t j = 0; j < num; j++)
            if (i == n[j])
            {
               found = true;
               break;
            }
         if (!found)
            m_n[m_numItems++] = m_n[i];
      }
   }
   void remove (NumSet<size_t> &n)
   {
      size_t numItems = m_numItems;
      m_numItems = 0;
      for(size_t i = 0; i < numItems; i++)
      {
         bool found = false;
         for (size_t j = 0; j < n.getNumItems(); j++)
            if (i == n.getItem(j))
            {
               found = true;
               break;
            }
         if (!found)
            m_n[m_numItems++] = m_n[i];
      }
   }
};
#pragma pack(pop)

struct Pair
{
   short m_np;
   short m_ng;
   Pair()
   {
      m_np = -1;
      m_ng = -1;
   }
   Pair(int np, int ng)
   {
      m_np = np;
      m_ng = ng;
   }
   bool operator== (const Pair &pair) 
   {
      return (m_np == pair.m_np && m_ng == pair.m_ng);
   }
   bool operator!= (const Pair &pair) 
   {
      return (m_np != pair.m_np || m_ng != pair.m_ng);
   }
   operator int()
   {
      return m_np;
   }
};
struct Link : public Pair
{
   Transition  m_transition;
   short         m_errR;             // distance error
   short         m_errA;             // angle error
   short         m_errA1;            // angle1 error
//   BYTE          m_sameDir;    

   Link() : Pair(-1, -1)
   {
      m_transition = UNKN;
      m_errR = m_errA = m_errA1 = -1;
      //m_sameDir = -1; 
   }
   Link(short np, short ng, Transition transition, bool sameDir, short errR, short errA, short errA1)
      : Pair(np, ng)
   {
      m_transition = transition;
      m_errR  = errR;
      m_errA  = errA;
      m_errA1 = errA1;
      //m_sameDir = sameDir ? 1 : 0; 
   }
   Link& operator=(const Link& link)
   {
      m_np           = link.m_np        ;
      m_ng           = link.m_ng        ;
      m_transition   = link.m_transition;
      m_errR         = link.m_errR      ;
      m_errA         = link.m_errA      ;
      m_errA1        = link.m_errA1     ;
      //m_sameDir      = link.m_sameDir; 
      return *this;
   }
};

class HitGroup 
{
   Transition   m_mainTransition;
   WORD         m_sim;   
   Link        *m_link;   
   BYTE         m_numItems;
   BYTE         m_maxItems; 

   void release()
   {
      if (m_link) delete [] m_link, m_link = NULL;
   }
   void alloc(int maxItems)
   {
      release();
      m_maxItems = maxItems;
      if (!m_maxItems)
         return;
      m_link = new (std::nothrow) Link[m_maxItems];
      if (!m_link)
         throw MyException(MA_LOW_MEMORY);
   }

public:
   HitGroup()                     
   {
      memset (this, 0, sizeof(HitGroup));
   }
   void init(BYTE maxItems)                     
   {
      m_mainTransition = UNKN;
      alloc(maxItems);
   }
   HitGroup (const HitGroup &hitGroup)
   {
      *this = hitGroup;
   }
   HitGroup& operator= (const HitGroup& hitGroup)
   {
      if (this->m_maxItems < hitGroup.getNumItems())
         alloc(hitGroup.getNumItems());
      m_numItems       = hitGroup.getNumItems();
      m_sim            = hitGroup.getSim();   
      m_mainTransition = hitGroup.getMainTransition();
      for(int i = 0; i < m_numItems; i++)
         m_link[i] = hitGroup.m_link[i];
      return *this;
   }
   ~HitGroup()
   {
      release();
   }
   void clear()
   {
      m_numItems = 0;
      m_sim = 0;
   }
   BYTE getNumItems()  const
   {
      return m_numItems;
   }
   Link* getItem(BYTE n) 
   {
      return &m_link[n];
   }
   int getProbe (BYTE pos) const
   {
      return m_link[pos].m_np;
   }
   int getGallery (BYTE pos) const
   {
      return m_link[pos].m_ng;
   }
   bool getPair (BYTE pos, short &np, short &ng) const
   {
      np = getProbe  (pos);
      ng = getGallery(pos);
      return (np != -1);
   }
   int find (short np, short ng, int start = 0)  const
   {
      int pos = findProbe(np, start);
      if (pos == -1)
         return -1;
      if (getGallery(pos) == ng)
         return pos;
      else
         return -1;
   }
   int findProbe (short np, int start = 0)  const
   {
      if (np == -1)
         return -1;
      for(short i = start; i < m_numItems; i++)
      {
         if (m_link[i].m_np == np)
            return i;
      }
      return -1;
   }

   int findGallery (short ng, int start = 0)  const
   {
      if (ng == -1)
         return -1;
      for(short i = start; i < m_numItems; i++)
      {
         if (m_link[i].m_ng == ng)
            return i;
      }
      return -1;
   }
   void add (short np, short ng, Transition transition, short errR, short errA, short errA1)//, bool sameDir)
   {
      assert(transition >= NT && transition <= MPT); 
      assert(m_numItems <  m_maxItems);
      if (findProbe(np) != -1 || findGallery(ng) != -1)
         return;
      m_link[m_numItems].m_np          = np        ;
      m_link[m_numItems].m_ng          = ng        ;
      m_link[m_numItems].m_transition  = transition;
      m_link[m_numItems].m_errR        = errR      ;
      m_link[m_numItems].m_errA        = errA      ;
      m_link[m_numItems].m_errA1       = errA1     ;
//      m_link[m_numItems].m_sameDir     = sameDir ? 1 : 0;
      m_numItems++;
   }
   void add (const Link &link)
   {
      add(link.m_np, link.m_ng, link.m_transition, link.m_errR, link.m_errA, link.m_errA1);
   }
   void remove (int n)
   {
      int num = m_numItems;
      m_numItems = 0;
      for(int i = 0; i < num; i++)
      {
         if (i == n)
            continue;
         m_link[m_numItems++] = m_link[i];
      }
   }
   void replace (int replacePos, short np, short ng, Transition transition, short errR, short errA, short errA1)
   {
      assert(transition <= MPT);
      assert(replacePos < m_numItems);
      m_link[replacePos].m_np          = np        ;
      m_link[replacePos].m_ng          = ng        ;
      m_link[replacePos].m_transition  = transition;
      m_link[replacePos].m_errR        = errR      ;
      m_link[replacePos].m_errA        = errA      ;
      m_link[replacePos].m_errA1       = errA1     ;
//      m_link[replacePos].m_sameDir     = sameDir ? 1 : 0;
   }

   short getErrR(int n) const
   {
      return m_link[n].m_errR;
   }
   short getErrA(int n) const
   {
      return m_link[n].m_errA;
   }
   short getErrA1(int n) const
   {
      return m_link[n].m_errA1;
   }
   Transition getTransition(int n) const
   {
      return m_link[n].m_transition;
   }
   Transition getMainTransition() const
   {
      return m_mainTransition;
   }
   void setMainTransition(Transition transition) 
   {
      m_mainTransition = transition;
   }
   void setSim(WORD sim) 
   {
      m_sim = sim;
   }
   WORD getSim() const
   {
      return m_sim;
   }
 //  bool isSameDir(int n) const
  // {
 //     return (m_link[n].m_sameDir == 1);
  // }
};
struct PairEx: public Pair
{
   Transition  m_transition;

   PairEx() : Pair(-1, -1)
   {
      m_transition = UNKN;
   }
   PairEx(int np, int ng, Transition transition)
      : Pair(np, ng)
   {
      m_transition = transition;
   }
   PairEx& operator=(const PairEx& pairEx)
   {
      m_np           = pairEx.m_np;
      m_ng           = pairEx.m_ng;
      m_transition   = pairEx.m_transition;
      return *this;
   }
};

struct PairEx2: public PairEx
{
   short   m_scaleX       ;
   short   m_scaleY       ;
   //short   m_transitionDif;
   //WORD    m_sim          ;  
   //short   m_err          ;

   PairEx2() : PairEx()
   {
      m_scaleX           =  0;
      m_scaleY           =  0;
      //m_transitionDif    =  0;
      //m_sim              =  0;
      //m_err              =  0;
   }
   PairEx2(short np, short ng, Transition transition)//, short transitionDif)//, WORD sim, short err)
      : PairEx(np, ng, transition)
   {
      m_scaleX  = 0                  ;
      m_scaleY  = 0                  ;
      //m_transitionDif = transitionDif;
      //m_sim           = sim          ; 
      //m_err           = err          ;

   }
   PairEx2& operator=(const PairEx2& pairEx)
   {
      m_np               = pairEx.m_np           ;
      m_ng               = pairEx.m_ng           ;
      m_transition       = pairEx.m_transition   ;
      m_scaleX           = pairEx.m_scaleX       ;
      m_scaleY           = pairEx.m_scaleY       ;
      //m_transitionDif    = pairEx.m_transitionDif;
      //m_sim              = pairEx.m_sim          ;
      //m_err              = pairEx.m_err          ; 
      return *this;
   }
};

class PairGroup 
{
   Pair     m_pair[MAX_MINUTIAE]; 
   short    m_numItems;

public:
   void clear()
   {
      m_numItems = 0;
   }
   PairGroup()                     
   {
      clear();
   }
   PairGroup (const PairGroup &g)
   {
      *this = g;
   }
   short getNumItems()  const
   {
      return m_numItems;
   }
   short getProbe (short pos) const
   {
      return m_pair[pos].m_np;
   }
   short getGallery (short pos) const
   {
      return m_pair[pos].m_ng;
   }
   bool getPair (int pos, short &np, short &ng) const
   {
      np = getProbe(pos);
      ng = getGallery(pos);
      return (np != -1);
   }
   int find (short np, short ng, int start = 0)  const
   {
      int pos = findProbe(np, start);
      if (pos == -1)
         return -1;
      if (getGallery(pos) == ng)
         return pos;
      else
         return -1;
   }
   int findProbe (short np, short start = 0)  const
   {
      if (np == -1)
         return -1;
      for(short i = start; i < m_numItems; i++)
      {
         if (m_pair[i].m_np == np)
            return i;
      }
      return -1;
   }

   int findGallery (short ng, short start = 0)  const
   {
      if (ng == -1)
         return -1;
      for(short i = start; i < m_numItems; i++)
      {
         if (m_pair[i].m_ng == ng)
            return i;
      }
      return -1;
   }
   bool canAdd (short np, short ng)
   {
      return (findProbe(np) == -1 && findGallery(ng) == -1);
   }
   void add (short np, short ng)
   {
      if (canAdd(np, ng))
         addWoCheck (np, ng);
   }
   void addWoCheck (short np, short ng)
   {
      if (m_numItems >= MAX_MINUTIAE)
         return;
      m_pair[m_numItems].m_np          = np;
      m_pair[m_numItems].m_ng          = ng;
      m_numItems++;
   }
   void add (const Pair &pair)
   {
      add(pair.m_np, pair.m_ng);
   }
   PairGroup& operator= (const PairGroup& v)
   {
      clear();
      *this += v;
      return *this;
   }
   PairGroup& operator+= (const PairGroup& v)
   {
      int num = v.getNumItems(); 
      for(int i = 0; i < num; i++)
         add(v.m_pair[i]);

      return *this;
   }
};


class PairGroupEx 
{
   PairEx     m_pair[MAX_MINUTIAE]; 
   short      m_numItems;

public:
   void clear()
   {
      m_numItems = 0;
   }
   PairGroupEx()                     
   {
      clear();
   }
   PairGroupEx (const PairGroupEx &g)
   {
      *this = g;
   }
   short getNumItems()  const
   {
      return m_numItems;
   }
   short getProbe (short pos) const
   {
      return m_pair[pos].m_np;
   }
   short getGallery (short pos) const
   {
      return m_pair[pos].m_ng;
   }
   Transition getTransition(int n) const
   {
      return m_pair[n].m_transition;
   }
   bool getPair (int pos, short &np, short &ng) const
   {
      np = getProbe(pos);
      ng = getGallery(pos);
      return (np != -1);
   }
   int find (short np, short ng, int start = 0)  const
   {
      int pos = findProbe(np, start);
      if (pos == -1)
         return -1;
      if (getGallery(pos) == ng)
         return pos;
      else
         return -1;
   }
   int findProbe (short np, short start = 0)  const
   {
      if (np == -1)
         return -1;
      for(short i = start; i < m_numItems; i++)
      {
         if (m_pair[i].m_np == np)
            return i;
      }
      return -1;
   }

   int findGallery (short ng, short start = 0)  const
   {
      if (ng == -1)
         return -1;
      for(short i = start; i < m_numItems; i++)
      {
         if (m_pair[i].m_ng == ng)
            return i;
      }
      return -1;
   }
   bool canAdd (short np, short ng)
   {
      return (findProbe(np) == -1 && findGallery(ng) == -1);
   }
   void add (short np, short ng, Transition transition)
   {
      if (canAdd(np, ng))
         addWoCheck (np, ng, transition);
   }
   void addWoCheck (short np, short ng, Transition transition)
   {
      assert(transition >= NT && transition <= MPT); 
      if (m_numItems >= MAX_MINUTIAE)
         return;
      m_pair[m_numItems].m_np          = np;
      m_pair[m_numItems].m_ng          = ng;
      m_pair[m_numItems].m_transition  = transition;
      m_numItems++;
   }
   void add (const PairEx &pair)
   {
      add(pair.m_np, pair.m_ng, pair.m_transition);
   }
   void remove (int n)
   {
      int num = m_numItems;
      m_numItems = 0;
      for(int i = 0; i < num; i++)
      {
         if (i == n)
            continue;
         m_pair[m_numItems++] = m_pair[i];
      }
   }
   void replace (int n, short np, short ng, Transition transition)
   {
      assert(n < m_numItems);
      m_pair[n].m_np          = np;
      m_pair[n].m_ng          = ng;
      m_pair[n].m_transition  = transition;
   }
   PairGroupEx& operator= (const PairGroupEx& v)
   {
      clear();
      *this += v;
      return *this;
   }
   PairGroupEx& operator+= (const PairGroupEx& v)
   {
      int num = v.getNumItems(); 
      for(int i = 0; i < num; i++)
         add(v.m_pair[i]);

      return *this;
   }
   //void compress ()
   //{
   //   int num = m_numItems;
   //   clear();
   //   for(int i = 0; i < num; i++)
   //   {
   //      if (m_pair[i].m_np != -1)
   //         add(m_pair[i]);
   //   }
   //}
   int getRealSize()
   {
      int num = m_numItems;
      int realSize = 0;
      for(int i = 0; i < num; i++)
      {
         if (m_pair[i].m_np != -1)
            realSize++;
      }
      return realSize;
   }
};


class GroupEx 
{
   NumSet<PairEx2>   m_pair; 
   int               m_angle;       // rotation angle for combine probe and gallery 
                                    // minutiae of the group
   int               m_around180;   // true, if m_angle is around 180 degree
      
   int               m_dr;                // distance between two ridge 
   int               m_dMinAngle;         // minutiae angle tolerance
   int               m_dMinAngle1;        // minutiae angle tolerance for minutiae those close to singular
   int               m_dAngle;            // tolerance for angle between direction from center group to minutiae and OX
   size_t            m_numAdded;          // number of pairs added while last operation(s)
   size_t            m_numChanged;        // number of pairs changed while last operation(s)
   int               m_xcP;
   int               m_ycP;
   int               m_xcG;
   int               m_ycG;
   size_t            m_firstGroupSize;
   size_t            m_mainGroupSize;
   // pointers to Matcher (probe and gallery) data
   ESK::Sign       *m_signP;          // probe minutiae  
   ESK::Sign       *m_signG;          // gallery minutiae
   MinutiaePairSet *m_pairSetP;   // probe minutiae pairs
   MinutiaePairSet *m_pairSetG; // gallery minutiae pairs
   bool            *m_nearSingularP;  // true if coresponded probe minutiae is located near singular
   bool            *m_nearSingularG;  // true if coresponded gallery minutiae is located near singular
   // distance tolerance table
   int             m_errorLevel;
   int             m_conflictPos;
   //WORD            m_conflictSim;
   //int             m_numParentsItem;


public:
   GroupEx() 
   { 
      memset(this, 0, sizeof(*this));
      m_dr            = DENSITY_DEF;
//      m_curDistTolTab = NULL;
      clear();
   }
   void init(int size, bool alloc) 
   { 
      m_pair.init(size, alloc);
   }
   void clear()
   {
      m_pair.clear();
      m_angle = 0;
      m_around180 = false;
      m_numAdded = 0;
      m_numChanged = 0;
      m_xcP = m_ycP = 0;
      m_xcG = m_ycG = 0;
      m_mainGroupSize = 0;
      m_firstGroupSize = 0;
      m_conflictPos    = -1;
      //m_conflictSim    = 0;
      //m_numParentsItem = 0;
   }
   NumSet<PairEx2>* getPair() 
   {
      return &m_pair;
   }
   size_t getNumItems()
   {
      return m_pair.getNumItems();
   }
   void mainGroupComplete()
   {
      m_mainGroupSize = getNumItems();
   }
   void firstGroupComplete()
   {
      m_firstGroupSize = getNumItems();
   }
   void setRotationAngle(int angle)
   {
      m_angle = angle;
   }

   size_t getMainGroupSize()
   {
      return m_mainGroupSize;
   }
   size_t getFirstGroupSize()
   {
      return m_firstGroupSize;
   }
   void setNests(ESK::Sign *nestP, ESK::Sign *nestG)
   {
      m_signP = nestP;
      m_signG = nestG;
   }
   void setPairSet(MinutiaePairSet *probePairSet, MinutiaePairSet *galleryPairSet)
   {
      m_pairSetP   = probePairSet;
      m_pairSetG = galleryPairSet;
   }
   void setNearSingular(bool *nearSingularP, bool *nearSingularG)
   {
      m_nearSingularP = nearSingularP;
      m_nearSingularG = nearSingularG;
   }
   void getRotation(int &xcP, int &ycP, int &xcG, int &ycG, int &angle, bool recalc = true) 
   { 
      if (recalc)
         recalcData();
      xcP = m_xcP;
      ycP = m_ycP;
      xcG = m_xcG;
      ycG = m_ycG;
      angle = m_angle; 
   }
   int getXcP() { return m_xcP; }
   int getYcP() { return m_ycP; }
   int getXcG() { return m_xcG; }
   int getYcG() { return m_ycG; }

   void setDensity(int dRidge)
   {
      m_dr = dRidge;
   }
   void setAngleTolerance(int dMinAngle, int dMinAngle1, int dAngle)
   {
      m_dMinAngle = dMinAngle; 
      m_dMinAngle1 = dMinAngle1; 
      m_dAngle = dAngle;
   }
   void setGroupAngle(int pos = 0)
   {
      m_angle = normAngle((int)m_signP[getProbe(pos)].Beta - (int)m_signG[getGallery(pos)].Beta);
      if (abs(abs(m_angle) - 180) < m_dAngle + 10)  // around 180
         m_around180 = true;
   }
   bool add(int np, int ng, Transition transition)//, short transitionDif)//, WORD sim = 0, short err = 0)
   {
      assert(transition <= MPT);
      if (!m_pair.add (PairEx2(np, ng, transition)))//, transitionDif)))//, sim, err)))
         return false;
      if (m_pair.getNumItems() == 1)
      {
         setGroupAngle(0);
         m_xcP = (int)m_signP[np].Movx;
         m_ycP = (int)m_signP[np].Movy;
         m_xcG = (int)m_signG[ng].Movx;
         m_ycG = (int)m_signG[ng].Movy;
      }
      m_numAdded++;
      return true;
   }
   bool getPair (size_t i, short &np, short &ng)
   {
      PairEx2& pair = m_pair.getItem(i);
      np = pair.m_np;
      ng = pair.m_ng;
      return (np != -1);
   }
   short getProbe (size_t pos) const
   {
      return m_pair.getItem(pos).m_np;
   }
   short getGallery (size_t pos) const
   {
      return m_pair.getItem(pos).m_ng;
   }
   Transition getTransition(size_t pos)
   {
      return m_pair.getItem(pos).m_transition;
   }
   //short getTransitionDif(size_t pos)
   //{
   //   return m_pair.getItem(pos).m_transitionDif;
   //}
   short getScaleX(size_t pos)
   {
      return m_pair.getItem(pos).m_scaleX;
   }
   short getScaleY(size_t pos)
   {
      return m_pair.getItem(pos).m_scaleY;
   }
   void setScaleX(size_t pos, short scale)
   {
      m_pair.getItem(pos).m_scaleX = scale;
   }
   void setScaleY(size_t pos, short scale)
   {
      m_pair.getItem(pos).m_scaleY = scale;
   }
   //WORD getSim(size_t pos)
   //{
   //   return m_pair.getItem(pos).m_sim;
   //}
   //int getErr(size_t pos)
   //{
   //   return m_pair.getItem(pos).m_err;
   //}

   short getConflictPos ()
   {
      return m_conflictPos;
   }
   void setConflictPos (short conflictPos)
   {
      m_conflictPos = conflictPos;
   }
   //WORD getConflictSim ()
   //{
   //   return m_conflictSim;
   //}
   //void setConflictSim (WORD conflictSim)
   //{
   //   m_conflictSim = conflictSim;
   //}
   //int getNumParentsItem ()
   //{
   //   return m_numParentsItem;
   //}
   //void setNumParentsItem (int numParentsItem)
   //{
   //   m_numParentsItem = numParentsItem;
   //}
   GroupEx& operator= (const GroupEx& g)
   {
      m_pair           = g.m_pair;
      m_angle          = g.m_angle;
      m_signP          = g.m_signP;
      m_signG          = g.m_signG;
      m_around180      = g.m_around180;
      m_pairSetP   = g.m_pairSetP;
      m_pairSetG = g.m_pairSetG;
      m_nearSingularP  = g.m_nearSingularP;
      m_nearSingularG  = g.m_nearSingularG;
      m_xcP            = g.m_xcP;
      m_ycP            = g.m_ycP;
      m_xcG            = g.m_xcG;
      m_ycG            = g.m_ycG;
      m_dr             = g.m_dr;
      m_dMinAngle      = g.m_dMinAngle;
      m_dMinAngle1     = g.m_dMinAngle1;
      m_dAngle         = g.m_dAngle;
      m_numAdded       = g.m_numAdded;
      m_numChanged     = g.m_numChanged;
      m_mainGroupSize  = g.m_mainGroupSize; 
      m_firstGroupSize = g.m_firstGroupSize; 
      m_signP          = g.m_signP;
      m_signG          = g.m_signG;
      m_pairSetP   = g.m_pairSetP;
      m_pairSetG = g.m_pairSetG;
      m_nearSingularP  = g.m_nearSingularP;
      m_nearSingularG  = g.m_nearSingularG;
      m_errorLevel     = g.m_errorLevel;
      m_conflictPos    = g.m_conflictPos;
      //m_conflictSim    = g.m_conflictSim;
      //m_numParentsItem = g.m_numParentsItem;

      return *this;
   }
   GroupEx& operator+= (const HitGroup& g)
   {
      BYTE size = g.getNumItems();
      short np = 0, ng = 0;
      Transition transition = NT;
      for (BYTE i = 0; i < size; i++)
      {
         g.getPair (i, np, ng);
         if (np == -1)
            continue;
         if (findProbe (np) != -1 || findGallery (ng) != -1)
            continue;
         transition = g.getTransition(i);
         add (np, ng, transition);//, 0);
      }
      return *this;
   }
   // check if (np, ng) minutiae pair compatible with the group
   bool isCompatible(short np, short ng, int errorLevel,
                       NumSet<size_t> &errorPos, size_t maxAcceptableError, 
                       int *err, NumSet<size_t> &skipPos, 
                       bool useScale, int scaleX, int scaleY, 
                       size_t checkStartPos, int checkStopPos = -1)
   {
      if (err) *err = 0;

      if (useScale && scaleX && scaleY)
         recalcData();

      size_t numItems = getNumItems();
      if (!numItems)           // any pair compatible with empty group
         return true;
      size_t stopPos = numItems -1;
      if (checkStopPos >= 0 && checkStopPos < (int)numItems)
         stopPos = checkStopPos;
      if (!checkMinAngles(np, ng))
         return false;
    //  if (!checkAngles (np, ng)) 
      //   return false;

      // compare all new pairs (thouse appears because the new minutiae pair added)
      short e = 0;
      int count = 0;
      int lenP = 0, lenG = 0;
      int angle = 0;
      int dx = 0, dy = 0;
      short scaleX_1 = 0, scaleY_1 = 0;
      short np1 = 0, ng1 = 0;
      int angleP = 0, angleG = 0;
      for (size_t i = checkStartPos; i <= stopPos; i++)
      {
         if (skipPos.find (i) != -1)
            continue;
         getPair(i, np1, ng1);
         lenP = m_pairSetP->getLen(np, np1);
         angleP = m_pairSetP->getAngleEx(np, np1);
//         if (local && lenP > maxDist)
//            continue;
         lenG = m_pairSetG->getLenEx(ng, ng1);
         angleG = m_pairSetG->getAngleEx(ng, ng1);
         if (useScale && scaleX && scaleY)
         {
            scaleX_1 = getScaleX(i);
            scaleY_1 = getScaleY(i);
            if (scaleX_1 && scaleY_1)
            {
               angle = m_pairSetG->getAngleEx (ng1, ng) + m_angle;
               lenG *= 2 * 256;
               dx = -cosm (lenG, angle) / (scaleX_1 + scaleX);
               dy = -sinm (lenG, angle) / (scaleY_1 + scaleY);
               lenG = dist(dx, dy);
               angleG = normAngle(atan(dx, dy) - m_angle);
            }
         }
         if (!compPairLen (lenP, lenG, errorLevel, &e)                 ||
             !checkGroupAngle (angleP, angleG, lenP, lenG, m_dAngle * 2))
         {
            if (errorPos.getNumItems() >= maxAcceptableError)
               return false;
            errorPos.add (i);
         }
         else if (err)
         {
            count++;
            *err += e;
         }
      }
      if (err && count)
         *err /= count;
      return true;
   }

   bool checkMinAngles(short np, short ng, int groupAngle)//, short *err = NULL)
   {
      return accelMatch::checkMinAngles((int)m_signP[np].Beta, (int)m_signG[ng].Beta, groupAngle, m_nearSingularP[np], m_nearSingularG[ng], 
                     m_dMinAngle, m_dMinAngle1);//, err);
   }
   bool compPairLen (int lenP, int lenG, int errorLevel, short *err = NULL)
   {
      if (err) *err = 0;
      int distErrTol = getDistTol (minAB(lenP, lenG), errorLevel);
      int dLen = abs (lenP - lenG);
      if (dLen > distErrTol)
         return false;
      if (err)
      {
         int maxLen = maxAB (lenP, lenG);
         *err =  maxLen ? dLen * 256 / maxLen : 0;
      }
      return true;
   }
   int findProbe (short np, int start = 0)
   {
      if (np == -1)
         return -1;
      size_t num = m_pair.getNumItems();
      for(size_t i = start; i < num; i++)
      {
         if (m_pair.getItem(i).m_np == np)
            return (int)i;
      }
      return -1;
   }

   int findGallery (short ng, int start = 0)
   {
      if (ng == -1)
         return -1;
      size_t numItems = m_pair.getNumItems();
      for(size_t i = start; i < numItems; i++)
      {
         if (m_pair.getItem(i).m_ng == ng)
            return (int)i;
      }
      return -1;
   }
   int find (short np, short ng, int start = 0)
   {
      int pos = findProbe(np, start);
      if (pos == -1)
         return -1;
      if (getGallery(pos) == ng)
         return pos;
      else
         return -1;
   }

   bool canAdd(short np, short ng)
   {
      if (findProbe(np) != -1 || findGallery(ng) != -1)
         return false;
      return true;
   }
   bool addWidthCheck(short np, short ng, Transition transition)//, short transitionDif)
   {
      if (!canAdd(np, ng))
         return false;
      return add(np, ng, transition);//, transitionDif);
   }
   bool replace (size_t replaceIndex, short np, short ng, Transition transition)//, short transitionDif)//, WORD sim = 0, short err = 0)
   {
      assert (replaceIndex < m_pair.getNumItems());
      if (!m_pair.replace (replaceIndex, PairEx2 (np, ng, transition)))//, transitionDif)))//, sim, err)))
         return false;
      if (!replaceIndex)
         setGroupAngle(0);
      m_numChanged++;
      return true;
   }
   void remove (size_t pos)
   {
      assert (pos < m_pair.getNumItems());
      m_pair.remove (pos);
      if (pos < m_mainGroupSize)
         m_mainGroupSize--;
      if (pos < m_firstGroupSize)
         m_firstGroupSize--;
      m_numChanged++;
   }
   void remove (size_t *pos, size_t numPos)
   {
      m_pair.remove (pos, numPos);
      for(size_t i = 0; i < numPos; i++)
      {
         if (pos[i] < m_mainGroupSize)
            m_mainGroupSize--;
         if (pos[i] < m_firstGroupSize)
            m_firstGroupSize--;
      }
      m_numChanged++;
   }
   void remove (NumSet<size_t> &pos)
   {
      m_pair.remove (pos);
      for(size_t i = 0; i < pos.getNumItems(); i++)
      {
         if (pos.getItem(i) < m_mainGroupSize)
            m_mainGroupSize--;
         if (pos.getItem(i) < m_firstGroupSize)
            m_firstGroupSize--;
      }
      m_numChanged++;
   }


   //void compress()
   //{
   //   m_pair.compress();
   //   m_lastAngleCalc = 0;
   //   m_lastScaleCalc = 0;
   //   recalcData();
   //}

private:

   bool checkMinAngles(short np, short ng)//, short *err = NULL)
   {
      return checkMinAngles(np, ng, m_angle);//, err);
   }

   bool checkGroupAngle(int angleP, int angleG, int lenP, int lenG, int angleTol,
               short *err = NULL)
   {
      if (err) *err = 0;
      if (lenP < m_dr * 2)
         return true;
      if (lenG < m_dr * 2)
         return true;
      if (err)
      {
         int maxAngle = maxAB (abs(angleP), abs(angleG));
         int dAngle = abs(normAngle(angleP - angleG));
         *err =  maxAngle ? dAngle * 256 / maxAngle : 0;
      }
      return (abs(normAngle(angleP - angleG - m_angle)) <= angleTol);
   }


   bool checkGroupAngle(short np, short ng, int np1, int ng1, int lenP, int lenG, int angleTol,
               short *err = NULL)
   {
      int angleP = m_pairSetP->getAngle(np, np1); 
      int angleG = m_pairSetG->getAngleEx(ng, ng1); 
      return checkGroupAngle(angleP, angleG, lenP, lenG, angleTol, err);
   }

   bool checkAngles(short np, short ng)
   {
      if (!checkMinAngles(np, ng))
         return false;
      return checkGroupAngle (np, ng, getProbe(0), getGallery(0), 
         m_pairSetP->getLen(np, 0), m_pairSetG->getLenEx(ng, 0), m_dAngle);
   }
public:
   // recalculate angle rotation
   void clearChangesCount()
   {
      m_numChanged = 0;
      m_numAdded   = 0;
   }
   size_t getNumChanges()
   {
      return m_numAdded + m_numChanged;
   }
   void recalcData()
   {
      size_t numItems = m_pair.getNumItems();
      if (numItems < 2 || !getNumChanges()) 
         return;
      m_xcP = m_ycP = m_xcG = m_ycG = 0;
      int np = 0, ng = 0, count = 0;
      for(size_t i = 0; i < numItems; i++)
      {
         np = getProbe(i);
         ng = getGallery(i);
         m_xcP += (int)m_signP[np].Movx;
         m_ycP += (int)m_signP[np].Movy;
         m_xcG += (int)m_signG[ng].Movx;
         m_ycG += (int)m_signG[ng].Movy;
         count++;
      }
      if (!count)
         return;
      m_xcP /= count;
      m_ycP /= count;
      m_xcG /= count;
      m_ycG /= count;

      int distP= 0, distG = 0;
      float difAngle = 0;
      float angP = 0, angG = 0;
      int dx = 0, dy = 0;
      float sumAngle = 0;
      int sumDistP = 0, sumDistG = 0;

      for(size_t i = 0; i < numItems; i++)
      {
         np = getProbe(i);
         ng = getGallery(i);
         dx = (int)m_signP[np].Movx - m_xcP;
         dy = (int)m_signP[np].Movy - m_ycP;
         distP = dist(dx, dy);
         if (distP < m_dr * 2)
            continue;
         angP = atan2 ((float)dy, (float)dx);
         dx = (int)m_signG[ng].Movx - m_xcG;
         dy = (int)m_signG[ng].Movy - m_ycG;
         distG = dist(dx, dy);
         sumDistP += distP;
         sumDistG += distG;
         angG = atan2 ((float)dy, (float)dx);
         difAngle = angP - angG;
         if (difAngle >= M_PI)
            difAngle -= (float)M_PI * 2;
         else if (difAngle < -M_PI)
            difAngle += (float)M_PI * 2;
         if (m_around180)
            difAngle += (difAngle > 0 ? -1 : 1) * (float)M_PI;
//            difAngle += (float)M_PI;
         sumAngle += difAngle * distP;
      }
      if (!sumDistP)
         return;
      m_angle = (int)(sumAngle * 180 / sumDistP / M_PI + 0.5);
      m_angle = normAngle(m_angle);
      if (m_around180)
         m_angle = normAngle(m_angle - 180);
   }

   void calcScaleForOnePair(MinutiaeShort *minutiaeGR, int np, int ng, short &scaleX, short &scaleY)
   {
      size_t numItems = m_mainGroupSize ? m_mainGroupSize : m_pair.getNumItems();
      short np1 = 0, ng1 = 0;
      int lenP_x = 0, lenP_y = 0, lenG_x = 0, lenG_y = 0;
      long long sumScaleX = 0, sumScaleY = 0;  
      int weight_x = 0, weight_y = 0, sumWeight_x = 0, sumWeight_y = 0;
      for(size_t i = 0; i < numItems; i++)
      {
         getPair(i, np1, ng1);
         if (np1 == np || ng1 == ng)
            continue;
         lenP_x = abs(m_signP[np].Movx - m_signP[np1].Movx);
         lenP_y = abs(m_signP[np].Movy - m_signP[np1].Movy);
         lenG_x = abs(minutiaeGR[ng].m_x - minutiaeGR[ng1].m_x);
         lenG_y = abs(minutiaeGR[ng].m_y - minutiaeGR[ng1].m_y);
         if (lenP_x >= CALC_SCALE_MIN_DIST && lenG_x >= CALC_SCALE_MIN_DIST)
         {
            weight_x     = lenP_x <= CALC_SCALE_MAX_DIST ? 256 : CALC_SCALE_MAX_DIST * 256 / lenP_x;  
            sumScaleX   += lenG_x * weight_x / lenP_x;
            sumWeight_x += weight_x;
         }
         if (lenP_y >= CALC_SCALE_MIN_DIST && lenG_y >= CALC_SCALE_MIN_DIST)
         {
            weight_y     = lenP_y <= CALC_SCALE_MAX_DIST ? 256 : CALC_SCALE_MAX_DIST * 256 / lenP_y;  
            sumScaleY   += lenG_y * weight_y / lenP_y;
            sumWeight_y += weight_y;
         }
      }
      scaleX = (short)(sumWeight_x ? sumScaleX  * 256 / sumWeight_x : 0);
      scaleY = (short)(sumWeight_y ? sumScaleY  * 256 / sumWeight_y : 0);
   }

   void calcScaleForNewPair(MinutiaeShort *minutiaeGR, size_t pos)
   {
      assert (pos < m_pair.getNumItems());
      short np = getProbe  (pos);
      short ng = getGallery(pos);
      short scaleX = 0, scaleY = 0;
      calcScaleForOnePair(minutiaeGR, np, ng, scaleX, scaleY);
      m_pair.getItem(pos).m_scaleX = scaleX;
      m_pair.getItem(pos).m_scaleY = scaleY;

   }

   void calcScale(MinutiaeShort *minutiaeGR)
   {
      size_t numItems = m_pair.getNumItems();
      if (numItems < 2 || !getNumChanges()) 
         return;

      short np = 0, ng = 0, scaleX = 0, scaleY = 0;
      for(size_t i = 0; i < numItems; i++)
      {
         getPair(i, np, ng);
         calcScaleForOnePair (minutiaeGR, np, ng, scaleX, scaleY);
         m_pair.getItem(i).m_scaleX = scaleX;
         m_pair.getItem(i).m_scaleY = scaleY;
      }
   }
};



#pragma pack(pop)
} //namespace accelMatch{


#endif // GROUP_100_H_