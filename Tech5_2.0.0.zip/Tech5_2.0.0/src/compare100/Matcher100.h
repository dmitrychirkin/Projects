/*
   moMatcher.h - declare the Matcher100 class that is supposed to compare the 
                 fingerprints on minutiae only information (x, y, angle, type)

   Copyright (C) 2006 Sonda Technologies Ltd.
   Author A.Mosunov
   21.05.2006
*/
#ifndef MATCHER_100_H_
#define MATCHER_100_H_

#include <set>

#include <assert.h>
#include <stdlib.h>

#include "coreSdk.h"
#include "core_err.h"
#include "Unwrap.h"
#include "group100.h"
#include "staticData100.h"
#include "scoreParameters100.h"
#include "sfsDef.h"
#include "accelTables.h"
#include "conflictPos.h"
#include "score100.h"
#include "expandGroup.h"
#include "nestSim.h"
#include "nestVirtSize.h"
#include "nestCompareResult.h"
#include "accelDeal.h"

using namespace std;
using namespace accelMatch;

namespace accelMatch{
#pragma pack(push,_CORE_PACKING)

// default search parameters
#define DEF_MAX_ANGLE                  50 
#define DEF_MAX_DIST                   400
#define DEF_SEARCH_SPEED               0

//#define MAX_NESTS_COMPARE_RESULT_SIZE  1256          
#define MAX_KERNEL_GROUPS             20
#define MAX_EXPAND_GROUPS             20
#define MAX_KERNEL_GROUP_SIZE         MAX_MINUTIAE
#define MAX_EXPAND_GROUP_SIZE         MAX_MINUTIAE

#define MAX_ACCEL_SIM                 97    // maximum possible accel     compare score
#define MAX_NEST_ACCEL_SIM            128   // maximum possible nestAccel compare score


struct NotHit
{
   bool notHit;
   bool isSameDir;

   NotHit()
   {
      memset(this, 0, sizeof(NotHit));
   }
};

class Matcher100
{
	ESK::Unwrap  *m_unwrap;
   // search parameters
   int          m_maxAngle;         // fingerprint rotation angle tolerance, degree
   int          m_speed;
   // minutiae data
   int          m_numNestP;         // number of minutiae
   int          m_numNestG;         // number of minutiae
   int          m_maxNumNestP;      // number of minutiae for those memory is allocated  
   int          m_maxNumNestG;  

   WORD         m_widthP;            // probe image width
   WORD         m_widthG;            // gallery image width
   WORD         m_heightP;           // probe image height
   WORD         m_heightG;           // gallery image height
   BYTE        *m_areaP;             // pointer to bad area zone
   BYTE        *m_areaG;             // pointer to bad area zone
   BYTE        *m_areaP_buf;         // bad area zone buffer
   BYTE        *m_areaG_buf;         // bad area zone buffer
   WORD         m_areaWidthP;        // with   of probe   bad area
   WORD         m_areaWidthG;        // with   of gallery bad area  
   WORD         m_areaHeightP;       // height of probe   bad area
   WORD         m_areaHeightG;       // height of gallery bad area  
   BYTE         m_qualityP;          // image quality 
   BYTE         m_qualityG;       
   // minutiae array
	ESK::Sign   *m_minutiaeP , *m_minutiaeG     ;         
	ESK::Link   *m_linkP     , *m_linkG     ;         
   WORD        *m_probP     , *m_probG     ;
   NestAccel   *m_nestAccelP, *m_nestAccelG;
   BYTE         m_maxProbP  ,  m_minProbP  ;
   size_t       m_k_speed[SPEED_PARAM_SIZE];      // speed coefficient
   // fingerprint templates 
   BYTE         m_templateP[MAX_TEMPLATE_SIZE_80];
   BYTE         m_templateG[MAX_TEMPLATE_SIZE_80];
       
   // PATTERN TYPE
   BYTE m_patternTypeP;
   BYTE m_patternTypeG;
   // SINGULAR
   ESK::Sign    m_singularP[MAX_SINGULAR];   
   ESK::Sign    m_singularG[MAX_SINGULAR];   
   int          m_numSingularP;
   int          m_numSingularG;
   // probe singular reflected to gallery fingerprint
   ESK::Sign    m_singularPR[MAX_SINGULAR];
   // gallery singular reflected to gallery fingerprint
   ESK::Sign    m_singularGR[MAX_SINGULAR];
   // possible exclude probe and galery singular
   bool         m_excludeSingP[MAX_SINGULAR];
   bool         m_excludeSingG[MAX_SINGULAR];
   FP_TYPE      m_typeP;
   FP_TYPE      m_typeG;

   // accelerator compare results
   BYTE         m_accelSim[MAX_MINUTIAE][MAX_MINUTIAE];
   BYTE         m_simHist[MAX_NEST_ACCEL_SIM + 1];
   // nests compare results
   NestCompareResult    m_nestCompResult [MAX_MINUTIAE][ MAX_MINUTIAE];
   NestSimSet           m_nestSimSet;
   NestVirtSizeSet      m_nestVirtSizeSet;  
   ExpandGroupPairSet   m_expandGroupPairSet;
   
   MinutiaePairSet m_pairSetP;
   MinutiaePairSet m_pairSetG;
   bool m_nearSingularP[MAX_MINUTIAE];
   bool m_nearSingularG[MAX_MINUTIAE];
   int m_densityP, m_densityG;
   int m_takenP[MAX_MINUTIAE];
   int m_takenG[MAX_MINUTIAE];

   // current group
   GroupEx       *m_curGroup;
   GroupEx        m_kernelGroups    [MAX_KERNEL_GROUPS];
   GroupEx       *m_p_kernelGroups  [MAX_KERNEL_GROUPS];
   GroupEx        m_expandGroups    [MAX_EXPAND_GROUPS];
   GroupEx       *m_p_expandGroups  [MAX_EXPAND_GROUPS];
   // probe minutiae reflected to gallery fingerprint
   MinutiaeShort *m_minutiaePR;  
   // gallery minutiae reflected to probe fingerprint
   MinutiaeShort *m_minutiaeGR;  
   // possible exclude probe and galery minutiae
   bool m_excludeP[MAX_MINUTIAE];
   bool m_excludeG[MAX_MINUTIAE];
   // strong exclude probe and galery minutiae
   bool m_strongExcludeP[MAX_MINUTIAE];
   bool m_strongExcludeG[MAX_MINUTIAE];
   bool m_quick;                          // quick matching
   int  m_rotation;
   int m_dMinAngle;
   int m_dMinAngle1;
   int m_dAngle;
   int m_dr;
//   int m_kDist;
   int *m_acceleratorG[4];
   //BYTE *m_accelG_buf;
   //BYTE *m_tpAccelG_buf;
   BYTE           *m_accelP;
   BYTE           *m_accelG;
   PairGroupEx     m_virtGroup;
   ScoreParameters m_param;
   MinData         m_minDataP[MAX_MINUTIAE];
   MinData         m_minDataG[MAX_MINUTIAE];
   // distance tolerance table
//   int *m_curDistTolTab;
   int m_errorLevel;
   // combine information from accelerator matching
//   int m_xcP, m_ycP, m_xcG, m_ycG, m_angle;    
   HitGroup m_compNestHitGroup, m_findBestGHitGroup, m_tempHitGroup;
   //short m_errA [MAX_MINUTIAE];
   //short m_errR [MAX_MINUTIAE];
   //short m_errGA[MAX_MINUTIAE];
//   int   m_xcP, m_ycP;      // center of minutia on probe
//   int   m_xcG, m_ycG;      // center of minutia on gallery
   bool        m_checkQuadrants;
   bool        m_allowReplacement;
   Transition  m_acceptableTransition;
   BYTE        m_maxRcDif;

public:
   // fill g_distTol table
   static void fillDistTolTalbe ();

   Matcher100();
   ~Matcher100();
//   int init(void *accelHandle);

   // load probe template
   int loadProbe (BYTE *templ, FP_TYPE type, BYTE *areaP, int areaWidthP, int areaHeightP)
   { return loadTemplate (true, templ, type, areaP, areaWidthP, areaHeightP); }
   // load gallery template
   int loadGallery (BYTE *templ, FP_TYPE type)
   { return loadTemplate (false, templ, type, NULL, 0, 0); }
   // compare templates
   int match (MatchResult &result, int maxAngle, int speed, bool useCombineData, //int xcP = 0, int ycP = 0, int xcG = 0, int ycG = 0, int angle = 0,
                        BYTE *np, BYTE *ng, BYTE accelGroupSize, bool quickAccelMatch);
   bool matchBranch1 (MatchResult &matchRes, CalcScoreTypeEnum calcScoreType);
   bool matchBranch2 (MatchResult &matchRes, CalcScoreTypeEnum calcScoreType);

private:
   // set matching parameters
   void setParameters(int maxAngle, int speed);
   // calculate similarity index for curretn minutiae group
   int calcGroupScore();
   // load template
   int loadTemplate (bool isProbe, BYTE *templ, FP_TYPE type, BYTE *area, int areaWidth, int areaHeight);
   int loadSingular (bool isProbe);
   // validate template 
   bool validateTemplate(const BYTE *fpTemplate, BYTE &quality, WORD &width, WORD &height);
   // calculate similarity of probe and transferred minutiae group
   int calcScore(CalcScoreTypeEnum calcScoreType);
   bool saveMatchResult(MatchResult &matchRes, CalcScoreTypeEnum calcScoreType);
   // add in the current group the minutiae, thouse locate the similar
   // returns number of added minutiae
   bool expandCurGroupByGeometry(bool quickAccelMatch);
   size_t expandCurGroup(bool quickAccelMatch);
   void expandGroupByTopology          (GroupEx* curGroup, size_t startPos                );
   void expandCurGroupByTopologyAlt();
   void expandGroupByNestSimSetAlt     (GroupEx* curGroup                                 );
   void fillCoflictPosSet              (                    ConflictPosSet &conflictPosSet);
   void fillCoflictPosSetForNestSimSet (GroupEx* curGroup,  ConflictPosSet &conflictPosSet);
   void testExpandCases                (                    ConflictPosSet &conflictPosSet);
   void testExpandCasesForNestSimSet   (GroupEx* curGroup,  ConflictPosSet &conflictPosSet);

   // transfer minutiaes to another fingerprint
   bool transferMinutiaes(GroupEx *g, ESK::Sign *srcMin, MinutiaeShort *dstMin, int num,
                           int srcXc, int srcYc, int dstXc, int dstYc, int angle, bool calcAll, bool isProbe);
   // transfer singulars to another fingerprint
   bool transferSingulars(GroupEx *g, ESK::Sign *srcSing, ESK::Sign *dstSing, int num, int srcXc, int srcYc, int dstXc, int dstYc, int angle/*, float scale*/, bool isProbe);
   // transfer singulars to another fingerprint based on minutiae those located near the corresponded singular
   void transferSingularsByNearestMinutiae(SingularData &data, GroupEx *curGroup);
   // get minutiae those located near the corresponded singular
   void getNearestMinutiae(GroupEx &g, ESK::Sign &sing, unsigned int maxDist);
   // transfer point to another coordinate system
   void transferPoint(int srcX, int srcY, int srcAngle, int &dstX, int &dstY, int &dstAngle,
                           int srcXc, int srcYc, int dstXc, int dstYc, int angle, int scaleX, int scaleY, int scaleXc, int scaleYc, bool isProbe);
   // find minutiaes thouse can be behind of clear area of another fingerprint
   void findExclude();
   // find singulars thouse can be behind of clear area of another fingerprint
   void findSingularExclude();
   // find minutiae thouse behind of clear area of another fingerprint with hight probability
   void findStrongExclude();
   // find all pairs that compatible wih current group and can be used for expantion by geometry 
   void findAllCompatiblePairs();
   // build possible expand groups
   size_t buildExpandGroups();
   // find the best probe minutiae for given gallery minutiae
//   int findBestP(int np,  int angle, int scaleX, int scaleY);
   // check how many pair can be added together with this (np; ng) pair
   void buildExpandGroup(GroupEx *g, short np, short ng, short conflictPos, WORD conflictSim, int numParentsItem);
   // create the local group that include only minutiae from current group, 
   // those near minutiae number 'numItem'
   void createLocalGroup (int numItem, int maxDist);
   // try to add new minutiae to the local gropu
   int expandLocalGroup (int maxDist);
   void calcTopologySim(int firstGroupSize, int mainGroupSize, int numItems);
   /*
      Calculate pair differences (location and angle differences for all 
      possible minutiae pairs from current group)
   */
   void calcPairDif (int firstGroupSize, int mainGroupSize, int numItems, int groupSize[3]);
   void calcPairRelAngleDif (int firstGroupSize, int mainGroupSize, int numItems, int groupSize[3]);

   bool reallocMinutiae (bool isProbe, int num);
   int loadMinutiae(bool isProbe, BYTE *templ);

   bool allocArea ();
//   bool allocYagi ();
   int loadArea (bool isProbe, BYTE *templ, BYTE *areaFromAccelLib = NULL, int areaWidthFromAccelLib = 0, int areaHeightFromAccelLib = 0);

   // calculate the number of excluded minitiae
   BYTE countExcluded(int num, bool *exclude);
   // compare all nests for those  compare accelerators give similarity more than simTol
   // return max of similarity
   void compareBestNests(BYTE accelThreshold);
   void compareNestsFromAccelMatch (BYTE *np, BYTE *ng, BYTE accelGroupSize);

   bool isTransitionPossible (short np, short ng, Transition transition)
   {
      assert (np >= 0 && np < m_numNestP);
      assert (ng >= 0 && ng < m_numNestG);
      if (transition > MPT)
         return false;
      ESK::byte_t typeP = m_minutiaeP[np].Type;
      ESK::byte_t typeG = m_minutiaeG[ng].Type;
      if (typeP == ENDING)
      {
         if(typeG == ENDING) return (transition == NT) || (transition == E2RE_2) || (transition == E2LE_2) || (transition == E2LE_4) || (transition == E2RE_4) || (transition == E2LE_6) || (transition ==  E2RE_6);
         else                return                       (transition == E2LB_1) || (transition == E2RB_1) || (transition == E2LB_3) || (transition == E2RB_3) || (transition == E2LB_5) || (transition ==  E2RB_5);
      }
      else // typeP == BIFURCATION
      {
         if(typeG == ENDING) return                       (transition == B2RE_1) || (transition == B2LE_1) || (transition == B2LE_3) || (transition == B2RE_3) || (transition == B2LE_5) || (transition == B2RE_5);
         else                return (transition == NT) || (transition == B2LB_2) || (transition == B2RB_2) || (transition == B2LB_4) || (transition == B2RB_4) || (transition == B2LB_6) || (transition == B2RB_6);
      }
   }
   HitGroup* nestCompare (int np, int ng, Transition transition, int angle)
   {
      assert(np >= 0 && np < m_numNestP);  
      assert(ng >= 0 && ng < m_numNestG);  
      assert (transition < TL_3);
      NestCompareResult *compRes = &m_nestCompResult[np][ng];
      HitGroup *hitGroup = compRes->getGroup(transition);
      if (hitGroup)
         return hitGroup;

      if (!isTransitionPossible (np, ng, transition))
         return NULL;
      compNestsAlt (np, ng, transition, angle);
      saveNestComRes(compRes, transition);
      return &m_compNestHitGroup;
   }
   void saveNestComRes(NestCompareResult *compRes, Transition transition)
   {
      if (transition > TL_1_MAX)
         return;
      HitGroup *hitGroup = compRes->alloc(transition);   
      *hitGroup = m_compNestHitGroup;
      compRes->setMatchResult (hitGroup);
   }

   NestCompareResult* getNestCompareResult (int np, int ng, Transition maxTransition, WORD &bestSim)
   {
      assert (maxTransition < TL_3);
      if (maxTransition >= TL_3) maxTransition = Transition(TL_3 - 1);
      bestSim = 0;
      NestCompareResult * nestCompRes = &m_nestCompResult[np][ng];
      int angleDif = nestCompRes->getAngleDif();
      if (!angleDif)
      {
         angleDif = normAngle((int)m_minutiaeP[np].Beta - (int)m_minutiaeG[ng].Beta);
         nestCompRes->setAngleDif (angleDif);
      }
      for(int transition = 0; transition <= maxTransition; transition++)
         nestCompare(np, ng, (Transition)transition, angleDif);

      bestSim = nestCompRes->getBestSim();
      return nestCompRes;
   }
   WORD getNestsBestSim(int np, int ng)
   {
      WORD bestSim = 0;
      getNestCompareResult (np, ng, B2RB_2, bestSim);
      return bestSim;
   }

   HitGroup* getNestCompareResult (int np, int ng, Transition transition, short &transitionDif)
   {
      transitionDif = 0;
      HitGroup* g = NULL;
      if (transition < TL_3)
      {
         g = nestCompare(np, ng, transition, m_nestCompResult[np][ng].getAngleDif());
         return g;
      }
      // for transition >= TL_3 return group for the bestSim and calculate the transitionDif
      WORD bestSim = 0;
      NestCompareResult* compRes = getNestCompareResult (np, ng, B2LE_1, bestSim);
      Transition bestTransition      = compRes->getBestTransition();
      int transitionLevel     = getTransitionLevel (transition    );
      int bestTransitionLevel = getTransitionLevel (bestTransition);
      transitionDif = transitionLevel - bestTransitionLevel;
      assert(transitionDif > 0);
      return compRes->getGroup (bestTransition); 
   }

   WORD getFullNestCompareResult (int np, int ng, Transition transition, int angle, short &transitionDif)
   {
      assert(np >= 0 && np < m_numNestP);  
      assert(ng >= 0 && ng < m_numNestG);  
      transitionDif = 0;
      if (!isTransitionPossible (np, ng, transition))
         return 0;
      WORD sim = 0;
      if (transition < TL_3) 
      {
         compNestsFinal (np, ng, transition, angle);
         sim = m_compNestHitGroup.getSim();
         return sim;
      }
      // For transition >= TL_3 return group for the bestSim for transition < TL_1 and calculate the transitionDif
      WORD maxSim = 0;
      Transition bestTransition = NT;
      for(int trans = 0; trans <= TL_1_MAX; trans++)
      {
         if (!isTransitionPossible (np, ng, (Transition)trans))
            continue;
         compNestsFinal (np, ng, (Transition)trans, angle);
         sim = m_compNestHitGroup.getSim();
         if (sim > maxSim) 
         {
            bestTransition = (Transition)trans;
            maxSim         = sim;
         }
      }
      int        transitionLevel     = getTransitionLevel (transition    );
      int        bestTransitionLevel = getTransitionLevel (bestTransition);
      transitionDif = transitionLevel - bestTransitionLevel;
      assert(transitionDif > 0);
      return maxSim; 
   }
 
   short getTransitionDif(int np, int ng, Transition &transition, Transition maxTransition, WORD &bestSim);

//   void buildGroup (int startKernelGroupNum);
   void buildKernelGroups (int numBranch, size_t maxGroups, bool quickAccelMatch);
   // unite all possible kernal groups
   void uniteKernelGroups  (size_t maxGroups);
   void uniteDifGroups     (size_t maxGroups);
   void expandKernelGroups (size_t maxGroups);
   void expandGroupByNestSimSet(GroupEx *curGroup);
   void calcScale (GroupEx *g);
   void calcScaleForNewPair(GroupEx *g, size_t pos);
   // check if two kernal groups can be united
   bool isGroupsCanBeUnite(GroupEx* firstGroup, GroupEx* secondGroup, size_t samePairsPercentThreshold, 
                        int sameFirstPos[MAX_MINUTIAE], int sameSecondPos[MAX_MINUTIAE]);
   // unite two different groups
   void uniteDifGroup(GroupEx* firstGroup, GroupEx* secondGroup);
   // expand kernel group with nests pair from m_nestSimSet
   void expandKernelGroup(GroupEx* curGroup);
   // check if two groups are compatible
   bool isGroupsCompatible(GroupEx* firstGroup, GroupEx* secondGroup);
   bool isCompatibleWitchCentralPoint(int np0, int ng0, int np, int ng, int groupAngle, bool nearSingular);
   bool isPairsCompatible            (int np0, int ng0, int np, int ng, int groupAngle, bool nearSingular);

   void buildKernelGroup1          (GroupEx *kernelGroup, bool quickAccelMatch);
   void buildKernelGroup2          (GroupEx *kernelGroup);
   void buildInitialGroup          (GroupEx *curGroup, short np, short ng);
   void tryAdd2InitialGroup        (GroupEx *curGroup, short np, short ng, Transition transition);
   void cleanInitialGroup          (GroupEx *curGroup);
   void cleanInitialGroupCase (NumSet<size_t> *errorPosSrc, size_t size, size_t conflictPairSrc[MAX_MINUTIAE], NumSet<size_t> &bestRemovePos);
   bool addNestPair2group(GroupEx *curGroup, int np, int ng, Transition transition, bool addCentralNest, 
                           bool isCentralPointSameDir = true, bool useScalse = false);
   bool checkAngle(int np, int ng, int dAngle, int angleDif)
   {
      assert(np < m_numNestP);  
      assert(ng < m_numNestG);  
      dAngle += (m_nearSingularP[np] || m_nearSingularG[ng]) ? m_dMinAngle1 : m_dMinAngle;
      return (abs(normAngle(angleDif + m_rotation)) <= dAngle);
   }
   Transition findBestTransition (int dealP, int dealG)
   {
      return T2T[dealP][dealG];
   }
   // add nest pair together with all they links (in fact binded tree of nests) to current group
   void addNestPair2groupEx (GroupEx *curGroup, short np, short ng);
   void initNewMatch (MatchResult &matchRes);
   bool isEnding (int deal)
   {
      return (deal == ERO_ || deal == EROX || deal == ELO_ || deal == ELOX || deal == EO);
   }
   bool isBifurcation (int deal)
   {
      return !isEnding (deal);
   }
   void compNestsAlt  (short np, short ng, Transition transition, int groupAnlge);
   void compNestsFinal(short np, short ng, Transition transition, int groupAnlge);
   // save data for best alternative transition for given (np, ng) nest pair 
   // returns max sim
//   BYTE saveBestAlt (int num, NestCompareResult *nestCompareResult);

   // compare all accelerators
   // return  max of similarity
   int compareAllNestAccel();
   int compareSuitableAccelerators(int np0, int ng0);
   // fill m_bestNests with best results of nests compare 
   void chooseBestNests(size_t numPassedNests, size_t minVirtualGroupSize);
   void calcNestSim      (int np, int ng, HitGroup &hitGroup, NotHit *notHitP, NotHit *notHitG, bool final);
   // calculate sum of probability for hit items
   int getHitProbabilities (HitGroup &hitGroup, bool finalCalc, int &sumHitProb);
   // calculate sum of probability for not hit items
   int getNotHitProbabilities (int np0, int ng0, NotHit *notHitP, NotHit *notHitG, int &count, bool final = false, int maxDist = 1024);
   // check if new pair of links better fit one to another
   bool isNewLinksBetter(HitGroup &g, int replaceNum, int np, int ng, int newLevel, int np0, int ng0);
   // clean notHit group from numbers, those in hitGroup
   void clearNotHitGroup(HitGroup &hitGroup, NotHit *notHitP, NotHit *notHitG, bool finalCalc);
   void checkBadArea (MinutiaeShort *min, int num, BYTE *area, int areaWidth, int areaHeight, int reach, int tol, bool *exclude);
   void checkBadArea (ESK::Sign *sing, int num, BYTE *area, int areaWidth, int areaHeight, int reach, int tol, bool *exclude);

   bool checkMinAngles(int np, int ng, int groupAngle, short *err = NULL)
   {
      assert(np < m_numNestP);  
      assert(ng < m_numNestG);  
      //return accelMatch::checkMinAngles((int)m_minutiaeP[np].Beta, (int)m_minutiaeG[ng].Beta, groupAngle, m_nearSingularP[np], m_nearSingularG[ng], 
      //               m_dMinAngle, m_dMinAngle1, err);  
      //return accelMatch::checkMinAngles((int)m_minutiaeP[np].Beta, (int)m_minutiaeG[ng].Beta, groupAngle, m_nearSingularP[np], m_nearSingularG[ng], 
      //               m_dMinAngle, m_dMinAngle, err);  
      //return accelMatch::checkMinAngles((int)m_minutiaeP[np].Beta, (int)m_minutiaeG[ng].Beta, groupAngle, m_nearSingularP[np], m_nearSingularG[ng], 
      //               25, 50, err);   
      return accelMatch::checkMinAngles((int)m_minutiaeP[np].Beta, (int)m_minutiaeG[ng].Beta, groupAngle, m_nearSingularP[np], m_nearSingularG[ng], 
                     DEF_MINUTIAE_ANGLE_TOL, DEF_MINUTIAE_ANGLE_TOL, err);   
   }
   bool checkAngle1(int np, int np0, int ng, int ng0, short *err = NULL)
   {
      assert(np < m_numNestP);  
      assert(ng < m_numNestG);  
      int angleP = m_pairSetP.getAngle(np, np0); 
      int angleG = m_pairSetG.getAngleEx(ng, ng0); 
      int angleDif = abs(normAngle((m_minutiaeP[np].Beta - angleP) - (m_minutiaeG[ng].Beta - angleG)));
//      int dAngle = (m_nearSingularP[np] || m_nearSingularP[np0] || m_nearSingularG[ng] || m_nearSingularG[ng0]) ? DEF_MINUTIAE_ANGLE_TOL * 2 : DEF_MINUTIAE_ANGLE_TOL; // M6
      int dAngle = DEF_MINUTIAE_ANGLE_TOL;
      if (err)
         *err = angleDif * 256 / dAngle;
      return (angleDif <= dAngle);
   }

   //bool checkGroupAngles(int np, int np0, int ng, int ng0, int groupAngle, short *err = NULL)
   //{
   //   assert(np < m_numNestP);  
   //   assert(ng < m_numNestG);  
   //   int angleP = m_pairSetP.getAngle(np, np0); 
   //   int angleG = m_pairSetG.getAngleEx(ng, ng0); 
   //   int angleDif = abs(normAngle(angleP - angleG - groupAngle));
   //   if (err)
   //      *err = angleDif * 256 / m_dAngle;
   //   return (angleDif <= m_dAngle * 2);
   //}

   void setAngleTolerance(int dMinAngle, int dAngle)
   {
      m_dMinAngle = dMinAngle + dAngle; 
      m_dMinAngle1 = 2 * dMinAngle + dAngle; 
      m_dAngle = dAngle;
      for(int i = 0; i < MAX_KERNEL_GROUPS; i++)
         m_kernelGroups[i].setAngleTolerance (m_dMinAngle, m_dMinAngle1, m_dAngle);
      for(int i = 0; i < MAX_EXPAND_GROUPS; i++)
         m_expandGroups[i].setAngleTolerance (m_dMinAngle, m_dMinAngle1, m_dAngle);
   }
   BYTE buildVirtualGroup(short np, short ng);
   void clearUsedNests     (GroupEx *curGroup);
   void clearUsedNestSimSet(GroupEx *curGroup);
   //   returns quadrant, where minutiae 'n' located relatively on 'nest'
   // and -1 if n don't belong to nest
   // lp - number link where n was found
   int getQuadrant(int angle, ESK::Sign *minutiae, ESK::Link *link, int n, bool &pink, int &rc, Transition trans = NT);
   bool checkQuadrants(GroupEx *curGroup, int np, int ng, Transition trans, NumSet <size_t> &skipPos, size_t checkStartPos,
                          NumSet<size_t> &errorPos, size_t maxAcceptableError);
   int calcFinalNestSim(int np, int ng, Transition transition, int groupAngle);
   int combineFingerprintsByCurGroup(GroupEx *g, bool probe2gallety, bool gallery2probe, bool calcSingular);
   int combineFingerprints(GroupEx *g, bool probe2gallety, bool gallery2probe, int xcP, int ycP, int xcG, int ycG, int angle, bool calcAll);
   void prepareScoreParameters(CalcScoreTypeEnum calcScoreType);
   void fillMinutiaesData();
   void fillMinutiaeData      (MinData &data, FOUND_STATUS status, WORD probability);
   void fillFoundMinutiaesData ();
   void fillFoundMinutiaeData (size_t pos, FOUND_STATUS status);
   void fillNotFoundMinutiaesData ();
   void fillUnreliableMinutiaesData ();
   void findUnreliablePairs(ESK::Sign *minutiae, ESK::Link *links, int numNests, int *taken,  int n0, MinData *minData, bool isProbe);
   void findAllUnreliablePairs(ESK::Sign *minutiae, ESK::Link *links, int *taken, int numNests, bool *exclude, MinData *minData, bool isProbe);
   int getBestUnreliablePair(ESK::Sign *minutiae, ESK::Link *links, int numNests, int *taken, int n0, BYTE &bestRc, BYTE &bestSize);
   void fillUnreliablePairData (MinData *data, int n1, int n2, BYTE size, BYTE rc, bool isProbe);
   void getUnreliableStatus(int n1, int n2, bool isProbe, UnreliablePairStatus status[2]);
   BYTE estimateNotFoundAreaProb (int x, int y, ESK::Sign *minutiae, int numNest);

   int calculateScore();
   // return scale in area around probe minutiae  with coordinates (x0, y0)
   void getAreaScaleP(GroupEx *curGroup, int np0, int &averScaleX, int &averScaleY)
   {
      return getAreaScale(curGroup, m_minutiaeP[np0].Movx, m_minutiaeP[np0].Movy, averScaleX, averScaleY, true); 
   }
   // return scale in area around gallery minutiae  with coordinates (x0, y0)
   void getAreaScaleG(GroupEx *curGroup, int ng0, int &averScaleX, int &averScaleY)
   {
      return getAreaScale(curGroup, m_minutiaeG[ng0].Movx, m_minutiaeG[ng0].Movy, averScaleX, averScaleY, false); 
   }
   void getAreaScale(GroupEx *curGroup, int x0, int y0, int &averScaleX, int &averScaleY, bool isProbe);

   // return true if link minutiae has same direction as central minutiae
   bool isSameDirection(int deal, MINUTIAE_TYPE type, int linkNum)
   {
      int q = Quadrant[type][linkNum];
      if (q == 0 || q == 3)
         return isSameDir[deal];
      else
         return !isSameDir[deal];
   }
   bool isRight(MINUTIAE_TYPE type, int linkNum)
   {
      return isRightLink[(int)type][linkNum];
   }
   bool isUp(MINUTIAE_TYPE type, int linkNum)
   {
      return isUpLink[(int)type][linkNum];
   }
   bool checkAngles(int np, int ng, int np1, int ng1);
   bool tryAddLinks(GroupEx *curGroup, int np, int ng, Transition transition, bool isCentralPointSameDir, bool useScale);
   void setDistErrorLevel(int level);   
   void fillAccelHashTable();
   // calculate ridge count
   inline int calcRidgeCount_(int type, int link, int deal); 
   // calculate ridge count with take central point transition in attention 
   inline int calcRidgeCountEx(Transition trans, int type, int link, int deal);
//   void parseAccel (int a, int rc[2], int dist[2], int dir[2]);
   // add new pair to hit group
   void add2hit      (HitGroup &hitGroup, NotHit *notHitP, NotHit *notHitG, int np, int ng, Transition trans, bool sameDir, int np0, int ng0,
                        short *errR = NULL, short *errA = NULL, short *errA1 = NULL);
   // check if (np1, ng1) links in (np, ng) nests pair are compatible
   bool checkLink(short np, short ng, short np1, short ng1, int groupAngle, short *errR = NULL, short *errA = NULL, short *errA1 = NULL);
   bool isOppositeQuadrants (int q1, int q2)
   {
      return (q1 == oppositeQuadrants[q2]);
   }
   bool isNextQuadrants (int q1, int q2)
   {
      return (q1 == nextQuadrants[q2]);
   }
   // return mirror deal of pink link
   inline int getPinkDeal(ESK::Link *link, int l1, int *l2, int deal, MINUTIAE_TYPE type);
   void getMaxRightAndLeftLink(ESK::byte_t type_p, ESK::Link *linkP, ESK::Link *linkG, Transition transition, int &maxRightLinkP, int &maxLeftLinkP);
   // fill notHitP and notHitG array
   //void fillNotHitProbe  (int maxLink, ESK::byte_t *deal_p, ESK::twin_t *item_p, HitGroup &hitGroup, int *notHitP);
   //void fillNotHitGallery(int maxLink, ESK::byte_t *deal_g, ESK::twin_t *item_g, HitGroup &hitGroup, int *notHitG);
   // try to add reserved pairs to current group
//   int tryAddReserved();
   // try add pair to current group
   int tryAdd2curGroup(GroupEx *curGroup, int np, int ng, Transition transition, //short transitionDif, 
                  int errorLevel, size_t minReplacePos, bool useScale, short scaleX, short scaleY);
   int tryAdd2curGroupWithReplacement(GroupEx *curGroup, int np, int ng, Transition transition, //short transitionDif,
                                       bool useScale = false, short scaleX = 0, short scaleY = 0);
   int tryAdd2curGroupWithReplacement1(GroupEx *curGroup, int np, int ng, Transition transition, 
                                       size_t replacePos, bool useScale = false, short scaleX = 0, short scaleY = 0);
   bool isNewPairBetter(int new_transitionLevel, int old_transitionLevel, int new_sim, int old_sim);
   bool isNewPairBetter1(int new_err, int old_err, int new_sim, int old_sim);

   // check if current group is around delta 
   bool isGroupAroundDelta(BYTE numMinNearDelta[3]);
   int findDeltas(bool isProbe, ESK::Sign *delta[3]);

   bool compPairLen (int lenP, int lenG, int errorLevel, short *err = NULL)
   {
      if (err) *err = 0;
      int distErrTol = getDistTol (minAB(lenP, lenG), errorLevel);
      int dLen = abs (lenP - lenG);
      if (dLen > distErrTol)
         return false;
      if (err)
      {
         int maxLen = maxAB (lenP, lenG);
         *err =  maxLen ? dLen * 256 / maxLen : 0;
      }
      return true;
   }
//   bool isPairCompatible (int np, int ng);
   char getCurl(ESK::Sign *nest)
   {
      char curl = nest->Curl >> 1; 
      return (nest->Curl & 0x1) ? curl : -curl;
   }
   // check all possible incompatibility cases of singulars
//   void checkSingularCompatibility(BYTE &minQ);
   void getSingular (SingularData &singularData);
   void combineSingular(SingularData &data, bool probe2gallety, bool gallery2probe);
   int checkDeltas(SingularData &data);
   int checkCores(SingularData &data);
   // check flow direction concordance
//   void checkFlowConcordance();
   // get flow direction on gallery fingerprint in certain position
   bool getGalleryFlowDirection (int x0, int y0, int &angle);
   // check if fingerprints combine by delta, but have different loops (left and right)
   bool isDifLoops(BYTE &minQ);
   int* getTransitionArray(BYTE transition)
   {
      assert(transition < TL_3);
      if (transition >= TL_3) transition = NT;
      return TransitionMatrix[transition];
   }
   // get flow diverging in point that correspond to not found minutiae
   int getAreaFlowDiverging(bool isProbe, int n1);
   // get flow diverging for not found minutiae, taking into account only not found minutiae
   int getNotFoundFlowDiverging(bool isProbe, int n);
   // get minutiae that closest to (x, y) point
   int getClosestMinutiae(bool isProbe, int x, int y, int maxDist);
   // try to define how direction of n" correspond direction minutiae in m_curGroup
   bool getDirection(bool isProbe, int n, bool &sameDir);
   // return true if find "n" among nest links
   // and set sameDir to true if "n" has same direction as central point of m_curGroup
   bool getDirectionByNest (bool isProbe, int n, bool &sameDir);
   // get minutiae from m_curGroup that closest to (x, y) point
   int getClosestCurGroupMinutiae(bool isProbe, int x, int y, size_t maxDist);
   BYTE getSimThreshold(int numPassed, BYTE hist[256]);

   void sortKernelGroupsByNumItems (size_t maxGroups);
   void sortKernelGroupsBySumSim (size_t maxGroups);
   bool getNumMinutiaeAroundDelta (bool isProbe, BYTE numMinNearDelta[3], BYTE numDelta, ESK::Sign *delta[3]);

};

inline void Matcher100::checkBadArea(ESK::Sign *sing, int num, BYTE *area, int areaWidth, int areaHeight, 
                     int reach, int tol, bool *exclude)
{
   assert (num <= MAX_SINGULAR);
   MinutiaeShort min[MAX_SINGULAR];
   for (int i = 0; i < num; i++)
   {
      min[i].m_x     = (int)sing[i].Movx; 
      min[i].m_y     = (int)sing[i].Movy; 
      min[i].m_angle = (int)sing[i].Beta;
   }
   return checkBadArea (min, num, area, areaWidth, areaHeight, reach, tol, exclude);
}

inline void Matcher100::checkBadArea(MinutiaeShort *min, int num, BYTE *area, int areaWidth, int areaHeight, 
                     int reach, int tol, bool *exclude)
{
   int x = 0, y = 0, sum = 0;
   int maxX = areaWidth;
   int maxY = areaHeight;
   int rowLen = areaWidth;
   for(int n = 0; n < num; n++)
   {
      x = min[n].m_x / 8; // cannot use << because x or y can be negative
      y = min[n].m_y / 8;
      sum = 0;
      for (int j = y - reach; j <= y + reach; j++ ) 
      {
         if (j >= 0 && j < maxY) 
         {
            int shift = j * rowLen;
            for (int i = x - reach; i <= x + reach; i++) 
            {
               if (i >= 0 && i < maxX) 
                  if (area[shift + i] != 0x40) 
                     sum++;
            }
         }
      }
      exclude[n] = ( sum < tol);
   }
}

// return mirror deal of pink link
inline int Matcher100::getPinkDeal(ESK::Link *link, int l1, int *l2, int deal, MINUTIAE_TYPE type)
{
   if (isRight(type, l1))  // link on the right
   {
      switch (deal)
      {
      case 15:
         return 9;
      case 11:
         if (!isUp(type, l1))
         {
            *l2 -= 4;
            if(*l2 <= 0)
               return 0;
         }
         return 3;
      case 7:
         if (isUp(type, l1))
         {
            *l2 -= 4;
            if(*l2 <= 0)
               return 0;
         }
         return 3;
      case 3:
         return 11;
      default:
         assert(false);
         return 0;
      }
   }
   else                 // link on the left
   {
      switch (deal)
      {
      case 15:
         return 10;
      case 7:
         if (!isUp(type, l1))
         {
            *l2 -= 4;
            if(*l2 <= 0)
               return 0;
         }
         return 3;
      case 11:
         if (isUp(type, l1))
         {
            *l2 -= 4;
            if(*l2 <= 0)
               return 0;
         }
         return 3;
      case 3:
         return 7;
      default:
         assert(false);
         return 0;
      }
   }
   return 0;
}
// calculate ridge count
inline int Matcher100::calcRidgeCount_(int type, int link, int deal) 
{
   int rc = calcRidgeCount (type, link, deal);
   if (type == ENDING)
      return rc;

   if (link == 1 && rc == -1)
      return 0;
   if (link == 2 && rc == 1)
      return 0;
   return rc;
}
// calculate ridge count with take central point transition in attention 
inline int Matcher100::calcRidgeCountEx(Transition trans, int type, int link, int deal) 
{
   int rc = calcRidgeCount_(type, link, deal);
return rc;
   switch (trans)
   {
   case NT:
      return rc;
   case E2LB_1:
      if (!link)
      {
         if (rc > 0)
            return rc;
         else 
            return 0;
      }
      if (isRightLink[type][link])
         return rc;
      return rc + 1;
   case E2RB_1:
      if (!link)
      {
         if (rc > 0)
            return 0;
         else 
            return rc;
      }
      if (isRightLink[type][link])
         return rc - 1;
      return rc;
   case B2RE_1:
      if (link == 1)
      {
         if (rc == 0)
            return -1;
         else 
            return rc;
      }
      if (isRightLink[type][link])
         return rc;
      return rc - 1;
   case B2LE_1:
      if (link == 2)
      {
         if (rc < 0)
            return rc;
         else 
            return +1;
      }
      if (!link)
         return rc + 1;
      if (isRightLink[type][link])
         return rc + 1;
      return rc;
   case B2LB_2:
      if (link == 0)
      {
         if (rc < 0)
            return +1;
         else 
            return +2;
      }
      return rc + 1;
   case B2RB_2:
      if (link == 0)
      {
         if (rc > 0)
            return -1;
         else 
            return rc - 1;
      }
      if (link == 1)
      {
         if (rc > 0)
            return 0;
         else 
            return rc - 1;
      }
      return rc - 1;
   default:
      assert(false);
      return  0;
//*/
   }
}


#pragma pack(pop)
} //namespace accelMatch{

#endif // MATCHER_100_H_