#ifndef EXPAND_GROUP_H_
#define EXPAND_GROUP_H_

#include <assert.h>
#include <stdlib.h>

#include "coreSdk.h"


namespace accelMatch{
#pragma pack(push, 1) 

struct ExpandGroupPair
{
   BYTE         m_np;  
   BYTE         m_ng;  
   WORD         m_sim;
   short        m_conflictPos;
   WORD         m_conflictSim;
   int          m_numParentItems;  

   ExpandGroupPair() 
   { 
      clear();
   }
   //ExpandGroupPair (BYTE np, BYTE ng, BYTE sim, BYTE conflictPos) 
   //{ 
   //   m_np          = np;
   //   m_ng          = ng;
   //   m_sim         = sim; 
   //   m_conflictPos = conflictPos;
   //}
   void clear()
   {
      memset(this, 0, sizeof(ExpandGroupPair));
   }
};

static inline int compareExpandGroupPair (const void *val1, const void *val2) 
{
   ExpandGroupPair** p1 = (ExpandGroupPair**)val1;
   ExpandGroupPair** p2 = (ExpandGroupPair**)val2;
   return (int)((*p2)->m_sim) - (int)((*p1)->m_sim);  
} 
/*
   this set is suppose that new (np, ng) pair will be inserted in certain sequence:
   for one np, then for another  np1 > np etc.
*/
struct ExpandGroupPairSet
{
   ExpandGroupPair   m_array   [MAX_MINUTIAE * MAX_MINUTIAE];
   ExpandGroupPair  *m_p_array [MAX_MINUTIAE * MAX_MINUTIAE];
   size_t            m_numItems                             ;
   size_t            m_npStart [MAX_MINUTIAE]               ;
   size_t            m_npStop  [MAX_MINUTIAE]               ;
   bool              m_exist   [MAX_MINUTIAE]               ;
   int               m_current_np                           ;  
   
   ExpandGroupPairSet ()
   {
      clear();
      for(size_t i = 0; i < m_numItems; i++)
         m_p_array[i] = &m_array[i];
   }
   void clear()
   {
      m_numItems     = 0;
      m_current_np   = -1;
      memset (m_npStart, 0, sizeof(m_npStart[0]) * MAX_MINUTIAE);
      memset (m_npStop , 0, sizeof(m_npStop [0]) * MAX_MINUTIAE);
      memset (m_exist  , 0, sizeof(m_exist  [0]) * MAX_MINUTIAE);
   }
   size_t size()
   {
      return m_numItems;
   }
   void insert (BYTE np, BYTE ng, WORD sim, short conflictPos)//, WORD conflictSim, int numParentItems)  
   {
      if (m_current_np != np)        // np is changed
      {
         m_npStart[np] = m_numItems;
         m_current_np  = np        ; 
         m_exist  [np] = true;
      }
      m_array  [m_numItems].m_np             = np ;
      m_array  [m_numItems].m_ng             = ng ;
      m_array  [m_numItems].m_sim            = sim;
      m_array  [m_numItems].m_conflictPos    = conflictPos;
      //m_array  [m_numItems].m_conflictSim    = conflictSim;
      //m_array  [m_numItems].m_numParentItems = numParentItems;
      m_npStop [np] = m_numItems;
      m_numItems++;
   }
   int find (short np, short ng)
   {
      if (!m_exist[np])
         return -1;
      for(size_t i = m_npStart[np]; i <= m_npStop[np]; i++)
      {
         if (m_array[i].m_ng == ng)
            return (int)i;
      } 
      return -1;
   }
   void sort()
   {
      for(size_t i = 0; i < m_numItems; i++)
         m_p_array[i] = &m_array[i];

      qsort (m_p_array, m_numItems, sizeof(m_p_array[0]), compareExpandGroupPair); 
   }
   ExpandGroupPair* getItem(size_t pos)
   {
      return &m_array[pos];
   }
   ExpandGroupPair* getSortedItem(size_t pos)
   {
      return m_p_array[pos];
   }
};




#pragma pack(pop) 
} // namespace accelMatch{

#endif  // EXPAND_GROUP_H_



