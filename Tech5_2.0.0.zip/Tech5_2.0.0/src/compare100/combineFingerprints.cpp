#include "matcher100.h"

namespace accelMatch{

int Matcher100::combineFingerprintsByCurGroup(GroupEx *g, bool probe2gallety, bool gallery2probe, bool calcAll)
{
   assert(g);
   int xcP = 0, ycP = 0, xcG = 0, ycG = 0, angle = 0;
   g->getRotation(xcP, ycP, xcG, ycG, angle);
   return combineFingerprints(g, probe2gallety, gallery2probe, xcP, ycP, xcG, ycG, angle, calcAll);
}

int Matcher100::combineFingerprints(GroupEx *g, bool probe2gallety, bool gallery2probe, int xcP, int ycP, int xcG, int ycG, int angle, bool calcAll)
{
   if (probe2gallety) transferMinutiaes (g, m_minutiaeP    , m_minutiaePR, m_numNestP    , xcP, ycP, xcG, ycG, -angle, calcAll, true );
   if (gallery2probe) transferMinutiaes (g, m_minutiaeG    , m_minutiaeGR, m_numNestG    , xcG, ycG, xcP, ycP,  angle, calcAll, false);
   return angle;
}


// transfer minutiaes to another fingerprint
bool Matcher100::transferMinutiaes(GroupEx *g, ESK::Sign *srcMin, MinutiaeShort *dstMin, int num,
                           int srcXc, int srcYc, int dstXc, int dstYc, int angle, bool calcAll, bool isProbe)
{
   if (!srcMin || !dstMin)
      return false;
   angle = normAngle(angle);
   int scaleXc = 0, scaleYc = 0;
   getAreaScale (g, srcXc, srcYc, scaleXc, scaleYc, isProbe); 
   if (calcAll)
   {
      int scaleX = 0, scaleY = 0;
      for (int i = 0; i < num; i++ )
      {
         if (isProbe) getAreaScaleP (g, i, scaleX, scaleY); 
         else         getAreaScaleG (g, i, scaleX, scaleY); 
         transferPoint ((int)srcMin[i].Movx, (int)srcMin[i].Movy, (int)srcMin[i].Beta, 
                     dstMin[i].m_x, dstMin[i].m_y, dstMin[i].m_angle, 
                     srcXc, srcYc, dstXc, dstYc, 
                     angle, scaleX, scaleY, scaleXc, scaleYc, isProbe);
      }
   }
   else
   {
      size_t numItems = g->getNumItems();
      if (isProbe)
         for (size_t i = 0; i < numItems; i++ )
         {
            int np = g->getProbe (i);
            assert(np < num);
            transferPoint ((int)srcMin[np].Movx, (int)srcMin[np].Movy, (int)srcMin[np].Beta, 
                        dstMin[np].m_x, dstMin[np].m_y, dstMin[np].m_angle, 
                        srcXc, srcYc, dstXc, dstYc, 
                        angle, g->getScaleX(i), g->getScaleY(i), scaleXc, scaleYc, isProbe);
         }
      else
         for (size_t i = 0; i < numItems; i++ )
         {
            int ng = g->getGallery (i);
            assert(ng < num);
            transferPoint ((int)srcMin[ng].Movx, (int)srcMin[ng].Movy, (int)srcMin[ng].Beta, 
                        dstMin[ng].m_x, dstMin[ng].m_y, dstMin[ng].m_angle, 
                        srcXc, srcYc, dstXc, dstYc, 
                        angle, g->getScaleX(i), g->getScaleY(i), scaleXc, scaleYc, isProbe);
         }
   }
   return true;
}


// transfer point to another coordinate system
void Matcher100::transferPoint(int srcX, int srcY, int srcAngle, int &dstX, int &dstY, int &dstAngle,
                           int srcXc, int srcYc, int dstXc, int dstYc, int angle, int scaleX, int scaleY, int scaleXc, int scaleYc, bool isProbe)
{
   angle = normAngle(angle);
   int x = 0, y = 0;
   if (!scaleX) scaleX = 256;
   if (!scaleY) scaleY = 256;
   if (isProbe) // transfer probe to gallery
   {
      x = (srcX - srcXc) * (scaleX + scaleXc) / 512;
      y = (srcY - srcYc) * (scaleY + scaleYc) / 512;
   }
   else
   {
      x = (srcX - srcXc) * 512 / (scaleX + scaleXc);
      y = (srcY - srcYc) * 512 / (scaleY + scaleYc);
   }
   int r =  dist(x, y);
   int ang = atan (x, y);
   dstX = dstXc + cosm(r, ang + angle);
   dstY = dstYc + sinm(r, ang + angle);
   dstAngle = normAngle(srcAngle + angle);
}


} // namespace accelMatch{
