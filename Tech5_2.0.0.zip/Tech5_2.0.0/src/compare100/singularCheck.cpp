#include "matcher100.h"
#include "Julwin.h"
#include "Eskuse.h"
#include "deltaWorks100.h"

namespace accelMatch{

bool compPairLen (int lenP, int lenG, int errorLevel)
{
   int distErrTol = getDistTol (minAB(lenP, lenG), errorLevel);
   int dLen = abs (lenP - lenG);
   return (dLen <= distErrTol);
}

bool isFullPattern(SingularData &data)
{
   int numRequiredDeltas = 0;
   for(int i = 0; i < data.m_numCoreG; i++)
   {
      if      (data.m_coreG_t[i] == ESK::FW) numRequiredDeltas += 2;
      else if (data.m_coreG_t[i] == ESK::FL) numRequiredDeltas += 1;
   }
   return (numRequiredDeltas == data.m_numDeltaG);
}

bool areAllDeltasPresent(SingularData &data)
{
   if (data.m_numDeltaP >= 3)
      return true;
   return isFullPattern(data);
}

bool areAllCoresPresent(SingularData &data)
{
   if (data.m_numCoreP >= 3)
      return true;
   return isFullPattern(data);
}


//int getMinDeltaQualityG(SingularData &data)
//{
//   int minQ = 100;
//   for(int i = 0; i < param.m_numDeltaG; i++)
//      if (data.m_deltaG_p[i] < minQ)
//         minQ = data.m_deltaG_p[i];
//
//   return minQ;
//}

void getPolarCooordinates (int xc, int yc, int x, int y, int &rad, int &angle, int scale_xc = 256, int scale_yc = 256, int scale_x = 256, int scale_y = 256)
{
   if (!scale_xc) scale_xc = 256;
   if (!scale_yc) scale_yc = 256;
   if (!scale_x ) scale_x  = 256;
   if (!scale_y ) scale_y  = 256;
   int dx = (x - xc) * 512 / (scale_xc + scale_x);
   int dy = (y - yc) * 512 / (scale_yc + scale_y);
   rad = dist (dx, dy);
   angle = atan (dx, dy);
}

bool checkPolarCoordinates (int distP, int distG, int errorLevel, int angleP, int angleG, int groupAngle, int angleTol)
{
   if (!compPairLen (distP, distG, errorLevel))
      return false;
   if (minAB (distP, distG) > 20 && abs(normAngle(angleP - angleG - groupAngle)) > angleTol)
      return false;
   return true;
}

bool checkDeltaAngles(int angleDif, int deltaAngleTol)
{
   // often delta on latent has wrong direction, so compare all 3 choices
   int angleDif1 = angleDif - 120;
   int angleDif2 = angleDif - 240;
   return (abs(normAngle(angleDif)) <= deltaAngleTol || abs(normAngle(angleDif1)) <= deltaAngleTol || abs(normAngle(angleDif2) <= deltaAngleTol));
}



int Matcher100::checkDeltas(SingularData &data)
{
   int numMissDelta = 0;
   // if pattern is not full or some of gallery deltas in bad area (on gallery or on corresponded place on probe)
   // we cannot use penalty anyway (even if we are not found pair for some deltas)
   if (!areAllDeltasPresent(data))
      return 0;
   for(int j = 0; j < data.m_numCoreG; j++)  
      if (data.m_deltaG_exclude[j])           
         return 0;

   int dxP = 0, dxG = 0, dyP = 0, dyG = 0, distP = 0, distG = 0, angleP = 0, angleG = 0;
   int errorLevel = 0;
   //int deltaAngleTol = 40;
   int angleTol      = 12;
   unsigned int maxDist = 21;

   // check how deltaS on probe and gallery corresponded each other. Check by using two ways of combination deltas:
   // 1 - location calculated relatevile of center of ALL found minutiae
   // 2 - location calculated relatevile of center of found minutiae, those near corresponded delta
   // if both way cannot found a corresponded delta - we have miss delta
   for(int i = 0; i < data.m_numDeltaP; i++)
   {
      //if (param.m_deltaP_exclude[i])
      //   continue;
      getPolarCooordinates (data.m_xcP * 2, data.m_ycP * 2, data.m_deltaP_x[i] * 2, data.m_deltaP_y[i] * 2, distP, angleP);

      bool missDelta = true;
      for(int j = 0; j < data.m_numDeltaG; j++)
      {
         
         getPolarCooordinates (data.m_xcG * 2, data.m_ycG * 2, data.m_deltaG_x[i] * 2, data.m_deltaG_y[i] * 2, distG, angleG,
            data.m_centreScaleX * 2, data.m_centreScaleY * 2, data.m_deltaP_scaleX[i] * 2, data.m_deltaP_scaleY[i] * 2);
         if (!checkPolarCoordinates (distP, distG, errorLevel, angleP, angleG, data.m_angle, angleTol) &&
            dist(data.m_deltaPR_x[i] * 2, data.m_deltaPR_y[i] * 2, data.m_deltaG_x[j] * 2, data.m_deltaG_y[j] * 2) > maxDist)
            continue;
         //if (!checkDeltaAngles((int)param.m_deltaP_a[i] * 2- (int)param.m_deltaG_a[j] * 2 - param.m_angle, deltaAngleTol))
         //   continue;
          
         missDelta = false;
         break;
      }
      if (missDelta)
         numMissDelta++;
   }
   return numMissDelta;
}

int Matcher100::checkCores(SingularData &data)
{
   int numMissCore = 0;
   // if pattern is not full or some of gallery cores in bad area (on gallery or on corresponded place on probe)
   // we cannot use penalty anyway (even if we are not found pair for some cores)
   if (!areAllCoresPresent(data))      
      return 0;
   for(int j = 0; j < data.m_numCoreG; j++)  
      if (data.m_coreG_exclude[j])           
         return 0;

   int dxP = 0, dxG = 0, dyP = 0, dyG = 0, distP = 0, distG = 0, angleP = 0, angleG = 0;
   int errorLevel = 1;
   int coreAngleTol = 40;
   int angleTol     = 12;
   unsigned int maxDist = 42;
   // check how CORES on probe and gallery corresponded each other. Check by using two ways of combination:
   // 1 - location calculated relatevile of center of ALL found minutiae
   // 2 - location calculated relatevile of center of found minutiae, those near corresponded core
   // if both way cannot found a corresponded delta - we have miss core

   for(int i = 0; i < data.m_numCoreP; i++)
   {
      if (data.m_coreP_exclude[i])
         continue;
      getPolarCooordinates (data.m_xcP * 2, data.m_ycP * 2, data.m_coreP_x[i] * 2, data.m_coreP_y[i] * 2, distP, angleP);

      bool missCore = true;
      for(int j = 0; j < data.m_numCoreG; j++)
      {
         getPolarCooordinates (data.m_xcG * 2, data.m_ycG * 2, data.m_coreG_x[i] * 2, data.m_coreG_y[i] * 2, distG, angleG,
            data.m_centreScaleX * 2, data.m_centreScaleY * 2, data.m_coreP_scaleX[i] * 2, data.m_coreP_scaleY[i] * 2);
         if (!checkPolarCoordinates (distP, distG, errorLevel, angleP, angleG, data.m_angle, angleTol) &&
            dist(data.m_corePR_x[i] * 2, data.m_corePR_y[i] * 2, data.m_coreG_x[j] * 2, data.m_coreG_y[j] * 2) > maxDist)
            continue;
         // check core angles
         int angleDif = data.m_corePR_a[i] * 2 - data.m_coreG_a[j] * 2;
         if (abs(normAngle(angleDif)) > coreAngleTol)
            continue;         
         missCore = false;
         break;
      }
      if (missCore)
         numMissCore++;
   }
   return numMissCore;
}


// transfer singulars to another fingerprint
bool Matcher100::transferSingulars(GroupEx *g, ESK::Sign *srcSing, ESK::Sign *dstSing, int num,
                           int srcXc, int srcYc, int dstXc, int dstYc, int angle/*, float scale*/, bool isProbe)
{
   if (!srcSing || !dstSing)
      return false;
   angle = normAngle(angle);
   int x = 0, y = 0, a = 0, scaleX = 0, scaleY = 0, scaleXc = 0, scaleYc = 0;
   getAreaScale (g, srcXc, srcYc, scaleXc, scaleYc, isProbe);
   for (int i = 0; i < num; i++ )
   {
      getAreaScale (g, (int)srcSing[i].Movx, (int)srcSing[i].Movy, scaleX, scaleY, isProbe);
      transferPoint ((int)srcSing[i].Movx, (int)srcSing[i].Movy, (int)srcSing[i].Beta, 
                      x, y, a, srcXc, srcYc, dstXc, dstYc, angle, scaleX, scaleY, scaleXc, scaleYc, isProbe);
      dstSing[i].Movx = x;
      dstSing[i].Movy = y;
      dstSing[i].Beta = a;
   }
   return true;
}

// get minutiae those located near the corresponded singular
void Matcher100::getNearestMinutiae(GroupEx &g, ESK::Sign &sing, unsigned int maxDist)
{
   g.clear();
   int x0 = sing.Movx;
   int y0 = sing.Movy;
   size_t numItems = m_curGroup->getNumItems ();
   short np = 0, ng = 0;
   for(size_t i = 0; i < numItems; i++)
   {
      np = m_curGroup->getProbe(i); 
      if (dist(x0, y0, m_minutiaeP[np].Movx, m_minutiaeP[np].Movy) > maxDist)
         continue;
      ng = m_curGroup->getGallery (i);
      g.add (np, ng, NT);//, 0);
   }

}

void setCoreDealtaTransitionParam(SingularData &data, ESK::Sign &sing, int &numDelta, int &numCore, int x, int y, int angle)
{
   if (sing.Type == ESK::FD)
   {
      if (numDelta >= 3)
         return;
      data.m_deltaPR_x[numDelta] = (BYTE)(x     / 2);
      data.m_deltaPR_y[numDelta] = (BYTE)(y     / 2);
      //data.m_deltaPR_a[numDelta] = (BYTE)(angle / 2);
      numDelta++;
   }
   else
   {
      if (numCore >= 3)
         return;
      data.m_corePR_x[numCore] = (BYTE)(x     / 2);
      data.m_corePR_y[numCore] = (BYTE)(y     / 2);
      data.m_corePR_a[numCore] = (BYTE)(angle / 2);
      numCore++;
   }
}

// transfer singulars to another fingerprint based on minutiae those located near the corresponded singular
void Matcher100::transferSingularsByNearestMinutiae(SingularData &data, GroupEx *curGroup)
{
   GroupEx g;
   g.init (MAX_MINUTIAE, true);
   g.setDensity (m_dr);
   g.setNests        (m_minutiaeP, m_minutiaeG);
   g.setPairSet      (&m_pairSetP, &m_pairSetG);
   g.setNearSingular (m_nearSingularP, m_nearSingularG);

   unsigned int maxDist = 100;
   int xcP = 0, ycP = 0, xcG = 0, ycG = 0, angle = 0;
   int x = 0, y = 0, a = 0;
   int numDelta = 0, numCore = 0;
   int scaleXc = 0, scaleYc = 0;
   for (int i = 0; i < m_numSingularP; i++)
   {
      if (m_singularP[i].Type != ESK::FD && m_singularP[i].Type != ESK::FW && m_singularP[i].Type != ESK::FL)
         continue;
      getNearestMinutiae (g, m_singularP[i], maxDist);
      if (g.getNumItems() <= 3)
      {
         setCoreDealtaTransitionParam (data, m_singularP[i], numDelta, numCore, m_singularPR[i].Movx, m_singularPR[i].Movy, m_singularPR[i].Beta);
         continue;
      }
      g.getRotation(xcP, ycP, xcG, ycG, angle);
      getAreaScale(curGroup, xcP, ycP, scaleXc, scaleYc, true);
      transferPoint ((int)m_singularP[i].Movx, (int)m_singularP[i].Movy, (int)m_singularP[i].Beta, 
                     x, y, a, xcP, ycP, xcG, ycG, -angle, curGroup->getScaleX(i), curGroup->getScaleY(i), scaleXc, scaleYc, true);
      setCoreDealtaTransitionParam (data, m_singularP[i], numDelta, numCore, x, y, a);
   }
}


void Matcher100::combineSingular(SingularData &data, bool probe2gallety, bool gallery2probe)
{
   int xcP = 0, ycP = 0, xcG = 0, ycG = 0, angle = 0;
   m_curGroup->getRotation(xcP, ycP, xcG, ycG, angle);
   int averScaleX = 0, averScaleY = 0;
   getAreaScale (m_curGroup, xcP, ycP, averScaleX, averScaleY, true);
   data.m_centreScaleX = (BYTE)(averScaleX / 2);
   data.m_centreScaleY = (BYTE)(averScaleY / 2);
   if (probe2gallety)
   {
      memcpy (m_singularPR, m_singularP, sizeof(ESK::Sign) * m_numSingularP);
      transferSingulars (m_curGroup, m_singularP, m_singularPR, m_numSingularP, xcP, ycP, xcG, ycG, -angle, true);
      transferSingularsByNearestMinutiae (data, m_curGroup);
   }
   if (gallery2probe)
   {
      memcpy (m_singularGR, m_singularG, sizeof(ESK::Sign) * m_numSingularG);
      transferSingulars (m_curGroup, m_singularG, m_singularGR, m_numSingularG, xcG, ycG, xcP, ycP, angle, false);
   }
}

// find singulars thouse can be behind of clear area of another fingerprint
void Matcher100::findSingularExclude()
{
   for (size_t i = 0; i < m_numSingularP; i++)
      m_excludeSingP[i] = false;
   for (size_t i = 0; i < m_numSingularG; i++)
      m_excludeSingG[i] = false;

   int reach = 5;
   int tol = (2 * reach + 1) * (2 * reach + 1) * 5 / 6; 
   checkBadArea (m_singularPR, m_numSingularP, m_areaG, m_areaWidthG, m_areaHeightG, reach, tol, m_excludeSingP);
   checkBadArea (m_singularGR, m_numSingularG, m_areaP, m_areaWidthP, m_areaHeightP, reach, tol, m_excludeSingG);

   checkBadArea (m_singularP, m_numSingularP, m_areaP, m_areaWidthP, m_areaHeightP, reach, tol, m_excludeSingP);
   checkBadArea (m_singularG, m_numSingularG, m_areaG, m_areaWidthG, m_areaHeightG, reach, tol, m_excludeSingG);
}


void Matcher100::getSingular (SingularData &singularData)
{
   if (!m_numSingularP || !m_numSingularG)
      return;
   int xcP = 0, ycP = 0, xcG = 0, ycG = 0, angle= 0;
   m_curGroup->getRotation (xcP, ycP, xcG, ycG, angle, false);
   singularData.m_angle = angle;
   singularData.m_xcP = (BYTE)(xcP / 2);
   singularData.m_ycP = (BYTE)(ycP / 2);
   singularData.m_xcG = (BYTE)(xcG / 2);
   singularData.m_ycG = (BYTE)(ycG / 2);

   combineSingular(singularData, true, true);
   findSingularExclude();

   singularData.m_numDeltaP = 0;
   singularData.m_numCoreP = 0;
   int averScaleX = 0,  averScaleY = 0;
   for(int i = 0; i < m_numSingularP; i++)
   {     
      getAreaScale (m_curGroup, m_singularP[i].Movx, m_singularP[i].Movy,  averScaleX, averScaleY, true);
      if ((m_singularP[i].Type == ESK::FD) && singularData.m_numDeltaP < 3)
      {
         singularData.m_deltaP_x      [singularData.m_numDeltaP] = (BYTE)(m_singularP[i].Movx > 511 ? 255 : m_singularP[i].Movx / 2);
         singularData.m_deltaP_y      [singularData.m_numDeltaP] = (BYTE)(m_singularP[i].Movy > 511 ? 255 : m_singularP[i].Movy / 2);
         singularData.m_deltaP_scaleX [singularData.m_numDeltaP] = (BYTE)(averScaleX / 2);
         singularData.m_deltaP_scaleY [singularData.m_numDeltaP] = (BYTE)(averScaleY / 2);
         singularData.m_deltaP_exclude[singularData.m_numDeltaP] = m_excludeSingP[i];
         singularData.m_numDeltaP++;
      }
      else if ((m_singularP[i].Type == ESK::FW || m_singularP[i].Type == ESK::FL) && singularData.m_numCoreP < 3) 
      {
         singularData.m_coreP_x      [singularData.m_numCoreP] = (BYTE)(m_singularP[i].Movx > 511 ? 255 : m_singularP[i].Movx / 2);
         singularData.m_coreP_y      [singularData.m_numCoreP] = (BYTE)(m_singularP[i].Movy > 511 ? 255 : m_singularP[i].Movy / 2);
         singularData.m_coreP_scaleX [singularData.m_numDeltaP] = (BYTE)(averScaleX / 2);
         singularData.m_coreP_scaleY [singularData.m_numDeltaP] = (BYTE)(averScaleY / 2);
         singularData.m_coreP_exclude[singularData.m_numCoreP] = m_excludeSingP[i];
         singularData.m_numCoreP++;
      }
   }
   singularData.m_numDeltaG = 0;
   singularData.m_numCoreG = 0;
   for(int i = 0; i < m_numSingularG; i++)
   {     
      getAreaScale (m_curGroup, m_singularG[i].Movx, m_singularG[i].Movy,  averScaleX, averScaleY, false);
      if ((m_singularG[i].Type == ESK::FD) && singularData.m_numDeltaG < 3)
      {
         singularData.m_deltaG_x      [singularData.m_numDeltaG] = (BYTE)(m_singularG[i].Movx > 511 ? 255 : m_singularG[i].Movx / 2);
         singularData.m_deltaG_y      [singularData.m_numDeltaG] = (BYTE)(m_singularG[i].Movy > 511 ? 255 : m_singularG[i].Movy / 2);
         singularData.m_deltaG_exclude[singularData.m_numDeltaG] = m_excludeSingG[i];
         singularData.m_numDeltaG++;
      }
      else if ((m_singularG[i].Type == ESK::FW || m_singularG[i].Type == ESK::FL) && singularData.m_numCoreG < 3) 
      {
         singularData.m_coreG_x       [singularData.m_numCoreG] = (BYTE)(m_singularG[i].Movx > 511 ? 255 : m_singularG[i].Movx / 2);
         singularData.m_coreG_y       [singularData.m_numCoreG] = (BYTE)(m_singularG[i].Movy > 511 ? 255 : m_singularG[i].Movy / 2);
         singularData.m_coreG_a       [singularData.m_numCoreG] = (BYTE)(m_singularG[i].Beta / 2);
         singularData.m_coreG_t       [singularData.m_numCoreG] = m_singularG[i].Type;
         singularData.m_coreG_exclude [singularData.m_numCoreG] = m_excludeSingG[i];
         singularData.m_numCoreG++;
      }
   }
}

//void Matcher100::checkSingularCompatibility(BYTE &minQ)
//{
//   SingularData singularData;
//   getSingular(singularData);
//   m_param.m_numMissDeltas = checkDeltas (singularData); 
//   m_param.m_numMissCores  = checkCores  (singularData); 
//
//   m_param.m_incompatibleSingular = 0;
//   if (isDifLoops(minQ))   //probe and gallery both have loop pattern type, but one left and another right
//   {
//      m_param.m_incompatibleSingular = 1;
//      m_param.m_incompatibleSingularMinQ = minQ;
//   }
//  
//}
bool Matcher100::isDifLoops(BYTE &minQ)
{
   bool isProbeLeftLoop    = m_patternTypeP == ESK::LOOP_L || m_patternTypeP == ESK::CURV_L;
   bool isProbeRightLoop   = m_patternTypeP == ESK::LOOP_R || m_patternTypeP == ESK::CURV_R;
   bool isGalleryLeftLoop  = m_patternTypeG == ESK::LOOP_L || m_patternTypeG == ESK::CURV_L;
   bool isGalleryRightLoop = m_patternTypeG == ESK::LOOP_R || m_patternTypeG == ESK::CURV_R;
   bool isProbeLoop   = isProbeLeftLoop   || isProbeRightLoop;
   bool isGalleryLoop = isGalleryLeftLoop || isGalleryRightLoop;

   if (!isProbeLoop || !isGalleryLoop)
      return false;
   if (isProbeLeftLoop && isGalleryLeftLoop)
      return false;
   if (isProbeRightLoop && isGalleryRightLoop)
      return false;

   // so, probe and gallery both hava loop pattern type, but a different types (one left another right)

   // get minimal quality of loops and deltas
   minQ = 100;
   for(int singP = 0; singP < m_numSingularP; singP++)
   {
      if (m_singularP[singP].Type != ESK::FL && m_singularP[singP].Type != ESK::FD)
         continue;
      if (m_singularP[singP].Prob < minQ)
         minQ = m_singularP[singP].Prob;
   }
   for(int singG = 0; singG < m_numSingularG; singG++)
   {
      if (m_singularG[singG].Type != ESK::FL && m_singularG[singG].Type != ESK::FD)
         continue;
      if (m_singularG[singG].Prob < minQ)
         minQ = m_singularG[singG].Prob;
   }
   // check if deltas combined 
   for(int singP = 0; singP < m_numSingularP; singP++)
   {
      if (m_singularP[singP].Type != ESK::FD)
         continue;
      for(int singG = 0; singG < m_numSingularG; singG++)
      {
         if (m_singularG[singG].Type != ESK::FD)
            continue;
         if (abs(m_singularP[singP].Movx - m_singularGR[singG].Movx) > 20)
            continue;
         if (abs(m_singularP[singP].Movy - m_singularGR[singG].Movy) > 20)
            continue;
         if (abs(normAngle(m_singularP[singP].Beta - m_singularGR[singG].Beta)) > 20)
            continue;
         return true;
      }
   }
   return false;
}

// check if current group is around delta 
bool Matcher100::isGroupAroundDelta(BYTE numMinNearDelta[3])
{
   // don't do anything if group is big enough for reliable conclusion
   if (m_curGroup->getNumItems() >= 32)  
      return false;
   // get all deltas
   ESK::Sign *deltaP[3], *deltaG[3];
   int numDeltaP = findDeltas(true,  deltaP);
   int numDeltaG = findDeltas(false, deltaG);
   if (!numDeltaP && !numDeltaG)
      return false;
   // check if some part of m_curGroup near a delta
   if (   !getNumMinutiaeAroundDelta (true, numMinNearDelta, numDeltaP, deltaP) 
       && !getNumMinutiaeAroundDelta (false, numMinNearDelta, numDeltaG, deltaG) 
       ) return false;
   return true;
}


int Matcher100::findDeltas(bool isProbe, ESK::Sign *delta[3])
{
   int  &numSingular      = isProbe ? m_numSingularP : m_numSingularG;
   ESK::Sign *singular    = isProbe ? m_singularP    : m_singularG;

   int numDelta = 0;
   for(int i = 0; i < numSingular; i++)
   {
      if (singular[i].Type != ESK::FD)
         continue;
      delta[numDelta++] = &singular[i];
      if (numDelta == 3)
         break;
   }

   return numDelta;
}



} // namespace accelMatch{
