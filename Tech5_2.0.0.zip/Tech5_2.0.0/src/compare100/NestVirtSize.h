#ifndef NEST_VIRT_SIZE_H_
#define NEST_VIRT_SIZE_H_

#include <assert.h>
#include <stdlib.h>

#include "coreSdk.h"

#define MAX_NEST_VIRT_SIZE_SET        200


namespace accelMatch{
#pragma pack(push, 1) 

struct NestVirtSize
{
   BYTE       m_np;  
   BYTE       m_ng;  
   BYTE       m_virtGroupSize;

   NestVirtSize() 
   { 
      clear();
   }
   NestVirtSize (BYTE np, BYTE ng, BYTE virtGorupSize) 
   { 
      m_np            = np;
      m_ng            = ng;
      m_virtGroupSize = virtGorupSize;
   }
   void clear()
   {
      memset(this, 0, sizeof(NestVirtSize));
   }
};
static inline int compareNestVirtSize (const void *val1, const void *val2) 
{
   return (int)(((NestVirtSize*)val2)->m_virtGroupSize) - (int)(((NestVirtSize*)val1)->m_virtGroupSize);  
} 
struct NestVirtSizeSet
{
   NestVirtSize     m_nestVirtSizeArray[MAX_NEST_VIRT_SIZE_SET];
   size_t           m_numItems;
   
   NestVirtSizeSet ()
   {
      clear();
   }
   void clear()
   {
      m_numItems = 0;
   }
   size_t size() const
   {
      return m_numItems;
   }
   void insert (BYTE np, BYTE ng, BYTE virtGroupSize)
   {
      assert(m_numItems < MAX_NEST_VIRT_SIZE_SET);
      m_nestVirtSizeArray[m_numItems].m_np            = np           ;
      m_nestVirtSizeArray[m_numItems].m_ng            = ng           ;
      m_nestVirtSizeArray[m_numItems].m_virtGroupSize = virtGroupSize;
      m_numItems++;
   }
   int find (BYTE np, BYTE ng) const
   {
      for(size_t i = 0; i < m_numItems; i++)
      {
         if (m_nestVirtSizeArray[i].m_np == np && m_nestVirtSizeArray[i].m_ng == ng)
            return (int)i;
      }
      return -1;
   }

   void sort()
   {
      qsort(m_nestVirtSizeArray, m_numItems, sizeof(m_nestVirtSizeArray[0]), compareNestVirtSize); 
   }
   NestVirtSize* getItem(size_t num) 
   {
      assert(num < m_numItems);
      return &m_nestVirtSizeArray[num];
   }
   void erase(size_t num)
   {
      m_nestVirtSizeArray[num].clear();
   }
   NestVirtSizeSet& operator= (const NestVirtSizeSet& nestVirtSizeSet)
   {
      m_numItems = nestVirtSizeSet.size();
      memcpy(this, &nestVirtSizeSet, sizeof(NestVirtSize) * m_numItems);
      return *this;
   }
};


#pragma pack(pop) 
} // namespace accelMatch{

#endif  // NEST_VIRT_SIZE_H_



