/*
   deltaWorks.h - declare the functions for work with delta

   Copyright (C) 2008 Sonda Technologies Ltd.
   Author A.Mosunov
   18.06.2008
*/
#ifndef  DELTA_WORKS_H_
#define DELTA_WORKS_H_

#include "group100.h"
#include "Unwrap.h"

namespace accelMatch{
#pragma pack(push,_CORE_PACKING)



#pragma pack(pop)
} //namespace accelMatch{


#endif // DELTA_WORKS_H_