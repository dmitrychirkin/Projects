/************************************************************************



************************************************************************/
#include <memory.h>
#include "myprimitives100.h"

#pragma pack(push, _CORE_PACKING)

namespace Primitive {
   void AllResults::operator= ( const AllResults tmp_AllResults )
   {
      this->areWhorlsOnOppositSides = tmp_AllResults.areWhorlsOnOppositSides;
      this->matches                 = tmp_AllResults.matches;
      this->pairCount               = tmp_AllResults.pairCount;
      this->qMainDensity            = tmp_AllResults.qMainDensity;
      this->sMainDensity            = tmp_AllResults.sMainDensity;
      this->qTotalDensity           = tmp_AllResults.qTotalDensity;
      this->sTotalDensity           = tmp_AllResults.sTotalDensity;

      memcpy( &this->measureErrors , &tmp_AllResults.measureErrors , sizeof( Primitive::Err )                        );
      memcpy(  this->pairRes       ,  tmp_AllResults.pairRes       , sizeof( PairDescription ) * MY_MAX_SINGULAR * 2 );
   }
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
   void AllResults::Clean()
   {
      this->pairCount                  = 0;
      this->areWhorlsOnOppositSides    = false;
      this->matches                    = 0;
      this->measureErrors.Clean();

      memset( pairRes, 0, sizeof( pairRes));
   }
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
   void PairDescription::Clean() { memset( this, 0, sizeof( PairDescription ) ); }
//////////////////////////////////////////////////////////////////////////
//		Structure for holding Integral and minutiae coordinates
//////////////////////////////////////////////////////////////////////////
   Coordinate Coordinate::operator+ ( Coordinate coord )
   {
      Coordinate tmp;
      tmp.X = this->X + coord.X;
      tmp.Y = this->Y + coord.Y;
      return tmp;
   }
//
   Coordinate Coordinate::operator- ( Coordinate coord )
   {
      Coordinate tmp;
      tmp.X = this->X - coord.X;
      tmp.Y = this->Y - coord.Y;
      return tmp;
   }
//
   void Coordinate::operator+= ( Coordinate coord ) 
   {
      this->X += coord.X;
      this->Y += coord.Y;
   }
//
   void Coordinate::operator-= ( Coordinate coord ) 
   {
      this->X -= coord.X;
      this->Y -= coord.Y;
   }
//
//
   int Coordinate::DistanceTo( const Coordinate tmp )
   {
      return accelMatch::sqri( SqrDistanceTo( tmp )  );
   }
//
   int Coordinate::AngleTo( const Coordinate tmp )
   {
      return accelMatch::atan( tmp.X - this->X, tmp.Y - this->Y );
   }  
//////////////////////////////////////////////////////////////////////////
//				Definition of MySign Struct Methods
//////////////////////////////////////////////////////////////////////////
   inline MySign MySign::operator- ( const Coordinate & coord ) 
   {
      MySign tmp;
      tmp.X     = this->X - coord.X;
      tmp.Y     = this->Y - coord.Y;
      tmp.Probability = this->Probability;
      tmp.Angle = this->Angle;
      tmp.Type  = this->Type;
      return tmp;
   }
//
   inline MySign MySign::operator- ( const MySign & coord ) 
   {
      return *this - ( Coordinate )coord;
   }
//
   MySign& MySign::operator= ( const MySign & tmp ) 
   {
      this->X                 = tmp.X;
      this->Y                 = tmp.Y;
      this->Angle             = tmp.Angle;
      this->distanceToBadArea = tmp.distanceToBadArea;
      this->Probability       = tmp.Probability;
      this->Type              = tmp.Type;
      this->isReliable        = tmp.isReliable;
      return *this;
   }
//////////////////////////////////////////////////////////////////////////
//				Definition of MyObject Struct
//////////////////////////////////////////////////////////////////////////
MyObject::MyObject ()
{
   this->SingularArr       = new MySign    [ MY_MAX_SINGULAR ];
   this->MinutiaeArr       = new MySign    [ MY_MAX_MINUTIAE ];
   this->m_BadArea         = new BYTE      [ MY_MAX_BAD_AREA ];
   this->m_MinutiaeRefArr  = new Coordinate[ MY_MAX_MINUTIAE ];
   this->m_SingularRefArr  = new MySign    [ MY_MAX_SINGULAR ];
   this->MinutiaeRefArr    = m_MinutiaeRefArr;
   this->SingularRefArr    = m_SingularRefArr;
   this->BadArea           = m_BadArea;
   this->BadAreaSize       = MY_MAX_BAD_AREA;
   Clean();      
}
//
MyObject::MyObject (MyObject * tmp)
{
   *this = *tmp;
}
//
MyObject::~MyObject ()
{
   if ( this->SingularArr ) delete [] this->SingularArr;
   if ( this->MinutiaeArr ) delete [] this->MinutiaeArr;
   if ( this->m_BadArea   ) delete [] this->m_BadArea;
   if ( this->m_MinutiaeRefArr ) delete [] this->m_MinutiaeRefArr;
   if ( this->m_SingularRefArr ) delete [] this->m_SingularRefArr;
   this->m_BadArea         = 0;
   this->m_MinutiaeRefArr  = 0;
   this->SingularArr       = 0;
   this->MinutiaeArr       = 0;
   this->m_SingularRefArr  = 0;
}
//
void MyObject::operator= ( const MyObject & tmp )
{
   this->PapillarDensity = tmp.PapillarDensity;
   this->CountMinutiae   = tmp.CountMinutiae;
   this->CountSingular   = tmp.CountSingular;
   this->MaxX            = tmp.MaxX;
   this->MaxY            = tmp.MaxY;
   this->Vector          = tmp.Vector;
   this->Scale           = tmp.Scale;
   this->Quality         = tmp.Quality;
   this->PatternType     = tmp.PatternType;        
   this->BadAreaSize     = tmp.BadAreaSize;

   memcpy( this->CountInts,         tmp.CountInts,      sizeof( this->CountInts )  );
   memcpy( this->SingularArr,       tmp.SingularArr,    sizeof( this->SingularArr[ 0 ] ) * MY_MAX_SINGULAR );
   memcpy( this->MinutiaeArr,       tmp.MinutiaeArr,    sizeof( this->MinutiaeArr[ 0 ] ) * this->CountMinutiae );
   memcpy( this->m_SingularRefArr,  tmp.SingularRefArr, sizeof( this->m_SingularRefArr[ 0 ] ) * MY_MAX_SINGULAR );
   memcpy( this->m_MinutiaeRefArr,  tmp.MinutiaeRefArr, sizeof( this->m_MinutiaeRefArr[ 0 ] ) * this->CountMinutiae );
   memcpy( this->BadArea,           tmp.BadArea,        this->BadAreaSize );
}
//
void MyObject::Clean()
{
   this->PapillarDensity = 0;
   this->CountMinutiae   = 0;
   this->CountSingular   = 0;
   this->MaxX            = 0;
   this->MaxY            = 0;
   this->Vector.X        = 0;
   this->Vector.Y        = 0;
   this->Vector.Angle    = 0;
   this->Scale           = 0;
   this->Quality         = 0;
   this->PatternType     = 0;
   this->BadArea         = m_BadArea;
   memset( CountInts, 0, sizeof( CountInts[ 0 ] ) * MY_MAX_SINGULAR );
}
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
}
#pragma pack(pop)
