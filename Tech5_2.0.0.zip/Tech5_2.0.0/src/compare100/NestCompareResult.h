#ifndef NEST_COMP_RESULT_H_
#define NEST_COMP_RESULT_H_

#include <assert.h>
#include <stdlib.h>

#include "coreSdk.h"
#include "staticData100.h"

namespace accelMatch{
#pragma pack(push, 1) 

class NestCompareResult
{
   WORD                   m_bestSim;
   //BYTE                   m_fullSim;
   short                  m_angleDif;
   Transition             m_bestTransition;
   HitGroup              *m_group[TL_2];                  // group of similar minutiae pairs
   bool                   m_isMatched;  

public:
   NestCompareResult()
   {
      memset(this, 0, sizeof(NestCompareResult));
   }
   HitGroup* alloc(Transition transition)
   {
      assert(!m_group[transition] && transition < TL_2);
      //assert(transition < TL_2);
      //if (!m_group[transition])
      m_group[transition] = new (std::nothrow)HitGroup;
      if (!m_group[transition])
         throw MyException(MA_LOW_MEMORY);
      m_group[transition]->setMainTransition(transition);
      return m_group[transition];
   }

   //NestCompareResult(const NestCompareResult &result)
   //{
   //   m_group = NULL;
   //   alloc();
   //   *this = result;
   //}
   void release()
   {
      for(int i = 0; i < TL_2; i++)
         if (m_group[i]) delete m_group[i], m_group[i] = NULL;
   }
   ~NestCompareResult()
   {
      release();
   }
   void clear()
   {
      release();
      m_bestSim        = 0;
      m_angleDif       = 0;
      m_bestTransition = UNKN;
      m_isMatched      = false;
   }
   short getAngleDif() const
   {
      return m_angleDif;
   }
   void setAngleDif(int angleDif) 
   {
      m_angleDif = angleDif;
   }
   Transition getBestTransition() const
   {
      return m_bestTransition;
   }
   void setBestTransition(Transition transition)
   {
      m_bestTransition = transition;
   }
   void  setBestSim(WORD sim)
   {
      m_bestSim = sim;
   }
   WORD  getBestSim() const
   {
      return m_bestSim;
   }
   HitGroup *getGroup(Transition transition)
   {
      if (transition >= TL_2)
         return NULL;
      return m_group[transition];
   }
   void setMatchResult(HitGroup *g)
   {
      assert(g);
      if (g->getSim() > m_bestSim)
      {
         m_bestSim        = g->getSim           ();
         m_bestTransition = g->getMainTransition();
      }
      else if (m_bestTransition == UNKN)  // in case g->getSim() = m_bestSim = 0
         m_bestTransition = g->getMainTransition();
      m_isMatched = true;
   }
   bool isMatched() const
   {
      return m_isMatched;
   }
};


#pragma pack(pop) 
} // namespace accelMatch{

#endif  // NEST_COMP_RESULT_H_


