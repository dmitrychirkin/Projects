#include "matcher100.h"
#include "adjustParams100.h"
#include "win2lin.h"

namespace accelMatch{



BYTE Matcher100::estimateNotFoundAreaProb(int x, int y, ESK::Sign *minutaie, int numNest)
{
   // found nearest minutiae
   int maxDist = 100, minDist = 20, len = 0, sumProb = 0, sumWeight = 0, weight = 0;
   for(int i = 0; i < numNest; i++)
   {
      len = dist(x, y, minutaie[i].Movx, minutaie[i].Movy);
      if (len >= maxDist)
         continue;
      if   (len < minDist) weight = 10;
      else                 weight = 10 * minDist / len;   
      sumProb += (minutaie[i].Prob & 0x3f) * weight;
      sumWeight += weight;
   }
   return sumWeight ? sumProb / sumWeight : 0;
}



int Matcher100::getBestUnreliablePair(ESK::Sign *minutiae, ESK::Link *links, int numNests, int *taken, int n0, BYTE &bestRc, BYTE &bestSize)
{
   int n = 0, bestN = -1;
   bestRc = 255, bestSize = 255;

   int cage = links[n0].Cage;
   for (int ln = 0; ln < cage; ln++)
   {
      ESK::byte_t deal = links[n0].Knot[ln].Deal;
      if (!deal)
         continue;
      n = links[n0].Knot[ln].Item;
      if (n == n0 || taken[n] || n >= numNests)
         continue;
      if (isSameDirection (deal, (MINUTIAE_TYPE)minutiae[n0].Type, ln))
         continue;
      ESK::twin_t size = links[n0].Knot[ln].Size;
      if (size > MAX_UNRELIABLE_PAIR_DIST || size > bestSize)
         continue;
      BYTE rc = (BYTE)(abs(calcRidgeCountEx (NT, minutiae[n0].Type, ln, deal))); 
      if (rc > MAX_UNRELIABLE_PAIR_RC)
         continue;
      if (size == bestSize && bestRc < rc)
         continue;
      bestSize = (BYTE)size;
      bestRc = rc;
      bestN = n;
   }

   return bestN;
}

void Matcher100::fillUnreliablePairData(MinData *data, int n1, int n2, BYTE size, BYTE rc, bool isProbe)
{
   UnreliablePairStatus status[2];
   getUnreliableStatus(n1, n2, isProbe, status);
   data[n1].m_unreliablePairStatus = status[0];
   data[n2].m_unreliablePairStatus = status[1];
   data[n1].m_unreliableSize       = data[n2].m_unreliableSize       = size  ; 
   data[n1].m_unreliableRc         = data[n2].m_unreliableRc         = rc    ; 
}

void Matcher100::getUnreliableStatus(int n1, int n2, bool isProbe, UnreliablePairStatus status[2])
{
   bool found1 = (isProbe ? m_curGroup->findProbe (n1) : m_curGroup->findGallery (n1)) != -1;
   bool found2 = (isProbe ? m_curGroup->findProbe (n2) : m_curGroup->findGallery (n2)) != -1;
   bool *exclude = isProbe ? m_excludeP : m_excludeG;

   if       (found1     ) status[1] = FOUND_UNRELIABLE_PAIR;
   else if  (exclude[n1]) status[1] = EXCLUDED_UNRELIABLE_PAIR; 
   else                   status[1] = NOT_FOUND_UNRELIABLE_PAIR;

   if       (found2     ) status[0] = FOUND_UNRELIABLE_PAIR;
   else if  (exclude[n2]) status[0] = EXCLUDED_UNRELIABLE_PAIR; 
   else                   status[0] = NOT_FOUND_UNRELIABLE_PAIR;

}

void Matcher100::findUnreliablePairs(ESK::Sign *minutiae, ESK::Link *links, int numNests, int *taken, int n0, MinData *minData, bool isProbe)
{
   BYTE bestRc1 = 255, bestSize1 = 255;
   int n = getBestUnreliablePair(minutiae, links, numNests, taken, n0, bestRc1, bestSize1);
   if (n == -1)
      return;
   BYTE bestRc2 = 255, bestSize2 = 255;
   int n1 = getBestUnreliablePair(minutiae, links, numNests, taken, n, bestRc2, bestSize2);
   if (n1 == n0 || n1 == -1)
   {
      fillUnreliablePairData(minData, n0, n, bestSize1, bestRc1, isProbe);
      taken[n0] = taken[n] = true;
      return;
   }
   // pair (n1, n) better than (n0; n) - add it 
   // and try to find a new pair for n0 again
   fillUnreliablePairData(minData, n, n1, bestSize2, bestRc2, isProbe);
   taken[n] = taken[n1] = true;

   return findUnreliablePairs(minutiae, links, numNests, taken, n0, minData, isProbe);
}

void Matcher100::findAllUnreliablePairs(ESK::Sign *minutiae, ESK::Link *links, int *taken, int numNests, bool *exclude, MinData *minData, bool isProbe)
{
   int takenEx[MAX_MINUTIAE];
//   memcpy (takenEx, taken, sizeof(takenEx[0]) * numNests);
   memset (takenEx, 0, sizeof(takenEx[0]) * numNests);
   for(int n = 0; n < numNests; n++)
   {
      if (takenEx[n] || exclude[n])
         continue;
      findUnreliablePairs(minutiae, links, numNests, takenEx, n, minData, isProbe);
   }
}

void Matcher100::fillMinutiaeData(MinData &data, FOUND_STATUS status, WORD probability)
{
   data.m_foundStatus   = status                  ;
   data.m_probability    = (ESK::byte_t)probability; 
}

void Matcher100::fillFoundMinutiaeData(size_t pos, FOUND_STATUS status)
{
   short np = m_curGroup->getProbe  (pos);
   short ng = m_curGroup->getGallery(pos);
   fillMinutiaeData (m_minDataP[np], status, m_probP[np]);
   fillMinutiaeData (m_minDataG[ng], status, m_probG[ng]);
}

void Matcher100::fillFoundMinutiaesData()
{
   size_t firstGroupSize = m_curGroup->getFirstGroupSize();
   size_t mainGroupSize  = m_curGroup->getMainGroupSize();
   size_t numFound       = m_curGroup->getNumItems();
   m_param.m_numFound = (BYTE)numFound;
   size_t pos = 0;
   short np = 0, ng = 0;
   for(; pos < firstGroupSize; pos++)
      fillFoundMinutiaeData (pos, FOUND_FIRST);
   for(; pos < mainGroupSize; pos++)
      fillFoundMinutiaeData (pos, FOUND_MAIN);
   for(; pos < numFound; pos++)
      fillFoundMinutiaeData (pos, FOUND);
}

void Matcher100::fillNotFoundMinutiaesData()
{
   BYTE probAR = 0;
   for(int np = 0; np < m_numNestP; np++)
   {
      if (m_takenP[np]) 
         continue;
      if (m_excludeP[np]) 
      {
         fillMinutiaeData (m_minDataP[np], EXCLUDED, m_probP[np]); 
         m_param.m_numExcludedP++;
         continue; 
      }   
         
      probAR = estimateNotFoundAreaProb(m_minutiaePR[np].m_x, m_minutiaePR[np].m_y, m_minutiaeG, m_numNestG);
      fillMinutiaeData (m_minDataP[np], NOT_FOUND, minAB(m_probP[np], probAR));
   }
   for(int ng = 0; ng < m_numNestG; ng++)
   {
      if (m_takenG[ng]) 
         continue;
      if (m_excludeG [ng]) 
      { 
         fillMinutiaeData (m_minDataG[ng], EXCLUDED, m_probG[ng]); 
         m_param.m_numExcludedG++;
         continue; 
      }   
      probAR = estimateNotFoundAreaProb(m_minutiaeGR[ng].m_x, m_minutiaeGR[ng].m_y, m_minutiaeP, m_numNestP);
      fillMinutiaeData (m_minDataG[ng], NOT_FOUND, minAB(m_probG[ng], probAR));
   }
}

void Matcher100::fillUnreliableMinutiaesData()
{
   findAllUnreliablePairs(m_minutiaeP, m_linkP, m_takenP, m_numNestP, m_excludeP, m_minDataP, true);
   findAllUnreliablePairs(m_minutiaeG, m_linkG, m_takenG, m_numNestG, m_excludeG, m_minDataG, false);
}

void Matcher100::fillMinutiaesData()
{
   for(int i = 0; i < m_numNestP; i++)
      m_minDataP[i].clear();
   for(int i = 0; i < m_numNestG; i++)
      m_minDataG[i].clear();
   fillFoundMinutiaesData     ();
   fillNotFoundMinutiaesData  ();
   fillUnreliableMinutiaesData();
   
}

void checkMinData(int firstGroupSize, int mainGroupSize, int foundNum, int numNest, MinData *minData)
{
   int _firstGroupSize         =  0;
   int _mainGroupSize          = 0;   
   int _foundNum               = 0;
   int _numExcluded            = 0; 
   int _notFound                = 0;
   for(int i = 0; i < numNest; i++)
   {
      switch(minData[i].m_foundStatus)
      {
      case FOUND_FIRST:
         _firstGroupSize++;
         break;
      case FOUND_MAIN:
         _mainGroupSize++;
         break;
      case FOUND:
         _foundNum++;
         break;
      case EXCLUDED:
         _numExcluded++;
         break;
      case NOT_FOUND:
         _notFound++;
         break;
      default:
         assert(false);
         break;
      }
   }
   _mainGroupSize += _firstGroupSize;
   _foundNum      += _mainGroupSize;
   assert(_firstGroupSize == firstGroupSize && _mainGroupSize == mainGroupSize && _foundNum == foundNum);
   assert(numNest == _foundNum + _numExcluded + _notFound);
}

void checkMinDatas(int firstGroupSize, int mainGroupSize, int foundNum, int numNestP, MinData *minDataP, int numNestG, MinData *minDataG)
{
#ifdef _DEBUG
   checkMinData(firstGroupSize, mainGroupSize, foundNum, numNestP, minDataP);
   checkMinData(firstGroupSize, mainGroupSize, foundNum, numNestG, minDataG);
#endif
}

void Matcher100::prepareScoreParameters(CalcScoreTypeEnum calcScoreType)
{
   m_param.clear();
   m_param.calcScoreType = (BYTE)calcScoreType;

   int firstGroupSize         = (int)m_curGroup->getFirstGroupSize();
   int mainGroupSize          = (int)m_curGroup->getMainGroupSize();   
   int numItems               = (int)m_curGroup->getNumItems();
   int groupSize[3];
   groupSize[0] = firstGroupSize;
   groupSize[1] = mainGroupSize - firstGroupSize;
   groupSize[2] = numItems      - mainGroupSize; 

   // at first check topology, because some items from current group can be removed 
   calcTopologySim(firstGroupSize, mainGroupSize, numItems);
   findExclude();
   fillMinutiaesData();
   checkMinDatas(firstGroupSize, mainGroupSize, numItems, m_numNestP, m_minDataP, m_numNestG, m_minDataG);
   m_param.m_numNestP = m_numNestP;
   m_param.m_numNestG = m_numNestG;
   m_param.m_qualityP = m_qualityP;
   m_param.m_qualityG = m_qualityG;
  
   // calculate diffenrences for minutiae position, angle, type etc
   calcPairDif        (firstGroupSize, mainGroupSize, numItems, groupSize);
   calcPairRelAngleDif(firstGroupSize, mainGroupSize, numItems, groupSize);

   //BYTE minSingularQ = 0;
   //checkSingularCompatibility(minSingularQ);
   //checkFlowConcordance();
}

int Matcher100::calculateScore()
{
   return accelMatch::calculateScore(m_param, m_minDataP, m_minDataG, 
      g_k_score_pg_q     , 
      g_k_score_pg       ,
      g_k_score          , 
      g_k_score_common   , 
      g_k_score_pg_bounds,
      g_k_score_q_bounds ,
      g_k_score_up_f_p   ,
      g_k_score_up_f_g    );
}

// calculate similarity score
int Matcher100::calcScore(CalcScoreTypeEnum calcScoreType)
{
   prepareScoreParameters(calcScoreType);
#ifdef ADJUST
   accelMatch::saveParameters (m_param, m_minDataP, m_minDataG);
#endif
   return calculateScore();
}



void Matcher100::calcTopologySim (int firstGroupSize, int mainGroupSize, int numItems)
{
   int xcP, ycP, xcG, ycG, angle;
   m_curGroup->getRotation (xcP, ycP, xcG, ycG, angle);
   short np = 0, ng = 0;
   int fullSim = 0;
   int count[3], sum[3];
   short transitionDif = 0;
   memset (count, 0, sizeof(count));
   memset (sum  , 0, sizeof(sum  ));
   Transition transition;
   int maxDist = m_dr * 5, divergeDif = 0;
   for(int i = 0; i < numItems; i++)
   {
      m_curGroup->getPair(i, np, ng);
      transition = m_curGroup->getTransition(i);
      fullSim = getFullNestCompareResult (np, ng, transition, angle, transitionDif);

      if (i < firstGroupSize)
      {
         sum[0] += fullSim;
         //m_param.m_transitionDif[0] += transitionDif;
         count[0]++;
      }
      else if (i < mainGroupSize)
      {
         sum[1] += fullSim;
         //m_param.m_transitionDif[1] += transitionDif;
         count[1]++;
      }
      else
      {
         sum[2] += fullSim;
         //m_param.m_transitionDif[2] += transitionDif;
         count[2]++;
      }
   }
   for(int i = 0; i < 3; i++)
      m_param.m_topologySim[i] = count[i] ? sum[i] / count[i] : 0;
 }

void Matcher100::calcPairDif (int firstGroupSize, int mainGroupSize, int numItems, int groupSize[3])
{
//   calcScale(m_curGroup);
   int errR = 0;
   int angleP = 0, angleG = 0, angleGR = 0, angleErr = 0, minAngleErr = 0, angleErr1 = 0;
   int distP  = 0, distG  = 0, maxDist  = 0, dDist  = 0;
   int distPR = 0, distGR = 0, maxDistR = 0, dDistR = 0;
   int distErrSumR        [3];
   int angleErrSum        [3];
   int angleErrSum1       [3];
   int minRelAngleErrSum  [3];
   int sumQ               [3];
   memset (distErrSumR         , 0, sizeof(distErrSumR         ));
   memset (minRelAngleErrSum   , 0, sizeof(minRelAngleErrSum   ));
   memset (angleErrSum         , 0, sizeof(angleErrSum         ));
   memset (angleErrSum1        , 0, sizeof(angleErrSum1        ));
   memset (sumQ                , 0, sizeof(sumQ                ));

   short np0 = 0, ng0 = 0, np = 0, ng = 0;
   int prob = 0, prob0 = 0;
   int xcP = 0, ycP = 0, xcG = 0, ycG = 0;
   int groupAngle = 0;
   m_curGroup->getRotation(xcP, ycP, xcG, ycG, groupAngle); 

   int index = 0;
   for(BYTE k = 0; k < numItems; k++)
   {
      m_curGroup->getPair (k, np0, ng0);
      prob0 = m_probP[np0] + m_probG[ng0];

      for(BYTE i = k + 1; i < numItems; i++)
      {
         if      (k < firstGroupSize && i < firstGroupSize) index = 0;
         else if (k < mainGroupSize  && i < mainGroupSize ) index = 1;
         else                                               index = 2;

         m_curGroup->getPair (i, np, ng);
         prob = prob0 + m_probP[np] + m_probG[ng];
         distP = m_pairSetP.getLen   (np, np0);
         distG = m_pairSetG.getLenEx (ng, ng0);
         maxDist = maxAB(distP, distG); 
         if (maxDist < m_dr * 2)
            continue;
         angleP = m_pairSetP.getAngle    (np0, np);
         angleG = m_pairSetG.getAngleEx(ng0, ng);
         angleGR = normAngle (atan(m_minutiaeGR[ng0].m_x - m_minutiaeGR[ng].m_x, m_minutiaeGR[ng0].m_y - m_minutiaeGR[ng].m_y));
         // calculate angle errors
         angleErr  = abs(normAngle (angleP - angleG- groupAngle));
         minAngleErr = abs(normAngle(
                        ((int)m_minutiaeP[np].Beta - (int)m_minutiaeP[np0].Beta) - 
                        ((int)m_minutiaeG[ng].Beta - (int)m_minutiaeG[ng0].Beta)
                        )) / 2;
         angleErr1  = abs(normAngle ((angleP - m_minutiaeP[np].Beta) - (angleG  - m_minutiaeG [ng].Beta)));
         

         distGR = dist(m_minutiaeGR[ng0].m_x, m_minutiaeGR[ng0].m_y, m_minutiaeGR[ng].m_x, m_minutiaeGR[ng].m_y);
         dDist  = abs(distP - distG );
         dDistR = abs(distP - distGR);
         maxDistR = maxAB(distP, distGR); 

         // calculate distance error with scale taking into account
         errR = maxDistR ? 100 * dDistR / maxDistR : 0; 
         distErrSumR       [index] += errR         * prob;
         minRelAngleErrSum [index] += minAngleErr  * prob;
         angleErrSum       [index] += angleErr     * prob;
         angleErrSum1      [index] += angleErr1    * prob;
         sumQ              [index] +=                prob;
      }
   }
   int val = 0;
   for(int i = 0; i < 3; i++)
   {
      val = distErrSumR [i] * 3 / (sumQ [i] + 1);
      m_param.m_distErrR     [i] = val <= 255 ? val : 255;

      val = minRelAngleErrSum   [i] * 4 / (sumQ [i] + 1);
      m_param.m_minRelAngleErr  [i] = val <= 255 ? val : 255;

      val = angleErrSum   [i] / (sumQ [i] + 1);
      m_param.m_angleErr  [i] = val <= 255 ? val : 255;

      val = angleErrSum1  [i] / (sumQ [i] + 1);
      m_param.m_angleErr1 [i] = val <= 255 ? val : 255;

   }
}

void Matcher100::calcPairRelAngleDif (int firstGroupSize, int mainGroupSize, int numItems, int groupSize[3])
{
   int angleP = 0, angleG = 0, angleErr = 0, index = 0;
   short np0 = 0, ng0 = 0, np1 = 0, ng1 = 0, np2 = 0, ng2 = 0;
   int prob = 0, sumQ[3], sum[3];
   int dist1 = 0, dist2 = 0, dist3 = 0, maxDist = 0;
   memset (sumQ   , 0, sizeof(sumQ  ));
   memset (sum    , 0, sizeof(sum   ));

   for(BYTE k0 = 0     ; k0 < numItems; k0++ )
   for(BYTE k1 = k0 + 1; k1 < numItems; k1++)
   {
      if      (k0 < firstGroupSize && k1 < firstGroupSize) index = 0;
      else if (k0 < mainGroupSize  && k1 < mainGroupSize ) index = 1;
      else                                                 index = 2;

      m_curGroup->getPair (k0, np0, ng0);
      m_curGroup->getPair (k1, np1, ng1);
      maxDist = maxAB(m_pairSetP.getLen(np0, np1), m_pairSetG.getLenEx(ng0, ng1)); 
      if (maxDist < m_dr * 2 || maxDist > m_dr * 20)
         continue;
      for(BYTE k2 = k1 + 1; k2 < numItems; k2++)
      {
         m_curGroup->getPair (k2, np2, ng2);
         maxDist = maxAB(m_pairSetP.getLen(np0, np2), m_pairSetG.getLenEx(ng0, ng2)); 
         if (maxDist < m_dr * 2 || maxDist > m_dr * 20)
            continue;
         prob = m_probP[np0] + m_probP[np1] + m_probP[np2] + 
                m_probG[ng0] + m_probG[ng1] + m_probG[ng2];
         // calculate errors
         angleP = normAngle (m_pairSetP.getAngle     (np0, np1) - m_pairSetP.getAngle    (np0, np2));
         angleG = normAngle (m_pairSetG.getAngleEx (ng0, ng1) - m_pairSetG.getAngleEx(ng0, ng2));
         angleErr = abs (normAngle(angleP - angleG));
         if      (k0 < firstGroupSize && k1 < firstGroupSize) index = 0;
         else if (k0 < mainGroupSize  && k1 < mainGroupSize ) index = 1;
         else                                                 index = 2;

         if (maxDist < m_dr * 2 || maxDist > m_dr * 10)
            continue;
         sum   [index] += angleErr * prob;
         sumQ  [index] += prob;
      }
   }
   for(int i = 0; i < 3; i++)
   {
      int val = sum   [i] * 2 / (sumQ  [i] + 1);
      m_param.m_relAngleErr    [i] = val <= 255 ? val : 255;
   }
}


/*
// find size of area that main group is taken
int Matcher100::getMainGroupSquare()
{
//   int num = m_curGroup->getMainGroupSize();
   int num = m_curGroup->getMarker(0);
   int diag[2];
   memset (diag, 0, sizeof(diag));
   // find the first diagonal
   int maxP1 = 0, maxP2 = 0;
   short np1 = 0, np2 = 0, ng = 0;
   int lenP = 0;
   for (int i = 0; i < num; i++)
   {
      m_curGroup->getPair (i, np1, ng);
      for (int j = i + 1; j < num; j++)
      {
         m_curGroup->getPair (j, np2, ng);
         lenP = m_pairSetP.getLen(np1, np2);
         if (lenP > diag[0])
         {
            diag[0] = lenP;
            maxP1 = np1;
            maxP2 = np2;
         }
      }
   }
   // find the second diagonal
   int a1 = m_pairSetP.getAngle(maxP1, maxP2);
   int maxDist = 0;
   for (int i = 0; i < num; i++)
   {
      m_curGroup->getPair (i, np1, ng);
      if (np1 == maxP1 || np1 == maxP2)
         continue;
      maxDist = abs(sinm (m_pairSetP.getLen(maxP2, np1), a1 - m_pairSetP.getAngle(maxP2, np1)));
      if (maxDist > diag[1])
      {
         diag[1] = maxDist;
      }
   }
   return diag[0] * (diag[1] ? diag[1] : 10);
}
*/
/*
// find the borders of points for combined fingerprint
void Matcher100::getCombineSize (short &combWidth, short &combHeight) 
{
   int top = SHRT_MAX, left = SHRT_MAX;
   int right = 0, bottom = 0; 
   int x = 0, y = 0;
   // find borders for gallery fingerprint
   for(int ng = 0; ng < m_numNestG; ng++)
   {
      x = (int)m_nestG[ng].Movx;
      y = (int)m_nestG[ng].Movy;
      if (x < left)
         left = x;
      if (x > right)
         right = x;
      if (y < top)
         top = y;
      if (y > bottom)
         bottom = y;
   }
   // find borders for probe fingerprint
   for(int np = 0; np < m_numNestP; np++)
   {
      x = m_minutiaePR[np].m_x;
      y = m_minutiaePR[np].m_y;
      if (x < left)
         left = x;
      if (x > right)
         right = x;
      if (y < top)
         top = y;
      if (y > bottom)
         bottom = y;
   }
   combWidth  = right  - left;
   combHeight = bottom - top;
}
*/

//static int max = 0;
void Matcher100::calcNestSim (int np, int ng, HitGroup &hitGroup, NotHit *notHitP, NotHit *notHitG, bool final)
{
   hitGroup.setSim(0);
   // clean notHit group
   clearNotHitGroup(hitGroup, notHitP, notHitG, final);

   // calculate sum of probability for hit items
   int sumHitProb = 0;
   int hitSim = getHitProbabilities (hitGroup, final, sumHitProb);
   // calculate sum of probability for not hit items
   int numNotHitMin = 0;
   int sumNotHitProb = getNotHitProbabilities (np, ng, notHitP, notHitG, numNotHitMin, final, 5 * m_dr);

   if (!hitSim)
      return;
   int sim = hitSim * sumHitProb / (sumHitProb + sumNotHitProb); 

   if (sim < 0        ) sim =         0;
   if (sim > USHRT_MAX) sim = USHRT_MAX;
   hitGroup.setSim((WORD)sim);
}


// calculate sum of probability for hit items
int Matcher100::getHitProbabilities (HitGroup &g, bool finalCalc, int &sumProb)
{
   sumProb = 0;
   short np1 = 0, ng1 = 0;
   int num = g.getNumItems();
   if (!num)
      return 0;
   int sim = 0, prob = 0, sum = 0;
   Transition transition = NT;
   int errR = 0, errA = 0, errA1 = 0;

   for(int n = 0; n < num; n++)
   {
      g.getPair (n, np1, ng1);
      prob = m_probP[np1] + m_probG[ng1];
      sumProb += prob;
      errR  = 256 - g.getErrR  (n);
      errA  = 256 - g.getErrA  (n);
      errA1 = 256 - g.getErrA1 (n);
      if (errR < 0 || errA < 0) sim = 0;
      else                      sim = int(prob * sqrt(errR * errA * errA1) / 256); 
      transition = g.getTransition(n);

      if      (transition <  TL_1  ) sum += 24 * sim;
      else if (transition <  TL_2  ) sum += 16 * sim;
      else if (transition <  TL_3  ) sum +=  8 * sim;
      else if (transition <  TL_4  ) sum +=  8 * sim;
      else if (transition <= MPT   ) sum +=  2 * sim;
   }
   return sumProb ? sum * num / sumProb : 0;
}

// calculate sum of probability for not hit items
int Matcher100::getNotHitProbabilities (int np0, int ng0, NotHit *notHitP, NotHit *notHitG, int &count, bool final, int maxDist)
{
   count = 0;
   int numSameDirP = 0, numSameDirG = 0, sumProb = 0; 
   for(int np = 0; np < m_numNestP; np++)
   {
      if (!notHitP[np].notHit)
         continue;
      sumProb += m_probP[np];
      count++;
   }
   for(int ng = 0; ng < m_numNestG; ng++)
   {
      if (!notHitG[ng].notHit)
         continue;
      sumProb += m_probG[ng];
      count++;
   }
   if (!final)
      return sumProb;

   for(int np = 0; np < m_numNestP; np++)
   {
      if (!notHitP[np].notHit || m_pairSetP.getLen (np0, np) > maxDist)
         continue;
      if   (notHitP[np].isSameDir) numSameDirP++;
      else                         numSameDirP--;
   }
   for(int ng = 0; ng < m_numNestG; ng++)
   {
      if (!notHitG[ng].notHit || m_pairSetG.getLen (ng0, ng) > maxDist)
         continue;
      if   (notHitG[ng].isSameDir) numSameDirG++;
      else                         numSameDirG--;
   }
   switch (abs(numSameDirP - numSameDirG))
   {
   case 0:
      return sumProb;
   case 1:
      return sumProb * 2;
   case 2:
      return sumProb * 2;
   case 3:
      return sumProb * 4;
   default:
      return sumProb * 8;
   }
}



} // namespace accelMatch{
