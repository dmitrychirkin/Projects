//////////////////////////////////////////////////////////////////////////
//
//
//////////////////////////////////////////////////////////////////////////
#ifndef PARAM_TUNE_H
#define PARAM_TUNE_H

#include <stdio.h>
#include <memory.h>

#include "MyPrimitives100.h"
#include "Comparator100.h"

using namespace Primitive;

namespace Comparator {
#pragma pack(push, _CORE_PACKING)
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
class PairDescript {
public:
   int      dist;
   int      angle;
   int      density;
   bool     isFound;
   bool     isInTransition;
   bool     isProcessingError;

   Primitive::MySign qSign;
   Primitive::MySign sSign;

   PairDescript () { Clean(); }

   void Clean(){ memset( this, 0, sizeof( PairDescript ) ); }
};
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
class ListRecord
{   
public:
   ListRecord()
   {
      this->m_Similarity               = 0;
      this->m_Correction               = 0;
      this->m_IsGenuine                = false;
      this->m_QGroup                   = 0;
      this->m_SGroup                   = 0;
      this->pairCount                  = 0;
      this->areWhorlsOnOppositSides    = false;
      this->qPatternType               = 0;
      this->sPatternType               = 0;
      this->sScale                     = 0;
      this->qScale                     = 0;
      this->qMainDensity               = 0;
      this->sMainDensity               = 0;
      this->qTotalDensity              = 0;
      this->sTotalDensity              = 0;
      this->qQuality                   = 0;
      this->sQuality                   = 0;  
      this->qSize.X                    = 0;
      this->qSize.Y                    = 0;   
      this->sSize.X                    = 0;
      this->sSize.Y                    = 0;
      this->matches                    = 0;

      this->measureErrors.Clean();
   }

   float             m_Similarity           ;
   float             m_Correction           ;
   bool              m_IsGenuine            ;
   BYTE              m_QGroup               ;
   BYTE              m_SGroup               ;
   bool              areWhorlsOnOppositSides;
   int               pairCount              ;
   BYTE              matches                ;
   BYTE              qPatternType           ;
   BYTE              sPatternType           ;
   BYTE              qQuality               ;
   BYTE              sQuality               ;
   BYTE              sTotalDensity          ;
   BYTE              qTotalDensity          ;
   float             sScale                 ;
   float             qScale                 ;
   BYTE              sMainDensity           ;
   BYTE              qMainDensity           ;
   Err               measureErrors          ;
   Coordinate        qSize                  ;
   Coordinate        sSize                  ;

   PairDescript      pairRes[ MY_MAX_SINGULAR * 2 ] ;
//////////////////////////////////////////////////////////////////////////
   void FillIN( Comparator::CompareDataHolder * cdHolder )
   {
      this->m_Similarity               = 0;
      this->m_Correction               = 0;
      this->m_IsGenuine                = false;
      this->pairCount                  = cdHolder->m_AllResults.pairCount;
      this->areWhorlsOnOppositSides    = cdHolder->m_AllResults.areWhorlsOnOppositSides;
      this->qPatternType               = cdHolder->queryObj->PatternType;
      this->sPatternType               = cdHolder->searchObj->PatternType;
      this->qScale                     = cdHolder->queryObj->Scale;
      this->sScale                     = cdHolder->searchObj->Scale;
      this->qMainDensity               = cdHolder->m_AllResults.qMainDensity;
      this->sMainDensity               = cdHolder->m_AllResults.sMainDensity;
      this->sTotalDensity              = cdHolder->m_AllResults.qTotalDensity;;
      this->qTotalDensity              = cdHolder->m_AllResults.qTotalDensity;;
      this->qQuality                   = cdHolder->queryObj->Quality;
      this->sQuality                   = cdHolder->searchObj->Quality;  
      this->measureErrors              = cdHolder->m_AllResults.measureErrors;
      this->qSize.X                    = cdHolder->queryObj->MaxX;
      this->qSize.Y                    = cdHolder->queryObj->MaxY;   
      this->sSize.X                    = cdHolder->searchObj->MaxX;
      this->sSize.Y                    = cdHolder->searchObj->MaxY;
      this->matches                    = cdHolder->m_AllResults.matches;

      for ( int i = 0; i < this->pairCount; i++ )
      {
         this->pairRes[ i ].dist              = cdHolder->m_AllResults.pairRes[ i ].dist              ;
         this->pairRes[ i ].angle             = cdHolder->m_AllResults.pairRes[ i ].angle             ;
         this->pairRes[ i ].density           = cdHolder->m_AllResults.pairRes[ i ].density           ;
         this->pairRes[ i ].isFound           = cdHolder->m_AllResults.pairRes[ i ].isFound           ;
         this->pairRes[ i ].isInTransition    = cdHolder->m_AllResults.pairRes[ i ].isInTransition    ;
         this->pairRes[ i ].isProcessingError = cdHolder->m_AllResults.pairRes[ i ].isProcessingError ;
         this->pairRes[ i ].qSign             = *( cdHolder->m_AllResults.pairRes[ i ].qSign )        ;
         if ( this->pairRes[ i ].isFound )
            this->pairRes[ i ].sSign          = *( cdHolder->m_AllResults.pairRes[ i ].sSign )        ;
      }
   }
//////////////////////////////////////////////////////////////////////////
   void FillOUT( Comparator::CompareDataHolder * cdHolder )
   {
      cdHolder->m_AllResults.pairCount                = this->pairCount;
      cdHolder->m_AllResults.areWhorlsOnOppositSides  = this->areWhorlsOnOppositSides ;
      cdHolder->queryObj->PatternType                 = this->qPatternType;
      cdHolder->searchObj->PatternType                = this->sPatternType;
      cdHolder->queryObj->Quality                     = this->qQuality;
      cdHolder->searchObj->Quality                    = this->sQuality;
      cdHolder->queryObj->Scale                       = this->qScale;
      cdHolder->searchObj->Scale                      = this->sScale;
      cdHolder->m_AllResults.sTotalDensity            = this->sTotalDensity;
      cdHolder->m_AllResults.qTotalDensity            = this->qTotalDensity;
      cdHolder->m_AllResults.measureErrors            = this->measureErrors;
      cdHolder->m_AllResults.sMainDensity             = this->sMainDensity;
      cdHolder->m_AllResults.qMainDensity             = this->qMainDensity;
      cdHolder->queryObj->MaxX                        = this->qSize.X;
      cdHolder->queryObj->MaxY                        = this->qSize.Y;   
      cdHolder->searchObj->MaxX                       = this->sSize.X;
      cdHolder->searchObj->MaxY                       = this->sSize.Y;
      cdHolder->m_AllResults.matches                  = this->matches;

      for ( int i = 0; i < this->pairCount; i++ )
      {
         cdHolder->m_AllResults.pairRes[ i ].dist              = this->pairRes[ i ].dist;
         cdHolder->m_AllResults.pairRes[ i ].angle             = this->pairRes[ i ].angle;
         cdHolder->m_AllResults.pairRes[ i ].density           = this->pairRes[ i ].density;
         cdHolder->m_AllResults.pairRes[ i ].isFound           = this->pairRes[ i ].isFound;
         cdHolder->m_AllResults.pairRes[ i ].isInTransition    = this->pairRes[ i ].isInTransition;
         cdHolder->m_AllResults.pairRes[ i ].isProcessingError = this->pairRes[ i ].isProcessingError;
         cdHolder->m_AllResults.pairRes[ i ].qSign             = & ( this->pairRes[ i ].qSign );
         cdHolder->m_AllResults.pairRes[ i ].sSign             = & ( this->pairRes[ i ].sSign );
      }
   }
//////////////////////////////////////////////////////////////////////////
};
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
class IndexCalculator {
public:
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
static float GetIndex( Comparator::CompareDataHolder * cdHolder, float* params, float* statistics = 0 )
{
   float corr = 0;
   try { 
      Comparator::CompareBySingular::PrepareForTuning( cdHolder );
      if ( ( corr = Comparator::CompareBySingular::CheckForScaleMismatches( cdHolder ) ) >= 0 )
      {
         if ( Comparator::CompareBySingular::isLowQualityImages( cdHolder ) ) 
             corr = Comparator::CompareBySingular::CalculateIndexCorrection( cdHolder );
         else
             corr = 0;
      }

      corr = Comparator::CompareBySingular::FinalSift( corr );
   }
   catch ( ... ) { corr = 0; }
   return corr;
}
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
static void DoStatistics( PairDescription * res, float tmpIndex , int matchCount, float* statistics  )
{
   MySign   qSign;
   MySign   sSign;

   if ( !res->isFound ) { statistics[ 6 ] ++; return;  }

   int statPos = tmpIndex > 0 ? 0 : 1;
   switch ( CompareBySingular::GetProbabilityCase( res->qSign, res->sSign ) )
   {
      case   1 : 
               {
                  statistics[ 0 + statPos ] ++; break;
               }
      case  -1 : 
               {
                  statistics[ 2 + statPos ] ++; break;
               }
      case   0 : 
               {
                  statistics[ 4 + statPos ] ++; break;
               }
   }
}
//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
   };
#pragma pack(pop)
}
#endif 