#ifndef CONFLICT_POS_H_ 
#define  CONFLICT_POS_H_ 

#include "group100.h"

namespace accelMatch{

#define MAX_PAIRS    10

class ConflictPos
{
   PairEx2  m_pairs[MAX_PAIRS    ];
   size_t   m_pos  [MAX_ERROR_POS];
   size_t   m_numPos;
   size_t   m_numPairs;

public:
   ConflictPos()
   {
      memset (this, 0, sizeof(ConflictPos));
   }
   size_t getNumPairs()
   {
      return m_numPairs;
   }
   size_t getNumPos()
   {
      return m_numPos;
   }
   PairEx2* getPair (size_t pos)
   {
      assert (pos < m_numPairs);
      return &m_pairs[pos];
   }
   size_t getPos (size_t pos)
   {
      assert (pos < m_numPos);
      return m_pos[pos];
   }
   size_t* getPosArray ()
   {
      return m_pos;
   }
   int getProfit()
   {
      return (int)m_numPairs - (int)m_numPos; 
   }

   int findPos (size_t pos)
   {
      for (size_t i = 0; i < m_numPos; i++)
         if (m_pos[i] == pos)
            return (int)i;
      return -1;
   }
   int findPair (Pair *pair)
   {
      for (size_t i = 0; i < m_numPairs; i++)
         if (m_pairs[i] == *pair)
            return (int)i;
      return -1;
   }
   void set (int np, int ng, Transition transition, short scaleX, short scaleY, NumSet<size_t> &skipPos, NumSet<size_t> &errorPos)
   {
      m_pairs[0].m_np         = np; 
      m_pairs[0].m_ng         = ng; 
      m_pairs[0].m_transition = transition; 
//      m_pairs[0].m_transitionDif = transitionDif;
      m_pairs[0].m_scaleX        = scaleX; 
      m_pairs[0].m_scaleY        = scaleY; 
      m_numPairs = 1;
      m_numPos = 0;
      for(size_t i = 0; i < skipPos.getNumItems(); i++)
         m_pos[m_numPos++] = (int)skipPos.getItem(i);
      for (size_t i = m_numPos; i < MAX_ERROR_POS && i < errorPos.getNumItems(); i++)
         m_pos[m_numPos++] = (int)errorPos.getItem(i);
   }
   void update (NumSet<size_t> &errorPos)
   {
      for (size_t i = 0; m_numPos < MAX_ERROR_POS && i < errorPos.getNumItems(); i++)
      {
         if (findPos((int)errorPos.getItem(i)) != -1)
            continue;
         m_pos[m_numPos++] = (int)errorPos.getItem(i);
      }
   }
   bool isPosEqual(ConflictPos &conflictPos)
   {
      if (m_numPos != conflictPos.m_numPos)
         return false;
      for (size_t i = 0; i < m_numPos; i++)
         if (findPos (conflictPos.m_pos[i]) == -1)
            return false;
      return true;
   }
   bool addPair (ConflictPos &conflictPos)
   {
      for(size_t i = 0; i < conflictPos.m_numPairs; i++)
      {
         if (m_numPairs >= MAX_PAIRS)
            return false;
         m_pairs[m_numPairs++] = conflictPos.m_pairs[i];
      }
      return true; 
   }
   //int isIncluded(ConflictPos &conflictPos) 
   //{
   //   if (conflictPos.m_numPos <= m_numPos)
   //   {
   //      size_t pos = 0;
   //      for(size_t i = 0; i < conflictPos.m_numPos; i++)
   //      {
   //         if (find(conflictPos.m_pos[i]) == -1)
   //            return 0;
   //      }
   //      return 1; // this is included conflictPos
   //   }
   //   else
   //   {
   //      size_t pos = 0;
   //      for(size_t i = 0; i < m_numPos; i++)
   //      {
   //         if (conflictPos.find(m_pos[i]) == -1)
   //            return 0;
   //      }
   //      return 2; // conflictPos is included this
   //   }
   //}
};

class ConflictPosSet
{
   size_t      m_maxItems;
   size_t      m_numItems;
   ConflictPos *m_conflictPos;

public:
   ConflictPosSet()
   {
      memset(this, 0, sizeof(ConflictPosSet));
   }
   ~ConflictPosSet()
   {
      if (m_conflictPos) delete [] m_conflictPos, m_conflictPos = NULL;
   }
   bool init (size_t maxItems)
   {
      m_maxItems = maxItems;
      return alloc();
   }
   bool alloc()
   {
      assert(m_maxItems > 0);
      m_conflictPos = new ConflictPos[m_maxItems];
      return m_conflictPos != NULL;
   }
   int findPair (ConflictPos &conflictPos)
   {
      for (size_t i = 0; i < m_numItems; i++)
      {
         size_t size = conflictPos.getNumPairs();
         for (size_t j = 0; j < size; j++)
            if (m_conflictPos[i].findPair (conflictPos.getPair (j)) != -1)
               return (int)i;
      }
      return -1;
   }
   int findPos (ConflictPos &conflictPos)
   {
      for (size_t i = 0; i < m_numItems; i++)
      {
         if (m_conflictPos[i].isPosEqual (conflictPos))
            return (int)i;
      }
      return -1;
   }
   bool insert(ConflictPos &conflictPos)
   {
      //for(size_t i = 0; i < m_numItems; i++)
      //{
      //   switch(m_conflictPos[i].isIncluded(conflictPos))
      //   {
      //   case 0:
      //      continue;
      //   case 1:            // ConflictPosSet already has item that >= conflictPos - return 
      //      return true; 
      //   case 2:            // ConflictPosSet has item that < conflictPos- replace and return
      //      memcpy(&m_conflictPos[i], &conflictPos, sizeof(ConflictPos));
      //      return true;
      //   default:
      //      break;
      //   }
      //}
      if (findPair (conflictPos) != -1) // alredy have record for this np/ng pair
         return true;
      int pos = findPos (conflictPos);
      if (pos != -1)                   // alredy have record for this pos but with new pair
         return m_conflictPos[pos].addPair (conflictPos);

      // no such items, create a new one
      if (m_numItems >= m_maxItems)
         return false;
      memcpy(&m_conflictPos[m_numItems++], &conflictPos, sizeof(ConflictPos));
      return true;
   }
   size_t getNumItems()
   {
      return m_numItems;
   }
   int getProfit(size_t pos)
   {
      assert (pos < m_numItems);
      return m_conflictPos[pos].getProfit();
   }
   ConflictPos* getItem (size_t pos)
   {
      assert (pos < m_numItems);
      return &m_conflictPos[pos];
   }
};

} // namespace accelMatch{


#endif //CONFLICT_POS_H_ 