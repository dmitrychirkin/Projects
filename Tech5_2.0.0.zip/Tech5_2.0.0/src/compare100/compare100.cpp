/*****************************************************************************
	compare100.cpp - implementation of Compare100 class.
	Compare100 implements the one to one finger matching algorithm of Core Matching SDK
              using ma100 alogithm  

*******************************************************************************/
#include <math.h>

#include "compare100.h"
#include "sfsDef.h"
#include "Matcher100.h"
#include "getFusedScore.h"

#ifdef	ROCKEY
	#include "key_func.h"
#endif	//	ROCKEY

namespace accelMatch{
#pragma pack(push,_CORE_PACKING)


Compare100::Compare100()
{
	m_matcher   = NULL;
   m_templ     = NULL;
   m_init      = false;
}

Compare100::~Compare100()
{
   free();
}

int Compare100::alloc()
{
   free();
   try
   {
      m_matcher = new(std::nothrow) Matcher100;
      m_templ   = new(std::nothrow) BYTE [MAX_TEMPLATE_SIZE_100];
   }
   catch(int &e)
   {
      return e;
   }
   if (!m_matcher || !m_templ)
      return MA_LOW_MEMORY;
   return MA_OK;
 }


void Compare100::free()
{
	if (m_matcher ) delete    m_matcher , m_matcher   = NULL;
	if (m_templ   ) delete [] m_templ   , m_templ     = NULL;
}


/* 
	initialize work with Compare100 class function
	Function returns MA_OK - if function succeeds, error code - otherwise
*/
int Compare100::init (void *accelHandle)
{
   if (m_init) return MA_OK;
   int protect[MAX_PROTECT_LEN];
   memset (protect, 0, sizeof(protect));
   int pp[TL_3][MAX_NUM_LINKS] = 
   {
      {  // NT - no transition
   //    0     1     2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29    30    31    32    33    34
         0,    1,    2,    3,    4,    5,    6,    7,    8,    9,    10,   11,   12,   13,   14,   15,   16,   17,   18,   19,   20,   21,   22,   23,   24,   25,   26,   27,   28,   29,   30,   31,   32,   33,   34 
      },  
      { // E2LB_1   - endian to left bifurcation
   //    0     1     2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29    30    31    32    33    34
         1,    2,    0,    5,    6,    3,    4,    9,   10,    7,    8,    13,   14,   11,   12,   17,   18,   15,   16,   21,   22,   19,   20,   25,   26,   23,   24,   29,   30,   27,   28,   33,   34,   -1,   -1 
      },  

      {  // E2RB_1   - endian to right bifurcation
   //    0     1     2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29    30    31    32    33    34
         2,    3,    4,    0,    1,    7,    8,    5,    6,   11,    12,    9,   10,   15,   16,   13,   14,   19,   20,   17,   18,   23,   24,   21,   22,   27,   28,   25,   26,   31,   32,   29,   30,   -1,   -1 
      },

      {  // B2RE_1 - bifurcation to right endian
   //    0     1     2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29    30    31    32    33    34
         2,    0,    1,    5,    6,    3,    4,    9,   10,    7,     8,   13,   14,   11,   12,   17,   18,   15,   16,   21,   22,   19,   20,   25,   26,   23,   24,   29,   30,   27,   28,   -1,   -1,   31,   32 
      },    

      {  // B2LE_1 - bifurcation to left endian 
   //    0     1     2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29    30    31    32    33    34
         3,    4,    0,    1,    2,    7,    8,    5,    6,   11,    12,    9,   10,   15,   16,   13,   14,   19,   20,   17,   18,   23,   24,   21,   22,   27,   28,   25,   26,   31,   32,   29,   30,   -1,   -1 
      },   

      {  // B2LB_2  - bifurcation to left bifurcation  
   //    0     1     2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29    30    31    32    33    34
         5,    6,    1,    2,    0,    9,   10,    3,    4,   13,    14,    7,    8,   17,   18,   11,   12,   21,   22,   15,   16,   25,   26,   19,   20,   29,   30,   23,   24,   33,   34,   27,   28,   -1,   -1 
      },  

      {  // B2RB_2 - bifurcation to right bifurcation  
   //    0     1     2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29    30    31    32    33    34
         4,    2,    3,    7,    8,    0,    1,   11,   12,    5,     6,   15,   16,    9,   10,   19,   20,   13,   14,   23,   24,   17,   18,   27,   28,   21,   22,   31,   32,   25,   26,   -1,   -1,   29,   30 
      },   
      {  // E2RE_2 - endian to right endian
   //    0     1     2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29    30    31    32    33    34
         5,    9,   10,    6,    1,   13,   14,    2,    0,   17,    18,    3,    4,   21,   22,    7,    8,   25,   26,   11,   12,   29,   30,   15,   16,   -1,   -1,   19,   20,   -1,   -1,   23,   24,   -1,   -1    
      },  
      {  // E2LE_2 - endian to left endian
   //    0     1     2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29    30    31    32    33    34
         8,    4,    7,   11,   12,    0,    3,   15,   16,    1,     2,   19,   20,    5,    6,   23,   24,    9,   10,   27,   28,   13,   14,   31,   32,   17,   18,   -1,   -1,   21,   22,   -1,   -1,   25,   26       
      },  
   };
   memcpy(protect, pp, sizeof(pp));
   return initEx(accelHandle, protect);
}

int Compare100::initEx (void *accelHandle, int protect[MAX_PROTECT_LEN])
{
   if (m_init) return MA_OK;
   int result = MA_OK;
   memcpy (TransitionMatrix, protect, sizeof(TransitionMatrix));
   if ((result = alloc()) != MA_OK)
      return result;
  //if ((result = m_matcher->init (accelHandle)) != MA_OK)
  //       return result;
   m_init = true;
	return MA_OK;
}


// allocate memory for data[] templates
int Compare100::allocateTemplate (BYTE *&templ)
{
	try
	{
		templ = new(std::nothrow) unsigned char[MAX_TEMPLATE_SIZE_100];
		if (!templ)
			return MA_LOW_MEMORY;
		memset (templ, 0, MAX_TEMPLATE_SIZE_100);
	}
	catch(...)
	{
		return MA_UNKNOWN_EXCEPTION;
	}

	return MA_OK;
}

// free memery that was earlier allocate templates
int Compare100::freeTemplate(BYTE *&templ)
{
	if (!templ) 
      return MA_WRONG_POINTER;

	try
	{
		delete [] templ;
		templ = NULL;
	}
	catch(...)
	{
		return MA_UNKNOWN_EXCEPTION;
	}
	return MA_OK;
}


/*
	Load probe fingerprint template
	function returns MA_OK - if function succeeds, error code - otherwise
	templP     (input) - probe fingerprint template 
*/
int Compare100::loadTemplate (BYTE *templP, FP_TYPE type)
{
   int result = MA_OK;
   if (!m_init || !m_matcher || !m_templ)
      return MA_NOT_INITIALIZED;
	if (!templP) 
      return MA_WRONG_POINTER;

   TemplateData data;
   TemplHeader *header = NULL;
   int count = 0;
   data.numFinger = FINGPOS_RT;
   count++;
   data.fpTemplate = templP;
   return m_matcher->loadProbe(data.fpTemplate, type, NULL, 0, 0);
}



int Compare100::matchEx (SearchParam &param, BYTE *templG,
                        int &similarity, MatchResult *matchResult,
                        FP_TYPE typeG,
                        bool useCombineData, 
                        BYTE *np, BYTE *ng, BYTE accelGroupSize, bool quickAccelMatch)
{
   int result = MA_OK;
   if (!m_init || !m_matcher || !m_templ)
      return MA_NOT_INITIALIZED;
	if (!templG) 
      return MA_WRONG_POINTER;

   if ( param.lowThreshold  > MAX_SCORE || param.lowThreshold  < 0 || 
      param.highThreshold > MAX_SCORE   || param.highThreshold < 0 ||
      param.maxAngle      > 180
      ) return MA_WRONG_PARAMETRS;



	try
	{
   	similarity = 0;
      if (matchResult)
      {
         memset (matchResult, 0, sizeof (MatchResult));
         matchResult->fingerP = matchResult->fingerG = FINGPOS_UK;
      }

      unsigned char *fpTemplate = NULL;
	   fpTemplate = templG;

      int result = m_matcher->loadGallery(fpTemplate, typeG);
      if (result != MA_OK)
         return result;
      MatchResult matchResult_a;
		if (m_matcher->match (matchResult_a, param.maxAngle, param.searchSpeed, useCombineData, np, ng, accelGroupSize, quickAccelMatch) == MA_OK)
      {
         similarity = matchResult_a.similarity;
         if (matchResult)
            memcpy (matchResult, &matchResult_a, sizeof (MatchResult));
         return MA_OK;
      }
      else
         similarity = 0;
	}
	catch(...)
	{
		return MA_UNKNOWN_EXCEPTION;
	}

	return MA_MATCH;
}


#pragma pack(pop)
} // namespace accelMatch{

