/*
   moMatcher.cpp - implement the Matcher100 class that is supposed to compare the 
                 fingerprints on minutiae only information (x, y, angle, type)

   Copyright (C) 2012 Sonda Technologies Ltd.
   19.09.2012
*/

#include <limits.h>

#include "Matcher100.h"
#include "adjustParams100.h"
#include "score100.h"
#include "deltaWorks100.h"
#include "win2lin.h"
#include "accelData.h"
#include "Eskuse.h"
#include "Julwin.h"



namespace accelMatch{
#pragma pack(push,_CORE_PACKING)

// search parameters
#define MIN_ROT_DIST                 20  // minimum distance from minutiae to center, when 
                                         // the minutie is used for angle rotation calculation
#define MAX_PAIR_LEN                 50  // maximum and minumum distance between minutiae
#define MIN_PAIR_LEN                 20  // for keeping minutiae pair in m_pairLen array

#define MAX_GROUPS                  256  // maximum number of groups


#define RELIABLE_GROUP_SIZE          12   // number of minutiae in a group, when we stop 
                                          // look through another minutiae 
#define QUICK_LIMIT             40 * 40   // number of minutiae in probe and gallery fingerprint, 
                                          //  when switch to quick mode 
#define MIN_ACCELERATOR_SIM        -100   // mimimum value of acceleraror similarity, when sockets will continue compare
   
#define MAX_CHECK_QUADRANT_DIST      200  // maximum distance where quadrants are checking   
#define MIN_CHECK_QUADRANT_DIST       20  // minimum distance where quadrants are checking   

#define MAX_FP_SIZE                  800  // maximum possible distance benween two minutiae of one fingerprint in pixels
#define MIN_ANGLE_TOL                 40  // minimum angle tolerance    
#define MAX_ANGLE_TOL                180  // maximum angle tolerance    
#define RELIABLE_NUM_FOUND_MINUTIAE   32  // number of found minutiae when we decide its genuine fingerprints and stop matching 


int s_distTolTab[MAX_ERROR_LEVEL][DIST_TOL_SIZE];

inline int calcDistTol(int dist, int percent, int add, int maxVal)
{
   int val = (dist * percent + 50) / 100  + add;
   return (val <= maxVal) ? val : maxVal;
}

//int getSimSum(GroupEx* g)
//{
//   assert(g);
//   int sum = 0;
//   size_t numItems = g->getNumItems();
//   for(size_t i = 0; i < numItems; i++)
//      sum += g->getSim(i);
//   short pos = g->getConflictPos();
//   if (pos > 0)
//      sum -= g->getConflictSim();
//   return sum;
//}
//
//int getSumDistErr(GroupEx* g)
//{
//   assert(g);
//   int sum = 0;
//   size_t numItems = g->getNumItems();
//   for(size_t i = 0; i < numItems; i++)
//      sum += g->getErr(i);
//   //short pos = g->getConflictPos();
//   //if (pos > 0)
//   //   sum -= g->getConflictSim();
//   return sum;
//}

inline int getNumAddItems (GroupEx *g) 
{
   int numItems =  (int)g->getNumItems();
   if (g->getConflictPos() != -1)
      numItems--; 
   return numItems;  
} 


inline int sortKernalGroupsByNumItems (const void *val1, const void *val2) 
{
   GroupEx* g1 = *(GroupEx**)val1;
   GroupEx* g2 = *(GroupEx**)val2;
   int numAddItems1 =  getNumAddItems(g1);
   int numAddItems2 =  getNumAddItems(g2);
   //int numParentItems1 = g1->getNumParentsItem();
   //int numParentItems2 = g2->getNumParentsItem();
   //if (numParentItems1 && numParentItems2)
   //{
   //   numAddItems1 = numAddItems1 * 256 / numParentItems1;
   //   numAddItems2 = numAddItems2 * 256 / numParentItems2;
   //   //if (numAddItems1 != numAddItems2)      
   //   //   return numAddItems2 - numAddItems1;
   //   if (abs(numAddItems1 - numAddItems2) > 50)     
   //      return numAddItems2 - numAddItems1;
   //   //int sim1 =  getSimSum(g1);
   //   //int sim2 =  getSimSum(g2);
   //   //return sim2 - sim1;  
   //   int err1 =  getSumDistErr(g1);
   //   int err2 =  getSumDistErr(g2);
   //   //if (err1 != err2)
   //   return err1 - err2;  
   //}
   //if (numAddItems1 != numAddItems2)
   //if (abs(numAddItems1 - numAddItems2) > 1)
      return numAddItems2 - numAddItems1;  
   //int sim1 =  getSimSum(g1);
   //int sim2 =  getSimSum(g2);
   //if (sim1 != sim2)
   //   return sim2 - sim1;  
   //int err1 =  getSumDistErr(g1);
   //int err2 =  getSumDistErr(g2);
   ////if (err1 != err2)
   //   return err1 - err2;  
} 

inline int sortKernalGroupsBySumSim (const void *val1, const void *val2) 
{
//   return getSimSum(*(GroupEx**)val2) - getSimSum(*(GroupEx**)val1);
   GroupEx* g1 = *(GroupEx**)val1;
   GroupEx* g2 = *(GroupEx**)val2;
   int numAddItems1 =  getNumAddItems(g1);
   int numAddItems2 =  getNumAddItems(g2);
   //int numParentItems1 = g1->getNumParentsItem();
   //int numParentItems2 = g2->getNumParentsItem();
   //if (numParentItems1 && numParentItems2)
   //{
   //   numAddItems1 = numAddItems1 * 256 / numParentItems1;
   //   numAddItems2 = numAddItems2 * 256 / numParentItems2;
   //   if (numAddItems1 != numAddItems2)      
   //      return numAddItems2 - numAddItems1;
   //   //if (abs(numAddItems1 - numAddItems2) > 50)     
   //   //   return numAddItems2 - numAddItems1;
   //int sim1 =  getSimSum(g1);
   //   //int sim2 =  getSimSum(g2);
   //   //return sim2 - sim1;  
   //   //int err1 =  getSumDistErr(g1);
   //   //int err2 =  getSumDistErr(g2);
   //   ////if (err1 != err2)
   //   //return err1 - err2;  
   //}
   //if (numAddItems1 != numAddItems2)
      return numAddItems2 - numAddItems1;  
   //int sim1 =  getSimSum(g1);
   //int sim2 =  getSimSum(g2);
   //return sim2 - sim1;  
   //int err1 =  getSumDistErr(g1);
   //int err2 =  getSumDistErr(g2);
   //if (err1 != err2)
      //return err1 - err2;  
   //int sim1 =  getSimSum(g1);
   //int sim2 =  getSimSum(g2);
   //return sim2 - sim1;  
} 


void Matcher100::setDistErrorLevel(int level)
{
   assert(level < MAX_ERROR_LEVEL);
   m_errorLevel = level;
}


bool checkMinAngles(int angle1, int angle2, int groupAngle, int dAngle, short *err = NULL)
{
   int angleDif = abs(normAngle(angle1 - angle2 - groupAngle));
   if (err)
      *err = angleDif * 256 / dAngle;
   return (angleDif <= dAngle);
}
bool checkMinAngles(int angle1, int angle2, int groupAngle, bool nearSingularP, bool nearSingularG, 
                     int dAngle, int dAngle1, short *err)
{
   dAngle = (nearSingularP || nearSingularG) ? dAngle1 : dAngle;
   return checkMinAngles (angle1, angle2, groupAngle, dAngle, err);
}



// fill g_distTol table
void Matcher100::fillDistTolTalbe ()
{
   int percent = 0, add = 0, maxVal = 1024;
   for(int level = 0; level < MAX_ERROR_LEVEL; level++)
   {
      switch (level)
      {
      case 0:
         percent =  10;
         add     =  20;
         break;
      case 1:
         percent = 20;
         add     = 20;
         break;
      case 2:
         percent = 25;
         add     = 20;
         break;
      case 3:
         percent = 30;
         add     = 20;
         break;
      case 4:
         percent = 25;
         add     = 35;
        // maxVal  = 55;
         break;
      case 5:
         percent = 55;
         add     = 45;
         break;
      default:
         percent = 50;
         add     = 40;
         break;
      }
      for(int i = 0; i < DIST_TOL_SIZE; i++)
         s_distTolTab[level][i] = calcDistTol(i, percent, add, maxVal);  
   }
}


Matcher100::Matcher100()
 {
    if (!check_SSE4_2 ())
       throw MA_NOT_SUPPORT_SSE4_2;
    memset(this, 0, sizeof(*this));
    m_expandGroupPairSet.clear(); // should be here, because in other case m_current_np will be set to zero by previous 'memset(this, 0, sizeof(*this))'
    m_compNestHitGroup.init    (MAX_MINUTIAE);
    m_findBestGHitGroup.init    (MAX_MINUTIAE);
    m_tempHitGroup.init(MAX_MINUTIAE);
    for (int i = 0; i < MAX_KERNEL_GROUPS; i++)
       m_kernelGroups[i].init(MAX_KERNEL_GROUP_SIZE, true); 
    for (int i = 0; i < MAX_EXPAND_GROUPS; i++)
       m_expandGroups[i].init(MAX_EXPAND_GROUP_SIZE, true); 

   setParameters(DEF_MAX_ANGLE, DEF_SEARCH_SPEED);
   fillDistTolTalbe();
	m_unwrap = ESK::Unwrap::create();
   if (!m_unwrap)
      throw MA_LOW_MEMORY;
#if defined (_ESK_ID)
   m_unwrap->versor (_ESK_ID);
#endif
//   m_unwrap->factor( (ESK::LAUNCH)(ESK::CAES_G | ESK::CAES_P | ESK::CAES_A), false);
//   m_unwrap->factor( (ESK::LAUNCH)(ESK::CAES_G | ESK::CAES_A), false);
//   m_unwrap->factor( (ESK::LAUNCH)(ESK::CAES_A), false);
//   m_unwrap->factor( (ESK::LAUNCH)(ESK::TPLA), false);
   m_unwrap->factor(false);

   if(!allocArea ())
      throw MA_LOW_MEMORY;
   if (!reallocMinutiae (true, MAX_MINUTIAE * 2) ||
       !reallocMinutiae (false, MAX_MINUTIAE * 2))
       throw MA_LOW_MEMORY;

   // force windows really allocate important memory
   setAngleTolerance (DEF_MINUTIAE_ANGLE_TOL, DEF_GROUP_ANGLE_TOL);

   for(int np = 0; np < MAX_MINUTIAE; np++)
      for(int ng = 0; ng < MAX_MINUTIAE; ng++)
         m_nestCompResult[np][ng].clear();
   
   memset (m_simHist, 0, sizeof (m_simHist));
   //m_accelThreshold = 0;
   m_checkQuadrants        = false;
   m_allowReplacement      = false;
   m_acceptableTransition  = NT;
}




Matcher100::~Matcher100()
{
	if (m_unwrap)         ESK::Unwrap::cancel (m_unwrap), m_unwrap     = NULL;
   if (m_minutiaePR)     free (m_minutiaePR)           , m_minutiaePR = NULL;
   if (m_minutiaeGR)     free (m_minutiaeGR)           , m_minutiaeGR = NULL;
   if (m_minutiaeP)      free (m_minutiaeP)            , m_minutiaeP  = NULL;
   if (m_minutiaeG)      free (m_minutiaeG)            , m_minutiaeG  = NULL;
   if (m_linkP)          free (m_linkP)                , m_linkP      = NULL;
   if (m_linkG)          free (m_linkG)                , m_linkG      = NULL;
   if (m_probP)          free (m_probP)                , m_probP      = NULL;
   if (m_probG)          free (m_probG)                , m_probG      = NULL;
   if (m_areaP_buf)      delete [] m_areaP_buf         , m_areaP_buf  = NULL;  
   if (m_areaG_buf)      delete [] m_areaG_buf         , m_areaG_buf  = NULL;  
   freeNestAccel (m_nestAccelP);
   freeNestAccel (m_nestAccelG);
}

// set matching parameters
void Matcher100::setParameters(int maxAngle, int speed)
{
   m_maxAngle    = maxAngle;
   if (m_maxAngle < MIN_ANGLE_TOL) m_maxAngle = MIN_ANGLE_TOL;
   if (m_maxAngle > MAX_ANGLE_TOL) m_maxAngle = MAX_ANGLE_TOL;
   m_speed       = speed;
   int maxSpeed = 0;
   if (m_typeP == LATENT || m_typeG == LATENT)
      maxSpeed = sizeof(g_k_speed_latent) / sizeof(g_k_speed_latent[0]) - 1;
   else
      maxSpeed = sizeof(g_k_speed) / sizeof(g_k_speed[0]) - 1;
   if (m_speed > maxSpeed) m_speed = maxSpeed;
}


bool Matcher100::reallocMinutiae (bool isProbe, int num)
{
   int           &maxNumNest     = isProbe ? m_maxNumNestP  : m_maxNumNestG;
   ESK::Sign     *&sign          = isProbe ? m_minutiaeP        : m_minutiaeG;
   ESK::Link     *&link          = isProbe ? m_linkP        : m_linkG;
   WORD          *&prob          = isProbe ? m_probP        : m_probG;
   NestAccel     *&nestAccel     = isProbe ? m_nestAccelP   : m_nestAccelG;
//   BYTE          *&highDensity   = isProbe ? m_highDensityP : m_highDensityG;

   MinutiaeShort *&minutiaeR   = isProbe ? m_minutiaePR  : m_minutiaeGR;

   if (num < maxNumNest)
      return true;
   int n = maxNumNest;
   while (n < num) 
      n += MAX_MINUTIAE / 4;

   if (!sign)
   {
      sign        = (ESK::Sign*    ) malloc (sizeof(ESK::Sign)     * n);
      link        = (ESK::Link*    ) malloc (sizeof(ESK::Link)     * n);
      minutiaeR   = (MinutiaeShort*) malloc (sizeof(MinutiaeShort) * n);
      prob        = (WORD*         ) malloc (sizeof(BYTE)          * n);
      allocNestAccel(nestAccel, n);
   }
   else if (n > maxNumNest)  
   {
      sign        = (ESK::Sign*    ) realloc ((void*)sign     , sizeof(ESK::Sign    ) * n);
      link        = (ESK::Link*    ) realloc ((void*)link     , sizeof(ESK::Link    ) * n);
      prob        = (WORD*         ) realloc ((void*)prob     , sizeof(WORD         ) * n);
      minutiaeR   = (MinutiaeShort*) realloc ((void*)minutiaeR, sizeof(MinutiaeShort) * n);
      allocNestAccel(nestAccel, n);
   }
   maxNumNest = n;
   return (sign &&link && prob && minutiaeR && nestAccel);
}
bool Matcher100::allocArea ()
{
   int size = MAX_WIDTH * MAX_HEIGHT / 8 / 8;
   if (!m_areaP_buf) 
      m_areaP_buf = new(std::nothrow) BYTE [size];
   if (!m_areaG_buf) 
      m_areaG_buf = new(std::nothrow) BYTE [size];
   return (m_areaP_buf && m_areaG_buf);
}

int Matcher100::loadMinutiae (bool isProbe, BYTE *templ)
{
   assert(m_unwrap);
   int result = MA_OK; 
   int &numNests        = isProbe ? m_numNestP     : m_numNestG;
   WORD &width          = isProbe ? m_widthP       : m_widthG; 
   WORD &height         = isProbe ? m_heightP      : m_heightG; 
   ESK::Sign *singular  = isProbe ? m_singularP    : m_singularG;
   int  &numSingular    = isProbe ? m_numSingularP : m_numSingularG;
   BYTE *&area          = isProbe ? m_areaP        : m_areaG;
   BYTE &patternType    = isProbe ? m_patternTypeP : m_patternTypeG;

   numNests = (int)m_unwrap->idnova (templ + sizeof(TemplHeader));
   if (!reallocMinutiae (isProbe, numNests))
      return MA_LOW_MEMORY;
   ESK::Sign *sign = isProbe ? m_minutiaeP : m_minutiaeG;
   ESK::Link *link = isProbe ? m_linkP : m_linkG;
   if (m_unwrap->denova (sign, templ + sizeof(TemplHeader)) != numNests)
      return isProbe ? MA_WRONG_PROBE_TEMPLATE : MA_WRONG_GALLERY_TEMPLATE;
   if (m_unwrap->denest (link, sign, numNests, templ + sizeof(TemplHeader)) != numNests)
      return isProbe ? MA_WRONG_PROBE_TEMPLATE : MA_WRONG_GALLERY_TEMPLATE;
   if (numNests > MAX_MINUTIAE)
      numNests = MAX_MINUTIAE;
   
   patternType = m_unwrap->immask (templ + sizeof(TemplHeader));

   // fill array of probability and nearSingular
   WORD *prob         = isProbe ? m_probP         : m_probG;
   bool *nearSingular = isProbe ? m_nearSingularP : m_nearSingularG;
   int probability = 0, angle = 0, dx = 0, dy = 0, add = 0, maxDist = 100;
   for (int i = 0; i < numNests; i++)
   {
      probability = sign[i].Prob;  
      prob[i] = probability & 0x3f;
      if (probability & 0x40)
      {
         nearSingular[i] = true;   
      }
      else
         nearSingular[i] = false;

      if (probability & 0x80)
         prob[i] /= 2;

      if ((MINUTIAE_TYPE)sign[i].Type == ENDING)
      {
         angle = normAngle((int)sign[i].Beta - 180);
         add = 5;//(nest[i].Lace / 8 + 5) / 4 + 2;
         dx = cosm(add, angle);
         dy = sinm(add, angle);
      }
      else
         dx = dy = 0;
      sign[i].Movx += dx;
      sign[i].Movy += dy;

      //xc += nest[i].Movx;
      //yc += nest[i].Movy;
   }
   //if ((isProbe && m_typeP == LATENT) || (!isProbe && m_typeG == LATENT))
   //   for (int i = 0; i < numNest; i++)
   //      prob[i] = 0x3f;
   return MA_OK;
}


int Matcher100::loadArea (bool isProbe, BYTE *templ, BYTE *areaFromAccelLib, int areaWidthFromAccelLib, int areaHeightFromAccelLib)
{
   int result = 0;
   BYTE *&area      = isProbe ? m_areaP      : m_areaG;
   WORD &areaWidth  = isProbe ? m_areaWidthP  : m_areaWidthG;
   WORD &areaHeight = isProbe ? m_areaHeightP : m_areaHeightG;
   assert(m_unwrap);
   if (areaFromAccelLib)
   {
      area       = areaFromAccelLib      ;
      areaWidth  = areaWidthFromAccelLib ;
      areaHeight = areaHeightFromAccelLib;
   }
   else
   {
      area = isProbe ? m_areaP_buf : m_areaG_buf;
      assert(area);
      result = m_unwrap->dearea (area, templ);
      if (!result)
		   return isProbe ? MA_WRONG_PROBE_TEMPLATE : MA_WRONG_GALLERY_TEMPLATE;
      areaWidth  =  result        & 0xffff;
      areaHeight = (result >> 16) & 0xffff;
   }
   return MA_OK;
}

// validate template 
bool Matcher100::validateTemplate(const BYTE *fpTemplate, BYTE &quality, WORD &width, WORD &height)
{
   TemplHeader *header = (TemplHeader*)fpTemplate;
   //if (header->checkIntegral != 0 && header->checkIntegral != 1)
   //   return false;
   //if (header->size > MAX_TEMPLATE_SIZE_80)
   //   return false;
   BYTE *templ = (BYTE*)fpTemplate + sizeof (TemplHeader);
   quality = m_unwrap->qualit(templ);
   if (quality > 100)// || quality != header->quality)
      return false;
	width   = m_unwrap->size_x(templ);
   height  = m_unwrap->size_y(templ);
   if (width  > MAX_WIDTH || height > MAX_HEIGHT)
      return false;
   //if (m_unwrap->length(templ) != header->size - sizeof(TemplHeader))
   //   return false;
   BYTE version = m_unwrap->versor(templ);
   if (version != 72 && version != 73 && version != 110 && version != 130)
      return false;
   if (!m_unwrap->verify (templ))
      return false;
   return m_unwrap->defend (templ);
}

// load template
int Matcher100::loadTemplate (bool isProbe, BYTE *templ, FP_TYPE type,  BYTE *area, int areaWidth, int areaHeight)
{
   int result = MA_OK;
	if (! templ)
		return MA_WRONG_POINTER; 
   if(isProbe) m_typeP = type;
   else        m_typeG = type; 

   int  &density    = isProbe ? m_densityP      : m_densityG;
   BYTE &quality    = isProbe ? m_qualityP      : m_qualityG;
   WORD &width      = isProbe ? m_widthP        : m_widthG;
   WORD &height     = isProbe ? m_heightP       : m_heightG;
   BYTE *fpTempl    = isProbe ? m_templateP     : m_templateG;

   try
   {
      if (!validateTemplate(templ, quality, width, height))
         return isProbe ? MA_WRONG_PROBE_TEMPLATE : MA_WRONG_GALLERY_TEMPLATE;
      //if (isProbe && m_typeP == LATENT)
      //   m_qualityP = 100;
      //if (!isProbe && m_typeG == LATENT)
      //   m_qualityG = 100;
      TemplHeader* header = (TemplHeader*)templ;
      int templSize = m_unwrap->length (templ + sizeof (TemplHeader)) + sizeof (TemplHeader);//header->size;
      // save template ver 8         
      if (templSize > MAX_TEMPLATE_SIZE_80)
         return isProbe ? MA_WRONG_PROBE_TEMPLATE : MA_WRONG_GALLERY_TEMPLATE;
      memcpy (fpTempl, templ, templSize);
		density = m_unwrap->densit(templ + sizeof (TemplHeader));
      if ((result = loadSingular (isProbe)                                                     ) != MA_OK) return result;
      if ((result = loadArea(isProbe, templ + sizeof(TemplHeader), area, areaWidth, areaHeight)) != MA_OK) return result;
      if ((result = loadMinutiae(isProbe, templ                                               )) != MA_OK) return result;

      // fill information about minutiae pairs 
     if (isProbe)
     {
        m_pairSetP.setNests (m_linkP, m_minutiaeP   );
        m_pairSetP.clear   (m_numNestP);
        m_pairSetP.setAll  (m_numNestP);
        calcAllNestAccel (true, m_nestAccelP, m_minutiaeP, m_linkP, m_numNestP, m_pairSetP);
        m_dr = m_densityP / 8;
        for(int i = 0; i < MAX_KERNEL_GROUPS; i++)
           m_kernelGroups[i].setDensity (m_dr);
        for(int i = 0; i < MAX_EXPAND_GROUPS; i++)
           m_expandGroups[i].setDensity (m_dr);
     }
     else
     {
        m_pairSetG.setNests(m_linkG, m_minutiaeG);
        m_pairSetG.clear   (m_numNestG);
        m_pairSetG.setAll  (m_numNestG);
        calcAllNestAccel(false, m_nestAccelG, m_minutiaeG, m_linkG, m_numNestG, m_pairSetG);
     }
   }
   catch (int &e)
   {
      result = e;
   }
   catch (...)
   {
      result = MA_UNKNOWN_EXCEPTION;
   }
   return result;
}

int Matcher100::loadSingular (bool isProbe)
{
   int  &numSingular = isProbe ? m_numSingularP : m_numSingularG;
   ESK::Sign *singular    = isProbe ? m_singularP    : m_singularG;
   BYTE *fpTempl     = (isProbe ? m_templateP   : m_templateG) + sizeof (TemplHeader);

   numSingular = 0;
   memset (singular , 0, sizeof(m_singularP  ));
   assert (m_unwrap && fpTempl);
   try
   {
      ESK::Sign sing[64];
//      numSingular = m_caesar->demain(sing, fpTempl);
      numSingular = (int)m_unwrap->demain(sing, fpTempl);
      if (numSingular > MAX_SINGULAR)
         numSingular = MAX_SINGULAR;
      memcpy (singular, sing, sizeof(ESK::Sign) * numSingular);
   }
   catch (...)
   {
      return MA_UNKNOWN_EXCEPTION;
   }
   return MA_OK;
}


void Matcher100::initNewMatch (MatchResult &matchRes)
{
   memset (&matchRes, 0, sizeof (MatchResult));
   for(int i = 0; i < MAX_KERNEL_GROUPS; i++)
   {
      m_kernelGroups[i].setNests        (m_minutiaeP, m_minutiaeG);
      m_kernelGroups[i].setPairSet      (&m_pairSetP, &m_pairSetG);
      m_kernelGroups[i].setNearSingular (m_nearSingularP, m_nearSingularG);
      m_kernelGroups[i].clear();
   }
   for(int i = 0; i < MAX_EXPAND_GROUPS; i++)
   {
      m_expandGroups[i].setNests        (m_minutiaeP, m_minutiaeG);
      m_expandGroups[i].setPairSet      (&m_pairSetP, &m_pairSetG);
      m_expandGroups[i].setNearSingular (m_nearSingularP, m_nearSingularG);
      m_expandGroups[i].clear();
   }


   for(int np = 0; np < m_numNestP; np++)
      for(int ng = 0; ng < m_numNestG; ng++)
      {
         m_accelSim      [np][ng] = 0;
         m_nestCompResult[np][ng].clear();
      }
   if (m_typeP == LATENT || m_typeG == LATENT)
      memcpy(m_k_speed, g_k_speed_latent[m_speed], sizeof (m_k_speed));
   else
      memcpy(m_k_speed, g_k_speed[m_speed], sizeof (m_k_speed));

   if (m_k_speed[11] >      MAX_KERNEL_GROUPS) m_k_speed[11] = MAX_KERNEL_GROUPS;
   if (m_k_speed[13] >      MAX_EXPAND_GROUPS) m_k_speed[13] = MAX_EXPAND_GROUPS;
   if (m_k_speed[ 5] > MAX_NEST_VIRT_SIZE_SET) m_k_speed[ 5] = MAX_NEST_VIRT_SIZE_SET;
   int num = minAB (m_numNestP, m_numNestG);
   if (num < 15)
   {
      m_k_speed[1] *= 2;
      m_k_speed[8] /= 2;
   }
   else if (num < 20)
   {
      m_k_speed[1] = (int)(m_k_speed[1] * 1.2);
      m_k_speed[8] = (int)(m_k_speed[8] / 1.2);
   }
   if (m_k_speed[1] > 100) m_k_speed[1] = 100;
   if (m_k_speed[8] <   3) m_k_speed[8] =   3;
}
void Matcher100::clearUsedNests(GroupEx *curGroup)
{
   if (!m_nestVirtSizeSet.size())
      return;
   // erase 0-th element of m_bestNests, because it was used as a start for build kernal group
   // and probably was change while replacement (so we haven't it in a curGroup)
   m_nestVirtSizeSet.erase (0);

   if (!curGroup->getNumItems())
   {
      m_nestVirtSizeSet.sort();
      return;
   }
   // erase elements of m_bestNests, those were already used
   size_t size = curGroup->getNumItems();
   short np = 0, ng = 0;
   int pos = 0;
   for(size_t i = 0; i < size; i++)
   {
      curGroup->getPair (i, np, ng);
      if ((pos = m_nestVirtSizeSet.find ((BYTE)np, (BYTE)ng)) != -1)
         m_nestVirtSizeSet.erase (pos);
   }
   m_nestVirtSizeSet.sort();
}

void Matcher100::clearUsedNestSimSet(GroupEx *curGroup)
{
   // erase elements of m_nestSimSet, those in curGroup
   size_t size = curGroup->getNumItems();
   short np = 0, ng = 0;
   int pos = 0;
   for(size_t i = 0; i < size; i++)
   {
      curGroup->getPair (i, np, ng);
      if ((pos = m_nestSimSet.find ((BYTE)np, (BYTE)ng)) != -1)
         m_nestSimSet.remove (pos);
   }
}

// compare templates
int Matcher100::match (MatchResult &matchRes, int maxAngle, int speed, bool useCombineData, BYTE *ap, BYTE *ag, BYTE accelGroupSize, bool quickAccelMatch)
{
   int result = MA_OK;
   setParameters(maxAngle, speed);
   quickAccelMatch = quickAccelMatch && useCombineData && (accelGroupSize > 1);
   try
   {
      if (m_typeP == LATENT)
      {
         int angleTol = m_unwrap->passan (m_templateP + sizeof(TemplHeader));
         if (m_maxAngle < angleTol) m_maxAngle = angleTol;
      }
      if (m_typeG == LATENT)
      {
         int angleTol = m_unwrap->passan (m_templateG + sizeof(TemplHeader));
         if (m_maxAngle < angleTol) m_maxAngle = angleTol;
      }
      initNewMatch (matchRes);
      MatchResult matchResult; 
      BYTE size = 0;

      setAngleTolerance (DEF_MINUTIAE_ANGLE_TOL, DEF_GROUP_ANGLE_TOL);
      setDistErrorLevel (2);
      m_acceptableTransition = TL_1_MAX;
      m_maxRcDif = (m_typeP == LATENT || m_typeG == LATENT) ? 32 : 16;

      if (useCombineData && (accelGroupSize > 1))
         compareNestsFromAccelMatch(ap, ag, accelGroupSize);
      else
      {
         int size = 0;
         size_t numPassed = 0;
         if (useCombineData)// && accelGroupSize == 1)
         {
            setDistErrorLevel (5);
            size = compareSuitableAccelerators(*ap, *ag);
            numPassed = size * m_k_speed[14] / 100;
            if (numPassed > m_k_speed[15]) 
               numPassed = m_k_speed[15];
         }
         else
         {
            size = compareAllNestAccel ();
            numPassed = size * m_k_speed[1] / 100;
            if (numPassed > m_k_speed[2]) 
               numPassed = m_k_speed[2];
         }
      
         BYTE accelThreshold = getSimThreshold((int)numPassed, m_simHist);
         if (accelThreshold < m_k_speed[0]) accelThreshold = (BYTE)m_k_speed[0];
         if (!accelThreshold) accelThreshold = 1;
         setDistErrorLevel (4);
         compareBestNests(accelThreshold);
      }
      size_t sizeNestSet = m_nestSimSet.size() ;
      size_t numPassed = sizeNestSet * m_k_speed[4] / 100;
      size_t maxNumPassed = (useCombineData && accelGroupSize == 1) ? m_k_speed[16] : m_k_speed[5];
      if (numPassed > maxNumPassed) numPassed = maxNumPassed;
      if (numPassed > sizeNestSet ) numPassed = sizeNestSet;
      if (m_typeP == LATENT || m_typeG == LATENT)
         setDistErrorLevel (3);
      else
         setDistErrorLevel (0);
      chooseBestNests (numPassed, m_k_speed[6]);

      NestVirtSizeSet nestVirtSizeSet = m_nestVirtSizeSet;
      //if (useCombineData && accelGroupSize > 1)
      //{
      //   matchBranch1(matchRes);
      //   return result;
      //}
   //   if (m_typeP == LATENT || m_typeG == LATENT)// || (useCombineData && accelGroupSize > 1))
      CalcScoreTypeEnum calcScoreType;
      {
         if (useCombineData && (accelGroupSize > 1))
         {
            if (quickAccelMatch) calcScoreType = ACCEL_QUICK;
            else                 calcScoreType = ACCEL_BRANCH1;
         }
         else                    calcScoreType = BRANCH1;     
         bool rs = matchBranch1(matchRes, calcScoreType);
         if (rs || quickAccelMatch)
            return result;
      }
      m_nestVirtSizeSet = nestVirtSizeSet;
      if (useCombineData && (accelGroupSize > 1)) calcScoreType = ACCEL_BRANCH2;
      else                                        calcScoreType = BRANCH2;     
      matchBranch2(matchRes, calcScoreType);
   }
   catch(int &e)
   {
      result = e;
   }
   catch (...)
   {
      result = MA_UNKNOWN_EXCEPTION;
   }
   return result;
}

bool Matcher100::saveMatchResult(MatchResult &matchRes, CalcScoreTypeEnum calcScoreType)
{
   int score = calcScore(calcScoreType);
   if (score <= matchRes.similarity)
      return false;

   size_t num = m_curGroup->getNumItems();
   for (unsigned int i = 0; i < num; i++)
   {
      matchRes.minutiaeNum[i][0] = m_curGroup->getProbe(i);
      matchRes.minutiaeNum[i][1] = m_curGroup->getGallery(i);
   }
   matchRes.numPairs = (unsigned int)num;
   matchRes.similarity = score;
   int xcP = 0, ycP = 0, xcG = 0, ycG = 0, angle = 0;
   m_curGroup->getRotation (xcP, ycP, xcG, ycG, angle, false);
   matchRes.angle = -angle;
   matchRes.xcP = xcP;
   matchRes.ycP = ycP;
   matchRes.xcG = xcG;
   matchRes.ycG = ycG;

   return (num > RELIABLE_NUM_FOUND_MINUTIAE || score >= MAX_SCORE);
}

bool Matcher100::matchBranch1 (MatchResult &matchRes, CalcScoreTypeEnum calcScoreType)
{
   bool matchingComplete = false;

   m_acceptableTransition  = TL_2_MAX;
   m_checkQuadrants        = false;
   m_allowReplacement      = false;
   m_maxRcDif              = 32;
   buildKernelGroups (1, m_k_speed[11], calcScoreType == ACCEL_QUICK);

   // build the final groups (m_curGroups) and choose the best one by final score
   m_checkQuadrants        = true;
   m_acceptableTransition = MPT;

   int score = 0;
   size_t maxFinalGroups = m_k_speed[18];
   if (maxFinalGroups > m_k_speed[11])
      maxFinalGroups = m_k_speed[11];
   for(size_t i = 0; i < maxFinalGroups; i++)
   {
      m_curGroup = m_p_kernelGroups[i];
      size_t num = m_curGroup->getNumItems();
      if (num < m_k_speed[8] || num < matchRes.numPairs * m_k_speed[10] / 100)
         continue;

      m_acceptableTransition  = MPT;
      setDistErrorLevel(1);
      m_curGroup->mainGroupComplete();
      if (!expandCurGroupByGeometry(calcScoreType == ACCEL_QUICK))
         continue;
      if (saveMatchResult (matchRes, calcScoreType))
      {
         matchingComplete = true;
         break;
      }
   }
   return matchingComplete;
}

bool Matcher100::matchBranch2 (MatchResult &matchRes, CalcScoreTypeEnum calcScoreType)
{
   bool matchingComplete = false;

   if (m_typeP == LATENT || m_typeG == LATENT)
   {
      setDistErrorLevel (3);
      m_acceptableTransition  = TL_2_MAX;
      m_maxRcDif = 32;
   }
   else
   {
      setDistErrorLevel (0);
      m_acceptableTransition  = TL_1_MAX;
      m_maxRcDif = 16;
   }
   m_checkQuadrants        = false;
   m_allowReplacement      = false;

   buildKernelGroups (2, m_k_speed[17], false);
   m_checkQuadrants        = true;
   m_allowReplacement      = true;
   uniteKernelGroups (m_k_speed[17]);
   m_allowReplacement      = false;

   // build the final groups (m_curGroups) and choose the best one by final score
   int score = 0;
   if (m_typeP == LATENT || m_typeG == LATENT)
      m_acceptableTransition  = MPT;
   else
      m_acceptableTransition  = TL_1_MAX;

   size_t maxFinalGroups = m_k_speed[7];
   if (maxFinalGroups > m_k_speed[17])
      maxFinalGroups = m_k_speed[17];
   for(size_t i = 0; i < maxFinalGroups; i++)
   {
      m_curGroup = m_p_kernelGroups[i];
      size_t num = m_curGroup->getNumItems();
      if (num < m_k_speed[8] || num < matchRes.numPairs * m_k_speed[10] / 100)
         continue;

      if (m_typeP == LATENT || m_typeG == LATENT)
         setDistErrorLevel(3);
      else
         setDistErrorLevel(0);
      expandGroupByTopology      (m_curGroup, 0);
      expandCurGroupByTopologyAlt();
      m_curGroup->mainGroupComplete();

      m_checkQuadrants = true;
      m_checkQuadrants = true;
      if (m_typeP == LATENT || m_typeG == LATENT)
      {
         setDistErrorLevel(1);
         m_acceptableTransition  = MPT;
         m_maxRcDif = 32;
      }
      else
      {
         setDistErrorLevel(0);
         m_acceptableTransition  = TL_2_MAX;
         m_maxRcDif = 32;
      }
      if (!expandCurGroupByGeometry(false))
         continue;
      if (saveMatchResult (matchRes, calcScoreType))
      {
         matchingComplete = true;
         break;
      }
   }
   return matchingComplete;
}

void Matcher100::sortKernelGroupsByNumItems (size_t maxGroups)
{
   // sort kernal groups by number of items
   for(size_t i = 0; i < maxGroups; i++)
      m_p_kernelGroups[i] = &m_kernelGroups[i];
   qsort(m_p_kernelGroups, maxGroups, sizeof(m_p_kernelGroups[0]), sortKernalGroupsByNumItems);   
}

void Matcher100::sortKernelGroupsBySumSim (size_t maxGroups)
{
   // sort kernal groups by number of items
   for(size_t i = 0; i < maxGroups; i++)
      m_p_kernelGroups[i] = &m_kernelGroups[i];
   qsort(m_p_kernelGroups, maxGroups, sizeof(m_p_kernelGroups[0]), sortKernalGroupsBySumSim);   
}


void Matcher100::buildKernelGroups (int numBranch, size_t maxGroups, bool quickAccelMatch)
{
   if (quickAccelMatch) maxGroups = 1;
   for(size_t i = 0; i < maxGroups; i++)
   {
      if (!m_nestVirtSizeSet.size())
         break;
      if (!m_nestVirtSizeSet.getItem(0)->m_virtGroupSize)
         break;
      // build a new kernel group
      if (numBranch == 1)
      {
         buildKernelGroup1(&m_kernelGroups[i], quickAccelMatch);
         if (maxGroups == 1)
            break;
      }
      else
         buildKernelGroup2(&m_kernelGroups[i]);
      // erase elements of m_bestNests, those were already used
      clearUsedNests      (&m_kernelGroups[i]);
   }
   sortKernelGroupsByNumItems (maxGroups);
}


void Matcher100::uniteKernelGroups (size_t maxGroups)
{
   uniteDifGroups(maxGroups);
}

void Matcher100::expandKernelGroups (size_t maxGroups)
{
   for(size_t i = 0; i < maxGroups; i++)
   {
      if (!m_p_kernelGroups[i]->getNumItems())
         break;
      //expandKernelGroup (m_p_kernelGroups[i]);
      expandGroupByNestSimSet (m_p_kernelGroups[i]);
   }
   sortKernelGroupsByNumItems(maxGroups);
}

void Matcher100::expandKernelGroup (GroupEx* curGroup)
{
   BYTE np     = 0, ng     = 0;
   int scaleX  = 0, scaleY = 0;
   Transition         transition    = NT  ;
   //short              transitionDif = 0   ;
   int                pos           = 0   ;
   BYTE               sim           = 0   ;
   NestCompareResult *nestCompRes   = NULL;
   bool               useScale      = true;  
   HitGroup          *g             = NULL;  

   size_t size = m_nestVirtSizeSet.size();
   for(size_t i = 0; i < size; i++)
   {
      if (!m_nestVirtSizeSet.getItem(i)->m_virtGroupSize)
         break;
      np = m_nestVirtSizeSet.getItem(i)->m_np;
      ng = m_nestVirtSizeSet.getItem(i)->m_ng;
      if (curGroup->find (np, ng) != -1)
         continue;
      nestCompRes = &m_nestCompResult[np][ng];
      transition = nestCompRes->getBestTransition();
      getAreaScaleP (curGroup, np, scaleX, scaleY);
      if (tryAdd2curGroup (curGroup, np, ng, transition, m_errorLevel, 0, useScale, scaleX, scaleY) == -1)
         continue;
      g = nestCompRes->getGroup (transition);
      if (!g) 
         continue;
      BYTE numItems = g->getNumItems();
      short np1 = 0, ng1 = 0;
      for (BYTE j = 0; j < numItems; j++)
      {
         g->getPair (j, np1, ng1);
         if (curGroup->find (np1, ng1) != -1)
            continue;
         nestCompRes = &m_nestCompResult[np1][ng1];
         transition = nestCompRes->getBestTransition();
         getAreaScaleP (curGroup, np1, scaleX, scaleY);
         tryAdd2curGroup (curGroup, np1, ng1, transition, m_errorLevel, 0, useScale, scaleX, scaleY);
      }
   }

}


void Matcher100::uniteDifGroups (size_t maxGroups)
{
   GroupEx *mainGroup = NULL, *g = NULL;
   for(size_t i = 0; i < maxGroups; i++)
   {
      mainGroup = m_p_kernelGroups[i];
      calcScale(mainGroup);
   }

   size_t numImems = 0, startNum = 0;
   for(size_t i = 0; i < maxGroups; i++)
   {
      mainGroup = m_p_kernelGroups[i];
      startNum = mainGroup->getNumItems();
      if (!startNum)
         continue;
      for(size_t j = i + 1; j < maxGroups; j++)
      {
         g = m_p_kernelGroups[j];
         numImems = g->getNumItems();
         if (!numImems)
            continue;
         //if (!isGroupsCompatible(mainGroup, g))
         //   continue;
         //for(size_t k = 0; k < numImems; k++)
         //   mainGroup->add (g->getProbe(k), g->getGallery(k), g->getTransition(k), g->getTransitionDif(k));
         //g->clear();
         uniteDifGroup(mainGroup, g);
      }
      //if (mainGroup->getNumItems () == startNum)
      //   continue;
      //cleanInitialGroup (mainGroup);
      //calcScale(mainGroup);
   }
   sortKernelGroupsByNumItems(maxGroups);
}

// check if two kernal groups can be united
bool Matcher100::isGroupsCanBeUnite(GroupEx* firstGroup, GroupEx* secondGroup, size_t samePairsPercentThreshold, 
                                    int sameFirstPos[MAX_MINUTIAE], int sameSecondPos[MAX_MINUTIAE])
{
   assert(firstGroup && secondGroup);
   memset (sameFirstPos , 0, sizeof(sameFirstPos [0]) * firstGroup->getNumItems ());
   memset (sameSecondPos, 0, sizeof(sameSecondPos[0]) * secondGroup->getNumItems());
   size_t firstSize  =  firstGroup->getNumItems();
   size_t secondSize = secondGroup->getNumItems();
   short np = 0, ng = 0;
   size_t numSamePairs = 0;
   int pos = 0;
   for(size_t i = 0; i < secondSize; i++)
   {
      secondGroup->getPair (i, np, ng);
      if ((pos = firstGroup->find (np, ng)) == -1)
         continue;
      sameFirstPos [pos] = 1;
      sameSecondPos[  i] = 1;
      numSamePairs++;
      if (numSamePairs * 100 / firstSize >= samePairsPercentThreshold)
         return true;
   }
   return false;
}


bool Matcher100::isCompatibleWitchCentralPoint(int np0, int ng0, int np, int ng, int groupAngle, bool nearSingular)
{
   int lenP = (np == np0) ? 0 : m_pairSetP.getLen  (np, np0);
   int lenG = (ng == ng0) ? 0 : m_pairSetG.getLenEx(ng, ng0);
   if (!compPairLen (lenP, lenG, m_errorLevel))
      return false;
   if (minAB(lenP, lenG) <= m_dr * 2)
      return true;
   int angleP = m_pairSetP.getAngle    (np0, np);
   int angleG = m_pairSetG.getAngleEx(ng0, ng);
   if(abs(normAngle(angleP - angleG - groupAngle)) > (nearSingular ? m_dAngle * 4 : m_dAngle * 2))
      return false;
   if (m_nearSingularP[np] || m_nearSingularG[ng]) 
      nearSingular = true;
   return accelMatch::checkMinAngles ((int)m_minutiaeP[np].Beta, (int)m_minutiaeG[ng].Beta, groupAngle, nearSingular ?  75 : 35);
}

// check if two pairs are compatible
bool Matcher100::isPairsCompatible(int np0, int ng0, int np, int ng, int groupAngle, bool nearSingular)
{
   int lenP = (np == np0) ? 0 : m_pairSetP.getLen  (np, np0);
   int lenG = (ng == ng0) ? 0 : m_pairSetG.getLenEx(ng, ng0);
   if (!compPairLen (lenP, lenG, m_errorLevel))
      return false;
   if (minAB(lenP, lenG) <= m_dr * 2)
      return true;
   int angleP = m_pairSetP.getAngle    (np0, np);
   int angleG = m_pairSetG.getAngleEx(ng0, ng);
   if(abs(normAngle(angleP - angleG - groupAngle)) > (nearSingular ? 50 : 35))
      return false;
   if (m_nearSingularP[np] || m_nearSingularG[ng]) 
      nearSingular = true;
   return accelMatch::checkMinAngles ((int)m_minutiaeP[np].Beta, (int)m_minutiaeG[ng].Beta, groupAngle, nearSingular ?  25 : 25);
}


// check if two groups are compatible
bool Matcher100::isGroupsCompatible(GroupEx* firstGroup, GroupEx* secondGroup)
{
   int xcP1 = 0, ycP1 = 0, xcG1 = 0, ycG1 = 0, angle1 = 0;
   int xcP2 = 0, ycP2 = 0, xcG2 = 0, ycG2 = 0, angle2 = 0;
   firstGroup->getRotation  (xcP1, ycP1, xcG1, ycG1, angle1);
   secondGroup->getRotation (xcP2, ycP2, xcG2, ycG2, angle2);
   if (abs(normAngle(angle1 - angle2)) > 10)
      return false;

   //short np1 = 0, ng1 = 0, np2 = 0, ng2 = 0;
   //firstGroup->getPair  (0, np1, ng1);
   //secondGroup->getPair (0, np2, ng2);
   //int lenP = (np1 == np2) ? 0 : m_pairSetP.getLen    (np1, np2);
   //int lenG = (ng1 == ng2) ? 0 : m_pairSetG.getLenEx(ng1, ng2);
   //if (!compPairLen (lenP, lenG, m_errorLevel))
   //   return false;
   //if (minAB(lenP, lenG) <= m_dr * 2)
   //   return true;
   //int angleP = m_pairSetP.getAngle    (np1, np2);
   //int angleG = m_pairSetG.getAngleEx(ng1, ng2);
   //int groupAngle = angle1;
   //bool nearSingular = m_nearSingularP[np1] || m_nearSingularG[ng1] || m_nearSingularP[np2] || m_nearSingularG[ng2];
   //if(abs(normAngle(angleP - angleG - groupAngle)) > (nearSingular ? m_dAngle * 4 : m_dAngle * 2))
   //   return false;
   return true;
}

// unite two different groups
void Matcher100::uniteDifGroup(GroupEx* firstGroup, GroupEx* secondGroup)
{
   assert(firstGroup && secondGroup);
   // check if groups are compatible
   if (!isGroupsCompatible(firstGroup, secondGroup))
      return ;

   // try to add to firstGroup the rest items of secondGroup
   Transition transition    = NT   ;
   //short      transitionDif = 0    ;
   int        numAdded      = 0    ;
   int        pos           = 0    ; 
   bool       useScale      =  true;
   short np = 0, ng = 0;
   
   size_t firstGroupSize  = firstGroup->getNumItems();
   size_t secondGroupSize = secondGroup->getNumItems();
   for(size_t i = 0; i < secondGroupSize; i++)
   {
      secondGroup->getPair (i, np, ng);
      transition = secondGroup->getTransition (i);
      pos = tryAdd2curGroup (firstGroup, np, ng, transition, m_errorLevel, 0,
                  useScale, secondGroup->getScaleX(i), secondGroup->getScaleY(i));
      if (pos == -1)
         continue;
      calcScaleForNewPair (firstGroup, pos);
      numAdded++;
   }

   if (numAdded * 100 / secondGroupSize > 80)
      secondGroup->clear();
   if (firstGroup->getNumChanges() * 100 / firstGroupSize > 20)
      calcScale(firstGroup);
}

short Matcher100::getTransitionDif(int np, int ng, Transition &transition, Transition maxTransition, WORD &bestSim)
{
   bestSim = 0;
   short transitionDif = 0;
   HitGroup *g = getNestCompareResult(np, ng, transition, transitionDif);
   if (g)
      bestSim = g->getSim();
   return transitionDif;
}

void Matcher100::tryAdd2InitialGroup(GroupEx *curGroup, short np, short ng, Transition transition)
{
   WORD sim = 0;
   short transitionDif = getTransitionDif(np, ng, transition, m_acceptableTransition, sim);

   int posP = curGroup->findProbe   (np);
   int posG = curGroup->findGallery (ng);
   if (posP == -1 && posG == -1)  // no such pair
   {
      curGroup->add (np, ng, transition);//, transitionDif);
      return;
   }
   if (posP == posG ) // already have this pair
      return;
   int  transitionLevel  = getTransitionLevel (transition);
      
   // np or/and ng has conflict 

   short               old_np               =     0,  old_ng               =     0;
   Transition          old_transitionP      =    NT,  old_transitionG      =    NT;
   int                 old_transitionLevelP =     0,  old_transitionLevelG =     0;
   //short               old_transitionDifP   =     0,  old_transitionDifG   =     0;
   //bool                old_sameDirP         =  true,  old_sameDirG         =  true;
   WORD                old_simP             =     0,  old_simG             =     0;   
   NestCompareResult  *old_nestCompP        =  NULL, *old_nestCompG        =  NULL; 
   
   if (posP != -1)
   {
      old_np = curGroup->getProbe                       (posP           );
      old_transitionP      = curGroup->getTransition    (posP           );
      //old_transitionDifP   = curGroup->getTransitionDif (posP           );
     // old_sameDirP         = curGroup->isSameDir        (posP           );
      old_transitionLevelP = getTransitionLevel         (old_transitionP);
      getNestCompareResult(old_np, ng, m_acceptableTransition, old_simP);

   }
   if (posG != -1)
   {
      old_ng = curGroup->getGallery                     (posG           );
      old_transitionG      = curGroup->getTransition    (posG           );
      //old_transitionDifG   = curGroup->getTransitionDif (posG           );
      //old_sameDirG         = curGroup->isSameDir        (posG           );
      old_transitionLevelG = getTransitionLevel         (old_transitionG);
      getNestCompareResult(np, old_ng, m_acceptableTransition, old_simG);
   }

   if (posP == -1) // only ng conflict
   {
      if (isNewPairBetter (transitionLevel, old_transitionLevelG, sim, old_simG)) 
      {
         curGroup->replace (posG, np, ng, transition);//, transitionDif);
      }
      return;
   }
   if (posG == -1) // only np conflict
   {
      if (isNewPairBetter (transitionLevel, old_transitionLevelP, sim, old_simP)) 
      {
         curGroup->replace (posP, np, ng, transition);//, transitionDif);
      }
      return;
   }
   // both np and ng have conflict
   if (isNewPairBetter (transitionLevel, old_transitionLevelP, sim, old_simP) &&
       isNewPairBetter (transitionLevel, old_transitionLevelG, sim, old_simG)) 
   {
      curGroup->replace (posP, np, ng, transition);//, transitionDif);
      curGroup->remove  (posG);
   }
}

void Matcher100::buildInitialGroup(GroupEx *curGroup, short np0, short ng0)
{
   assert(curGroup);
   curGroup->clear();

   short np = 0, ng  = 0;
   Transition transition              =     NT;
   //bool       sameDir                 =   true;
   short      transitionDif           =      0;


   NestCompareResult *nestCompRes = &m_nestCompResult[np0][ng0];
   transition = nestCompRes->getBestTransition();
   curGroup->add(np0, ng0, transition);//, transitionDif);

   HitGroup *g = nestCompRes->getGroup (transition);
   if (!g) 
      return;
   int num = g->getNumItems();
   for(int i = 0; i < num; i++)
   {
      g->getPair(i, np, ng);
      transition      = g->getTransition(i );
//      sameDir         = g->isSameDir    (i ); 
      tryAdd2InitialGroup(curGroup, np, ng, transition);
      //if (!curGroup->addWidthCheck(np, ng, transition, sameDir))
      //   curGroup->addWidthCheckReserve (np, ng, transition, sameDir);
   }
   for(size_t i  = 0; i < curGroup->getNumItems(); i++) 
   {
      curGroup->getPair (i, np, ng);
      transition = curGroup->getTransition(i);
      g = getNestCompareResult (np, ng, transition, transitionDif);
      if(!g)
         continue;
      num = g->getNumItems();
      short np1 = 0, ng1 = 0;
      for(int j = 0; j < num; j++)
      {
         g->getPair(j, np1, ng1);
         transition = g->getTransition(j);
         tryAdd2InitialGroup(curGroup, np1, ng1, transition);
      }
   }
   //curGroup->compress();
}

void Matcher100::cleanInitialGroupCase(NumSet<size_t> *errorPosSrc, size_t size, 
                                       size_t conflictPairSrc[MAX_MINUTIAE], NumSet<size_t> &bestRemovePos)
{
   NumSet<size_t> *removePos = NULL, *errorPos = NULL;
   NumSet<size_t> maxConflictIndex;
   removePos = new NumSet<size_t>[size];
   errorPos  = new NumSet<size_t>[size];
   if(!removePos || !errorPos)
      throw MA_LOW_MEMORY;
   for(size_t i = 0; i < size; i++)
   {
      removePos[i].init (size, true);
      errorPos[i].init (size, true);
      errorPos[i]  = errorPosSrc[i];
      removePos[i] = bestRemovePos;
   }
   maxConflictIndex.init(size, true);

   // if bestRemovePos contains items, remove from conflictPair references 
   // to last item from bestRemovePos
   size_t conflictPair[MAX_MINUTIAE];
   memcpy (conflictPair, conflictPairSrc, sizeof(conflictPair));
   size_t numItems = bestRemovePos.getNumItems();
   if (numItems > 0)
   {
      size_t curNum = bestRemovePos.getItem (numItems - 1);
      size_t pos = 0;
      for(size_t k = 0; k < errorPos[curNum].getNumItems(); k++)
      {
         pos = errorPos[curNum].getItem(k);
         if (conflictPair[pos]) conflictPair[pos]--; 
      }
      conflictPair[curNum] = 0;
   }

   // find positions that have most conflicts
   size_t maxConflictNum = 0;
   for(size_t k = 0; k < size; k++)
   {
      if (conflictPair[k]  < maxConflictNum)
         continue;
      if (conflictPair[k] > maxConflictNum)
         maxConflictIndex.clear();
      maxConflictIndex.add (k);
      maxConflictNum = conflictPair[k];
   }
   if (!maxConflictNum) // we have cleaned it all!
   {
      if (removePos) delete [] removePos, removePos = NULL;
      if (errorPos ) delete [] errorPos , errorPos  = NULL;
      return;
   }
   // for each position with maxConflictNum conflicts, recursively call cleanInitialGroupCase
   size_t bestSize = size + 1, bestIndex = 0;
   for(size_t i = 0; i < maxConflictIndex.getNumItems(); i++)
   {
      removePos[i].add (maxConflictIndex.getItem(i));
      cleanInitialGroupCase (errorPos, size, conflictPair, removePos[i]); 
      if (removePos[i].getNumItems() < bestSize) 
      {
         bestSize = removePos[i].getNumItems();
         bestIndex = i;
      }
   }
   bestRemovePos = removePos[bestIndex];
   if (removePos) delete [] removePos, removePos = NULL;
   if (errorPos ) delete [] errorPos , errorPos  = NULL;
}

void Matcher100::cleanInitialGroup(GroupEx *curGroup)
{
   assert(curGroup);
  // calcScale (curGroup);
   size_t size = curGroup->getNumItems();
   NumSet<size_t> *errorPos = NULL, skipPos, removePos;
   errorPos  = new NumSet<size_t>[size];
   if(!errorPos)
      throw MA_LOW_MEMORY;
   for(size_t i = 0; i < size; i++)
      errorPos [i].init (size, true);
   skipPos.init   (size, true);
   removePos.init (size, true);

   short np = 0, ng = 0;
   size_t maxAcceptableError = size;
   int *pErr = NULL;
   bool useScale = true;
   int scaleX = 0, scaleY = 0;
   size_t checkStartPos = 0;
   for(size_t i = 0; i < size; i++)
   {
      curGroup->getPair (i, np, ng);
      skipPos.clear();
      errorPos[i].clear();
      skipPos.add (i);
      for(size_t j = 0; j < size; j++)
      {
         if (i == j)
            continue;
         if (curGroup->getProbe(j) != np && curGroup->getGallery(j) != ng)
            continue;  
         skipPos.add     (j);
         errorPos[i].add (j);
      }
      checkStartPos = 0;//i + 1;
      scaleX = curGroup->getScaleX (i);
      scaleY = curGroup->getScaleY (i);
      curGroup->isCompatible (np, ng, m_errorLevel, errorPos[i], maxAcceptableError, pErr, skipPos, useScale, scaleX, scaleY, checkStartPos);    
      skipPos += errorPos[i];
      checkQuadrants (curGroup, np, ng, curGroup->getTransition (i), skipPos, checkStartPos, errorPos[i], maxAcceptableError); 
   }

   // calculate sum of conflict number for each position
   size_t conflictPair[MAX_MINUTIAE];
   memset (conflictPair, 0, sizeof(conflictPair));
   size_t pos = 0;
   for(size_t i = 0; i < size; i++)
   {
      for(size_t k = 0; k < errorPos[i].getNumItems(); k++)
      {
         pos = errorPos[i].getItem(k);
         conflictPair[pos]++; 
      }
   }
   // find best removePos  (the smallest one)
   cleanInitialGroupCase (errorPos, size, conflictPair, removePos);
   curGroup->remove (removePos);
   if (errorPos ) delete [] errorPos , errorPos  = NULL;
}


void Matcher100::expandGroupByNestSimSet(GroupEx *curGroup)
{
   NestSim           *nestSim    = NULL   ;
   NestCompareResult *nestComp   = NULL   ;
   Transition         transition = NT     ;  
   bool               useScale   = true   ;
   int                pos        = 0      ;   
   int    scaleX = 0, scaleY  = 0;
   int    np     = 0, ng      = 0;

   size_t size = m_nestSimSet.size() ;
   if (size > 8) size = 8;
   for(size_t i = 0; i < size; i++)
   {
      nestSim = m_nestSimSet.getItem (i);
      assert (nestSim);
      np = nestSim->m_np;
      ng = nestSim->m_ng;
      nestComp = &m_nestCompResult[np][ng];
      assert (nestComp);
      transition = nestComp->getBestTransition();
      getAreaScaleP (curGroup, np, scaleX, scaleY);
      pos = tryAdd2curGroup (curGroup, np, ng, transition, m_errorLevel, 0, useScale, scaleX, scaleY);
      if (pos != -1)
         calcScaleForNewPair (curGroup, pos);
   }
}

void Matcher100::buildKernelGroup1 (GroupEx *kernelGroup, bool quickAccelMatch)
{
   kernelGroup->clear();
   NestVirtSize* p = m_nestVirtSizeSet.getItem(0);
   if (!p->m_virtGroupSize)
      return;

   int np0 = p->m_np, ng0 = p->m_ng, np = 0, ng = 0;
   NestCompareResult *compRes = &m_nestCompResult[np0][ng0];
   kernelGroup->add (np0, ng0, compRes->getBestTransition());//, 0);
   bool nearSingular = m_nearSingularP[np0] || m_nearSingularG[ng0];
   int groupAngle = normAngle(m_minutiaeP[np0].Beta - m_minutiaeG[ng0].Beta);
   size_t size = m_nestVirtSizeSet.size();
   for (size_t i = 1; i < size; i++)
   {
      p = m_nestVirtSizeSet.getItem(i);
      if (!p->m_virtGroupSize)
         continue;
      np = p->m_np;
      ng = p->m_ng;
      if (!quickAccelMatch)
      {
         if (!isPairsCompatible(np0, ng0, np, ng, groupAngle, nearSingular))
            continue;
      }
      compRes = &m_nestCompResult[np][ng];
      kernelGroup->add (np, ng, compRes->getBestTransition());//, 0);
   }
   cleanInitialGroup       (kernelGroup   );
   calcScale(kernelGroup);
   m_allowReplacement = true;
   expandGroupByTopology   (kernelGroup, 0);
   kernelGroup->firstGroupComplete();
}

void Matcher100::buildKernelGroup2 (GroupEx *kernelGroup)
{
   kernelGroup->clear();
   NestVirtSize* p = m_nestVirtSizeSet.getItem(0);
   if (!p->m_virtGroupSize)
      return;
   addNestPair2groupEx       (kernelGroup, p->m_np, p->m_ng );

   kernelGroup->firstGroupComplete();
}


// add nest pair together with all they links (in fact binded tree of nests) to current group
void Matcher100::addNestPair2groupEx (GroupEx *curGroup, short np, short ng)
{
   NestCompareResult *compRes = &m_nestCompResult[np][ng];
   size_t start = curGroup->getNumItems();
   // try to add the nest itself
   //short      transitionDif = 0;   
   if (!addNestPair2group(curGroup, np, ng, compRes->getBestTransition(), true, true))
      return;

   // try to add the linked nests
   Transition transition = UNKN;  
   size_t i = start + 1;
   for(; i < curGroup->getNumItems(); i++)
   {
      curGroup->getPair (i, np, ng);
      transition    = curGroup->getTransition   (i);
      //transitionDif = curGroup->getTransitionDif(i);
//      assert (transition < TL_3);
      assert (transition <= MPT);
      addNestPair2group(curGroup, np, ng, transition, false);
   }
//   addReservePairs(curGroup);
}

bool Matcher100::addNestPair2group(GroupEx *curGroup, int np, int ng, Transition transition, bool addCentralNest, 
                                   bool isCentralPointSameDir, bool useScale)
{
   assert(np < m_numNestP);  
   assert(ng < m_numNestG);  
   // try to add the central pair of nests
   int minReplacementPos = 0, scaleX = 0, scaleY = 0;
   if (addCentralNest)
   {
      if (tryAdd2curGroup(curGroup, np, ng, transition, m_errorLevel, minReplacementPos, useScale, scaleX, scaleY) == -1)
         return false;
   }
   // try to add link of central minutiae
   tryAddLinks(curGroup, np, ng, transition, isCentralPointSameDir, useScale);
   return true;
}

bool Matcher100::tryAddLinks(GroupEx *curGroup, int np, int ng, Transition transition,   
                             bool isCentralPointSameDir, bool useScale)
{
   WORD sim = 0;
   short transitionDif = getTransitionDif(np, ng, transition, m_acceptableTransition, sim);
   HitGroup *g = getNestCompareResult (np, ng, transition, transitionDif);
   if (!g)
      return false;

   // try to add link of central minutiae
   int num = g->getNumItems();
   short np1 = 0, ng1 = 0;
   int minReplacementPos = 0, scaleX = 0, scaleY = 0;
   for(int i = 0; i < num; i++)
   {
      if (!g->getPair (i, np1, ng1))
         continue;
      if (curGroup->find (np1, ng1) != -1)
         continue;
      transition = g->getTransition(i);
      //transitionDif = getTransitionDif(np1, ng1, transition, m_acceptableTransition, sim);
      tryAdd2curGroup(curGroup, np1, ng1, transition, m_errorLevel, minReplacementPos, useScale, scaleX, scaleY);
   }
   return true;
}



// try add pair to current group
int Matcher100::tryAdd2curGroup(GroupEx *curGroup, int np, int ng, Transition transition, //short transitionDif,
                                 int errorLevel, size_t minReplacePos,  bool useScale, short scaleX, short scaleY)
{
   if (transition > m_acceptableTransition)
      return -1;
   //if (!m_accelSim[np][ng])            // ������, ����� �� ������� ������� ����� ���� �������������, �.�. m_accelSim � ���� ������ �� �����������!!!
   //   return -1;
   if (curGroup->find(np, ng) != -1)
      return -1;

   int posP = curGroup->findProbe(np);
   int posG = curGroup->findGallery(ng);
   if (posP != -1 || posG != -1)
   {
      if (!m_allowReplacement || (posP >= 0 && posP < (int)minReplacePos) || (posG >= 0 && posG < (int)minReplacePos)) 
         return -1;
      // eiter np or ng already in curGroup - check if replacement will improve curGroup and do it if it's true
      return tryAdd2curGroupWithReplacement(curGroup, np, ng, transition, useScale, scaleX, scaleY);
   }
   int *err = NULL, checkStartPos = 0;
   NumSet<size_t> errorPos, skipPos;
   errorPos.init (1, true);
   skipPos.init  (1, true);
   int maxAcceptableError = 1;
   if (m_allowReplacement)
   {
      if (!curGroup->isCompatible(np, ng, errorLevel, errorPos, maxAcceptableError, err, skipPos, useScale, scaleX, scaleY, checkStartPos))
         return -1;
      // there is only one pair in curGroup that incompatible with (np; ng) - check if the new pair is better and replace to it if it's true
      if (errorPos.getNumItems() && errorPos.getItem(0) < minReplacePos)
         return -1;
      if (errorPos.getNumItems() && errorPos.getItem(0) >= minReplacePos)
         return tryAdd2curGroupWithReplacement1 (curGroup, np, ng, transition, errorPos.getItem(0), useScale, scaleX, scaleY);
   }
   else  
   {
      maxAcceptableError = 0;
      errorPos.clear();
      if (!curGroup->isCompatible(np, ng, errorLevel, errorPos, maxAcceptableError, err, skipPos, useScale, scaleX, scaleY, checkStartPos))
         return -1;
   }
   if (!checkQuadrants(curGroup, np, ng, transition, skipPos, 0, errorPos, maxAcceptableError))
      return -1;
   curGroup->add (np, ng, transition);//, transitionDif);
   return (int)curGroup->getNumItems() - 1;
}

// try to add (np; ng) pair to curGroup, when it incompatible with one pair in curGroup, that in replacePos position
int Matcher100::tryAdd2curGroupWithReplacement1(GroupEx *curGroup, int np, int ng, Transition transition,  
                                                 size_t replacePos, bool useScale, short scaleX, short scaleY)
{
   assert (replacePos < curGroup->getNumItems());
   // check quadrants for new pair with skip compare to pair in replacePos position
   NumSet<size_t> errorPos, skipPos; 
   errorPos.init(1, true);
   skipPos.init (1, true);
   skipPos.add(replacePos);
   size_t maxAcceptableError = 0;
   if (!checkQuadrants(curGroup, np, ng, transition, skipPos, 0, errorPos, maxAcceptableError))
      return -1;

   // compare transition and nests similarity for new and old pairs
   short old_np = 0, old_ng = 0;
   curGroup->getPair (replacePos, old_np, old_ng);
   Transition old_transition      = curGroup->getTransition  (replacePos    );
   int        old_transitionLevel = getTransitionLevel       (old_transition);
   int        transitionLevel     = getTransitionLevel       (transition    );

   WORD     sim = getNestsBestSim(    np,     ng);
   WORD old_sim = getNestsBestSim(old_np, old_ng);

   if (!isNewPairBetter(transitionLevel, old_transitionLevel, sim, old_sim))
      return -1;

   // get old error 
   int err = 0, old_err = 0;
   errorPos.clear();   
   curGroup->isCompatible(    np,     ng, m_errorLevel, errorPos, maxAcceptableError,     &err, skipPos, useScale, scaleX, scaleY, 0);
   errorPos.clear();
   curGroup->isCompatible(old_np, old_ng, m_errorLevel, errorPos, maxAcceptableError, &old_err, skipPos, useScale, scaleX, scaleY, 0);
   if (!isNewPairBetter1(err, old_err, sim, old_sim))
      return -1;

   curGroup->replace (replacePos, np, ng, transition);//, transitionDif);
   return (int)replacePos;
}

// try to add pair to curGroup when when at least np or ng of both already in curGroup
int Matcher100::tryAdd2curGroupWithReplacement(GroupEx *curGroup, int np, int ng, Transition transition, //short transitionDif,
                                                bool useScale, short scaleX, short scaleY)
{
   int   posP                =  0, posG            = 0;
   WORD  old_simP            =  0, old_simG        = 0, sim = 0;
   int   old_np              = np, old_ng          = ng;
   int   old_err             =  0, err             =  0;
   int   old_transitionLevel = NT, transitionLevel = NT;
   
   transitionLevel = getTransitionLevel(transition);
   sim = getNestsBestSim(np, ng);

   if ((posP = curGroup->findProbe(np)) != -1) // np in curGroup
   {
      old_ng            = curGroup->getGallery       (posP);
      old_transitionLevel = getTransitionLevel(curGroup->getTransition(posP));
      old_simP = getNestsBestSim(np,  old_ng);
      if (!isNewPairBetter(transitionLevel, old_transitionLevel, sim, old_simP))
         return -1;
   }
   if ((posG = curGroup->findGallery(ng)) != -1) // ng in curGroup
   {
      old_np = curGroup->getProbe (posG);
      old_transitionLevel = getTransitionLevel(curGroup->getTransition(posG));
      old_simG = getNestsBestSim(old_np, ng);
      if (!isNewPairBetter(transitionLevel, old_transitionLevel, sim, old_simG))
         return -1;
   }
   int max_old_sim = maxAB(old_simP, old_simG);
   NumSet<size_t> skipPos ;
   NumSet<size_t> errorPos;
   skipPos.init  (2, true);
   errorPos.init (1, true);
   if (posP != -1)skipPos.add (posP);
   if (posG != -1)skipPos.add (posG);
   size_t maxAcceptableError = 0;
   if (!curGroup->isCompatible(np, ng, m_errorLevel, errorPos, maxAcceptableError, &err, skipPos, useScale, scaleX, scaleY, 0))
      return -1;
   if (!checkQuadrants (curGroup, np, ng, transition, skipPos, 0, errorPos, maxAcceptableError))
      return -1;
   errorPos.clear();
   curGroup->isCompatible (old_np, old_ng, m_errorLevel, errorPos, maxAcceptableError, &old_err, skipPos, useScale, scaleX, scaleY, 0);
   if (!isNewPairBetter1(err, old_err, sim, max_old_sim))
      return -1;

   if (posP == -1) 
   {
      curGroup->replace (posG, np, ng, transition);//, transitionDif); // no np in curGroup - change pair with ng
      return posG;
   }
   else if (posG == -1) 
   {
      curGroup->replace (posP, np, ng, transition);//, transitionDif); // no ng in curGroup - change pair with np
      return posP;
   }
   else                                                                                   // both np and ng in curGroup 
   {
      curGroup->replace (posP, np, ng, transition);//, transitionDif);
      curGroup->remove  (posG);
      return posP < posG ? posP : posP - 1;
   }
}
bool Matcher100::isNewPairBetter(int new_transitionLevel, int old_transitionLevel, int new_sim, int old_sim)
{
   if (new_transitionLevel <= 1 && old_transitionLevel > 1)  return true;
   if (old_transitionLevel <= 1 && new_transitionLevel > 1)  return false;
   return (new_sim > old_sim);
//   return (new_sim > old_sim && (new_transitionLevel <= 1 || new_transitionLevel <= old_transitionLevel));
}

bool Matcher100::isNewPairBetter1(int new_err, int old_err, int new_sim, int old_sim)
{
   return (new_err < old_err || (new_sim >= old_sim * 2 && new_err <= old_err * 2));
}

//   returns quadrant, where minutiae 'n' located relatively on 'nest'
// and -1 if n don't belong to nest
int Matcher100::getQuadrant (int angle, ESK::Sign *minutiae, ESK::Link *link, int n, bool &isPink, int &rc, Transition trans)
{
   int cage = link->Cage;
   int quadrant = -1;
   for (int ln = 0; ln <= cage; ln++)
   {
      if (link->Knot[ln].Item != n)
         continue;
      ESK::byte_t deal = link->Knot[ln].Deal;
      if (!deal)
         continue;
      //if (pink[ln] == 1)
      //   isPink = true;
      //else if (ln >= 4)
      //{
      //   if (pink[ln - 4]  == 1 && (item[ln - 4] == n) && deal[ln - 4])
      //      isPink = true;
      //}
      int type = minutiae->Type;
      rc = calcRidgeCountEx (trans, type, ln, deal); 
      if (quadrant != -1 && quadrant != Quadrant[type][ln])
         return -1;
      quadrant = Quadrant[type][ln];
   }
   //switch(quadrant)
   //{
   //case 0:
   //   if ((angle > 0 && angle > 120) || angle < -30)
   //      quadrant = -1;
   //   break;
   //case 1:
   //   if ((angle < 0 && angle > -150 )|| angle < 60)
   //      quadrant = -1;
   //   break;
   //case 2:
   //   if ((angle > 0 && angle < 150) || angle > -60)
   //      quadrant = -1;
   //   break;
   //case 3:
   //   if ((angle > 0 && angle > 30) || angle < -120)
   //      quadrant = -1;
   //   break;
   //default:
   //   quadrant = -1;
   //   break;
   //}
   return quadrant;
}


bool Matcher100::checkQuadrants(GroupEx *curGroup, int np, int ng, Transition trans, NumSet<size_t> &skipPos, size_t checkStartPos,
                                NumSet<size_t> &errorPos, size_t maxAcceptableError)
{
   if (!m_checkQuadrants)
      return true;
   assert(np < m_numNestP);  
   assert(ng < m_numNestG);  
   int rcDif = 0;
   ESK::Sign *minutiaeP = &m_minutiaeP[np];
   ESK::Link *linkP     = &m_linkP    [np];
   ESK::Sign *minutiaeG = &m_minutiaeG[ng];
   ESK::Link *linkG     = &m_linkG    [ng];
   size_t num = curGroup->getNumItems();
   short np1 = 0, ng1 = 0;
   int  q1 = -1, q2 = -1;
   bool pinkP = false, pinkG = false;
   int rcP = 0, rcG = 0;
   int rcDifSum = 0, rc = 0;
   int count = 0, lenP = 0, lenG = 0;
   int angleP = 0, angleG = 0;
   for(size_t i = checkStartPos; i < num; i++)
   {
      if (skipPos.find(i) != -1)
         continue;
      curGroup->getPair (i, np1, ng1);
      lenP = m_pairSetP.getLen(np, np1);
      lenG = m_pairSetG.getLenEx(ng, ng1);
      if (lenP > MAX_CHECK_QUADRANT_DIST || lenP < MIN_CHECK_QUADRANT_DIST ||
          lenG > MAX_CHECK_QUADRANT_DIST || lenG < MIN_CHECK_QUADRANT_DIST
          ) continue;
      angleP = -normAngle(minutiaeP->Beta - m_pairSetP.getAngle   (np1, np));
      angleG = -normAngle(minutiaeG->Beta - m_pairSetG.getAngleEx (ng1, ng));
      q1 = getQuadrant (angleP, minutiaeP, linkP, np1, pinkP, rcP, trans);
      q2 = getQuadrant (angleG, minutiaeG, linkG, ng1, pinkG, rcG       );

      if (q1 == -1 || q2 == -1)
      {
         if (!checkAngles(np, ng, np1, ng1))
         {
            if (errorPos.getNumItems() >= maxAcceptableError)
               return false;
            errorPos.add (i);
         }
         continue;
      }
      rc = abs(rcP - rcG);
      if (m_typeP == LATENT || m_typeG == LATENT)
      {
         if (rc > 3)             // � ������ ����, ��� ����� ��� ���� ��������� �� ������������� �� ���������, ��� ���� ������ ������� � �����
            continue;            // �� ������ ����� (�������� � � �����) - ������� �� ���������
      }
      else // not a latent
      {
         if (rc > 2)
         {
            if (errorPos.getNumItems() >= maxAcceptableError)
               return false;
            errorPos.add (i);
            continue;
         }
      }
      if (q1 == q2)
      {
         rcDifSum += rc;
         count++;
         continue;
      }
      // check pinks
      if (isOppositeQuadrants(q1, q2))
      {
         if (m_typeP != LATENT && m_typeG != LATENT && !pinkP && !pinkG)
         {
            if (errorPos.getNumItems() >= maxAcceptableError)
               return false;
            errorPos.add (i);
            continue;
         }
      }
      // if pair close to central point
      else if (isNextQuadrants(q1, q2))
      {
         if (abs(rcP) > 1 || abs(rcG) > 1)
         {
            if (errorPos.getNumItems() >= maxAcceptableError)
               return false;
            errorPos.add (i);
            continue;
         }
      }
      else
      {
         if (errorPos.getNumItems() >= maxAcceptableError)
            return false;
         errorPos.add (i);
         continue;
      }

      rcDifSum += rc;
      count++;
      continue;
   }
   rcDif = count ? rcDifSum * 16 / count : 0;
   return (rcDif <= m_maxRcDif);
}

bool Matcher100::checkAngles(int np, int ng, int np1, int ng1)
{
   assert(np < m_numNestP);  
   assert(ng < m_numNestG);  
   int angle = normAngle((int)m_minutiaeP[np].Beta - (int)m_minutiaeG[ng].Beta);
   int angleP = m_pairSetP.getAngle(np, np1); 
   int angleG = m_pairSetG.getAngleEx(ng, ng1); 
   int angleTol = (m_nearSingularP[np] || m_nearSingularP[np1] || m_nearSingularG[ng] || m_nearSingularG[ng1]) ?
                     90 : 60;//45;
   if (m_pairSetP.getLen(np, np1) < m_dr * 2 || m_pairSetG.getLenEx(ng, ng1) < m_dr * 2)
      return normAngle(angleP - (int)m_minutiaeP[np].Beta) * normAngle(angleG - (int)m_minutiaeG[ng].Beta) > 0;
   return (abs(normAngle(angleP - angleG - angle)) <= angleTol);
}


int Matcher100::compareSuitableAccelerators(int np0, int ng0)
{
   int angleDif= 0, lenP = 0, lenG = 0, count = 0;
   BYTE sim = 0;
   bool nearSingular = m_nearSingularP[np0] || m_nearSingularG[ng0];
   int groupAngle = normAngle(m_minutiaeP[np0].Beta - m_minutiaeG[ng0].Beta);
   memset(m_simHist, 0, sizeof(m_simHist));
   
   for(int np = 0; np < m_numNestP; np++)
   {
      for(int ng = 0; ng < m_numNestG; ng++)
      {
         if (!isCompatibleWitchCentralPoint(np0, ng0, np, ng, groupAngle, nearSingular))
            continue;
         sim = compNestAccel(m_nestAccelP[np], m_nestAccelG[ng]);
         m_accelSim[np][ng] = sim;
         assert (sim <= MAX_NEST_ACCEL_SIM);
         m_simHist[sim]++;
         count++;
      }
   }
   return count;
}

void Matcher100::compareBestNests(BYTE accelThreshold)
{
   // free all data 
   m_nestSimSet.clear();

   NestCompareResult *nestCompareResult = NULL;
   WORD sim = 0;
   HitGroup *g = NULL;
   for (int np = 0; np < m_numNestP; np++)
   for (int ng = 0; ng < m_numNestG; ng++)
   {
      if (m_accelSim[np][ng] < accelThreshold)
         continue;
//      if (m_nearSingularP[np] || m_nearSingularG[ng])
//         continue;
      getNestCompareResult (np, ng, m_acceptableTransition, sim); 
      if (sim > m_k_speed[3])
         m_nestSimSet.insert (np, ng, sim); 
   }
   m_nestSimSet.sort();
}


void Matcher100::compareNestsFromAccelMatch (BYTE *ap, BYTE *ag, BYTE accelGroupSize)
{
   // free all data 
   m_nestSimSet.clear();
   BYTE np  = 0, ng = 0;
   WORD sim = 0;
   for(BYTE i = 0 ; i < accelGroupSize; i++)
   {
      np = ap[i];
      ng = ag[i];
      assert (np >= 0 && np < m_numNestP);
      assert (ng >= 0 && ng < m_numNestG);
      getNestCompareResult (np, ng, m_acceptableTransition, sim);
      m_nestSimSet.insert (np, ng, sim); 
   }
   m_nestSimSet.sort();
}


BYTE Matcher100::buildVirtualGroup(short np0, short ng0)
{
   m_virtGroup.clear();
   NestCompareResult *nestCompRes = &m_nestCompResult[np0][ng0];
//return nestCompRes->getBestSim();
   Transition transition = nestCompRes->getBestTransition();
   HitGroup *g = nestCompRes->getGroup (transition);
   if (!g) 
      return 0;
   return g->getNumItems() + 1;
   //m_virtGroup.add(np0, ng0, transition);
   //int groupAngle = normAngle(m_minutiaeP[np0].Beta - m_minutiaeG[ng0].Beta);

   //int num = g->getNumItems();
   //short np = 0, ng = 0; 
   //for(int i = 0; i < num; i++)
   //{
   //   g->getPair(i, np, ng);
   //   if (!m_virtGroup.canAdd (np, ng))
   //      continue;
   //   transition = g->getTransition(i);
   //   m_virtGroup.addWoCheck(np, ng, transition);
   //}
   //return (BYTE)m_virtGroup.getNumItems();

}


void Matcher100::chooseBestNests (size_t numPassedNests, size_t minVirtualGroupSize)
 {
   m_nestVirtSizeSet.clear();
   BYTE np = 0, ng = 0;
   BYTE virtualGroupSize = 0;
   for(size_t count = 0; count < numPassedNests; count++)
   {
      np = m_nestSimSet.getItem (count)->m_np;
      ng = m_nestSimSet.getItem (count)->m_ng;
      virtualGroupSize = buildVirtualGroup(np, ng);
      if (virtualGroupSize < minVirtualGroupSize)
         continue;
      m_nestVirtSizeSet.insert (np, ng, virtualGroupSize);
   }
   m_nestVirtSizeSet.sort();
}


// check if new pair of links better fit one to another
bool Matcher100::isNewLinksBetter(HitGroup &g, int replaceNum, int np, int ng, int newTransition, int np0, int ng0)
{
   assert (np >= 0 && np < m_numNestP);
   assert (ng >= 0 && ng < m_numNestG);

   
   // check transition level: if pairs have different level of transition, take with less level
   Transition oldTransition = g.getTransition(replaceNum);
 //  if (newTransition != oldTransition)   // ��� �\��� �������� �����. ������? ��� �������, ��� ������� � ����� ������� ��� 
                                           // (�.�. ��� � ������������ ������ ������ �� ������ � NT),
                                           // �� ������� ���������� �� ����� ������� �����?
   {
      if (newTransition == NT)// && oldTransition > NT)
         return true;
      if (oldTransition == NT)// && newTransition > NT)
         return false;
      if (newTransition <  TL_2 && oldTransition >= TL_2)
         return true;
      if (newTransition >= TL_2 && oldTransition <  TL_2)
         return false;
   }
   if (newTransition != oldTransition)    
   {
      //assert (newTransition <= MPT && oldTransition <= MPT);
      //if      (newTransition <  TL_1)  // NT  
      //   return true;
      //else if (newTransition <  TL_2) // 1st level
      //{
      //   if      (oldTransition >= TL_2) return true;
      //   else if (oldTransition <  TL_1) return false;
      //}
      //else                           //more than 1st level
      //{
      //        if (oldTransition <  TL_2) return false;
      //}
   //   //else if (newTransition <  TL_3) // 2nd level
   //   //{
   //   //   if      (oldTransition >= TL_3) return true;
   //   //   else if (oldTransition <  TL_2) return false;
   //   //}
   //   //else if (newTransition <  TL_4) // 3rd level
   //   //{
   //   //   if      (oldTransition >= TL_4) return true;
   //   //   else if (oldTransition <  TL_3) return false;
   //   //}
   //   //else if (newTransition <  TL_5) // 4th level
   //   //{
   //   //   if      (oldTransition >= TL_5) return true;
   //   //   else if (oldTransition <  TL_4) return false;
   //   //}
   //   //else if (newTransition <  TL_6) // 5th level
   //   //{
   //   //   if      (oldTransition >= TL_6) return true;
   //   //   else if (oldTransition <  TL_5) return false;
   //   //}
   //   //else                              // 6th level
   //   //{
   //   //   if (oldTransition <  TL_6) return false;
   //   //}
   }

   int old_np = g.getProbe   (replaceNum);
   int old_ng = g.getGallery (replaceNum);
   assert (old_np >= 0 && old_np < m_numNestP);
   assert (old_ng >= 0 && old_ng < m_numNestG);

   if (m_nestCompResult[old_np][old_ng].isMatched() && m_nestCompResult[np][ng].isMatched())
   {
      return (m_nestCompResult[np][ng].getBestSim() > m_nestCompResult[old_np][old_ng].getBestSim());
   }
   else if (m_accelSim[np][ng] > m_accelSim[old_np][old_ng])
      return true;
   else if (abs(m_pairSetP.getLen (np0, np) - m_pairSetG.getLenEx(ng0, ng)) <  abs(m_pairSetP.getLen(np0, old_np) - m_pairSetG.getLenEx(ng0, old_ng))) 
      return true;
   
   //if (m_accelSim[np][ng] != m_accelSim[old_np][old_ng])
   //   return (m_accelSim[np][ng] > m_accelSim[old_np][old_ng]);
   //if (abs(m_pairSetP.getLen (np0, np) - m_pairSetG.getLenEx(ng0, ng)) <  abs(m_pairSetP.getLen(np0, old_np) - m_pairSetG.getLenEx(ng0, old_ng))) 
   //   return true;


   //short oldDistErr = 0, newDistErr = 0;
   //compPairLen(m_pairSetP.getLen(np0,     np), m_pairSetG.getLenEx(ng0,     ng), &newDistErr);
   //compPairLen(m_pairSetP.getLen(np0, old_np), m_pairSetG.getLenEx(ng0, old_ng), &oldDistErr);

   return false;
}

void Matcher100::compNestsAlt (short np, short ng, Transition transition, int groupAngle)
{
   assert(np < m_numNestP);  
   assert(ng < m_numNestG);  

   m_compNestHitGroup.clear();
   m_compNestHitGroup.setMainTransition(transition);
   ESK::Sign *minutiaeP = &m_minutiaeP[np];
   ESK::Link *linkP     = &m_linkP    [np];
   ESK::Sign *minutiaeG = &m_minutiaeG[ng];
   ESK::Link *linkG     = &m_linkG    [ng];
   int typeP            = minutiaeP->Type; 
   short errA = 0, errR = 0, errA1 = 0;

   NotHit notHitP[MAX_MINUTIAE];
   NotHit notHitG[MAX_MINUTIAE];
   // initial filling of notHit
   int np1 = 0, ng1 = 0;                  // number of minutiae on link
   for (int lp = 0; lp < linkP->Cage; lp++)
   {
      if (!linkP->Knot[lp].Deal)
         continue;
      np1 = linkP->Knot[lp].Item;
      if(np1 >= m_numNestP)
         continue;
      notHitP[np1].notHit = 1;
   }
   for (int lg = 0; lg < linkG->Cage; lg++)
   {
      if (!linkG->Knot[lg].Deal)
         continue;
      ng1 = linkG->Knot[lg].Item;
      if(ng1 >= m_numNestG)
         continue;
      notHitG[ng1].notHit = 1;
   }


   int *transitionArray = getTransitionArray(transition);
   Transition trans = NT;
   bool sameDir = true;
   int dealP =0, dealG = 0;                // link number

   int lg = 0;                            // number of link in gallery fingerprint
   int maxLink = linkP->Cage;
   if (!maxLink)
      return;

   for (int lp = 0; lp < maxLink; lp++)   // go through probe links
   {
      dealP = linkP->Knot[lp].Deal;      
      lg = transitionArray[lp];  
      if (lg < 0)
         continue;
      dealG = linkG->Knot[lg].Deal;      
      trans = T2T[dealP][dealG];
      if (trans > MPT)
         continue;
      np1  = linkP->Knot[lp].Item;   
      if(np1 >= m_numNestP || np1 == np)
         continue;
      ng1 = linkG->Knot[lg].Item;    
      if(ng1 >= m_numNestG|| ng1 == ng)
         continue;
      //if (!m_accelSim[np1][ng1])
      //   continue;
      if (m_compNestHitGroup.find(np1, ng1) != -1) 
         continue;
      sameDir = isSameDirection (dealP, (MINUTIAE_TYPE)typeP, lp);
      if (checkLink(np, ng, np1, ng1, groupAngle, &errR,  &errA, &errA1))
         add2hit(m_compNestHitGroup, notHitP, notHitG, np1, ng1, trans, sameDir, np, ng, &errR,  &errA, &errA1);
   }
   calcNestSim(np, ng, m_compNestHitGroup, notHitP, notHitG, false);
}

void Matcher100::compNestsFinal(short np, short ng, Transition transition, int groupAngle)
{
   assert(np < m_numNestP && ng < m_numNestG);  
   m_compNestHitGroup.clear();
   m_compNestHitGroup.setMainTransition(transition);
   ESK::Sign *minutiaeP = &m_minutiaeP[np];
   ESK::Link *linkP     = &m_linkP    [np];
   ESK::Sign *minutiaeG = &m_minutiaeG[ng];
   ESK::Link *linkG     = &m_linkG    [ng];
   int typeP           = minutiaeP->Type; 
   int typeG           = minutiaeG->Type; 
   short errR = 0, errA = 0, errA1 = 0;
   //short *pErrA = NULL, *pErrR = NULL, *pErrGA = NULL;
   //memset(m_errA,  0, sizeof(m_errA )); 
   //memset(m_errR,  0, sizeof(m_errR )); 
   //memset(m_errGA, 0, sizeof(m_errGA)); 
   //pErrA  = &errA ;
   //pErrR  = &errR ;
   //pErrGA = &errGA;
   groupAngle = normAngle((int)m_minutiaeP[np].Beta - (int)m_minutiaeG[ng].Beta);

   NotHit notHitP[MAX_MINUTIAE], notHitG[MAX_MINUTIAE];
   int *transitionArray = getTransitionArray(transition);
   Transition trans = NT;
   bool sameDirP = true, sameDirG = true;
   int  dealP    = 0   , dealG    = 0   ;                // link number
   int  np1      = 0   , ng1      = 0   ;                // number of minutiae on link
   int  lg       = 0   ;                                 // number of link in gallery fingerprint

   int maxLink = linkP->Cage;
   if (!maxLink)
      return;
   int maxRightLinkP = 0, maxLeftLinkP = 0;
   getMaxRightAndLeftLink (minutiaeP->Type, linkP, linkG, transition, maxRightLinkP, maxLeftLinkP);

   for (int lp = 0; lp < maxLink; lp++)   // go through probe links
   {
      if (isRightLink[typeP][lp])
      {
         if (lp > maxRightLinkP)
            continue;
      }
      else
      {
         if (lp > maxLeftLinkP)
            continue;
      }
      dealP = linkP->Knot[lp].Deal;      
      lg = transitionArray[lp];  
      if (lg < 0)
         continue;
      dealG = linkG->Knot[lg].Deal;      
      if(!dealP && !dealG)
         continue;
      if (dealP)
      {
         np1  = linkP->Knot[lp].Item;   
         if(np1 == np || np1 >= m_numNestP)
            continue;
         sameDirP = isSameDirection (dealP, (MINUTIAE_TYPE)typeP, lp);
         if (m_curGroup->findProbe (np1) == -1)
         {
            notHitP[np1].notHit    = 1;
            notHitP[np1].isSameDir = sameDirP;
            continue;
         }
      }
      if (dealG)
      {
         ng1 = linkG->Knot[lg].Item;    
         if(ng1 == ng || ng1 >= m_numNestG)
            continue;
         sameDirG = isSameDirection (dealG, (MINUTIAE_TYPE)typeG, lg);
         if (m_curGroup->findGallery (ng1) == -1)
         {
            notHitG[ng1].notHit    = 1;
            notHitG[ng1].isSameDir = sameDirG;
            continue;
         }
      }
      if(!dealP || !dealG)
         continue;
      if (m_curGroup->find(np1, ng1) == -1) // np1 and ng1 exist in m_curGroup, but not in this combination
         continue;
      if (m_compNestHitGroup.find(np1, ng1) != -1) // (np1, ng1) already added
         continue;
      trans = T2T[dealP][dealG];
      if (trans > MPT)
         continue;
      checkMinAngles(np1, ng1, groupAngle, &errA); 
      compPairLen(m_pairSetP.getLen(np, np1), m_pairSetG.getLenEx(ng, ng1), m_errorLevel, &errR); 
//      compPairLen(m_pairSetP.getLen(np, np1), dist(m_minutiaeGR[ng].m_x, m_minutiaeGR[ng].m_y, m_minutiaeGR[ng1].m_x, m_minutiaeGR[ng1].m_y), m_errorLevel, &errR); 
      checkAngle1 (np1, np, ng1, ng, &errA1);
      m_compNestHitGroup.add (np1, ng1, trans, errR, errA, errA1);
   }
   calcNestSim(np, ng, m_compNestHitGroup, notHitP, notHitG, true);
}


void Matcher100::getMaxRightAndLeftLink(ESK::byte_t type_p, ESK::Link *linkP, ESK::Link *linkG, Transition transition, int &maxRightLinkP, int &maxLeftLinkP)
{
   maxRightLinkP = 0, maxLeftLinkP = 0;

   int maxRightLinkG = 0, maxLeftLinkG = 0;
   int maxLink        = linkP->Cage;
   int *transitionArray = getTransitionArray(transition);
   int lg = 0;
   for (int lp = 1; lp < maxLink; lp++)   // go through probe links
   {
      lg = transitionArray[lp];  
      if (isRightLink[type_p][lp])
      {
         if (linkP->Knot[lp].Deal) maxRightLinkP = lp;
         if (linkG->Knot[lg].Deal) maxRightLinkG = lp;
      }
      else
      {
         if (linkP->Knot[lp].Deal) maxLeftLinkP  = lp;
         if (linkG->Knot[lg].Deal) maxLeftLinkG  = lp;
      }
   }
   maxRightLinkP = minAB (maxRightLinkP, maxRightLinkG);
   maxLeftLinkP  = minAB (maxLeftLinkP , maxLeftLinkG );
}

// fill notHitP array
//void Matcher100::fillNotHitProbe(int maxLink, ESK::byte_t *deal_p, ESK::twin_t *item_p, HitGroup &hitGroup, int *notHitP)
//{
//   // fill notHitP array
//   int np1 = 0;
//   for (int lp = 0; lp < maxLink; lp++)   // go through probe links
//   {
//      if (!deal_p[lp])
//         continue;
//      np1 = item_p[lp]; 
//      if(np1 >= m_numNestP)
//         continue;
//      if (hitGroup.findProbe(np1) == -1) 
//         notHitP[np1] = 1;
//   }
//}
//// fill notHitP array
//void Matcher100::fillNotHitGallery(int maxLink, ESK::byte_t *deal_g, ESK::twin_t *item_g, HitGroup &hitGroup, int *notHitG)
//{
//   // fill notHitG array
//   int ng1 = 0;
//   for (int lg = 0; lg < maxLink; lg++)   // go through gallery links
//   {
//      if (!deal_g[lg])
//         continue;
//      ng1  = item_g[lg]; 
//      if(ng1 >= m_numNestG)
//         continue;
//      if (hitGroup.findGallery(ng1) == -1) 
//         notHitG[ng1] = 1;
//   }
//}


// check if (np1, ng1) links in (np, ng) nests pair are compatible
bool Matcher100::checkLink(short np, short ng, short np1, short ng1, int groupAngle, short *errR, short *errA, short *errA1)
{
   if (!checkMinAngles(np1, ng1, groupAngle, errA))
      return false;
   if (!compPairLen(m_pairSetP.getLen(np, np1), m_pairSetG.getLenEx(ng, ng1), m_errorLevel, errR))
      return false;
//   if (!checkGroupAngles (np1, np, ng1, ng, groupAngle, errGA))
   if (!checkAngle1 (np1, np, ng1, ng, errA1))
      return false;
   return true;
}

// add new pair to hit group
void Matcher100::add2hit(HitGroup &hitGroup, NotHit *notHitP, NotHit *notHitG, int np, int ng, Transition trans, bool sameDir, int np0, int ng0,
                           short *errR, short *errA, short *errA1)
{
   assert(np < m_numNestP && np0 < m_numNestP && ng < m_numNestG && ng0 < m_numNestG);  

   // check for double links
   int posP = hitGroup.findProbe   (np);
   int posG = hitGroup.findGallery (ng);

   if (posP != -1 && posG != -1) // already have a pair with np and ng
   {
      if (!isNewLinksBetter(hitGroup, posP, np, ng, trans, np0, ng0) ||
          !isNewLinksBetter(hitGroup, posG, np, ng, trans, np0, ng0))
          return;
      // a new pair is better both of old pairs
      hitGroup.replace (posP, np, ng, trans, *errR, *errA, *errA1);
      hitGroup.remove (posG);
   }
   else if (posP != -1) // already have a pair with np
   { 
      if (!isNewLinksBetter(hitGroup, posP, np, ng, trans, np0, ng0))
         return;
      hitGroup.replace (posP, np, ng, trans, *errR, *errA, *errA1);
   }
   else if (posG != -1)// already have a pair with ng
   {  
      if (!isNewLinksBetter(hitGroup, posG, np, ng, trans, np0, ng0))
         return;
      hitGroup.replace (posG, np, ng, trans, *errR, *errA, *errA1);
   }
   else
      hitGroup.add (np, ng, trans, *errR, *errA, *errA1);
}

// clean notHit group from numbers, those in hitGroup
void Matcher100::clearNotHitGroup(HitGroup &hitGroup, NotHit *notHitP, NotHit *notHitG, bool finalCalc) 
{
   // remove items those in hitGroup
   int num = hitGroup.getNumItems();
   short np = 0, ng = 0, replaceNum = -1;
   for(int i = 0; i < num; i++)
   {
      hitGroup.getPair (i, np, ng);
      assert(np < m_numNestP && ng < m_numNestG);
      notHitP[np].notHit = 0;
      notHitG[ng].notHit = 0;
   }
   if (!finalCalc)
      return;
   // remove items those in m_excludeP
   for(int np = 0; np < m_numNestP; np++)
      if (m_excludeP[np])
         notHitP[np].notHit = 0;
   // remove items those in m_excludeG
   for(int ng = 0; ng < m_numNestG; ng++)
      if (m_excludeG[ng])
         notHitG[ng].notHit = 0;
}



// try to add the linked nests
void Matcher100::expandGroupByTopology(GroupEx* curGroup, size_t startPos)
{
//   calcScale(curGroup);
   short       np                    = 0    , ng     = 0;
   int         scaleX                = 0    , scaleY = 0;
   int         minReplacePos         = 0    ;
   bool        useScale              = true ;    
   Transition  transition            = UNKN ;  
   short       transitionDif         = 0;   
   WORD        bestSim               = 0    ;
   int         pos                   = 0;
   size_t     initialGroupSize = curGroup->getNumItems();
   for(size_t i = startPos; i < curGroup->getNumItems(); i++)
   {
      curGroup->getPair (i, np, ng);
      transition = curGroup->getTransition(i);
      HitGroup *g = getNestCompareResult (np, ng, transition, transitionDif);
      if (!g)
         continue;
      int num = g->getNumItems();
      short np1 = 0, ng1 = 0;
      int  rcDif   =    0;
      for(int j = 0; j < num; j++)
      {
         if (!g->getPair (j, np1, ng1))
            continue;
         //if (!m_accelSim[np1][ng1])
         //   continue;
         if (curGroup->find (np1, ng1) != -1)
            continue;
         getAreaScaleP(curGroup, np1, scaleX, scaleY);
         transition    = g->getTransition(j);
         //transitionDif = getTransitionDif (np1, ng1, transition, B2RB_2, bestSim); 
         if ((pos = tryAdd2curGroup (curGroup, np1, ng1, transition,  
                              m_errorLevel, minReplacePos, useScale, scaleX, scaleY)) == -1)
            continue;
         calcScaleForNewPair (curGroup, pos);
      }
   }
   if (curGroup->getNumChanges() > initialGroupSize * 25 / 100)
      calcScale(curGroup);
}

void Matcher100::fillCoflictPosSet(ConflictPosSet &conflictPosSet)
{
   short       np                    = 0    , ng     = 0;
   int         scaleX                = 0    , scaleY = 0;
   int         minReplacePos         = 0    ;
   bool        useScale              = true ;    
   Transition  transition            = UNKN ;  
   short       transitionDif         = 0;   
   WORD        bestSim               = 0    ;
   int         pos                   = 0;
   int         checkStartPos         = 0;

   size_t maxAcceptableError = MAX_ERROR_POS;
   NumSet <size_t> errorPos;
   NumSet <size_t> skipPos ;
   errorPos.init(MAX_ERROR_POS, true);
   skipPos.init (2            , true);

   for(size_t i = 0; i < m_curGroup->getNumItems(); i++)
   {
      m_curGroup->getPair (i, np, ng);
      transition = m_curGroup->getTransition(i);
      HitGroup *g = getNestCompareResult (np, ng, transition, transitionDif);
      if (!g)
         continue;
      int num = g->getNumItems();
      short np1 = 0, ng1 = 0;
      int  rcDif   =    0;
      for(int j = 0; j < num; j++)
      {
         if (!g->getPair (j, np1, ng1))
            continue; 
//         if (!m_accelSim[np1][ng1])
//            continue;
         if (m_curGroup->find (np1, ng1) != -1)
            continue;
         transition    = g->getTransition(j);
         transitionDif = getTransitionDif (np1, ng1, transition, B2RB_2, bestSim); 
         if (transition > m_acceptableTransition)
            continue;
         int posP = m_curGroup->findProbe(np1);
         int posG = m_curGroup->findGallery(ng1);
         maxAcceptableError = MAX_ERROR_POS;
         ConflictPos conflictPos;
         skipPos.clear();
         errorPos.clear();
         if (posP != -1) skipPos.add(posP), maxAcceptableError--;
         if (posG != -1) skipPos.add(posG), maxAcceptableError--;
         assert (maxAcceptableError >= 0);
         getAreaScaleP(m_curGroup, np1, scaleX, scaleY);
         if (!m_curGroup->isCompatible(np1, ng1, m_errorLevel, errorPos, maxAcceptableError, NULL, skipPos, useScale, scaleX, scaleY, checkStartPos))
            continue;
         conflictPos.set (np1, ng1, transition, scaleX, scaleY, skipPos, errorPos);
         if (!checkQuadrants(m_curGroup, np1, ng1, transition, skipPos, 0, errorPos, maxAcceptableError))
            continue;
         conflictPos.update (errorPos);
         conflictPosSet.insert (conflictPos);
      }
   }
}


void Matcher100::fillCoflictPosSetForNestSimSet(GroupEx* curGroup, ConflictPosSet &conflictPosSet)
{
   short       np                    = 0    , ng     = 0;
   int         scaleX                = 0    , scaleY = 0;
   int         minReplacePos         = 0    ;
   bool        useScale              = true ;    
   Transition  transition            = UNKN ;  
   //short       transitionDif         = 0;   
   WORD        bestSim               = 0    ;
   int         pos                   = 0;
   int         checkStartPos         = 0;

   size_t maxAcceptableError = MAX_ERROR_POS;
   NumSet <size_t> errorPos;
   NumSet <size_t> skipPos ;
   errorPos.init(MAX_ERROR_POS, true);
   skipPos.init (2            , true);

   size_t sizeNestSet = m_nestSimSet.size() ;
   if (sizeNestSet > 8 ) sizeNestSet = 8;
   for(size_t i = 0; i < sizeNestSet; i++)
   {
      if (!m_nestSimSet.getItem (i)->m_sim)
         continue;
      np = m_nestSimSet.getItem (i)->m_np;
      ng = m_nestSimSet.getItem (i)->m_ng;
      transition = m_nestCompResult[np][ng].getBestTransition();
      int  rcDif   =    0;
      //if (!m_accelSim[np][ng])   // ������, ����� �� ������� ������� ����� ���� �������������, �.�. m_accelSim � ���� ������ �� �����������!!!
      //   continue;
      if (curGroup->find (np, ng) != -1)
         continue;
      int posP = curGroup->findProbe(np);
      int posG = curGroup->findGallery(ng);
      maxAcceptableError = MAX_ERROR_POS;
      ConflictPos conflictPos;
      skipPos.clear();
      errorPos.clear();
      if (posP != -1) skipPos.add(posP), maxAcceptableError--;
      if (posG != -1) skipPos.add(posG), maxAcceptableError--;
      assert (maxAcceptableError >= 0);
      getAreaScaleP(curGroup, np, scaleX, scaleY);
      if (!curGroup->isCompatible(np, ng, m_errorLevel, errorPos, maxAcceptableError, NULL, skipPos, useScale, scaleX, scaleY, checkStartPos))
         continue;
      conflictPos.set (np, ng, transition, scaleX, scaleY, skipPos, errorPos);
      if (!checkQuadrants(curGroup, np, ng, transition, skipPos, 0, errorPos, maxAcceptableError))
         continue;
      conflictPos.update (errorPos);
      conflictPosSet.insert (conflictPos);
   }
}


void Matcher100::testExpandCases(ConflictPosSet &conflictPosSet)
{
   size_t size = conflictPosSet.getNumItems(), count = 0;
   int profitThreshold = 0;
   ConflictPos *conflictPos = NULL;
   size_t bestPos = 0, bestNumItems = 0;
   for (size_t i = 0; i < size; i++)
   {
      if (conflictPosSet.getProfit (i) < profitThreshold)
         continue;
      m_expandGroups[count] = *m_curGroup;
      // remove all conflict pos from m_expandGroups[count]
      conflictPos = conflictPosSet.getItem(i);
      size_t numPos = conflictPos->getNumPos();
      m_expandGroups[count].remove (conflictPos->getPosArray(), (int)conflictPos->getNumPos());
      // try to add all pairs from conflictPos and count a real profit (in case if some pairs incompatible)
      size_t numPairs = conflictPos->getNumPairs();
      int realProfit = 0 - (int)numPos;
      int pos = 0;
      PairEx2 *pair = NULL;
      int minReplacePos = (int)m_expandGroups[count].getNumItems();
      bool useScale = true;
      for (size_t j = 0; j < numPairs; j++)
      {
         pair = conflictPos->getPair(j);
         if ((pos = tryAdd2curGroup (&m_expandGroups[count], pair->m_np, pair->m_ng, pair->m_transition,  
                              m_errorLevel, minReplacePos, useScale, pair->m_scaleX, pair->m_scaleY)) == -1)
            continue;
         realProfit++;
         calcScaleForNewPair (&m_expandGroups[count], pos);
      }
      if (realProfit < profitThreshold)
         continue;
      expandGroupByTopology(&m_expandGroups[count], minReplacePos);
      if (m_expandGroups[count].getNumItems() > bestNumItems)
      {
         bestNumItems = (int)m_expandGroups[count].getNumItems();
         bestPos = count;
      }
      if (++count >= MAX_EXPAND_GROUPS)
         break;
   }
   if (m_expandGroups[bestPos].getNumItems() > m_curGroup->getNumItems())
      *m_curGroup = m_expandGroups[bestPos];
}

void Matcher100::testExpandCasesForNestSimSet (GroupEx* curGroup, ConflictPosSet &conflictPosSet)
{
   size_t size = conflictPosSet.getNumItems(), count = 0;
   int profitThreshold = 0;
   ConflictPos *conflictPos = NULL;
   size_t bestPos = 0, bestNumItems = 0;
   for (size_t i = 0; i < size; i++)
   {
      if (conflictPosSet.getProfit (i) < profitThreshold)
         continue;
      m_expandGroups[count] = *curGroup;
      // remove all conflict pos from m_expandGroups[count]
      conflictPos = conflictPosSet.getItem(i);
      size_t numPos = conflictPos->getNumPos();
      m_expandGroups[count].remove (conflictPos->getPosArray(), (int)conflictPos->getNumPos());
      // try to add all pairs from conflictPos and count a real profit (in case if some pairs incompatible)
      size_t numPairs = conflictPos->getNumPairs();
      int realProfit = 0 - (int)numPos;
      int pos = 0;
      PairEx2 *pair = NULL;
      int minReplacePos = (int)m_expandGroups[count].getNumItems();
      bool useScale = true;
      for (size_t j = 0; j < numPairs; j++)
      {
         pair = conflictPos->getPair(j);
         if ((pos = tryAdd2curGroup (&m_expandGroups[count], pair->m_np, pair->m_ng, pair->m_transition,  
                              m_errorLevel, minReplacePos, useScale, pair->m_scaleX, pair->m_scaleY)) == -1)
            continue;
         realProfit++;
         calcScaleForNewPair (&m_expandGroups[count], pos);
      }
      if (realProfit < profitThreshold)
         continue;
      expandGroupByTopology(&m_expandGroups[count], minReplacePos);
      if (m_expandGroups[count].getNumItems() > bestNumItems)
      {
         bestNumItems = (int)m_expandGroups[count].getNumItems();
         bestPos = count;
      }
      if (++count >= MAX_EXPAND_GROUPS)
         break;
   }
   if (m_expandGroups[bestPos].getNumItems() > curGroup->getNumItems())
      *curGroup = m_expandGroups[bestPos];
}

void Matcher100::expandCurGroupByTopologyAlt()
{
//   calcScale(m_curGroup);

   ConflictPosSet conflictPosSet; 
   conflictPosSet.init (MAX_EXPAND_GROUPS);
   
   fillCoflictPosSet(conflictPosSet);
   testExpandCases(conflictPosSet);

   calcScale(m_curGroup);
}

void Matcher100::expandGroupByNestSimSetAlt(GroupEx* curGroup)
{
   size_t initialGroupSize = curGroup->getNumItems();
   calcScale(curGroup);

   ConflictPosSet conflictPosSet; 
   conflictPosSet.init (MAX_EXPAND_GROUPS);
  
   fillCoflictPosSetForNestSimSet(curGroup, conflictPosSet);
   testExpandCasesForNestSimSet  (curGroup, conflictPosSet);
   
   calcScale(curGroup);
}

void Matcher100::findAllCompatiblePairs()
{
   int scaleX = 0, scaleY = 0;
   bool               useScale   = true;
   int                rcDif      = 0   ;
   WORD               sim        = 0   ;

   if (m_expandGroupPairSet.size())
      m_expandGroupPairSet.clear();
   int *err = NULL, checkStartPos = 0;
   size_t maxAcceptableError = (m_typeP == LATENT || m_typeG == LATENT) ? 1 : 0;
   NumSet <size_t> errorPos, skipPos;
   errorPos.init (MAX_ERROR_POS, true);
   skipPos.init  (2            , true);
   
   for(int np = 0; np < m_numNestP; np++)
   {
      if (m_takenP[np])
         continue;
      if (m_strongExcludeP[np])
         continue;
      getAreaScaleP(m_curGroup, np, scaleX, scaleY);
      for(int ng = 0; ng < m_numNestG; ng++)
      {
         if (m_takenG[ng])
            continue;
         if (m_strongExcludeG[ng])
            continue;
         //if (!m_accelSim[np][ng])
         //   continue;
         errorPos.clear();
         if (!m_curGroup->isCompatible (np, ng, m_errorLevel, errorPos, maxAcceptableError, err, skipPos, useScale, scaleX, scaleY, checkStartPos)) 
            continue;
         if (!checkQuadrants(m_curGroup, np, ng, UNKN, skipPos, 0, errorPos, maxAcceptableError))
            continue;
         getNestCompareResult (np, ng, B2RB_2, sim); 
         if (!errorPos.getNumItems())
         {
            m_expandGroupPairSet.insert (np, ng, sim, -1);//,  0, 0); 
            continue;
         }
         int conflictPos = (int)errorPos.getItem(0);
         m_expandGroupPairSet.insert (np, ng, sim, conflictPos);//, m_curGroup->getSim (conflictPos), m_curGroup->getNumItems()); 
      } 
   }
}

void Matcher100::buildExpandGroup (GroupEx *expandGroup, short np, short ng, short conflictPos, WORD conflictSim, int numParentsItem)
{
   assert(expandGroup);
   expandGroup->clear();
   expandGroup->setConflictPos    (conflictPos   );
   //expandGroup->setConflictSim    (conflictSim   );
   //expandGroup->setNumParentsItem (numParentsItem);

   WORD sim = 0;
   short np1  = 0, ng1    = 0;
   short np2  = 0, ng2    = 0;
   int scaleX = 0, scaleY = 0;
   bool       useScale        = false;
   Transition transition      =    NT;
   short      transitionDif   =     0;

   NestCompareResult *nestComp = getNestCompareResult (np, ng, B2RB_2, sim);
//   if (!sim)
  //    return;
   Transition bestTransition = nestComp->getBestTransition();
   expandGroup->add (np, ng, bestTransition);//, transitionDif);//, sim); 
//   int *err = NULL, checkStartPos = 0;
   int err, checkStartPos = 0;
   size_t maxAcceptableError = 0;
   NumSet <size_t> errorPos, skipPos;
   errorPos.init (1, true);
   skipPos.init  (1, true);
   for(size_t i = 0; i < expandGroup->getNumItems(); i++)
   {
      expandGroup->getPair (i, np1, ng1);
      transition = expandGroup->getTransition (i);
      HitGroup *g = getNestCompareResult (np1, ng1, transition, transitionDif);
      if (!g)
         continue;
      int num = g->getNumItems();
      for(int j = 0; j < num; j++)
      {
         g->getPair (j, np2, ng2);
         if (m_expandGroupPairSet.find (np2, ng2) == -1)
            continue;
         if (!expandGroup->canAdd (np2, ng2))
            continue;
//         getAreaScaleP(expandGroup, np2, scaleX, scaleY);
         errorPos.clear();
         if (!expandGroup->isCompatible(np2, ng2, m_errorLevel, errorPos, maxAcceptableError, &err, skipPos, useScale, scaleX, scaleY, checkStartPos))
            continue;
         transition    = g->getTransition (j);
         transitionDif = getTransitionDif (np2, ng2, transition, B2RB_2, sim);
         if (!checkQuadrants(expandGroup, np2, ng2, transition, skipPos, 0, errorPos, maxAcceptableError))
            continue;
         expandGroup->add (np2, ng2, transition);//, transitionDif);//, sim + 1, (short)err); // (sim + 1)  - to avoid cases when all sim = 0. 
                                                                          // In this case sorting will be equal sorting by numItems
      }
   }
}

size_t Matcher100::buildExpandGroups()
{
   BYTE np = 0, ng = 0;
   short conflictPos = -1;
   WORD conflictSim = 0;
   int  numParentItems = 0;
   size_t numExpandGroups = m_k_speed[13];
   size_t num = minAB(m_expandGroupPairSet.size(), numExpandGroups);

   m_expandGroupPairSet.sort();
   ExpandGroupPair *pair = NULL;
   for(size_t i = 0; i < num; i++)
   {
      pair = m_expandGroupPairSet.getSortedItem(i);
      assert(pair);
      np             = pair->m_np;
      ng             = pair->m_ng;
      conflictPos    = pair->m_conflictPos;
      conflictSim    = pair->m_conflictSim;
      numParentItems = pair->m_numParentItems;
      buildExpandGroup (&m_expandGroups[i], np, ng, conflictPos, conflictSim, numParentItems);
   }
   // sort expand groups by number of items
   for(size_t i = 0; i < numExpandGroups; i++)
      m_p_expandGroups[i] = &m_expandGroups[i];
   if (m_typeP == LATENT || m_typeG == LATENT)
      qsort(m_p_expandGroups, num, sizeof(m_p_expandGroups[0]), sortKernalGroupsByNumItems);   
   else
      qsort(m_p_expandGroups, num, sizeof(m_p_expandGroups[0]), sortKernalGroupsBySumSim);   

   return num;
}


BYTE Matcher100::getSimThreshold(int numPassed, BYTE hist[256])
{
   int threshold = 0, count = 0;
   for (int sim = MAX_NEST_ACCEL_SIM; sim >= 0; sim--)
   {
      count += hist[sim];
      if (count < numPassed)
         continue;
      return sim;
   }
   return 0;
}


#pragma pack(pop)
} //namespace accelMatch{

