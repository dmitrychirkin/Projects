/*
   minutiaePair.h - declare the MinutiaePair class that keep information 
                    about one pair of minutiae

   Copyright (C) 2007 Sonda Technologies Ltd.
   Author A.Mosunov
   21.04.2007
*/
#ifndef  COMPAR_MINUTIAE_PAIR_H_
#define  COMPAR_MINUTIAE_PAIR_H_

#include <assert.h>

#include "mathem100.h"
//#include "Unpack.h"
#include "Unwrap.h"


namespace accelMatch{
#pragma pack(push,_CORE_PACKING)


struct MinutiaePair 
{
   int      m_len;        // pair lenght
   int      m_angle;      // angle between pair and oX axis

public:
   MinutiaePair()
   {
      init();
   }
   void init()
   {
      m_len     = 0;
      m_angle   = 256;
   }
   MinutiaePair(const MinutiaePair &pair)
   {
      *this = pair;
   }
   MinutiaePair& operator =(const MinutiaePair &pair)
   {
      m_len     = pair.m_len;
      m_angle   = pair.m_angle;
      return *this;
   }
   void setLen (int len)
   {
      m_len = len;
   }
   void setLen (int min1X, int min1Y, int min2X, int min2Y)
   {
      int dx = min1X - min2X;
      int dy = min1Y - min2Y;
      m_len = dist(dx, dy);
   }
   void setAngle (int angle)
   {
      m_angle = angle;
   }
   void setAngle (int min1X, int min1Y, int min2X, int min2Y)
   {
      int dx = min1X - min2X;
      int dy = min1Y - min2Y;
      m_angle = normAngle(atan(dx, dy));
   }
};

class MinutiaePairSet
{
   MinutiaePair  m_pair[MAX_MINUTIAE][MAX_MINUTIAE];
   ESK::Sign    *m_minutiae;                                // corresponded minutiaes array
   ESK::Link    *m_link;                                // corresponded links array

public:
   MinutiaePairSet()
   {
      m_minutiae = NULL;
      m_link = NULL;
   }
   ~MinutiaePairSet(){}
   void setNests(ESK::Link *link, ESK::Sign *minutiae)
   {
      m_minutiae = minutiae;
      m_link = link;
   }
   void clear (int num)
   {
      for(int i = 0; i < num; i++)
         for(int j = 0; j < num; j++)
         {
            m_pair[i][j].init();
         }
   }
   void setLen(int n1, int n2, int len)
   {
      assert(m_minutiae && n1 != n2);
      MinutiaePair *pair = &m_pair[n1][n2];
      pair->setLen (len);
      m_pair[n2][n1].setLen (len);
   }

   void setLen(int n1, int n2)
   {
      assert(m_minutiae && n1 != n2);
      MinutiaePair *pair = &m_pair[n1][n2];
      pair->setLen ((int)m_minutiae[n1].Movx, (int)m_minutiae[n1].Movy, (int)m_minutiae[n2].Movx, (int)m_minutiae[n2].Movy);
      m_pair[n2][n1].setLen (pair->m_len);
   }
   void setAngle(int n1, int n2)
   {
      assert(m_minutiae && n1 != n2);
      MinutiaePair *pair = &m_pair[n1][n2];
      pair->setAngle ((int)m_minutiae[n1].Movx, (int)m_minutiae[n1].Movy, (int)m_minutiae[n2].Movx, (int)m_minutiae[n2].Movy);
      m_pair[n2][n1].setAngle (normAngle (180 + pair->m_angle));
   }
   void setAll (int num)
   {
      for (int i = 0; i < num; i++)
         for (int j = i + 1; j < num; j++)
         {
            setLen(i, j);
            setAngle(i, j);
         }
   }
   int getLen(int n1, int n2)  
   {
      assert (n1 != n2);
//      return getLenEx(n1, n2) ;
      return m_pair[n1][n2].m_len;
   }
   int getLenEx(int n1, int n2)  
   {
      return getLen(n1, n2);  
      //assert (n1 != n2);
      //MinutiaePair* pair = &m_pair[n1][n2];
      //if (!pair->m_len)
      //   setLen (n1, n2);
      //return pair->m_len;
   }
   int getAngle(int n1, int n2)  
   {
      assert (n1 != n2);
      return getAngleEx (n1, n2);
//      return m_pair[n1][n2].m_angle;
   }
   int getAngleEx(int n1, int n2)  
   {
      assert (n1 != n2);
      MinutiaePair* pair = &m_pair[n1][n2];
      if (pair->m_angle == 256)
         setAngle (n1, n2);
      return pair->m_angle;
   }
};

#pragma pack(pop)
} // namespace accelMatch{

#endif // COMPAR_MINUTIAE_PAIR_H_