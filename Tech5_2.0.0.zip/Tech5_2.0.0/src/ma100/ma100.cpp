/*****************************************************************************
	ma100.cpp - implementation of finger to finge matching algorithm (MA) of Core Matching SDK
	             using ma100 algorithm

*******************************************************************************/
#include <set>

#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "ma100.h"
#include "compare100.h"
#include "getFusedScore.h"

namespace accelMatch{
#pragma pack(push,_CORE_PACKING)


Ma100::Ma100()
{
	m_compare = NULL;
   m_init    = false;  
}

Ma100::~Ma100()
{
	if (m_compare)       delete m_compare;
}

int Ma100::init ()
{
   if (m_init) return MA_OK;
   int result = MA_OK;
   try
   {
      m_compare = new Compare100;
      if (!m_compare)
         return MA_LOW_MEMORY;

      if ((result = m_compare->init(NULL)) != MA_OK)
            return result;
   }
   catch (int &e)
   {
      return e;
   }
	m_init = true;

	return MA_OK;
}

int Ma100::initEx (int protect[MAX_PROTECT_LEN])
{
   if (m_init) return MA_OK;
   int result = MA_OK;
   try
   {
      m_compare = new Compare100;
      if (!m_compare)
         return MA_LOW_MEMORY;

      if ((result = m_compare->initEx(NULL, protect)) != MA_OK)
            return result;
   }
   catch (int &e)
   {
      return e;
   }
	m_init = true;
	
	return MA_OK;
}


int Ma100::allocateTemplate (BYTE *&templ)
{
	return Compare100::allocateTemplate (templ);
}


int Ma100::freeTemplate (BYTE *&templ)
{
	return Compare100::freeTemplate (templ);
}


int Ma100::match            ( SearchParam  &param, 
                             BYTE          *templP,
                             BYTE          *templG, 
                             int           &similarity,
                             FP_TYPE        typeP,
                             FP_TYPE        typeG,
                             MatchResult   *matchResult)
{
	// load first set of templates
	int result = loadTemplate( templP, typeP);
	if (result != MA_OK) 
      return result;
	// match it with the second set of templates
	return	matchEx (param, templG, similarity, typeG, matchResult);
}

int Ma100::loadTemplate (BYTE *templP, FP_TYPE typeP)
{
   if (!m_init || !m_compare) return MA_NOT_INITIALIZED;
	
   return m_compare->loadTemplate (templP, typeP);
}

int Ma100::matchEx          ( SearchParam        &param, 
                             BYTE               *templG,
                             int            &similarity,
                             FP_TYPE             typeG,
                             MatchResult    *matchResult)
{
   if (!m_init || !m_compare ) return MA_NOT_INITIALIZED;
 
   return m_compare->matchEx (param, templG, similarity, matchResult, typeG);
}


bool Ma100::checkSearchParam(SearchParam &param)
{
   if (param.highThreshold  >           MAX_SCORE) return false;
   if (param.lowThreshold   >            MAX_SCORE) return false;
   if (param.maxAngle       >                  180) return false;
   if (param.maxAngleThumbs >                  180) return false;
   if (param.maxMatch       >                   10) return false;
   if (param.minMatch       >                   10) return false;
   if (param.searchSpeed    >  HIGHEST_MATCH_SPEED) return false;

   return true;
}


#pragma pack(pop)
} // namespace accelMatch{
