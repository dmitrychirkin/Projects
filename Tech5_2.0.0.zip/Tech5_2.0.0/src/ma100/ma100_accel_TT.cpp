/*****************************************************************************
	ma100_TT.cpp - implementation of TP-TP matching algorithm (MA) of Core Matching SDK
                  using ma100 algorithm 
*******************************************************************************/
#include <set>

#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "ma100_accel_TT.h"
#include "compare100_TT.h"
#include "getFusedScore.h"

namespace accelMatch{
#pragma pack(push,_CORE_PACKING)


Ma100_accel_TT::Ma100_accel_TT()
{
	m_compare       = NULL;
   m_isProbeLoaded = false;
   m_init          = false;  
}

Ma100_accel_TT::~Ma100_accel_TT()
{
	if (m_compare)  delete m_compare;
}

int Ma100_accel_TT::init (void *accelHandle)
{
   if (m_init) return MA_OK;
   int result = MA_OK;
   try
   {
      m_compare = new Compare100_TT;
      if (!m_compare)
         return MA_LOW_MEMORY;

      if ((result = m_compare->init(accelHandle)) != MA_OK)
            return result;
      m_isProbeLoaded = false;
   }
   catch (int &e)
   {
      return e;
   }
   m_init = true;

	return MA_OK;
}

int Ma100_accel_TT::initEx (void *accelHandle, int protect[MAX_PROTECT_LEN])
{
   if (m_init) return MA_OK;
   int result = MA_OK;
   try
   {
      m_compare = new Compare100_TT;
      if (!m_compare)
         return MA_LOW_MEMORY;

      if ((result = m_compare->initEx(accelHandle, protect)) != MA_OK)
            return result;
      m_isProbeLoaded = false;
   }
   catch (int &e)
   {
      return e;
   }
	m_init = true;
	
	return MA_OK;
}


int Ma100_accel_TT::loadTT (TpTemplate &probe, FP_TYPE typeP, BYTE **areaP, int *areaWidth, int *areaHeight)
{
   if (!m_init || !m_compare)
      return MA_NOT_INITIALIZED;

   int result = m_compare->loadTT (probe, typeP, areaP, areaWidth, areaHeight);
	if (result != MA_OK) 
      return result;
   m_isProbeLoaded = true;
   return MA_OK;
}


int Ma100_accel_TT::matchEx ( SearchParam          &param, 
                              BYTE                *templG,
                              FP_TYPE              typeG,
                              int             &similarity,
                              FINGERS             fingerP,
                              MatchResult    *matchResult,
                              bool         useCombineData, 
                              BYTE                    *np,
                              BYTE                    *ng,
                              BYTE         accelGroupSize,
                              bool             quickAccelMatch)
{
   if (!m_init || !m_compare ) return MA_NOT_INITIALIZED;
 
   return m_compare->matchEx (param, templG, similarity, fingerP, matchResult,
                                    typeG, useCombineData, np, ng, accelGroupSize, quickAccelMatch);
}


#pragma pack(pop)
} // namespace accelMatch{
