/*****************************************************************************
	ma100_TT.cpp - implementation of TP-TP matching algorithm (MA) of Core Matching SDK
                  using ma100 algorithm 
*******************************************************************************/
#include <set>

#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "ma100_TT.h"
#include "compare100_TT.h"
#include "getFusedScore.h"

namespace accelMatch{
#pragma pack(push,_CORE_PACKING)


Ma100_TT::Ma100_TT()
{
	m_compare       = NULL;
   m_isProbeLoaded = false;
   m_init          = false;  
}

Ma100_TT::~Ma100_TT()
{
	if (m_compare)  delete m_compare;
}

int Ma100_TT::init ()
{
   if (m_init) return MA_OK;
   int result = MA_OK;
   try
   {
      m_compare = new Compare100_TT;
      if (!m_compare)
         return MA_LOW_MEMORY;

      if ((result = m_compare->init(NULL)) != MA_OK)
            return result;
      m_isProbeLoaded = false;
   }
   catch (int &e)
   {
      return e;
   }
   m_init = true;

	return MA_OK;
}

int Ma100_TT::initEx (int protect[MAX_PROTECT_LEN])
{
   if (m_init) return MA_OK;
   int result = MA_OK;
   try
   {
      m_compare = new Compare100_TT;
      if (!m_compare)
         return MA_LOW_MEMORY;

      if ((result = m_compare->initEx (NULL, protect)) != MA_OK)
            return result;
      m_isProbeLoaded = false;
   }
   catch (int &e)
   {
      return e;
   }
	m_init = true;
	return MA_OK;
}


int Ma100_TT::matchTT (SearchParam &param, TpTemplate &probe, TpTemplate &gallery, MatchResultTT &matchResultTT, FP_TYPE typeP, FP_TYPE typeG)
{
	// load probe
	int result = loadTT(probe, typeP);
	if (result != MA_OK) 
      return result;
	// match it with the second set of templates
	return matchTTex (param, gallery, matchResultTT, typeG);
}

int Ma100_TT::loadTT (TpTemplate &probe, FP_TYPE typeP)
{
   if (!m_init || !m_compare)
      return MA_NOT_INITIALIZED;

   int result = m_compare->loadTT (probe, typeP, NULL, 0, 0);
	if (result != MA_OK) 
      return result;
   m_isProbeLoaded = true;
   return MA_OK;
}

int Ma100_TT::matchTTex (SearchParam &param, TpTemplate &gallery, MatchResultTT &matchResultTT, FP_TYPE typeG)
{
   if (!m_init || !m_compare)
      return MA_NOT_INITIALIZED;
   if (!m_isProbeLoaded)
      return MA_NO_LOAD;

   return m_compare->matchTTEx (param, gallery, matchResultTT, typeG);
}

int Ma100_TT::identifyTT (SearchParam &param, TpTemplate &probe, TpTemplate *gallery, unsigned int sizeGallery, RL *rl, unsigned int sizeRl, FP_TYPE typeP, FP_TYPE typeG)
{
   memset(rl, 0, sizeof(RL) * sizeRl);
   RL_SET  rlSet;
   rlSet.clear();
    
   // load probe
   int result = loadTT (probe, typeP);
   if (result != MA_OK) 
      return result;

   MatchResultTT matchResultTT;
   for(unsigned int i = 0; i < sizeGallery; i++)
   {
      result = matchTTex (param, gallery[i], matchResultTT, typeG);
      if (result != MA_OK && result != MA_NO_FINGERS) 
         return result;
      if (matchResultTT.fusionScore)
         rlSet.insert (RLex(i, -1, matchResultTT.fusionScore));
   }
   RL_SET::iterator p = rlSet.begin();
   for(unsigned int i = 0; i < sizeRl && p != rlSet.end(); i++, p++)
   {
      rl[i].regNum  = p->regNum;
      rl[i].score   = p->score;
   }

   return result;
}


#pragma pack(pop)
} // namespace accelMatch{
