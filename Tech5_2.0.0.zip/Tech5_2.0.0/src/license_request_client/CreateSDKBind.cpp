// CreateSDKBind.cpp : Defines the entry point for the application.
//
#if defined(_WINDOWS)
#include <Windows.h>
#include <iphlpapi.h>
#include <rpc.h>
#include <mapi.h>

#include "Resource.h"

LPMAPISENDMAIL lpfnMAPISendMail = NULL;
#else
#endif // _WINDOWS 

#include <cstdlib>
#include <string.h>
#include <stdio.h>
#include <wchar.h>

#include "hardwarebind.h"
#include "coreSdk.h"

#ifdef GENERATE_CLIENT
TECH5_PRODUCTS m_product_for_request = TECH5_SDK_CLIENT;
#ifdef	TRIAL_VERSION
wchar_t filename[MAX_PATH] = {L"tech5_client_trial"};
#else
wchar_t filename[MAX_PATH] = {L"tech5_client"};
#endif // TRIAL_VERSION
char	activation_note[MAX_PATH] = {"Please, activate our copy of Tech5 Client Edition SDK "};
#endif //GENERATE_CLIENT
#ifdef GENERATE_AUTH_MATCHER
TECH5_PRODUCTS m_product_for_request = TECH5_SDK_AUTH_MATCHER;
#ifdef	TRIAL_VERSION
wchar_t filename[MAX_PATH] = {L"tech5_auth_matcher_trial"};
#else
wchar_t filename[MAX_PATH] = {L"tech5_auth_matcher"};
#endif // TRIAL_VERSION
char	activation_note[MAX_PATH] = {"Please, activate our copy of Tech5 Auth Matcher SDK "};
#endif //GENERATE_AUTH_MATCHER
#ifdef GENERATE_GALLERY_MATCHER
TECH5_PRODUCTS m_product_for_request = TECH5_SDK_GALLERY_MATCHER;
#ifdef	TRIAL_VERSION
wchar_t filename[MAX_PATH] = {L"tech5_gallery_matcher_trial"};
#else
wchar_t filename[MAX_PATH] = {L"tech5_gallery_matcher"};
#endif // TRIAL_VERSION
char	activation_note[MAX_PATH] = {"Please, activate our copy of Tech5 Gallery Matcher SDK"};
#endif // GENERATE_GALLERY_MATCHER


#ifdef _WINDOWS

bool sendMail(char* filename);

bool was_generated = false;
INT_PTR CALLBACK About(HWND,UINT,WPARAM,LPARAM);

HINSTANCE hInst = NULL;
LANGID language = 1033;

int APIENTRY wWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	language = GetSystemDefaultLangID();
	hInst = hInstance;
	INT_PTR ret = DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_ABOUTBOX),NULL,About,0);
	return 0;
}


bool sendMail(char* filename)
{
	bool manual = false;
	HINSTANCE hlibMAPI = LoadLibrary(L"mapi32.dll");
	lpfnMAPISendMail = (LPMAPISENDMAIL) GetProcAddress (hlibMAPI, "MAPISendMail");

	ULONG err;
	MapiFileDesc attachment = { 0,         // ulReserved, must be 0
		0,         // no flags; this is a data file
		(ULONG)-1, // position not specified
		filename,  // pathname
		NULL,      // original filename
		NULL};               // MapiFileTagExt unused

	MapiRecipDesc recipient;
	MapiRecipDesc originator;
	memset(&originator,0,sizeof(MapiRecipDesc));
	memset(&recipient,0,sizeof(MapiRecipDesc));
	recipient.lpszName = "Tech5";
	recipient.lpszAddress = "support@tech5-sa.com";
	recipient.ulRecipClass = MAPI_TO;

	// Create a message.

	MapiMessage note = {0,            // reserved, must be 0
		"activation code",         // no subject
		activation_note,         // no note text
		NULL,         // NULL = interpersonal message
		NULL,         // no date; MAPISendMail ignores it
		NULL,         // no conversation ID
		0L,           // no flags, MAPISendMail ignores it
		&originator,   // no originator, this is ignored too
		1,            // zero recipients
		&recipient,         // NULL recipient array
		1,            // one attachment
		&attachment}; // the attachment structure


	err = lpfnMAPISendMail(0L,          // use implicit session.
		0L,          // ulUIParam; 0 is always valid
		&note,       // the message being sent
		MAPI_LOGON_UI |MAPI_NEW_SESSION , // allow the user to edit the message
		0L);         // reserved; must be 0

	if(hlibMAPI)
		FreeLibrary(hlibMAPI);

	manual = false;
	switch(err)
	{
	case MAPI_E_AMBIGUOUS_RECIPIENT :
		{
			MessageBox(NULL,L"A recipient matched more than one of the recipient descriptor structures and MAPI_DIALOG was not set. No message was sent. ",0,MB_OK | MB_ICONERROR);
			break;
		}
	case MAPI_E_ATTACHMENT_NOT_FOUND :
		{
			MessageBox(NULL,L"The specified attachment was not found. No message was sent. ",0,MB_OK | MB_ICONERROR);
			break;
		}
	case MAPI_E_ATTACHMENT_OPEN_FAILURE :
		{
			MessageBox(NULL,L"The specified attachment could not be opened. No message was sent. ",0,MB_OK | MB_ICONERROR);
			break;
		}
	case MAPI_E_BAD_RECIPTYPE :
		{
			MessageBox(NULL,L"The type of a recipient was not MAPI_TO, MAPI_CC, or MAPI_BCC. No message was sent. ",0,MB_OK | MB_ICONERROR);
			break;
		}
	case MAPI_E_FAILURE :
		{
			MessageBox(NULL,L"One or more unspecified errors occurred. No message was sent. ",0,MB_OK | MB_ICONERROR);
			break;
		}
	case MAPI_E_INSUFFICIENT_MEMORY :
		{
			MessageBox(NULL,L"There was insufficient memory to proceed. No message was sent. ",0,MB_OK | MB_ICONERROR);
			break;
		}
	case MAPI_E_INVALID_RECIPS :
		{
			MessageBox(NULL,L"One or more recipients were invalid or did not resolve to any address. ",0,MB_OK | MB_ICONERROR);
			break;
		}
	case MAPI_E_LOGIN_FAILURE :
		{
			MessageBox(NULL,L"There was no default logon, and the user failed to log on successfully when the logon dialog box was displayed. No message was sent. ",0,MB_OK | MB_ICONERROR);
			break;
		}
	case MAPI_E_TEXT_TOO_LARGE :
		{
			MessageBox(NULL,L"The text in the message was too large. No message was sent. ",0,MB_OK | MB_ICONERROR);
			break;
		}
	case MAPI_E_TOO_MANY_FILES :
		{
			MessageBox(NULL,L"There were too many file attachments. No message was sent. ",0,MB_OK | MB_ICONERROR);
			break;
		}
	case MAPI_E_TOO_MANY_RECIPIENTS :
		{
			MessageBox(NULL,L"There were too many recipients. No message was sent. ",0,MB_OK | MB_ICONERROR);
			break;
		}
	case MAPI_E_UNKNOWN_RECIPIENT :
		{
			MessageBox(NULL,L"A recipient did not appear in the address list. No message was sent. ",0,MB_OK | MB_ICONERROR);
			break;
		}
	case MAPI_E_USER_ABORT :
		{
			MessageBox(NULL,L"The user canceled one of the dialog boxes. No message was sent. ",0,MB_OK | MB_ICONERROR);
			break;
		}
	case SUCCESS_SUCCESS :
		{
			//				MessageBox(NULL,"The call succeeded and the message was sent. ",0,MB_OK);
			manual = true;
			break;
		}
	default:
		{
			MessageBox(NULL,L"Unable to send the message",0,MB_OK | MB_ICONERROR);
			break;
		}
	}
	return manual;
}

INT_PTR CALLBACK About(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
		case WM_INITDIALOG:
			{
				EnableWindow(GetDlgItem(hDlg,IDC_GENERATE),FALSE);
				break;
			}
		case WM_COMMAND:
			{
				switch(LOWORD(wParam))
				{
					case IDOK:
					case IDCANCEL:
						{
							bool exit_now = false;
							if( !was_generated )
							{
								wchar_t string_text[MAX_PATH];
								LoadString(hInst,IDS_EXIT_WITHOUT_GENERATION,string_text,MAX_PATH);
								wchar_t string_caption[MAX_PATH];
								LoadString(hInst,IDS_CONFIRMATION,string_caption,MAX_PATH);
								exit_now = ( MessageBox(hDlg,string_text,string_caption,MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDYES ? true : false);
							}
							else
								exit_now = true;
							if(exit_now)
								EndDialog(hDlg,LOWORD(wParam));
							break;
						}
					case IDC_BROWSE:
						{

							OPENFILENAME ofn;
//							char m_buffer[MAX_PATH];
							wchar_t* filter = NULL;
							filter = new wchar_t[MAX_PATH];
							memset(filter,0,MAX_PATH*sizeof(wchar_t));
							wcscpy(filter,L"bind request");
							memcpy((byte*)(filter+wcslen(L"bind request")+1),(byte*) (L"*.srl"),wcslen(L"*.srl")*sizeof(wchar_t));
							memset(&ofn,0,sizeof(ofn));
							ofn.lStructSize = sizeof(ofn);
							ofn.lpstrFile = filename;
							ofn.nMaxFile = MAX_PATH;
							ofn.lpstrDefExt = L"srl";
							ofn.lpstrFilter = filter;
							ofn.Flags = OFN_CREATEPROMPT | OFN_EXPLORER | OFN_OVERWRITEPROMPT;

							if( GetSaveFileName(&ofn))
							{
								SetDlgItemText(hDlg,IDC_FILENAME,ofn.lpstrFile);
								EnableWindow(GetDlgItem(hDlg,IDC_GENERATE),TRUE);
							}
							break;
						}
					case IDC_GENERATE:
						{
							bool sehr_good = false;
							char filename[MAX_PATH];
							wchar_t m_filename[MAX_PATH];
							if( (0 == GetDlgItemTextA(hDlg,IDC_FILENAME,filename,MAX_PATH)) || (strlen(filename) < 4) )
							{
								wchar_t string_text[MAX_PATH];
								LoadString(hInst,IDS_SELECTION_ASK,string_text,MAX_PATH);
								MessageBox(hDlg,string_text,L"",MB_OK | MB_ICONINFORMATION);
//								MessageBox(hDlg,L"Select location and filename, please",L"",MB_OK | MB_ICONINFORMATION);
								break;
							}
							GetDlgItemText(hDlg,IDC_FILENAME,m_filename,MAX_PATH);
							Tech5_Hardware_Protect m_prot(m_product_for_request);
#ifdef	TRIAL_VERSION
							sehr_good = m_prot.create_request_file(m_filename,true);
#else
							sehr_good = m_prot.create_request_file(m_filename,false);
#endif	TRIAL_VERSION
							if( !sehr_good )
							{
//								wchar_t message_d[1024];
//								wsprintf(message_d,L"Activation request not created.\nLaunch CreateSDKBind.exe again.");
								wchar_t string_text[MAX_PATH];
								LoadString(hInst,IDS_GENERATE_FAILED,string_text,MAX_PATH);
								wchar_t string_caption[MAX_PATH];
								LoadString(hInst,IDS_ACTIVATION_CODE,string_caption,MAX_PATH);
								MessageBox(hDlg,string_text,string_caption,MB_OK);
								break;
							}
							else
								was_generated = true;
							if(was_generated)
								MessageBox(hDlg,L"OK!",L"Success!",MB_OK | MB_ICONINFORMATION);
							wchar_t string_text[MAX_PATH];
							LoadString(hInst,IDS_SEND_QUESTION,string_text,MAX_PATH);
							wchar_t string_caption[MAX_PATH];
							LoadString(hInst,IDS_CONFIRMATION,string_caption,MAX_PATH);
							bool manual = MessageBox(hDlg,string_text,string_caption,MB_YESNO | MB_DEFBUTTON1) == IDYES ? false : true;
							if(!manual)
							{
								if( sendMail(filename) )
									manual = false;
								else
									manual = true;
							}
							if(manual)
							{
								wchar_t string_text[MAX_PATH];
								LoadString(hInst,IDS_MANUAL_SEND,string_text,MAX_PATH);
								wchar_t message_d[1024];
								wsprintf(message_d,string_text,filename);
								wchar_t string_caption[MAX_PATH];
								LoadString(hInst,IDS_ACTIVATION_CODE,string_caption,MAX_PATH);

								MessageBox(hDlg,message_d,string_caption,MB_OK);
							}
							;
						}
					default:
						break;
				}
				break;
			}
		default:
			{
				break;
			}
	}
	return (INT_PTR)FALSE;
}
#else

int main(int argc, char** argv)
{
    bool success = false;
    wchar_t m_filename[MAX_PATH];
    wcscpy(m_filename,filename);
    wcscat(m_filename,L".srl");
    Tech5_Hardware_Protect m_prot(m_product_for_request);
#ifdef	TRIAL_VERSION
    success = m_prot.create_request_file(m_filename,true);
#else
    success = m_prot.create_request_file(m_filename,false);
#endif
    if( success )
	printf("Ok!\n");
    else
	printf("Failed\n");
    return 0;
}

#endif // _WINDOWS