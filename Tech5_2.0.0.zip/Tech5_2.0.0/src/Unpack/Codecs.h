#pragma		once
#ifndef		CODECS_H
#define		CODECS_H

//	Header project file
#include		"Eskdef.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
//-------------------------------------
// Codec main definitions
//-------------------------------------
#define UNPACK_N_BIT( _AND,_NUM,_Src,_Lin,_Bit,_Val )                                              \
   /* decode n bits */                                                                             \
   register _Ty                                                                                    \
      _Tmp =  _Val & _AND;                                                                         \
   const _Ty                                                                                       \
      _New = (_Bit + _NUM) & ((sizeof(_Ty) << 3) - 1);                                             \
                                                                                                   \
   if(_New >=  _NUM)                                                                               \
      _Val >>= _NUM;                                                                               \
   else                                                                                            \
      {                                                                                            \
      _Val = _Src[++_Lin]; _Tmp += (_Val & ~(_Ty(-1) << _New)) << (_NUM -_New); _Val >>= _New;     \
      }                                                                                            \
   _Bit = _New;

#define ENPACK_N_BIT( _AND,_NUM,_Dst,_Lin,_Bit,_Val )                                              \
   /* encode n bits */                                                                             \
   const _Ty                                                                                       \
      _Tmp =  _Val & _AND,                                                                         \
      _New = (_Bit + _NUM) & ((sizeof(_Ty) << 3) - 1);                                             \
                                                                                                   \
   /* body pack */                                                                                 \
   _Dst[_Lin] |= _Tmp << _Bit;                                                                     \
                                                                                                   \
   if (_New < _NUM)                                                                                \
      {/* tail pack */                                                                             \
      _Dst[++_Lin] = _Tmp >> (_NUM - _New);                                                        \
      }                                                                                            \
   _Bit = _New;

//-------------------------------------
// Tool kit to decode bits of template
//-------------------------------------
template<class _Ty> inline _Ty
   unpack_1_bit( _Ty const*const _Src,_Ty &_Lin,_Ty &_Bit,_Ty &_Val )
	   {//unpack 1 bit
      UNPACK_N_BIT( 1,1,_Src,_Lin,_Bit,_Val ); return _Tmp;
	   }

template<class _Ty> inline _Ty
   unpack_2_bit( _Ty const*const _Src,_Ty &_Lin,_Ty &_Bit,_Ty &_Val )
	   {//unpack 2 bits
      UNPACK_N_BIT( 3,2,_Src,_Lin,_Bit,_Val ); return _Tmp;
	   }

template<class _Ty> inline _Ty
   unpack_3_bit( _Ty const*const _Src,_Ty &_Lin,_Ty &_Bit,_Ty &_Val )
	   {//unpack 3 bits
      UNPACK_N_BIT( 7,3,_Src,_Lin,_Bit,_Val ); return _Tmp;
	   }

template<class _Ty> inline _Ty
   unpack_4_bit( _Ty const*const _Src,_Ty &_Lin,_Ty &_Bit,_Ty &_Val )
	   {//unpack 4 bits
      UNPACK_N_BIT( 15,4,_Src,_Lin,_Bit,_Val ); return _Tmp;
	   }

template<class _Ty> inline _Ty
   unpack_5_bit( _Ty const*const _Src,_Ty &_Lin,_Ty &_Bit,_Ty &_Val )
	   {//unpack 4 bits
      UNPACK_N_BIT( 31,5,_Src,_Lin,_Bit,_Val ); return _Tmp;
	   }

template<class _Ty> inline _Ty
   unpack_x_bit( _Ty const*const _Src,_Ty &_Lin,_Ty &_Bit,_Ty &_Val,const _Ty _Num )
	   {//unpack any quantity of bits
      UNPACK_N_BIT( ~(_Ty(-1) << _Num),_Num,_Src,_Lin,_Bit,_Val ); return _Tmp;
	   }

//-------------------------------------
// Tool kit to encode bits of template
//-------------------------------------
template<class _Ty,class _Tp> inline void_t
   repack_1_bit( _Ty *const _Dst,_Ty &_Lin,_Ty &_Bit,const _Tp &_Val )
	   {//pack 1 bit to _Dst
      ENPACK_N_BIT( 1,1,_Dst,_Lin,_Bit,_Val );
	   }

template<class _Ty,class _Tp> inline void_t
   repack_2_bit( _Ty *const _Dst,_Ty &_Lin,_Ty &_Bit,const _Tp &_Val )
	   {//pack 2 bits to _Dst
      ENPACK_N_BIT( 3,2,_Dst,_Lin,_Bit,_Val );
	   }

template<class _Ty,class _Tp> inline void_t
   repack_3_bit( _Ty *const _Dst,_Ty &_Lin,_Ty &_Bit,const _Tp &_Val )
	   {//pack 3 bits to _Dst
      ENPACK_N_BIT( 7,3,_Dst,_Lin,_Bit,_Val );
	   }

template<class _Ty,class _Tp> inline void_t
   repack_4_bit( _Ty *const _Dst,_Ty &_Lin,_Ty &_Bit,const _Tp &_Val )
	   {//pack 4 bits to _Dst
      ENPACK_N_BIT( 15,4,_Dst,_Lin,_Bit,_Val );
	   }

template<class _Ty,class _Tp> inline void_t
   repack_5_bit( _Ty *const _Dst,_Ty &_Lin,_Ty &_Bit,const _Tp &_Val )
	   {//pack 5 bits to _Dst
      ENPACK_N_BIT( 31,5,_Dst,_Lin,_Bit,_Val );
	   }

template<class _Ty,class _Tp> inline void_t
   repack_x_bit( _Ty *const _Dst,_Ty &_Lin,_Ty &_Bit,const _Tp &_Val,const _Ty &_Num )
	   {//pack any quantity of bits
      ENPACK_N_BIT( ~(_Ty(-1) << _Num),_Num,_Dst,_Lin,_Bit,_Val );
	   }

//-------------------------------------
// Advanced tool kit
//-------------------------------------
template<class _Ty> inline _Ty 
   local_type_size( const _Ty &_Lin,const _Ty &_Bit ) _NOTHROW
	   {//calculate unpacked bytes (reconstructed)
      _Ty 
         _Add = _Bit >> 3; return _Lin*sizeof(_Ty) + (_Add > 0 ? _Add + 1 : _Bit > 0);
	   }

template<class _Ty> inline bool_t
   local_type_test( const _Ty &_Lin,const _Ty &_Bit,const _Ty &_Len ) _NOTHROW
	   {//test old and new formats
      _Ty 
         _Res = local_type_size( _Lin,_Bit ); return _Res == _Len || _Res == _Len + 1;
	   }

template<class _Ty> inline _Ty
   quants( const _Ty &_Val )
	   {//detect necessary bits for value representation
	   register _Ty i = 0; for (;_Ty(1 << i) <= _Val; i++); return (i);
	   }

template<class _Ty> inline _Ty
   vquant( const _Ty &_Qnt )
	   {//detect maximum value for _Qnt bits
	   return ((1 << _Qnt) - 1);
	   }

/**************************************
				Struct Codecs
**************************************/
template<class _Ty>
struct Codecs
	{//encode and decode class
   typedef _Ty* pointer;

	Codecs() : Line(0),Bits(0),Data(0),Pack(0)
		{//default constructor
		}

   template<class _Other> explicit 
   Codecs( const _Other *_Pnt ) : Line(0),Bits(0)
		{//assign constructor
      Pack =  pointer(_Pnt);
      Data = *pointer(_Pnt);
		}

	_Ty 
      get_1_bit()
		   {//unpack 1 bit with internal state
		   return unpack_1_bit( Pack,Line,Bits,Data );
		   }

	_Ty
      get_2_bit()
		   {//unpack 2 bits with internal state
		   return unpack_2_bit( Pack,Line,Bits,Data );
		   }

	_Ty
      get_3_bit()
		   {//unpack 3 bits with internal state
		   return unpack_3_bit( Pack,Line,Bits,Data );
		   }

	_Ty
      get_4_bit()
		   {//unpack 4 bits with internal state
		   return unpack_4_bit( Pack,Line,Bits,Data );
		   }

	_Ty
      get_5_bit()
		   {//unpack 5 bits with internal state
		   return unpack_5_bit( Pack,Line,Bits,Data );
		   }

	_Ty
      get_x_bit( _Ty _Num )
		   {//unpack x bits with internal state
		   return unpack_x_bit( Pack,Line,Bits,Data,_Num );
		   }

	_Ty
      debits( _Ty _Num )
		   {//unpack x bits with internal state
         return get_x_bit( _Num );
		   }

	void_t
      set_1_bit()
		   {//pack 1 bit with internal state
		   return repack_1_bit( Pack,Line,Bits,Data );
		   }

	void_t
      set_2_bit()
		   {//pack 2 bits with internal state
		   return repack_2_bit( Pack,Line,Bits,Data );
		   }

	void_t
      set_3_bit()
		   {//pack 3 bits with internal state
		   return repack_3_bit( Pack,Line,Bits,Data );
		   }

	void_t
      set_4_bit()
		   {//pack 4 bits with internal state
		   return repack_4_bit( Pack,Line,Bits,Data );
		   }

	void_t
      set_5_bit()
		   {//pack 5 bits with internal state
		   return repack_5_bit( Pack,Line,Bits,Data );
		   }

	void_t
      set_x_bit( _Ty _Num )
		   {//pack x bits with internal state
		   return repack_x_bit( Pack,Line,Bits,Data,_Num );
		   }

	void_t
      enbits( _Ty _Num )
		   {//pack x bits with internal state
         set_x_bit( _Num );
		   }

	_Ty
      type_count()
		   {//detect unpacked bytes in types
		   return local_type_count( Line,Bits );
		   }

private:
	pointer
		Pack; //pointer to buffer of packed data
	_Ty
		Line, //item counter
		Bits,	//bit counter
		Data;

	};//Codecs

typedef Codecs<uint_t>  code_t;

_ESK_END
#pragma pack(pop)
#endif//CODECS_H
