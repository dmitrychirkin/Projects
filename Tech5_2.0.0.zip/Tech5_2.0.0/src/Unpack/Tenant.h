#pragma		once
#ifndef		TENANT_H
#define		TENANT_H

//	Header project file
#include		"Access.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
/**************************************
			Class Uwrap_keep
**************************************/
class	Unwrap_keep : public Unwrap
	{//various size array of nests
public:
	//----------------------------------
	//	Constructors and destructor
	//----------------------------------
	Unwrap_keep() : Degree(false)
		{//constructor
		};

	~Unwrap_keep()
		{//destructor					
		}

	//----------------------------------
	// Control functions
	//----------------------------------
	bool_t 
      test() _NOTHROW
		   {//test if pyramid exist
		   return (Versor == _ESK_ID);
		   }

	void_t
      versor( uint_t _Ver ) _NOTHROW
		   {//day month year
         Versor = _Ver;
		   }

	void_t 
      factor( bool_t _Flg ) _NOTHROW
		   {//false - 360 degree
         Degree = _Flg;
		   }

	bool_t 
      verify( const byte_t *_Tpl ) _NOTHROW
		   {//partial inspection
		   return verify_model_size( Decode.power_quantity( _Tpl )) &&
                verify_model_sign( Decode.access_version( _Tpl )) &&
                verify_image_qual( Decode.sample_quality( _Tpl )) &&
                verify_image_freq( Decode.sample_density( _Tpl )) &&
                verify_image_type( Decode.sample_type_of( _Tpl )) &&
                verify_image_link( Decode.links_capacity( _Tpl )) &&
                verify_image_size( Decode.image_length_x( _Tpl ),
                                   Decode.image_length_y( _Tpl ));
		   }

	bool_t 
      defend( const byte_t *_Tpl ) _NOTHROW
		   {//first signature
	      return test() ? Decode.defend( _Tpl ) : 0;
		   }

	bool_t 
      hasher( const byte_t *_Tpl ) _NOTHROW
		   {//next signature
	      return test() ? Decode.hasher( _Tpl ) : 0;
		   }

	//----------------------------------
	//	Isolated parameters
	//----------------------------------
	uint_t 
      length( const byte_t *_Tpl) _NOTHROW
		   {//get length of template
         return Decode.power_quantity( _Tpl );
		   }

	byte_t 
      versor( const byte_t *_Tpl) _NOTHROW
		   {//get quality of image
         return Decode.access_version( _Tpl );
		   }

	byte_t 
      qualit( const byte_t *_Tpl) _NOTHROW
		   {//get quality of image
         return Decode.sample_quality( _Tpl );
		   }

	byte_t 
      densit( const byte_t *_Tpl) _NOTHROW
		   {//get density of image
		   return Decode.sample_density( _Tpl );
		   }

	byte_t 
      passxy( const byte_t *_Tpl) _NOTHROW
		   {//get xy pass
		   return Decode.sample_pass_xy( _Tpl );
		   }

	byte_t
      passan( const byte_t *_Tpl) _NOTHROW
		   {//get alpha pass
		   return Decode.sample_pass_an( _Tpl );
		   }

	byte_t
      square( const byte_t *_Tpl) _NOTHROW
		   {//get density of image
		   return Decode.sample_squares( _Tpl );
		   }

	byte_t 
      immask( const byte_t *_Tpl) _NOTHROW
		   {//get image mask
		   return Decode.image_smp_mask( _Tpl );
		   }

	twin_t 
      exmask( const byte_t *_Tpl) _NOTHROW
		   {//get extended image mask
		   return Decode.image_ext_mask( _Tpl );
		   }

	twin_t 
      size_x( const byte_t *_Tpl) _NOTHROW
		   {//get x size of pattern
		   return Decode.image_length_x( _Tpl );
		   }

	twin_t
      size_y( const byte_t *_Tpl) _NOTHROW
		   {//get y size of pattern
		   return Decode.image_length_y( _Tpl );
		   }

	twin_t
      imgppi( const byte_t *_Tpl) _NOTHROW
		   {//get image processing PPI
		   return Decode.processing_ppi( _Tpl );
		   }

	twin_t
      tplppi( const byte_t *_Tpl) _NOTHROW
		   {//get template PPI
		   return Decode.template_scope( _Tpl );
		   }

	byte_t
      finger( const byte_t *_Tpl) _NOTHROW
		   {//get number of finger
		   return Decode.finger_number_( _Tpl );
		   }

	//----------------------------------
	//	Isolated deblocking
	//----------------------------------
	twin_t 
      demain( Sign *const _Dst,const byte_t *_Tpl ) _NOTHROW
		   {//unpack singularities
		   return test() ? Decode.demain( _Dst,_Tpl,Degree ) : 0;
		   }

	twin_t 
      denova( Sign *const _Dst,const byte_t *_Tpl ) _NOTHROW
		   {//unpack minutiae
		   return test() ? Decode.denova( _Dst,_Tpl,Degree ) : 0;
		   }

	twin_t 
      denest( const link_p &_Dst,const sign_p &_Src,twin_t _Num,const byte_t *_Tpl ) _NOTHROW
		   {//unpack nest of minutiae
         return test() ? Decode.denest( _Dst,_Src,_Num,_Tpl ) : 0;
		   }

	twin_t 
      deabac( byte_t *const _Dst,const byte_t *_Tpl) _NOTHROW
		   {//unpack ridge count
		   return test() ? Decode.deabac( _Dst,_Tpl ) : 0;
		   }

	uint_t
      dearea( byte_t *const _Dst,const byte_t *_Tpl ) _NOTHROW
		   {//unpack list of area
         return test() ? Decode.dearea( _Dst,_Tpl ) : 0;
		   }

	//----------------------------------
	//	Read number of objects
	//----------------------------------
	twin_t
      idmain( const byte_t *_Tpl ) _NOTHROW
		   {//number of singularities
		   return Decode.idmain( _Tpl );
		   }

	twin_t 
      idnova( const byte_t *_Tpl ) _NOTHROW
		   {//number of minutiae
		   return Decode.idnova( _Tpl );
		   }

	uint_t
      idarea( const byte_t *_Tpl ) _NOTHROW
		   {//size of area
		   return Decode.idarea( _Tpl );
		   }

	//----------------------------------
	//	Functions for partial inspection
	//----------------------------------
private:
	bool_t 
      verify_image_type( byte_t _Ity ) const _NOTHROW
		   {//verify type of image
		   return _Ity == 'L'   ||
				    _Ity == 'F'   ||
				    _Ity == 'P'   ||
				    _Ity == 'T';
		   }

	bool_t 
      verify_image_qual( byte_t _Qlt ) const _NOTHROW
		   {//test if harmon in range
		   return _Qlt <= 0x64;
		   }

	bool_t 
      verify_image_link( byte_t _Net ) const  _NOTHROW
		   {//verify deep of section
		   return _Net <= MAXR  && 
                _Net;
		   }
	
	bool_t 
      verify_image_freq( byte_t _Frq ) const _NOTHROW
		   {//test if harmon in range
		   return _Frq <= HH*HP && 
                _Frq;
		   }

	bool_t 
      verify_model_size( uint_t _Len ) const  _NOTHROW
		   {//verify deep of section
		   return _Len < TPLLEN && 
                _Len;
		   }

	bool_t 
      verify_model_sign( byte_t _Ver ) const  _NOTHROW
		   {//verify deep of section
         return _Ver & WIZARD || 
                _Ver & ISSUER;
		   }

	bool_t 
      verify_image_size( twin_t _Xsz,twin_t _Ysz ) const _NOTHROW
		   {//test if harmon value in range
         return _Xsz < MAXLEN &&
                _Ysz < MAXLEN;
		   }

private:
   deco_t //deblocking object
      Decode;
   bool_t //true - 256,false - 360 degree
      Degree;
	uint_t  //version of library
      Versor;

	};//Unpack_keep

_ESK_END
#pragma pack(pop)
#endif//TENANT_H

