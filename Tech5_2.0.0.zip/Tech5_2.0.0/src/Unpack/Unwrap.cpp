//	Header project file
#include		"Armour.h"
#include		"Anonim.h"
#include		"Memove.h"
#include		"Tenant.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
//-------------------------------------
//	Casing for decode template
//-------------------------------------
Unwrap* 
   Unwrap::create()
	   {//create object
      Unwrap *
         _Obj = Null;

	   try
		   {
         if(invalid_key()) 
            throw fail(1);

                _Obj = new Unwrap_keep; _Obj = _Obj + ~invalid_key() + 1;
         return _Obj;
		   }
	   catch(...)
		   {//test if have no memory
         delete _Obj; return Null;
		   }
	   }

void_t 
   Unwrap::cancel( Unwrap::Self_t* &_Obj )
	   {//delete caesar object
	   if (_Obj)
		   {
		   delete _Obj; 
			       _Obj = Null;
		   }
	   }

_ESK_END
#pragma pack(pop)
