#pragma		once
#ifndef		ACCESS_H
#define		ACCESS_H

//	Header project file
#include		"Unwrap.h"
#include		"Eskuse.h"
#include		"Codecs.h"
#include		"Memove.h"
#include		"Trigon.h"
#include		"Utiles.h"
#include		"Fnctnl.h"
#include		"Virtue.h"

#pragma pack(push,_ESK_PACKING)
#pragma pack(push,_ESK_TIGHTEN)
_ESK_BEGIN
//-------------------------------------
// Global forward references
//-------------------------------------
template<class _Ty>
class   Access_access;
typedef Access_access<byte_t>    acss_t;
template<class _Ty>
class   Access_decode;
typedef Access_decode<byte_t>    deco_t;
template<class _Ty>
class   Access_encode;
typedef Access_encode<byte_t>    enco_t;

//-------------------------------------
// Local forward references
//-------------------------------------
struct  Wood;
typedef Wood   wood_t, *wood_p;
struct  Homo;
typedef Homo   homo_t, *homo_p;
struct  Hash;
typedef Hash   hash_t, *hash_p;

//-------------------------------------
// Matcher special definitions
//-------------------------------------
struct _LNX_TIGHTEN Wood
	{//accelerator
	Wood() : Mask(),Clou()
		{//default constructor
		}

   uint_t
      Mask,
		Clou;
   };

struct _LNX_TIGHTEN Homo
	{//complex nest
   Homo() : Type()
		{//construct default
		}

	wood_t   //soft accelerators
      Comb[SISE];
	byte_t   //type of minutiae
      Type;
	};

struct _LNX_TIGHTEN Hash
	{//accelerators
   Hash()
		{//construct default
      }

   byte_t   //classificator, radius, direction, vector difference
      Clas,
      Size,
      Beta,
      Teta;

	twin_t   //minutiae
		Item;
   };

//-------------------------------------
// Template header definitions
//-------------------------------------
struct _LNX_TIGHTEN Item_header
	{//dactilogram header
   Item_header() : VeSign(WIZARD),Passxy(),Passan(),ImgPPI(STDPPI),TplPPI(STDPPI)
      {//constructor
	   Length = 0;
		Number = 0;
	   Qualit = 0;
		Densit = 0;
		ImMask = 0;
		ImType = 0;
		Square = 0;
		TipNet = 0;
	   PFocus = 0;
	   PPoint = 0;
		PTotal = 0;
		PRidge = 0;
		PAreas = 0;
	   PLinks = 0;
	   Size_X = 0;
		Size_Y = 0;
      }

	uint_t   
      Length;							//length
	byte_t   
      VeSign,							//version
	   Number;							//image number
	twin_t   
      ImgPPI,							//processing PPI
		TplPPI;							//template PPI
	byte_t
      Qualit,							//quality
		Densit,							//image density
		ImMask,							//type of pattern
		ImType,							//L, F, P, T
		Square,							//image area
		Passxy,							//xy pass
		Passan,							//alpha pass
		TipNet;							//deep section
	byte_t   
      PFocus;							//singularities length
	twin_t
      PPoint,							//minutiae length
		PTotal,							//total length
		PRidge,							//ridge count length
		PAreas;							//areas length
	uint_t
      PLinks;							//linkages length
	twin_t
      Size_X,							//image x size
		Size_Y;							//image y size

	};//Item_header

struct _LNX_TIGHTEN Code_header
	{//renovate dactilogram header
   Code_header() : VeSign(ISSUER),Passxy(),Passan(),ImgPPI(DEFPPI),TplPPI(TPLPPI)
      {//constructor
	   Length = 0;
		Number = 0;
	   Qualit = 0;
		Densit = 0;
		ImMask = 0;
		ImType = 0;
		Square = 0;
		TipNet = 0;
      //power
	   PFocus = 0;
	   PPoint = 0;
		PTotal = 0;
		PRidge = 0;
		PAreas = 0;
	   PLinks = 0;
      PClass = 0;
      PGloss = 0;
      //parameter
	   Size_X = 0;
		Size_Y = 0;
      ExMask = 0;
      }

	uint_t   
      Length;							//length
	byte_t   
      VeSign,							//version
		Number;							//image number
	twin_t 
      ImgPPI,							//processing PPI
		TplPPI;							//template PPI
	byte_t
      Qualit,							//quality
		Densit,							//image density
		ImMask,							//type of pattern
		ImType,							//L, F, P, T
		Square,							//image area
		Passxy,							//xy pass
		Passan,							//alpha pass
		TipNet;							//deep section
	byte_t
      PFocus;							//singularities length
	twin_t
      PPoint,							//minutiae length
		PTotal,							//total length
		PRidge,							//ridge count length
		PAreas;							//areas length
	uint_t
      PLinks;							//linkages length
   twin_t
		PClass,							//classificators length
      PGloss;							//indexes length
	twin_t
      Size_X,							//image x size
		Size_Y;							//image y size
   twin_t
      ExMask;							//extended type of pattern

	};//Code_header

struct _LNX_TIGHTEN Dislocation
	{//dislocation of fields
   Dislocation()
      {//constructor
	   DFocus = 0;
		DPoint = 0;
		DTotal = 0;
		DRidge = 0;
		DAreas = 0;
		DLinks = 0;
		DClass = 0;
		DGloss = 0;
      }

	uint_t
      DFocus,							//singularity
		DPoint,							//minutiae
		DTotal,							//total ridge count
		DRidge,							//ridge count
		DAreas,							//areas
		DLinks,							//linkages
		DClass,							//meshes
		DGloss;							//indexes

	};//Dislocation

struct _LNX_TIGHTEN Dipole
	{//accelerator
   Dipole() : Item(),Size(),Azim(),Teta(),Clop(),Rang()
      {//default constructor
      }

   byte_t   //azimuth, radius, direction. vector difference, contrariwise
      Azim,
      Size,
      Beta,
      Teta,
      Clop,
      Rang;
	twin_t   //minutiae number
      Item;

   };//Dipole

#pragma pack(pop)
//-------------------------------------
// Accelerator's operators
//-------------------------------------
inline bool_t
   operator<( const Dipole &_Left,const Dipole &_Right )
	   {//functor
      if (_Left.Size == _Right.Size)
         return (_Left.Azim > _Right.Azim);
      else
         return (_Left.Size < _Right.Size);
	   }

inline bool_t
   operator>( const Dipole &_Left,const Dipole &_Right )
	   {//functor
      if (_Left.Azim == _Right.Azim)
         return (_Left.Size < _Right.Size);
      else
         return (_Left.Azim > _Right.Azim);
	   }

inline bool_t
   operator<( const hash_t &_Left,const hash_t &_Right )
	   {//functor
      if (_Left.Clas == _Right.Clas)
         return (_Left.Size < _Right.Size);
      else
         return (_Left.Clas < _Right.Clas);
	   }

//-------------------------------------
// Signature collector
//-------------------------------------
#define _ACCESS_DEFEND( _Stp,_RHS )                                                                \
   register uint_t                                                                                 \
        _Len =  Base::power_quantity( _Tpl ) - _Stp,                                               \
        _Idx = _Len,                                                                               \
        _Val =  0x0;                                                                               \
   for(;_Idx--;)                                                                                   \
        _Val += _Tpl[_Idx] _RHS;

/**************************************
 Topological accelerator for mutation
**************************************/
template<iint_t SIZE>
class _LNX_PACKING Accelerator
	{//generate accelerator for any kind of mutation
public:
	void_t 
      operator()( homo_p _Dst,const link_p &_Net,const sign_p &_Src ) const _NOTHROW
		   {//accelerators with masks provided "as is" without express or implied warranty
		   register quad_t
            _Msk = 0,
				_Dat = 0;

			   mutant_not( _Dst,
                        _Net,_Msk,_Dat,_Net->Cage );
         bool_t
            _Bool = (_Dst->Type = _Src->Type) == ME;
         if(_Bool)
			   {//four mutations for ending
			   mutant_ecl( _Dst,_Msk,_Dat );
			   mutant_ecr( _Dst,_Msk,_Dat );
            /*
			   mutant_esl( _Dst,_Msk,_Dat );
			   mutant_esr( _Dst,_Msk,_Dat );
            */
			   }
		   else
			   {//four mutations for bifurcation
			   mutant_bbl( _Dst,_Msk,_Dat );
			   mutant_bbr( _Dst,_Msk,_Dat );
            /*
			   mutant_bcl( _Dst,_Msk,_Dat );
			   mutant_bcr( _Dst,_Msk,_Dat );
            */
			   }
		   }

private:
	void_t 
      mutant_not( homo_p _Dst,const link_p &_Net,quad_t &_Msk,quad_t &_Dat,uint_t _End ) const _NOTHROW
		   {//set accelerator without mutation
		   register quad_t
             _Bit = 1;
		   for(uint_t i = 0; i < _End; i++,_Bit <<= 1)
			   {//generate accelerator
            const bond_t &
               _Sref = _Net->Knot[i];

			   if (uint_t _Top = _Sref.Deal)
				   {//detect topology
					   _Msk |= _Bit;
				   if(Clop[_Top])
					   _Dat |= _Bit;
				   }
			   }
         wood_t &
            _Dref = _Dst->Comb[0];

		   _Dref.Mask = uint_t(_Msk); //mask
		   _Dref.Clou = uint_t(_Dat); //data
		   }

	template<class _Ty> void_t
      mutant_ecl( _Ty *_Dst,const quad_t &_Msk,const quad_t &_Dat ) const _NOTHROW
		   {//ending close to left
         wood_t &
            _Dref = _Dst->Comb[1];

         _Dref.Mask = uint_t(((_Msk << 2) & 0x99999980) | ((_Msk >> 2) & 0x66666667) | ((_Msk << 3) & 0x18));
         _Dref.Clou = uint_t(((_Dat << 2) & 0x99999980) | ((_Dat >> 2) & 0x66666667) | ((_Dat << 3) & 0x18));
		   }

	template<class _Ty> void_t
      mutant_ecr( _Ty *_Dst,const quad_t &_Msk,const quad_t &_Dat ) const _NOTHROW
		   {//ending close to right
         wood_t &
            _Dref = _Dst->Comb[2];

		   _Dref.Mask = uint_t(((_Msk << 2) & 0x66666664) | ((_Msk >> 2) & 0x99999998) | ((_Msk >> 1) & 0x3));
         _Dref.Clou = uint_t(((_Dat << 2) & 0x66666664) | ((_Dat >> 2) & 0x99999998) | ((_Dat >> 1) & 0x3));
		   }

	template<class _Ty> void_t
      mutant_esl( _Ty *_Dst,const quad_t &_Msk,const quad_t &_Dat ) const _NOTHROW
		   {//ending switch to left
         wood_t &
            _Dref = _Dst->Comb[3];

		   _Dref.Mask = uint_t(((_Msk << 4) & 0x99999990) | ((_Msk >> 4) & 0x66666666) | ((_Msk << 1) & 0x8) | ((_Msk >> 1) & 0x1));
		   _Dref.Clou = uint_t(((_Dat << 4) & 0x99999990) | ((_Dat >> 4) & 0x66666666) | ((_Dat << 1) & 0x8) | ((_Dat >> 1) & 0x1));
		   }

	template<class _Ty> void_t
      mutant_esr( _Ty *_Dst,const quad_t &_Msk,const quad_t &_Dat ) const _NOTHROW
		   {//ending switch to right
         wood_t &
            _Dref = _Dst->Comb[4];

		   _Dref.Mask = uint_t(((_Msk << 4) & 0x66666660) | ((_Msk >> 4) & 0x99999999) | ((_Msk << 1) & 0x2) | ((_Msk >> 1) & 0x4));
		   _Dref.Clou = uint_t(((_Dat << 4) & 0x66666660) | ((_Dat >> 4) & 0x99999999) | ((_Dat << 1) & 0x2) | ((_Dat >> 1) & 0x4));
		   }

	template<class _Ty> void_t
      mutant_bbl( _Ty *_Dst,const quad_t &_Msk,const quad_t &_Dat ) const _NOTHROW
		   {//bifurcation break to left
         wood_t &
            _Dref = _Dst->Comb[1];

         _Dref.Mask = uint_t(((_Msk << 2) & 0x66666660) | ((_Msk >> 2) & 0x99999999) | ((_Msk << 1) & 0x6));
         _Dref.Clou = uint_t(((_Dat << 2) & 0x66666660) | ((_Dat >> 2) & 0x99999999) | ((_Dat << 1) & 0x6));
		   }

	template<class _Ty> void_t
      mutant_bbr( _Ty *_Dst,const quad_t &_Msk,const quad_t &_Dat ) const _NOTHROW
		   {//bifurcation break to right
         wood_t &
            _Dref = _Dst->Comb[2];

         _Dref.Mask = uint_t(((_Msk << 2) & 0x9999999c) | ((_Msk >> 2) & 0x66666660) | ((_Msk >> 3) & 0x3));
         _Dref.Clou = uint_t(((_Dat << 2) & 0x9999999c) | ((_Dat >> 2) & 0x66666660) | ((_Dat >> 3) & 0x3));
		   }

	template<class _Ty> void_t
      mutant_bcl( _Ty *_Dst,const quad_t &_Msk,const quad_t &_Dat ) const _NOTHROW
		   {//bifurcation close to left
         wood_t &
            _Dref = _Dst->Comb[3];

		   _Dref.Mask = uint_t(((_Msk << 4) & 0x66666600) | ((_Msk >> 4) & 0x99999999) | ((_Msk << 5) & 0x60) | ((_Msk >> 1) & 0x6));
		   _Dref.Clou = uint_t(((_Dat << 4) & 0x66666600) | ((_Dat >> 4) & 0x99999999) | ((_Dat << 5) & 0x60) | ((_Dat >> 1) & 0x6));
		   }

	template<class _Ty> void_t
      mutant_bcr( _Ty *_Dst,const quad_t &_Msk,const quad_t &_Dat ) const _NOTHROW
		   {//bifurcation close to right
         wood_t &
            _Dref = _Dst->Comb[4];

		   _Dref.Mask = uint_t(((_Msk << 4) & 0x99999990) | ((_Msk >> 4) & 0x66666660) | ((_Msk << 1) & 0xc) | ((_Msk >> 5) & 0x3));
		   _Dref.Clou = uint_t(((_Dat << 4) & 0x99999990) | ((_Dat >> 4) & 0x66666660) | ((_Dat << 1) & 0xc) | ((_Dat >> 5) & 0x3));
		   }

   };//Accelerator

/**************************************
		Template class Access_access
**************************************/
template<class _Ty>
struct _LNX_PACKING Access_base
	{//base class for accessing
   typedef _Ty item_t;
	};

template<class _Ty>
class Access_access : public Access_base<_Ty>
	{//common quick access
	typedef Access_base<_Ty> Self_t;
	typedef typename Self_t::item_t item_t;

   //----------------------------------
	//	Constructor and destructor
	//----------------------------------
public:
   Access_access()
      {//default constructor
      }

   ~Access_access()
      {//default destructor
      }

   //----------------------------------
	//	Codec's types
	//----------------------------------
public:
	typedef item_t* pointer;
	typedef item_t& reference;
	typedef const item_t* const_pointer;
	typedef const item_t& const_reference;

	byte_t 
      access_version( const_pointer _Tpl ) const _NOTHROW
		   {//get index of version
		   return (((Item_header*)_Tpl)->VeSign);
		   }

	bool_t 
      wizard_version( const_pointer _Tpl ) const _NOTHROW
		   {//size of header for any version
		   return (access_version(_Tpl) == WIZARD);
		   }

	uint_t 
      header_size( const_pointer _Tpl ) const _NOTHROW
		   {//size of header for any version
		   return (wizard_version(_Tpl) ? sizeof(Item_header) : sizeof(Code_header));
		   }

	//----------------------------------
	//		Read parameters from code
	//----------------------------------
public:
	byte_t 
      harmon_Nyqwist( const_pointer _Tpl ) const _NOTHROW
		   {//correct harmon for version
         return (wizard_version(_Tpl) ? 32 : 0);
		   }

	uint_t 
      power_quantity( const_pointer _Tpl ) const _NOTHROW
		   {//length of template
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->Length : ((Code_header*)_Tpl)->Length);
		   }

	byte_t
      focus_quantity( const_pointer _Tpl ) const _NOTHROW
		   {//length of singularities
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->PFocus : ((Code_header*)_Tpl)->PFocus);
		   }

	twin_t
      point_quantity( const_pointer _Tpl ) const _NOTHROW
		   {//length of minutiae
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->PPoint : ((Code_header*)_Tpl)->PPoint);
		   }

	twin_t
      total_quantity( const_pointer _Tpl ) const _NOTHROW
		   {//length of ridge count
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->PTotal : ((Code_header*)_Tpl)->PTotal);
		   }

	twin_t
      ridge_quantity( const_pointer _Tpl ) const _NOTHROW
		   {//lrngth of ridge count
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->PRidge : ((Code_header*)_Tpl)->PRidge);
		   }

	twin_t
      areas_quantity( const_pointer _Tpl ) const _NOTHROW
		   {//length of areas
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->PAreas : ((Code_header*)_Tpl)->PAreas);
		   }

	uint_t
      links_quantity( const_pointer _Tpl ) const _NOTHROW
		   {//length of links
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->PLinks : ((Code_header*)_Tpl)->PLinks);
		   }

	uint_t
      class_quantity( const_pointer _Tpl ) const _NOTHROW
		   {//length of classificators
         return (wizard_version(_Tpl) ?  /* test if old version */ 0 : ((Code_header*)_Tpl)->PClass);
		   }

	uint_t
      gloss_quantity( const_pointer _Tpl ) const _NOTHROW
		   {//length of glossary
         return (wizard_version(_Tpl) ?  /* test if old version */ 0 : ((Code_header*)_Tpl)->PGloss);
		   }

	byte_t
      image_smp_mask( const_pointer _Tpl ) const _NOTHROW
		   {//get simple mask
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->ImMask : ((Code_header*)_Tpl)->ImMask);
		   }

	twin_t
      image_ext_mask( const_pointer _Tpl ) const _NOTHROW
		   {//get extended mask
         return (wizard_version(_Tpl) ?  /* test if old version */ 0 : ((Code_header*)_Tpl)->ExMask);
		   }

	byte_t 
      sample_type_of( const_pointer _Tpl ) const _NOTHROW
		   {//get type of image
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->ImType : ((Code_header*)_Tpl)->ImType);
		   }

	byte_t 
      sample_quality( const_pointer _Tpl ) const _NOTHROW
		   {//get quality of pattern
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->Qualit : ((Code_header*)_Tpl)->Qualit);
		   }

	byte_t
      sample_density( const_pointer _Tpl ) const _NOTHROW
		   {//get density of pattern
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->Densit : ((Code_header*)_Tpl)->Densit) + harmon_Nyqwist(_Tpl);
		   }

	byte_t
      sample_pass_xy( const_pointer _Tpl ) const _NOTHROW
		   {//get density of pattern
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->Passxy : ((Code_header*)_Tpl)->Passxy);
		   }

	byte_t 
      sample_pass_an( const_pointer _Tpl ) const _NOTHROW
		   {//get density of pattern
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->Passan : ((Code_header*)_Tpl)->Passan);
		   }

	byte_t
      sample_squares( const_pointer _Tpl ) const _NOTHROW
		   {//get image area
         return (wizard_version(_Tpl) ?  /* test if old version */ 0 : ((Code_header*)_Tpl)->Square);
		   }

	byte_t
      links_capacity( const_pointer _Tpl ) const _NOTHROW
		   {//get net power of image
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->TipNet : ((Code_header*)_Tpl)->TipNet);
		   }

	twin_t
      image_length_x( const_pointer _Tpl ) const _NOTHROW
		   {//get <x> size of pattern
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->Size_X : ((Code_header*)_Tpl)->Size_X);
		   }

	twin_t 
      image_length_y( const_pointer _Tpl ) const _NOTHROW
		   {//get <y> size of pattern
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->Size_Y : ((Code_header*)_Tpl)->Size_Y);
		   }

	twin_t
      processing_ppi( const_pointer _Tpl ) const _NOTHROW
		   {//get image processing PPI
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->ImgPPI : ((Code_header*)_Tpl)->ImgPPI);
		   }

	twin_t
      template_scope( const_pointer _Tpl ) const _NOTHROW
		   {//get template PPI
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->TplPPI : ((Code_header*)_Tpl)->TplPPI);
		   }

	byte_t
      finger_number_( const_pointer _Tpl ) const _NOTHROW
		   {//get template PPI
         return (wizard_version(_Tpl) ? ((Item_header*)_Tpl)->Number : ((Code_header*)_Tpl)->Number);
		   }

	//----------------------------------
	//	Various displacements into code
	//----------------------------------
public:
	uint_p 
      focus_parallax( const_pointer _Tpl ) const _NOTHROW
		   {//displacement to list of indignations
		   return (uint_p)(_Tpl+((Dislocation*)(_Tpl+header_size(_Tpl)))->DFocus);
		   }

	uint_p
      point_parallax( const_pointer _Tpl ) const _NOTHROW
		   {//displacement to list of minutiaes
		   return (uint_p)(_Tpl+((Dislocation*)(_Tpl+header_size(_Tpl)))->DPoint);
		   }

	uint_p
      total_parallax( const_pointer _Tpl ) const _NOTHROW
		   {//displacement to the ridge count for singularities
		   return (uint_p)(_Tpl+((Dislocation*)(_Tpl+header_size(_Tpl)))->DTotal);
		   }
	   
	uint_p
      ridge_parallax( const_pointer _Tpl ) const _NOTHROW
		   {//displacement to ridge count for minutiae
		   return (uint_p)(_Tpl+((Dislocation*)(_Tpl+header_size(_Tpl)))->DRidge);
		   }

	uint_p
      areas_parallax( const_pointer _Tpl ) const _NOTHROW
		   {//displacement to list of areas
		   return (uint_p)(_Tpl+((Dislocation*)(_Tpl+header_size(_Tpl)))->DAreas);
		   }

	uint_p
      links_parallax( const_pointer _Tpl ) const _NOTHROW
		   {//displacement to list of links
		   return (uint_p)(_Tpl+((Dislocation*)(_Tpl+header_size(_Tpl)))->DLinks);
		   }

	uint_p
      class_parallax( const_pointer _Tpl ) const _NOTHROW
		   {//displacement to unuse region
		   return (uint_p)(_Tpl+((Dislocation*)(_Tpl+header_size(_Tpl)))->DClass);
		   }

	uint_p
      gloss_parallax( const_pointer _Tpl ) const _NOTHROW
		   {//displacement to unuse region
		   return (uint_p)(_Tpl+((Dislocation*)(_Tpl+header_size(_Tpl)))->DGloss);
		   }
      
	};//Access_access

/**************************************
		Template class Access_decode
**************************************/
template<class _Ty>
class _LNX_PACKING Access_decode : public Access_access<_Ty>
	{//interface: quick access to decode template of signes
	typedef Access_access<_Ty> Base;
	typedef typename Base::pointer pointer;
	typedef typename Base::const_pointer const_pointer;

   struct Hash_size
      {//functor
      template<class _Is> bool_t 
         operator()( const _Is &_Lft,const _Is &_Rht ) const _NOTHROW
            {//test nearest minutiae
            return (_Lft.Size < _Rht.Size); 
            }
      };

   struct Hash_clas
      {//functor
      template<class _Is> bool_t 
         operator()( const _Is &_Lft,const _Is &_Rht ) const _NOTHROW
            {//test class order
            return (_Lft.Clas < _Rht.Clas); 
            }
      };

	bool_t 
      verify_issuer( const_pointer _Tpl ) const _NOTHROW
		   {//size of header for any version
         byte_t _Ver = Base::access_version(_Tpl); return (_Ver == WIZARD || _Ver >= VERWIZ);
		   }

   //----------------------------------
	//	Constructor and destructor
	//----------------------------------
public:
   Access_decode()
      {//default constructor
      }

   ~Access_decode()
      {//default destructor
      }

   //----------------------------------
	//	Decode functions
	//----------------------------------
public:
	bool_t 
      defend( const_pointer _Tpl ) const _NOTHROW
		   {//check first signature
         _ACCESS_DEFEND( 1,^ 000 ); return _Tpl[_Len] == (_Val % 251);
		   }

	bool_t 
      hasher( const_pointer _Tpl ) const _NOTHROW
		   {//check next signature
         _ACCESS_DEFEND( 2,^_Idx ); return _Tpl[_Len] == (_Val & 255);
		   }

	twin_t 
      idmain( const_pointer _Tpl ) const _NOTHROW
		   {//get number of singularities
         twin_t 
            _Tmp = demain( sign_p(0),_Tpl,true ); return _Tmp < SING_F ? _Tmp : 0;
		   }

	twin_t
      idnova( const_pointer _Tpl ) const _NOTHROW
		   {//get number of minutiae
         twin_t 
            _Tmp = denova( sign_p(0),_Tpl,true ); return _Tmp < MINT_F ? _Tmp : 0;
		   }

	uint_t
      idarea( const_pointer _Tpl ) const _NOTHROW
		   {//get size of area
         uint_t 
            _Tmp = dearea( char_p(0),_Tpl );      return _Tmp < AREA_F ? _Tmp : 0;
		   }

	twin_t
      demain( const sign_p _Dst,const_pointer _Tpl,bool_t _Flg ) const _NOTHROW
		   {//singularities deblocking
		   uint_t
           *_Buf = Base::focus_parallax(_Tpl );
         uint_t
			   _Hac = Base::harmon_Nyqwist(_Tpl ),
			   _Len = Base::focus_quantity(_Tpl );
         byte_t
            _Ver = Base::access_version(_Tpl );

		   if(!_Len) 
			   return 0;
         if(!verify_issuer( _Tpl ))
            return 0;
		   if (verify_length( _Buf,_Len,_Tpl ))
			   return 0;

         return denova( _Dst,_Buf,_Len,_Hac,_Ver,_Flg,SING_F );
		   }

	template<class _Other> twin_t
      demain( _Other &_Dst,const_pointer _Tpl,bool_t _Flg ) const _NOTHROW
		   {//singularities deblocking to container
		   uint_t 
           *_Buf = Base::focus_parallax(_Tpl );
         uint_t
			   _Hac = Base::harmon_Nyqwist(_Tpl ),
			   _Len = Base::focus_quantity(_Tpl );
         byte_t
            _Ver = Base::access_version(_Tpl );

		   if(!_Len) 
			   return 0;
         if(!verify_issuer( _Tpl ))
            return 0;
		   if (verify_length( _Buf,_Len,_Tpl ))
			   return 0;

         return deauto( _Dst,_Buf,_Len,_Hac,_Ver,_Flg,demain( typename _Other::pointer(),_Tpl,_Flg ));
		   }

	twin_t
      denova( const sign_p _Dst,const_pointer _Tpl,bool_t _Flg ) const _NOTHROW
		   {//minutiae deblocking
		   uint_t
           *_Buf = Base::point_parallax(_Tpl );
         uint_t
			   _Hac = Base::harmon_Nyqwist(_Tpl ),
			   _Len = Base::point_quantity(_Tpl );
         byte_t
            _Ver = Base::access_version(_Tpl );

		   if(!_Len) 
			   return 0;
         if(!verify_issuer( _Tpl ))
            return 0;
		   if (verify_length( _Buf,_Len,_Tpl ))
			   return 0;

		   return denova( _Dst,_Buf,_Len,_Hac,_Ver,_Flg,MINT_F );
		   }

	template<class _Other> twin_t
      denova( _Other &_Dst,const_pointer _Tpl,bool_t _Flg ) const _NOTHROW
		   {//minutiae deblocking to container
		   uint_t
           *_Buf = Base::point_parallax(_Tpl );
         uint_t
			   _Hac = Base::harmon_Nyqwist(_Tpl ),
			   _Len = Base::point_quantity(_Tpl );
         byte_t
            _Ver = Base::access_version(_Tpl );

		   if(!_Len) 
			   return 0;
         if(!verify_issuer( _Tpl ))
            return 0;
		   if (verify_length( _Buf,_Len,_Tpl ))
			   return 0;

         return deauto( _Dst,_Buf,_Len,_Hac,_Ver,_Flg,denova( typename _Other::pointer(),_Tpl,_Flg ));
		   }

	twin_t
      denest( const link_p _Dst,const sign_p &_Src,twin_t _Num,const_pointer _Tpl ) const _NOTHROW
		   {//nest deblocking
		   if (_Num < MINT_F)
			   {//previous point deblocking
			   uint_t
              *_Buf = Base::links_parallax(_Tpl );
            uint_t
               _Den = Base::sample_density(_Tpl ),
				   _Net = Base::links_capacity(_Tpl ),
				   _Len = Base::links_quantity(_Tpl );

			   if(!_Den) 
				   return 0; //test if density trivial
			   if(!_Len) 
				   return 0; //test if length trivial
			   if (verify_length( _Buf,_Len,_Tpl ))
				   return 0;//test if length too long

            return denest( _Dst,_Src,_Buf,_Len,_Net,_Num );
			   }
		   return 0;
		   }

	template<class _Other> twin_t
      denest( _Other &_Dst,const sign_p &_Src,twin_t _Num,const_pointer _Tpl ) const _NOTHROW
		   {//nest deblocking
		   if (_Num < MINT_F)
			   {//previous point deblocking
			   uint_t
              *_Buf = Base::links_parallax(_Tpl );
            uint_t
               _Den = Base::sample_density(_Tpl ),
				   _Net = Base::links_capacity(_Tpl ),
				   _Len = Base::links_quantity(_Tpl );

			   if(!_Den) 
				   return 0; //test if density trivial
			   if(!_Len) 
				   return 0; //test if length trivial
			   if (verify_length( _Buf,_Len,_Tpl ))
				   return 0; //test if length too long

            return denest( _Dst,_Src,_Buf,_Len,_Net,_Num );
			   }
		   return 0;
		   }

	twin_t 
      demask( const homo_p _Dst,const link_p &_Net,const sign_p &_Src,twin_t _Num ) const _NOTHROW
		   {//decode packed lnkages
         Accelerator<SISE>
            _Acc;
         for(twin_t i = 0; i < _Num; i++)
            {//build accelerator
            _Acc( _Dst + i,_Net + i,_Src + i ); 
            }
         return _Num;
         }

   twin_t
      deseed( const hash_p &_Dst,const twin_p &_Tbl,const link_p &_Net,const sign_p &_Min,twin_t _Num,uint_t _Adj,uint_t _Tln,char_t _Tol ) const _NOTHROW
		   {//extract seeds of accelerators
         twin_t
            _Cnt =  0;
         if(_Tol >= 0)
            _Cnt = exseed( _Dst,_Net,_Min,
                           _Num,_Adj,_Tol );
         if(_Cnt != 0)
            _Cnt = exsort( _Dst,_Tbl,_Cnt,
                                     _Tln );

         return _Cnt;
		   }

	template<class _Other> twin_t
      deabac( _Other *_Dst,const_pointer _Tpl ) const _NOTHROW
		   {//decode ridge count between singularities
		   uint_t
		     *_Buf = Base::total_parallax(_Tpl );
         twin_t
			   _Len = Base::total_quantity(_Tpl );

		   if(!_Len) 
			   return 0; //test if length trivial
		   if (verify_length( _Buf,_Len,_Tpl ))
			   return 0;//test if length too long

		   return deabac( _Dst,_Buf,_Len );
		   }

	template<class _Other> uint_t
      dearea( _Other *_Dst,const_pointer _Tpl,uint_t _Xln = 0,uint_t _Yln = 0 ) const _NOTHROW
		   {//decode list of regions to destination
		   uint_t
		     *_Buf = Base::areas_parallax(_Tpl );
         uint_t
			   _Len = Base::areas_quantity(_Tpl );

		   if(!_Len) 
			   return 0; //test if length trivial
		   if (verify_length( _Buf,_Len,_Tpl ))
			   return 0;//test if length too long

		   return dearea( _Dst,_Buf,_Len,_Xln,_Yln );
		   }

	//----------------------------------
	//	Kernal subfunctions
	//----------------------------------
private:
	twin_t
      denova( sign_p _Dst,uint_t const*const _Buf,uint_t _Len,uint_t _Hac,byte_t _Ver,bool_t _Flg,uint_t _Stop ) const _NOTHROW
		   {//decode packed features to buffer
         twin_t
            _Size = 0;
		   uint_t
            _Line = 0,
				_Bits = 0, _Date =   *_Buf;
		   const uint_t //read header
            _Movx = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Movy = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Type = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Lace = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Prob = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Beta = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Look = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Curl = unpack_4_bit( _Buf,_Line,_Bits,_Date );

		   if(!_Dst)//quantity of items
			   return  twin_t(((_Len << 3) - 8*4)/(_Movx + _Movy + _Type + _Lace + _Prob + _Beta + _Look + _Curl));
		
		   for (; local_type_size( _Line,_Bits ) < _Len && _Size < _Stop; _Size++)
			   {//arithmetic pointer
            sign_p
               _Pnt = _Dst + _Size;

			   _Pnt->Movx = shrt_t(unpack_x_bit( _Buf,_Line,_Bits,_Date,_Movx ));
			   _Pnt->Movy = shrt_t(unpack_x_bit( _Buf,_Line,_Bits,_Date,_Movy ));
			   _Pnt->Type = byte_t(unpack_x_bit( _Buf,_Line,_Bits,_Date,_Type ));
			   _Pnt->Lace = byte_t(unpack_x_bit( _Buf,_Line,_Bits,_Date,_Lace ) + _Hac);
			   _Pnt->Prob = byte_t(unpack_x_bit( _Buf,_Line,_Bits,_Date,_Prob ));
			   _Pnt->Beta = shrt_t(unpack_x_bit( _Buf,_Line,_Bits,_Date,_Beta ));
			   _Pnt->Look = byte_t(unpack_x_bit( _Buf,_Line,_Bits,_Date,_Look ));
			   _Pnt->Curl = byte_t(unpack_x_bit( _Buf,_Line,_Bits,_Date,_Curl ));
			   }

         if (_Flg == true)
            {//need 256 degree
            if (_Ver == WIZARD)
               for (twin_t i = _Size; i--;) 
                  _Dst[i].Beta = dndg( 
                                 dudg( _Dst[i].Beta )); //transform 360 to 256 degree
            }
         else
            {//need 360 degree
            if (_Ver >= VERWIZ)
               for (twin_t i = _Size; i--;) 
                  _Dst[i].Beta = updg( _Dst[i].Beta ); //transform 256 to 360 degree
            else
            if (_Ver == WIZARD)
               for (twin_t i = _Size; i--;) 
                  _Dst[i].Beta = dudg( _Dst[i].Beta ); //set duple
            }
         //verify
         return local_type_test( _Line,_Bits,_Len ) ? _Size : 0;
		   }

	template<class _Other> twin_t
      deauto( _Other &_Dst,uint_t const*const _Buf,uint_t _Len,uint_t _Hac,byte_t _Ver,bool_t _Flg,twin_t _Num ) const _NOTHROW
		   {//auto decode packed features to container
         if(!_Num)
            return 0;
         else
            {//vacate new container		
            _Dst.reserve( _Num ); _Dst.clear();
            }

         typename _Other::item_t 
            _Val;

		   uint_t //prepare data
            _Line = 0,
				_Bits = 0, _Date =   *_Buf; 
		   const uint_t //read header
            _Movx = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Movy = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Type = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Lace = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Prob = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Beta = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Look = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Curl = unpack_4_bit( _Buf,_Line,_Bits,_Date );

		   for (uint_t i = 0; local_type_size( _Line,_Bits ) < _Len && i < _Dst.capacity(); i++)
			   {//unpack _Other element
			   _Val.Movx = shrt_t(unpack_x_bit( _Buf,_Line,_Bits,_Date,_Movx ));
			   _Val.Movy = shrt_t(unpack_x_bit( _Buf,_Line,_Bits,_Date,_Movy ));
			   _Val.Type = byte_t(unpack_x_bit( _Buf,_Line,_Bits,_Date,_Type ));
			   _Val.Lace = byte_t(unpack_x_bit( _Buf,_Line,_Bits,_Date,_Lace ) + _Hac);
			   _Val.Prob = byte_t(unpack_x_bit( _Buf,_Line,_Bits,_Date,_Prob ));
			   _Val.Beta = shrt_t(unpack_x_bit( _Buf,_Line,_Bits,_Date,_Beta ));
			   _Val.Look = byte_t(unpack_x_bit( _Buf,_Line,_Bits,_Date,_Look ));
			   _Val.Curl = byte_t(unpack_x_bit( _Buf,_Line,_Bits,_Date,_Curl ));

			   _Dst.push_back( _Val );
			   }

         if (_Flg == true)
            {//need 256 degree
            if (_Ver == WIZARD)
               for (uint_t i = _Dst.size(); i--;) 
                  _Dst[i].Beta = dndg( 
                                 dudg( _Dst[i].Beta )); //transform 360 to 256 degree
            }
         else
            {//need 360 degree
            if (_Ver >= VERWIZ)
               for (uint_t i = _Dst.size(); i--;) 
                  _Dst[i].Beta = updg( _Dst[i].Beta ); //transform 256 to 360 degree
            else
            if (_Ver == WIZARD)
               for (uint_t i = _Dst.size(); i--;) 
                  _Dst[i].Beta = dudg( _Dst[i].Beta ); //set duple
            }
         //verify
         return local_type_test( _Line,_Bits,_Len ) ? twin_t(_Dst.size()) : 0;
		   }

	twin_t 
      denest( const link_p _Dst,const sign_p &_Src,uint_t const*const _Buf,uint_t _Len,uint_t _Net,twin_t _Num ) const _NOTHROW
		   {//decode packed lnkages to _Other pointer
         uint_t //prepare data 
            _Line = 0,
				_Bits = 0, _Date =   *_Buf;
         const uint_t //read header
            _Deal = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Mind = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Rupt = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Pins = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Down = unpack_4_bit( _Buf,_Line,_Bits,_Date ),
				_Diff = unpack_4_bit( _Buf,_Line,_Bits,_Date ); 
         if(_Deal == 0)
            return   0;
         if(_Mind == 0)
            return   0;
         if(_Rupt == 0)
            return   0;

		   for(twin_t j = 0; j < _Num; j++)
			   {//decode linkages while minutiae
            link_p
               _Phub = _Dst + j;
            sign_p
               _Pone = _Src + j;

            //prepare
            uint_t   
               _Stop = 2*_Net + (_Pone->Type == MB ? 1 : -1),
               _Cage = 0;

            if(_Pins == 1)
               {//short pink
			      for(uint_t i = 0; i < _Stop; i++)
				      {//scan section
                  bond_t &
                     _Refr = _Phub->Knot[i];
                  register uint_t 
                     _Fact = unpack_2_bit( _Buf,_Line,_Bits,_Date ),
                     _Pink = 0;

				      if(_Fact)
					      {//not rupture
					      if(_Fact == 3)
						      _Fact += unpack_2_bit( _Buf,_Line,_Bits,_Date ) << 2,
						      _Pink  = unpack_1_bit( _Buf,_Line,_Bits,_Date );
					      else//projection
						      _Fact += unpack_1_bit( _Buf,_Line,_Bits,_Date ) << 2;
                     //meaning link
                     _Cage = i + 1;
					      }

                  _Refr.Deal = _Fact & 0xff;
                  _Refr.Pink = _Pink & 0xff;
				      }
               }
            else
               {//link length
			      for(uint_t i = 0; i < _Stop; i++)
				      {//scan section
                  bond_t &
                     _Refr = _Phub->Knot[i];
                  register uint_t 
                     _Fact = unpack_2_bit( _Buf,_Line,_Bits,_Date ),
                     _Pink = 0;

				      if(_Fact)
					      {//not rupture
					      if(_Fact == 3)
						      _Fact += unpack_2_bit( _Buf,_Line,_Bits,_Date ) << 2;
					      else//projection
						      _Fact += unpack_1_bit( _Buf,_Line,_Bits,_Date ) << 2;
						      _Pink  = unpack_x_bit( _Buf,_Line,_Bits,_Date,_Pins );
                     //meaning link
                     _Cage = i + 1;
					      }

                  _Refr.Deal = _Fact & 0xff;
                  _Refr.Pink = _Pink & 0xff;
				      }
               }

            //store vector size 
            _Phub->Cage = _Cage & 0xff;

			   const uint_t 
               _Dwn = unpack_x_bit( _Buf,_Line,_Bits,_Date,_Down ), //low index
					_Qnt = unpack_x_bit( _Buf,_Line,_Bits,_Date,_Diff ); //quants
			
			   for(uint_t i = 0; i < _Cage; i++)
				   {//look section over a net
               const bond_p
                  _Knot = _Phub->Knot + i;
               register byte_t
                  _Fact = _Knot->Deal,
                  _Azim = 0,
                  _Teta = 0;
               register sign_p
                  _Tree = 0;
               register uint_t 
                  _Item = 0,
                  _Size = 0;

				   if(_Fact)
					   {//test if subsist
					   if ((_Item = unpack_x_bit( _Buf,_Line,_Bits,_Date,_Qnt ) + _Dwn) < _Num)
						   {//correct event
                     _Fact |= ((_Tree = _Src + _Item)->Type == ME) << 3;

							//calc geometry
                     const iint_t
                        _Dx = _Tree->Movx - _Pone->Movx,
                        _Dy = _Tree->Movy - _Pone->Movy;

                     if(_Dx || _Dy)
                        {//other minutiae <see mutant>
                        _Size =        isize( _Dx,_Dy );   if(_Size > SIMA-1) _Size = SIMA-1;
                        _Azim = watch( arctg( _Dx,_Dy ),_Pone->Beta );
                        _Teta = watch(    _Tree->Beta  ,_Pone->Beta );
                        }
						   }
					   else
                     {//error
                     AFFBUG; return 0;
                     }
					   }
            
               _Knot->Deal = _Fact;
               _Knot->Item = _Item & 0x7fff;
               _Knot->Size = _Size & 0x7fff;
               _Knot->Azim = _Azim;
               _Knot->Teta = _Teta;
				   }
            //erase the tail of this nest
            type_init( _Phub->Knot + _Cage,MAXL - _Cage );
			   }
         //verify
         return local_type_test( _Line,_Bits,_Len ) ? _Num : 0;
		   }

	template<class _Other> twin_t 
      denest( _Other &_Dst,uint_t const*const _Buf,uint_t _Len,uint_t _Net,twin_t _Num ) const _NOTHROW
		   {//decode packed lnkages to _Other pointer
         return denest( _Dst.data(),_Buf,_Len,_Net,_Num );
         }

   twin_t
      exseed( const hash_p &_Dst,const link_p &_Net,const sign_p &_Min,twin_t _Num,iint_t _Adj,char_t _Tol ) const _NOTHROW
		   {//extract seeds from nests
         enum
            {//limitations
            SMAX = 130,
            SMIN =  10,
            ATOL =  21,
            NDIP =   8,
            };

         //parameters
         Dipole 
            _Dipl[NDIP];
         iint_t 
            _Nhas = 0,
            _Ndip = 0; 

         for(twin_t j = 0; j < _Num; j++)
            {//scan all nests
            const link_p
               _Phub = j + _Net; _Ndip = 0;
            const sign_p
               _Pmin = j + _Min;

            for(uint_t i = 0; i < _Phub->Cage && _Ndip < NDIP; i++)
               {//scan links in nest
               const bond_p
                  _Plnk = _Phub->Knot + i;

               if (byte_t _Deal = _Plnk->Deal)
                  {twin_t _Item = _Plnk->Item;
                   byte_t _Azim = _Plnk->Azim,
                          _Teta = _Plnk->Teta,
                          _Beta = _Pmin->Beta & 255,
                          _Size = _Plnk->Size < 255 ? (_Plnk->Size & 255) : 255;
                  
                  for(iint_t g = 0; g < _Ndip; g++)
                     {//test item
                     if (_Item == _Dipl[g].Item) 
                        goto skip;
                     }
                  //store new dipole
                  _Dipl[_Ndip].Item = _Item;
                  _Dipl[_Ndip].Size = _Size;
                  _Dipl[_Ndip].Azim = _Azim;
                  _Dipl[_Ndip].Beta = _Beta;
                  _Dipl[_Ndip].Teta = _Teta;
                  _Dipl[_Ndip].Clop =  Clop[_Deal]; _Ndip++;
   skip:;         }
               }

            if (_Ndip)
               {//sort nearest
               sort<Less<Dipole> >( _Dipl,_Ndip-1,0 );

               for(iint_t i = 0;   i < _Ndip; i++)
                  {iint_t g = 0;

                  while ( g < i && i < _Ndip)
                     {//test size and azimuth
                     if (_Dipl[g].Size < SMIN || 
                         _Dipl[g].Size > SMAX || uturn( _Dipl[g].Azim,_Dipl[i].Azim ) < ATOL)
                        {_Ndip--;
                        for(iint_t k = i; k < _Ndip; k++)
                           {//compress
                           _Dipl[k] = _Dipl[k+1];
                           }
                        }
                     else
                        g++;
                     }
                  }
               
               for(iint_t i = 0; i < _Ndip && i < _Adj; i++)
                  {//store meshes
                  iint_t 
                     _Core = _Dipl[i].Azim >> 2;
                  byte_t
                     _Clop = _Dipl[i].Clop,
                     _Size = _Dipl[i].Size,
                     _Beta = _Dipl[i].Beta,
                     _Teta = _Dipl[i].Teta;

                  for(iint_t t = -_Tol; t <= _Tol; t++,_Nhas++)
                     {
                      if(_Nhas >= twin_t(-2))
                         {
                         AFFBUG; return (twin_t)_Nhas;
                         }
                     _Dst[_Nhas].Clas = ((t + _Core) & 63) | (_Clop << 6);
                     _Dst[_Nhas].Item =   j   ;
                     _Dst[_Nhas].Size =  _Size;
                     _Dst[_Nhas].Beta =  _Beta;
                     _Dst[_Nhas].Teta =  _Teta;
                     }
                  }
               }
            }
         return (twin_t)_Nhas;
         }

	twin_t
      exsort( const hash_p &_Dst,const twin_p &_Tbl,twin_t _Cnt,uint_t _Tln ) const _NOTHROW
		   {//sort and build references
         sort<Less<hash_t> >( _Dst,_Cnt-1,0 ); return tbseed( _Dst,_Tbl,_Cnt,_Tln );
         }

	twin_t
      tbseed( const hash_p & _Dst,const twin_p &_Tbl,twin_t _Cnt,uint_t _Tln ) const _NOTHROW
		   {//build references
         const twin_t
            _Val = twin_t(-1);
         uint_t 
            _Idx,
            _Jdx;

         //reset table
         type_init( _Tbl,_Val,_Tln );

         for(_Idx = 0; _Idx < _Cnt; _Idx = _Jdx)
            {//build table
            const uint_t
               _Clas = _Dst[_Idx].Clas;
                            _Tbl[_Clas] = twin_t(_Idx);

            for(_Jdx = _Idx; _Jdx < _Cnt; _Jdx++)
               {//skip copies
               if(_Dst[_Jdx].Clas != _Clas) break;
               }
            }
         return _Cnt;
         }

	template<class _Other> twin_t
      deabac( _Other *_Dst,uint_t const*const _Buf,uint_t _Len ) const _NOTHROW
		   {//decode ridge count between singularities
         twin_t
            _Size = 0;
		   uint_t
            _Line = 0,
				_Bits = 0, _Date = _Buf[0];

		   if (!_Dst)
			   return twin_t((_Len << 3)/( 2+5 ));

		   for (; local_type_size( _Line,_Bits ) < _Len; _Size++)
			   {//unpack ridge count
                _Dst[_Size]  = byte_t(unpack_2_bit( _Buf,_Line,_Bits,_Date ));
			   if (_Dst[_Size])
				    _Dst[_Size] += byte_t(unpack_5_bit( _Buf,_Line,_Bits,_Date ) << 2);
			   }
         //verify
		   return local_type_test( _Line,_Bits,_Len ) ? _Size : 0;
		   }

	template<class _Other> uint_t
      dearea( _Other *_Dst,uint_t const*const _Buf,uint_t _Len,uint_t _Xln,uint_t _Yln ) const _NOTHROW
		   {//decode list of regions to destination
		   uint_t
            _Bool = 0,
				_Line = 0,
				_Bits = 0, _Date = _Buf[0];

         const uint_t
            _Xtpl = unpack_x_bit( _Buf,_Line,_Bits,_Date,uint_t(16)),
            _Ytpl = unpack_x_bit( _Buf,_Line,_Bits,_Date,uint_t(16));
         uint_t
            _Calc = unpack_x_bit( _Buf,_Line,_Bits,_Date,uint_t( 8));

         if(!_Dst) //memorie's bytes
            return _Xtpl*_Ytpl;

         if(_Xln)
            {//test width
            if(_Xln < _Xtpl) return 0;
            }
         else
            _Xln = _Xtpl;

         if(_Yln)
            {//test height
            if(_Yln < _Ytpl) return 0;
            }
         else
            _Yln = _Ytpl;

         for (uint_t j = 0; j < _Ytpl; j++)
            {
		      for (uint_t i = 0; i < _Xtpl; i++)
			      {
			      if(_Calc == 0)
				      {//test if end of phase
				      _Bool = !_Bool; _Len--; _Calc =  unpack_x_bit( _Buf,_Line,_Bits,_Date,uint_t(8));
				      }
			      if(_Calc == 0)
				      {//test if end of phase
				      _Bool = !_Bool; _Len--; _Calc =  unpack_x_bit( _Buf,_Line,_Bits,_Date,uint_t(8));
				      }
			      if(_Calc)
				      {//encode and advance pointer
				      if (_Bool)
                     *_Dst++ = C6;
                  else
					      *_Dst++ = C7;

				      _Calc--; //reduce length of list
				      }
			      }
               for (uint_t i = _Xln -_Xtpl; i > 0; i--)
                  *_Dst++ = C7; //remainder
            }
         for (uint_t j = _Yln -_Ytpl; j > 0; j--)
            {//remainder
		      for (uint_t i = 0; i < _Xtpl; i++)
			      *_Dst++ = C7;
            for (uint_t i = _Xln -_Xtpl; i > 0; i--)
               *_Dst++ = C7;
            }
         //verify
		   return ((_Len == 5 || _Len == 6) ? _Xtpl + (_Ytpl << 16) : 0);
		   }

	template<class _Other> bool_t
      verify_length( _Other const*const _Buf,uint_t _Len,byte_t const*const _Tpl ) const _NOTHROW
		   {//verify the length of data list
		   return (((byte_p)_Buf + _Len) > (_Tpl + Base::power_quantity( _Tpl )));
		   }

	};//Access_decode

/**************************************
		  Class Access_encode
**************************************/
template<class _Ty>
class _LNX_PACKING Access_encode : private Access_access<_Ty>
	{//interface: quick access to encode template of signes
	typedef Access_access<_Ty> Base;
	typedef typename Base::pointer pointer;
	typedef typename Base::const_pointer const_pointer;

   //----------------------------------
	//	Constructor and destructor
	//----------------------------------
public:
   Access_encode()
      {//default constructor
      }

   ~Access_encode()
      {//default destructor
      }

   //----------------------------------
	//	Encode functions
	//----------------------------------
public:
	void_t 
      defend( pointer _Tpl ) const _NOTHROW
		   {//set first signature
         _ACCESS_DEFEND( 1,^ 000 ); _Tpl[_Len] = (_Val % 251);
		   }

	void_t 
      hasher( pointer _Tpl ) const _NOTHROW
		   {//set next signature
         _ACCESS_DEFEND( 2,^_Idx ); _Tpl[_Len] = (_Val & 255);
		   }

	template<class _Other> uint_t
      encode( atom_t *_Tpl,const _Other &_Src ) const _NOTHROW
		   {//encode the vector of sign
		   if (_Src.size())
			   return encode((uint_t *const)_Tpl,_Src );
		   return 0;
		   }

	template<class _Pool,class _Mint> uint_t
      ennest( atom_t *_Tpl,const _Pool &_Src,const _Mint &_Sgn,uint_t _Pin,uint_t _Net ) const _NOTHROW
		   {//encode the vector of nests
		   if (_Src.size())
			   return ennest((uint_t *const)_Tpl,_Src,_Sgn,_Pin,_Net );
		   return 0;
		   }

	uint_t 
      enarea( atom_t *_Tpl,atom_t *_Src,uint_t _Xsz,uint_t _Ysz,byte_t _Msk ) const _NOTHROW
		   {//encode list of regions to destination
		   if (_Msk)
			   return enarea((uint_t *const)_Tpl,_Src,_Xsz,_Ysz,_Msk );
		   return 0;
		   }

	//----------------------------------
	//	Kernal subfunctions
	//----------------------------------
private:
	template<class _Other> uint_t
      encode( uint_t *const _Tpl,const _Other &_Src ) const _NOTHROW
		   {//encode the vector of _Other type
		   uint_t
            _Line = 0,
				_Bits = 0;
		   const uint_t//bit size
            _Movx = quants<uint_t>( get_movx_max( _Src )),
				_Movy = quants<uint_t>( get_movy_max( _Src )),
				_Type = quants<uint_t>( get_type_max( _Src )),
				_Lace = quants<uint_t>( get_lace_max( _Src )),
				_Prob = quants<uint_t>( get_prob_max( _Src )),
				_Beta = quants<uint_t>( get_beta_max( _Src )),
            _Look = quants<uint_t>( get_look_max( _Src )),
            _Curl = quants<uint_t>( get_curl_max( _Src ));

		   //store heading for item of vector
         section_init( _Tpl );
		   repack_4_bit( _Tpl,_Line,_Bits,_Movx );
		   repack_4_bit( _Tpl,_Line,_Bits,_Movy );
		   repack_4_bit( _Tpl,_Line,_Bits,_Type );
		   repack_4_bit( _Tpl,_Line,_Bits,_Lace );
		   repack_4_bit( _Tpl,_Line,_Bits,_Prob );
		   repack_4_bit( _Tpl,_Line,_Bits,_Beta );
		   repack_4_bit( _Tpl,_Line,_Bits,_Look );
		   repack_4_bit( _Tpl,_Line,_Bits,_Curl );

		   for (uint_t i = 0; i < _Src.size(); i++)
			   {//encode element of _Other
            typename _Other::const_reference 
               _Ref = _Src[i];

			   repack_x_bit( _Tpl,_Line,_Bits,_Ref.Movx,_Movx );
			   repack_x_bit( _Tpl,_Line,_Bits,_Ref.Movy,_Movy );
			   repack_x_bit( _Tpl,_Line,_Bits,_Ref.Type,_Type );
			   repack_x_bit( _Tpl,_Line,_Bits,_Ref.Lace,_Lace );
			   repack_x_bit( _Tpl,_Line,_Bits,_Ref.Prob,_Prob );
            repack_x_bit( _Tpl,_Line,_Bits,_Ref.Beta,_Beta );
			   repack_x_bit( _Tpl,_Line,_Bits,_Ref.Look,_Look );
			   repack_x_bit( _Tpl,_Line,_Bits,_Ref.Curl,_Curl );
			   }
         //length
		   return local_type_size( _Line,_Bits );
		   }

	template<class _Pool,class _Mint> uint_t
      ennest( uint_t *const _Tpl,const _Pool &_Src,const _Mint &_Sgn,uint_t _Pins,uint_t _Net ) const _NOTHROW
		   {//encode the vector of _Other type
		   uint_t
            _Line = 0,
				_Bits = 0;
			const uint_t //bit size
            _Deal = 4,
				_Mind = 3,
				_Rupt = 2,
				_Down = quants( _Src.size()), _Diff = quants( _Down );

		   //store heading for item of vector
         section_init( _Tpl );
		   repack_4_bit( _Tpl,_Line,_Bits,_Deal );
		   repack_4_bit( _Tpl,_Line,_Bits,_Mind );
		   repack_4_bit( _Tpl,_Line,_Bits,_Rupt );
		   repack_4_bit( _Tpl,_Line,_Bits,_Pins );
		   repack_4_bit( _Tpl,_Line,_Bits,_Down );
		   repack_4_bit( _Tpl,_Line,_Bits,_Diff );

		   for (uint_t j = 0; j < _Src.size(); j++)
			   {//encode the vector of _Other
            typename _Pool::const_pointer 
               _Tptr = _Src.data() + j;
			   uint_t
               _Stop = _Net*2 + (_Sgn[j].Type == MB ? 1 :-1 ),
					_Qloc = 00;
            iint_t
					_Imax = 00,
               _Imin = SS;

			   for (uint_t i = 0; i < _Stop; i++)
				   {//look section over the net
               const bond_t & 
                  _Refr = _Tptr->Knot[i];

				   if (_Refr.Deal)
					   {//parse event & save
					   if(_Imin > _Refr.Item)
						   _Imin = _Refr.Item;
					   if(_Imax < _Refr.Item)
						   _Imax = _Refr.Item;

					   if(_Pins == 1)
						   {//as it was 
						   if((_Refr.Deal & 3) == 3)
							   {//set event and the pink
							   repack_x_bit( _Tpl,_Line,_Bits,_Refr.Deal,_Deal );
							   repack_1_bit( _Tpl,_Line,_Bits,_Refr.Pink );
							   }
						   else//only event
							   repack_x_bit( _Tpl,_Line,_Bits,_Refr.Deal,_Mind );
						   }
					   else
						   {//strongly modified version
						   if((_Refr.Deal & 3) == 3)
							   repack_x_bit( _Tpl,_Line,_Bits,_Refr.Deal,_Deal );
						   else
							   repack_x_bit( _Tpl,_Line,_Bits,_Refr.Deal,_Mind );
                        //always pink
							   repack_x_bit( _Tpl,_Line,_Bits,_Refr.Pink,_Pins );
						   }
					   }
				   else		
                        repack_x_bit( _Tpl,_Line,_Bits,_Refr.Deal,_Rupt );
				   }
            //purify if empty
			   if(_Imax < _Imin)
				   _Imax = _Imin = 00;
            
			   repack_x_bit( _Tpl,_Line,_Bits,_Imin,_Down );
				/* ecode difference */               _Qloc = quants( _Imax-_Imin );
			   repack_x_bit( _Tpl,_Line,_Bits,_Qloc,_Diff );

			   for (uint_t i = 0; i < _Stop; i++)
				   {//look section over the net
               const bond_t & 
                   _Refr = _Tptr->Knot[i];

				   if (_Refr.Deal)
					   {//pack number
					   repack_x_bit( _Tpl,_Line,_Bits,_Refr.Item - _Imin,_Qloc );
					   }
				   }
			   }
         //length
		   return local_type_size( _Line,_Bits );
		   }

	uint_t
      enarea( uint_t *const _Tpl,atom_t *_Src,uint_t _Xsz,uint_t _Ysz,atom_t _Msk ) const _NOTHROW
		   {//encode list of regions to destination
		   uint_t
            _Line = 0,
				_Bits = 0,
				_Bool = 0,
				_Calc = 0;

		   section_init( _Tpl );
         repack_x_bit( _Tpl,_Line,_Bits,_Xsz,uint_t(16));
		   repack_x_bit( _Tpl,_Line,_Bits,_Ysz,uint_t(16));

		   for(uint_t i = 0; i < _Xsz*_Ysz; i++)
			   {//scan the list of regions
			   if (_Src[i] == _Msk)
				   {//test if good area
				   if (_Bool)
					   _Calc++;
				   else//a list
					   enarea_list( _Tpl,_Line,_Bits,_Bool,_Calc );
				   }
			   else//bad area
				   {
				   if(!_Bool)
					   _Calc++;
				   else//a list
					   enarea_list( _Tpl,_Line,_Bits,_Bool,_Calc );
				   }	//region flushing
			   }		enarea_list( _Tpl,_Line,_Bits,_Bool,_Calc );
         //length
		   return (local_type_size( _Line,_Bits ));
		   }

	void_t
      enarea_list( uint_t *const _Tpl,uint_t &_Line,uint_t &_Bits,uint_t &_Bool,uint_t &_Calc ) const _NOTHROW
		   {//write list of regions
		   for(; _Calc > BM; _Calc -= BM)
			   {
			   repack_x_bit( _Tpl,_Line,_Bits,BM,uint_t(8));
			   repack_x_bit( _Tpl,_Line,_Bits,00,uint_t(8));
			   }
		   //flash remainder
		   repack_x_bit( _Tpl,_Line,_Bits,_Calc,uint_t(8));

		   //adapt new region info
		   _Calc = 1; _Bool = !_Bool;
		   }

	//----------------------------------
	//	Primitive subfunctions
	//----------------------------------
private:
	template<class _Other> uint_t
      get_movx_max( const _Other &_Src,iint_t _Max = 0 ) const _NOTHROW
		   {//find maximum of x coordinate
		   for (uint_t i = 0; i < _Src.size(); i++)
			   if (_Max < _Src[i].Movx)
				    _Max = _Src[i].Movx;
		   return _Max;
		   }

	template<class _Other> uint_t
      get_movy_max( const _Other &_Src,iint_t _Max = 0 ) const _NOTHROW
		   {//find maximum of y coordinate
		   for (uint_t i = 0; i < _Src.size(); i++)
			   if (_Max < _Src[i].Movy)
				    _Max = _Src[i].Movy;
		   return _Max;
		   }

	template<class _Other> byte_t
      get_type_max( const _Other &_Src,byte_t _Max = 0 ) const _NOTHROW
		   {//find maximum of probability
		   for (uint_t i = 0; i < _Src.size(); i++)
			   if (_Max < _Src[i].Type)
				    _Max = _Src[i].Type;
		   return _Max;
		   }

	template<class _Other> byte_t
      get_prob_max( const _Other &_Src,byte_t _Max = 0 ) const _NOTHROW
		   {//find maximum of probability
		   for (uint_t i = 0; i < _Src.size(); i++)
			   if (_Max < _Src[i].Prob)
				    _Max = _Src[i].Prob;
		   return _Max;
		   }

	template<class _Other> twin_t
      get_beta_max( const _Other &_Src,twin_t _Max = 0 ) const _NOTHROW
		   {//find maximum of direction
		   for (uint_t i = 0; i < _Src.size(); i++)
			   if (_Max < _Src[i].Beta)
				    _Max = _Src[i].Beta;
		   return _Max;
		   }

	template<class _Other> byte_t
      get_lace_max( const _Other &_Src,byte_t _Max = 0 ) const _NOTHROW
		   {//find maximum harmon
		   for (uint_t i = 0; i < _Src.size(); i++)
			   if (_Max < _Src[i].Lace)
				    _Max = _Src[i].Lace;
		   return _Max;
		   }

	template<class _Other> byte_t
      get_look_max( const _Other &_Src,byte_t _Max = 0 ) const _NOTHROW
		   {//find maximum looking
		   for (uint_t i = 0; i < _Src.size(); i++)
			   if (_Max < _Src[i].Look)
				    _Max = _Src[i].Look;
		   return _Max;
		   }

	template<class _Other> byte_t
      get_curl_max( const _Other &_Src,byte_t _Max = 0 ) const _NOTHROW
		   {//find maximum for positive & negative curvature
		   for (uint_t i = 0; i < _Src.size(); i++)
			   if (_Max < _Src[i].Curl)
				    _Max = _Src[i].Curl;
		   return _Max;
		   }

   void_t
      section_init( uint_t *const _Tpl ) const _NOTHROW
         {//initialize start of section
         *_Tpl = 0;
         }

	};//Access_encode

_ESK_END
#pragma pack(pop)
#endif//ACCESS_H
