#ifndef BIND_REQUEST_TECH5
#define BIND_REQUEST_TECH5

const DWORD encrypt_mac_address_count_sdk_gallery_matcher = 0x5a4f7d89;
const DWORD encrypt_mac_address_count_sdk_client = 0x5a4f7d89;
const DWORD encrypt_mac_address_count_sdk_auth_matcher = 0x5a4f7d89;
const DWORD encrypt_mac_address_count_sdk_ma = 0x5a4f7d89;

const DWORD encrypt_hdd_sdk_gallery_matcher = 0x5a4f6d89;
const DWORD encrypt_hdd_sdk_client = 0x5a4f6d89;
const DWORD encrypt_hdd_sdk_auth_matcher = 0x5a4f6d89;
const DWORD encrypt_hdd_sdk_ma = 0x5a4f6d89;

const DWORD encrypt_answer_sdk_gallery_matcher	= 0x0AAAAAA;
const DWORD encrypt_answer_sdk_client	= 0x0BBBBBB;
const DWORD encrypt_answer_sdk_auth_matcher	= 0x0CCCCCC;
const DWORD encrypt_answer_sdk_ma	= 0x0DDDDDD;

const DWORD encrypt_mac_address_count[4] = {encrypt_mac_address_count_sdk_gallery_matcher,encrypt_mac_address_count_sdk_client,encrypt_mac_address_count_sdk_auth_matcher,encrypt_mac_address_count_sdk_ma};

const DWORD encrypt_hdd[4] = {encrypt_hdd_sdk_gallery_matcher,encrypt_hdd_sdk_client,encrypt_hdd_sdk_auth_matcher,encrypt_hdd_sdk_ma};

const DWORD encrypt_answer[4] = {encrypt_answer_sdk_gallery_matcher,encrypt_answer_sdk_client,encrypt_answer_sdk_auth_matcher,encrypt_answer_sdk_ma};

#endif