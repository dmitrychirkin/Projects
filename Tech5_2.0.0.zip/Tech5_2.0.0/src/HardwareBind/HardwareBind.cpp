#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <time.h>
#include <locale.h>
#include <coreSdk.h>

#if defined(_WINDOWS) || defined (_WIN32_WCE)
#include <windows.h>
#include <iphlpapi.h>
#include <rpc.h>
#include <Rpcdce.h>
#include <setupapi.h>
#include <devguid.h>
#elif defined (ANDROID)
#include <stdint.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <net/ethernet.h>
#include <netinet/ether.h>
#include <linux/if.h>
#include <unistd.h>

#define __stdcall

typedef struct _GUID {
   unsigned long  Data1;
   unsigned short Data2;
   unsigned short Data3;
   unsigned char  Data4[8];
} GUID;

#ifndef UUID_DEFINED
#define UUID_DEFINED
typedef GUID UUID;
#ifndef uuid_t
#define uuid_t UUID
#endif
#endif

typedef unsigned int    __time32_t;
#define _time32    time

#define stricmp strcasecmp
#define __int64 int64_t
FILE* _wfopen(const wchar_t* filename, const  wchar_t* mode);
#elif defined (linux)
#include <stdint.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <net/ethernet.h>
#include <ifaddrs.h>
#include <netinet/ether.h>
#include <linux/if.h>
#include <unistd.h>
#include <uuid/uuid.h>

#define __stdcall
typedef uuid_t  UUID;

typedef unsigned int    __time32_t;
#define _time32    time

#define stricmp strcasecmp
#define __int64 int64_t

FILE* _wfopen(const wchar_t* filename, const  wchar_t* mode);
#endif // _WINDOWS

#include "cipher.h"
#include "bind_request.h"
#include "getHDDSerial.h"
#include "hardwarebind.h"

//#define DEBUG_OUTPUT_ENABLED	TRUE

TECH5_PRODUCTS m_product = TECH5_SDK_CLIENT;
#ifdef DEBUG_OUTPUT_ENABLED
FILE* m_ff = NULL;
#endif // DEBUG_OUTPUT_ENABLED

int Tech5_Hardware_Protect::getAdaptersNames(char adapters_guids[][48])
{

    int cards_count = 0;
    memset(adapters_guids[0],0,48);
#if defined (_WINDOWS) || defined (_WIN32_WCE)
	unsigned int const nbufSize = 512;
	wchar_t szRetStringService[nbufSize] = {0};
	wchar_t szClassPath[nbufSize] = {0};
	HDEVINFO hDevInfo = INVALID_HANDLE_VALUE;
	SP_DEVINFO_DATA DeviceInfoData;
	unsigned int i = 0;

	try
	{
		// ������� HDEVINFO � ��������������� ������������ NET.
		hDevInfo = SetupDiGetClassDevs((LPGUID) &GUID_DEVCLASS_NET,0,0,DIGCF_PRESENT );
		if (hDevInfo == INVALID_HANDLE_VALUE)
		{
#ifdef DEBUG_OUTPUT_ENABLED
			if(m_ff)
				fwrite("Get Devices failed\n",strlen("Get Devices failed\n"),1,m_ff);
#endif // DEBUG_OUTPUT_ENABLED
			throw 0;
		}
		// ����������� ��� ���������� � Set.
		memset(&DeviceInfoData,0,sizeof(DeviceInfoData));
		DeviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);
		for( i = 0; SetupDiEnumDeviceInfo(hDevInfo,i,&DeviceInfoData); i++)
		{
			DWORD DataT = 0;
			DWORD buffersize = nbufSize*sizeof(szClassPath[0]);
			if(!SetupDiGetDeviceRegistryProperty(hDevInfo,&DeviceInfoData,SPDRP_DRIVER,&DataT,(PBYTE)szClassPath,buffersize,&buffersize))
			{
#ifdef DEBUG_OUTPUT_ENABLED
				if(m_ff)
					fwrite("Get Properties failed\n",strlen("Get Properties failed\n"),1,m_ff);
#endif // DEBUG_OUTPUT_ENABLED
				throw 0;
			}
			if( IsHardware(szClassPath,adapters_guids[cards_count]) )
			{
				cards_count++;
			}
		}
	}
	catch(int )
	{
		cards_count = 0;
	}
	catch(...)
	{
#ifdef DEBUG_OUTPUT_ENABLED
		if(m_ff)
			fwrite("Get Names failed\n",strlen("Get Names failed\n"),1,m_ff);
#endif // DEBUG_OUTPUT_ENABLED
		cards_count = 0;
	}
	if(hDevInfo != INVALID_HANDLE_VALUE)
		SetupDiDestroyDeviceInfoList(hDevInfo); //Cleanup
#endif // _WINDOWS
	return cards_count;
}
//-----------------------------------------------------------------------------
bool Tech5_Hardware_Protect::IsHardware(wchar_t*  classname, char* adapters_guid)
{
	bool present = false;
#if defined(_WINDOWS) || defined (_WIN32_WCE)
	DWORD ulCount=0;
	int lRet;
	HKEY rk;
	wchar_t szRegKey[512];
	wchar_t szComponentId[512] = {0};
	DWORD type = REG_SZ;

	try
	{
		wcscpy(szRegKey,L"SYSTEM\\CurrentControlSet\\Control\\Class\\");
		wcscat(szRegKey,classname); // {4D36E972-E325-11CE-BFC1-08002bE10318}\0001
		lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE,szRegKey,0, KEY_READ,&rk);
		if(lRet != ERROR_SUCCESS)
		{
#ifdef DEBUG_OUTPUT_ENABLED
			if(m_ff)
				fwrite("Get Registry failed\n",strlen("Get Registry failed\n"),1,m_ff);
#endif // DEBUG_OUTPUT_ENABLED
			throw 0;
		}

		ulCount = 512*sizeof(szComponentId[0]);
		type = REG_SZ;
		lRet = RegQueryValueEx(rk,L"ComponentId",NULL,&type,(LPBYTE)szComponentId, &ulCount);
		if(lRet != ERROR_SUCCESS)
		{
#ifdef DEBUG_OUTPUT_ENABLED
			if(m_ff)
				fwrite("Get Values failed\n",strlen("Get Values failed\n"),1,m_ff);
#endif // DEBUG_OUTPUT_ENABLED
			throw 0;
		}
		_wcsupr(szComponentId);
		if(wcsstr(szComponentId,L"DEV") == NULL)
		{
			if(wcsstr(szComponentId,L"PCI_") == NULL)
			{
				if(wcsstr(szComponentId,L"&PID_") == NULL)
				{
					if(wcsstr(szComponentId,L"VMBUS") == NULL)
					{
#ifdef DEBUG_OUTPUT_ENABLED
						if(m_ff)
							fwrite("Is not hardware\n",strlen("Is not hardware\n"),1,m_ff);
#endif // DEBUG_OUTPUT_ENABLED
						throw 0;
					}
				}
			}
		}
		else
		{
#ifdef DEBUG_OUTPUT_ENABLED
			if(m_ff)
				fwrite("Is hardware\n",strlen("Is hardware\n"),1,m_ff);
#endif // DEBUG_OUTPUT_ENABLED
		}

		ulCount = 48*sizeof(adapters_guid[0]);
		type = REG_SZ;
		lRet = RegQueryValueExA(rk,"NetCfgInstanceId",NULL,&type,(LPBYTE)adapters_guid,&ulCount);
		if(lRet != ERROR_SUCCESS)
		{
#ifdef DEBUG_OUTPUT_ENABLED
			if(m_ff)
				fwrite("No instnaced\n",strlen("No instanced\n"),1,m_ff);
#endif // DEBUG_OUTPUT_ENABLED
			throw 0;
		}
		present = true;
	}
	catch(int)
	{
		present = false;
	}
	catch(...)
	{
#ifdef DEBUG_OUTPUT_ENABLED
		if(m_ff)
			fwrite("Get Hardware failed\n",strlen("Get Hardware failed\n"),1,m_ff);
#endif // DEBUG_OUTPUT_ENABLED
		present = false;
	}
	if(rk)
		RegCloseKey(rk);
#else
	present = true;
#endif // _WINDOWS
	return present;
}

bool Tech5_Hardware_Protect::getAdapterMACAddress(char address[][_MAC_LENGTH],int& count)
{
	bool status = false;
#if defined(_WINDOWS) || defined(_WIN32_WCE)
	IP_ADAPTER_INFO* adapter_address = NULL;
	char m_network_cards_names[_MAX_ADAPTER_COUNT][_MAC_LENGTH*3];
	int cards_count = 0;
	bool is_physical = false;

	try
	{
		memset(m_network_cards_names,0,_MAC_LENGTH*3*_MAX_ADAPTER_COUNT*sizeof(m_network_cards_names[0][0]));
		count = 0;
		HKEY key_enum;
		char card_number_sub_key[MAX_PATH];
		DWORD card_number_sub_key_size = MAX_PATH;
		if( RegOpenKeyEx(HKEY_LOCAL_MACHINE,L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\NetworkCards",0,KEY_READ,&key_enum) == ERROR_SUCCESS)
		{
			while( RegEnumKeyExA(key_enum,cards_count,card_number_sub_key,&card_number_sub_key_size,NULL,NULL,NULL,NULL) == ERROR_SUCCESS)
			{
				HKEY h_key = NULL;
				if( RegOpenKeyExA(key_enum,card_number_sub_key,0,KEY_READ,&h_key) == ERROR_SUCCESS)
				{
					DWORD type_data = REG_SZ;
					DWORD size_data = _MAC_LENGTH*3*sizeof(m_network_cards_names[0][0]);
					RegQueryValueExA(h_key,"ServiceName",NULL,&type_data,(LPBYTE)m_network_cards_names[cards_count],&size_data);
					RegCloseKey(h_key);
				}
				cards_count++;
				card_number_sub_key_size = MAX_PATH;
			}
			RegCloseKey(key_enum);
		}

		ULONG bufLen = sizeof(IP_ADAPTER_INFO)*10;
		unsigned int res = GetAdaptersInfo(NULL,&bufLen);
		adapter_address = (IP_ADAPTER_INFO*)new unsigned char[bufLen];
		if(adapter_address)
			memset(adapter_address,0,bufLen);
		res = GetAdaptersInfo(adapter_address,&bufLen);
		if(res == ERROR_SUCCESS)
		{
			is_physical = false;
			for(int i = 0; i < cards_count; i++)
			{
				if(stricmp(m_network_cards_names[i],adapter_address->AdapterName) == 0)
				{
					is_physical = true;
					break;
				}
			}
			if(is_physical)
			{
				sprintf(address[count],"%02X",adapter_address->Address[0]);
				int offset = 2;
				for(UINT i = 1; i < adapter_address->AddressLength; i++)
				{
					sprintf((char*)(address[count]+offset),":%02X",adapter_address->Address[i]);
					offset += 3;
				}

				count++;
			}

			PIP_ADAPTER_INFO adapter_info_next = adapter_address->Next;
			while(adapter_info_next)
			{

				is_physical = false;
				for(int i = 0; i < cards_count; i++)
				{
					if(stricmp(m_network_cards_names[i],adapter_info_next->AdapterName) == 0)
					{
						is_physical = true;
						break;
					}
				}
				if(is_physical)
				{
					sprintf(address[count],"%02X",adapter_info_next->Address[0]);
					int offset = 2;
					for(UINT i = 1; i < adapter_info_next->AddressLength; i++)
					{
						sprintf((char*)(address[count]+offset),":%02X",adapter_info_next->Address[i]);
						offset += 3;
					}
					count++;
				}
				adapter_info_next = adapter_info_next->Next;
			}
			status = true;
		}
		else
		{
			sprintf_s(address[count],"%02x:%02x:%02x:%02x:%02x:%02x",
				10,
				10,
				10,
				10,
				10,
				10);
			count++;
			status = true;
		}
	}
	catch(...)
	{
		;
	}
	memset(m_network_cards_names,0,_MAC_LENGTH*3*_MAX_ADAPTER_COUNT*sizeof(m_network_cards_names[0][0]));
	if(adapter_address)
		delete [] adapter_address, adapter_address = NULL;
#else
	count = 0;
	sprintf(address[0],"00:00:00:00");
#endif
	return status;
}

#if defined (linux)
int getMAAC(char* name_of_interface, char* mac_address)
{
    int fd  = -1;
    struct ifreq ifr;
    int success = 0;
    try
    {
        memset(mac_address,0,18);
        fd = socket(AF_INET, SOCK_DGRAM, 0);

        ifr.ifr_addr.sa_family = AF_INET;
        strncpy(ifr.ifr_name, name_of_interface, IFNAMSIZ-1);

        if( ioctl(fd, SIOCGIFHWADDR, &ifr) == 0)
        {
            sprintf(mac_address,"%.2x:%.2x:%.2x:%.2x:%.2x:%.2x",
                    (unsigned char)ifr.ifr_hwaddr.sa_data[0],
         (unsigned char)ifr.ifr_hwaddr.sa_data[1],
         (unsigned char)ifr.ifr_hwaddr.sa_data[2],
         (unsigned char)ifr.ifr_hwaddr.sa_data[3],
         (unsigned char)ifr.ifr_hwaddr.sa_data[4],
         (unsigned char)ifr.ifr_hwaddr.sa_data[5]);
            success = 1;
        }
    }
    catch(...)
    {
        ;
    }
    if(fd != -1)
        close(fd);
    return success;
}
#endif // linux

bool Tech5_Hardware_Protect::getAdapterMACAddress2(char address[][_MAC_LENGTH],int& count)
{
	bool status = false;

#if defined (_WINDOWS) || defined (_WIN32_WCE)
#ifdef DEBUG_OUTPUT_ENABLED
	m_ff = fopen("C:\\TECH5_output.txt","wb");
#endif // DEBUG_OUTPUT_ENABLED

	IP_ADAPTER_INFO* adapter_address = NULL;
	char m_network_cards_names[_MAX_ADAPTER_COUNT][48];
	int cards_count = 0;
	bool is_physical = false;

	try
	{
		count = 0;
		memset(m_network_cards_names,0,48*_MAX_ADAPTER_COUNT*sizeof(m_network_cards_names[0][0]));
		cards_count = getAdaptersNames(m_network_cards_names);
		ULONG bufLen = sizeof(IP_ADAPTER_INFO)*10;
		unsigned int res = GetAdaptersInfo(NULL,&bufLen);
		adapter_address = (IP_ADAPTER_INFO*)new unsigned char[bufLen];
		if(adapter_address)
			memset(adapter_address,0,bufLen);
		res = GetAdaptersInfo(adapter_address,&bufLen);
		if(res == ERROR_SUCCESS)
		{
			is_physical = false;
			for(int i = 0; i < cards_count; i++)
			{
				if(stricmp(m_network_cards_names[i],adapter_address->AdapterName) == 0)
				{
					is_physical = true;
					break;
				}
			}
			if(is_physical)
			{
				sprintf(address[count],"%02X",adapter_address->Address[0]);
				int offset = 2;
				for(UINT i = 1; i < adapter_address->AddressLength; i++)
				{
					sprintf((char*)(address[count]+offset),":%02X",adapter_address->Address[i]);
					offset += 3;
				}

				count++;
			}

			PIP_ADAPTER_INFO adapter_info_next = adapter_address->Next;
			while(adapter_info_next)
			{

				is_physical = false;
				for(int i = 0; i < cards_count; i++)
				{
					if(stricmp(m_network_cards_names[i],adapter_info_next->AdapterName) == 0)
					{
						is_physical = true;
						break;
					}
				}
				if(is_physical)
				{
					sprintf(address[count],"%02X",adapter_info_next->Address[0]);
					int offset = 2;
					for(UINT i = 1; i < adapter_info_next->AddressLength; i++)
					{
						sprintf((char*)(address[count]+offset),":%02X",adapter_info_next->Address[i]);
						offset += 3;
					}
					count++;
				}
				adapter_info_next = adapter_info_next->Next;
			}
			status = true;
		}
		else
		{
			sprintf_s(address[count],"%02X:%02X:%02X:%02X:%02X:%02X",
				10,
				10,
				10,
				10,
				10,
				10);
			count++;
			status = true;
		}
	}
	catch(...)
	{
		;
	}
#ifdef DEBUG_OUTPUT_ENABLED
	if(m_ff)
		fclose(m_ff); m_ff = NULL;
#endif // DEBUG_OUTPUT_ENABLED

	memset(m_network_cards_names,0,48*_MAX_ADAPTER_COUNT*sizeof(m_network_cards_names[0][0]));
	if(adapter_address)
		delete [] adapter_address, adapter_address = NULL;
#elif defined ANDROID
   status = false;
#elif defined (linux)
    count = 0;
	struct ifaddrs *ifa = NULL, *ifap = NULL;
    if(getifaddrs(&ifap) < 0)
        status = false;
	else
	{
		for(ifa = ifap; ifa; ifa = ifa->ifa_next)
		{
			if (! (ifa->ifa_flags & IFF_LOOPBACK))
			{
				if(ifa->ifa_addr->sa_family == AF_PACKET)
				{
					if(getMAAC(ifa->ifa_name,address[count]))
					{
						count++;
	//                    printf("For interface %s MAC-address is %s\n",ifa->ifa_name,address);
					}
				}
			}
		}
		status = true;
		freeifaddrs(ifap);
	}
#endif // _WINDOWS
	return status;
}

Tech5_Hardware_Protect::Tech5_Hardware_Protect(TECH5_PRODUCTS product_id)
{
	m_adapters_count = 0;
	memset(m_serial_number,0,_MAX_SERIAL_COUNT*sizeof(m_serial_number[0]));
	memset(macAddress,0,_MAC_LENGTH*_MAX_ADAPTER_COUNT*sizeof(macAddress[0][0]));
	getHDDSerialByNumber(0,m_serial_number);
	getAdapterMACAddress2(macAddress,m_adapters_count);
	m_product = product_id;
	m_additional_data = 0;
	m_additional_data_length = 0;
	m_instance_for_count_request = 4;
	m_instance = 0;
	m_instance_guid = 0;
	m_memory_file = 0;
	m_memory_file_length = 0;
}

Tech5_Hardware_Protect::~Tech5_Hardware_Protect()
{
	memset(m_serial_number,0,_MAX_SERIAL_COUNT*sizeof(m_serial_number[0]));
	for (int i = 0; i < _MAX_ADAPTER_COUNT; i++)
		memset(macAddress[i],0,_MAC_LENGTH*sizeof(macAddress[0][0]));
	m_adapters_count = 0;
	m_instance = 0;
	m_additional_data_length = 0;
	if(m_additional_data)
		delete[] m_additional_data, m_additional_data = NULL;
	if(m_instance_guid)
		delete[] m_instance_guid, m_instance_guid = NULL;
	if(m_memory_file)
		delete[] m_memory_file, m_memory_file = 0;
	m_memory_file_length = 0;
}


bool Tech5_Hardware_Protect::create_request_file(wchar_t *request_filename, bool is_trial)
{
#ifndef ANDROID
	bool status  = false;
	char *cryptAddress = NULL;
	FILE *fff = NULL;
	__time32_t	m_pass = 0;
	int max_file_size = 1024;
	char *m_crypto_buffer = NULL;
	try
	{
//		snd_ulong length = 0;
		m_pass = _time32(NULL);
		cryptAddress = new char[_MAC_LENGTH*_MAX_ADAPTER_COUNT];
		if(!cryptAddress)
			throw L"";
		memset(cryptAddress,0,_MAC_LENGTH*_MAX_ADAPTER_COUNT);
		__int64 macCount_l = 0;
		fff = _wfopen(request_filename,L"w+b");
		if(fff == NULL)
			throw L"";

		snd_ulong temp_p = m_pass;
//		WORD temp_p = LOWORD(m_pass);
		fwrite(&temp_p,1,sizeof(temp_p),fff); // len == 8

		snd_ulong len = 0;
		snd_ulong password = encrypt_mac_address_count[m_product];
		BYTE ideal[32];
		macCount_l = m_adapters_count;
		CAPIEncryptString((char*)&macCount_l,sizeof(macCount_l),(char*)&password,sizeof(password),(char*)ideal,&len);
		fwrite(ideal,1,len,fff); // len == 8
		CAPIEncryptString(macAddress[0],_MAC_LENGTH*_MAX_ADAPTER_COUNT,(char*)&password,sizeof(password),cryptAddress,&len);
		fwrite(cryptAddress,1,len,fff); // len == 204
		memset(ideal,0,32);
		srand( (unsigned)time( NULL ) );
		int random = rand();
		memcpy(ideal + 24,&random,sizeof(random));
		password = encrypt_hdd[m_product];
		CAPIEncryptString((char*)m_serial_number,_MAX_SERIAL_COUNT,(char*)&password,sizeof(password),(char*)ideal,&len);
		fwrite(ideal,1,32,fff);
		int len_file = ftell(fff);
		m_crypto_buffer = new char[max_file_size];
		rewind(fff);
		fread(m_crypto_buffer,1,sizeof(temp_p),fff);
		fread(m_crypto_buffer,1,len_file-sizeof(temp_p),fff);
		CAPIEncryptData((unsigned char*)m_crypto_buffer,len_file-sizeof(temp_p),(char*)&temp_p,sizeof(temp_p));
		fseek(fff,sizeof(temp_p),SEEK_SET);
		fwrite(m_crypto_buffer,1,len_file-sizeof(temp_p),fff);
		if(is_trial)
			fwrite("rial",1,strlen("rial"),fff);
		else
			fwrite("real",1,strlen("real"),fff);
		status = true;
	}
	catch( int /*code*/)
	{
		;
	}
	catch( wchar_t* /*text*/)
	{
		;
	}
	catch(...)
	{
		;
	}
	if(fff)
		fclose(fff); fff = NULL;
	if(m_crypto_buffer)
	{
		memset(m_crypto_buffer,0,max_file_size);
		delete [] m_crypto_buffer, m_crypto_buffer = NULL;
	}
	if(cryptAddress)
		delete [] cryptAddress, cryptAddress = NULL;
	return status;
#else
   return true;
#endif // ANDROID
}

bool Tech5_Hardware_Protect::initLicense(wchar_t* license_filename)
{
#ifdef ANDROID
   return true;
#else

	FILE* m_ff = 0;
	bool retVal = false;
	try
	{
		m_ff = _wfopen(license_filename,L"rb");
      if (!m_ff)
         return false;
		fseek(m_ff,0,SEEK_END);
		m_memory_file_length = ftell(m_ff);
		if(m_memory_file)
			delete[] m_memory_file;
		m_memory_file = new unsigned char[m_memory_file_length];
		memset(m_memory_file,0,m_memory_file_length*sizeof(unsigned char));
		fseek(m_ff,0,SEEK_SET);
		fread(m_memory_file,1,m_memory_file_length,m_ff);
		retVal = true;
	}
	catch(...)
	{
	}
	if(m_ff)
		fclose(m_ff); m_ff = 0;
	return retVal;
#endif // ANDROID

}

bool Tech5_Hardware_Protect::parseLicense(bool is_trial)
{
#ifdef ANDROID
   return true;
#else

	bool status = false;
	snd_uchar *bufferok = NULL;
	__int64 macCount = 0;
	snd_ulong destLen = 0;
	snd_ulong password = encrypt_answer[m_product];
	int	error_stage = 0;

	char encryptedAddress[_MAX_ADAPTER_COUNT][_MAC_LENGTH];
	char cryptAddress[_MAX_ADAPTER_COUNT][_MAC_LENGTH];
	bool found[1+_MAX_ADAPTER_COUNT];

	if( !m_memory_file)
		return false;

	snd_ulong file_offset = 0;

	try
	{
		for(int i = 0; i < _MAX_ADAPTER_COUNT; i++)
		{
			memset(encryptedAddress[i],0,_MAC_LENGTH);
			memset(cryptAddress[i],0,_MAC_LENGTH);
		}

		for(int i = 0; i < 1+_MAX_ADAPTER_COUNT; i++)
			found[i] = false;

		if(m_memory_file_length > 0)
		{
			bufferok = new snd_uchar[m_memory_file_length];
                        memset(bufferok,0,m_memory_file_length);
			memcpy(bufferok,m_memory_file+file_offset,sizeof(__int64));
			file_offset += sizeof(__int64);
			destLen = 0;
			error_stage = 1;
			CAPIDecryptString((char*)bufferok,sizeof(__int64),(char*)&password,sizeof(password),(char*)&macCount,&destLen);
			if(macCount > _MAX_ADAPTER_COUNT || macCount < 0)
				throw error_stage;
			memcpy(cryptAddress,m_memory_file+file_offset,(size_t)(_MAC_LENGTH*macCount));
			file_offset += (snd_ulong)(_MAC_LENGTH*macCount);
			CAPIDecryptString((char*)cryptAddress,_MAC_LENGTH*((snd_ulong)macCount),(char*)&password,sizeof(password),(char*)encryptedAddress,&destLen);
		}
		else
		{
			error_stage = 0;
			throw error_stage;
		}

		char serial_hdd[_MAX_SERIAL_COUNT+4];
		password = encrypt_answer[m_product];
		error_stage = 2;
		memcpy(bufferok,m_memory_file+file_offset,_MAX_SERIAL_COUNT+4);
		file_offset += _MAX_SERIAL_COUNT+4;

		CAPIDecryptString((char*)bufferok,_MAX_SERIAL_COUNT+4,(char*)&password,sizeof(password),(char*)serial_hdd,&destLen);
		error_stage = 3;
		m_serial_number[8] = '\0';
		serial_hdd[8] = '\0';
#if defined (_WINDOWS) || defined (_WIN32_WCE)
		if(stricmp(m_serial_number,serial_hdd) == 0)
		{
#endif // _WINDOWS
			found[0]=true;
#if defined (_WINDOWS) || defined (_WIN32_WCE)
		}
		else
			error_stage = 4;
#endif // _WINDOWS

		for(int i = 0; i < _MAX_ADAPTER_COUNT; i++)
		{
			encryptedAddress[i][17] = '\0';
			macAddress[i][17] = '\0';
		}
		for(int i = 0; i < m_adapters_count; i++)
		{
			for( int j = 0; j < macCount; j++)
			{
				if(stricmp(encryptedAddress[j],macAddress[i]) == 0)
				{
					found[i+1] = true;
				}
			}
		}
		password = 0;
		for( int i = 0; i < (_MAX_ADAPTER_COUNT+1); i++)
		{
			if(found[i])
				password++;
		}
		if(password < 2)
		{
			status = false;
		}
		else
		{
			status =  true;
			__time32_t end_trial;
			memcpy(&end_trial,m_memory_file+file_offset,sizeof(end_trial));
			file_offset += sizeof(end_trial);
			bool trial_is = false;
			memcpy(&trial_is,m_memory_file+file_offset,sizeof(trial_is));
			file_offset += sizeof(trial_is);
			if(is_trial)
			{
				if(trial_is == is_trial)
					status = true;
				else
					status = false;
			}
			else
			{
				status = true;
			}
		}
		if(status)
		{
                        int uuid_size = sizeof(UUID)*2+4;

			unsigned short* uuid_str = 0;
                        int type_wchar_t_size = sizeof(uuid_str[0]);
                        
                        snd_ulong uuid_read_size = file_offset + uuid_size*type_wchar_t_size;
			if( m_memory_file_length >=  uuid_read_size)
			{
                            uuid_str = new unsigned short[ uuid_size +1 ];
                            memset(uuid_str,0,(uuid_size + 1)*type_wchar_t_size);
                            
                            memcpy(uuid_str,m_memory_file+file_offset,uuid_size*type_wchar_t_size);
                            file_offset += uuid_size*type_wchar_t_size;
                            
                            if(m_instance_guid == NULL)
                                m_instance_guid = new wchar_t[uuid_size +1 ];
                            memset(m_instance_guid,0,(uuid_size+1)*sizeof(wchar_t));
                            for(int i = 0; i < uuid_size; i++)
                                m_instance_guid[i] = (wchar_t)uuid_str[i];
			}
                        if(uuid_str)
                            delete[] uuid_str, uuid_str = 0;

			int inst_count = 0;
			memcpy(&inst_count,m_memory_file+file_offset,sizeof(inst_count));
			file_offset += sizeof(inst_count);

			this->m_instance = inst_count;

			long size_add = 0;
			
			if( m_memory_file_length >= (file_offset + sizeof(size_add)))
			{
				memcpy(&size_add,m_memory_file+file_offset,sizeof(size_add));
				file_offset += sizeof(size_add);

				password = encrypt_answer[m_product];
				CAPIDecryptData((snd_uchar*)&size_add,sizeof(size_add),(char*)&password,sizeof(password));
				if(size_add < 10*1024*1024)
				{
					snd_uchar* temp_buf = 0;
					temp_buf = new snd_uchar[size_add];
					memcpy(temp_buf,m_memory_file+file_offset,size_add);
					file_offset += size_add;
					
					m_additional_data_length = (unsigned long)size_add;
					if(m_additional_data != NULL)
						delete[] m_additional_data;
					m_additional_data = new unsigned char[m_additional_data_length];
					memcpy(m_additional_data,temp_buf,m_additional_data_length);
					memset(temp_buf,0,size_add);
                                        if( temp_buf)
                                            delete[] temp_buf, temp_buf = 0;
				}
				password = 0;
			}
		}
	}
	catch(int )
	{
		status = false;
	}
	catch(...)
	{
		status = false;
	}
	if(bufferok)
		delete[] bufferok, bufferok = 0;
	return status;
#endif // ANDROID
}

bool Tech5_Hardware_Protect::check_protect(bool is_trial)
{
#ifndef ANDROID

	bool status = false;
	snd_uchar *bufferok = NULL;
	__int64 macCount = 0;
	snd_ulong destLen = 0;
	snd_ulong password = encrypt_answer[m_product];
	int	error_stage = 0;

	char encryptedAddress[_MAX_ADAPTER_COUNT][_MAC_LENGTH];
	char cryptAddress[_MAX_ADAPTER_COUNT][_MAC_LENGTH];
	bool found[1+_MAX_ADAPTER_COUNT];

	if( !m_memory_file)
		return false;

	snd_ulong file_offset = 0;

	try
	{
		for(int i = 0; i < _MAX_ADAPTER_COUNT; i++)
		{
			memset(encryptedAddress[i],0,_MAC_LENGTH);
			memset(cryptAddress[i],0,_MAC_LENGTH);
		}

		for(int i = 0; i < 1+_MAX_ADAPTER_COUNT; i++)
			found[i] = false;

		if(m_memory_file_length > 0)
		{
			bufferok = new snd_uchar[m_memory_file_length];
                        memset(bufferok,0,m_memory_file_length);
//			fread(bufferok,1,sizeof(__int64),fff);
			memcpy(bufferok,m_memory_file+file_offset,sizeof(__int64));
			file_offset += sizeof(__int64);
			destLen = 0;
			error_stage = 1;
			CAPIDecryptString((char*)bufferok,sizeof(__int64),(char*)&password,sizeof(password),(char*)&macCount,&destLen);
			if(macCount > _MAX_ADAPTER_COUNT || macCount < 0)
				throw error_stage;
//			fread(cryptAddress,1,_MAC_LENGTH*a2,fff);
			memcpy(cryptAddress,m_memory_file+file_offset,(size_t)(_MAC_LENGTH*macCount));
			file_offset += (snd_ulong)(_MAC_LENGTH*macCount);
			CAPIDecryptString((char*)cryptAddress,_MAC_LENGTH*((snd_ulong)macCount),(char*)&password,sizeof(password),(char*)encryptedAddress,&destLen);
		}
		else
		{
			error_stage = 0;
			throw error_stage;
		}
		char serial_hdd[_MAX_SERIAL_COUNT+4];
		password = encrypt_answer[m_product];
		error_stage = 2;
//		fread(bufferok,1,_MAX_SERIAL_COUNT+4,fff);
		memcpy(bufferok,m_memory_file+file_offset,_MAX_SERIAL_COUNT+4);
		file_offset += _MAX_SERIAL_COUNT+4;

		CAPIDecryptString((char*)bufferok,_MAX_SERIAL_COUNT+4,(char*)&password,sizeof(password),(char*)serial_hdd,&destLen);
		error_stage = 3;
		m_serial_number[8] = '\0';
		serial_hdd[8] = '\0';
#if defined (_WINDOWS) || defined (_WIN32_WCE)
		if(stricmp(m_serial_number,serial_hdd) == 0)
		{
#endif // _WINDOWS
			found[0]=true;
#if defined (_WINDOWS) || defined (_WIN32_WCE)
		}
		else
			error_stage = 4;
#endif // _WINDOWS

		for(int i = 0; i < _MAX_ADAPTER_COUNT; i++)
		{
			encryptedAddress[i][17] = '\0';
			macAddress[i][17] = '\0';
		}
		for(int i = 0; i < m_adapters_count; i++)
		{
			for( int j = 0; j < macCount; j++)
			{
				if(stricmp(encryptedAddress[j],macAddress[i]) == 0)
				{
					found[i+1] = true;
				}
			}
		}
		password = 0;
		for( int i = 0; i < (_MAX_ADAPTER_COUNT+1); i++)
		{
			if(found[i])
				password++;
		}
		if(password < 2)
		{
			status = false;
		}
		else
		{
			status =  true;
			__time32_t end_trial;
//			fread(&end_trial,1,sizeof(__time32_t),fff);
			memcpy(&end_trial,m_memory_file+file_offset,sizeof(end_trial));
			file_offset += sizeof(end_trial);
//			long po_cur = ftell(fff);
			bool trial_is = false;
//			fread(&trial_is,1,sizeof(trial_is),fff);
			memcpy(&trial_is,m_memory_file+file_offset,sizeof(trial_is));
			file_offset += sizeof(trial_is);
			if(is_trial)
			{
				if(trial_is == is_trial)
					status = true;
				else
					status = false;
			}
			else
			{
				status = true;
			}
		}
	}
	catch(int )
	{
		status = false;
	}
	catch(...)
	{
		status = false;
	}
	if(bufferok)
		delete[] bufferok, bufferok = NULL;
	return status;
#else
return true;
#endif // !ANDROID
}

/*
bool Tech5_Hardware_Protect::check_protect(const wchar_t* answer_filename, bool is_trial)
{
	bool status = false;
	BYTE *bufferok = NULL;
	__int64 a2 = 0;
	snd_ulong destLen = 0;
	snd_ulong password = encrypt_answer[m_product];
	snd_ulong lengthFilename = 0;
	FILE *fff = NULL;
	int	error_stage = 0;

	char encryptedAddress[_MAX_ADAPTER_COUNT][_MAC_LENGTH];
	char cryptAddress[_MAX_ADAPTER_COUNT][_MAC_LENGTH];
	bool found[1+_MAX_ADAPTER_COUNT];
	int macCountFound = 0;

	try
	{
		for(int i = 0; i < _MAX_ADAPTER_COUNT; i++)
		{
			memset(encryptedAddress[i],0,_MAC_LENGTH);
			memset(cryptAddress[i],0,_MAC_LENGTH);
		}

		for(int i = 0; i < 1+_MAX_ADAPTER_COUNT; i++)
			found[i] = false;
		setlocale(LC_ALL,"");
		fff = _wfopen(answer_filename,L"rb");
		if(fff)
		{
			bufferok = new BYTE[128]; memset(bufferok,0,128);
			fread(bufferok,1,sizeof(__int64),fff);
			destLen = 0;
			error_stage = 1;
			CAPIDecryptString((char*)bufferok,sizeof(__int64),(char*)&password,sizeof(password),(char*)&a2,&destLen);
			if(a2 > _MAX_ADAPTER_COUNT || a2 < 0)
				throw error_stage;
			fread(cryptAddress,1,_MAC_LENGTH*a2,fff);
			CAPIDecryptString((char*)cryptAddress,_MAC_LENGTH*((snd_ulong)a2),(char*)&password,sizeof(password),(char*)encryptedAddress,&destLen);
		}
		else
		{
			error_stage = 0;
			throw error_stage;
		}
		char serial_hdd[_MAX_SERIAL_COUNT+4];
		password = encrypt_answer[m_product];
		error_stage = 2;
		fread(bufferok,1,_MAX_SERIAL_COUNT+4,fff);
		CAPIDecryptString((char*)bufferok,_MAX_SERIAL_COUNT+4,(char*)&password,sizeof(password),(char*)serial_hdd,&destLen);
		error_stage = 3;
		m_serial_number[8] = '\0';
		serial_hdd[8] = '\0';
		if(stricmp(m_serial_number,serial_hdd) == 0)
		{
			found[0]=true;
		}
		else
			error_stage = 4;

		for(int i = 0; i < _MAX_ADAPTER_COUNT; i++)
		{
			encryptedAddress[i][17] = '\0';
			macAddress[i][17] = '\0';
		}
		for(int i = 0; i < m_adapters_count; i++)
		{
			for( int j = 0; j < a2; j++)
			{
				if(stricmp(encryptedAddress[j],macAddress[i]) == 0)
				{
					found[i+1] = true;
				}
			}
		}
		password = 0;
		for( int i = 0; i < (_MAX_ADAPTER_COUNT+1); i++)
		{
			if(found[i])
				password++;
		}
		if(password < 2)
		{
			status = false;
		}
		else
		{
			status =  true;
			__time32_t end_trial;
			fread(&end_trial,1,sizeof(__time32_t),fff);
			long po_cur = ftell(fff);
			bool trial_is = false;
			fread(&trial_is,1,sizeof(trial_is),fff);
			if(is_trial)
			{
				if(trial_is == is_trial)
					status = true;
				else
					status = false;
			}
			else
			{
				status = true;
			}
		}
		if(status)
		{
			wchar_t* uuid_str = new wchar_t[ sizeof(UUID)*2+4+1 ];
			memset(uuid_str,0,(sizeof(UUID)*2+4+1)*sizeof(wchar_t));
			if( fread(uuid_str,1,(sizeof(UUID)*2+4)*sizeof(uuid_str[0]),fff) > 0)
			{
				if(m_instance_guid == NULL)
					m_instance_guid = new wchar_t[ sizeof(UUID)*2+4+1 ];
				memset(m_instance_guid,0,(sizeof(UUID)*2+4+1)*sizeof(wchar_t));
				wcsncpy(m_instance_guid,uuid_str,sizeof(UUID)*2+4);
				delete[] uuid_str;
			}
			int inst_count = 0;
			fread(&inst_count,1,sizeof(inst_count),fff);

			this->m_instance = inst_count;

			long size_add = 0;
			if(fread(&size_add,1,sizeof(size_add),fff) == sizeof(size_add))
			{
				password = encrypt_answer[m_product];
				CAPIDecryptData((snd_uchar*)&size_add,sizeof(size_add),(char*)&password,sizeof(password));
				if(size_add < 10*1024*1024)
				{
					snd_uchar* temp_buf = NULL;
					temp_buf = new snd_uchar[size_add];
					fread(temp_buf,1,size_add,fff);
//					CAPIDecryptData(temp_buf,size_add,(snd_char*)&password,sizeof(password));
					
					m_additional_data_length = (unsigned long)size_add;
					if(m_additional_data != NULL)
						delete[] m_additional_data;
					m_additional_data = new unsigned char[m_additional_data_length];
					memcpy(m_additional_data,temp_buf,m_additional_data_length);
					memset(temp_buf,0,size_add);
					delete[] temp_buf; temp_buf = 0;
				}
				password = 0;
			}
		}
	}
	catch(int err)
	{
		status = false;
	}
	catch(...)
	{
		status = false;
	}
	if(fff)
		fclose(fff);	fff = NULL;
	if(bufferok)
	{
		delete bufferok;
		bufferok = NULL;
	}
	return status;
}
*/

void Tech5_Hardware_Protect::getAdditionalBuffer(unsigned char* addBuffer)
{
	try
	{
		if( (m_additional_data_length != 0) && (m_additional_data != NULL))
		{
			unsigned int password = encrypt_answer[m_product];
			memcpy(addBuffer,m_additional_data,m_additional_data_length);
			CAPIDecryptData(addBuffer,m_additional_data_length,(snd_char*)&password,sizeof(password));
			password = 0;
		}
	}
	catch(...)
	{
	}
}

#if defined( _WIN32_WCE ) || defined (_WINDOWS)
#else
FILE* _wfopen(const wchar_t* filename,const  wchar_t* mode)
{
    char* m_path = NULL;
    char* m_mode = NULL;
    FILE* m_file = NULL;
    size_t m_size = 0;

    try
    {
		m_size = wcstombs(NULL,filename,0);
		m_path = new char[m_size+1];
		memset(m_path,0,m_size+1);
		wcstombs(m_path,filename,m_size);
		m_size = wcstombs(NULL,mode,0);
		m_mode = new char[m_size+1];
		memset(m_mode,0,m_size+1);
		wcstombs(m_mode,mode,m_size);
		m_file = fopen(m_path,m_mode);
    }
    catch(...)
    {
		m_file = NULL;
    }
    if(m_path)
		delete[] m_path, m_path = 0;
	if(m_mode)
		delete[] m_mode, m_mode = 0;
    return m_file;
}

#endif // _WINDOWS
