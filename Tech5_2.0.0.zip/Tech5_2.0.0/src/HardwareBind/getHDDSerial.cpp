
#include <stdlib.h>
#include <stdio.h>
#include "getHDDSerial.h"

//  Max number of drives assuming primary/secondary, master/slave topology
#define  IDENTIFY_BUFFER_SIZE  512
#define  IDE_ATA_IDENTIFY    0xEC  //  Returns ID sector for ATA.
#define  MAX_IDE_DRIVES			4
#define  MAX_DISCS_ON_DRIVES	1

//unsigned char signature[8] = {'S','C','S','I','D','I','S','K'};
unsigned char signature[8] = {83,67,83,73,68,73,83,75};

#if defined (_WINDOWS) || defined (_WIN32)
#include <windows.h>

//  IOCTL commands

#define  FILE_DEVICE_SCSI              0x0000001b
#define  IOCTL_SCSI_MINIPORT_IDENTIFY  ((FILE_DEVICE_SCSI << 16) + 0x0501)
#define  IOCTL_SCSI_MINIPORT 0x0004D008  //  see NTDDSCSI.H for definition

// The following struct defines the interesting part of the IDENTIFY
// buffer:
typedef struct _IDSECTOR
{
	USHORT  wGenConfig;
	USHORT  wNumCyls;
	USHORT  wReserved;
	USHORT  wNumHeads;
	USHORT  wBytesPerTrack;
	USHORT  wBytesPerSector;
	USHORT  wSectorsPerTrack;
	USHORT  wVendorUnique[3];
	CHAR    sSerialNumber[MAX_SERIAL_COUNT];
	USHORT  wBufferType;
	USHORT  wBufferSize;
	USHORT  wECCSize;
	CHAR    sFirmwareRev[8];
	CHAR    sModelNumber[40];
	USHORT  wMoreVendorUnique;
	USHORT  wDoubleWordIO;
	USHORT  wCapabilities;
	USHORT  wReserved1;
	USHORT  wPIOTiming;
	USHORT  wDMATiming;
	USHORT  wBS;
	USHORT  wNumCurrentCyls;
	USHORT  wNumCurrentHeads;
	USHORT  wNumCurrentSectorsPerTrack;
	ULONG   ulCurrentSectorCapacity;
	USHORT  wMultSectorStuff;
	ULONG   ulTotalAddressableSectors;
	USHORT  wSingleWordDMA;
	USHORT  wMultiWordDMA;
	BYTE    bReserved[128];
} IDSECTOR, *PIDSECTOR;


typedef struct _SRB_IO_CONTROL
{
	ULONG HeaderLength;
	UCHAR Signature[8];
	ULONG Timeout;
	ULONG ControlCode;
	ULONG ReturnCode;
	ULONG Length;
} SRB_IO_CONTROL, *PSRB_IO_CONTROL;

//  IDE registers
/*
typedef struct _IDEREGS
{
	BYTE bFeaturesReg;       // Used for specifying SMART "commands".
	BYTE bSectorCountReg;    // IDE sector count register
	BYTE bSectorNumberReg;   // IDE sector number register
	BYTE bCylLowReg;         // IDE low order cylinder value
	BYTE bCylHighReg;        // IDE high order cylinder value
	BYTE bDriveHeadReg;      // IDE drive/head register
	BYTE bCommandReg;        // Actual IDE command.
	BYTE bReserved;          // reserved for future use.  Must be zero.
} IDEREGS, *PIDEREGS, *LPIDEREGS;

//  SENDCMDINPARAMS contains the input parameters for the 
//  Send Command to Drive function.
typedef struct _SENDCMDINPARAMS
{
	DWORD     cBufferSize;   //  Buffer size in bytes
	IDEREGS   irDriveRegs;   //  Structure with drive register values.
	BYTE bDriveNumber;       //  Physical drive number to send 
	//  command to (0,1,2,3).
	BYTE bReserved[3];       //  Reserved for future expansion.
	DWORD     dwReserved[4]; //  For future use.
	BYTE      bBuffer[1];    //  Input buffer.
} SENDCMDINPARAMS, *PSENDCMDINPARAMS, *LPSENDCMDINPARAMS;

// Status returned from driver
typedef struct _DRIVERSTATUS
{
	BYTE  bDriverError;  //  Error code from driver, or 0 if no error.
	BYTE  bIDEStatus;    //  Contents of IDE Error register.
	//  Only valid when bDriverError is SMART_IDE_ERROR.
	BYTE  bReserved[2];  //  Reserved for future expansion.
	DWORD  dwReserved[2];  //  Reserved for future expansion.
} DRIVERSTATUS, *PDRIVERSTATUS, *LPDRIVERSTATUS;


// Structure returned by PhysicalDrive IOCTL for several commands
typedef struct _SENDCMDOUTPARAMS
{
	DWORD         cBufferSize;   //  Size of bBuffer in bytes
	DRIVERSTATUS  DriverStatus;  //  Driver status structure.
	BYTE          bBuffer[1];    //  Buffer of arbitrary length in which to store the data read from the                                                       // drive.
} SENDCMDOUTPARAMS, *PSENDCMDOUTPARAMS, *LPSENDCMDOUTPARAMS;

*/
#define  SENDIDLENGTH  sizeof (SENDCMDOUTPARAMS) + IDENTIFY_BUFFER_SIZE

bool getSerial(const wchar_t* driveName, char serial[MAX_SERIAL_COUNT])
{
	HANDLE hScsiDriveIOCTL = NULL;
	bool retVal = false;

	try
	{
		hScsiDriveIOCTL = CreateFile (driveName,
			GENERIC_READ | GENERIC_WRITE, 
			FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
			OPEN_EXISTING, 0, NULL);

		if (hScsiDriveIOCTL == INVALID_HANDLE_VALUE)
		{
			hScsiDriveIOCTL = NULL;
			return 0;
		}
		char buffer [sizeof (SRB_IO_CONTROL) + SENDIDLENGTH];
		SRB_IO_CONTROL *p = (SRB_IO_CONTROL *) buffer;
		SENDCMDINPARAMS *pin = (SENDCMDINPARAMS *) (buffer + sizeof (SRB_IO_CONTROL));
		unsigned long dummy = 0;

		memset (buffer, 0, sizeof (buffer));
		p -> HeaderLength = sizeof (SRB_IO_CONTROL);
		p -> Timeout = 10000;
		p -> Length = SENDIDLENGTH;
		p -> ControlCode = IOCTL_SCSI_MINIPORT_IDENTIFY;
		memcpy(p->Signature,signature,8);

		pin -> irDriveRegs.bCommandReg = IDE_ATA_IDENTIFY;
		pin -> bDriveNumber = 0;

		if (DeviceIoControl(	hScsiDriveIOCTL, IOCTL_SCSI_MINIPORT, 
								buffer,
								sizeof (SRB_IO_CONTROL) +
								sizeof (SENDCMDINPARAMS) - 1,
								buffer,
								sizeof (SRB_IO_CONTROL) + SENDIDLENGTH,
								&dummy, NULL))
		{
			SENDCMDOUTPARAMS *pOut = (SENDCMDOUTPARAMS *) (buffer + sizeof (SRB_IO_CONTROL));
			IDSECTOR *pId = (IDSECTOR *) (pOut -> bBuffer);
			if (pId -> sModelNumber [0])
			{
				retVal = true;
				for(int i = 0; i < MAX_SERIAL_COUNT;)
				{
					serial[i] = pId->sSerialNumber[i+1];
					serial[i+1] = pId->sSerialNumber[i];
					if(serial[i] == ' ')
					{
						serial[i] = 0;
						serial[i+1] = 0;
						break;
					}
					i += 2;
				}
			}
		}
	}
	catch(...)
	{
		retVal = false;
	}
	if(hScsiDriveIOCTL != NULL)
		CloseHandle (hScsiDriveIOCTL);
	return retVal;
}

#endif // _WINDOWS

int  modificator getAllHDDSerial (char	serials[MAX_IDE_DRIVES*MAX_DISCS_ON_DRIVES][MAX_SERIAL_COUNT])
{
#ifdef WIN32
	OSVERSIONINFO ovx;
	memset(&ovx,0,sizeof(OSVERSIONINFO));
	ovx.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	if( !GetVersionEx(&ovx) )
		return 0;
	if( (ovx.dwMajorVersion == 4) || (ovx.dwMajorVersion == 5) )
	{
		int count = 0;
		wchar_t   driveName [256];
		for (int i = 0; i < MAX_IDE_DRIVES; i++)
		{
			wsprintf (driveName, L"\\\\.\\SCSI%d:", i);
			if( getSerial(driveName,serials[count]) )
				count++;
		}
		return count;
	}
	else if(ovx.dwMajorVersion == 6)
	{
		return 0;
	}
	else
		return 0;
#else
	return 0;
#endif
}

int  modificator getHDDSerialByLetter (char* disk_letter, char	serial[MAX_SERIAL_COUNT])
{
#ifdef WIN32
	OSVERSIONINFO ovx;
	memset(&ovx,0,sizeof(OSVERSIONINFO));
	ovx.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	if( !GetVersionEx(&ovx) )
		return 0;
	if( (ovx.dwMajorVersion == 4) || (ovx.dwMajorVersion == 5) )
	{
		wchar_t   driveName [MAX_PATH];
		wsprintf (driveName, L"\\\\.\\%C:", disk_letter[0]);
		if( getSerial(driveName,serial) )
			return 1;
		else
			return 0;
	}
	else if(ovx.dwMajorVersion == 6)
	{
		return 0;
	}
	else
		return 0;
#else
	for(int i=0; i < MAX_SERIAL_COUNT; i++)
		serial[i] = 0;
	return 0;
#endif
}

int  modificator getHDDSerialByNumber (int disk_physical_number, char	serial[MAX_SERIAL_COUNT])
{
/*
#ifdef WIN32
	OSVERSIONINFO ovx;
	memset(&ovx,0,sizeof(OSVERSIONINFO));
	ovx.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	if( !GetVersionEx(&ovx) )
		return 0;
	if( (ovx.dwMajorVersion == 4) || (ovx.dwMajorVersion == 5) )
	{
		wchar_t   driveName [MAX_PATH];
//		wsprintf (driveName, L"\\\\.\\PhysicalDrive%d",disk_physical_number);
		wsprintf (driveName, L"\\\\.\\SCSI%d:",disk_physical_number);
		if( getSerial(driveName,serial) )
			return 1;
		else
			return 0;
	}
	else if(ovx.dwMajorVersion == 6)
	{
		return 0;
	}
	else
		return 0;
#else
	return 0;
#endif
*/
	try
	{
#if defined (_WINDOWS) || defined (_WIN32)
		DWORD serial_num = 0;
		memset(serial,0,MAX_SERIAL_COUNT*sizeof(serial[0]));
		GetVolumeInformation(L"C:\\",NULL,0,&serial_num,NULL,NULL,NULL,0);
//		sprintf(serial,"%X",(char*)serial_num);
		sprintf_s(serial,MAX_SERIAL_COUNT*sizeof(serial[0]),"%X",(char*)serial_num);
#else
    for(int i=0; i < MAX_SERIAL_COUNT; i++)
        serial[i] = 0;
#endif
	}
	catch(...)
	{
	}
	return 0;
}