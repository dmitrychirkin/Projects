#include "ti.h"
#include "fpTemplate.h"


Ti::Ti()
{
   m_templ = new FpTemplate;
}


Ti::~Ti()
{
   if (m_templ)
   {
      delete m_templ;
      m_templ = NULL;
   }
}

int Ti::getMinutiae (const BYTE * fpTemplate, unsigned int &numMinutiae, 
                     Minutiae minutiae[MAX_MINUTIAE])
{
   if (!m_templ)
      return TI_LOW_MEMORY;
   return m_templ->getMinutiae (fpTemplate, numMinutiae, minutiae);
}

int Ti::getSingular (const BYTE * fpTemplate, unsigned int &numSingular,
                       Singular Singular[MAX_SINGULAR],
                        unsigned int &pattern)
{
   if (!m_templ)
      return TI_LOW_MEMORY;
   return m_templ->getSingular (fpTemplate, numSingular, 
                                   Singular, pattern);
}

int Ti::getArea (const BYTE * fpTemplate, BYTE *area)
{
   if (!m_templ)
      return TI_LOW_MEMORY;
   return m_templ->getArea (fpTemplate, area);
}

int Ti::getQuality (const BYTE * fpTemplate, BYTE &quality)
{
   if (!m_templ)
      return TI_LOW_MEMORY;
   return m_templ->getQuality (fpTemplate, quality);
}

int Ti::getImageSize (const BYTE * fpTemplate, int &width, int &height)
{
   if (!m_templ)
      return TI_LOW_MEMORY;
   return m_templ->getImageSize (fpTemplate, width, height);
}

int Ti::getVersion (const BYTE * fpTemplate)
{
   if (!m_templ)
      return TI_LOW_MEMORY;
   return m_templ->getVersion (fpTemplate);
}

int Ti::getFingerPos (const BYTE * fpTemplate, FINGERS &finger)
{
   if (!m_templ)
      return TI_LOW_MEMORY;
   return m_templ->getFingerPos (fpTemplate, finger);
}

