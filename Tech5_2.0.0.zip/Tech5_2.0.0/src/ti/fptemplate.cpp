#include "fpTemplate.h"
#include "sfsDef.h"
#include "wizard73.h"


FpTemplate::FpTemplate()
{
   m_init = false;
   m_area = NULL;
   m_unpack = NULL;
}

FpTemplate::~FpTemplate()
{
    if (m_unpack)
       ESK::Unwrap::cancel(m_unpack);
   if (m_area)
      delete [] m_area;
}

bool FpTemplate::init()
{
	m_unpack = ESK::Unwrap::create();
   if (!m_unpack) 
      return false;
#if defined (_ESK_ID)
   m_unpack->versor (_ESK_ID);
#endif
   m_area  = new BYTE[(MAX_WIDTH >> 3) * (MAX_HEIGHT >> 3)];
    if (!m_area)
      return false;
    m_init = true;
    return true;
}

int FpTemplate::getMinutiae (const BYTE * fpTemplate, unsigned int &numMinutiae, 
                     Minutiae minutiae[MAX_MINUTIAE])
{
   if (!m_init && !init())
      return TI_LOW_MEMORY;
	if (!fpTemplate) 
      return TI_WRONG_POINTER;
   int version = getVersion(fpTemplate);
 	if (!version) 
      return TI_WRONG_TEMPLATE;

   if (version == 110)
      return getMinutiae110 (fpTemplate + sizeof(TemplHeader), numMinutiae, minutiae);
   if (version == 75)
      return getMinutiae110 (fpTemplate + sizeof(TemplHeader), numMinutiae, minutiae);
   if (version == 73)
      return getMinutiae110 (fpTemplate, numMinutiae, minutiae);

   return TI_WRONG_TEMPLATE;
}

int FpTemplate::getSingular (const BYTE * fpTemplate, 
                                unsigned int &numSingular,
                                Singular Singular[MAX_SINGULAR],
                                unsigned int &pattern)
{
   if (!m_init && !init())
      return TI_LOW_MEMORY;
	if (!fpTemplate) 
      return TI_WRONG_POINTER;
   int version = getVersion(fpTemplate);
 	if (!version) 
      return TI_WRONG_TEMPLATE;
   
   if (version == 110)
      return getSingular110 (fpTemplate + sizeof(TemplHeader), numSingular,
                                Singular, pattern);
   if (version == 75)
      return getSingular110 (fpTemplate + sizeof(TemplHeader), numSingular,
                                Singular, pattern);
   if (version == 73)
      return getSingular110 (fpTemplate, numSingular,
                                Singular, pattern);

   return TI_WRONG_TEMPLATE;
}



int FpTemplate::getArea (const BYTE * fpTemplate, BYTE *area)
{
   if (!m_init && !init())
      return TI_LOW_MEMORY;
	if (!fpTemplate || !area) 
      return TI_WRONG_POINTER;
   
   int version = getVersion(fpTemplate);
 	if (!version) 
      return TI_WRONG_TEMPLATE;

   if (version == 110)
      return getArea110 (fpTemplate + sizeof(TemplHeader), area);
   if (version == 75)
      return getArea110 (fpTemplate + sizeof(TemplHeader), area);
   if (version == 73)
      return getArea110 (fpTemplate, area);

   return TI_WRONG_TEMPLATE;
}

int FpTemplate::getVersion(const BYTE * fpTemplate)
{
   if (!m_init && !init())
      return TI_LOW_MEMORY;
   if (!fpTemplate)
      return 0;
   if (checkTemplate110(fpTemplate))
      return 110;
   if (checkTemplate75(fpTemplate))
      return 75;
   if (checkTemplate73(fpTemplate))
      return 73;
   return 0;
}

bool FpTemplate::checkTemplate75(const BYTE * fpTemplate)
{
   TemplHeader *header = (TemplHeader*)fpTemplate;
   if (header->checkIntegral != 0 && header->checkIntegral != 1)
      return false;
//   if (header->points > wizard73::MAXFIN || header->quality > 100) // ������, �.�. � 11-� ������, ������ ����� 73, � ����� ������, ��� 255!!
   if (header->quality > 100)
      return false;
//   if (header->relPoints > header->points)
//      return false;
   if (header->size > MAX_TEMPLATE_SIZE_80)
      return false;
   wizard73::SItem *item = (wizard73::SItem*)(fpTemplate + sizeof(TemplHeader));
   if ((unsigned int)(item->Length) != header->size - sizeof(TemplHeader))
      return false;
   if (item->Qualit > 100)// || item->Qualit != header->quality)
      return false;
   if (item->VeSign != 73 && item->VeSign != 72)
      return false;

   return true;
}

bool FpTemplate::checkTemplate73(const BYTE * fpTemplate)
{
   wizard73::SItem *item = (wizard73::SItem*)fpTemplate;
   if (item->Qualit > 100)
      return false;
   if (item->Length < 0 || item->Length > MAX_TEMPLATE_SIZE_80)
      return false;
   if (item->VeSign != 73 && item->VeSign != 72)
      return false;

   return true;
}


int FpTemplate::getQuality (const BYTE * fpTemplate, BYTE &quality)
{
   if (!m_init && !init())
      return TI_LOW_MEMORY;
	if (!fpTemplate) 
      return TI_WRONG_POINTER;
   
   int version = getVersion(fpTemplate);
 	if (!version) 
      return TI_WRONG_TEMPLATE;

   if (version == 110)
      return getQuality110 (fpTemplate + sizeof (TemplHeader), quality);
   if (version == 75)
      return getQuality73 (fpTemplate + sizeof (TemplHeader), quality);
   if (version == 73)
      return getQuality73 (fpTemplate, quality);

   return TI_WRONG_TEMPLATE;
}

int FpTemplate::getQuality73 (const BYTE * fpTemplate, BYTE &quality)
{
    wizard73::SItem *item = (wizard73::SItem*)fpTemplate;
    quality = item->Qualit;
    return TI_OK;
}


int FpTemplate::getFingerPos (const BYTE * fpTemplate, FINGERS &fingerPos)
{
   if (!m_init && !init())
      return TI_LOW_MEMORY;
	if (!fpTemplate) 
      return TI_WRONG_POINTER;
   
   int version = getVersion(fpTemplate);
 	if (!version) 
      return TI_WRONG_TEMPLATE;

   if (version == 110)
      return getFingerPos73 (fpTemplate + sizeof (TemplHeader), fingerPos);
   if (version == 75)
      return getFingerPos73 (fpTemplate + sizeof (TemplHeader), fingerPos);
   if (version == 73)
      return getFingerPos73 (fpTemplate + sizeof (TemplHeader), fingerPos);

   return TI_WRONG_TEMPLATE;
}


int FpTemplate::getFingerPos73 (const BYTE * fpTemplate, FINGERS &fingerPos)
{
    wizard73::SItem *item = (wizard73::SItem*)fpTemplate;
    fingerPos = (FINGERS)item->Number;
   return TI_OK;
}



int FpTemplate::getImageSize (const BYTE * fpTemplate, int &width, int &height)
{
   if (!m_init && !init())
      return TI_LOW_MEMORY;
	if (!fpTemplate) 
      return TI_WRONG_POINTER;
   
   int version = getVersion(fpTemplate);
 	if (!version) 
      return TI_WRONG_TEMPLATE;
   if (version == 110)
      return getImageSize110 (fpTemplate + sizeof (TemplHeader), width, height);
   if (version == 75)
      return getImageSize73 (fpTemplate + sizeof (TemplHeader), width, height);
   if (version == 73)
      return getImageSize73 (fpTemplate, width, height);

   return TI_WRONG_TEMPLATE;
}


int FpTemplate::getImageSize73 (const BYTE * fpTemplate, int &width, int &height)
{
    wizard73::SItem *item = (wizard73::SItem*)fpTemplate;
    width  = item->Size_X;
    height = item->Size_Y;
    return TI_OK;
}

int FpTemplate::getImageSize110 (const BYTE * fpTemplate, int &width, int &height)
{
   width  = m_unpack->size_x (fpTemplate);
   height = m_unpack->size_y (fpTemplate);
   return TI_OK;
}


int FpTemplate::getQuality110 (const BYTE * fpTemplate, BYTE &quality)
{
   quality = m_unpack->qualit(fpTemplate);
   return TI_OK;
}

bool FpTemplate::checkTemplate110(const BYTE * fpTemplate)
{
   TemplHeader *header = (TemplHeader*)fpTemplate;
   if (header->checkIntegral != 0 && header->checkIntegral != 1)
      return false;
//   if (header->points > wizard73::MAXFIN || header->quality > 100)
//      return false;
   //if (header->quality > 100)
   //   return false;
   //if (header->relPoints > header->points)
   //   return false;
   if (header->size > MAX_TEMPLATE_SIZE_80)
      return false;

   if (m_unpack->length(fpTemplate + sizeof(TemplHeader)) != header->size - sizeof(TemplHeader))
      return false;
   BYTE quality = m_unpack->qualit(fpTemplate + sizeof(TemplHeader));
   if (quality > 100 || quality != header->quality)
      return false;
	int version = m_unpack->versor(fpTemplate + sizeof(TemplHeader));

   return (version == 110);
}
int FpTemplate::getArea110 (const BYTE * fpTemplate, BYTE *area)
{
	if (!m_unpack->dearea (m_area, fpTemplate))
		return TI_WRONG_TEMPLATE;

   int w = m_unpack->size_x(fpTemplate);
   int h = m_unpack->size_y(fpTemplate);
   w = w / 4 * 4;
   int shift  = 0;
   int wArea  = (w + 7) >> 3;
	memset (area, 0, w * h);
   
   for (int j = 0; j < h; j++)
   {
      shift = wArea * (j >> 3);
      for (int i = 0; i < w; i++)
      {
         if (m_area[shift + (i >> 3)] != 0x40)
            area[i + j * w] = 1;
      }
   }

   return TI_OK;
}
int FpTemplate::getSingular110 (const BYTE * fpTemplate, 
                                unsigned int &numSingular,
                                Singular singular[MAX_SINGULAR],
                                unsigned int &pattern)
{
	ESK::Sign  sign[MAX_SINGULAR * 10];
   size_t maxSingular = m_unpack->demain (sign, fpTemplate);

   if (maxSingular < 0) 
      return TI_WRONG_TEMPLATE;
   if (maxSingular > MAX_SINGULAR) 
      maxSingular = MAX_SINGULAR;
   
   pattern = m_unpack->immask (fpTemplate);

   numSingular = 0;
   for(unsigned  int i = 0; i < maxSingular; i++)
   {
      singular[i].x     = (int)sign[i].Movx;
      singular[i].y     = (int)sign[i].Movy;
      singular[i].prob  = (sign[i].Prob & 0x3f) * 100 / 64;
      if (sign[i].Prob & 0x80)
         singular[i].prob /= 2;
      singular[i].angle = (int)sign[i].Beta;
      if (singular[i].angle > 180) 
         singular[i].angle -= 360;
      switch (sign[i].Type)
      {
      case 1:
         singular[numSingular].type = WHORL;
         break;
      case 2:
         singular[numSingular].type = LOOP;
         break;
      case 8:
         singular[numSingular].type = DELTA;
         break;
      default:
         continue;
      }
      singular[i].density = sign[i].Lace / 8;
      numSingular++;
   }

   return TI_OK;
}

int FpTemplate::getMinutiae110 (const BYTE * fpTemplate, unsigned int &numMinutiae, 
                     Minutiae minutiae[MAX_MINUTIAE])
{
	ESK::Sign  sign[MAX_MINUTIAE * 10];
   numMinutiae = (unsigned int)m_unpack->denova (sign, fpTemplate);
   if (numMinutiae > MAX_MINUTIAE)
      numMinutiae = MAX_MINUTIAE;

   for(unsigned int i = 0; i < numMinutiae; i++)
   {
      minutiae[i].x     = (int)sign[i].Movx;
      minutiae[i].y     = (int)sign[i].Movy;
      minutiae[i].prob  = (sign[i].Prob & 0x3f) * 100 / 63;
      if (sign[i].Prob & 0x80)
      {
         minutiae[i].prob /= 2;
         if (minutiae[i].prob >= MIN_REL_THRES)
            minutiae[i].prob = MIN_REL_THRES;
      }
      minutiae[i].type  = (MINUTIAE_TYPE)sign[i].Type;
      minutiae[i].angle = (int)sign[i].Beta;
      if (minutiae[i].angle > 180)
         minutiae[i].angle -= 360;
      minutiae[i].density = sign[i].Lace / 8;
   }

    return TI_OK;
}
