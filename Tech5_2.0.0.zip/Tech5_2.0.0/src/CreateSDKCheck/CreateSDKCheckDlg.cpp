// CreateSDKCheckDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"		// main symbols

#include <cipher.h>
#include <HardwareAnswer.h>
#include "CreateSDKCheck.h"
#include "CreateSDKCheckDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CCreateSDKCheckDlg dialog




CCreateSDKCheckDlg::CCreateSDKCheckDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCreateSDKCheckDlg::IDD)
	, m_srl_filename(_T(""))
	, m_lic_filename(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_instance_count = 1;
}

CCreateSDKCheckDlg::~CCreateSDKCheckDlg()
{
}

void CCreateSDKCheckDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PROPERTIES, m_props);
	DDX_Text(pDX, IDC_SRL_FILENAME, m_srl_filename);
	DDX_Text(pDX, IDC_LIC_FILENAME, m_lic_filename);
	DDX_Control(pDX, IDC_LIST1, m_list_ctrl);
	DDX_Control(pDX, IDC_SPIN_INST_COUNT, m_spin_ctrl);
	DDX_Control(pDX, IDC_INSTANCE_COUNT, m_instance_ctrl);
}

BEGIN_MESSAGE_MAP(CCreateSDKCheckDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BROWSE_1, &CCreateSDKCheckDlg::OnBnClickedBrowse1)
	ON_BN_CLICKED(IDC_SRL_SELECT, &CCreateSDKCheckDlg::OnBnClickedSrlSelect)
	ON_BN_CLICKED(IDC_ANSWER, &CCreateSDKCheckDlg::OnBnClickedAnswer)
	ON_WM_DESTROY()
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_INST_COUNT, &CCreateSDKCheckDlg::OnDeltaposSpinInstCount)
END_MESSAGE_MAP()


// CCreateSDKCheckDlg message handlers

BOOL CCreateSDKCheckDlg::OnInitDialog()
{

	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
		CString strInfoMenu;
		strInfoMenu.LoadString(IDS_KEY_INFORMATION);
		if (!strInfoMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_LICENSEBOX, strInfoMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	SetDlgItemInt(IDC_INSTANCE_COUNT,m_instance_count);
	m_spin_ctrl.SetRange32(1,100);
	((CButton*)GetDlgItem(IDC_CLIENT))->SetCheck(BST_CHECKED);
	m_list_ctrl.ShowWindow(SW_HIDE);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCreateSDKCheckDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if (nID == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else if (nID == IDM_LICENSEBOX)
	{
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCreateSDKCheckDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCreateSDKCheckDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CCreateSDKCheckDlg::OnBnClickedBrowse1()
{
//	return OnBnClickedBrowse2();
	
	// TODO: Add your control notification handler code here
	UpdateData();
	if ( (m_srl_filename.GetLength() < 4) || (m_lic_filename.GetLength() < 4))
	{
		wchar_t string_text[MAX_PATH];
		LoadString(AfxGetResourceHandle(),IDS_SELECT_FILES,string_text,MAX_PATH);
//		MessageBox(L"Select location and names for both files, please");
		MessageBox(string_text);
		return;
	}
	unsigned char* the_add_data = NULL;
	unsigned long the_add_data_length = 0;
	unsigned char* srl_content = NULL;
	unsigned char* lic_content = NULL;
	TECH5_PRODUCTS id_product = TECH5_SDK_CLIENT;
	int check_radio = GetCheckedRadioButton(IDC_AUTH_MATCHER,IDC_GALLERY_MATCHER);
	switch(check_radio)
	{
		case IDC_AUTH_MATCHER:
			{
				id_product = TECH5_SDK_AUTH_MATCHER;
				break;
			}
		case IDC_CLIENT:
			{
				id_product = TECH5_SDK_CLIENT;
				break;
			}
      case IDC_GALLERY_MATCHER:
			{
				id_product = TECH5_SDK_GALLERY_MATCHER;
				break;
			}
		default:
			{
				MessageBox(L"Error!");
				return;
			}
	}
	char m_serial_number_answer[20];
	char *m_macAddress_answer[_MAX_ADAPTER_COUNT];
	__time32_t m_time_end = 0;
	bool is_trial = (IsDlgButtonChecked(IDC_CHECK_TRIAL) == 0 ? false : true);
	if( !is_trial)
	{
		wchar_t string_text[MAX_PATH];
		LoadString(AfxGetResourceHandle(),IDS_TRIAL_QUESTION,string_text,MAX_PATH);
		MessageBox(string_text);
	}
	bool is_new_format = false;
	for(int i = 0; i < _MAX_ADAPTER_COUNT; i++)
	{
		m_macAddress_answer[i] = new char[_MAC_LENGTH];
		memset(m_macAddress_answer[i],0,_MAC_LENGTH*sizeof(char));
	}
	int liength_srl = 0;
	int length_lic = 0;
	FILE* m_ff = NULL;
	m_ff = _wfopen((LPTSTR)(LPCTSTR)m_srl_filename,L"rb");
	if(!m_ff)
	{
		MessageBox(m_srl_filename,L"Could not read : ",MB_OK | MB_ICONHAND);
		return;
	}
	else
	{
		fseek(m_ff,0,SEEK_END);
		liength_srl = ftell(m_ff);
		rewind(m_ff);
		srl_content = new unsigned char[liength_srl];
		memset(srl_content,0,liength_srl);
		fread(srl_content,1,liength_srl,m_ff);
		fclose(m_ff);
		lic_content = new unsigned char[10*1024*1024];
		memset(lic_content,0,10*1024*1024);
	}


	if( create_answer_file(srl_content,liength_srl,lic_content,length_lic,id_product,m_serial_number_answer,m_macAddress_answer,&m_time_end, is_trial,&is_new_format,(unsigned char*)the_add_data,the_add_data_length,m_instance_count) )
	{
// �������� ������� ������ � ���� ������ � ����������� ��� ���������� �������
		//////////////////////////////////////////////////////////////////////////
		{
				bool stop_asking = false;

				while( !stop_asking )
				{
					m_ff = _wfopen((LPTSTR)(LPCTSTR)m_lic_filename,L"wb");
					if( !m_ff)
					{
						if(	IDCANCEL == MessageBox(L"Could not create file.\nSelect other location.",(LPTSTR)(LPCTSTR)m_lic_filename,MB_OKCANCEL | MB_ICONWARNING) )
							stop_asking = true;

						wchar_t file_srl[MAX_PATH];

						OPENFILENAME ofn;
						wchar_t filter[MAX_PATH];

						memset(file_srl,0,MAX_PATH*sizeof(wchar_t));
						memset(filter,0,MAX_PATH*sizeof(wchar_t));
						wcscpy(filter,L"license file");
						memcpy((byte*)(filter+wcslen(L"license file")+1),(byte*) (L"*.lic"),wcslen(L"*.lic")*sizeof(wchar_t));
						memset(&ofn,0,sizeof(ofn));
						ofn.lStructSize = sizeof(ofn);
						ofn.lpstrFile = file_srl;
						ofn.nMaxFile = MAX_PATH;
						ofn.lpstrDefExt = L"lic";
						ofn.lpstrFilter = filter;
						ofn.Flags = OFN_OVERWRITEPROMPT;

						if( GetSaveFileName(&ofn))
						{
							m_lic_filename = file_srl;
							UpdateData(FALSE);
						}
					}
					else
					{
						fwrite(lic_content,1,length_lic,m_ff);
						fclose(m_ff); m_ff = NULL;
						stop_asking = true;
					}

				}
		}
		//////////////////////////////////////////////////////////////////////////

		MessageBox(L"Success");
		if(!is_new_format)
			MessageBox(L"Old format file created");
		CString m_text(m_serial_number_answer);
		m_props.SetWindowText(L"Serial number of hard disk is:\r\n    " + m_text);
		m_props.GetWindowText(m_text);
		m_text += L"\r\nAdapters have mac-addresses:\r\n";
		m_props.SetWindowText(m_text);
		for(int i = 0; i <_MAX_ADAPTER_COUNT; i++)
		{
			if( strstr(m_macAddress_answer[i],":") == 0)
				continue;
			CString m_temp(m_macAddress_answer[i]);
			m_props.GetWindowText(m_text);
			m_text += L"    " + m_temp + CString("\r\n");
			m_props.SetWindowText(m_text);
		}
		struct tm today;
		_localtime32_s(&today, &m_time_end );
		wchar_t tmpbuf[128];
		wcsftime( tmpbuf, 128,L"License will stop at %A, day %d of %B in the year %Y.", &today );
		m_props.GetWindowText(m_text);
		if(is_trial)
			m_text += CString(tmpbuf) + CString("\r\n");
		m_props.SetWindowText(m_text);
	}
	else
		MessageBox(L"Error");
	for(int i = 0; i < _MAX_ADAPTER_COUNT; i++)
	{
		delete m_macAddress_answer[i];
	}
	if(srl_content)
		delete[] srl_content; srl_content = NULL;
	if(lic_content)
		delete[] lic_content; lic_content = NULL;
	if(	the_add_data)
		delete[] the_add_data; the_add_data = NULL;

}

void CCreateSDKCheckDlg::OnBnClickedSrlSelect()
{
	// TODO: Add your control notification handler code here
	wchar_t file_srl[MAX_PATH];

	OPENFILENAME ofn;
	wchar_t filter[MAX_PATH];

	memset(file_srl,0,MAX_PATH*sizeof(wchar_t));
	memset(filter,0,MAX_PATH*sizeof(wchar_t));
	wcscpy(filter,L"bind request");
	memcpy((byte*)(filter+wcslen(L"bind request")+1),(byte*) (L"*.srl"),wcslen(L"*.srl")*sizeof(wchar_t));
	memset(&ofn,0,sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.lpstrFile = file_srl;
	ofn.nMaxFile = MAX_PATH;
	ofn.lpstrDefExt = L"srl";
	ofn.lpstrFilter = filter;
	ofn.Flags = OFN_FILEMUSTEXIST;

	if( !GetOpenFileName(&ofn))
		return;
	m_srl_filename = file_srl;

	if( wcsstr(file_srl,L"tech5_auth_matcher") != NULL)
	{
		if( ((CButton*)GetDlgItem(IDC_AUTH_MATCHER))->IsWindowEnabled() )
			CheckRadioButton(IDC_AUTH_MATCHER,IDC_GALLERY_MATCHER,IDC_AUTH_MATCHER);
	}
	else if( wcsstr(file_srl,L"tech5_client") != NULL)
	{
		if( ((CButton*)GetDlgItem(IDC_CLIENT))->IsWindowEnabled() )
			CheckRadioButton(IDC_AUTH_MATCHER,IDC_GALLERY_MATCHER,IDC_CLIENT);
	}
	else if( wcsstr(file_srl,L"tech5_gallery_matcher") != NULL)
	{
		if( ((CButton*)GetDlgItem(IDC_GALLERY_MATCHER))->IsWindowEnabled() )
			CheckRadioButton(IDC_AUTH_MATCHER,IDC_GALLERY_MATCHER,IDC_GALLERY_MATCHER);
	}
	FILE* f_srl = NULL;
	f_srl = _wfopen(file_srl,L"rb");
	if(f_srl)
	{
		char tmp_buf[8];
		memset(tmp_buf,0,8*sizeof(tmp_buf[0]));
		fseek(f_srl,0,SEEK_END);
		long size_file = ftell(f_srl);
		fseek(f_srl,size_file - strlen("real"),SEEK_SET);
		fread(tmp_buf,1,strlen("real"),f_srl);
		fclose(f_srl);
		if( strnicmp("rial",tmp_buf,strlen("rial")) == 0)
		{
			CheckDlgButton(IDC_CHECK_TRIAL,1);
			MessageBox(L"It seems a trial version product request",L"Information",MB_OK | MB_ICONINFORMATION);
		}
		else
		{
			CheckDlgButton(IDC_CHECK_TRIAL,0);
		}
	}
	long length = wcslen(file_srl);
	file_srl[length-3] = L'l';
	file_srl[length-2] = L'i';
	file_srl[length-1] = L'c';
	m_lic_filename = file_srl;
	UpdateData(FALSE);
}

void CCreateSDKCheckDlg::OnBnClickedAnswer()
{
	// TODO: Add your control notification handler code here
	wchar_t file_lic[MAX_PATH];

	OPENFILENAME ofn;
	wchar_t filter[MAX_PATH];

	memset(file_lic,0,MAX_PATH*sizeof(wchar_t));
	memset(filter,0,MAX_PATH*sizeof(wchar_t));
	wcscpy(filter,L"bind files");
	memcpy((byte*)(filter+wcslen(L"bind files")+1),(byte*) (L"*.lic"),wcslen(L"*.lic")*sizeof(wchar_t));
	memset(&ofn,0,sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.lpstrFile = file_lic;
	ofn.nMaxFile = MAX_PATH;
	ofn.lpstrDefExt = L"lic";
	ofn.lpstrFilter = filter;
	ofn.Flags = OFN_CREATEPROMPT | OFN_EXPLORER | OFN_OVERWRITEPROMPT;

	bool sehr_good = false;
	if( !GetSaveFileName(&ofn))
		return;
	m_lic_filename = file_lic;
	UpdateData(FALSE);
}

void CCreateSDKCheckDlg::OnDestroy()
{
	CDialog::OnDestroy();

	// TODO: Add your message handler code here
}

void CCreateSDKCheckDlg::OnDeltaposSpinInstCount(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: Add your control notification handler code here
	*pResult = 0;
	m_instance_count = pNMUpDown->iPos+pNMUpDown->iDelta;
}
