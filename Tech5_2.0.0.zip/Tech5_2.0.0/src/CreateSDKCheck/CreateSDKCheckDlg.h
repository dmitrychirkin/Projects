// CreateSDKCheckDlg.h : header file
//

#pragma once
#include "afxwin.h"

// CCreateSDKCheckDlg dialog
class CCreateSDKCheckDlg : public CDialog
{
// Construction
public:
	CCreateSDKCheckDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CCreateSDKCheckDlg();

// Dialog Data
	enum { IDD = IDD_CREATESDKCHECK_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	int m_instance_count;
	afx_msg void OnBnClickedBrowse1();
	CStatic m_props;
	afx_msg void OnBnClickedSrlSelect();
	afx_msg void OnBnClickedAnswer();
	CString m_srl_filename;
	CString m_lic_filename;
	afx_msg void OnDestroy();
	CListCtrl m_list_ctrl;
	CSpinButtonCtrl m_spin_ctrl;
	CEdit m_instance_ctrl;
	afx_msg void OnDeltaposSpinInstCount(NMHDR *pNMHDR, LRESULT *pResult);
};
