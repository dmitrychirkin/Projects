// test_Tech5_AuthMatcher_ServerE.cpp : Defines the entry point for the console application.
//
#include <omp.h>
#include <stdio.h>
#include <assert.h>
#include <time.h>

#include "coreSdk.h"
#include "fileUtl.h"
#include "dib.h"
#include "sfsDef.h"
#include "calcRates.h"
#include "Tech5_AuthMatcher_ServerE.h"


#define MAX_IMAGE_SIZE                       (1024 * 1024)   
const unsigned int g_numThreads              = 8;
const unsigned int g_numRecords              = 140;
const unsigned  int g_numImpressions         = 12;
const char *g_imageDir                       = "../../test/images/";
const char *g_logDir                         = "../../test/";
const char *g_tech5_templDir                 = "../../test/tech5_templates/";
const char *g_nist_templDir                  = "../../test/nist_templates/";
const char *g_iso_templDir                    = "../../test/iso_templates/";
const char *g_license_filename               = "../../test/tech5_auth_matcher.lic";
const char *g_ip_speed_filename              = "../../test/ipSpeed.txt";
TECH5_AUTH_SERVER_E g_sdk[g_numThreads];


typedef int (* MATCH_FUNC)          (TECH5_AUTH_SERVER_E sdk, const unsigned char* probeTemplate, const unsigned char* galleryTemplate, unsigned char* score);
typedef int (* CREATE_TEMPLATE_FUNC)(TECH5_AUTH_SERVER_E sdk, unsigned int numFingers, DIBImage* dibImage, unsigned char* templ, unsigned char* quality, int* templ_size, 
                                     int maxTemplateSize, bool certifiedSensor, unsigned short sensorID);

bool check(int result, char *caption, TECH5_AUTH_SERVER_E sdk)
{
   assert(caption && sdk);
   if (result == SE_OK)
      return true;
   printf ("%s error: %s\n", caption, getLastErrorMsg (sdk)) ;
   return false;
}

bool readImageFile(char *name, CDib &dib)
{
   assert(name);
   if (dib.readBmp (name) != DIB_OK)
   {
      printf ("error of reading file %s\n", name);
      return false;
   }
   dib.setResolutionX (500);
   dib.setResolutionY (500);
   return true;
}

int create_tech5_template(TECH5_AUTH_SERVER_E sdk, unsigned int numFingers, DIBImage* dibImage, unsigned char* templ, unsigned char* quality, int* templ_size, 
                                     int maxTemplateSize, bool certifiedSensor, unsigned short sensorID)
{
   unsigned int templSize = 0;
   int result = create_Template_Tech5Ex (sdk, dibImage[0], templ, &templSize, quality);
   *templ_size = (int)templSize;
   return result;
}

void create_template(CREATE_TEMPLATE_FUNC func, int numThread, BYTE *dib, BYTE *fpTemplate, char *templName)
{
   assert(dib && fpTemplate && templName);
   DIBImage dibImage;
   dibImage.image = dib;
   dibImage.finger = 0;
   unsigned char quality = 0;
   int  templSize = 0;
   if(!check( func (g_sdk[numThread], 1, &dibImage, fpTemplate, &quality, &templSize, 0, false, 0 ), "create_Template_ISO", g_sdk[numThread]))
      return;
   if (saveFile (templName, fpTemplate, templSize) != FU_OK)
   {
      printf ("error of saving file %s\n", templName);
   }
//   printf ("%50s created, thread = %d, quality = %3d, templSize = %4d\n", templName, numThread, quality, templSize);
}

void alloc_templates_for_build (BYTE *tech5_template[g_numThreads], BYTE *nist_template [g_numThreads], BYTE *iso_template  [g_numThreads])
{
   assert(tech5_template && nist_template && iso_template);
   for (int i = 0; i < g_numThreads; i++)
   {
      check( allocate_Template_Tech5 (g_sdk[i],    &tech5_template[i]), "allocate_Template_Tech5", g_sdk[i]);
      check( allocate_Template_NIST  (g_sdk[i], 1, &nist_template [i]), "allocate_Template_NIST" , g_sdk[i]);
      check( allocate_Template_ISO   (g_sdk[i], 1, &iso_template  [i]), "allocate_Template_ISO"  , g_sdk[i]);
   }
}

void free_templates_for_build (BYTE *tech5_template[g_numThreads], BYTE *nist_template [g_numThreads], BYTE *iso_template  [g_numThreads])
{
   assert(tech5_template && nist_template && iso_template);
   for (int i = 0; i < g_numThreads; i++)
   {
      free_Template_Tech5 (g_sdk[i], &tech5_template[i]);
      free_Template_NIST  (g_sdk[i], &nist_template [i]);
      free_Template_ISO   (g_sdk[i], &iso_template  [i]);
   }
}

void report_image_processing_speed(clock_t start, clock_t finish, int count)
{
   FILE *f = fopen(g_ip_speed_filename, "w");
   if(!f)
      return;
   char msg[1024];
   sprintf (msg, "\nAverange image procesing time = %f sec\n", (double)(finish - start) / count / CLOCKS_PER_SEC);
   printf (    "%s\n", msg);
   fprintf (f, "%s\n", msg);
   fclose(f);
}

void build_all_templates()
{
   printf ("\nStart building all templates\n");
   BYTE *tech5_template[g_numThreads];
   BYTE *nist_template [g_numThreads];
   BYTE *iso_template  [g_numThreads];
   CDib  dib           [g_numThreads];
   alloc_templates_for_build (tech5_template, nist_template, iso_template);
   unsigned int count = 0;

   clock_t start = clock();

#pragma omp parallel for num_threads(g_numThreads)
   for(int i = 0; i < g_numRecords; i++)
   {
      int num_thread = omp_get_thread_num();
      if (!num_thread)
         printf ("%c%4.2f%%", 13, count * 100.0 / g_numRecords);
      for(int j = 0; j < g_numImpressions; j++)
      {
         char name[MAX_PATH];
         // read image
         sprintf (name, "%s%d_%d.bmp", g_imageDir, i + 1, j+ 1);
         if (!readImageFile(name, dib[num_thread]))
            continue;
         // create Tech5 template
         sprintf (name, "%s%d_%d.tpl", g_tech5_templDir, i+ 1, j+ 1);
         create_template(create_tech5_template, num_thread, dib[num_thread].getDib(), tech5_template[num_thread], name);
         // create NIST template
         sprintf (name, "%s%d_%d.nist", g_nist_templDir, i+ 1, j+ 1);
         create_template(create_Template_NIST , num_thread, dib[num_thread].getDib() , nist_template [num_thread], name);
         // create ISO template
         sprintf (name, "%s%d_%d.iso", g_iso_templDir, i+ 1, j+ 1);
         create_template(create_Template_ISO  , num_thread, dib[num_thread].getDib()  , iso_template  [num_thread], name);
      }
      #pragma omp atomic
         count++;
   }
   clock_t finish = clock();

   free_templates_for_build (tech5_template, nist_template, iso_template);
   printf ("%c100%%     ", 13);
   printf ("\nFinish build all templates\n\n");

   report_image_processing_speed(start, finish, count * 3);
}

bool alloc_templates_for_match (BYTE *tech5_template[g_numRecords][g_numImpressions], BYTE *nist_template [g_numRecords][g_numImpressions], BYTE *iso_template  [g_numRecords][g_numImpressions])
{
   assert(tech5_template && nist_template && iso_template);
   for (int i = 0; i < g_numRecords; i++)
      for (int j = 0; j < g_numImpressions; j++)
      {
         if (!check( allocate_Template_Tech5 (g_sdk[0],    &tech5_template[i][j]), "allocate_Template_Tech5", g_sdk[0])) return false;
         if (!check( allocate_Template_NIST  (g_sdk[0], 1, &nist_template [i][j]), "allocate_Template_NIST" , g_sdk[0])) return false;
         if (!check( allocate_Template_ISO   (g_sdk[0], 1, &iso_template  [i][j]), "allocate_Template_ISO"  , g_sdk[0])) return false;
      }
   return true;
}

void free_templates_for_match (BYTE *tech5_template[g_numRecords][g_numImpressions], BYTE *nist_template [g_numRecords][g_numImpressions], BYTE *iso_template  [g_numRecords][g_numImpressions])
{
   assert(tech5_template && nist_template && iso_template);
   for (int i = 0; i < g_numRecords; i++)
      for (int j = 0; j < g_numImpressions; j++)
      {
         check( free_Template_Tech5 (g_sdk[0], &tech5_template[i][j]), "allocate_Template_Tech5", g_sdk[0]);
         check( free_Template_NIST  (g_sdk[0], &nist_template [i][j]), "allocate_Template_NIST" , g_sdk[0]);
         check( free_Template_ISO   (g_sdk[0], &iso_template  [i][j]), "allocate_Template_ISO"  , g_sdk[0]);
      }
}

void readTemplFile(char *name, BYTE *templ)
{
   assert(name && templ);
   char msg[1024];
   size_t size = MAX_TEMPLATE_SIZE;
   if (readFile (name, templ, &size) != FU_OK)
   {
      sprintf (msg, "cannot read file %s", name);
      throw msg;
   }
}

bool read_all_templates(BYTE *tech5_template[g_numRecords][g_numImpressions], BYTE *nist_template [g_numRecords][g_numImpressions], BYTE *iso_template  [g_numRecords][g_numImpressions])
{
   assert(tech5_template && nist_template && iso_template);
   char name[MAX_PATH];
   try
   {
      for (int i = 0; i < g_numRecords; i++)
         for (int j = 0; j < g_numImpressions; j++)
         {
            sprintf (name, "%s%d_%d.tpl", g_tech5_templDir, i + 1, j + 1);
            readTemplFile (name, tech5_template[i][j]);
            sprintf (name, "%s%d_%d.nist", g_nist_templDir, i + 1, j + 1);
            readTemplFile (name,nist_template[i][j]);
            sprintf (name, "%s%d_%d.iso", g_iso_templDir, i + 1, j + 1);
            readTemplFile (name, iso_template[i][j]);
         }
   }
   catch (char *e)
   {
      printf ("%s\n", e);
      return false;
   }
   return true;
}

void reportRocAndSpeed(CalcRate calc[g_numThreads], char *logName, clock_t start, clock_t finish, unsigned int count)
{
   assert(logName);
   for(unsigned int i = 1; i < g_numThreads; i++)
      calc[0] += calc[i];

   char msg[1024];
   FILE *log = fopen(logName, "w");
   if (!log)
   {
      sprintf (msg, "cannot open log file %s", logName);
      return;
   }

   double frr = 100;
   double err = 100; // FAR
   for(int i = 0; i < 10; i++)
   {
      frr = calc[0].FRR_FAR(err);
      sprintf (msg, "FAR = %12.8f%% FRR = %12.8f%%\n", err, frr); 
      printf("%s", msg);
      fprintf(log, "%s", msg);
      err /= 10;
   }
   sprintf (msg, "\nZeroFMR = %12.8f%%\n", calc[0].ZeroFMR()); 
   printf("%s", msg);
   fprintf(log, "%s", msg);

   sprintf (msg, "\n\nAverange matching speed = %f match/sec\n\n", (double)count / (finish - start) * CLOCKS_PER_SEC ); 
   printf("%s", msg);
   fprintf(log, "%s", msg);

   if (log) fclose(log), log = NULL;
}


void match(MATCH_FUNC match_func, BYTE *templ1[g_numRecords][g_numImpressions], BYTE *templ2[g_numRecords][g_numImpressions], char *searchType)
{
   assert(templ1 && templ2);
   printf ("\nStart matching %s templates\n", searchType);
   char caption[256];
   sprintf (caption, "match_Templates_%s", searchType);
   CalcRate calc[g_numThreads];
   
   unsigned int count = 0;
   clock_t start =  clock();
   #pragma omp parallel for num_threads(g_numThreads)
   for (int i1 = 0; i1 < g_numRecords    ; i1++)
   {
      int num_thread = omp_get_thread_num();
 //     if (!num_thread)
         printf ("%c%4.2f%%", 13, count * 100.0 / g_numRecords);
      for (int j1 = 0; j1 < g_numImpressions; j1++)
      for (int i2 = 0; i2 < g_numRecords    ; i2++)
      for (int j2 = 0; j2 < g_numImpressions; j2++)
      {
         unsigned char score = 0;
         check(match_func(g_sdk[num_thread],  templ1[i1][j1], templ2[i2][j2], &score), caption, g_sdk[num_thread]);
         if (i1 == i2) calc[num_thread].putGenuineScore  (score / 100.0);
         else          calc[num_thread].putImpostorScore (score / 100.0);
      }
      #pragma omp atomic 
         count++;
   }
   clock_t finish =  clock();
   printf ("%c100%%     ", 13);
   printf ("\nFinish matching %s templates\n", searchType);
   
   // report roc
   char logName[MAX_PATH];
   sprintf (logName, "%s%s_roc.txt", g_logDir, searchType);
   reportRocAndSpeed(calc, logName, start, finish, 
      g_numRecords * g_numImpressions * g_numRecords * g_numImpressions);
}


void match_all()
{
   BYTE *tech5_template[g_numRecords][g_numImpressions];
   BYTE *nist_template [g_numRecords][g_numImpressions];
   BYTE *iso_template  [g_numRecords][g_numImpressions];

   // set search param
   SearchParams param;
   param.maxAngle = 60;
   param.searchSpeed = LOW_MATCH_SPEED;
   for(int i = 0; i < g_numThreads; i++)
      check(setSearchParams (g_sdk[i], &param), "setSearchParams", g_sdk[i]);

   // report search params
   printf ("\nMatching parameters:\n");
   for(int i = 0; i < g_numThreads; i++)
   {
      const SearchParams *pSearchParams = getSearchParams (g_sdk[i]);
      printf ("for thread %d: maxAngle = %d, maxDisp = %d, searchSpeed = %d\n", i, pSearchParams->maxAngle, pSearchParams->maxDisp, pSearchParams->searchSpeed);
   }
      
   // allocate memory for all templates and read it
   if (!alloc_templates_for_match (tech5_template, nist_template, iso_template)) return;
   if (!read_all_templates        (tech5_template, nist_template, iso_template)) return;
      
   // match all 
   match (match_Templates_Tech5, tech5_template, tech5_template, "tech5"     );
   match (match_Templates_NIST , nist_template , nist_template , "nist"      );
   match (match_Templates_ISO  , iso_template  , iso_template  , "iso"       );
   match (match_Tech5_NIST     , tech5_template, nist_template , "tech5_nist");
   match (match_Tech5_ISO      , tech5_template, iso_template  , "tech5_iso" );

   free_templates_for_match (tech5_template, nist_template, iso_template);
}

int main(int argc, char* argv[])
{
   // initialize SDK
   for(int i = 0; i < g_numThreads; i++)
   {
      if (initSDK(&g_sdk[i]) != SE_OK)
      {
         printf ("cannot initialize Tech5_AuthMatcher_ServerE\n");
         return -1;
      }
      printf ("\nthe wrong license file name will be used for 'setLicense' function\n");
      check(setLicense(g_sdk[i], ""), "setLicense", g_sdk[i]);

      printf ("\nthe proper license file name will be used for 'setLicense' function\n");
      if (!check(setLicense(g_sdk[i], g_license_filename), "setLicense", g_sdk[i]))
         return -1;
      printf ("'setLicense' OK\n");
   }

   // build all templates
   build_all_templates();

   // match all templates
   match_all();

   // close SDK
   for(int i = 0; i < g_numThreads; i++)
      closeSDK(&g_sdk[i]);

	return 0;
}

