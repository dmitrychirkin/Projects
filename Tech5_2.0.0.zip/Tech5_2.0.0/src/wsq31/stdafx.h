// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#ifdef _WINDOWS
#include <io.h> // access
#endif

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include "wsq_fbi.h"
#include "swsq31.h"
#include "dataio.h"
#include "Util.h"
#include "swap.H"
#include "defs.H"

