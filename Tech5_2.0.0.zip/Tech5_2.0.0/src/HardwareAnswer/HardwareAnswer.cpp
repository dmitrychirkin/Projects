#if defined (_WINDOWS) || defined (_WIN32)
#include <windows.h>
#else
#endif

#include <stdio.h>
#include "cipher.h"
#include "protected_period.h"
#include "..\HardwareBind\bind_request.h"
#include "HardwareAnswer.h"

//const __time32_t PROTECTED_PERIOD_IN_SECONDS = 12*30*24*60*60;
const __time32_t PROTECTED_PERIOD_IN_SECONDS = PROTECTED_PERIOD;

FILE* createtmpfile(TECH5_PRODUCTS product)
{
	wchar_t filename[MAX_PATH];
	wchar_t wintmp[MAX_PATH];
	wchar_t *template_name = NULL;
	memset(wintmp,0,MAX_PATH*sizeof(wintmp[0]));
	DWORD length = GetTempPath(MAX_PATH,wintmp);
	switch(product)
	{
		case TECH5_SDK_GALLERY_MATCHER:
			{
				template_name = L"TECH5_SDK_GALLERY_MATCHER.tmp";
				break;
			}
		case TECH5_SDK_CLIENT:
			{
				template_name = L"TECH5_SDK_CLIENT.tmp";
				break;
			}
		case TECH5_SDK_AUTH_MATCHER:
			{
				template_name = L"TECH5_SDK_AUTH_MATCHER.tmp";
				break;
			}
		default:
			{
				return NULL;
				break;
			}
	}
	wsprintf(filename,L"%s%s",wintmp,template_name);
	return _wfopen(filename,L"w+bTD");
}

bool create_answer_file(wchar_t* request_filename, wchar_t* answer_filename, TECH5_PRODUCTS product, char* m_serial_number_answer, char* m_macAddress_answer[_MAX_ADAPTER_COUNT], __time32_t* end_license, bool is_trial, bool* is_old_format, unsigned char* additional_info, unsigned long additional_info_length, int m_instance_count)
{
	bool status = false;
	int lengthRequest = 0;
	int lengthAnswer = 1024000;
	FILE* fff_request = NULL;
	FILE* fff_answer = NULL;
	snd_uchar* request_buffer = 0;
	snd_uchar* answer_buffer = 0;

	try
	{
		fff_request = _wfopen(request_filename,L"rb");
		if(fff_request)
		{
			fseek(fff_request,0,SEEK_END);
			lengthRequest = ftell(fff_request);
			fseek(fff_request,0,SEEK_SET);
			request_buffer = new snd_uchar[lengthRequest];
			if( lengthRequest != fread(request_buffer,1,lengthRequest,fff_request))
				throw lengthRequest;
			fclose(fff_request); fff_request = NULL;
		}
		else
			throw request_filename;
		answer_buffer = new snd_uchar[lengthAnswer];
		memset(answer_buffer,0,lengthAnswer*sizeof(answer_buffer[0]));
		if( create_answer_file(request_buffer,lengthRequest,answer_buffer,lengthAnswer,product,m_serial_number_answer, m_macAddress_answer, end_license, is_trial, is_old_format,  additional_info, additional_info_length, m_instance_count))
		{
			fff_answer = _wfopen(answer_filename,L"wb");
			if( !fff_answer )
				throw answer_filename;
			fwrite(answer_buffer,1,lengthAnswer,fff_answer);
			fclose(fff_answer); fff_answer = 0;
			status = true;
		}
	}
	catch(...)
	{
	}
	if(request_buffer)
		delete[] request_buffer, request_buffer = 0;
	if(answer_buffer)
		delete[] answer_buffer, answer_buffer = 0;
	if(fff_request)
		fclose(fff_request), fff_request = 0;
	if(fff_answer)
		fclose(fff_answer), fff_answer = 0;
	return status;
}
/*
bool create_answer_file(wchar_t* request_filename, wchar_t* answer_filename, TECH5_PRODUCTS product, char* m_serial_number_answer, char* m_macAddress_answer[_MAX_ADAPTER_COUNT], __time32_t* end_license, bool is_trial, bool* is_old_format, unsigned char* additional_info, unsigned long additional_info_length, int m_instance_count)
{
	bool status = false;
	snd_uchar *bufferok = NULL;
	__time32_t end_of_license = 0;
	__int64 a2 = 0;
	snd_ulong destLen = 0;
	snd_ulong password = encrypt_mac_address_count[product];
	snd_ulong lengthFilename = 0;
	FILE *fff = NULL;
	FILE* ff_tmp = NULL;

	char encryptedAddress[_MAX_ADAPTER_COUNT][_MAC_LENGTH];
	char cryptAddress[_MAX_ADAPTER_COUNT][_MAC_LENGTH];
	bool found[1+_MAX_ADAPTER_COUNT];
	int macCountFound = 0;
	int max_file_size = 1024;
	char *m_crypto_buffer = NULL;
	char serial_hdd[_MAX_SERIAL_COUNT+4];
	bool is_real = true;

	try
	{
		for(int i = 0; i < _MAX_ADAPTER_COUNT; i++)
		{
			memset(encryptedAddress[i],0,_MAC_LENGTH);
			memset(cryptAddress[i],0,_MAC_LENGTH);
		}
		for(int i = 0; i < 1+_MAX_ADAPTER_COUNT; i++)
			found[i] = false;
		fff = _wfopen(request_filename,L"r+b");
		if(fff)
		{
			ff_tmp = createtmpfile(product);
			if(!ff_tmp)
				throw 0;
			int len_file = fseek(fff,0,SEEK_END);
			len_file = ftell(fff);
			fseek(fff,-strlen("real"),SEEK_END);
			fread(serial_hdd,1,strlen("real"),fff);
			if(strncmp("real",serial_hdd,strlen("real")) == 0 )
				is_real = true;
			else if(strncmp("rial",serial_hdd,strlen("rial")) == 0 )
			{
				is_real = true;
			}
			else
				is_real = false;
			rewind(fff);
			if(is_real)
				len_file = len_file - strlen("real");
			m_crypto_buffer = new char[max_file_size];
			__time32_t m_pass = 0;
//			WORD m_pass = 0;
			fread(&m_pass,1,sizeof(m_pass),fff);
			end_of_license = m_pass;
			fread(m_crypto_buffer,1,len_file - sizeof(m_pass),fff);
			CAPIDecryptData((unsigned char*)m_crypto_buffer,len_file-sizeof(m_pass),(char*)&m_pass,sizeof(m_pass));
			fwrite(m_crypto_buffer,1,len_file-sizeof(m_pass),ff_tmp);
			rewind(ff_tmp);
			bufferok = new snd_uchar[128]; memset(bufferok,0,128);
			fread(bufferok,1,sizeof(__int64),ff_tmp);
			destLen = 0;
			CAPIDecryptString((char*)bufferok,sizeof(__int64),(char*)&password,sizeof(password),(char*)&a2,&destLen);
			fread(cryptAddress,1,_MAC_LENGTH*_MAX_ADAPTER_COUNT,ff_tmp);
			CAPIDecryptString((char*)cryptAddress,_MAC_LENGTH*_MAX_ADAPTER_COUNT,(char*)&password,sizeof(password),(char*)encryptedAddress,&destLen);
			password = encrypt_hdd[product];
			fread(bufferok,1,32,ff_tmp);
			CAPIDecryptString((char*)bufferok,_MAX_SERIAL_COUNT+4,(char*)&password,sizeof(password),(char*)serial_hdd,&destLen);
			fclose(fff); fff = NULL;
			fclose(ff_tmp); ff_tmp = NULL;
		}
		else
			throw "";
		fff = _wfopen(answer_filename,L"wb");
		if(fff)
		{
			password = encrypt_answer[product];
			CAPIEncryptString((char*)&a2,sizeof(a2),(char*)&password,sizeof(password),(char*)bufferok,&destLen);
			fwrite(bufferok,1,destLen,fff);
			for(int i = 0; i < a2; i++)
			{
				if(m_macAddress_answer)
					memcpy(m_macAddress_answer[i],encryptedAddress[i],_MAC_LENGTH);
				CAPIEncryptString(encryptedAddress[i],_MAC_LENGTH,(char*)&password,sizeof(password),cryptAddress[i],&destLen);
				fwrite(cryptAddress[i],1,destLen,fff);
			}
			if(m_serial_number_answer)
				memcpy(m_serial_number_answer,serial_hdd,_MAX_SERIAL_COUNT*sizeof(m_serial_number_answer[0]));
			CAPIEncryptString((char*)serial_hdd,_MAX_SERIAL_COUNT,(char*)&password,sizeof(password),(char*)bufferok,&destLen);
			fwrite(bufferok,1,destLen,fff);
			memset(bufferok,0,destLen);
			end_of_license += PROTECTED_PERIOD_IN_SECONDS;
			if(end_license)
				*end_license = end_of_license;
			CAPIEncryptData((unsigned char*)&end_of_license,sizeof(end_of_license),(char*)&password,sizeof(password));
			fwrite(&end_of_license,1,sizeof(end_of_license),fff);
			if(is_real)
			{
				fwrite(&is_trial,1,sizeof(is_trial),fff);
			
				// Generate the UUID for counting instances of sdk 
				UUID uuId;
				int retCode = RPC_S_OK;
				RPC_WSTR uuid_str = NULL;
				memset(&uuId,0,sizeof(uuId));
				UuidCreate(&uuId);
				retCode = UuidToStringW(&uuId,&uuid_str);
				if(retCode != RPC_S_OK)
				{
					uuid_str = (RPC_WSTR) new wchar_t[sizeof(UUID)*2+4];
					memcpy(uuid_str,L"11111111-2222-3333-4444-555555555555",(sizeof(UUID)*2+4)*sizeof(uuid_str[0]));
				}
				// write UUID into file 
				size_t random = wcslen((wchar_t*)uuid_str)*sizeof(uuid_str[0]);
				fwrite(uuid_str,1,random,fff);
				for(int i = random; i < (sizeof(UUID)*2+4)*sizeof(uuid_str[0]); i++)
					fwrite("",1,1,fff);
				RpcStringFreeW(&uuid_str);
				// Write max instance count
				fwrite(&m_instance_count,1,sizeof(m_instance_count),fff);
			}
			// Write additinal information
			if( (additional_info_length != 0) && (additional_info != 0))
			{
				long size_add = additional_info_length;
				CAPIEncryptData((snd_uchar*)&size_add, sizeof(size_add),(snd_char*)&password,sizeof(password));
				fwrite(&size_add,1,sizeof(size_add),fff);
				snd_uchar* temp_buf = NULL;
				temp_buf = new snd_uchar[additional_info_length];
				if(temp_buf != NULL)
				{
					memcpy(temp_buf,additional_info,additional_info_length);
					CAPIEncryptData(temp_buf, additional_info_length,(snd_char*)&password,sizeof(password));
					fwrite(temp_buf,1,additional_info_length,fff);
					delete[] temp_buf; temp_buf = 0;
				}
			}
		}
		status =  true;
		if(is_old_format)
		{
			*is_old_format = is_real;
		}
	}
	catch(...)
	{
		;
	}
	if(ff_tmp)
		fclose(ff_tmp); ff_tmp = NULL;
	if(fff)
		fclose(fff);	fff = NULL;
	if(bufferok)
		delete[] bufferok,	bufferok = NULL;
	if(m_crypto_buffer)
		delete[] m_crypto_buffer, m_crypto_buffer = NULL;
	return status;
}
*/
bool create_answer_file(unsigned char* request_buffer,int lenth_request ,unsigned char* answer_filename,int& length_answer , TECH5_PRODUCTS product, char* m_serial_number_answer, char* m_macAddress_answer[_MAX_ADAPTER_COUNT], __time32_t* end_license, bool is_trial, bool* is_old_format, unsigned char* additional_info, unsigned long additional_info_length, int m_instance_count)
{
	bool status = false;
	snd_uchar *bufferok = NULL;
	__time32_t end_of_license = 0;
	__int64 a2 = 0;
	snd_ulong destLen = 0;
	snd_ulong password = encrypt_mac_address_count[product];
	snd_ulong lengthFilename = 0;

	char encryptedAddress[_MAX_ADAPTER_COUNT][_MAC_LENGTH];
	char cryptAddress[_MAX_ADAPTER_COUNT][_MAC_LENGTH];
	bool found[1+_MAX_ADAPTER_COUNT];
	int macCountFound = 0;
	int max_file_size = 1024;
	char *m_crypto_buffer = NULL;
	char serial_hdd[_MAX_SERIAL_COUNT+4];
	bool is_real = true;

	try
	{
		for(int i = 0; i < _MAX_ADAPTER_COUNT; i++)
		{
			memset(encryptedAddress[i],0,_MAC_LENGTH);
			memset(cryptAddress[i],0,_MAC_LENGTH);
		}
		for(int i = 0; i < 1+_MAX_ADAPTER_COUNT; i++)
			found[i] = false;

		int len_file = lenth_request;
		memcpy(serial_hdd,request_buffer + (lenth_request-strlen("real")),strlen("real"));
		if(strncmp("real",serial_hdd,strlen("real")) == 0 )
			is_real = true;
		else if(strncmp("rial",serial_hdd,strlen("rial")) == 0 )
		{
			is_real = true;
		}
		else
			is_real = false;
		if(is_real)
			len_file = len_file - strlen("real");
		m_crypto_buffer = new char[max_file_size];
		__time32_t m_pass = 0;
		//			WORD m_pass = 0;
		memcpy(&m_pass,request_buffer,sizeof(m_pass));
		end_of_license = m_pass;
		memcpy(m_crypto_buffer,request_buffer+sizeof(m_pass),len_file-sizeof(m_pass));
		CAPIDecryptData((unsigned char*)m_crypto_buffer,len_file-sizeof(m_pass),(char*)&m_pass,sizeof(m_pass));
		bufferok = new snd_uchar[128]; memset(bufferok,0,128);
		memcpy(bufferok,m_crypto_buffer,sizeof(__int64));
		destLen = 0;
		CAPIDecryptString((char*)bufferok,sizeof(__int64),(char*)&password,sizeof(password),(char*)&a2,&destLen);
		memcpy(cryptAddress,m_crypto_buffer + sizeof(__int64),_MAC_LENGTH*_MAX_ADAPTER_COUNT);
		CAPIDecryptString((char*)cryptAddress,_MAC_LENGTH*_MAX_ADAPTER_COUNT,(char*)&password,sizeof(password),(char*)encryptedAddress,&destLen);
		password = encrypt_hdd[product];
		memcpy(bufferok,m_crypto_buffer + sizeof(__int64)+ _MAC_LENGTH*_MAX_ADAPTER_COUNT,32);
		CAPIDecryptString((char*)bufferok,_MAX_SERIAL_COUNT+4,(char*)&password,sizeof(password),(char*)serial_hdd,&destLen);

		length_answer = 0;

		password = encrypt_answer[product];
		CAPIEncryptString((char*)&a2,sizeof(a2),(char*)&password,sizeof(password),(char*)bufferok,&destLen);
		memcpy(answer_filename,bufferok,destLen);
		length_answer += destLen;
		for(int i = 0; i < a2; i++)
		{
			if(m_macAddress_answer)
				memcpy(m_macAddress_answer[i],encryptedAddress[i],_MAC_LENGTH);
			CAPIEncryptString(encryptedAddress[i],_MAC_LENGTH,(char*)&password,sizeof(password),cryptAddress[i],&destLen);
			memcpy(answer_filename + length_answer,cryptAddress[i],destLen);
			length_answer += destLen;
		}
		if(m_serial_number_answer)
			memcpy(m_serial_number_answer,serial_hdd,_MAX_SERIAL_COUNT*sizeof(m_serial_number_answer[0]));
		CAPIEncryptString((char*)serial_hdd,_MAX_SERIAL_COUNT,(char*)&password,sizeof(password),(char*)bufferok,&destLen);
		memcpy(answer_filename + length_answer,bufferok,destLen);
		length_answer += destLen;
		memset(bufferok,0,destLen);
		end_of_license += PROTECTED_PERIOD_IN_SECONDS;
		if(end_license)
			*end_license = end_of_license;
		CAPIEncryptData((unsigned char*)&end_of_license,sizeof(end_of_license),(char*)&password,sizeof(password));
		memcpy(answer_filename + length_answer,&end_of_license,sizeof(end_of_license));
		length_answer += sizeof(end_of_license);
		if(is_real)
		{
			memcpy(answer_filename + length_answer,&is_trial,sizeof(is_trial));
			length_answer += sizeof(is_trial);
			// Generate the UUID for counting instances of sdk 
			UUID uuId;
			int retCode = RPC_S_OK;
			RPC_WSTR uuid_str = NULL;
			memset(&uuId,0,sizeof(uuId));
			UuidCreate(&uuId);
			retCode = UuidToStringW(&uuId,&uuid_str);
			if(retCode != RPC_S_OK)
			{
				uuid_str = (RPC_WSTR) new wchar_t[sizeof(UUID)*2+4];
				memcpy(uuid_str,L"11111111-2222-3333-4444-555555555555",(sizeof(UUID)*2+4)*sizeof(uuid_str[0]));
			}
			// write UUID into file 
			size_t random = wcslen((wchar_t*)uuid_str)*sizeof(uuid_str[0]);
//			fwrite(uuid_str,1,random,fff);
			memcpy(answer_filename + length_answer,uuid_str,random);
			length_answer += random;
			for(int i = random; i < (sizeof(UUID)*2+4)*sizeof(uuid_str[0]); i++)
			{
				memcpy(answer_filename+length_answer,"",1);
				length_answer++;
//				fwrite("",1,1,fff);
			}
			RpcStringFreeW(&uuid_str);
			// Write max instance count
//			fwrite(&m_instance_count,1,sizeof(m_instance_count),fff);
			memcpy(answer_filename + length_answer,&m_instance_count,sizeof(m_instance_count));
			length_answer += sizeof(m_instance_count);
			// Write additinal information
			if( (additional_info_length != 0) && (additional_info != 0))
			{
				long size_add = additional_info_length;
				CAPIEncryptData((snd_uchar*)&size_add, sizeof(size_add),(snd_char*)&password,sizeof(password));
				memcpy(answer_filename+length_answer,&size_add,sizeof(size_add));
				length_answer += sizeof(size_add);
				snd_uchar* temp_buf = NULL;
				temp_buf = new snd_uchar[additional_info_length];
				if(temp_buf != NULL)
				{
					memcpy(temp_buf,additional_info,additional_info_length);
					CAPIEncryptData(temp_buf, additional_info_length,(snd_char*)&password,sizeof(password));
					memcpy(answer_filename+length_answer,temp_buf,additional_info_length);
					length_answer += additional_info_length;
					delete[] temp_buf;
				}
			}

		}
		status =  true;
		if(is_old_format)
		{
			*is_old_format = is_real;
		}
	}
	catch(...)
	{
		;
	}
	if(bufferok)
		delete[] bufferok;	bufferok = NULL;
	if(m_crypto_buffer)
		delete[] m_crypto_buffer; m_crypto_buffer = NULL;
	return status;
}
