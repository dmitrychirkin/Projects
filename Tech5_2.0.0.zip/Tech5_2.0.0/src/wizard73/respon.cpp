/**************************************
				Respon.cpp
	Measure response for model flow.

			Author Gudkov V.U.
***************************************/

//	Header project file
#include		"inline73.h"
#include		"mathem73.h"
#include		"sorter73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local definitions
//-------------------------------------
enum
{
	_GRD_X = TEMP_T,
	_GRD_Y,
	_MODU_,
	_BETA_
};
	 
//-------------------------------------
//	Local tune constants
//-------------------------------------
static const		
int	Clevel =  H3,					//base level
	Cqueue =   3,					//length of queue
	C_zero =   7,					//addition
	Cloops =  75,					//scope for loop
	Cwhorl =  85,					//scope for whorl
	Cdelta =  80,					//scope for delta
	Cphase =  85;					//any scope

/**************************************
			Tune communications
**************************************/

//	Tune to measure gradient probability
void	CWork::ReTune( int dsth,int srch )
{
	Srco = GetLay(NORMAL, srch);	//normalized
	Snxo = GetLay(_BETA_, srch);	//gradient phase
	Sexo = GetLay(_MODU_, srch);	//gradient module
	Dsto = GetLay(PROB_M, dsth);	//refined probability
   if (integ)
   {
	   Dhpo = GetLay(FLOW_F, dsth);	//alpha
      Dnxo = GetLay(FCLASS, dsth);	//fclass
   }
	Dexo = GetLay(FLOW_V, dsth);	//victory flow
	Dfno = GetLay(FLOW_L, dsth);	//local flow
	Dwoo = GetLay(_GRD_X, dsth);	//x decompose
	Dmoo = GetLay(_GRD_Y, dsth);	//y decompose
	Deio = GetLay(PROB_G, dsth);	//gradient probability
}

//	Tune to calculate flower & quality
void	CWork::ReDeep( int dsth,int srch )
{
	Srco = GetLay( FLOW_M,srch );			//flow
	Shpo = GetLay( QUAL_S,srch );			//quality
	Sexo = GetLay( _GRD_X,srch );			//x decompose
	Sfno = GetLay( _GRD_Y,srch );			//y decompose
	Dsto = GetLay( FLOW_M,dsth );			//flow
	Dhpo = GetLay( QUAL_S,dsth );			//quality
   if (integ)
	   Dnxo = GetLay( FCLASS,dsth );			//fclass
	Dexo = GetLay( _GRD_X,dsth );			//x decompose
	Dfno = GetLay( _GRD_Y,dsth );			//y decompose
}

//-------------------------------------
//	Destroy communications
//-------------------------------------
template <class T>
static void destroyrespon( T *p )
{
	//destroy temporary lays
	p->DelLay( _GRD_X,p->Eche );
	p->DelLay( _GRD_Y,p->Eche );
	p->DelLay( _MODU_,p->Eche );
	p->DelLay( _BETA_,p->Eche );
}

/**************************************
		Bodies of service functions
**************************************/

//	Store quality, gradient
void	CWork::Respon( void )
{
	*Srco = 
	*Dsto = Orie;
	*Shpo =
	*Dhpo = Qual;
}

//	Store wave for gradient
void	CWork::ReWave( void )
{
	*Sexo = LIM( Grax+BA );
	*Sfno = LIM( Gray+BA );
}

/**************************************
		Virtual inner functions
**************************************/

//	Measure phase & module
void CWork::RePrep(void)
{
	int grax = -*p_Delim;//Fisuna( Srco );
	int gray = *p_Delim_c;//Fisunc( Srco );

	//calculate vector & phase
	*Snxo = atan(grax, gray)/2;
	*Sexo = dist(grax, gray)/4;
	++Rank[*Sexo]; //histogram
	//p_Delim++; p_Delim_c++;
}
//	Measure sorted gradient
void	CWork::ReGrad( void )
{
	//if a border
	if (Razors())		 return;

	//measure a scaled quality
	Qual = LIM ((*Sexo << 8 )/
							 Hypo );
	Qual = Lord[ Hypo ]*	//low
			 Rank[ Qual ] >> 8 ;

	//measure phases deviation
   if (integ)
   {
      switch (*Dnxo )
      {
	      case FL:	Args = cone( *Snxo*2,*Dhpo* 2 );
				      break;
	      case FW:	Args = cone( *Snxo*2,*Dhpo* 2 );
				      break;
	      case FD:	Args = cone( *Snxo*2,*Dfno+AR );
				      break;
	      default:	Args = cone( *Snxo*2,*Dexo+AR );
				      break;
      }
   }
   else
      Args = cone( *Snxo*2,*Dexo+AR );

   //pros and cons collection
	Pran += cogm( 
			  cogm( Qual,Args ),
							 Args );
	Qran += sigm( 
			  sigm( Qual,Args ),
							 Args );

	//builds probability queue
	if(Crop[Cqueue] < Qual  )
	{
		Crop[Cqueue] = Qual; isort( Crop,less,Cqueue );
	}
}

//	Smooth probability
void	CWork::ReFilt( void )
{
	//rebuild
	Respon();
	ReWave();
}

//	Final inward probability
void	CWork::ReFili( void )
{
	Replyi();
	Respon();
}

//	Final outward probability
void	CWork::ReFilo( void )
{
	Replyo();
	Respon();
}
				 
/**************************************
		Virtual upper functions
**************************************/

//	Result of gradient
void	CWork::ReCome( void )
{
	//quality model
   if (integ)
   {
	   switch (*Dnxo )
	   {
		   case FL:	Args = *Dhpo*2
								    +AR;
					   Open = Cloops;
					   break;
		   case FW:	Args = *Dhpo*2
							       +AR;
					   Open = Cwhorl;
					   break;
		   case FD:	Args = *Dfno ;
					   Open = Cdelta;
					   break;
		   default:	Args = *Dexo ;
					   Open = Cphase;
					   break;
	   }
   }
   else
   {
      Args = *Dexo ;
      Open = Cphase;
   }
	//a quality as probability
	Qual = cogm( Crop[Cqueue],Open*Qran/VON( Pran+Qran )) + C_zero;
	//do complex decomposition
	*Dwoo = LIM( cosm( Qual,Args*2 )/2 +BA );
	*Dmoo = LIM( sinm( Qual,Args*2 )/2 +BA );
	//do more specific quality
	*Deio = MAX( cogm( *Dsto,Open*Qran/VON( Pran+Qran )));
}

//	Prepare before measuring
int	CWork::RePrev( void )
{
	//the future filter reply
	ResDst( Crop,Cqueue + 1 );
	Rreset();
	return 1;  //goon measure
}

//	Smooth inner reply
int	CWork::Replyi( void )
{
	//measure complex impulse
	Grax = Fiimpn( Dexo )-BA;
	Gray = Fiimpn( Dfno )-BA;
	Orie = atan( Grax,Gray )/
								  2;
	Qual = dist( Grax,Gray );
	return 1;  //goon measure
}

//	Original outward reply
int	CWork::Replyo( void )
{
	//measure complex impulse
	Grax = (*Dexo - BA)	 /2;
	Gray = (*Dfno - BA)	 /2;
	Orie = atan( Grax,Gray )/
								  2;
	Qual = dist( Grax,Gray );
	return 1;  //goon measure
}

/**************************************
		Assemble <Respon> function
**************************************/
void Codex::Respon( int reih )
{
	//laws to amplifier the probability
	int low[] = {3, 15,0, 64,90, BM,BM};

	//if focuses wasn't defined
	if(GetKey(FCLASS, Clevel) == -1)
	{
		Ifocus(IfocuS); //previous works
	}

	//tune in respon queue
	OldLay(Tops = RESpon);
	Eche = Clevel;
	memset(Rank, 0, sizeof(Rank));

	//a gradient procedure
	p_Delim = I_Fisuna; 
   p_Delim_c = I_Fisunc;
	Snxo = GetLay(_BETA_, H0);	//gradient phase
	Sexo = GetLay(_MODU_, H0);	//gradient module
   memset (Snxo, 0, Size[0]);
   memset (Sexo, 0, Size[0]);
#ifdef SAVE_LAYERS
   saveLayer("respon__BETA_00.dat", _BETA_, 0);
   saveLayer("respon__MODU_00.dat", _MODU_, 0);
#endif	
	Reax = MaxX[H0];  
   Reay = MaxY[H0];
	Snxo += Reax; 
   Sexo += Reax; 
   p_Delim += Reax; 
   p_Delim_c += Reax;
	for(Srcy = 1; Srcy < Reay-1; Srcy++)
	{
		Snxo++; Sexo++; p_Delim++; p_Delim_c++;
		for(Srcx = 1; Srcx < Reax-1; Srcx++)
		{
			RePrep();
			Snxo++; 
         Sexo++; 
         p_Delim++; 
         p_Delim_c++;
		}
		Snxo++; 
      Sexo++; 
      p_Delim++; 
      p_Delim_c++;
	}

#ifdef SAVE_LAYERS
   saveLayer("respon__BETA_01.dat", _BETA_, 0);
   saveLayer("respon__MODU_01.dat", _MODU_, 0);
#endif	
	Snxo = GetLay(_BETA_, H0); 
   Sexo = GetLay(_MODU_, H0);
	unsigned char *temp_B =  GetLay(I_B, H0);
	unsigned char *temp_M =  GetLay(I_M, H0);
	memmove(temp_B, Snxo, Size[H0]); 
   memmove(temp_M, Sexo, Size[H0]);

	//get the part of Rank
	Hypo = RanSha(3) +  1;	
	I_Hypo = Hypo;

	//builds amplitude low
	RanMod(low); RanSmo(7);
	//memmove((void *)Rank, (void *)Flower_Rank, sizeof(Rank));
	LorLog();//contrast

	//a gradient procedure
	Docvie = (tvii)&CWork::ReTune;
	Docupi = (ti_v)&CWork::RePrev;
	Docisi = (tv_v)&CWork::ReGrad;
	Docfni = (tv_v)&CWork::ReCome;
	Scenew(  0,Eche,H0  );

	//do flower, quality
	for (Eche = Clevel; Eche > reih; Eche--)
	{
		//hierarchy projection
		Docvie = (tvii)&CWork::ReDeep;
		Docupi = (ti_v)&CWork::Replyi;
		Docupo = (ti_v)&CWork::Replyo;
		Docisi = Dociso = (tv_v)&CWork::ReFilt;
		Scenei(0,Eche,Eche-1);
	}

	//final small smothing
	Docvie = (tvii)&CWork::ReDeep;
	Docisi = (tv_v)&CWork::ReFili;
	Dociso = (tv_v)&CWork::ReFilo;
	Scenei(2, Eche, Eche);

#ifdef SAVE_LAYERS
   saveLayer("respon__BETA_.dat", _BETA_, 0);
   saveLayer("respon__MODU_.dat", _MODU_, 0);
   saveLayer("respon_I_B.dat", I_B, 0);
   saveLayer("respon_I_M.dat", I_M, 0);
   saveLayer("respon_PROB_M.dat", PROB_M, 3);
   saveLayer("respon_FLOW_F.dat", FLOW_F, 3);
   saveLayer("respon_FCLASS.dat", FCLASS, 3);
   saveLayer("respon_FLOW_V.dat", FLOW_V, 3);
   saveLayer("respon_FLOW_L.dat", FLOW_L, 3);
   saveLayer("respon__GRD_X.dat", _GRD_X, 3);
   saveLayer("respon__GRD_Y.dat", _GRD_Y, 3);
   saveLayer("respon_PROB_G.dat", PROB_G, 3);
   saveLayer("respon_FLOW_M.dat", FLOW_M, 3);
   saveLayer("respon_QUAL_S.dat", QUAL_S, 3);

   saveLayer("respon_FLOW_M_2.dat", FLOW_M, 2);
   saveLayer("respon_QUAL_S_2.dat", QUAL_S, 2);
   saveLayer("respon_FCLASS_2.dat", FCLASS, 2);
   saveLayer("respon__GRD_X_2.dat", _GRD_X, 2);
   saveLayer("respon__GRD_Y_2.dat", _GRD_Y, 2);

   saveLayer("respon_FLOW_M_1.dat", FLOW_M, 1);
   saveLayer("respon_QUAL_S_1.dat", QUAL_S, 1);
   saveLayer("respon_FCLASS_1.dat", FCLASS, 1);
   saveLayer("respon__GRD_X_1.dat", _GRD_X, 1);
   saveLayer("respon__GRD_Y_1.dat", _GRD_Y, 1);
#endif


	//destroy links
	for(Eche = Clevel; Eche >=  H0; Eche--)
	{
		//destroy a local link
		destroyrespon( this );
	}
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
