/**************************************
				Pickup.cpp
	Proves the more trustable flow.

			Author Gudkov V.U.
***************************************/

//	Header project file
#include		"mathem73.h"
#include		"moulds73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local distribution
//-------------------------------------
enum
{
	_TEMP_ = TEMP_T,
	_QUAL_
};

//-------------------------------------
//	Local tune constants
//-------------------------------------
static //const						
int	Cdelim[] = {3,8,370}, //delta,shake,limit
	Clevel	= H3,		  //level
	Cthres	= 54,		 //a sea
   Cclass	=  3;
static int Cwhirl = 4;	//whirl


void	CWork::PiTest( void )
{
   if(*Sexo & C2)
	   Pran += *Shpo;
   else
	   Qran += *Shpo;
}


/**************************************
			Tune communications
**************************************/
void CWork::PiTune(int dsth, int srch)
{
	Srco = GetLay(FLOW_L, srch); //local
	Shpo = GetLay(PROB_M, srch); //refined probability
	Sexo = GetLay(CCLASS, srch); //cclass
	Swoo = GetLay(_QUAL_, srch); //dinamic quality
	Smoo = GetLay(_TEMP_, srch); //dinamic steps
}

//-------------------------------------
//	Destroy communications 
//-------------------------------------
template <class T>
static void destroypickup( T *p )
{
	//destroy all temporary lays
	p->DelLay(_TEMP_, p->Eche);
	p->DelLay(_QUAL_, p->Eche);
}

/**************************************
			Gap functions
**************************************/
static inline int gapgap( byte *p )
{
	return (*p & CG) == 0;
}

/**************************************
			Cluster processing
**************************************/
void CWork::PiRing( int flow,int step )
{
	if((*Eoff < Star))
		 ++Quan[petx(flow - *Useo)];
}
/**************************************
		Rules to analize flow
**************************************/

//	Recognize reticence gradient
static inline int close( int *quan )
{
	return  (quan[0] && quan[4] ||
			 quan[1] && quan[5] ||
			 quan[2] && quan[6] ||
			 quan[3] && quan[7]);
}

//	Calculate arch max delta
static inline int delta( byte *goal,int *flow )
{
	return  MAX( Max4( cone(*goal,flow[0] ),
					   cone(*goal,flow[4] ),
					   cone(*goal,flow[2] ),
					   cone(*goal,flow[6] )),
				 Max4( cone(*goal,flow[1] ),
					   cone(*goal,flow[5] ),
					   cone(*goal,flow[3] ),
					   cone(*goal,flow[7] )));
}

//	Calculate arch max shake

static inline int shake( byte *goal,int *flow )
{
	return  MAX( MAS( scis(*goal,flow[0] ),
							scis(*goal,flow[4] ),
							scis(*goal,flow[2] ),
							scis(*goal,flow[6] )),
					 MAS( scis(*goal,flow[1] ),
							scis(*goal,flow[5] ),
							scis(*goal,flow[3] ),
							scis(*goal,flow[7] )));
}
//	Rule to classify the curvature
static inline int delim( byte *goal,int *flow )
{
	return  delta(goal, flow)*Cdelim[0] +
			  shake(goal, flow)*Cdelim[1];
}

//	Rule to classify gradient based on gauss replies
static inline int delim(int *asse, short delim_value)
{
	return cogm(asse[0]+asse[1]+asse[2]+asse[3]+asse[4]+asse[5]+asse[6]+asse[7],
		LIR(delim_value * AR/Cdelim[2]))/8;
}
/**************************************
	Virtual functions to classify flow
**************************************/

//	Prepare function
//	Measure area quality
void CWork::PiQual( void )
{
	//was flow proved?
	if(gapgap(Sexo))
	{
		if(*Shpo < 7) //here should be 7 + something. 20, 50 is okay for 91 but should not for all
		{
			*Swoo = *Shpo; *p_Delim = 400; p_Delim++; return;
		}
		//measure flows
		Joff = Shpo;
		DoMove(&Srco); DoKeep(&Useo);
		Treset(Re_v); Treset(Im_v); Treset(Ap_w);
		Spiral(Eche, Clas);
		Targum(Re_v, Im_v, Flow, Useo);
		Tmodul(Re_v, Im_v, Modu, Ap_w);

		//build local quality and find the best global quality
		*p_Delim = delim(Useo, Flow); //smaller -> better
		if(Thre < (*Swoo = MIN(*Shpo, delim(Modu, *p_Delim)))) //bigger -> better
		//if(Thre < (*Swoo = MIN(*Shpo, delim(Modu, Useo, Flow))))
			 Thre = *Swoo;
	}
	p_Delim++;
}
//	Prove kernal flow
void CWork::PiFlow( void )
{
	//if was not proved
	if(gapgap( Sexo ))
	{
		//check threshold
		if(*Swoo < Thre)
			return;
		if((!quick && Clas == Cwhirl) || (quick && Clas == Cclass))
		{
			*Sexo |= C2; *Smoo = 0; //up a class
		}
		else//if nearby prooved
		{
			if(FiBits(Sexo, C2))
			{			
				*Sexo |= C2; *Smoo = 0; GoOn = 1; //mark as C2 and continue
			}
		}
	}
}

//	Prove the whirls
void CWork::PiRingV(void)
{	
	if(gapgap(Sexo)) //if was not proved before
	{
		Eoff = Smoo;		
		DoMove(&Srco); DoKeep(&Useo);		
		Treset(Quan);
		Docexe = (tvii)&CWork::PiRing;
		Spiral(Eche, Clas);

		if(close(Quan))
		{
			if(Cdelim[2] > *p_Delim) //smaller -> better
			{
				*Sexo |= C3; *Smoo = Star;
			}
		}

	}
	p_Delim++;
}
/**************************************
		Assembly <Pickup> function
**************************************/
void CWork::PiEdgeAddP(void)
{
	p_Delim++;
}
void Codex::Pickup( int reih )
{
_DBG_INFO( "CONTROL POINT A\n" );
   if (quick)
   {
      Cdelim[0] = 3;
      Cdelim[1] = 8;
      Cdelim[2] = 370;
      Cthres	 = 40;
      Cwhirl    = 4;		
   }
   else
   {
      Cdelim[0] = 3;
      Cdelim[1] = 8;
      Cdelim[2] = 370;
      Cthres	 = 54;
      Cwhirl    = 4;
   }
_DBG_INFO( "CONTROL POINT B\n" );
	//if probability wasn't built
	if (GetKey( PROB_M,Clevel ) == -1)
	{		
      _DBG_INFO( "CONTROL POINT COHERING\n" );
		Cohere(CoherE);//previous works
	}
_DBG_INFO( "CONTROL POINT C\n" );
	//tune in pickup queue
	OldLay(Tops = PICkup),
	WiRect(Eche = Clevel);
_DBG_INFO( "CONTROL POINT D\n" );
	//prepare step & class
	Sexo = GetLay(CCLASS, Eche); 
   Smoo = GetLay(_TEMP_, Eche);
	memset(Sexo, 0, Size[Eche]); 
   memset(Smoo, BM, Size[Eche]);
_DBG_INFO( "CONTROL POINT E\n" );
	//dinamic kernal development of flower
  	int start = quick ? Cclass : Cwhirl;
   int stop = quick ? 0 : 1;
	for(Clas = start; Clas >= stop; Clas--)
	{
      Thre = quick ? Cthres : 0; //prepare

      if (quick)
      {
		   switch(Clas)
		   {
		   case 0: 
			   p_Delim = I_Fisunb;
			   break;
		   case 1: 
			   p_Delim = I_Fisunb + Size[Eche];
			   break;
		   case 2: 
			   p_Delim = I_Fisund;
			   break;
		   case 3: 
			   p_Delim = I_Fisund + Size[Eche];
			   break;
		   default: break;
		   }
      }
      else
      {
		   switch(Clas)
		   {
		   case 1: 
			   p_Delim = I_Fisunb;
			   break;
		   case 2: 
			   p_Delim = I_Fisunb + Size[Eche];
			   break;
		   case 3: 
			   p_Delim = I_Fisund;
			   break;
		   case 4: 
			   p_Delim = I_Fisund + Size[Eche];
			   break;
		   default: break;
		   }
      }
_DBG_INFO( "CONTROL POINT F\n" );
		//builds quality field
		Docvie = (tvii)&CWork::PiTune;
		Docisi = (tv_v)&CWork::PiQual;
  		Docexe = (tvii)&CWork::Argums_quick;
		Scener(Eche);
_DBG_INFO( "CONTROL POINT G\n" );
		//get a threshold quality
		Thre = PER(Cthres, Thre);
		do
		{	
			GoOn = 0;//stop deal
			//flood of kernal flow
			Docvie = (tvii)&CWork::PiTune;
			Docisi = (tv_v)&CWork::PiFlow;
			Scenei(2, Eche, Eche);
		}
		while (GoOn);
	}
_DBG_INFO( "CONTROL POINT H\n" );
	//dynamic development based on kernal
	for(Star = 1; Star < Cwhirl * 2; Star++)	
	{
		//law for attractor
		if(Star <= Cwhirl)
			Clas =  Star;
		else
			Clas =  Cwhirl + Cwhirl - Star;
		switch(Clas)
		{
		case 1: 
			p_Delim = I_Fisunb;
			break;
		case 2: 
			p_Delim = I_Fisunb + Size[Eche];
			break;
		case 3: 
			//p_Delim = I_Fisunc;
			p_Delim = I_Fisund;
			break;
		case 4: 
			p_Delim = I_Fisund + Size[Eche];
			break;
		default: break;
		}
		//flood of a curvature
		Docvie = (tvii)&CWork::PiTune;
		Docisi = (tv_v)&CWork::PiRingV;
		Dociso = (tv_v)&CWork::PiEdgeAddP;
		Scenei(2, Eche, Eche);
	}
_DBG_INFO( "CONTROL POINT I\n" );
#ifdef SAVE_LAYERS
   saveLayer("pickup_FLOW_L.dat", FLOW_L, 3);
   saveLayer("pickup_PROB_M.dat", PROB_M, 3);
   saveLayer("pickup_CCLASS.dat", CCLASS, 3);
   saveLayer("pickup__QUAL_.dat", _QUAL_, 3);
   saveLayer("pickup__TEMP_.dat", _TEMP_, 3);
#endif

	//destroy a local link
	destroypickup( this );
   
   // get image quality
   Pran = Qran = 1;
	Docvie = (tvii)&CWork::PiTune;
	Docisi = (tv_v)&CWork::PiTest;
	Scenei( 2,Eche,Eche );
   m_quality = Pran /(1 + (Pran + Qran) / 100);
_DBG_INFO( "CONTROL POINT K\n" );
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
