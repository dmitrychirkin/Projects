/**************************************
				Skelet.cpp
		 Refine binary image.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"mathem73.h"
#include		"moulds73.h"
#include		"retain73.h"
#include		"sorter73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local definitions
//-------------------------------------
enum
{
	_SOUR_ = REFINE,
	_NEXT_ = SKELET,
	_TEMP_ = TEMP_T
};

//-------------------------------------
//	Local tune constants
//-------------------------------------
static const 
 int	Clevel =  H1,					//native level
		CAngle =   6,					//angle delta
		CAnmax = 120;					//real (+-) /= 2

//	Table of masks to refine
//static const
//byte skeletMask[] =
//{
//	1, 12, 12, 36, 12,  1,  4,  1, 12,  9, 42,  0, 68,  1,  1,  1, //   0
//  12,  9,  9,  0,  1,  1,  1,  1, 36,  0,  0,  0,  1,  1,  1,  1, //  16
//  12,  9,  9,  0,  9, 66,  0,  0, 74,  8,  8,  0,  0, 66, 66,  0, //  32
// 100,  0,  0,  0,  1,  1,  1,  0,  1,  0, 34,  0,  1,  1,  1,  0, //  48
//  12,  1,  9,  1,  9,  1,  0,  1,  9, 66,  8, 34,  0,  1,  0,  1, //  64
//	1,  1, 34,  1,  1,  1,  1,  0,  1,  1, 34,  1,  1,  0,  1,  0, //  80
//  68,  1,  0,  1,  0,  1,  0,  0,  0, 66,  0,  0,  0,  1,  0,  0, //  96
//	1,  1,  0,  0,  1,  0,  0,  0,  1,  1,  0,  0,  1,  0,  0,  0, // 112
//  12,100, 10,  1,  9,  1,  0,  1,  9,  0,  8, 34,  0,  1,  2,  1, // 128
//   9,  0,  8,  0, 98,  1,  2,  1,  0,  0,  0,  0,  0,  0,  0,  0, // 144
// 106,  0,  8, 98,  8, 98,  0,  0,  8,  0,  1,  0,  0,  0,  0,  0, // 160
//	0,  0,  0,  0, 98,  1,  0,  0, 98,  0,  0,  0,  0,  0,  0,  0, // 176
//	4,  1,  0,  1,  0,  1,  0,  1,  0,  0,  0,  0,  0,  0,  0,  0, // 192
//	1,  1,  2,  1,  1,  0,  1,  0,  1,  0,  0,  0,  0,  0,  0,  0, // 208
//	1,  1,  2,  1,  0,  1,  0,  0, 66,  0,  0,  0,  0,  0,  0,  0, // 224
//	1,  1,  0,  0,  1,  0,  0,  0,  1,  0,  0,  0,  0,  0,  0,  0, // 240
//};
byte skeletMask[256];

/**************************************
		Tune Refine procedures
**************************************/

//	Tune to refine image
void	CWork::SkTune( int dsth,int srch )
{
	Srco = GetLay( Star ? _SOUR_ : _NEXT_,srch );
	Shpo = GetLay( Star ? _NEXT_ : _SOUR_,srch );
	Dsto = GetLay(	CCLASS,dsth );			//c-class
	Dhpo = GetLay(	_TEMP_,dsth );			//temporary
	Dnxo = GetLay(	GOAL_F,dsth );			//filter goal
	Dexo = GetLay(	GOAL_M,dsth );			//minutiae goal
	Dfno = GetLay(	DENSIT,dsth );			//density
	Dwoo = GetLay(	MORDER,dsth );			//m-class
	Dmoo = GetLay(	FLOW_E,dsth );			//flow-p
	Deio = GetLay(	GOAL_R,dsth );			//ridge goal
}

//-------------------------------------
//	Destroy comunications 
//-------------------------------------
template <class T>
static void destroyskelet( T *p )
{
	p->DelLay( _TEMP_,p->Eche );
}

/**************************************
		Split two closest lines
**************************************/
int	CWork::Splits( int nlen,int dirs )
{
	//if cross defined
	if(Crossd( nlen ))
	{
		//build direction from centre to point
		int flow[ 4 ];
		for(int i = 0; i < 4; i++)
		{
			flow[i] = atan(Arms[i].Movx-Usex, Arms[i].Movy-Usey);
		}

		//clockwize sort 4 points 
		CCopy copy; bsort(Arms, flow, less, 4);

		//select the best pairs to draw sceleton
		if(MAX( cone(Tdirec(Arms[0], Arms[1]), dirs),
				  cone(Tdirec(Arms[2], Arms[3]), dirs))<
			MAX( cone(Tdirec(Arms[0], Arms[3]), dirs),
				  cone(Tdirec(Arms[1], Arms[2]),dirs )))
		{
			copy.Repair(this, Arms[1]); //start
			Pastes(Arms[0].Movx,Arms[0].Movy );
			copy.Repair(this, Arms[3]); //start
			Pastes(Arms[2].Movx, Arms[2].Movy);
		}
		else
		{
			copy.Repair(this, Arms[3]); //start
			Pastes(Arms[0].Movx, Arms[0].Movy);
			copy.Repair(this, Arms[2]); //start
			Pastes(Arms[1].Movx, Arms[1].Movy);
		}
		//success
		return 1;
	}
	else
		//can not
		return 0;
}
/**************************************
		 Kernal virtual functions

**************************************/

//	New local work, man zone
//	Take off veil
static inline void noveil( byte *p )
{
	//if working area
	if (!(*p &   W5))
	{
		*p &= ~W1;
	}
}

void CWork::Ske_init(void)
{
	if(Hypo)
	{
		Docexe = (tvii)&CWork::Sketch;
		Reax = MaxX[Eche]; Reay = MaxY[Eche];
		Docexe = (tvii)&CWork::Sketch;
		for(Srcy = 0; Srcy < Reay; Srcy++)
		{
			for(Srcx = 0; Srcx < Reax; Srcx++)
			{
				if(*Snxo & W6)
				{
					Movo = Snxo; Movx = Srcx; Movy = Srcy;//DoMove(&Snxo);
					noveil(Movo);
					Spiral(Eche);
					*Snxo &= ~W6;
				}
				Snxo++;
			}
		}
		Docexe = &CBase::Deaden;
	}
}

/***************************************
		Resize local working areas
***************************************/

//	Resize working areas
void	CWork::Sketch( int flow,int step )
{
	noveil( Movo );
}

//	Delete superfluous pixel
void CWork::SkThin( void )
{
	//is a skeleton?
	if(*Srco > BS) 
	{
		*Shpo = BG; return;
	}
	//reset the masks
	int	mask_r = 0, mask_c = 0, mask_e = 0, mask_o = 0, mask_m = 0;
	//look nearest environment
	for(int dir = 0, msk = 1; dir < _DIR_; dir++, msk += msk)
	{
		//read pixel for translation
		int val = *(Srco + Vide[dir]);
		//build common mask
		if(val <= BX)//was
		{
			mask_c += msk;
			if(val <= BS)//now
			{
				mask_e += msk; mask_r += msk;
				if(val <= BE)//!!!
					mask_m  +=  msk;
			}
		}
		else
		{
            if(val == BM && !(dir & 1)) //sense the edge of an image
			{
				mask_c += msk; mask_e += msk; mask_o += msk;
			}
		}
	}//end of for(int dir = 0, msk = 1; dir < _DIR_; dir++, msk += msk)

	//trasform table masks
	mask_c = skeletMask[mask_c]; 
    mask_e = skeletMask[mask_e]; 
    mask_r = skeletMask[mask_r];
	mask_o = skeletMask[mask_o]; 
    mask_m = skeletMask[mask_m];

	//extract direction from situation..
	int i_mask_e = mask_e>>4;
	int i_mask_r = mask_r>>4;
	byte *curr = Srco + Vide[i_mask_e];
	byte *next = Shpo + Vide[i_mask_e];
	byte *scur = Srco + Vide[i_mask_r];
	byte *snex = Shpo + Vide[i_mask_r];
	
	if(mask_r & 8) //if a minutia //if(mask_r & 8 == 1)
	{
		if(mask_r & 4) //if the ending //if(mask_r & 8 == 1 && mask_r & 4 == 1)
		{	//was marked ?
			if(*Srco > BE)
				Proc |= Case |= 1;
			if(mask_c & 1) //if rich area
			{	//goon here
				Proc |= Case |= 1;
				*Shpo = BG; *Srco = BU; //set pixel
			}
			else//if near.. //if(!(mask_c & 1))
			{
				if(mask_m & 4)
				{	//goon here
					Proc |= Case |= 1;
					*Shpo = BG; *Srco = BX; //set pixel
				}
				else //set pixel
					*Shpo = *Srco = BE;
			}//end of if(mask_c & 1)
		}
		else//transfer //if( mask_r & 8 == 1 && mask_r & 4 == 0 )
		{
			if(mask_r & 2)
			{
				Proc |=	Case |= 1;	//continue
				*Shpo = BG; *Srco = BX;//set pixel
				if(*scur != BM)//working area? transfere
					*snex =	*scur = BU;
			}
			else//skeleton //if( (mask_r & 4) == 0  && (mask_r & 2) == 0 )
			{
				if(mask_r & 1)//if rich area
				{
					if(mask_o & 4)
					{	//goon here
						Proc |= Case |= 1;
						*Shpo = BG; *Srco = BU;//set pixel
					}
					else//set pixel
						*Shpo =	*Srco = BS;
				}
				else//bifurcation //if( (mask_r & 4) == 0  && (mask_r & 2) == 0 )
				{	//was marked ?
					if(*Srco > BE)
						Proc |= Case |= 1;
					*Shpo = *Srco = BB;	//set pixel
				}//end of if(mask_r & 1) else
			}//end of if(mask_r & 2) else
		}//end of if(mask_r & 4) else
	}
	else//protect //if(mask_r & 8 == 0)
	{
		if(mask_c & 4) //if(mask_r & 8 == 0 && mask_c & 4 == 1)
		{
			if(mask_e & 4)//protect area //if(mask_r & 8 == 0 && mask_c & 4 == 1 && mask_e & 4 == 1)
			{
				Proc |=	Case |= 1; //continue
				*Shpo = BG; *Srco = BU; //set pixel
				if(*curr != BM) //working area?
				{
					*next = BG; *curr = BX; //transfere
				}
			}
			else//hidrance //if(mask_e & 4 == 0)
				*Shpo =	*Srco = BU;
		}
		else//transfer //if(mask_c & 4 == 0)
		{
			if(mask_c & 2) //if(mask_c & 4 == 0 && mask_c & 2 == 1)
			{
				if(mask_e & 4) //protect area
				{
					Proc |=	Case |= 1; //continue
					*Shpo = BG; *Srco = BU; //set pixel				
					if(*curr != BM) //working area?
					{
						*next = BG; *curr = BX; //transfere
					}
				}
				else//transfer
				{
					if(mask_e & 2)
					{
						Proc |=	Case |= 1; //continue
						*Shpo = BG; *Srco = BX; //set pixel
						if(*curr != BM) //working area?
							*next =	*curr = BU; //transfere
					}
					else//hidrance
						*Shpo =	*Srco = BU;
				}//end of if(mask_e & 4) else
			}
			else//refine it //if(mask_c & 2 == 0)
			{
				if(mask_c & 1)
				{			
					if(mask_e & 4) //protect area //if(mask_c & 1 == 1 && mask_e & 4 == 1)
					{
						Proc |=	Case |= 1; //continue
						*Shpo = BG; *Srco = BU; //set pixel
						if(*curr != BM) //working area?
						{
							*next = BG; *curr = BX;//transfere
						}
					}
					else //transfer //if(mask_c & 1 == 1 && mask_e & 4 == 0)
					{
						if(mask_e & 2) //if(mask_e & 4 == 0 && mask_e & 2 == 1)
						{
							Proc |=	Case |= 1;	//continue
							*Shpo = BG; *Srco = BX; //set pixel				
							if(*curr != BM) //working area?
								*next =	*curr = BU;//transfere
						}
						else//refine //if(mask_e & 4 == 0 && mask_e & 2 == 0)
						{
							if(mask_e & 1)
							{
								Proc |=	Case |= 1; //continue
								*Shpo = BG; *Srco = BX; //set pixel
							}
							else//hidrance
								*Shpo =	*Srco = BU;
						}//end of if(mask_e & 2)
					}//end of if(mask_e & 4)
				}
				else//hidrance //if(mask_c & 1 == 0)
					*Shpo =	*Srco = BU;
			}//end of if(mask_c & 2) else
		}//end of if(mask_c & 4) else
	}//end of if(mask_r & 8) else
}

//	Correct minutiae branches
void CWork::SkBran( void )
{
	//if some ending
	if(*Srco == BE)
	{
		Narm = 0;

		Movo = Srco; Movx = Srcx; Movy = Srcy;
      if (quick)
      {
         Thre = *Dfno/1 - 1;
         Branch( Thre, *Dmoo );
      }
      else
         Branch(*Dfno, *Dmoo );
	}
}
//	Split two bifurcations
void CWork::SplitsV( void )
{
	//if bifurcation
	if(*Srco == BB)
	{
		//get start length
      Thre = *Dfno/2 + 2;
		do
		{
			DoMove(&Srco );
			DoKeep(&Useo );
		}
		while (!Splits( Thre,*Dmoo ) && --Thre > 0);
	}
}

//	Correct dumb-bels
void CWork::SkDumb( void )
{
	//if some ending
	if(*Srco == BE)
	{
		//get direction
		//DoMove(&Srco);
		Movo = Srco; Movx = Srcx; Movy = Srcy;
		Orient(*Dfno);
		//invert direction and verify phase of vectors
		if(simu(Orie = reci(Arms[0].Beta), *Dmoo))
			Orie = upci(*Dmoo );
		else
			Orie = reci(*Dmoo );
		//oscillate a ray and glue two endings
		for(int ang = 0,beta = Orie; ABS(ang) <= CAnmax;)
		{
			//sets position
			//DoMove(&Srco);
			Movo = Srco; Movx = Srcx; Movy = Srcy;
			//try to find existing anti-eye
         if (quick && SkeEnd(beta, Bresen_LookupCm[*Dfno+2][ABS(Orie-beta)]) ||
           (!quick && SkeEnd(beta, Bresen_LookupCm[*Dfno+1][ABS(Orie-beta)])))
//         if (SkeEnd(beta, Bresen_LookupCm[*Dfno+1][ABS(Orie-beta)]))
			{
				//get direction
				DoMove(&Useo); Orient(*Dfno);
				//verify ending antiorientation
				if(simu(Orie, Arms[0].Beta))
				{
					//glue skeleton
					Pastes(Srcx, Srcy); return;//exit
				}
			}
			//oscillate
			if(ang > 0)
				beta += (ang = -(ang + CAngle));
			else
				beta += (ang = -(ang - CAngle));
		}
	}
}
//	Checks hidrance
void CWork::SkHidr( void )
{
	if(*Srco > BS)
		return;
	Bask++; //if(*Srco <= BS)
	if(*Srco == BE)
	{
		//do farsee length
      if (quick)
		   Thre = *Dfno*7/10 + 1;
      else
		   Thre = *Dfno*7/10;
		//look around and verify the hidrance
		for(Orie = 0; Orie < AF; Orie += AQ)
		{	  
			//set position
			DoMove(&Srco);
			//control outward areas
			if(SkeOut(Orie, Thre))
			{
				*Dexo = 8; return;
			}
		}
		//using a bigger len		
      if (quick)
		   Thre = *Dfno*11/7 + 2;		
      else
         Thre = *Dfno*11/7;

		for(Orie = 0; Orie < AF; Orie += AQ)
		{	  
			//set positions
			DoMove(&Srco);
			//control outward region
			if(SkeOut(Orie, Thre))
			{
				*Dexo = 4; return;
			}
		}
		*Dexo = 2;
	}
	else
	{
		if(*Srco == BB)
		{
			//do farsee length
         if (quick)
			   Thre = *Dfno*11/7 + 2;
         else
			   Thre = *Dfno*11/7;
			//look around and verify outward area
			for(Orie = 0; Orie < AF; Orie += AQ)
			{	  
				//set positions
				DoMove(&Srco);
				//control outward region
				if(SkeOut(Orie, Thre))
				{
					*Dexo = 4; return;
				}
			}
			*Dexo = 2;
		}
	}
}
//	Rubout sceleton
void CWork::SkWipe( void )
{
	//rubout all...
	if(*Dnxo & W5)
		return;
	//	*Srco = 
	//	*Shpo =  BM;
	//else//renew gap
	if(*Srco != *Shpo)
		*Dnxo |= W6;
}

/**************************************
		 Virtual upper functions
**************************************/

//	Check kind of the work
int	CWork::SkKind( void )
{
	//check events
	switch (*Dnxo)// & ~W6)
	{
		case W2: //real work
		case W4: Case  = 0;
				 return   1;
		//case W5:	//skip work
		//			*Dhpo  = 0;
		default: return   0;
	}
}
////	Group local signs
void CWork::SkArea( void )
{
	//recognize outward
	if(*Snxo & W5)
		return;
	if(*Srco || check_neighbor(Srco))
		*Snxo &= ~W1;
	else
		*Snxo |=  W1;
}
//	Recognize border areas
int	CWork::SkEdge( void )
{
	if (*Dsto & C6)
		return 1;//OK
	else
		return 0;//OK
}
//	Limit oneself man work
//	Remark area to refine
void	CWork::SkGoonV( void )
{
	*Dhpo = Case;
}

int	CWork::SkHarm( void )
{
		return  1;
}
//	Get minutiae's area
int	CWork::SkSign( void )
{
	*Dnxo |=  W3; //lock
	Bask = 0;
	return 1;
}

//	Mark skeleton area
void	CWork::SkMark( void )
{
	//exist ?
	if (Bask) 
		*Deio =~0;
	else
		*Deio = 0;
}

/**************************************
		Intellectual image refining
**************************************/
bool CWork::check_neighbor(unsigned char *src)
{
	//do gather & scaling
	if(*(src + 1)) return true;
	if(*(src - 1))  return true;
	if(*(src + Indx)) return true;
	if(*(src + Redx)) return true;
	if(*(src + Dedx))  return true;	
	if(*(src - Indx))  return true;
	if(*(src - Redx))  return true;
	if(*(src - Dedx))  return true;
	return false;
	//inf[8] = *(src);
}

void Codex::Skelet(int reih)
{
	//if filter did not work
	if (GetKey( GOAL_I,Clevel ) == -1)
	{
		//previous works
		Filter( FilteR );
	}
	//tune in skelet queue
	OldLay(Tops = SKElet);
	WiRect(Eche = Clevel, 0);

	//compact recursive refining
	unsigned char *original_temp = GetLay(_TEMP_, Eche);//temorary
	unsigned char *original_goal_f = GetLay(GOAL_F, Eche);//filter goal
	unsigned char *original_goal_m = GetLay(GOAL_M, Eche);//minutiae goal

	for(Hypo = 0,Star = 1; ; Hypo++)
	{
		memset(original_temp, 0, Size[Eche]);
		//memset(original_goal_m, 0, Size[Eche]);
		Snxo = original_goal_f;
		Ske_init();

		//iterative procedures
		for(Proc=1; Proc; Star = !Star)
		{
			Proc = 0;//try to stop

			//skeletonize kernel..
			Docvie = (tvii)&CWork::SkTune;
			Docisi = (tv_v)&CWork::SkThin;
			Docupi = Docupo = (ti_v)&CWork::SkKind;
			Docfni = Docfno = (tv_v)&CWork::SkGoonV;
			Scenei(0, Eche, H0);

			//skeletonize kernel..
			Snxo = original_goal_f; Srco = original_temp;
			//Docvie = (tvii)&CWork::SkGoon;
			Docisi = (tv_v)&CWork::SkArea;
			Scener(Eche);
		}

		//if after corrections
		if(Hypo) break;

		//cutout short branche
		Docvie = (tvii)&CWork::SkTune;
		Docisi = (tv_v)&CWork::SkBran;
		Docupi = (ti_v)&CWork::SkHarm;
		Scenew(  0,Eche,H0  );

		//splits merged ridges
		Docvie = (tvii)&CWork::SkTune;
		Docisi = (tv_v)&CWork::SplitsV;
		Docupi = (ti_v)&CWork::SkHarm;
		Scenew(0, Eche, H0);

		//correct dumb-bells..
		Docvie = (tvii)&CWork::SkTune;
		Docisi = (tv_v)&CWork::SkDumb;
		Docupi = (ti_v)&CWork::SkHarm;
		Scenew(0, Eche, H0);

		//wipe border skeleton
		Docvie = (tvii)&CWork::SkTune;
		Docisi = (tv_v)&CWork::SkWipe;
		Docupi = (ti_v)&CWork::SkEdge;
		Scenew(0, Eche, H0);
	}

	//mark ending-hidrance
	memset(original_goal_m, 0, Size[Eche]);

	Docvie = (tvii)&CWork::SkTune;
	Docisi = (tv_v)&CWork::SkHidr;
	Docupi = (ti_v)&CWork::SkSign;
	Docfni = (tv_v)&CWork::SkMark;
	Scenew(0, Eche, H0);

	//destroy a local link
	destroyskelet( this );
	
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
