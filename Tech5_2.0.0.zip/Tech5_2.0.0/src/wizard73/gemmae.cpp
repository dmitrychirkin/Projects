/**************************************
				Gemmae.cpp
		Some source for kernal.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"assert.h"
#include		"mathem73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

/**************************************
			Special functions 
		for kernal of convolution
**************************************/

//	Get part of radius as angle
static inline int circle( int angx,int angy )
{
	return	dist( angx,angy );
}

//	Get wide of trench as angle
static inline int trench( int angx,int angy,int flow )
{
	return   cosm( angx,flow )+
				sinm( angy,flow );
}

//	Get part of observation as angle
static inline int observ( int angx,int angy,int flow )
{
	//measure wide of the strip
	flow = trench( angx,angy,
							  flow );
	//cut out figure of kernal!
	if (ABS(flow) > 45)	return AF;

	//get a tier into the strip
	return circle( angx,angy );
}

//	Generate kernal of convolution
static inline int kernal( int angx,int angy,int flow,int type )
{
	//parse type
	switch (type)
	{
		case	0:	return circle( angx,
										angy );
		case	1:	return observ( angx,
										angy,
										flow );
	}
    return -1;
}

/**************************************
	Generator for planar convolution
**************************************/
int	CWork::GemWeb( SStep *web,int size,int hier,int flow,int type )
{
	//local data..
	int	sum = 0,
			j = 0, i = 0;

	//look over y axe
	for (int y = -size; y <= size; y++)
	{
		//look over x axe
		for (int x = -size; x <= size; x++)
		{
			//get center position
			if (!(x || y)) j = i;

			//transform positions
			int beta = kernal( AH*x/size,
									 AH*y/size,flow,type );
			//angle - form
			if(beta <= AH) 
			{
				sum +=
				web[i].Dose = cosm( Dose,Corn[beta] );
				web[i].Movx = x;
				web[i].Movy = y;
				web[i].IncO = MaxX[ hier]*y+x;//offset
				i++;
			}
		}
	}

	//set up end of list
	web[i].IncO  =  0  ;
	//calc average value
	sum  = DIP( sum,i );

	//away average value
	int err;
	for (err = 0; --i >= 0; )
		err += web[i].Dose -= sum;

	//save final balance
	return	 web[j].Dose -= err;
}

/**************************************
		Source complex collections
**************************************/

//	Collect complex weighed arguments
void CWork::Argums(int flow, int step)
{	
	//calculate influence upon each petal
   for (int i = 0,beta = *Useo*Util,prob; i < _DIR_; i++,beta += AQ)
   {
	   //define weighed influence to the sector
	   if( (prob = Argums_Lookup0[turn(beta,flow)]) > 0)
	   {
		   //decomposition			
         Re_v[i] += cosm( *Joff*prob,*Movo*2 );
         Im_v[i] += sinm( *Joff*prob,*Movo*2 );

		   //specific list
		   Ap_w[i] += prob;
	   }
   }
}

void CWork::Argums_quick(int flow, int step)
{	
	//calculate influence upon each petal
   for (int i = 0,beta = *Useo*Util,prob; i < _DIR_; i++,beta += AQ)
   {
	   //define weighed influence to the sector
	   if( (prob = Argums_Lookup0[turn(beta,flow)]) > 0)
	   {
		   //decomposition			
		   Re_v[i] += ((*Joff*prob)* Argums_LookupCosm[*Movo] + ARGUMS_COSM_SCALE_HALF )/ARGUMS_COSM_SCALE;
		   Im_v[i] += ((*Joff*prob)* Argums_LookupSinm[*Movo] + ARGUMS_SINM_SCALE_HALF )/ARGUMS_SINM_SCALE;

		   //specific list
		   Ap_w[i] += prob;
	   }
   }
}

void CWork::Argums_NoApw(int flow, int step)
{	
	//calculate influence upon each petal
	for(int i = 0,beta = *Useo*Util,prob; i < _DIR_; i++,beta += AQ)
	{
		if( (prob = Argums_Lookup0[turn(beta,flow)]) > 0)
		{
         Re_v[i] += cosm( *Joff*prob,*Movo*2 );
         Im_v[i] += sinm( *Joff*prob,*Movo*2 );
		}
	}
}
void CWork::Argums_NoApw_quick(int flow, int step)
{	
	//calculate influence upon each petal
	for(int i = 0,beta = *Useo*Util,prob; i < _DIR_; i++,beta += AQ)
	{
		if( (prob = Argums_Lookup0[turn(beta,flow)]) > 0)
		{
			Re_v[i] += ((*Joff*prob)* Argums_LookupCosm[*Movo] + ARGUMS_COSM_SCALE_HALF )/ARGUMS_COSM_SCALE;
			Im_v[i] += ((*Joff*prob)* Argums_LookupSinm[*Movo] + ARGUMS_SINM_SCALE_HALF )/ARGUMS_SINM_SCALE;
		}
	}
}

void CWork::Argums_I (int flow, int step)
{
	int prob;
	int beta = *Useo*Util;
	if( (prob = Argums_Lookup0[ turn(beta,flow)]) > 0)
	{
      Re_v[0] += cosm( *Joff*prob,*Movo*2 );
      Im_v[0] += sinm( *Joff*prob,*Movo*2 );
	}

	beta += 180;
	if( (prob = Argums_Lookup0[ turn(beta,flow)]) > 0)
	{
      Re_v[4] += cosm( *Joff*prob,*Movo*2 );
      Im_v[4] += sinm( *Joff*prob,*Movo*2 );
	}
}

void CWork::Argums_I_quick(int flow, int step)
{
	int prob;
	int beta = *Useo*Util;
	if( (prob = Argums_Lookup0[ turn(beta,flow)]) > 0)
	{
		Re_v[0] += ((*Joff*prob)* Argums_LookupCosm[*Movo] + 
				ARGUMS_COSM_SCALE_HALF )/ARGUMS_COSM_SCALE;
		Im_v[0] += ((*Joff*prob)* Argums_LookupSinm[*Movo] + 
				ARGUMS_SINM_SCALE_HALF )/ARGUMS_SINM_SCALE;
	}

	beta += 180;
	if( (prob = Argums_Lookup0[ turn(beta,flow)]) > 0)
	{
		Re_v[4] += ((*Joff*prob)* Argums_LookupCosm[*Movo] + 
				ARGUMS_COSM_SCALE_HALF )/ARGUMS_COSM_SCALE;
		Im_v[4] += ((*Joff*prob)* Argums_LookupSinm[*Movo] + 
				ARGUMS_SINM_SCALE_HALF )/ARGUMS_SINM_SCALE;
   }
}


//	Collect twist in area
void	CWork::Twists_I( int flow,int step )
{
	//rotate center of curve
	for(int i = 0,beta = *Useo*2; i < _DIR_ ; i++,beta += AQ)
	{
		//collect clashing
		Tw_v[i] += Corn[AR + coor(beta, *Movo*2)/2];
	}
	Area++;
}

//	Collect twist in area
void	CWork::Twists( int flow,int step )
{
	//rotate center of curve
	for (int i = 0,beta = *Useo*2; i < _DIR_ ; i++,beta += AQ)
	{
		//collect clashing
		Tw_v[i] += Corn[AR + coor(beta, *Movo*2)/2]*2;
		Quan[i]++;
	}
}

/**************************************
			Update flow regulation
**************************************/

//	Kernal to re-join original regularity
int	CWork::GemReg( byte *arg,byte *mod,int beta )
{
	//find nearest flow based on image regularity
	int imax = 0;
	for (int i = 0,bask = 0; i < 4; i++)
	{
		int qual = *ProSrc(PROB_R+i,Eche,
											 Eche );
		int args = *ProSrc(FLOW_R+i,Eche,
											 Eche );
		int tval =  cogm  ( qual,
						scis  ( args, beta ) );

		//finds quality
		if(bask < tval)
		{
			bask = tval;
			*arg = args;
			*mod = qual;
		}
		//finds maximum
		if(imax < qual)
			imax = qual;
	}
	//this maximum
	return	imax;
}

int	CWork::GemReg_I(byte *arg, byte *mod, int beta)
{
	int imax = 0;
	for (int i = 0,bask = 0; i < 4; i++)
	{
		int qual = *PR_4[i];//ProSrc(PROB_R+i,Eche, Eche );
		int args = *FR_4[i];//ProSrc(FLOW_R+i,Eche, Eche );
		int tval = cogm(qual, scis(args, beta));

		//finds quality
		if(bask < tval)
		{
			bask = tval; *arg = args; *mod = qual;
		}
		//finds maximum
		if(imax < qual)
			imax = qual;
	}
	//this maximum
	return	imax;
}
void CWork::GemReg_Stream_1(byte *arg, byte *mod, int beta)
{
	//int imax = 0;
	for (int i = 0,bask = 0; i < 4; i++)
	{
		int qual = *PR_4[i];
		int args = *FR_4[i];
		int tval = cogm(qual, scis(args, beta));

		//finds quality
		if(bask < tval)
		{
			bask = tval; *arg = args; *mod = qual;
		}
	}
}


#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
