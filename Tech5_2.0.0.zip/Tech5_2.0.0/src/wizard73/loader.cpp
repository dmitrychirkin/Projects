/**************************************
				Loader.cpp
		Load image to the kernal.

			Author Gudkov V.U.
**************************************/

//	Header files
#include		"inline73.h"
#include		"mathem73.h"
#include		"sorter73.h"
#include		"wizard73.h"
#include		"wibase73.h"
//#include		"parity73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local tune constants
//-------------------------------------
static const
int	Cpaper = 238;					//paper bright

/**************************************
		Verify status of work
**************************************/
static inline int status( SData &inf )
{
	//look throw image
	for (int i = 0; i < inf.Size_X*inf.Size_Y-BM; i++)
		inf.Status -=	  inf.Irefer[ i+=inf.Irefer[i]];

	//must be zero !!!
	return inf.Status;
}

/**************************************
		Normalize histogram
**************************************/

//	Collect image histogram
static inline void getimg( byte *src,int size, int *buf )
{
	for (register int i = 0; i < size; i++)	++buf[src[i]];
}

//	Rebuild image histogram
static inline void setimg( byte *src,int size, int *buf )
{
	for (register int i = 0; i < size; i++)			src[i] = 
													  buf[src[i]];
}

/**************************************
		Simple inline function
**************************************/

//	Build moving table for a direction
static inline void dir( SMove &tbl,int dr,int ix,int iy,int io,int fx,int fy )
{
	tbl.IncX[dr] = ix; 
	tbl.IncY[dr] = iy; 
	tbl.IncO[dr] = io; 
	tbl.FroX[dr] = fx; 
	tbl.FroY[dr] = fy; 
}

//	Verify type of image
static inline int ver( byte type, const char *src )
{
	//parse src
	while (*src) 
		if (type == *src++)	return 1;
									return 0;
}

//	Translate bits of byte
static inline byte get( byte *src,byte bits )
{
	return (!bits) ? *src : 
						 (*src & bits) ? BM : 0;
}

/**************************************
	Kernal procedures to resize image
**************************************/

//	Tune pyramid parameters
inline void	Codex::TunePi( void )
{
		MaxX[0] = Redx;//the x
		MaxY[0] = Redy;//the y

	//build hierarchy parameter
	int i;
	for (i = 1; i < ECHEM; i++)
	{			
		MaxX[i] = MaxX[i-1]/2+
					 MaxX[i-1]%2;
		MaxY[i] = MaxY[i-1]/2+
					 MaxY[i-1]%2;
	}

	//build hierarchy parameter
	for (int j = 0; j < ECHEM; j++)
	{
		Size[j] = MaxX[j]*
					 MaxY[j];
		Side[j] = 1 << j ;
	}

	//----------------------------------
	//	build hierarchy table
	//----------------------------------
	for (int l = 0; l < ECHEM; l++)
	{
		dir( Move[l], 0, 1, 0,			 1,MaxX[l]-1,		  -9 );
		dir( Move[l], 1, 1, 1, MaxX[l]+1,MaxX[l]-1,MaxY[l]-1 );
		dir( Move[l], 2, 0, 1, MaxX[l]  ,		 -9,MaxY[l]-1 );
		dir( Move[l], 3,-1, 1, MaxX[l]-1,		  0,MaxY[l]-1 );
		dir( Move[l], 4,-1, 0,			-1,		  0,		  -9 );
		dir( Move[l], 5,-1,-1,-MaxX[l]-1,		  0,			0 );
		dir( Move[l], 6, 0,-1,-MaxX[l]  ,		 -9,			0 );
		dir( Move[l], 7, 1,-1,-MaxX[l]+1,MaxX[l]-1,			0 );
	}
}

//	Get size of pyramid in bytes
inline int	Codex::SizePi( void )
{
	//calculate the pyramid
	int size = 0,i = 0;
	for (; i < ECHEM; i++)
				size += Size[i]*LayN[i];
	return	size;
}

//	Tune fields of echelons
inline void	Codex::TuneFi( byte *src )
{
	//pyramid hierarchy pointers
	for (int i = 0; i < ECHEM; i++)
	{
		//pyramid lay pointer & reset
		for (int j = 0; j < LayN[i]; j++,src += Size[i])
		{
			Hier[i].Lays[j] = src;
			Hier[i].Keys[j] =  -1;
			Hier[i].Clks[j] =  -1;
		}
	}
}

//	Tune quick access
inline void	Codex::TuneQu( void )
{
	//initialize quick tables access
	for (int i = 0; i < MAX( Reax,Reay ); i++)
		Stab[i] = i*Reax;
	for (int j = 0; j < MAX( Redx,Redy ); j++)
		Dtab[j] = j*REMAIN*
						ImgDPI/
						ManDPI;
}

//-------------------------------------
//	Calculate pixel transformation
//-------------------------------------
void	Codex::APixel( byte *dst,byte *src,byte bits )
{
	//transformed from turning matrix
	int	posx = Dtab[Dstx]-Dtab[Redx/2], tmpx = posx;
	int	posy = Dtab[Dsty]-Dtab[Redy/2], tmpy = posy;	

	//rotation?
	if (ManDir)
	{
		posx = cosm( tmpx,ManDir )-sinm( tmpy,ManDir );
		posy = sinm( tmpx,ManDir )+cosm( tmpy,ManDir );
	}

	//calc goal new coordinates
	Srcx = Reax/2 + posx/REMAIN;
	Srcy = Reay/2 + posy/REMAIN;

	//if an outward original position
	if ( Srcx >=  Reax || Srcx < 0 ||
		  Srcy >=  Reay || Srcy < 0 )
		  //build the outward position
		  *dst  = (!bits) ? 
					 (uran() >> 12) +
								  Yard : BM;
	else
	{
		//calc weight for new position
		int dx = ABS(posx)&(REMAIN-1),
			 cs = 0,
			 dy = ABS(posy)&(REMAIN-1);

		//get delta for [x&y] position
		int nx = (posx >  0) ?  1 :
					(posx <  0) ? -1 : 0,
			 ny = (posy >  0) ?  1 :
					(posy <  0) ? -1 : 0,
			 jy =  Reax*ny, a, b, c, d;

		//define original source refer
		Prjo = src +Srcx +Stab[Srcy ];
		a = b = c = d =   get( Prjo,
									  bits );

		//check one x position
		if (Srcx+nx <  Reax &&
			 Srcx+nx >= 0	  ) cs += 1;
		//check one y position
		if (Srcy+ny <  Reay &&
			 Srcy+ny >= 0	  ) cs += 2;

		//verify <xy> position
		if (cs == 3)
		{
			b = get( Prjo+nx   ,bits );
			c = get( Prjo+   jy,bits );
			d = get( Prjo+nx+jy,bits );
		}
		else//get <y> position
		if (cs == 2)
			c = get( Prjo+   jy,bits );
		else//get <x> position
		if (cs == 1)
			b = get( Prjo+nx   ,bits );

		//calculate the bright
		if (a == b&& b == c&& c == d)
			*dst = a;
		else
			//calculate pixel value
			*dst = ((a*(REMAIN-dx) + b*dx)*(REMAIN-dy) +
					  (c*(REMAIN-dx) + d*dx)*dy)/(REMAIN*REMAIN);
	}
	//restore
	if (bits) 
	{
		//mark the bits
		if(*dst > BA  ) 
			*dst = bits;
		else
			*dst = C0  ;
	}
}

//-------------------------------------
//	Construct transformed image
//-------------------------------------
void	Codex::Loader( byte *dst,byte *src,int eche,byte bits )
{
	//do pointer, verify
	if ((Dsto = dst) && (Srco = src));
	else								return;

	//simple quick copy?
	if (ManDPI == ImgDPI && !ManDir )
	{
		//the simple copy
		if (Redx == Reax)
			StrSrc( Dsto,Srco,Redx*Redy );
		else
		//scan the new image buffer along y
		for (Dsty = 0; Dsty < Redy; Dsty++)
		{
			StrSrc( Dsto,Srco,Redx );
			Dsto += Redx;
			Srco += Reax;
		}
	}
	else
	{
		//allocate memory for quick image processing
		if ((Stab = new int[MAX( Reax,Reay )]) == 0)
			throw What = DEFMEM;
		if ((Dtab = new int[MAX( Redx,Redy )]) == 0)
			throw What = DEFMEM;

		//tune in
		TuneQu();

		//scan the new image buffer along y
		for (Dsty = 0; Dsty < Redy; Dsty++)
		{
			//scan the new image buffer along x, calc
			for (Dstx = 0; Dstx< Redx; Dstx++,Dsto++)
			{
				//verify draw rectangle
				if(InRect( Dstx<< eche, Dsty<< eche )) 
				{
					APixel( Dsto,Srco,
									 bits );
				}
			}
		}
		//clear !
		DelTab();
	}
}

/**************************************
		Read image & resize image
**************************************/
int	Codex::GetTip( SData &inf )
{
	//parameter reading
	Reax = inf.Size_X;
	Reay = inf.Size_Y;
	Srco = inf.Irefer;

	//set outward pixel
	Yard = Cpaper		;

	//get xy image size
	Redx = (ABS(cosm( Reax,ManDir )) + 
			  ABS(sinm( Reay,ManDir )))*ManDPI/
												 ImgDPI;
	Redy = (ABS(sinm( Reax,ManDir )) + 
			  ABS(cosm( Reay,ManDir )))*ManDPI/
												 ImgDPI;

	//cerealize xy size
	Redx-= Redx% GRAIN;
	Redy-= Redy% GRAIN;

	TunePi(); //pyramid 
	WiRect(); //regions

	//verify a finger print 
	if (ver( ImType,"LF" ))
	{
		//check image size - else don't continue
		if (MaxX[0] > _MAL_X || MaxY[0] > _MAL_Y)
			throw What = BIGIMG;
		if (MaxX[0] < _MIN_X || MaxY[0] < _MIN_Y)
			throw What = STUMPS;
	}

	//check palm print size
	if (ver( ImType,"PS" ))
	{
		//check image size - else don't continue
		if (MaxX[0] > _MAX_X || MaxY[0] > _MAX_Y)
			throw What = BIGIMG;
		if (MaxX[0] < _MIN_X || MaxY[0] < _MIN_Y)
			throw What = STUMPS;
	}

	//allocate main pyramid
   int sizePiramid = SizePi();
	if ((Dsto = new byte[sizePiramid]) == 0)
		throw What = DEFMEM;
   memset(Dsto, 0, sizePiramid);

	if(!(I_Fisuna = new short [Size[0]]))
		throw What = DEFMEM;
   memset(I_Fisuna, 0, Size[0]);

	if(!(I_Fisunb = new short [Size[0]]))
		throw What = DEFMEM;
   memset(I_Fisunb, 0, Size[0]);

	if(!(I_Fisunc = new short [Size[0]]))
		throw What = DEFMEM;
   memset(I_Fisunc, 0, Size[0]);

	if(!(I_Fisund = new short [Size[0]]))
		throw What = DEFMEM;
   memset(I_Fisund, 0, Size[0]);

   if(!(I_Fisunac = new short [Size[0]]))
		throw What = DEFMEM;
   memset(I_Fisunac, 0, Size[0]);

	//tune echelons
	TuneFi( Dsto );
	RanIni(		 );

	//generate a source lay
	Loader( GetLay( SOURCE,H0 ),Srco,H0 );
	//collect the histogram
	getimg( GetLay( SOURCE,H0 ),Size[H0],
										 Rank		);

	//----------------------------------
	//	verify and define new histogram
	//----------------------------------
	if (ver( ImType,"LFPS" ))
	{
		//verify special status
		if (status( inf ))
			throw	What = STATUS;

		//look spectrum impulse
      if (quick)
      {
//         if(RanImp( BM ) > 0x8f)
  //          throw	What = NOTIMG;
      }
      else
      {
//         if(RanImp( BM ) > 0x9f)
  //          throw	What = NOTIMG;
      }

			//measures
			RanSmo(1);
			RanSmo(3);
			RanSmo(1);
			RanBeg(6);
			RanEnd(9);

		//verify spectrum limit
	   if (Rlim - Llim > 0xf0)
			RanOrg();
		else
		if (Rlim - Llim > 0x10)
			RanRes();
		else
			throw	What = NOTIMG;
	}
	else//original
			RanOrg();

	//rebuild the histogram
	setimg( GetLay( SOURCE,H0 ),Size[H0],
										 Rank		);

	//final success 
	return  SUCCES;
}

/**************************************
		Quick process loading
**************************************/
int	Codex::Loader( SData &inf, const int *lay, bool ISO_compatibe)
{
	quick = false;//quickProcessing;
   m_ISO_compatibe = ISO_compatibe;
   m_quality = 0;

	//clear the pointer
	CBase	::  DelDoc();
	CBase	::  DelTab();
	CBase	::  ResDoc();
	CBase	::  Resume();

	//reset my document
	Codex	::  ResDoc();
	CWork	::  ResDoc();

	//set anything info
	ImType= inf.ImType;
	Number= inf.Number;
	ImgDPI= inf.ImgDPI;
//   if (quick)
  //    ImgDPI = (int)(ImgDPI * K_CHANGE_DPI);
	ManDPI= inf.ManDPI;
	ManDir= inf.ManDir;
	TipNet= inf.TipNet;
	Shrink= inf.Shrink;

	//verify a topology
	if(TipNet > NETMAX)
		TipNet = NETMAX;
	//verify a topology
	if(TipNet < NETMIN)
		TipNet = NETMAX;
		TipNet|= 1; //ok

	//image working Dir
	if (ver( ImType,"LFPST"))
		ManDir = DEFDIR;

	//image working DPI
	if (ver( ImType,"LFPS" ))
		ManDPI = DEFDPI;
	else
	if (ver( ImType,"T" )   )
		ManDPI = LIMDPI;
	else
	if(!ver( ImType,"A" )   )
		return	UNTYPE;

	//up processing DPI
	inf.ManDir= ManDir;
	inf.ManDPI= ManDPI;
	inf.TipNet= TipNet;

	//build echelon map
	if (!lay)
		SetMap(	PyrL );
	else
		SetMap(	lay  );

	//set working image
	try
	{
		GetTip(  inf  );
   
#ifdef SAVE_LAYERS
      saveLayer("loader_SOURCE.dat", SOURCE, 0);
#endif
		//goal - success
		return	SUCCES;
	}

	//exception handling
	catch( int nerr )
	{
		//clear pointers
		CBase::DelDoc();
		CBase::DelTab();
		CBase::ResDoc();

		return nerr;//ok
	}
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
