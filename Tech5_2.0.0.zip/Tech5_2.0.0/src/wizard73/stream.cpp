/**************************************
				Stream.cpp
 Measure stream based on regular line.

			Author Gudkov V.U.
***************************************/

//	Header files
#include		"assert.h"
#include		"mathem73.h"
#include		"moulds73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local tune constants
//-------------------------------------
static 
 int	tabrun[] = {15,13,11,10,9,0},
				Clevel	=  H3,				//level
				C_tail	= 130,				//arch twist
				Cnoise	=   7,				//noise
				tabclu[] = { 1, 1, 1, 1,0,0}; 

static int	tabrun_2[] = {11, 9, 8, 7, 6, 0};//{6, 6, 7, 8, 9, 11};//{9,9,10,11,13,15};

/**************************************
			Tune communications
**************************************/

//	Tune to measure flow direction
void	CWork::StSetf( int dsth,int srch )
{
	Srco = GetLay( Hypo + LIGHTS,srch );//selected sunlit
	Dsto = GetLay(			 FLOW_V,dsth );//victory
	Dhpo = GetLay(			 FLOW_L,dsth );//local
	Dnxo = GetLay(			 PROB_V,dsth );//victory
	Dexo = GetLay(			 PROB_L,dsth );//local
	Dwoo = GetLay(	Hypo + FLOW_R,dsth );//selected argument
	Dmoo = GetLay(	Hypo + PROB_R,dsth );//selected path
   Deio = GetLay(			 GOAL_S,dsth );//work
}

//	Tune for expert work
void	CWork::StSete( int dsth,int srch )
{
	Srco = GetLay(FLOW_V, srch);//victory
	Shpo = GetLay(FLOW_L, srch);//local
   if (integ)
	   Snxo = GetLay(FLOW_F, srch);//focus alpha
	Dsto = GetLay(PROB_V, dsth);//victory
	Dhpo = GetLay(PROB_L, dsth);//local
   Deio = GetLay(GOAL_S, dsth);//work
}

//-------------------------------------
//	Destroy comunications 
//-------------------------------------
template <class T>
static void destroystream( T *p, bool quick )
{
   if (quick)
      return;
	for (int i = 0; i < 4; i++)
	{
		p->DelLay( PROB_R+i,p->Eche );
		p->DelLay( FLOW_R+i,p->Eche );
	}
}

/**************************************
				Gap functions
**************************************/

//	Check base focuses
static inline int ifturn( byte *p )
{
	return *p == FD || *p == FL || *p == FW;
}

//	Gap for full work
static inline int gapgap( byte *p )
{
	return  *p == 0 || ifturn(p);
}
/**************************************
			Prepare parameters
**************************************/

//	Calculate free runner
static inline int	runrun( int hypo,int iter )
{
	//if diagonal
	if (hypo & 1)
		return tabrun_2[iter];//cosm( tabrun[iter],AQ );
//		return cosm( tabrun[iter],AQ );
	else
		return tabrun[iter]; //OK
}
//	Check probable focus area
static inline void afocus( int &dst,byte *src )
{
	//is indignation ?
	if(ifturn( src ))
		dst = 1;
	else
		dst = 0;
}

/**************************************
		Cluster processing of flow
**************************************/

//	Collect area parameters
void	CWork::StGoon( int flow,int step )
{
	//verify type
	switch (*Hoff)
	{
		case FL:	//verify open angle in the cluster
					if (coor(flow, *Movo*2) < C_tail)
					return;
		case FW:
		case FD:	Area++;
		default:	return;
	}
}

/**************************************
		Bodies of kernal functions
**************************************/

//	Prepare base lay to work
//	Measure stream for areas
void CWork::StFlow(void)
{
	//is the full work?	
	if(*Deio == FV)
      return;
	//forward and backward movement
	for(int anti = 0,best = 0; anti < 8; anti += 4)
	{
		int fwd = updi(Hypo+anti);
		int bck = redi(Hypo+anti);

		//white threads
		ReMove(&Srco);
//         if (quick)
//       {
 //        MvLayW( bck,1       ,0,H0 );
   //      MvLayW( fwd,2+Runs/2,0,H0 );
     // }
      //else
      {
		   MvLayW(fwd, 1+Runs/2, 0, H0);
      }
		MvLayW(bck,  Runs, 1, H0);			
		Prjo = Movo; Prjx = Movx; Prjy = Movy;

		//black threads
		ReMove(&Srco);
//         if (quick)
//         {
//            MvLayI( bck,1		  ,0,H0 );
//            MvLayI( fwd,2+Runs/2,0,H0 );
//         }
//         else
         MvLayI(fwd, 1+Runs/2, 0, H0);
		MvLayI(bck, Runs,	1, H0);			
		Useo = Movo; Usex = Movx; Usey = Movy;

		//synchro black
		Loco = Prjo; Locx = Prjx; Locy = Prjy;
		Movo = Useo; Movx = Usex; Movy = Usey;

		Tr_i = LIM(Cnoise + DIP(MvSynI(fwd, Runs, 1, H0), Runs));
		Fl_i = uppi(atan(Usex-Movx, Usey-Movy));

		//synchro white
		Loco = Useo; Locx = Usex; Locy = Usey;
         Movo = Prjo; Movx = Prjx; Movy = Prjy;

		Tr_w = LIM(Cnoise + DIP(MvSynW(fwd, Runs, 1, H0), Runs));
		Fl_w = uppi(atan(Prjx-Movx, Prjy-Movy));

		//global favourite
		if(Tr_i >= *Dexo)
		{
			*Dnxo  = *Dexo  =  Tr_i;
			*Dsto  = *Dhpo  =  Fl_i;
		}
		//global favourite
		if(Tr_w >= *Dexo)
		{
			*Dnxo  = *Dexo  =  Tr_w;
			*Dsto  = *Dhpo  =  Fl_w;
		}				
		//local favourite
		if(Tr_i >=  best)
		{
			*Dwoo  = Fl_i;
			*Dmoo  = best  =  Tr_i;
		}
		//local favourite
		if(Tr_w >=  best)
		{
			*Dwoo  = Fl_w;
			*Dmoo  = best  =  Tr_w;
		}
	}
}
//	Re-join to original regularity
void CWork::StJoin( void )
{
	//if(gapgap(Deio)) //is the full work?
	if(*Deio != FV)
	{
		//measure flows
		//DoMove(&Dsto);
		//DoLink(&Joff);
		Joff = Dsto;
		DoMove(&Srco);
		DoKeep(&Useo);
		//Movo = Useo = Srco; Movx = Srcx; Movy = Srcy;
		Treset(Re_v); Treset(Im_v);
		//memset(Re_v, 0, sizeof(Re_v)); memset(Im_v, 0, sizeof(Im_v));
		Spiral(Eche, Clas);
		Targum(Re_v, Im_v, Flow, Useo);
		Trelax(Flow, Useo, &Orie, quick);
		GemReg_Stream_1(Shpo, Dhpo, Orie);
	}
	PR_4[0]++; PR_4[1]++; PR_4[2]++; PR_4[3]++;
	FR_4[0]++; FR_4[1]++; FR_4[2]++; FR_4[3]++;
}

//	Recognize focus area
void CWork::StIndi( void )
{
	//is the full work?
	if(gapgap(Deio))	
	{
		//measure flows
		//DoMove(&Dhpo);
		//DoLink(&Joff);
		Joff = Dhpo;
		DoMove(&Shpo);
		DoKeep(&Useo);
		Treset(Re_v); Treset(Im_v);
		Spiral(Eche, Clas);
		Targum(Re_v, Im_v, Flow, Useo);
		int focus = Tfocus(Flow, quick);
		Trelax_StIndi(Flow, Useo, &Orie, focus);
		//GemReg(Srco, Dsto, Orie);
		GemReg_Stream_1(Srco, Dsto, Orie);
		*Srco = Orie;
		//set indignations
		if(!Razors())
		{
			Trecog_StIndi(Deio, focus);
			//get focus tether
			//if(ifturn(Deio))
			if(*Deio == FL)
			{
				Toscil(Flow, Useo, Deio, Snxo);
			}
		}
	}
	PR_4[0]++; PR_4[1]++; PR_4[2]++; PR_4[3]++;
	FR_4[0]++; FR_4[1]++; FR_4[2]++; FR_4[3]++;
}

//	Classify inner areas
void CWork::StGoonV( void )
{
	//data backloop
	*Shpo = *Srco;
	*Dhpo = *Dsto;
	//is indignation ?
	if(ifturn(Deio))
	{
		*Dsto = *Dhpo = 0;//new
	}
	else//setup region
//	if(gapgap(Deio))
	if(*Deio == 0)
	{
		//get curvature
		//DoMove(&Deio);
		//DoLink(&Hoff);
		Hoff = Deio;
		//afocus(Area, Hoff);
		Area = 0;
		DoMove(&Snxo); DoKeep(&Useo);
		Spiral(Eche, Clas);

		//repeat work?
		if(Area != 0)
		{
			*Dsto = *Dhpo  = 0 ;
		}
		else//stop work
			*Deio = FV;
	}
}
//	Adaptate model flow
void CWork::StReco(void)
{
	//update flower
	GemReg_Stream_1(Shpo, Dhpo, *Srco);
	//GemReg(Shpo, Dhpo, *Srco );
	//& probability
	*Dsto = MAX(cogm(*Dhpo, cone(*Shpo, *Srco)), Cnoise);
	PR_4[0]++; PR_4[1]++; PR_4[2]++; PR_4[3]++;
	FR_4[0]++; FR_4[1]++; FR_4[2]++; FR_4[3]++;
}

/**************************************
		Assembly <Stream> function
**************************************/
void Codex::Stream( int reih )
{
	//was reliefs of image built ?
	if(GetKey( LIGHTS,H0 ) == -1)
	{
_DBG_INFO( "CONTROL POINT LIGHTF\n" );
		//previous works
		Lightf( LightF );
	}             
_DBG_INFO( "CONTROL POINT STREAM OLDLAY\n" );
	//tune in stream queue
	OldLay(Tops = STReam);
_DBG_INFO( "CONTROL POINT STREAM WIRECT\n" );
	WiRect(Eche = Clevel, 0);
	if (quick)
	{
      tabrun[0] = 6;//8;//13;
      tabrun[1] = 6;//7;//11;
      tabrun[2] = 5;//6;//10;
      tabrun[3] = 4;//5;//9;
      tabrun[4] = 0;
      tabrun[5] = 0;	

		Cnoise	=  3;

      tabclu[0] = 0;//1;
      tabclu[1] = 0;//1;
      tabclu[2] = 0;
      tabclu[3] = 0;
      tabclu[4] = 0;
      tabclu[5] = 0; 

      tabrun_2[0] = cosm (tabrun[0], AQ);
      tabrun_2[1] = cosm (tabrun[1], AQ);
      tabrun_2[2] = cosm (tabrun[2], AQ);
      tabrun_2[3] = cosm (tabrun[3], AQ);
      tabrun_2[4] = cosm (tabrun[4], AQ);
      tabrun_2[5] = cosm (tabrun[5], AQ);
	}
   else
   {
      tabrun[0] = 15;
      tabrun[1] = 13;
      tabrun[2] = 11;
      tabrun[3] = 10;
      tabrun[4] = 9;
      tabrun[5] = 0;

      Cnoise	=   7;

      tabclu[0] = 1;
      tabclu[1] = 1;
      tabclu[2] = 1;
      tabclu[3] = 1;
      tabclu[4] = 0;
      tabclu[5] = 0;

      tabrun_2[0] = 11;
      tabrun_2[1] =  9;
      tabrun_2[2] =  8;
      tabrun_2[3] =  7;
      tabrun_2[4] =  6;
      tabrun_2[5] =  0;
   }
_DBG_INFO( "CONTROL POINT STREAM PREPARE\n" );
	//prepare stream works
	Dsto = GetLay(PROB_V, Eche); 
   Dhpo = GetLay(PROB_L, Eche);
	memset(Dsto, 0, Size[Eche]); 
   memset(Dhpo, 0, Size[Eche]);
   Deio = GetLay(GOAL_S, Eche);
   memset(Deio, 0, Size[Eche]); 

	byte *original_PR_4[4], *original_FR_4[4];
	int i = 0;
	for(; i < 4; i++)
	{
		original_PR_4[i] = GetLay(PROB_R+i, Eche);
		original_FR_4[i] = GetLay(FLOW_R+i, Eche);
	}
_DBG_INFO( "CONTROL POINT STREAM ITERRATIONS\n" );
	//intellect iterations
	for(i = 0; true; i++)
	{
		//measure free flower
		for(Hypo = 0; Hypo < 4; Hypo++)
		{
_DBG_INFO( "CONTROL POINT STREAM RUNRUN\n" );
			//set far free runners
			Runs = runrun(Hypo,i);
_DBG_INFO( "CONTROL POINT STREAM DIRDIR\n" );
			//percolate directions
			Docvie = (tvii)&CWork::StSetf;
			Docisi = (tv_v)&CWork::StFlow;
_DBG_INFO( "CONTROL POINT STREAM SCENEW\n" );
			Scenew(1, Eche, H0);
			if(i==0)
			{
				Dwoo = GetLay(Hypo + FLOW_R, Eche);
				Dmoo = GetLay(Hypo + PROB_R, Eche);

				Srco = GetLay(Hypo + J_FR, Eche);
				Shpo = GetLay(Hypo + J_PR, Eche);
				
				memmove(Srco, Dwoo, Size[Eche]);
				memmove(Shpo, Dmoo, Size[Eche]);
			}
		}
		//defines cluster size
		Clas = tabclu[i];//set
_DBG_INFO( "CONTROL POINT STREAM REGULATE\n" );
		//regulate local flows
		memmove(PR_4, original_PR_4, 4*sizeof(byte *));
		memmove(FR_4, original_FR_4, 4*sizeof(unsigned char *));
_DBG_INFO( "CONTROL POINT STREAM SCENER\n" );
		Docvie = (tvii)&CWork::StSete;
		Docisi = (tv_v)&CWork::StJoin;
  		Docexe = (tvii)&CWork::Argums_NoApw_quick;
		Scener(Eche);
_DBG_INFO( "CONTROL POINT STREAM RECOGNIZE\n" );
      //recognize focus area
      if (integ)
      {
	      memmove(PR_4, original_PR_4, 4 * sizeof(unsigned char *));
	      memmove(FR_4, original_FR_4, 4 * sizeof(unsigned char *));
         Docvie = (tvii)&CWork::StSete;
         Docisi = (tv_v)&CWork::StIndi;
         Docexe = (tvii)&CWork::Argums_NoApw_quick;
         Scener(Eche);
      }
      //verify procedure end
		if(!tabrun[i+1])break;
_DBG_INFO( "CONTROL POINT STREAM RECOGNIZE SCENER\n" );	   
      //define detailed area
      Docvie = (tvii)&CWork::StSete;
      Docisi = (tv_v)&CWork::StGoonV;
      Docexe = (tvii)&CWork::StGoon;
      Scener(Eche);
	}
_DBG_INFO( "CONTROL POINT STREAM ADAPTING\n" );
	//adaptate to original
	memmove(PR_4, original_PR_4, 4*sizeof(unsigned char *));
	memmove(FR_4, original_FR_4, 4*sizeof(unsigned char *));
	Docvie = (tvii)&CWork::StSete;
	Docisi = (tv_v)&CWork::StReco;
	Scener(Eche);


#ifdef SAVE_LAYERS
   saveLayer("stream_FLOW_V.dat", FLOW_V, 3);
   saveLayer("stream_FLOW_L.dat", FLOW_L, 3);
   saveLayer("stream_PROB_V.dat", PROB_V, 3);
   saveLayer("stream_PROB_L.dat", PROB_L, 3);
   saveLayer("stream_GOAL_S.dat", GOAL_S, 3);
#endif
_DBG_INFO( "CONTROL POINT STREAM DESTROY\n" );
	//destroy a local link
	destroystream( this, quick );
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
