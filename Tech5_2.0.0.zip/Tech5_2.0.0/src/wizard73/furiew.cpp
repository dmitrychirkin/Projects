/**************************************
				Furiew.cpp
	Measure local image spectrum.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"inline73.h"
#include		"mathem73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local enumerated type
//-------------------------------------
enum
{
	_NEED_ = TEMP_T,
	_BETA_,
	_MODU_
};

//-------------------------------------
//	Local tune constants
//-------------------------------------
static const		
 int	Clevel	= H3;					//native level

/**************************************
			Tune Furew filters
**************************************/

//	Tune special procedure
void	CWork::FuTune( int dsth,int srch )
{
	Srco = GetLay(	NORMAL	,srch );		//source lay
	Shpo = GetLay(	_NEED_	,srch );		//needle lay
	Dsto = GetLay(	FLOW_E	,dsth );		//expert flow
   if (integ)
   {
	   Dnxo = GetLay(	FCLASS	,dsth );		//indignation
   }
  	Dexo = GetLay(	ARCH_D	,dsth );		//direction
	Dfno = GetLay(	ARCH_V	,dsth );		//value
}
/*
//	Tune kernal procedure
void	CWork::FuKern( int dsth,int srch )
{
	Shpo = GetLay(	_NEED_	,srch );		//needle lay
	Snxo = GetLay(	_BETA_	,srch );		//gradient phase
	Sexo = GetLay(	_MODU_	,srch );		//gradient module
	Dsto = GetLay(	FLOW_E	,dsth );		//expert flow
	Dhpo = GetLay(	FCLASS	,dsth );		//indignation
	Dnxo = GetLay(	SPEC_O+ 0,dsth );		// 4 harmon
	Dexo = GetLay(	SPEC_O+ 1,dsth );		// 5 harmon
	Dfno = GetLay(	SPEC_O+ 2,dsth );		// 6 harmon
	Dwoo = GetLay(	SPEC_O+ 3,dsth );		// 7 harmon
	Dmoo = GetLay(	SPEC_O+ 4,dsth );		// 8 harmon
	Deio = GetLay(	SPEC_O+ 5,dsth );		// 9 harmon
	Deao = GetLay(	SPEC_O+ 6,dsth );		//10 harmon
	Deco = GetLay(	SPEC_O+ 7,dsth );		//11 harmon
	Deeo = GetLay(	SPEC_O+ 8,dsth );		//12 harmon
	Demo = GetLay(	SPEC_O+ 9,dsth );		//13 harmon
	Dero = GetLay(	SPEC_O+10,dsth );		//14 harmon
	Deso = GetLay(	SPEC_O+11,dsth );		//15 harmon
	Deuo = GetLay(	SPEC_O+12,dsth );		//16 harmon
	Dezo = GetLay(	SPEC_O+13,dsth );		//17 harmon
}
*/
//	Join the areas in hierarchy
void	CWork::FuJoin( int dsth,int srch )
{
	//source
	Snxo = GetLay(	SPEC_O+ 0,srch );		// 4 harmon
	Sexo = GetLay(	SPEC_O+ 1,srch );		// 5 harmon
	Sfno = GetLay(	SPEC_O+ 2,srch );		// 6 harmon
	Swoo = GetLay(	SPEC_O+ 3,srch );		// 7 harmon
	Smoo = GetLay(	SPEC_O+ 4,srch );		// 8 harmon
	Seio = GetLay(	SPEC_O+ 5,srch );		// 9 harmon
	Seao = GetLay(	SPEC_O+ 6,srch );		//10 harmon
	Seco = GetLay(	SPEC_O+ 7,srch );		//11 harmon
	Seeo = GetLay(	SPEC_O+ 8,srch );		//12 harmon
	Semo = GetLay(	SPEC_O+ 9,srch );		//13 harmon
	Sero = GetLay(	SPEC_O+10,srch );		//14 harmon
	Seso = GetLay(	SPEC_O+11,srch );		//15 harmon
	Seuo = GetLay(	SPEC_O+12,srch );		//16 harmon
	Sezo = GetLay(	SPEC_O+13,srch );		//17 harmon
	//destination
	Dnxo = GetLay(	SPEC_O+ 0,dsth );		// 4 harmon
	Dexo = GetLay(	SPEC_O+ 1,dsth );		// 5 harmon
	Dfno = GetLay(	SPEC_O+ 2,dsth );		// 6 harmon
	Dwoo = GetLay(	SPEC_O+ 3,dsth );		// 7 harmon
	Dmoo = GetLay(	SPEC_O+ 4,dsth );		// 8 harmon
	Deio = GetLay(	SPEC_O+ 5,dsth );		// 9 harmon
	Deao = GetLay(	SPEC_O+ 6,dsth );		//10 harmon
	Deco = GetLay(	SPEC_O+ 7,dsth );		//11 harmon
	Deeo = GetLay(	SPEC_O+ 8,dsth );		//12 harmon
	Demo = GetLay(	SPEC_O+ 9,dsth );		//13 harmon
	Dero = GetLay(	SPEC_O+10,dsth );		//14 harmon
	Deso = GetLay(	SPEC_O+11,dsth );		//15 harmon
	Deuo = GetLay(	SPEC_O+12,dsth );		//16 harmon
	Dezo = GetLay(	SPEC_O+13,dsth );		//17 harmon
}

//-------------------------------------
//	Destroy comunications
//-------------------------------------
template <class T>
static void destroyfuriew( T *p )
{
	p->DelLay( _NEED_,H0 );
	p->DelLay( _BETA_,H0 );
	p->DelLay( _MODU_,H0 );
}

/**************************************
				Gap functions
**************************************/
static inline int	outind( byte *p )
{
	return !( *p & FF);
}

static inline void spread( byte *dst,SStep &web,int aval )
{
	//reply exist
	//if (aval > 1)
	{
		//fill in frequency region
		if( *(dst - web.IncO) < aval)
			*(dst - web.IncO) = aval;
		if( *(dst + web.IncO) < aval)
			*(dst + web.IncO) = aval;
		//impulse reply for center
		//if( *(dst) < aval) 
		//	*(dst) = aval;
	}
}
template <class T>
static inline int scheme( T *p, int *e,int *d, bool quick)
{
	//rebuild wing
	int v[] = {MIN(e[0], e[2]), MIN(e[1], e[2])};
	//correct wing
	//int w[] = {cosm(v[0], d[0]), cosm(v[1], d[1])};
	int w[] = {p->Bresen_LookupCm[v[0]][d[0]], p->Bresen_LookupCm[v[1]][d[1]]} ;

   if (quick)
   {
  	   if(w[0] > 0 && w[1] > 0)
		   return MIN( w[0],w[1] )+3;
	   if(w[0] < 0 && w[1] < 0)
		   return MAX( w[0],w[1] )-3;

	   return 0;
   }
	//as Chebychev
	return MIN( w[0],w[1] );
}
/**************************************
		Kernal virtual functions
**************************************/

//	Kernal to put needle
void	CWork::FuNeed( void )
{
	//no indignations ?
	if (!integ || outind( Dnxo ))
//	if (outind( Dnxo ))
   {
		//broken line !
      if (quick)
         *Shpo = FiBrot( Head,Tail,Srco );
      else
         *Shpo = FiBrom( Head,Tail,Srco );
   }
	else
		*Shpo = *Srco;
}

//	If outward needle
void	CWork::FuCopy( void )
{
		*Shpo = *Srco;
}

//	Prognoses gradient
void	CWork::FuRank( void )
{
	//special accelerator
   if (Srcx & 1 & Srcy)
	{
		//get gradient differences
		int grax = Fisuna( Shpo );
		int gray = Fisunc( Shpo );

		//measure length of vector
		Qual = dist(grax, gray) >> 2 ;

		//a histogram of amplitude
		if (Qual)  ++Rank[ Qual ];
	}
}

//	Build scaled gradient
void	CWork::FuGrad( void )
{
	//if no border
	if (!Razors())	 
	{
		//get gradient differences
		int grax = Fisuna( Shpo );
		int gray = Fisunc( Shpo );

		//calculate vector & phase
		Args	= atan( grax,gray );
		Qual	= dist( grax,gray );

		//stretch measured quality
		Qual	= LIM ((Qual << 6 )/
								 Hypo );
		//restore original quality
		Qual	= Rank[ Qual ]*
				  Lord[ Hypo ]/ 255;

		*Snxo = Args/2; //argument
		*Sexo = Qual  ; //& module
	}
	else
	{
		//clear it
		*Snxo =   
		*Sexo = 0;
	}
}

//	Measure frequency	reply
void CWork::FuKernV(void)
{
	//build measuring scheme
	if(!*Sexo)
		return;
	int	e[] = {0, 0, *Sexo},
		d[] = {0, 0};

	int	org[HH+1];//source
	memset(org, 0, sizeof(org));

	//skip if empty position
	//if (e[2] == 0)	  return;

	//reset frequency buffer
	register int i, t, h;
	//measure phase synchronization
	for (i = 0; West[i].IncO; i++)
	{
		//check borders
		if(!N_Edge(West[i].Movx,West[i].Movy )) 
			break;
		//get module
		if((e[0] = *(Sexo-West[i].IncO)) == 0)
			continue;
		if((e[1] = *(Sexo+West[i].IncO)) == 0)
			continue;

		//get phases
		d[0] = coor(*(Snxo-West[i].IncO )*2, *Snxo*2);
		d[1] = coor(*(Snxo+West[i].IncO )*2, *Snxo*2);

		//get harmon		
		h = Furiew_dist_lookup[ABS(West[i].Movx)][ABS(West[i].Movy)];
		//dist(West[i].Movx, West[i].Movy);
		//a spectrum
		t = scheme(this, e, d, quick);
      if (quick)
      {
//         if(t > 0) t = t * 16 / (15 + h) + 2; 
//         else      t = t * 16 / (15 + h) - 2; 
      }		
		if(org[h] < t || org[h] == 0)
		{
			org[h] = t;
//         if (quick && h > 6)
//            org[h] = org[h] * 6 / h;
		}
	}

	//clear the phase of center
	for(i = 0 ; i <= (quick? HH_Q : HH); i++)
	{
		if(org[i] < 0) break;
		org[i] = 0;
	}
	if(i == (quick? HH_Q : HH) + 1)
		return;

	//do local spectrum quality
	for(t= i= 0; i <= (quick? HH_Q : HH); i++)
	{
      if (quick)
		   t += EVK( org[i] ) * EVK ((quick? HH_Q : HH)-i);
      else
		   t += EVK( org[i] );
	}

	//the best spectrum quality
	if(Bask > t) return;
	Bask = t;

	//prognose some absent data
   for (quick ? i = 1 : i = 2; i <  (quick? HH_Q : HH); i++)
   {
	   //if absent
	   if(!org[i])
		    org[i] = MIN( org[i-1],org[i+1] );
   }

	//copy to a spectrum buffer
	for(i = (quick? HL_Q : HL); i <= (quick? HH_Q : HH); i++)
	{
		Spec[i-(quick? HL_Q : HL)] = org[i];
	}
}
//	Collect frequency reply
void	CWork::FuEche( void )
{
	Spec[ 0] += *Snxo;
	Spec[ 1] += *Sexo;
	Spec[ 2] += *Sfno;
	Spec[ 3] += *Swoo;
	Spec[ 4] += *Smoo;
	Spec[ 5] += *Seio;
	Spec[ 6] += *Seao;
	Spec[ 7] += *Seco;
	Spec[ 8] += *Seeo;
	Spec[ 9] += *Semo;
	Spec[10] += *Sero;
	Spec[11] += *Seso;
	Spec[12] += *Seuo;
	Spec[13] += *Sezo;
}

//-------------------------------------
//	Upper virtual functions
//-------------------------------------

//	Reset integrator
int	CWork::FuPrep( void )
{
	*Dnxo =
	*Dexo =
	*Dfno =
	*Dwoo =
	*Dmoo =
	*Deio =
	*Deao =
	*Deco =
	*Deeo =
	*Demo =
	*Dero =
	*Deso =
	*Deuo =
	*Dezo = 0;
	return  1;
}

//	Tune to put needle
int	CWork::FuBres( void )
{
	//no indignations ?
	if (!integ || outind( Dnxo ))
//	if (outind( Dnxo ))
	{
		//needle's parameter
		int curv = *Dfno/05,
			 grad;

		//get original flows
		if (*Dexo)
			grad  = *Dsto+AR;
		else
			grad  = *Dsto-AR;

		//do head
		Movo = 0;
		//Joff = 0;		
		//Movx = Movy = 0;
      if (quick)
   		Breweb_Furiew(grad+AR-curv, 7, H0, Head);
      else
   		Breweb_Furiew(grad+AR-curv, 8, H0, Head);

		//do tail
		Movo = 0;
      if (quick)
         Breweb_Furiew(grad-AR+curv, 7, H0, Tail);
      else
         Breweb_Furiew(grad-AR+curv, 8, H0, Tail);
	}

	//go on !
	return 1;
}

//	Subtuning frequency
int	CWork::FuCorr( void )
{
	//no indignations ?
	if (!integ || outind( Dhpo ))
//	if (outind( Dhpo ))
	{
		//prepare
		//Basket();
		Bask = 0;
		//ResDst( Spec,_HAR_ );//reset
		memset(Spec, 0, _HAR_*sizeof(int));
		//do wing
		Breset();
		Breweb(*Dsto+AR,10,H1,Tail );
		//do wing
		Breset();
		Breweb(*Dsto+AR,(quick? HH_Q : HH),H0,West );
		//go on !
		return 1;
	}
	//stop it
	return 0;
}

//	Spread impulse reply
void CWork::FuSpre( void )
{
	bool bigger_0, bigger_1, bigger_2, bigger_3, bigger_4, bigger_5, bigger_6, 
		bigger_7, bigger_8, bigger_9, bigger_10, bigger_11, bigger_12, bigger_13;
	bigger_0 = bigger_1 = bigger_2 = bigger_3 = bigger_4 = bigger_5 = bigger_6 = 
		bigger_7 = bigger_8 = bigger_9 = bigger_10 = bigger_11 = bigger_12 = bigger_13 = false;
	if(Spec[0] > 1) 
	{ bigger_0 = true; if( *Dnxo < Spec[0]) *Dnxo = Spec[0];}
	if(Spec[1] > 1) 
	{ bigger_1 = true; if(*Dexo < Spec[1]) *Dexo = Spec[1];}
	if(Spec[2] > 1)
	{ bigger_2 = true; if(*Dfno < Spec[2]) *Dfno = Spec[2];}
	if(Spec[3] > 1)
	{ bigger_3 = true; if(*Dwoo < Spec[3]) *Dwoo = Spec[3];}
	if(Spec[4] > 1) 
	{ bigger_4 = true; if(*Dmoo < Spec[4]) *Dmoo = Spec[4];}
	if(Spec[5] > 1)
	{ bigger_5 = true; if(*Deio < Spec[5]) *Deio = Spec[5];}
	if(Spec[6] > 1) 
	{ bigger_6 = true; if(*Deao < Spec[6]) *Deao = Spec[6];}
	if(Spec[7] > 1)
	{ bigger_7 = true; if(*Deco < Spec[7]) *Deco = Spec[7];}
	if(Spec[8] > 1)
	{ bigger_8 = true; if(*Deeo < Spec[8]) *Deeo = Spec[8];}
	if(Spec[9] > 1)
	{ bigger_9 = true; if(*Demo < Spec[9]) *Demo = Spec[9];}
	if(Spec[10] > 1) 
	{ bigger_10 = true; if(*Dero < Spec[10]) *Dero = Spec[10];}
	if(Spec[11] > 1)
	{ bigger_11 = true; if(*Deso < Spec[11]) *Deso = Spec[11];}
	if(Spec[12] > 1)
	{ bigger_12 = true; if(*Deuo < Spec[12]) *Deuo = Spec[12];}
	if(Spec[13] > 1)
	{ bigger_13 = true; if(*Dezo < Spec[13]) *Dezo = Spec[13];}

	//scan the sequence of frequencies
	for (int i = 0; Tail[i].IncO; i++)
	{
		//verify edge
		if (!N_Edge( Tail[i].Movx,Tail[i].Movy,0 )) 
				return;

		//parse freqs
      if (!quick)
      {
         switch(Furiew_dist_lookup[ABS(Tail[i].Movx)][ABS(Tail[i].Movy)])
         {
			   case	1: 
			   case	2:	//realize whiskers of any harmon 
			   case	3:	
				   if(bigger_0) spread(Dnxo, Tail[i], Spec[0]);
				   if(bigger_1) spread(Dexo, Tail[i], Spec[1]);
			   case	4:	
				   if(bigger_2) spread(Dfno, Tail[i], Spec[2]);
				   if(bigger_3) spread(Dwoo, Tail[i], Spec[3]);
			   case	5:	
				   if(bigger_4) spread(Dmoo, Tail[i], Spec[4]);
				   if(bigger_5) spread(Deio, Tail[i], Spec[5]);
			   case	6:	
				   if(bigger_6) spread(Deao, Tail[i], Spec[6]);
				   if(bigger_7) spread(Deco, Tail[i], Spec[7]);
			   case	7:	
				   if(bigger_8) spread(Deeo, Tail[i], Spec[8]);
				   if(bigger_9) spread(Demo, Tail[i], Spec[9]);
			   case	8:	
				   if(bigger_10) spread(Dero, Tail[i], Spec[10]);
				   if(bigger_11) spread(Deso, Tail[i], Spec[11]);
			   case	9:	
				   if(bigger_12) spread(Deuo, Tail[i], Spec[12]);
				   if(bigger_13) spread(Dezo, Tail[i], Spec[13]);
						   break;
			   default:	return;
         }
      }
      else
      {
		   switch(Furiew_dist_lookup[ABS(Tail[i].Movx)][ABS(Tail[i].Movy)])
		   {
			   case	0: 
			   case	1: 
				   if(bigger_0) spread(Dnxo, Tail[i], Spec[0]);
				   if(bigger_1) spread(Dexo, Tail[i], Spec[1]);
			   case	2:	
				   if(bigger_2) spread(Dfno, Tail[i], Spec[2]);
				   if(bigger_3) spread(Dwoo, Tail[i], Spec[3]);
			   case	3:	
				   if(bigger_4) spread(Dmoo, Tail[i], Spec[4]);
				   if(bigger_5) spread(Deio, Tail[i], Spec[5]);
			   case	4:	
				   if(bigger_6) spread(Deao, Tail[i], Spec[6]);
				   if(bigger_7) spread(Deco, Tail[i], Spec[7]);
			   case	5:	
				   if(bigger_8) spread(Deeo, Tail[i], Spec[8]);
				   if(bigger_9) spread(Demo, Tail[i], Spec[9]);
			   case	6:	
				   if(bigger_10) spread(Dero, Tail[i], Spec[10]);
				   if(bigger_11) spread(Deso, Tail[i], Spec[11]);
			   case	7:	
				   if(bigger_12) spread(Deuo, Tail[i], Spec[12]);
				   if(bigger_13) spread(Dezo, Tail[i], Spec[13]);
						   break;
			   default:	return;
         }
		}
	}
}
//	Reset expectation
int	CWork::FuZero( void )
{
	//prepare
	//ResDst( Spec,_HAR_ );
	memset(Spec, 0, _HAR_*sizeof(int));
	//go on !
	return 1;
}

//	Hierarchy spectrum reply
void	CWork::FuDone( void )
{
	*Dnxo = ( Spec[ 0]+2 )/4;
	*Dexo = ( Spec[ 1]+2 )/4;
	*Dfno = ( Spec[ 2]+2 )/4;
	*Dwoo = ( Spec[ 3]+2 )/4;
	*Dmoo = ( Spec[ 4]+2 )/4;
	*Deio = ( Spec[ 5]+2 )/4;
	*Deao = ( Spec[ 6]+2 )/4;
	*Deco = ( Spec[ 7]+2 )/4;
	*Deeo = ( Spec[ 8]+2 )/4;

	*Demo = ( Spec[ 9]+2 )/4;
	*Dero = ( Spec[10]+2 )/4;
	*Deso = ( Spec[11]+2 )/4;
	*Deuo = ( Spec[12]+2 )/4;
	*Dezo = ( Spec[13]+2 )/4;
}

/**************************************
			Assemble <Furiew>
**************************************/
void Codex::Furiew(int reih)
{
	//law to amplifier the probability
	int low[] = {3, 4,0, 60,68, BM,BM};

	//if curvature field was not built
	if (GetKey( ARCH_V,Clevel ) == -1)
	{
		//previous works
		Curvat( CurvaT );
	}
	//tune in furiew queue
	OldLay(Tops = FURiew);
	Eche = Reih = (reih);

	//RanIni( 0 ); //prepare
	memset(Rank, 0, sizeof(Rank));

	//the needle procedure
	Docvie = (tvii)&CWork::FuTune;
	Docisi = (tv_v)&CWork::FuNeed;
	Dociso = (tv_v)&CWork::FuCopy;
	Docupi = (ti_v)&CWork::FuBres;
	Scenes(0, 3, Eche, H0);

#ifdef SAVE_LAYERS
   saveLayer("furiew_NORMAL.dat", NORMAL, 0);
   saveLayer("furiew__NEED_.dat", _NEED_, 0);
   saveLayer("furiew_FLOW_E_1st.dat", FLOW_E, 1);
   saveLayer("furiew_FCLASS_1st.dat", FCLASS, 1);
   saveLayer("furiew_ARCH_D_1st.dat", ARCH_D, 1);
   saveLayer("furiew_ARCH_V_1st.dat", ARCH_V, 1);
#endif

	unsigned char *original_Shpo = GetLay(_NEED_, H0);//needle lay
	short *p_Fisuna, *p_Fisunc, *p_Fisunac;
	Indx = MaxX[H0] + 1;
	p_Fisuna = I_Fisuna + Indx;	p_Fisunc = I_Fisunc + Indx;
	p_Fisunac = I_Fisunac + Indx;
	Shpo = original_Shpo + Indx;
	
	Redx = MaxX[H0]; Redy = MaxY[H0];
	for(Srcy = 1; Srcy < Redy-1; Srcy++)
	{
		for(Srcx = 1; Srcx < Redx-1; Srcx++)
		{
            *p_Fisuna = Fisuna(Shpo);
			*p_Fisunc = Fisunc(Shpo);
			*p_Fisunac = dist(*p_Fisuna, *p_Fisunc);
			if( (Srcx & 1) && (Srcy & 1) && 
				(Srcx > 6) && (Srcx < Redx-6) &&
				(Srcy > 6) && (Srcy < Redy-6) )
			{
				Qual = (*p_Fisunac) >> 2 ;
				if(Qual)
					++Rank[Qual];
			}
			Shpo++; p_Fisuna++; p_Fisunc++; p_Fisunac++;
		}
		Shpo += 2; p_Fisuna += 2; p_Fisunc += 2; p_Fisunac += 2;
	}
	//get the part of Rank
	Hypo = RanSha(2) + 2 ;

	//builds amplitude low
	RanMod(low);RanSmo(4);
	LorLog();//contrast

	//form scaled gradient
	unsigned char *original_Snxo = GetLay(_BETA_, H0); //gradient phase
	unsigned char *original_Sexo = GetLay(_MODU_, H0); //gradient module
	memset(original_Snxo, 0, Redx); memset(original_Sexo, 0, Redx);
	p_Fisuna = I_Fisuna + Redx;
	p_Fisunc = I_Fisunc + Redx;
	p_Fisunac = I_Fisunac + Redx;
	Snxo = original_Snxo + Redx;
	Sexo = original_Sexo + Redx;
	for(Srcy = 2; Srcy < Redy; Srcy++)
	{
		*Snxo = *Sexo = 0;
		Snxo++; Sexo++; p_Fisuna++; p_Fisunc++; p_Fisunac++;
		for(Srcx = 2; Srcx < Redx; Srcx++)
		{
            int grax = *p_Fisuna;//Fisuna( Shpo );
			int gray = *p_Fisunc; //Fisunc( Shpo );
			//calculate vector & phase
			Args = atan(grax, gray);
			Qual = *p_Fisunac; //dist(grax, gray);
			//stretch measured quality
			Qual = LIM ((Qual << 6 )/Hypo );
			//restore original quality
			Qual = Rank[Qual]*Lord[Hypo]/255;
			
			*Snxo = Args/2; //argument
			*Sexo = Qual; //& module

    		Snxo++; Sexo++; p_Fisuna++; p_Fisunc++; p_Fisunac++;
		}
		*Snxo = *Sexo = 0;
		Snxo++; Sexo++; p_Fisuna++; p_Fisunc++; p_Fisunac++;
	}
	memset(Snxo, 0, Redx); memset(Sexo, 0, Redx);

	unsigned char *original_Dnxo = Dnxo = GetLay(SPEC_O+ 0, Eche);// 4 harmon
	unsigned char *original_Dexo = Dexo = GetLay(SPEC_O+ 1, Eche); // 5 harmon
	unsigned char *original_Dfno = Dfno = GetLay(SPEC_O+ 2, Eche);	// 6 harmon
	unsigned char *original_Dwoo = Dwoo = GetLay(SPEC_O+ 3, Eche);	// 7 harmon
	unsigned char *original_Dmoo = Dmoo = GetLay(SPEC_O+ 4, Eche);	// 8 harmon
	unsigned char *original_Deio = Deio = GetLay(SPEC_O+ 5, Eche);	// 9 harmon
	unsigned char *original_Deao = Deao = GetLay(SPEC_O+ 6, Eche);	//10 harmon
	unsigned char *original_Deco = Deco = GetLay(SPEC_O+ 7, Eche);	//11 harmon
	unsigned char *original_Deeo = Deeo = GetLay(SPEC_O+ 8, Eche);	//12 harmon
	unsigned char *original_Demo = Demo = GetLay(SPEC_O+ 9, Eche);	//13 harmon
	unsigned char *original_Dero = Dero = GetLay(SPEC_O+10, Eche);	//14 harmon
	unsigned char *original_Deso = Deso = GetLay(SPEC_O+11, Eche);	//15 harmon
	unsigned char *original_Deuo = Deuo = GetLay(SPEC_O+12, Eche);	//16 harmon
	unsigned char *original_Dezo = Dezo = GetLay(SPEC_O+13, Eche);	//17 harmon
	memset(original_Dnxo, 0, Size[Eche]);	memset(original_Dexo, 0, Size[Eche]);
	memset(original_Dfno, 0, Size[Eche]);	memset(original_Dwoo, 0, Size[Eche]);
	memset(original_Dmoo, 0, Size[Eche]);	memset(original_Deio, 0, Size[Eche]);	
	memset(original_Deao, 0, Size[Eche]);	memset(original_Deco, 0, Size[Eche]);
	memset(original_Deeo, 0, Size[Eche]);	memset(original_Demo, 0, Size[Eche]);	
	memset(original_Dero, 0, Size[Eche]);	memset(original_Deso, 0, Size[Eche]);
	memset(original_Deuo, 0, Size[Eche]);	memset(original_Dezo, 0, Size[Eche]);

	//set harmonized field
	Snxo = original_Snxo;
	Sexo = original_Sexo;
	Dsto = GetLay(FLOW_E, Eche);		//expert flow
   if (integ)
	   Dhpo = GetLay(FCLASS, Eche);		//indignation

	//Docvie = (tvii)&CWork::FuKern;
	Docisi = (tv_v)&CWork::FuKernV;
	Docupi = (ti_v)&CWork::FuCorr;
	Docupo = (ti_v)&CWork::Deafen;
	Docfni = (tv_v)&CWork::FuSpre;
	Scenes(0, 2, Eche, H0);

	Snxo = original_Dnxo; Sexo = original_Dexo;	Sfno = original_Dfno;
	Swoo = original_Dwoo; Smoo = original_Dmoo;	Seio = original_Deio;
	Seao = original_Deao; Seco = original_Deco;	Seeo = original_Deeo;
	Semo = original_Demo; Sero = original_Dero;	Seso = original_Deso;
	Seuo = original_Deuo; Sezo = original_Dezo;

	//gather spectrum reply into hierarchy..
	for(int i = reih; i < Clevel; i++)
	{
		//collect the spectrum
		Eche++;
		original_Dnxo = Dnxo = GetLay(SPEC_O+ 0, Eche);// 4 harmon
		original_Dexo = Dexo = GetLay(SPEC_O+ 1, Eche); // 5 harmon
		original_Dfno = Dfno = GetLay(SPEC_O+ 2, Eche);	// 6 harmon
		original_Dwoo = Dwoo = GetLay(SPEC_O+ 3, Eche);	// 7 harmon
		original_Dmoo = Dmoo = GetLay(SPEC_O+ 4, Eche);	// 8 harmon
		original_Deio = Deio = GetLay(SPEC_O+ 5, Eche);	// 9 harmon
		original_Deao = Deao = GetLay(SPEC_O+ 6, Eche);	//10 harmon
		original_Deco = Deco = GetLay(SPEC_O+ 7, Eche);	//11 harmon
		original_Deeo = Deeo = GetLay(SPEC_O+ 8, Eche);	//12 harmon
		original_Demo = Demo = GetLay(SPEC_O+ 9, Eche);	//13 harmon
		original_Dero = Dero = GetLay(SPEC_O+10, Eche);	//14 harmon
		original_Deso = Deso = GetLay(SPEC_O+11, Eche);	//15 harmon
		original_Deuo = Deuo = GetLay(SPEC_O+12, Eche);	//16 harmon
		original_Dezo = Dezo = GetLay(SPEC_O+13, Eche);	//17 harmon

		//Docvie = (tvii)&CWork::FuJoin;
		Docisi = (tv_v)&CWork::FuEche;
		Docupi = (ti_v)&CWork::FuZero;
		Docfni = (tv_v)&CWork::FuDone;
		Scenew(0, Eche, Eche-1);

		Snxo = original_Dnxo; Sexo = original_Dexo;	Sfno = original_Dfno;
		Swoo = original_Dwoo; Smoo = original_Dmoo;	Seio = original_Deio;
		Seao = original_Deao; Seco = original_Deco;	Seeo = original_Deeo;
		Semo = original_Demo; Sero = original_Dero;	Seso = original_Deso;
		Seuo = original_Deuo; Sezo = original_Dezo;
	}

#ifdef SAVE_LAYERS
   saveLayer("furiew_FLOW_E.dat", FLOW_E, 1);
   saveLayer("furiew_FCLASS.dat", FCLASS, 1);
   saveLayer("furiew_ARCH_D.dat", ARCH_D, 1);
   saveLayer("furiew_ARCH_V.dat", ARCH_V, 1);
#endif
   
   //destroy a local link
	destroyfuriew( this );
	
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
