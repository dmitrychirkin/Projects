/**************************************
				Flower.cpp
 Decomposition and confluence of flow.
		 Generate expert flow.

			Author Gudkov V.U.
***************************************/

//	Header project file
#include		"inline73.h"
#include		"mathem73.h"
#include		"sorter73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local definitions
//-------------------------------------
enum
{
	_GRD_X = TEMP_T,
	_GRD_Y,
	_MODU_,
	_BETA_
};
	 
//-------------------------------------
//	Local tune constants
//-------------------------------------
static const		
int	Clevel =  H3,					//base level
				Cqueue =   3,					//length of queue
				C_zero =   7,					//addition
				Cloops =  90,					//scope for loop
				Cwhorl =  85,					//scope for whorl
				Cdelta =  75,					//scope for delta
				Cphase =  90;					//any scope

/**************************************
			Tune communications
**************************************/

//	Tune to measure gradient probability
void	CWork::FlTune( int dsth,int srch )
{
	Srco = GetLay( NORMAL,srch );			//normalized
	Snxo = GetLay(	_BETA_,srch );			//gradient phase
	Sexo = GetLay(	_MODU_,srch );			//gradient module
	Dsto = GetLay( FLOW_E,dsth );			//expert flow
   if (integ)
   {
   	Dhpo = GetLay( FLOW_F,dsth );			//alpha
	   Dnxo = GetLay( FCLASS,dsth );			//fclass
   }
	Dexo = GetLay( FLOW_P,dsth );			//pattern flow
	Dwoo = GetLay( _GRD_X,dsth );			//x decompose
	Dmoo = GetLay( _GRD_Y,dsth );			//y decompose
	Deio = GetLay( CONC_G,dsth );			//gradient concordance
}

//	Tune to calculate flower & quality
void	CWork::FlDeep( int dsth,int srch )
{
	Srco = GetLay( FLOW_E,srch );			//expert flow
	Swoo = GetLay( _GRD_X,srch );			//x decompose
	Smoo = GetLay( _GRD_Y,srch );			//y decompose
	Dsto = GetLay( FLOW_E,dsth );			//expert flow
	Dwoo = GetLay( _GRD_X,dsth );			//x decompose
	Dmoo = GetLay( _GRD_Y,dsth );			//y decompose
}

//-------------------------------------
//	Destroy communications
//-------------------------------------
template <class T>
static void destroyflower( T *p )
{
	//destroy temporary lays
	p->DelLay( _GRD_X,p->Eche );
	p->DelLay( _GRD_Y,p->Eche );

	//destroy phase & module
	p->DelLay( _MODU_,	H0	  );
	p->DelLay( _BETA_,	H0	  );
}

/**************************************
		Measure flow concordance
**************************************/
void	CWork::FlConc( void )
{
	//gather flow probability based on regularity
	int i, qran, pran;
	for (i = 0, pran = 0, qran = 0; i < 4; i++)
	{
		int qual = *PR_4[i];//*ProRef(PROB_R+i,Dstx, Dsty, Eche, Eche );
		int args = *FR_4[i];//*ProRef(FLOW_R+i,Dstx, Dsty, Eche, Eche );
		//measure
		int aval, beta	= cone( args,*Dexo ) << 1;

		//use fuzzy function pros and cons!
		if((aval = cosm( qual,beta )) > 0 )
			pran += aval;
		else
			qran -= aval;
	}

	*Deio = DIP( AR*qran,pran+qran );//set
	PR_4[0]++; PR_4[1]++; PR_4[2]++; PR_4[3]++;
	FR_4[0]++; FR_4[1]++; FR_4[2]++; FR_4[3]++;
}

/**************************************
		Bodies of service functions
**************************************/

//	Store flow
void	CWork::Flower( void )
{
	*Srco = Orie;
}

//	Store wave for gradient
void	CWork::FlWave( void )
{
	*Swoo = LIM( Grax+BA );
	*Smoo = LIM( Gray+BA );
}

/**************************************
		Virtual inner functions
**************************************/

//	Measure phase & module
void	CWork::FlGrad( void )
{
	//if a border
	if (Razors())		 return;

	//get gradient differences
	int grax = Fisuna( Srco );
	int gray = Fisunc( Srco );

	//calculate vector & phase
	*Snxo = atan( grax,gray )/
									2;
	*Sexo = dist( grax,gray )/
									4;
	++Rank[*Sexo]; //histogram
}

//	Measure sorted gradient
void	CWork::FlQual( void )
{
	//if a border
	if (Razors())		 return;

	//measure a scaled quality
	Qual = LIM ((*Sexo << 8 )/
							 Hypo );
	Qual = Lord[ Hypo ]*	//low
			 Rank[ Qual ] >> 8 ;

	//measure phases deviation
   if (integ)
	   switch (*Dnxo )
	   {
		   case FL:	Args = cone( *Snxo*2,*Dhpo* 2 );
					   break;
		   case FW:	Args = cone( *Snxo*2,*Dhpo* 2 );
					   break;
		   case FD:	Args = cone( *Snxo*2,*Dexo+AR );
					   break;
		   default:	Args = cone( *Snxo*2,*Dexo+AR );
					   break;
	   }
   else
      Args = cone( *Snxo*2,*Dexo+AR );

	//pros and cons collection
	Pran += cogm( 
			  cogm( Qual,Args ),
							 Args );
	Qran += sigm( 
			  sigm( Qual,Args ),
							 Args );

	//builds probability queue
	if(Crop[Cqueue] < Qual  )
	{
		Crop[Cqueue] = Qual; isort( Crop,less,Cqueue );
	}
}

//	Store filtered gradient
void	CWork::FlFilt( void )
{
	FlWave();
	Flower();
}

//	Final inward impulse
void	CWork::FlFili( void )
{
	FlImpi();
	Flower();
}
				 
/**************************************
		Virtual upper functions
**************************************/

//	Decomposition of gradient
void	CWork::FlCome( void )
{
	//expert flower
	*Dsto = *Dexo ;

	//quality model
   if (integ)
   {
	   switch (*Dnxo )
	   {
		   case FL:	Args = *Dhpo*2
								    +AR;
					   Open = Cloops;
					   break;
		   case FW:	Args = *Dhpo*2
							       +AR;
					   Open = Cwhorl;
					   break;
		   case FD:	Args = *Dexo ;
					   Open = Cdelta;
					   break;
		   default:	Args = *Dexo ;
					   Open = Cphase;
					   break;
	   }
   }
   else
   {
      Args = *Dexo ;
      Open = Cphase;
   }


	//a quality as probability
	Qual = cogm(Crop[Cqueue], Open*Qran/VON( Pran+Qran )) + C_zero ;

	//do complex decomposition
	*Dwoo = LIM(cosm(Qual, Args*2 )/2 + BA);
	*Dmoo = LIM(sinm(Qual, Args*2 )/2 + BA);
}

//	Prepare before measuring
int	CWork::FlPrep( void )
{
	//the future filter reply
	ResDst( Crop,Cqueue + 1 );
	FlConc();
	Rreset();
	return 1;  //goon measure
}

//	Get inner impulse reply
int	CWork::FlImpi( void )
{
	//measure complex impulse
	Grax = Fiimpo(*Dsto, Dwoo) - BA;
	Gray = Fiimpo(*Dsto, Dmoo) - BA;

	//calculate argument-flow
	Orie = atan(Grax, Gray)/2;
	return 1;  //goon measure
}

//	Original outward impulse reply
int	CWork::FlImpo( void )
{
	//measure complex impulse
	Grax = (*Dwoo - BA)/1;
	Gray = (*Dmoo - BA)/1;

	//calculate argument-flow
	Orie = atan( Grax,Gray )/2;
	return 1;  //goon measure
}

/**************************************
		Assemble <Flower> function
**************************************/
void Codex::Flower( int reih )
{
	//laws to amplifier the probability
	int low[] = {3, 9,0, 60,90, BM,BM};

	//if pattern stream wasn't built..
	if (GetKey( FLOW_P,Clevel ) == -1)
	{
		//previous works
		Swells( SwellS );
	}
	//tune in respon queue
	OldLay( Tops=FLOwer );
	Eche = Clevel;

	unsigned char *original_Snxo = GetLay(_BETA_, H0);			//gradient phase
	unsigned char *original_Sexo = GetLay(_MODU_, H0);			//gradient module
	unsigned char *temp_B =  GetLay(I_B, H0);
	unsigned char *temp_M =  GetLay(I_M, H0);
	memmove(original_Snxo, temp_B,  Size[H0]);
	memmove(original_Sexo, temp_M,  Size[H0]);
	//get the part of Rank
	Hypo = RanSha(3) +  1;

	//builds amplitude low
	RanMod(low);RanSmo(7);
	LorLog();//contrast

	//a gradient procedure
	unsigned char *original_PR_4[4], *original_FR_4[4];
	int i;
	for(i = 0; i < 4; i++)
	{
		original_PR_4[i] = GetLay(PROB_R+i, Eche);
		original_FR_4[i] = GetLay(FLOW_R+i, Eche);
	}
	memmove(PR_4, original_PR_4, 4*sizeof(unsigned char *));
	memmove(FR_4, original_FR_4, 4*sizeof(unsigned char *));
	Docvie = (tvii)&CWork::FlTune;
	Docupi = (ti_v)&CWork::FlPrep;
	Docisi = (tv_v)&CWork::FlQual;
	Docfni = (tv_v)&CWork::FlCome;
	Scenew(0, Eche, H0);

	//do flower projection
	for (Eche = Clevel; Eche > reih; Eche--)
	{
		//hierarchy projection
		Docvie = (tvii)&CWork::FlDeep;
		Docupi = (ti_v)&CWork::FlImpi;
		Docupo = (ti_v)&CWork::FlImpo;
		Docisi =
		Dociso = (tv_v)&CWork::FlFilt;
		Scenei(0,Eche,Eche-1);
	}

	//final small smothing
	Docvie = (tvii)&CWork::FlDeep;
	Docisi = (tv_v)&CWork::FlFili;
	Scenei( 2,Eche,Eche );
#ifdef SAVE_LAYERS
    saveLayer("flower_NORMAL.dat", NORMAL, 0);
    saveLayer("flower__BETA_.dat", _BETA_, 0);
    saveLayer("flower__MODU_.dat", _MODU_, 0);
    saveLayer("flower_I_B.dat", I_B, 0);
    saveLayer("flower_I_M.dat", I_M, 0);
    saveLayer("flower_FCLASS.dat", FCLASS, 3);
    saveLayer("flower_FLOW_P.dat", FLOW_P, 3);
    saveLayer("flower_CONC_G_3.dat", CONC_G, 3);
    saveLayer("flower_FLOW_E_3.dat", FLOW_E, 3);
    saveLayer("flower__GRD_X_3.dat", _GRD_X, 3);
    saveLayer("flower__GRD_Y_3.dat", _GRD_Y, 3);
    saveLayer("flower_FLOW_E_2.dat", FLOW_E, 2);
    saveLayer("flower__GRD_X_2.dat", _GRD_X, 2);
    saveLayer("flower__GRD_Y_2.dat", _GRD_Y, 2);
    saveLayer("flower_FLOW_E_1.dat", FLOW_E, 1);
    saveLayer("flower__GRD_X_1.dat", _GRD_X, 1);
    saveLayer("flower__GRD_Y_1.dat", _GRD_Y, 1);
#endif

	//destroy temporary links
	for (Eche = reih; Eche <=Clevel; Eche++)
	{
		//destroy a local link
		destroyflower( this );
	}
	DelLay(I_B, H0);
	DelLay(I_M, H0);
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */

