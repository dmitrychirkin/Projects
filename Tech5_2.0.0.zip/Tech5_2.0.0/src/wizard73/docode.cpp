/**************************************
				DoCode.cpp
	  Encode and decode sceleton.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"access73.h"
#include		"inline73.h"
#include		"packed73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local definitions
//-------------------------------------
enum
{
	_TEMP_ = TEMP_T,
	_CONV_
};

//-------------------------------------
//	Local tune constants
//-------------------------------------
static const 
int	C_pack =	  H1,					//packing level
				C_size =		4,					//byte for size	
				Cvalue =	 160,					//bright value
				C_deep = 9999;					//branch size

/**************************************
			Tune communications
**************************************/

//	Tune in encoding
void	CCode::EnTune( int dsth,int srch )
{
	Srco = GetLay(	SKELET,srch );			//sceleton
	Shpo = GetLay(	REFINE,srch );			//refine..
}

//	Tune in encoding
void	CCode::DeTune( int dsth,int srch )
{
	Srco = GetLay(	UNPACK,srch );			//unpacked
}

//	Tune in decoding
void	CCode::DoTune( int dsth,int srch )
{
	Srco = GetLay(	UNPACK,srch );			//unpacked
	Shpo = GetLay(	NORMAL,srch );			//reconstruction
	Snxo = GetLay(	SOURCE,srch );			//source
	Sexo = GetLay(	_CONV_,srch );			//convolution
}

//	Tune in procedure to inherit skeleton
void	CCode::DoCopy( int dsth,int srch )
{
	Srco = GetLay(	SKELET,srch );			//sceleton
	Shpo = GetLay(	REFINE,srch );			//refine..
	Snxo = GetLay(	UNPACK,srch );			//unpacked
	Dnxo = GetLay(	GOAL_F,dsth );			//filter goal
}

//	Tune in procedure to inherit minutiae
void	CCode::DoMini( int dsth,int srch )
{
	Srco = GetLay(	SKELET,srch );			//sceleton
	Shpo = GetLay(	REFINE,srch );			//refine..
	Dexo = GetLay(	GOAL_M,dsth );			//minutiae goal
}

/**************************************
		Verify code structure
**************************************/
static inline int vercod( byte *sig )
{
	if (DFocus<byte*>(sig) != sig + sizeof( SItem) + sizeof( SDisp ))
		return RUINED;
	if (DPoint<byte*>(sig) != DFocus<byte*>(sig) + QFocus<uint>(sig))
		return RUINED;
	if (DTotal<byte*>(sig) != DPoint<byte*>(sig) + QPoint<uint>(sig))
		return RUINED;
	if (DRidge<byte*>(sig) != DTotal<byte*>(sig) + QTotal<uint>(sig))
		return RUINED;
	if (DAreas<byte*>(sig) != DRidge<byte*>(sig) + QRidge<uint>(sig))
		return RUINED;																	
	if (DLinks<byte*>(sig) != DAreas<byte*>(sig) + QAreas<uint>(sig))
		return RUINED;
	if (DOwner<byte*>(sig) != DLinks<byte*>(sig) + QLinks<uint>(sig))
		return RUINED;
//	if (DUnuse<byte*>(sig) != DLinks<byte*>(sig) + QLinks<uint>(sig)+4)
//		return RUINED;
		return SUCCES;
}

/**************************************
		Kernal virtual functions
**************************************/

//	Restore sceleton
void	CCode::EnOrig( void )
{
	*Srco = *Shpo;
}

//	Enter code sceleton
void	CCode::EnCodeV( void )
{
	//verify pixel
	switch (*Srco)
	{
		case BP:	
		case BL:
		case BR:
		case BS:	Pack[Lpck++]  = Srcx		 ;
					Pack[Lpck  ]  = Srcx >> 8;
					Pack[Lpck  ] &=		0x0f;
					Pack[Lpck++] |= Srcy << 4;
					Pack[Lpck++]  = Srcy >> 4;

					//code skeleton
					DoMove(&Srco );
					Chaine(C_deep);
		default:	return;
	}
}

//	Prepare unpacked buffer
void	CCode::DeCodeV( void )
{
	*Srco = BM;
}
/*
//	Inner convolution
void	CCode::ReConi( void )
{
	//measure impulse response
	if((Bask = WebCon( HCon,Srco )) < 0)
		//write models
		Bask = LIM( Bask + Cvalue );
	else
		//other region
		Bask = BM - ( uran() >>11 );

	//mixed images
	*Sexo = DIP	 ( Bask*Pran+ 
					  *Snxo*Qran, BA );
}
*/
//	Outward convolution
void	CCode::ReCono( void )
{
		//other region
		Bask = BM - ( uran() >>11 );

	//mixed images
	*Shpo =
	*Sexo = DIP	 ( Bask*Pran+
					  *Snxo*Qran, BA );
}

//	Reconstruct pattern
void	CCode::Recons( void )
{
	*Shpo = Fiimpr( Sexo );
}

//	Inherit skeleton
void	CCode::DoCopyV( void )
{
	//is work region ?
	if (!(*Dnxo & W5))
	{
		//set skeleton
		if(*Snxo <= BS)
			*Srco	 =
			*Shpo  = BU;
		else
			*Srco  =
			*Shpo  = BG;
	}
}

//	Inherit old minutiae
void	CCode::DoMiniV( void )
{
	//minutiae exist
	if (*Srco < BU)
	{
		//look throw the old list of minutiae
		int i = 0, imax = 2, prob = 0, tmpi = 0;
		for (; i < Nmin; i++)
		{
			if (imax > (tmpi = dist( Srcx,Srcy,Sign[i].Movx,Sign[i].Movy )))
			{
				 imax =  tmpi;				 prob = Sign[i].Prob;
			}
		}
		//old is absent
		if (imax ==  2)
			*Dexo  =  8;
		else//doubtful?
		if (prob &  C8)
			*Dexo  =  4;
	}
}

/**************************************
			Encode sceleton
**************************************/
int	CCode::EnCode( byte *dst )
{
	Lpck = C_size;  //tune
	Pack = 
	GetLay(_TEMP_,C_pack);

	//encode some sceleton
	Docvie = (tvii)&CCode::EnTune;
	Docisi = (tv_v)&CCode::EnCodeV;
	Scenes(  2,2,H0,H0  );

	//restore the skeleton
	Docvie = (tvii)&CCode::EnTune;
	Docisi = (tv_v)&CCode::EnOrig;
	Scenew(   2,H0,H0   );

	//stores a string size
	SaveSz(  Pack,Lpck  );

	//if try size
	if (dst == 0)
		Lpck = EnNode(     0,Pack );
	else
	{
		//do signature
		dst[0]   =  1;
		//common pack!
		Lpck = EnNode( dst+1,Pack );
	}

	//destroy a local link
	DelLay(_TEMP_,C_pack);
	return Lpck+1; //total
}

/**************************************
			Decode sceleton
**************************************/
int	CCode::DeCode( byte *src )
{
	//tune in the pack-lay
	Pack = 
	GetLay(_TEMP_,C_pack);

	//decode a packed code
	DeNode( Pack,src +1 );

	//read the packed size
        int size = 0;
	ReadSz(  Pack, size  );
        Imax = size;

	//restore packed data!
	if(Pack[Imax-1] != 8)
		Pack[Imax-1]  = 8 ;

	//builds lay to unwrap
	Docvie = (tvii)&CCode::DeTune;
	Docisi = (tv_v)&CCode::DeCodeV;
	Scenew(   2,H0,H0   );

	//draw common sceleton
	for (Lpck = C_size; Lpck < Imax;)
	{
		//restore a start position
		Srcx  = Pack[Lpck++];
		Srcx += Pack[Lpck  ]	<< 8;
		Srcx &= 0xfff;
		Srcy  = Pack[Lpck++] >> 4;
		Srcy += Pack[Lpck++] << 4;

		//mounts skeleton position
		ProLay( UNPACK,Srcx,Srcy,H0 );

		//try restore two branches
		if (Chaind(C_deep) != SUCCES)
			break;
	}

	//destroy a local link
	DelLay(_TEMP_,C_pack);

	//watch correspondence
	return Lpck == Imax ? SUCCES:
								 RUINED;
}

/**************************************
		Reconstruct processing image
**************************************/

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
