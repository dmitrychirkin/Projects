/**************************************
				Confer.cpp
 Filter based on topology & geometry.

			Author Gudkov V.U.
**************************************/

//	Header project files
#include		"access73.h"
#include		"mathem73.h"
#include		"moulds73.h"
#include		"search73.h"
#include		"sorter73.h"
#include		"virtue73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

/**************************************
		Sort fragment development
**************************************/
static int sort( CCand a,CCand b )
{
	return a.Simi < b.Simi;
}
/*
static int clash( Graph *dst,Graph *src,int ncan )
{
	int inum = src->Cand[ncan].CapI->Nord;
	int tnum = src->Cand[ncan].CapT->Nord;

	return src->Free[inum] & 0x01 && 
			 dst->Free[inum] & 0x01 ||
			 src->Free[tnum] & 0x10 && 
			 dst->Free[tnum] & 0x10 ||
			 src->Free[inum] & 0x02 && 
			 dst->Free[inum] & 0x02 &&
			 src->Free[tnum] & 0x20 && 
			 dst->Free[tnum] & 0x20;
}
*/
/**************************************
	Estimate the nest in every branch
**************************************/

//	Estimates one branch
int	CKnow::Branch( char *tab,int i,CNest *dst,CNest *src )
{
	//default data
	int j,ires = -1,
			fine,
			rate;

	//link out of the nest?
	if ((j = tab[i]) < dst->Wnet) 
	{
		//look over the source
		for (int n = 0; n < _VIR_; n++)
		{
			//skips the broken link
			if (src->Deal[n][i] == E0) 
				continue;

			//look over the destination
			for (int m = 0; m < _VIR_; m++)
			{
				//skips the broken link
				if (dst->Deal[m][j] == E0)
					continue;

				//get penalty for transformation
				fine =	MAX  (src->Fine[n][i], 
									dst->Fine[m][j]);

				//parse complementary events for source
				switch(TabPar[src->Deal[n][i] + (dst->Deal[m][j] << 4)])
				{
					//group E1
					case	1:
					case	2:
					case	3:
					case	4:
					case	5:
					case	6:
					case	7:
					case	8:
					case	9:
					case 10:
					case 11:
					case 12:	fine += TbFine(17); break;
					//group E2
					case 31:
					case 32:
					case 33:
					case 34:
					case 35:
					case 36:
					case 37:
					case 38:
					case 39:
					case 40:
					case 41:
					case 42:
					case 43:
					case 44:
					case 45:
					case 46:
					case 47:
					case 48:
					case 49:
					case 50:	fine += TbFine(18); break;
					//group E3
					case 61:
					case 62:
					case 63:
					case 64:
					case 65:
					case 66:
					case 67:
					case 68:
					case 69:
					case 70:
					case 71:
					case 72:
					case 73:
					case 74:
					case 75:
					case 76:	fine += TbFine(19); break;
					//another
					default: fine += TbFine(20); break;
				}

				//measure penalty
				rate  = src->Size[n][i]-dst->Size[m][j];
				rate  = ABS( rate ) << 10;		//caution!
				rate /= src->Size[n][i]+dst->Size[m][j];

				//select the best
				if ((rate += fine) < ires || ires < 0 )
				{
					src->Trap = src->Tree[n][i];
					dst->Trap = dst->Tree[m][j]; ires = rate;
				}
			}
		}
	}
	//final value
	return  ires;
}

//	Estimates all branches of the nest
int	CKnow::Branch( char *tab,CNest *dst,CNest *src )
{
	//local data..
	int	sum = 0,
			num = 0,
			end = 0;

	//estimation..
	for (int i = 0,x; i < src->Wnet; i++)
	{
		//estimate separate branch
		if ((x = Branch( tab,i,dst,src )) < 0)
			end++  ;
		else
		{
			//gather
			sum+= x;
			num++	 ;
		}
	}

	//estimation with a penalty
	return TbFine(tab) + TbFine(0)*end + DIP( sum,num );
}

/**************************************
			Nest examination
**************************************/

//	Examination the hypothesis for nest
void	CKnow::ExNest( char *tab,CNest *dst,CNest *src,CCand *can )
{
	int	tmp;//estimation

	//build isomer of nest
	Isomer( tab,dst,src );

	//estimates hypothesis
	if(can->Simi > (tmp = Branch( tab,dst,src )) || can->Simi < 0)
	{
		can->CapI = src;
		can->CapT = dst;
		can->Simi = tmp;
		can->Kind = tab;
	}
}

//	Nest examination
void	CKnow::ExNest( CNest	*dst,CNest *src,CCand *can )
{
	//prepare queue
	can->Simi = -1;

	//ending and ending
	if (dst->Type == BE && BE == src->Type)
	{
		ExNest( TabNot,dst,src,can );
		ExNest( TabEsr,dst,src,can );
		ExNest( TabEsl,dst,src,can );
	}
	else//bifurcation and bifurcation
	if (dst->Type == BB && BB == src->Type)
	{
		ExNest( TabNot,dst,src,can );
		ExNest( TabBcr,dst,src,can );
		ExNest( TabBcl,dst,src,can );
	}
	else//ending and bifurcation
	if (dst->Type == BE && BB == src->Type)
	{
		ExNest( TabEcr,dst,src,can );
		ExNest( TabEcl,dst,src,can );
	}
	else//ending and bifurcation
	if (dst->Type == BB && BE == src->Type)
	{
		ExNest( TabBbr,dst,src,can );
		ExNest( TabBbl,dst,src,can );
	}
}

/**************************************
		Define source of fragments
**************************************/

//	Is list for the same source
int	CKnow::Native( int srci,int srcj )
{
	return Cand[srci].CapI->Nord == Cand[srcj].CapI->Nord;
}

//	Presses source list
void	CKnow::Tender( void )
{
	while (Cand[Head].Simi*TbFine(31) > Cand[Tail].Simi*64 && Ncan > 1)
	{
		Head--;
		Ncan--;
	}
}

//	Reduce candidate list
void	CKnow::Reduce( void )
{
	//clear candidate,set shift
	int head = Head; Disp = 16;
						  Head = 
						  Tail =  0;

	//look throw list of nest
	for (int i = 0; i < head; )
	{
		//prepare source data
		Ncan = 0; Tail = Head; 

		//look throw list of nest
		for (int j = i; i < head; i++)
		{
			//native list of order ?
			if (!Native(i,j))	break;

			//estimates nest to nest
			ExNest( Cand[i].CapT,
					  Cand[i].CapI,
					 &Cand[Head]	 );

			//sort & find best pairs
			isort( Cand,sort,Head,
								  Tail );

			//can be the nest leader
			if (Ncan < _CAN_)
			{
				 Head++;
				 Ncan++;
			}
		}
		//tender
		Tender();
	}
}

//	Define the free source
void	CKnow::Source( void )
{
	//clear candidate,set shift
	Head = Tail	= 0; Disp = 48;

	//look throw list of nest
	for (uint i = 0; i < Icon.Nmin; i++)
	{
		//prepare source data
		Ncan = 0; Tail = Head; 

		//look throw list of nest
		for (uint j = 0; j < Test.Nmin; j++)
		{
			//estimates nest to nest
			ExNest( &Test.Nest[j],
					  &Icon.Nest[i],
					  &Cand[Head]   );

			//sort & find best pairs
			isort( Cand,sort,Head,
								  Tail );

			//can be the nest leader
			if (Ncan < _CAN_)
			{
				 Head++;
				 Ncan++;
			}
		}
		//tender
		Tender();
	}
}

/**************************************
			Fragments gusher
**************************************/
void	CKnow::Gusher( void )
{
	//prepare then set shift
	Elim = Time = 0; Disp = 80;

	//defines horizont, lays
	Over = MAX( Test.Nmin,
					Icon.Nmin );
	Hori = MIN( Test.Nmin,
					Icon.Nmin );
	Hori = MIN(_DEV_,Hori );
	Lays = MIN(_LAY_,Head );

	//verify gusher quantity
	if (!Lays)
		throw	 What = NOLAYS;

	//verify horizont length
	if (!Hori)
		throw	 What = NOHORI;

	//a list of best gushers
	isort(Cand,sort,Head-1);

	//load dukes to develop gusher, check limit
	for (int i = 0,n = Lays/6+1; i < Lays; i++)
	{
		//load the <i> candidate

		CCand	 *can =  &Cand[i];

		//new 2 nests estimation
		ExNest( can->CapT,
				  can->CapI,can );
		Duke[i].Loader(  *can );
		Duke[i].Resets(  Over );

		//estimate the couples
		if (i < n)
			Elim +=  can->Simi;
	}
}

/**************************************
		Develop the fragments
**************************************/

//	Insert apex into trajectory
int	CKnow::Insert( Graph *lay )
{
	//watch look-ahead list
	for (int h = lay->Head,t = lay->Tail+1; t < h; t++)
	{
		//will be minutiae splited?
		if((lay->Cand[t].CapI->Nord	!= 
			 lay->Cand[h].CapI->Nord)	&&
			(lay->Cand[t].CapT->Nord	!= 
			 lay->Cand[h].CapT->Nord))			continue;

		//select the best candidate
		if (lay->Cand[t].Simi			<=
			 lay->Cand[h].Simi)					return 0;

			 //free nest
			 lay->Free[
			 lay->Cand[t].CapI->Nord]  &=			~0x02;
			 lay->Free[
			 lay->Cand[t].CapT->Nord]  &=   		~0x20;
			 //veil nest
			 lay->Free[
			 lay->Cand[h].CapI->Nord]  |=   		 0x02;
			 lay->Free[
			 lay->Cand[h].CapT->Nord]  |=   		 0x20;

			 lay->Cand[t] = lay->Cand[h];		return 0;
	}
	//advance
	return 1;
}

//	Split apex of the tail of list
int	CKnow::Splits( Graph *lay )
{
	//set quick reference to the local nest
	CNest	*src = lay->Cand[lay->Tail].CapI,
			*dst = lay->Cand[lay->Tail].CapT;
	char	*tab = lay->Cand[lay->Tail].Kind;

	//list of nests was exhausted ?
	if(lay->Tail    >=   lay->Head)
		lay->Lose =  TbFine(30);

	if(lay->Lose >= TbFine(30))
		return 0;

	//if anybody was splitted before 
	if(lay->Free[src->Nord] &	0x01)
		return 0;
	else
	if(lay->Free[dst->Nord] &	0x10)
		return 0;
	else//remark
	{
		lay->Free[src->Nord] |= 0x01;
		lay->Free[dst->Nord] |= 0x10;
	}

	//build isomer of nest
	Isomer( tab,dst,src );	 Time++;

	//look over branches
	for (int i = 0,x; i < src->Wnet; i++)
	{
		//interior buffer exhausted ?
		if (lay->Head >= Hori) break;

		//if branch exist
		if ((x = Branch( tab,i,dst,src )) != -1)
		{
			//src nest was before splited ?
			if ( lay->Free[src->Trap->Nord]
										   & 0x01)	continue;
			//dst nest was before splited ?
			if ( lay->Free[dst->Trap->Nord]
										   & 0x10)	continue;
			//if pear of nest was estimated
			if ((lay->Free[src->Trap->Nord]
										   & 0x02)	&&
				 (lay->Free[dst->Trap->Nord]
											& 0x20))	continue;

			//setup flag for estimated nest
			lay->Free[src->Trap->Nord] |=
											  0x02;
			lay->Free[dst->Trap->Nord] |=   
											  0x20;

			//estimate 2 nests
			ExNest( dst->Trap,
					  src->Trap,&lay->Cand[lay->Head] );

			//assemble nest and rib balance
			lay->Cand[lay->Head].Simi += x;

			//insert the apex of trajectory
			lay->Head += Insert( lay );//++
		}
	}

	//up best
	isort( lay->Cand,sort,lay->Head-1,++lay->Tail );

	//success
	return 1;
}

//	Survey graph probability
int	CKnow::Survey( Graph *lay )

{
	//loss amount sufficiently ?
	if (lay->Lose >= TbFine(30))	
		return 0;

	//look throw this trajectory
	int i = 0,qual = 0;
	for (; i < lay->Head; i++)
	{
		qual+= lay->Cand[i].Simi;
	}

	//get the trajectory quality
	return Hori*(qual/lay->Head)
						  /lay->Head;
}

//	Select trajectory to develop
void	CKnow::Select( void )
{
	//reference
	Graph *src,
			*dst;

	//look throw the sources
	for (int i = 0; i < Lays; i++)
	{
		//if duke still active
		if((src = &Duke[i])->Lose >= TbFine(30)) 
			continue;

		//verify pairs of source trajectory
		for (int n = 0; n < src->Head; n++)
		{
			//get number of pair of minutiaes..
			int inum = src->Cand[n].CapI->Nord;
			int tnum = src->Cand[n].CapT->Nord;

			//look throw the destinations
			for (int j = i; j < Lays; j++)
			{
				if((dst = &Duke[j])->Lose >= TbFine(30)) 
					continue;

				//if dukes came into collision
				if (src->Free[inum] & 0x03 && 
					 dst->Free[inum] & 0x03 ||
					 src->Free[tnum] & 0x30 && 
					 dst->Free[tnum] & 0x30)	
				{
					//select a trajectory
					if (View[j]  > View[i])
					{
						dst->Lose++;
						if (Mark  > View[i] || Mark == -1)
							{Mark  = View[i];   Gold =  i;}
					}
					//select a trajectory
					if (View[j]  < View[i])
					{
						src->Lose++;
						if (Mark  > View[j] || Mark == -1)
							{Mark  = View[j];   Gold =  j;}
					}
					//select a trajectory
					if (View[j] == View[i])
					{
						if (Mark  > View[i] || Mark == -1)
							{Mark  = View[i];   Gold =  i;}
					}
				}
			}
		}
	}
}
	
//--------------------------------------
//	Develop the fragments
//--------------------------------------
void	CKnow::Growth( void )
{
	//a tuning
	Disp = 80;

	//develop a fragment interior
	for (int j = 0,i; j < Hori; j++)
	{
		int iter = 0; //iterations

		//simultaniously splitting
		for (i = 0; i < Lays; i++)
		{
			iter += Splits( &Duke[i] );
		}

		if (!iter) break;   //stop

		//estimate the development
		for (i = 0; i < Lays; i++)
		{
			View[i]=Survey( &Duke[i] );
		}

		//select better trajectory
		Mark = Gold = -1;		Select();
	}
}

/**************************************
			Common search
**************************************/
int	CKnow::Search( int goal )
{
	//preparation
	Goal  = goal;

	//find tether
	if(Expres())
		Reduce();
	else
		Source();

	//develop
	Gusher();
	Growth();

	//calculate new quality of path!!!

	//estimation
	return  Mark;
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
