/**************************************
				Search.cpp
	 Definitions for compatible.

			Author Gudkov V.U.
**************************************/

//	Header project files
#include		"access73.h"
#include		"inline73.h"
#include		"mathem73.h"
#include		"moulds73.h"
#include		"packed73.h"
#include		"search73.h"	
#include		"virtue73.h"	

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

/**************************************
		Simple inline function
**************************************/
static bool quick = false;

//	Verify type of image
static inline int verify( byte type )
{
	return type == 'L' ||
			 type == 'F' ||
			 type == 'P' ||
			 type == 'S';
}

//	Verify deep of section
static inline int vernet( byte deep )
{
	return deep >= NETMIN && 
			 deep <= NETMAX;
}

//	Verify harmon value
static inline int harmon( byte harm, bool quick )
{
	return harm >= (quick? HL_Q : HL)* HP &&
			 harm <= (quick? HH_Q : HH)* HP;
}

/**************************************
		Load data and match
**************************************/

//	Load query and build pattern
int	CKnow::Loader( byte *src )
{
	//load icon
	if ((What = Icon.Loader( src )) != SUCCES)
		return What;
	//load test
	if ((What = Test.Loader( src )) != SUCCES)
		return What;

	//penalties
	return Goal = Search( PRESS );
}

//	Kernal of common search
int	CKnow::Search( byte *dst )
{
	//strangers constant
	const int Cmatch = 1500;

	//depacks only test
	if ((What =	Test.Loader( dst )) != SUCCES)
		return What;

	//the targets penalty!
	if ((Mark = Search( Goal )) < 0)
		return Mark;

	//calc tested penalty!
	return 1000*MAX( Cmatch-Mark )/
						( Cmatch-Goal );
}
				
//	Save native pairs of minutiaes
int	CKnow::Native( CPair *dst )
{
	//setup the best fragment
	Graph *grh = &Duke[Gold];

	//verify
	if (dst)	
	{
		for (int i = 0; i < grh->Head; i++)
		{
			dst[i].Icon = grh->Cand[i].CapI->Nord;
			dst[i].Test = grh->Cand[i].CapT->Nord;
		}
	}

	//return quantity
	return grh->Head;
}

/**************************************
		Build synthetic data
**************************************/

//	Set common divided data
void	Comer::Ground( void )
{
	//look over the minutiaes
	for (uint i = 0; i < Nmin; i++)
	{
		//divide among nests
		Nest[i].Harm = Harm;
		Nest[i].Gene = 0;	
		Nest[i].Nord = i;	
		Nest[i].Trap = 0;	
		Nest[i].Prox = 0;	
		Nest[i].Qual = Qual;
	}
}

//	Generate data for tether
void	Comer::Tether( void )
{
	//look over the indignations
	for (uint i = 0,n = 0,t; i < Nind; i++)
	{
		//skip if Indi[i].Type is axe
		if ((t = Indi[i].Type) == FX )
			continue;
		
		//look over the minutiaes list
		for (uint j = 0; j < Nmin; j++)
		{
			//measure a distance 
			Nest[j].Geom[n].Size = _MUL_*Tdists( Indi[i],Nest[j] ) /
																				Harm;
			//measure an azimuth
			Nest[j].Geom[n].Azim = upci( Tcompl( Indi[i],Nest[j] ));

			//define the turning
			Nest[j].Geom[n].Beta = upci( Tturns( Indi[i],Nest[j] ));

			//++indignation type
			Nest[j].Geom[n].Type = t  ;
			Nest[j].Gene			= n+1;
		}
		++n;		//common indignations
	}
}

/**************************************
		Recognize unstable fragments
**************************************/

//	Rule to define short distance
static inline uint istiny( CNest *src,CNest *con )
{
	return Tdists( *src,*con )*HP < (uint)(src->Lace + con->Lace);
}

//	Recognize some unstable branch, bridge, island
static inline void steady( byte *tab,CNest *src,int link )
{
	//look throw the permissible event
	for (register int i = 0; tab[i]; i++ )
	{
		//extract the pointer from tree
		CNest *con = src->Tree[0][link];

		//verify the events on the link
		if(tab[i] == src->Deal[0][link])
		{
			//branch,bridge,island
			if (istiny( src,con ))
			{
				src->Prox =
				con->Prox = 1; //up
			}
		}
	}
}

//-------------------------------------
//	Recognize unstability
//-------------------------------------
void	Comer::Steady( void )
{
	byte	tab_com[] = {Ef,E7,Eb},
			tab_one[] = {E3		};

	//scan the list of minutiae up end
	for (uint i = 0; i < Nmin; i++)
	{
		//verify ending
		if(Nest[i].Type) 

		{
			steady( tab_com,&Nest[i],0 );
		}
		else//bifurcation
		{
			steady( tab_one,&Nest[i],0 );
			steady( tab_com,&Nest[i],1 );
			steady( tab_com,&Nest[i],2 );
		}
	}
}

/**************************************
		Full and partial loading
**************************************/

//	Decode list of ridge count
int	Comer::DeAbac( byte *src )
{
	//set buffer of
	uint *abuf = DRidge<uint*>(src),
			alin = 0,
			abit = 0,
			data = 0,
			temp = 0,
			base = 0,
			size = QRidge<uint >(src);

	//verify length of local buffer!
	if ((byte*)abuf+size > src+Ncod)
		return 0;
	//parameter!
	if (!size)		 //initialization
		return 1;	  data = abuf[0];

	//unpack ridge count
	for (uint i = 0; (alin << 2) + (abit >> 3) + (abit & 7 ? 1 : 0) < size; i++)
	{
		//look over the indignations
		for (uint j = 0; j < Nind; j++)
		{
			//skip if Indi[j] - axe
			if (Indi[j].Type == FX)
				continue;

			DEBIT2( abuf,alin,abit,data,base );
			if (base)
			{
				DEBITS( abuf,alin,abit,data,temp,5 );
				base += temp << 2;
			}

			Nest[i].Abac[j] = base;
		}
	}

	//were ridge count unpacked successful?
	return (alin << 2) + (abit >> 3) + (abit & 7 ? 1 : 0) == size;
}

//	Decode list of indignations
int	Comer::DeIndi( byte *src)
{
	//set buffer of
	uint *abuf = DFocus<uint*>(src),
			alin = 0,
			abit = 0,
			data = 0,
			temp = 0,
			size = QFocus<uint >(src);

	//verify length of local buffer!
	if ((byte*)abuf+size > src+Ncod)
		return 0;
	//parameter!
	if (!size)		 //initialization
		return 1;	  data = abuf[0];

	//a header	
	DEBIT4( abuf,alin,abit,data,temp ); uint movx = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint movy = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint type = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint lace = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint prob = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint beta = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint look = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint curl = temp;

	//unpack indignations
	int i = 0;
	for (; (alin << 2) + (abit >> 3) + (abit & 7 ? 1 : 0) < size && i < _IND_; i++)
	{
		DEBITS( abuf,alin,abit,data,temp,movx ); Indi[i].Movx = temp;
		DEBITS( abuf,alin,abit,data,temp,movy ); Indi[i].Movy = temp;
		DEBITS( abuf,alin,abit,data,temp,5    ); Indi[i].Type = temp;
		DEBITS( abuf,alin,abit,data,temp,lace ); Indi[i].Lace = temp + HP*(quick? HL_Q : HL);
		DEBITS( abuf,alin,abit,data,temp,6    ); Indi[i].Prob = temp;
		DEBITS( abuf,alin,abit,data,temp,8    ); Indi[i].Beta = temp;
	}
	//unpack successful ?
				Nind =  i;
	return  (alin << 2) + (abit >> 3) + (abit & 7 ? 1 : 0) == size;
}

//	Decode list of minutiaes
int	Comer::DeNest( byte *src )
{
	//set buffer of
	uint *abuf = DPoint<uint*>(src),
			alin = 0,
			abit = 0,
			data = 0,
			temp = 0,
			size = QPoint<uint >(src);

	//verify length of local buffer!
	if ((byte*)abuf+size > src+Ncod)
		return 0;
	//parameter!
	if (!size)		 
		return 1;	  
	//initialization
#ifndef _WIN32_WCE
	data = abuf[0];
#else
	data = getUint((byte*)abuf);
#endif

	//a header	
	DEBIT4( abuf,alin,abit,data,temp ); uint movx = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint movy = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint type = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint lace = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint prob = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint beta = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint look = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint curl = temp;

	//unpack indignations
	int i = 0;
	for (; (alin << 2) + (abit >> 3) + (abit & 7 ? 1 : 0) < size && i < NESTS; i++)
	{
		DEBITS( abuf,alin,abit,data,temp,movx ); Nest[i].Movx = temp;
		DEBITS( abuf,alin,abit,data,temp,movy ); Nest[i].Movy = temp;
		DEBIT1( abuf,alin,abit,data,temp      ); Nest[i].Type = temp;
		DEBITS( abuf,alin,abit,data,temp,lace ); Nest[i].Lace = temp + HP*(quick? HL_Q : HL);
		DEBITS( abuf,alin,abit,data,temp,8    ); Nest[i].Prob = temp;
		DEBITS( abuf,alin,abit,data,temp,8    ); Nest[i].Beta = temp;
	}
	//unpack successful ?
				Nmin =  i;
	return  (alin << 2) + (abit >> 3) + (abit & 7 ? 1 : 0) == size;
}

//	Decode list of linkages
int	Comer::DeLink( byte *src,byte tree )
{
	//set buffer of
	uint *abuf = DLinks<uint*>(src),
			alin = 0,
			abit = 0,
			data = 0,
			temp = 0,
			imul =   _MUL_*_MUL_/Harm,
			deal = 0,
			pink = 0,
			base = 0,
			quan = 0,
			size = QLinks<uint >(src);

	//verify length of local buffer!
	if ((byte*)abuf+size > src+Ncod)
		return 0;
	//parameter!
	if (!size)		 
		return 1;	 
	//initialization
#ifndef _WIN32_WCE
	data = abuf[0];
#else
	data = getUint((byte*)abuf);
#endif
	//a header	
	DEBIT4( abuf,alin,abit,data,temp ); uint four = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint trio = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint twob = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint oneb = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint nmin = temp;
	DEBIT4( abuf,alin,abit,data,temp ); uint rest = temp;

	//unpack linkages
	for (uint i = 0,j,lim; (alin << 2) + (abit >> 3) + (abit & 7 ? 1 : 0) < size && i < Nmin; i++)
	{
		//calculate the depth of the nest
		if(Nest[i].Type == BE)
			Nest[i].Wnet = lim = Deep*2-1;
		else
			Nest[i].Wnet = lim = Deep*2+1;

		//look section over a net
		for (j = 0; j < lim; j++)
		{
			//reset tree!
			if (tree & 2)
			{
				//rebuild alternative nests
				for (uint u = 0; u < _VIR_; u++)
				{
					Nest[i].Tree[u][j] = 00;
					Nest[i].Item[u][j] =
					Nest[i].Size[u][j] =
					Nest[i].Fine[u][j] = 00;
				}
			}

			//read event from buffer
			DEBIT2( abuf,alin,abit,data,deal  );
			//exist ?
			if (deal)
			{
				//complicative
				if (deal == 3)
				{
					DEBIT2( abuf,alin,abit,data,temp );
					deal += temp << 2;
					DEBIT1( abuf,alin,abit,data,pink );
				}
				else
				{
					DEBIT1( abuf,alin,abit,data,temp );
					deal += temp << 2;	  pink = 0;	 ;
				}
				Nest[i].Deal[0][j] = deal;
				Nest[i].Pink[0][j] = pink;
			}
			else
			{
				Nest[i].Deal[0][j] =	0;	 ;
				Nest[i].Pink[0][j] = 0;	 ;
			}
		}

		//gets low number in the nest & quants
		DEBITS( abuf,alin,abit,data,base,nmin );
		DEBITS( abuf,alin,abit,data,quan,rest );

		//look section over a net
		for (j = 0; j < lim; j++)
		{
			//does it was broken ?
			if(Nest[i].Deal[0][j])
			{
				DEBITS( abuf,alin,abit,data,temp,quan );

				//get the number
				if((Nest[i].Item[0][j] = (temp += base)) >=	Nmin	)
					return 0;

				//restore events
				if (Nest[temp].Type == BE)	  Nest[i].Deal[0][j] |= 8;

				//tree size !
				if (tree & 1)
				{
					//size of branch
					Nest[i].Size[0][j] = Tdists( Nest[i],Nest[temp] )*
																	 imul/_MUL_  ;
				}
				//tree branch
				if (tree & 2)
				{
					//generates tree
					Nest[i].Tree[0][j] = &Nest[temp];
				}

			}
		}
	}

	//were linkages unpacked successful ?
	return  (alin << 2) + (abit >> 3) + (abit & 7 ? 1 : 0) == size;
}

//	Decode list of areas
int	Comer::DeArea( byte *dst,byte *src )
{
	//do local data
	uint  temp = QAreas<uint >( src ),
			lpck = 4,
			qual = 0;
	//local pointer
	byte *pack = DAreas<byte*>( src ),
		  *movo = dst;	

	//verify length
	if(temp < lpck)
		return	 0;

	//restore x&y dimension
	Reax = (pack[1] << 8) +
			  pack[0]	    ;
	Reay = (pack[3] << 8) +
			  pack[2]	    ;

	//tune the first length
	uint	size = Reax*Reay,
			calc = pack[lpck++ ];

	//unpack
	for (uint i  = 0; i < size; i++)
	{
		//if end phase
		if (calc == 0)
		{
			qual = !qual; temp--;
			calc =  pack[lpck++];
		}
		//if end phase
		if (calc == 0)
		{
			qual = !qual; temp--;
			calc =  pack[lpck++];
		}
		//unwrap
		if (calc)
		{
			//mark an area
			if (qual == 0)
				*movo = C7;
			else
				*movo = C6;

			//advance data
				 movo++;
				 calc--;
		}
	}
	//verify the list
	return temp == 5;
}

//-------------------------------------
//	Assemble data decoding
//-------------------------------------

//	Quick decode only part of data
int	Comer::DeCase( byte *dst,byte *src,byte tree,byte type )
{
	//prepare base data..
	Harm = Densit<byte>( src )+ HP*(quick? HL_Q : HL);
	Mask = ImMask<byte>( src );
	Type = ImType<byte>( src );
	Qual = Qualit<byte>( src );
	Deep = TipNet<byte>( src );
	Ncod = QPower<uint>( src );

	//verify image type
	if (!verify( Type ))
		return NODATA;

	//verify net of nest
	if (!vernet( Deep ))
		return NODATA;

	//verify real harmon
	if (!harmon( Harm, quick ))
		return NODATA;

	//load indignations
	if ((type & C1) && !DeIndi( src ))
		return NOINDI;

	//load minutiaes
	if ((type & C2) && !DeNest( src ))
		return NONEST;

	//load ridge count
	if ((type & C3) && !DeAbac( src ))
		return NOABAC;

	//load linkages
	if ((type & C4) && !DeLink( src,tree ))
		return NOLINK;

	//load regions
	if ((type & C5) && !DeArea( dst,src ))
		return NOAREA;

		//form success
		return SUCCES;
}

//	Quick decode all data
int	Comer::DeCode( byte *dst,byte *src,byte tree )
{
	return DeCase( dst,src,tree,0xff);
}

//-------------------------------------
//	Assemble data loading
//-------------------------------------
int	Comer::Loader( byte *src,byte type )
{
	//decode the data of sign
	if ((What = DeCode( 0,src,1 )) != SUCCES)
		return	What;
	else
	{
		Ground(); //ok
		Tether(); //ok
		Steady(); //ok

		//form success
		return	What;
	}
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
