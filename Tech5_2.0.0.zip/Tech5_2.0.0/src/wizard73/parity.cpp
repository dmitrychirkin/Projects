/**************************************
 Reform and reconstruction of image.

Copyright (c) 1994-2006 by V.U. Gudkov.
**************************************/

#include "wizard73.h"
#include "wiBase73.h"
//	Header project file

namespace wizard73{

   enum
{//architecture definitions
   PARITY_NOISE = 3,
   PARITY_EQUAL = 64
};

	//----------------------------------
	//	Tune communications
	//----------------------------------
   void CWork::parity_tune( int _Dsth,int _Srch )
		{//tune red-green-blue palette
		Srco = GetLay(	SOURCE,_Srch );
      //Srco = GetLay(	NORMAL,_Srch );
		Snxo = GetLay(	PARITY,_Srch );
      //Snxo = GetLay(	NORMAL,_Srch );
		}

	//----------------------------------
	//	Subfunctions
	//----------------------------------
	void CWork::parity_get(int,int)
		{//measure probability of parity 
			++Pran;
		if (*Movo <= *Srco)
			++Qran;
		}

	void CWork::parity_set( byte* _Dst )
		{//store parity result
//		*_Dst = (256*(*Srco*PARITY_NOISE + Qran*PARITY_EQUAL)/
//						 (  256*PARITY_NOISE + Pran*PARITY_EQUAL) - *Srco)/2 + BA;
		*_Dst = (255*(*Srco*PARITY_NOISE + Qran*PARITY_EQUAL)/
						 (  256*PARITY_NOISE + Pran*PARITY_EQUAL));
		}

	//----------------------------------
	//	Kernal functions
	//----------------------------------
	void CWork::parity_work()
		{//get probability of current brightness
      Pran = Qran = 1;
		DoMove( &Srco );
      Docexe = (tvii)&CWork::parity_get;
		Spiral( Eche,Clas ); 
      parity_set( Snxo );
		}

	//----------------------------------
	//	Assembly <Parity> functions
	//----------------------------------
	void CWork::parity()
		{//prepare probability of parity 
		if (GetKey( PARITY,H0 ) == -1)
			{
					( Tops=SOUrce );
			      ( Eche=((0)) );
					( Clas=((04)) );

			//fulfill measuring
		   Docvie = (tvii)&CWork::parity_tune;
		   Docisi = (tv_v)&CWork::parity_work;
		   Dociso = (tv_v)&CWork::parity_work;
		   Scenei( 2,Eche,Eche );
			}
		}

}//namespace wizard73{
