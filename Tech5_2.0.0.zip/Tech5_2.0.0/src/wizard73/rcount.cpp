/**************************************
				Rcount.cpp
		  Measure ridge count.

			Author Gudkov V.U.
**************************************/

//	Header file
#include		"mathem73.h"
#include		"moulds73.h"
#include		"packed73.h"
#include		"wizard73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local tune constants
//-------------------------------------
static const 
int	Clevel = H3,
				Stride =  8;

/**************************************
		Restrict ridge count value
**************************************/
static inline int info( int a,int b )
{
	//parse absent data
	if (a < 0 && b < 0)
		return -1;
	if (a < 0)
		return (b << 2) | RT;
	if (b < 0)
		return (a << 2) | RT;

	//curtail measuring
	int v = EVE( a,b );
	int p = MIN( 
			  ABS( a-v ),
			  ABS( b-v )
						  );

	//control measuring
	if (v > RM)
		return -1;	//no
	if (p > RT)
		return -1;	//no
	else
		return (v << 2) | ((p == 0) ? 1 : p);
}

/**************************************
	Tighten two points for ridge count
**************************************/
int	CWork::Rcount( SSign &dst )
{
	//measure ridge count
	int cnt = 0,lay = (*Movo > BS) ? 0:1,dir,aim;
	for (;;)
	{
		//tune moving and faraim
		dir = adir( dst.Movx-Movx,
						dst.Movy-Movy );
		aim = dist( dst.Movx-Movx,
						dst.Movy-Movy );
		
		//out of region?
		if (*Movo == BM)
			return -1;
		else//counting	!
		if (*Movo >  BS)
			  lay = 0;
		else 
		if (!lay)
		{
			++lay;
			++cnt;
		}

		//trajectory end
		if (aim == 0)
			break;

			MvTune( dir , H0);

		if (aim == 1)
			MvMove( dir );
		else//try moving
		if(Chosei( dir ))
			;//try select
		else
			return -1;
	}
	//correct counting !
	return lay ? cnt-1 : cnt;
}

/**************************************
				Keep an eye 
		from source to destination
**************************************/
int	CWork::Rtrace( SCoor &dst,SSign &src )
{
	//set goal position & direction
	int	flow = Talpha( 110,src );

	//mount start position based on source
	ProLay( SKELET,src.Movx,src.Movy,H0 );
	Thre	= dist( Movx,Movy,dst.Movx,
									dst.Movy    );

	//moves to the disposition ridge count
	for (int step = Stride*2; step > 0; )
	{
		//if absent ridge
		if (*Movo == BM)
			return -1;//no

		//move active point to new position
		MvLayI( petx( flow    ),step,0,0 );
		Runs = dist( Movx,Movy,dst.Movx,
									  dst.Movy	);

		//best distance?
		if (Runs < Thre)
		{
			//steps regulator
			if(step > Stride)
				step--;
			else
				step++;
			//save position
			Thre	 =	 Runs;
			DoKeep(&Useo );
		}
		else//unclear
			step /= 2;

		//extract new flow directions to move
		Hypo = *ProRef( FLOW_E,Movx,Movy,H1 );

		//regulates orientation
		if (simu( flow, Hypo ))
			flow = upci( Hypo );
		else
			flow = reci( Hypo );
	}

	//success
	return 0;
}

/**************************************
			Measure ridge count 
**************************************/

//	Get ridge count between two points
int	CWork::Rcount( SSign &dst,SSign &src )
{
	//first ridge count
	ProLay( SKELET,src.Movx,src.Movy,H0,H0 );
	int a = Rcount(dst);

	//second ridge count
	ProLay( SKELET,dst.Movx,dst.Movy,H0,H0 );
	int b = Rcount(src);

	//if pair of branch
	return  info( a,b );
}

//	Ridge count of minutiaes
int	CWork::Rcount( void )
{		
	//find a buffer for ridge count
	Pack = GetLay( LIST_R,Clevel );
	Nlin = 0,
	Nbit = 0;

	//look over the minutiaes
	for (int i = 0,n = 0; i < Nmin; i++)
	{
		//look over the indignations
		for (int j = 0; j < Nind && n < Size[Clevel]; j++)
		{
			//skip if Indi[j] - axe
			if (Indi[j].Type == FX)
				continue;

			//measure ridge count & probability
			if ((n = Rcount( Sign[i],Indi[j] )) < 0)
				EnBits( Pack,&Nlin,&Nbit,0,2 );
			else
				EnBits( Pack,&Nlin,&Nbit,n,7 );
		}
	}

	//make even the active length
	return Nbit ? Nlin +1 : Nlin;
}

//	Indignation ridge count
int	CWork::Rtotal( void )
{
	//find a buffer for ridge count
	Pack = GetLay( LIST_T,Clevel );
	Nlin = 0,
	Nbit = 0;

	//look over the indignations
	for (int i = 0,n = 0; i < Nind-1; i++)
	{
		//look over the indignations
		for (int j = i+1; j < Nind && n < Size[Clevel]; j++)
		{
			//skip if Indi[i] - axe
			if (Indi[i].Type == FX)
				continue;
			//skip if Indi[i] - axe
			if (Indi[j].Type == FX)
				continue;

			//measure ridge count & probability
			if ((n = Rcount( Indi[i],Indi[j] )) < 0)
				EnBits( Pack,&Nlin,&Nbit,0,2 );
			else
				EnBits( Pack,&Nlin,&Nbit,n,7 );
		}
	}

	//make even the active length
	return Nbit ? Nlin +1 : Nlin;
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
