/**************************************
				HueHue.cpp
		Simple work with colour.

			Author Gudkov V.U.
**************************************/

//	Header project files
#include		"assert.h"
#include		"mathem73.h"
#include		"wizard73.h"	

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

/**************************************
	Functions to control the palette
**************************************/

//	Set type of work
void	CHues::Colour( byte type )
{
	if (type == COLOUR)
		 HuSa =  COLOUR;
	else
		 HuSa = !COLOUR;
}

//	Generate invertion pallete
byte	CHues::HueInv( byte *dst,corn pall )
{
	//palette
	int sum = 0, i;
	for (i = 0; i < _PAL_; i++)
	{
		sum += dst[i] = (byte)~(pall >> (i << 3));
	}
	//an average palette
	return VON( sum/i );
}

//	Generate original pallete
byte	CHues::HueOrg( byte *dst,corn pall )
{
	//palette
	int sum = 0, i;
	for (i = 0; i < _PAL_; i++)
	{
		sum += dst[i] = (byte)(pall >> (i << 3));
	}
	//an average palette
	return VON( sum/i );
}

//	Set specific palette
void	CHues::SetHue( int type,corn huew,corn huei )
{
	//parse order
	switch (type)
	{
		case PHOTIC:
		case EMPIRE: //the palette
		case SHADOW: WLum = HueOrg( WHue,huew );
						 ILum = HueInv( IHue,huei );
						 break ;
		case SOURCE: OLum = HueOrg( OHue,huew );
						 break;
		case SKELET: SLum = HueOrg( SHue,huew );
						 break;
		case CCLASS: RLum = HueOrg( RHue,huew );
						 break;
		case FLOW_P: FLum = HueOrg( FHue,huew );
						 DLum = HueOrg( DHue,huei );
						 break;
	}
}

//	Set palette poligons
void	CHues::PolHue( int *pol )
{
	//filling rgb poligons
	for (register int i = 0; i < SRANK; i++)
	{
		//palette
		register int ival = pol[i] -BA;//+-

		//if need gray image
		if	(HuSa	 != COLOUR)
			Brgb[i] = 
			Grgb[i] = 
			Rrgb[i] = ival;//equal value
		else//white
		if (i > BA)
		{
			Brgb[i] = ival*WHue[2]/WLum;
			Grgb[i] = ival*WHue[1]/WLum;
			Rrgb[i] = ival*WHue[0]/WLum;
		}
		else//inked
		{
			Brgb[i] = ival*IHue[2]/ILum;
			Grgb[i] = ival*IHue[1]/ILum;
			Rrgb[i] = ival*IHue[0]/ILum;
		}
	}
}

//	Set original palette poligons
void	CHues::PolHue( int *pol,byte *hue,byte lum )
{
	//filling rgb poligons
	for (register int i = 0; i < SRANK; i++)
	{
		//if need gray image
		if (HuSa  != COLOUR)
			Brgb[i] = 
			Grgb[i] = 
			Rrgb[i] = pol[i];		//equal
		else//hue
		{
			Brgb[i] = pol[i]*hue[2]/lum;
			Grgb[i] = pol[i]*hue[1]/lum;
			Rrgb[i] = pol[i]*hue[0]/lum;
		}
	}
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
