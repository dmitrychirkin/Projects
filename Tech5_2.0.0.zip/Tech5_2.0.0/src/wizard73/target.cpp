/**************************************
				 Target.cpp
		Prepare target on tenprint.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"assert.h"
#include		"mathem73.h"
#include		"sorter73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local tune constants
//-------------------------------------
static const 
int	Clevel =  H3;					//native level

/**************************************
		Tune Target procedure
**************************************/

//	Tune to prepare the target
void	CWork::TaTune( int dsth,int srch )
{
	Srco = GetLay(	SOURCE,srch );
	Shpo = GetLay(	NORMAL,srch );
	Snxo = GetLay(	TARGET,srch );
	Dsto = GetLay(	TARGET,dsth );
}

//	Tune in hierarchy immersion
void	CWork::TaDeep( int dsth,int srch )
{
	Srco = GetLay(	TARGET,srch );
	Dsto = GetLay(	TARGET,dsth );
}

//-------------------------------------
//	Destroy comunications 
//-------------------------------------
template <class T>
static void destroytarget( T *p )
{
	//do nothing
}

/**************************************
		Local inline functions
**************************************/

//	Measure position of moda
template <class T>
static inline void ismoda( T *p )
{
	//find position of moda
	for (int isup = 0,i = 0; i < SRANK; i++)
			if(isup < p->Rank[i])
				isup = p->Rank[p->Llim = i];
}

//	Get untrustable wing
static inline int ismin( int lwing,int rwing )
{
	//check wings
	if (lwing > 0 && rwing > 0)
		return MIN( rwing,lwing );
	else
		return 0;
}

/**************************************
			Virtual subfunctions
**************************************/

//	Measures clear space
void	CWork::TaHist( void )
{
	//build difference scheme based on image
	byte m[] = {ismin( *Srco - *(Srco+1   ),
							 *Srco - *(Srco-1   )),
					ismin( *Srco - *(Srco+2   ),
							 *Srco - *(Srco-2   )),
					ismin( *Srco - *(Srco+Reax),
							 *Srco - *(Srco-Reax)),
					ismin( *Srco - *(Srco+Incx),
							 *Srco - *(Srco-Incx)),
					ismin( *Srco - *(Srco+Decx),		
							 *Srco - *(Srco-Decx)),
					ismin( *Srco - *(Srco+Reax
												+Reax),
							 *Srco - *(Srco-Reax
												-Reax))};

	//set two sublays to catch ten rectangles
	isort( m,less,5 );  ++Rank[ *Shpo = m[2]];
										 *Snxo = m[0] ;
}

//	Set plug
void	CWork::TaPlug( void )
{
	*Shpo =
	*Snxo = 0;//do nothing
}

//	Rebuild clear space
void	CWork::TaArea( void )
{
	Bask += *Shpo = Rank[*Shpo];
	Team++; *Snxo = Rank[*Snxo];
}

//	Inner immersion
void	CWork::TaImmi( void )
{
	//previous done
	*Srco  =  Bask;
}

//	Outward immersion
void	CWork::TaImmo( void )
{
	//a simple copy
	*Srco  = *Dsto;
}

//	Build target sublay
void	CWork::TaMark( void )
{
	Team++; *Shpo = MIN( Rank[*Dsto],MAX( *Shpo,
													  *Dsto ));
	Bask += *Snxo = MIN( Rank[*Dsto],MAX( *Snxo,
													  *Dsto ));
}

//-------------------------------------
//	Upper virtual functions
//-------------------------------------

//	Upper start background
int	CWork::TaPrep( void )
{
	Basket();
	return 1;
}

//	Upper final background
void	CWork::TaDone( void )
{
	*Dsto = DIP( Bask,
					 Team );
}

//	Smooth rank background
int	CWork::TaRank( void )
{	
	++Rank[ Bask = Fiimpn( Dsto )];
	return 1;
}

/**************************************
	Find out the target on tenprint
**************************************/
void	Codex::Target( int reih )
{
	//if source image absent -exit
	if (GetKey( SOURCE,H0 ) == -1)
	{
	}             

	//tune in target queue
	OldLay( Tops=TARget );
			  Eche=Clevel  ;
	
	RanIni(0);//initialize

	//measures clear space
	Docvie = (tvii)&CWork::TaTune;
	Docisi =	(tv_v)&CWork::TaHist;
	Dociso = (tv_v)&CWork::TaPlug;
	Scenes(  2,3,H0,H0  );

	RanBeg( 40 ); //l-edge
	RanEnd( 07 ); //r-edge
	RanRes(    ); //resize

	//collects clear space
	Docvie = (tvii)&CWork::TaTune;
	Docisi = (tv_v)&CWork::TaArea;
	Docupi = (ti_v)&CWork::TaPrep;
	Docfni = (tv_v)&CWork::TaDone;
	Scenew(	0,Eche,H0  );

	//hierarchy projection
	for (Eche = Clevel; Eche > reih; Eche--)
	{
		RanIni(0);//initialize

		//range for background
		Docvie = (tvii)&CWork::TaDeep;
		Docupi = (ti_v)&CWork::TaRank;
		Docisi = (tv_v)&CWork::TaImmi;
		Dociso = (tv_v)&CWork::TaImmo;
		Scenei(0,Eche,Eche-1);
	}

	ismoda(this); //l-edge
	RanEnd( 07 ); //r-edge
	RanRes(    ); //resize

	//builds target sublay
	Docvie = (tvii)&CWork::TaTune;
	Docisi = (tv_v)&CWork::TaMark;
	Docupi = (ti_v)&CWork::TaPrep;
	Docfni = (tv_v)&CWork::TaDone;
	Scenew(	0,Eche,H0  );

	//free temporary links
	for (Eche = Clevel; Eche >= H0; Eche--)
	{
		//destroy a local link
		destroytarget( this );
	}
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
