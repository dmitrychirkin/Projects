/**************************************
				Minuti.cpp
	  Read minutiaes from sceleton.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"assert.h"
#include		"mathem73.h"
#include		"moulds73.h"
#include		"sorter73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local tune constants
//-------------------------------------
static const 
int	Clevel = H1,					//native level
				C_qual = 43;					//tune scaling


/**************************************
			Tune communications
**************************************/
void	CWork::MiTune( int dsth,int srch )
{
	Srco = GetLay(	SKELET,srch );			//skelet
	Shpo = GetLay(	REFINE,srch );			//refine
	Dsto = GetLay(	GOAL_M,dsth );			//fields
	Dhpo = GetLay(	DENS_M,dsth );			//density
   if (integ)
	   Dnxo = GetLay(	FCLASS,dsth );			//fclass
	Dexo = GetLay(	FLOW_E,dsth );			//expert flow
	Dfno = GetLay(	QUAL_M,dsth );			//qualit
	Dwoo = GetLay(	DENSIT,dsth );			//density
	Deio = GetLay(	CCLASS,dsth );			//c-class
	Sign = (SSign*)							//list
			 GetLay( LIST_M,dsth );			//of minutiaes
}

//-------------------------------------
//	Destroy comunications 
//-------------------------------------
template <class T>
static void destroyminuti( T *p )
{
}

/**************************************
			Inline functions
**************************************/

//	Available quantity
static inline int permit( Codex *src )
{
	//minutiae buffer size
	switch (src->ImType)
	{
		case'L':
		case'F':	return MIN( src->Size[Clevel]/sizeof( SSign ),
												 MAXFIN);
		case'P':
		case'S':	return MIN( src->Size[Clevel]/sizeof( SSign ),
												 MAXPAL);
	}
    return 0;
}

//	Adaptate image quality
static inline int	QVS( int ival,int inum )
{
	return	LIM( 100*(ival/C_qual)/inum,0,100 );
}
 
/**************************************
		Process list of minutiaes
**************************************/

//	Set active minutiae
void	CWork::Active( int posx,int posy )
{
	//look throw all minutiaes to find..
	for (Nact =  0; Nact < Nmin; Nact++)
	{
  		if (posx != Sign[Nact].Movx)
			continue;
		if (posy != Sign[Nact].Movy)
			continue;

			//success
			return  ;
	}
			//nothing
			Nact= -1;
}

//	Find nearest minutiae by module
int	CWork::Native( int posx,int posy,int modu )
{
	//look over the list of minutiaes
	int num = -1,min = -1;
	for (int i = 0; i < Nmin; i++)
	{
		//verify module
		if (modu != -1)
		{
			if (modu != (i & MO)) continue ;
		}

		//distance from coordinate to point
		int d	 =	 EVK( Sign[i].Movx-posx,
							Sign[i].Movy-posy );

		//if the best position
  		if(min > d || min < 0)
		{
			min = d;
			num = i;
		}
	}

	//this order..
	return	num ;
}

//	Is the nearest active ?
int	CWork::NativeI( int modu )
{
	return Nact == Native( Movx,Movy,modu );
}

//	Find nearest indignation
int	CWork::Nature( int posx,int posy )
{
	//look over the list of minutiaes
	int num = -1, min = -1;
	for (int i = 0; i < Nind; i++)
	{
		//distance from coordinate to point
		int d	 =	 EVK( Indi[i].Movx-posx,
							Indi[i].Movy-posy );
		//real indignation the best
		if (Indi[i].Type == FX)		 d += 1;


		//if the best position
  		if(min > d || min < 0)
		{
			min = d;
			num = i;
		}
	}

	//this order..
	return	num ;
}

/**************************************
	Read position & alpha of minutiae
**************************************/
//	Read minutiae & alpha
void CWork::MiRead( void )
{
	//remark the pixels - obstacle
	if(*Srco < BU && *Dsto == 8)
	{
		 *Srco = *Shpo = BU; return;
	}
	//minutia?
	if(*Srco >= BU) return;
	//already enough?
	if(Nmin >= Imax) return;


	if(*Srco == BE) //ending
	{
		DoMove(&Srco); Thre = *Dwoo;
		do 
		{ 
			Orient(Thre); Orie = Arms[0].Beta;
		}
		while(--Thre > 3 && cone(Orie, *Dexo) > AQ);
		if(!integ || !(*Dnxo & FF))		

//		if(*Dnxo & FF)		
		{
			if(simu(Orie, *Dexo))
				Orie = *Dexo;
			else
				Orie = reci(*Dexo);
		}
		Orie = Orie/2;
	}
	else //bifurcation
	{
		DoMove(&Srco ); Thre = *Dwoo;
		do
		{			
			Orient( Thre ); //do orienation
			//look over all arms
			for(int tail = 0,head,best = AF,ang,abs; tail < Narm; tail++)
			{
				//get an index untill maximum
				if((head  = tail+1) >= Narm)
					head -= Narm;
				//get angle from head to tail
				ang = turn(Arms[tail].Beta, Arms[head].Beta);
				//select the best orientation
				if((abs = ABS( ang ))> best)
					continue;
				best = abs; //new parameters
				Orie = upci(Arms[tail].Beta - ang/2);
			}
		}
		while(--Thre > 3 && cone(Orie, *Dexo) > AQ);	
		//update local direction
		if(integ && (*Dnxo & FF)) 
//		if(*Dnxo & FF) 

         Orie = reci(Orie);
		else

		{
			if(simu(Orie, *Dexo)) Orie = reci(*Dexo);
			else Orie = *Dexo;
		}
		//arms turn to base orienation
		int i;
		for(i = 0; i < Narm; i++)
		{
			Metr[i] = ABS(turn( Arms[i].Beta, Orie));
		}
		//sort a metric
		bsort(Arms, Metr, less, Narm);
		//turn clocwize upto direction
		for(i = 0; i < Narm; i++)
		{
			Metr[i] = cloc(Arms[i].Beta, Arms[0].Beta);
		}
		//sort a metric
		bsort(Arms, Metr, less, Narm);
		//bifurcation input
		*Arms[1].Join = BL; *Arms[2].Join = BR;
		Orie = reci(Orie)/2;
	}
	//set current parametersz
	Sign[Nmin].Type = *Srco;
	Sign[Nmin].Movx = Srcx;
	Sign[Nmin].Movy = Srcy;
	Sign[Nmin].Beta = Orie;
	Sign[Nmin].Lace = *Dhpo; 
	Sign[Nmin].Prob = *Dfno;  //if dubious
	Sign[Nmin].Prob|= *Dsto == 4 ? C8 : 0;
	++Nmin;
}

//	Read minutiae & alpha   in ISO compatible manner
void CWork::MiReadIso( void )
{
	//remark the pixels - obstacle
	if(*Srco < BU && *Dsto == 8)
	{
		 *Srco = *Shpo = BU; return;
	}
	//minutia?
	if(*Srco >= BU) return;
	//already enough?
	if(Nmin >= Imax) return;

	if(*Srco == BE) //ending
	{
      Thre = 16;
		DoMove(&Srco); //Thre = *Dwoo;
		do 
		{ 
			Orient(Thre); Orie = Arms[0].Beta;
		}
		while(--Thre > 3 && cone(Orie, *Dexo) > AQ);

//		if(!integ || !(*Dnxo & FF))		
//		if(*Dnxo & FF)		
		{
//			if(simu(Orie, *Dexo))
//				Orie = *Dexo;
//			else
//				Orie = reci(*Dexo);
		}
		Orie = Orie/2;
	}
	else //bifurcation
	{
      Thre = 16;
		DoMove(&Srco ); //Thre = *Dwoo;
		do
		{			
			Orient( Thre ); //do orienation
			//look over all arms
			for(int tail = 0,head,best = AF,ang,abs; tail < Narm; tail++)
			{
				//get an index untill maximum
				if((head  = tail+1) >= Narm)
					head -= Narm;
				//get angle from head to tail
				ang = turn(Arms[tail].Beta, Arms[head].Beta);
				//select the best orientation
				if((abs = ABS( ang ))> best)
					continue;
				best = abs; //new parameters
				Orie = upci(Arms[tail].Beta - ang/2);
			}
		}
		while(--Thre > 3 && cone(Orie, *Dexo) > AQ);	
		//update local direction
//		if(integ && (*Dnxo & FF)) 
//		if(*Dnxo & FF) 
      {
         Orie = reci(Orie);
      }
//		else
		{
//			if(simu(Orie, *Dexo)) Orie = reci(*Dexo);
//			else Orie = *Dexo;
		}
		//arms turn to base orienation
		int i;
		for(i = 0; i < Narm; i++)
		{
			Metr[i] = ABS(turn( Arms[i].Beta, Orie));
		}
		//sort a metric
		bsort(Arms, Metr, less, Narm);
		//turn clocwize upto direction
		for(i = 0; i < Narm; i++)
		{
			Metr[i] = cloc(Arms[i].Beta, Arms[0].Beta);
		}
		//sort a metric
		bsort(Arms, Metr, less, Narm);
		//bifurcation input
		*Arms[1].Join = BL; *Arms[2].Join = BR;
		Orie = reci(Orie)/2;
	}
	//set current parameters
	Sign[Nmin].Type = *Srco;
	Sign[Nmin].Movx = Srcx;
	Sign[Nmin].Movy = Srcy;
	Sign[Nmin].Beta = Orie;
	Sign[Nmin].Lace = *Dhpo; 
	Sign[Nmin].Prob = *Dfno;  //if dubious
	Sign[Nmin].Prob|= *Dsto == 4 ? C8 : 0;
	++Nmin;
}
//-------------------------------------
//		 Virtual upper functions
//-------------------------------------
int	CWork::MiGoal( void )
{
	//collect working area
	if ((*Deio & CZ) == 0)
	{
		Pran += *Dhpo*16;
		Team +=		  16;
		Qran += *Dfno*16;
		return (*Dsto);
	}
	else	//empty region
	{
		Pran += *Dhpo*01;
		Team +=		  01;
		Qran += *Dfno*01;
		return 0;
	}

	//minutiae area ?
	//return *Dsto == 2 || 
	//		 *Dsto == 4 ||
	//		 *Dsto == 8;
}
/**************************************
			Mark doubtful points
**************************************/
void CWork::Doubts( void )
{
	//look over all minutiaes
	for(int i = 0; i < Nmin; i++)
	{
		//restores the original harmon
		int hm = (Sign[i].Lace + HP*(quick? HL_Q : HL))/HP+ 1 ;
		int thre_1 = 3*EVK(hm);

		//check proximity of minutiaes
		for (int j = 0; j < Nmin; j++)
		{
			if(i == j) continue;//skip it			

			//measure antiphase of vectors
			int an = simu(Sign[i].Beta << 1, Sign[j].Beta << 1);

			if(an)	continue;//a phase

			//measure square of a distance
			int sq = EVK(Sign[i].Movx - Sign[j].Movx, Sign[i].Movy - Sign[j].Movy );

			//if they not too far
			if(sq < thre_1)//3*EVK(hm))
			{
				Sign[i].Prob |= C8;	//mark
				Sign[j].Prob |= C8;	break;
			}
		}

		int thre_2 = 5*EVK(hm);
		//get proximity focus-minutiae 
		for (int k = 0; k < Nind; k++)
		{
			//skip other loop,delta,whorl
			if((Indi[k].Type & FF) == 0)
				continue;

			//measure square of distance
			int sq = EVK(Sign[i].Movx - Indi[k].Movx,
						 Sign[i].Movy - Indi[k].Movy );

			//if they not too far
			if (sq < thre_2)//5*EVK( hm ))
			{
				Sign[i].Prob |= C7;	break;
			}
		}
	}
}



/**************************************
			Extract minutiaes
**************************************/
void Codex::Minuti (int reih)
{
	//if refined image wasn't build
	if(GetKey(GOAL_M, Clevel) == -1)
	{		
		Skelet(SkeleT);//previous works
	}
	//tune in minuti queue
	OldLay(Tops = MINuti);
	Eche = Clevel;
	Nmin = 0/* */;

	//quantity of minutiae
	Imax = permit( this );

	//reset square counter
	Basket();
	//no quality & density
	Rreset();
	//read image minutiaes
	Docvie = (tvii)&CWork::MiTune;
   if (m_ISO_compatibe)
	   Docisi = (tv_v)&CWork::MiReadIso;
   else
	   Docisi = (tv_v)&CWork::MiRead;
	Docupi = (ti_v)&CWork::MiGoal;
	Scenew(  0,Eche,H0  );


	//mark doubtful points
	Doubts();
	//store finger density
	Densit =  DIP(Pran, Team);
	//store finger quality
	Qualit =  QVS(Qran, Team);

#ifdef SAVE_LAYERS
   saveLayer("minuti_GOAL_M.dat", GOAL_M, 1);
   saveLayer("minuti_DENS_M.dat", DENS_M, 1);
   saveLayer("minuti_FCLASS.dat", FCLASS, 1);
   saveLayer("minuti_FLOW_E.dat", FLOW_E, 1);
   saveLayer("minuti_DENSIT.dat", DENSIT, 1);
   saveLayer("minuti_CCLASS.dat", CCLASS, 1);
   saveLayer("minuti_LIST_M.dat", LIST_M, 1);
#endif

	//destroy a local link
	destroyminuti( this );
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
