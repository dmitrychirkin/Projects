/**************************************
				Cohere.cpp
	 Define coherent probability.

			Author Gudkov V.U.
***************************************/

//	Header files
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local enumerated type
//-------------------------------------
enum
{
	_TEMP_ = TEMP_T
};

//-------------------------------------
//	Local tune constants
//-------------------------------------
static const
int	Clevel	= H3;					//level


			
/**************************************
			Tune communications
**************************************/
void CWork::CoTune( int dsth,int srch )
{
	Srco = GetLay(	PROB_L,srch );			//local
	Shpo = GetLay(	_TEMP_,srch );			//temporary
	Snxo = GetLay( PROB_M,srch );			//refined probability
}

//-------------------------------------
//	Destroy comunications 
//-------------------------------------
template <class T>
static void destroycohere( T *p )
{
	p->DelLay( _TEMP_,p->Eche );
}

/**************************************
		 Virtual functions
**************************************/

//	Find inner minimum
void	CWork::CoMini( void )
{
	*Shpo = FiList( Srco,1 );
}

//	Find outward minimum
void	CWork::CoMino( void )
{
	*Shpo = 0; //suppose low
}

//	Find inner maximum
void	CWork::CoMaxi( void )
{
	*Snxo = FiList( Shpo,7 );

	//impulses poligon
	if (*Srco > *Snxo)
		++Rank[*Srco - *Snxo];
}

//	Find outward maximum
void	CWork::CoMaxo( void )
{
	*Snxo = FiMirr( Shpo );
}

//	Set refined probability
void	CWork::CoRefi( void )
{
   if(*Srco - *Snxo < Hypo)
	   *Snxo = *Srco;
}

/**************************************
		Assembly <Cohere> function
**************************************/
void	Codex::Cohere( int reih )
{

	//if flower wasn't built
	if (GetKey( FLOW_V,Clevel ) == -1)
	{
_DBG_INFO( "CONTROL POINT STREAMING\n" );
		//previous works
		Stream( StreaM );
	}
_DBG_INFO( "CONTROL POINT COHERE OLDLAY\n" );
	//tune in cohere queue
	OldLay( Tops=COHere );
	WiRect( Eche=Clevel,	1);
/*
   if (quick)
   {
   	Srco = GetLay(	PROB_L, H3);			//local
	   Snxo = GetLay( PROB_M, H3);			//refined probability
      memmove(Snxo, Srco, Size[H3]);
      return;
   }
*/
   //spread local minimum
   Docvie = (tvii)&CWork::CoTune;
   Docisi = (tv_v)&CWork::CoMini;
   Dociso = (tv_v)&CWork::CoMino;
   Scener	(Eche)		;

   RanIni();  //preparing

   //spread local maximum
   Docvie = (tvii)&CWork::CoTune;
   Docisi = (tv_v)&CWork::CoMaxi;
   Dociso = (tv_v)&CWork::CoMaxo;
   Scener	(Eche)		;

   //get the part of Rank
   Hypo = RanSha(4) +  1;

   //build flow curvature
   Docvie = (tvii)&CWork::CoTune;
   Docisi = (tv_v)&CWork::CoRefi;
   Scener	(Eche)		;

   //destroy a local link
   destroycohere( this );
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
