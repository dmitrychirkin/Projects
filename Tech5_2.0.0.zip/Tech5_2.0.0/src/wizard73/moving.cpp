/**************************************
				Moving.cpp
	 Generate base movement scemes.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"assert.h"
#include		"mathem73.h"
#include		"wizard73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

/**************************************
		Sceme to move step by step
			 along direction.
**************************************/

//	Check simple border of image
inline int	CBase::MvStop( int adir )
{
	//check echelon edge for steps
	return Movx <= 0				 ||
			 Movx >= MaxX[H_go]-1 || 
			 Movy <= 0				 ||
			 Movy >= MaxY[H_go]-1;
}
/*
//	Advance position along direction
inline void	CBase::MvStep( int adir )
{
	Movx += Move[H_go].IncX[adir];
	Movy += Move[H_go].IncY[adir];
	Movo += Move[H_go].IncO[adir];
	Joff += Move[H_go].IncO[adir];
	Hoff += Move[H_go].IncO[adir];
	Noff += Move[H_go].IncO[adir];
	Eoff += Move[H_go].IncO[adir];
}

//	Advance one position along
inline void	CBase::MvMove( int adir ) 
{
	//check the argument
	ASSERT( adir >= 0 );
	ASSERT( adir <= 7 );

	//advance the current position
	Movx += Move[H_go].IncX[adir];
	Movy += Move[H_go].IncY[adir];
	Movo += Move[H_go].IncO[adir];
}
*/
//	Advance two position along
inline void	CBase::MvSync( int adir ) 
{
	//advance the current position
	Movx += Move[H_go].IncX[adir];
	Movy += Move[H_go].IncY[adir];
	Movo += Move[H_go].IncO[adir];
	Locx += Move[H_go].IncX[adir];
	Locy += Move[H_go].IncY[adir];
	Loco += Move[H_go].IncO[adir];
}

/**************************************
		Chose the next position
**************************************/

//	Choose white point along direction
int	CBase::Chosew( int adir )
{
	//check echelon edge - exit
	if (Movx <= 0				 ||
		 Movx >= MaxX[H_go]-1 || 
		 Movy <= 0				 ||
		 Movy >= MaxY[H_go]-1 )		return 0;

	//read pixels to select
	int fwd = *(Movo+F_go);
	int rht = *(Movo+R_go);
	int lft = *(Movo+L_go);

	//select direction
	if (rht > fwd)
		if (rht > lft)//right
			MvMove((adir == 7) ? 0: adir+1 );
		else//left
			MvMove((adir == 0) ? 7: adir-1 );
	else 
		if (lft > fwd)//left
			MvMove((adir == 0) ? 7: adir-1 );
		else//forward
			MvMove( adir );			return 1;
}
/*
//	Choose inked point along direction
int	CBase::Chosei( int adir )
{
	//check echelon edge - exit
	if (Movx <= 0				 ||
		 Movx >= MaxX[H_go]-1 || 
		 Movy <= 0				 ||
		 Movy >= MaxY[H_go]-1 )		return 0;

	//read pixels to select
	int fwd = *(Movo+F_go);
	int rht = *(Movo+R_go);
	int lft = *(Movo+L_go);

	//select direction
	if (rht < fwd)
		if (rht < lft)//right
			MvMove((adir == 7) ? 0: adir+1 );
		else//left
			MvMove((adir == 0) ? 7: adir-1 );
	else 
		if (lft < fwd)//left
			MvMove((adir == 0) ? 7: adir-1 );
		else//forward
			MvMove( adir );			return 1;
}
*/
//	Choose white sinchronized point
int	CBase::Chsynw( int adir )
{
	//check echelon edge - exit
	if (Movx <= 0				 ||
		 Movx >= MaxX[H_go]-1 || 
		 Movy <= 0				 ||
		 Movy >= MaxY[H_go]-1 ||
		 Locx <= 0				 ||
		 Locx >= MaxX[H_go]-1 || 
		 Locy <= 0				 ||
		 Locy >= MaxY[H_go]-1 )		return 0;

	//read pixels to move
	int fwd = *(Movo+F_go);
	int rht = *(Movo+R_go);
	int lft = *(Movo+L_go);

	//select direction
	if (rht > fwd)
		if (rht > lft)//right
			MvSync((adir == 7) ? 0: adir+1 );
		else//left
			MvSync((adir == 0) ? 7: adir-1 );
	else 
		if (lft > fwd)//left
			MvSync((adir == 0) ? 7: adir-1 );
		else//forward
			MvSync( adir );			return 1;
}

//	Choose inked synchronized point
int	CBase::Chsyni( int adir )
{
	//check echelon edge - exit
	if (Movx <= 0				 ||
		 Movx >= MaxX[H_go]-1 || 
		 Movy <= 0				 ||
		 Movy >= MaxY[H_go]-1 ||
		 Locx <= 0				 ||
		 Locx >= MaxX[H_go]-1 || 
		 Locy <= 0				 ||
		 Locy >= MaxY[H_go]-1 )		return 0;

	//read pixels to move
	int fwd = *(Movo+F_go);
	int rht = *(Movo+R_go);
	int lft = *(Movo+L_go);

	//select direction
	if (rht < fwd)
		if (rht < lft)//right
			MvSync((adir == 7) ? 0: adir+1 );
		else//left
			MvSync((adir == 0) ? 7: adir-1 );
	else 
		if (lft < fwd)//left
			MvSync((adir == 0) ? 7: adir-1 );
		else//forward
			MvSync( adir );			return 1;
}

/**************************************
		Tuning function to move
**************************************/
void	CBase::MvTune( int adir,int hier )
{
	int xmax = MaxX[H_go = hier];
	int xinc = xmax +1; //+1
	int xdec = xmax -1; //-1

	//directions
	switch (adir)
	{
		case  0:	R_go =  xinc;
					F_go =	  1;
					L_go = -xdec; return;
		case  1:	R_go =  xmax;
					F_go =  xinc;
					L_go =	  1; return;
		case  2:	R_go =  xdec;
					F_go =  xmax; 
					L_go =  xinc; return;
		case  3:	R_go =    -1;
					F_go =  xdec; 
					L_go =  xmax; return;
		case  4:	R_go = -xinc;
					F_go =	 -1; 
					L_go =  xdec; return;
		case  5:	R_go = -xmax;
					F_go = -xinc; 
					L_go =	 -1; return;
		case  6:	R_go = -xdec;
					F_go = -xmax;
					L_go = -xinc; return;
		case  7:	R_go =	  1;
					F_go = -xdec;
					L_go = -xmax; return;
	}
}

/**************************************
	Various moving along direction
				Sense a lay!
**************************************/

//	Move in white lay
int	CBase::MvLayW( int dir,int len,int key,int hier )
{
	//tune direction..
	MvTune( dir,hier );
	//select lay in a scope
	for (int lay = 0; len; len--)
	{
		//advance
		if(!Chosew( dir ))  
			break;
		//controle ?
		if(key)
		{
			//check a lay
			if (*Movo > BA)
				lay++;
			else if (lay)
				break;
		}
	}

	//get we success ?
	return *Movo > BA;
}

//	Move in inked lay
int	CBase::MvLayI( int dir,int len,int key,int hier )
{
	//tune direction..
	MvTune( dir,hier );

	//select lay in a scope
	for (int lay = 0; len; len--)
	{
		//advance
		if(!Chosei( dir ))
			break;

		//controle ?
		if (key)

		{
			//check a lay
			if (*Movo < BA)
				lay++;
			else if (lay)
				break;
		}
	}

	//get we success ?
	return *Movo < BA;
}

//	Move & collect sum in white lay
int	CBase::MvSumW( int dir,int len,int key,int hier )
{
	//tune direction..
	MvTune( dir,hier );

	//select lay in a scope
	int sum = 0;
	for (int lay = 0; len; len--)
	{
		//advance
		if(!Chosew( dir ))
			break;

		//controle ?
		if (key)
		{
			//check a lay
			if (*Movo > BA)
				lay++;
			else if (lay)
				break;
		}

		//collect
		sum += (*Movo - BA); 
	}

	//positive result?
	return (sum > 0) ? sum+sum : 0;
}

//	Move & collect sum in inked lay
int	CBase::MvSumI( int dir,int len,int key,int hier )
{
	//tune direction..
	MvTune( dir,hier );

	//select lay in a scope
	int sum = 0;
	for (int lay = 0; len; len--)
	{
		//advance
		if(!Chosei( dir ))
			break;

		//controle ?
		if (key)
		{
			//check a lay
			if (*Movo < BA)
				lay++;
			else if (lay)
				break;
		}

		//collect
		sum -= (*Movo - BA); 
	}

	//positive result?
	return (sum > 0) ? sum+sum : 0;
}

//	Find white path & inked synchrosum
int	CBase::MvSynW( int dir,int len,int key,int hier )
{
	//tune direction..
	MvTune( dir,hier );

	//select lay in a scope
	int smw = 0, smi = 0;
	for (int lay = 0; len; len--)
	{
		//advance
		if(!Chsynw( dir ))
			break;

		//controle ?
		if (key)
		{
			//check a lay
			if (*Movo > BA)
				lay++;
			else if (lay)
				break;
		}

		//collects trustable
		smw += (*Movo - BA);
		smi -= (*Loco - BA);
	}

	//positive result?
	return (smw < smi) ? (smw > 0 ? smw + smw : 0)
							 : (smi > 0 ? smi + smi : 0);
}

//	Find inked path & white synchrosum
int	CBase::MvSynI( int dir,int len,int key,int hier )
{
	//tune direction..
	MvTune( dir,hier );

	//select lay in a scope
	int smi = 0,smw = 0;
	for(int lay = 0; len; len--)
	{
		//advance
		if(!Chsyni( dir ))
			break;
		//controle ?
		if(key)
		{
			//check a lay
			if (*Movo < BA)
				lay++;
			else if (lay)
				break;
		}

		//collects trustable
		smi -= (*Movo - BA);
		smw += (*Loco - BA);
	}

	//positive result?
	return (smw < smi) ? (smw > 0 ? smw + smw : 0)
							 : (smi > 0 ? smi + smi : 0);
}

/**************************************
				Generate 
		round movement sceme.
**************************************/

//	Immerse in 8-linked area
void	CBase::Rounde( int nlen )
{
	//run before immerce at the end
	if ( !nlen)	 (this->*Docend)();

	//deep well
	if (nlen--)
	{
		//try any possible direction
		for (int i = 0; i < 8; i+=1)
		{
			//check an edge
			if (!MvStop(i))
			{
				MvStep( D_go =i );			//forward
				if ((this->*Docimm)()) Rounde(nlen);
				MvStep(redi( i ));			//reverse
			}
		}
	}
}

//	Immerse in 4-linked area
void	CBase::Roundf( int nlen )
{
	//run before immerce at the end
	if ( !nlen)	 (this->*Docend)();

	//deep well
	if (nlen--)
	{
		//try any possible direction
		for (int i = 0; i < 8; i+=2)
		{
			//check an edge
			if (!MvStop(i))
			{
				MvStep( D_go =i );			//forward
				if ((this->*Docimm)()) Roundf(nlen); 
				MvStep(redi( i ));			//reverse
			}
		}
	}
}

//	Immerse in 8-linked area
void	CBase::Rounde( int nlen,int hier )
{
	H_go = hier; //hierarchy

	//success - assignment..
	if ( (this->*Docimm)( ))
	{
		Rounde( --nlen );
	}
}

//	Immerse in 4-linked area
void	CBase::Roundf( int nlen,int hier )
{
	H_go = hier; //hierarchy

	//success - assignment..
	if ( (this->*Docimm)( ))
	{
		Roundf( --nlen );
	}
}

//	Quick trajectory movement
void	CBase::Runner( int nlen,int hier )
{
	H_go = hier; //hierarchy

	//success - assignment..
	if ( (this->*Docimm)( ))
	{
		//limit branch
		while (nlen--)
		{
			MvStep( D_go=0 ); if ((this->*Docimm)()) continue; MvStep(4);
			MvStep( D_go=1 ); if ((this->*Docimm)()) continue; MvStep(5);
			MvStep( D_go=2 ); if ((this->*Docimm)()) continue; MvStep(6);
			MvStep( D_go=3 ); if ((this->*Docimm)()) continue; MvStep(7);
			MvStep( D_go=4 ); if ((this->*Docimm)()) continue; MvStep(0);
			MvStep( D_go=5 ); if ((this->*Docimm)()) continue; MvStep(1);
			MvStep( D_go=6 ); if ((this->*Docimm)()) continue; MvStep(2);
			MvStep( D_go=7 ); if ((this->*Docimm)()) continue; break;//no
		}
	}
}

//	Unwrap assigned trajectory
void	CBase::UnWrap( int nlen,int hier )
{
	H_go = hier; //hierarchy

	//verify direction assignment
	if ((D_go = Pack[Lpck]) < BF)
	{
		//limit branch
		while (nlen--)
		{
			//verify image edge
			if (!MvStop( D_go ))
			{
				MvStep( D_go );		//forward
				if (!(this->*Docimm)()) break;
											//reverse
			}
		}
	}
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
