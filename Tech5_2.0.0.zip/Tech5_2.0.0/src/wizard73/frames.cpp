/**************************************
				Frames.cpp
	Recognize frames for tenprint.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"assert.h"
#include		"inline73.h"
#include		"mathem73.h"
#include		"sorter73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local tune constants
//-------------------------------------
static const
int	Clevel =  H1;					//native level

/**************************************
			Tune communications
**************************************/
void	CWork::FrTune( int dsth,int srch )
{
	Srco = GetLay( TARGET,srch);
}

/**************************************
				Try memory
**************************************/

//	Get memory for processing
static void trymem( Codex *p,int size )
{
	//get memory for histogram
	if ((p->Hist = new int[size]) == 0)
		throw  p->What = DEFMEM;
	//get memory for correlation
	if ((p->Corr = new int[size]) == 0)
		throw	 p->What = DEFMEM;
	//get memory for deviation
	if ((p->Devi = new int[size]) == 0)
		throw	 p->What = DEFMEM;
	//get memory for swaping
	if ((p->Swap = new int[size]) == 0)
		throw	 p->What = DEFMEM;
}

//	Free memory of processing
static void outmem( Codex *p )
{
	//free histogram
	if (p->Hist != 0)
	{
		delete [] p->Hist; p->Hist = 0;
	}
	//free correlation
	if (p->Corr != 0)
	{
		delete [] p->Corr; p->Corr = 0;
	}
	//free deviation
	if (p->Devi != 0)
	{
		delete [] p->Devi; p->Devi = 0;
	}
	//free swaping
	if (p->Swap != 0)
	{
		delete [] p->Swap; p->Swap = 0;
	}
}

/**************************************
			Buffer preprocessing
**************************************/

//	Measure correlation quality
static int qualit( int *list,int fini )
{
	//sorting data
	isort( list,
			 less,
			 fini );

	//measure case
	int ival, i;
	for (ival = 0,i = 0; i <= fini; i++)
	{
		ival += list[i]*(1<<i);
	}

	//some quality
	return	ival;
}

//	Normalize histogram
static void normal( Codex *p )
{
	//smooth it
	p->AnySmo( 1,p->Hist,p->Hend );

	//normalize
	p->AnyNor(	 
	p->AnySup(   p->Hist,p->Hend ),
					 p->Hist,p->Hend );
}

//	Correct fingerprint width
static int	fwidth( Codex *p )
{
	//look over the list
	for (int r = 1,l; r < _TIP_; r++)
	{
		//sets previous finger
		if (r==5) r++; l= r-1;

		//finger absent - skip
		if (!p->Rect[r].Rect )
			continue;
		if (!p->Rect[l].Rect )
			continue;
		//verifies left -right
		if ( p->Rect[r].L_re - p->Rect[l].R_re < 2)
		{
			  p->Rect[r].L_re	= 
			  p->Rect[l].R_re	=(p->Rect[r].L_re + 
									  p->Rect[l].R_re)/ 2;
			  p->Rect[r].L_re++;
			  p->Rect[l].R_re--;
		}
	}

	//look over the list
	int i = 0, sm, n;
	for (i = 0,sm = 0,n = 0; i < _TIP_; i++)
	{
		//finger absent - skip
		if (!p->Rect[i].Rect ) 
				continue;
		if (i == 0  || i == 5)
				continue;

		//set window parameter
		sm +=	p->Rect[i].R_re;
		sm -=	p->Rect[i].L_re;
		n++;
	}
					//final width
	return		n ? sm/n : 0;
}

//	Restore rectangles
static void	restor( Codex *p )
{
	//look over list of the fingers
	for (int i = 0; i < _TIP_; i++)
	{
		//if a finger exist
		if(p->Rect[i].Rect)
		{
			p->Rect[i].L_re *= 2;
			p->Rect[i].T_re *= 2;
			p->Rect[i].R_re *= 2;
			p->Rect[i].B_re *= 2;

			//verify size of rect
			while ((p->Rect[i].R_re-p->Rect[i].L_re)*DEFDPI/LIMDPI > _MAL_X)
			{
				--p->Rect[i].R_re;
				++p->Rect[i].L_re;
			}
			//verify size of rect
			while ((p->Rect[i].B_re-p->Rect[i].T_re)*DEFDPI/LIMDPI > _MAL_Y)
			{
				--p->Rect[i].B_re;
				++p->Rect[i].T_re;
			}
		}
	}
}

/**************************************
		Scanning virtual functions
**************************************/

//	Build histogram along y
void	CWork::Framey( void )
{
	//is area in rectangle ?
	if (InRect( Srcx,Srcy ))
	{
		//build histogram along x
		Hist[Srcy-T_re] += *Srco;
	}
}

//	Build histogram along x
void	CWork::Framex( void )
{
	//is area in rectangle ?
	if (InRect( Srcx,Srcy ))
	{
		//build histogram along y
		Hist[Srcx-L_re] += *Srco;
	}
}

/**************************************
			Find maximum
**************************************/

//	Try to catch necessary heights
void	CWork::Fcatch( int hill,int wing,int tiny )
{
	int	trap [9],
			best = 0;

	//autotuning scanner
	for (int qual; wing >= tiny; wing -= 2)
	{
		//builds a correlation
		ResDst( Corr,Hend+1 );
		CorCos( wing,Hend,0 );

		//measures float value
		Zero = Rfloat( Corr,
							Hend,
				 AnyPow( Corr,
							Hend )/
							Hend,
							hill );

		//hills of correlation
		int npos, n;
		for (npos = 0,n = 0; npos <= Hend;)
		{
			npos = Rraise( Corr,Hend,Zero,npos );

			//hill found - read position
			if (n < hill && npos < Hend)	
			{
				trap[n] = Corr[npos];n++;
			}

			npos = Rlower( Corr,Hend,Zero,npos );
		}

		//get best correlation
		if(best <= (qual = qualit( trap,n-1 )))
		{
			best  = qual;//store best
			StrCop( Swap,Corr,Hend );
		}
	}
			//set up best correlation
			StrCop( Corr,Swap,Hend );
}

//	Find height between hills
int	CWork::FrDoor( int inum,int hill )
{
	//look throw list of data
	for (int npos = 0; inum;)
	{
		npos = Rraise( Corr,Hend,Zero,npos );

		//if hill was found do position
		if (--inum == 0 && npos < Hend)
		{
			//get l-edge
			for (Llim = npos; Corr[Llim] > 
									Corr[npos]/4 && Llim >	  0; Llim--);
			//get r-edge
			for (Rlim = npos; Corr[Rlim] > 
									Corr[npos]/4 && Rlim < Hend; Rlim++);
			//the result
			return npos;
		}

		npos = Rlower( Corr,Hend,Zero,npos );
	}

	//nothing
	return 0;
}

//	Approach to the foot of wave
void	CWork::ComeUp( int look )
{
	//find out the best height
	for (int a = 0,i = 0,l = Llim; l >    0 && i < look; l--,i++)
	{
		if (a < Corr[l] && Devi[l] > +1)	
			 a = Corr[Llim = l];
	}
	//find out the best height
	for (int b = 0,j = 0,r = Rlim; r < Hend && j < look; r++,j++)
	{
		if (b < Corr[r] && Devi[r] < -1)	
			 b = Corr[Rlim = r];
	}
}

//	Find flexor line
void	CWork::FrFlex( int look )
{
	//find maximum of correlation
	int i, max;
	for (i = 0,max = 1; i < Hend; i++)
	{
		if (max < Corr[i])
			 max = Corr[i];
	}

	//set a start positions
	int npos = Rlim = Llim;

	//find flexor line position
	for (int prob = 0; npos < Hend; npos++)
	{
		//if large window
		if (npos-Llim > 4*look/3)
			break;
		//if small window
		if (npos-Llim < 2*look/3)
			 Rlim=npos;	 
		else
		{
			//measure a local position probability
			int reli =	4*(Corr[npos]+1)*look/max-
							4* ABS (look-(npos-Llim));

			//select the best
			if (reli >= prob)
			{
				prob = reli;
				Rlim = npos;
			}
		}
	}
}

/**************************************
		  Set frames on tenprint
**************************************/
int	Codex::Frames( int  )
{
	//statistic low for fingerprint 
	int	ord[] = { 105,91,95,95,90,
						 105,91,95,95,90 };

	//if target image absent build it
	if (GetKey( TARGET,Clevel ) == -1)
	{
		//previous works
		Target( TargeT );
	}             

	//local data
	int	rows,
			fing;

			//base echelon
			Eche = Clevel;

	//----------------------------------
	//	default reset all frames
	//----------------------------------
	for (fing = 0; fing < _TIP_; fing++)
		 Rect[fing].Rect =
		 Rect[fing].Hold = 0;

	//----------------------------------
	//	find two rows of fingerprints
	//----------------------------------
	Hend = MaxY[Eche] - 1;

	//get memory
	try
	{
		trymem( this,//full
				  Hend + 1 );
	}

	//exceptions
	catch( int nerr )
	{
		outmem( this ); 
		return  nerr  ;
	}

	//set working boundary
	L_re = 0,			//OK
	R_re = MaxX[ Eche ]-1,
	T_re = 0,			//OK
	B_re = MaxY[ Eche ]-1;

	//preparing histograms
	ResDst( Hist,Hend+1 );

	//histogram along y...
	Docvie = (tvii)&CWork::FrTune;
	Docisi = (tv_v)&CWork::Framey;
	Scenew( 2,Eche,Eche );

	//normalize histograms
	normal( this );	//ok

	//get best correlation
	Fcatch( 2,0x50,0x40 );

	//set previous borders
	for (rows = 0; rows < _ROW_; rows++)
	{
		//request row exist-set
		if (FrDoor( rows+1,_ROW_ ))
		{
			//corrects top boder
			Llim = MAX(	Llim - 15 );

			//stores a rectangle
			for (fing = 0; fing < 5; fing++)
			{
				Rect[5*rows+fing].T_re = Llim;
				Rect[5*rows+fing].B_re = Rlim;
				Rect[5*rows+fing].Rect = 1;//!
			}
		}
	}

	//free a memory
	outmem( this );

	//----------------------------------
	//	find fingerprints in every row
	//----------------------------------
	Hend = MaxX[Eche] - 1;

	//get memory
	try
	{
		trymem( this,//full
				  Hend + 1 );
	}

	//exceptions
	catch( ... )
	{
		outmem( this ); 
		return  What  ;
	}

	//recognize fingerprints in two rows
	for (rows = 0; rows < _ROW_; rows++)
	{
		//request row absent ?
		if(!Rect[rows*5].Rect)  continue;

		//set top&bottom edges
		T_re = 
			 Rect[rows*5].T_re;
		B_re = 
			 Rect[rows*5].B_re;

		//preparing histograms
		ResDst( Hist,Hend+1 );

		//histogram along y...
		Docvie = (tvii)&CWork::FrTune;
		Docisi = (tv_v)&CWork::Framex;
		Scenew( 2,Eche,Eche );

		//normalize histograms
		normal( this );	//ok

		//get best correlation
		Fcatch( 5,0x3c,0x32 );

		//recognize fingerprint into row
		for (fing = 0; fing < 5; fing++)
		{
			//fingerprint exist-set
			if (FrDoor( fing+1,5 ))
			{
				Rect[rows*5+fing].L_re = Llim;
				Rect[rows*5+fing].R_re = Rlim;
				Rect[rows*5+fing].Rect = 1;//!
			}
			else
				Rect[rows*5+fing].Rect = 0;//!
		}

		//measures correlation
		ResDst( Corr,Hend+1 );
		CorCos( 7,	 Hend,1 );
		AnyDev( 9,Devi,Hist,
							Hend );

		//find left&right edge of finger
		for (fing = 0; fing < 5; fing++)
		{
			//request finger absent-go out
			if ( !Rect[rows*5+fing].Rect ) 
					continue;

			//comes up to the finger edges
			Llim = Rect[rows*5+fing].L_re;
			Rlim = Rect[rows*5+fing].R_re;
			ComeUp( 40 );
			Rect[rows*5+fing].L_re = Llim;
			Rect[rows*5+fing].R_re = Rlim;
		}
	}//fingerprint in every row

	//free a memory
	outmem( this );

	//forecast flexure deep
	Bask = fwidth( this );

	//----------------------------------
	//	top & bottom fingerprint boundary
	//----------------------------------
	for (fing = 0; fing < _TIP_; fing++)
	{
		//if finger absent-skip
		if ( !Rect[fing].Rect ) 
				continue;

		//set window parapeters
		L_re = Rect[fing].L_re;
		R_re = Rect[fing].R_re;
		T_re = Rect[fing].T_re;
		B_re = Rect[fing].B_re;

		//set top & bottom working boundary
		T_re = MAX(			  0,T_re-Bask/3 );
		B_re = MIN( MaxY[0]-1,B_re+Bask/3 );

		//set buffer parameter
		Hend = B_re - T_re +1;

		//get memory
		try
		{
			trymem( this,//full
					  Hend + 1 );
		}

		//exceptions
		catch( ... )
		{
			outmem( this ); 
			return  What  ;
		}

		//preparing histograms
		ResDst( Hist,Hend+1 );

		//histogram along y...
		Docvie = (tvii)&CWork::FrTune;
		Docisi = (tv_v)&CWork::Framey;
		Scenew( 2,Eche,Eche );

		//normalize histograms
		normal( this );	//ok

		//get best correlation
		Fcatch( 1,0x4a,0x3c );

		//finger must be here!
		if (FrDoor( 1,1 ))
		{
			//measures correlation
			ResDst( Corr,Hend+1 );
			CorCos( 7,	 Hend,1 );
			AnyDev( 9,Devi,Hist,
								Hend );
			ComeUp( 40 );

			//find prognosis flexure position
			Thre = PER( ord[fing],
								 Bask);

			ResDst( Corr,Hend+1 );
			CorCos( 6,	 Hend,1 );

			//measures flexure line
			FrFlex( Thre );
			Rect[fing].T_re = Llim+
									T_re;
			Rect[fing].B_re =	Rlim+
									T_re;
		}
		else
			Rect[fing].Rect = 0;//

		//free a memory
		outmem( this );

	}//end top boundary & flexure line

	//sets original
	restor( this );

	//success deal!
	return  SUCCES;
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
