/**************************************
				Histog.cpp
	Various histogram processing.

			Author Gudkov V.U.
**************************************/

//	Header files
#include		"assert.h"
#include		"inline73.h"
#include		"mathem73.h"
#include		"wizard73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

/**************************************
			Local special low
**************************************/

//	Store gauss value
inline void	_gauss( int *buf,int i,int val )
{
	buf[SRANK-i-1] = BM -(buf[i] = LIM( val ));
}

//	Store argument value
inline void	_argum( int *buf,int i,int val )
{
	buf[AR-i] = -(buf[AR+i] = LIR( val ));
}

/**************************************
			Local procesing
**************************************/

//	Move right untill the end
inline int moveright( int i,int &cnt,int size,int *tab,int fini )
{
	//form a sum
	int sm = 0;
	for (int j = 1; j <= size; j++,cnt++)
	{
		sm += tab[i+j < fini ? i+j : fini];
	}

	//the result
	return	sm;
}

//	Move left untill the end
inline int moveleft( int i,int &cnt,int size,int *tab,int fini ) 
{
	//form a sum
	int sm = 0;
	for (int j = 1; j <= size; j++,cnt++)
	{
		sm += tab[i-j > fini ? i-j : fini];
	}

	//the result
	return	sm;
}

/**************************************
			Initialize histogram
**************************************/

//	Clear 'Rank' buffer
void	CRank::RanIni( int vval ) 
{
	for (int i = 0; i < SRANK; Rank[i++] = vval);
}

//	Clear 'Lord' buffer
void	CRank::LorIni( int vval ) 
{
	for (int i = 0; i < SRANK; Lord[i++] = vval);
}

//	Clear 'Corn' buffer
void	CRank::CorIni( int vval ) 
{
	for (int i = 0; i < SCORN; Corn[i++] = vval);
}

/**************************************
		Calculate original poligon
**************************************/

//	Build Rank poligon
void	CRank::RanMod( int *low ) 
{
	for (int i = 0; i <= SRANK-1; i++) 
	{
		Rank[i] = LIM( lagran( low,i ),0,BM );
	}
}

//	Build Lord poligon
void	CRank::LorMod( int *low ) 
{
	for (int i = 0; i <= SRANK-1; i++)
	{
		Lord[i] = LIM( lagran( low,i ),0,BM );
	}
}

//	Build Corn poligon
void	CRank::CorMod( int *low ) 
{
	for (int i = 0; i <= SCORN-1; i++)
	{
		Corn[i] = LIM( lagran( low,i ),0,AH );
	}
}

//-------------------------------------
//	Calculate probability integrals
//-------------------------------------

//	Build poligon as gauss integral
void	CRank::RanGau( int *low ) 
{
	for (int i = 0; i <  SRANK/2; i++)
	{
		_gauss( Rank,i,lagran( low,i ));
	}
}

//	Build poligon as gauss integral
void	CRank::LorGau( int *low ) 
{
	for (int i = 0; i <  SRANK/2; i++)
	{
		_gauss( Lord,i,lagran( low,i ));
	}
}

//	Translate argument as special low
void	CRank::CorGau( int *low ) 
{
	for (int i = 0; i <= SCORN/2; i++)
	{
		_argum( Corn,i,lagran( low,i ));
	}
}

/**************************************
			Common processing
**************************************/

//	Recognize begin of histogram
void	CRank::RanBeg( int feel )
{
	//find the percent, precision up to 0.1
	feel = AnyPow( Rank,SRANK-1)*feel/1000;

	//find left border
	for (Llim = 0; Llim < SRANK-1;  Llim++)
	{
		if ((feel -= Rank[Llim]) <= 0) break;
	}
}

//	Recognize end of histogram
void	CRank::RanEnd( int feel )
{
	//find the percent, precision up to 0.1
	feel = AnyPow( Rank,SRANK-1)*feel/1000;

	//find left border
	for (Rlim = SRANK-1; Rlim > 0;  Rlim--)
	{
		if ((feel -= Rank[Rlim]) <= 0) break;
	}
}

//	Measure histogram impuls
int	CRank::RanImp( int feel )
{
	return feel*AnySup( Rank,SRANK-1 )/
					AnyPow( Rank,SRANK-1 );
}

//	Get histogram base weight
int	CRank::AnyPow( int *tab,int fini )
{
	//collection
	for	(Rpow =  0; fini >= 0; fini--)
			 Rpow+= tab[fini];

	//the result
	return Rpow;
}

//	Measure histogram suprum
int	CRank::AnySup( int *tab,int fini )
{
	//find suprum
	for	(Rsup = -1; fini >= 0; fini--)
		if (Rsup < tab[fini] || Rsup < 0)
			 Rsup = tab[fini];

	//the result
	return Rsup;
}

//	Measure histogram infrum
int	CRank::AnyInf( int *tab,int fini )
{
	//find infrum
	for	(Rinf = -1; fini >= 0; fini--)
		if (Rinf > tab[fini] || Rinf < 0)
			 Rinf = tab[fini];

	//the result
	return Rinf;
}

//	Measure upper histogram part
int	CRank::AnySha( int *tab,int fini,int feel )
{
	//get percent of a histogram
	feel = PER( AnyPow( tab,fini ),feel );

	//find upper part of histogram
	int i = fini;
	for (int sm = 0; i > 0; i--)
		if ((sm += tab[i]) >= feel) break;
			return i; //success
}

//-------------------------------------
//	Localize common functions
//-------------------------------------

//	Calculate upper part of Rank
int	CRank::RanSha( int feel )
{
	return AnySha( Rank,SRANK-1,feel );
}

//	Calculate upper part of Lord
int	CRank::LorSha( int feel )
{
	return AnySha( Lord,SRANK-1,feel );
}

/**************************************
	 Build special poligons for any
				link of scheme
**************************************/

//	Build poligon as logarithm
void	CRank::AnyLog( int *dst,int high,int fini )
{
	//full range
	for (int i = 0; i <= fini; i++)
	{
		dst[i] = logm( i,fini )*high/2048;
	}
}

//	Generate Rank as logarithm
void	CRank::RanLog( int high )
{
	AnyLog( Rank,high,SRANK-1 );
}

//	Generate Lord as logarithm
void	CRank::LorLog( int high )
{
	AnyLog( Lord,high,SRANK-1 );
}

//	Build gauss sqrt(sqrt(x))
void	CRank::GauSqr( int high )
{
	//full range, high == 1..4
	for (int i = 0; i < SRANK/2; i++)
	{
		_gauss( Rank,BA-i,BA-sqri( sqri( high*i*i*i )));
	}
}

//	Build default histogram
void	CRank::RanOrg( void )
{
	for (int i = 0; i < SRANK; Rank[i] = i, i++);
}

//	Resize histogram spectrum
void	CRank::RanRes( void ) 
{
	//resize rank
	for (int i = 0,range = Rlim-Llim; i < SRANK; i++)
	{
		if (i <= Llim)
			Rank[i] = 00;
		else
		if (i >= Rlim)
			Rank[i] = BM;
		else
			Rank[i] = BM*(i-Llim)/range;
	}
}

//	Translate histogram to uniform 
void	CRank::RanUni( void )
{
	//measure histogram weight
	int we = AnyPow( Rank,SRANK-1);

	//rebuild histogram
	for (int i = 0,sm = 0; i < SRANK; i++)
	{
		//add real weigh
		sm += Rank[i];

		//oversign the histogram
		Rank[i] = DIP( BM*sm,we );
	}
}

/**************************************
			Smooth any table
**************************************/

//	Normalize any buffer
void	CRank::AnyNor( int isup,int *tab,int fini )
{
	//look over the buffer
	for (int i = 0; i <= fini; i++)
	{
		tab[i] = (tab[i] << 8)/isup;
	}
}

//	Build expectaion
void	CRank::AnyMat( int size,int *dst,int *src,int fini )
{
	//expecation 
	for (int i = 0,n; i <= fini; i++)
	{ 
		//gets centre
		dst[i] = 
		src[i],n = 1;

		//left..right
		dst[i] += moveright( i,n,size,src,fini );
		dst[i] += moveleft ( i,n,size,src,   0 );

		//set a value
		if (n)	dst[i] = DIP( dst[i],n );
	}
}

//	Build deviation
void	CRank::AnyDev( int size,int *dst,int *src,int fini )
{
	//processes the source dot to dot
	for (int i = 0,n; i <= fini; i++)
	{ 
		//preparation
		dst[i] =n =0;

		//left..right
		dst[i] += moveright( i,n,size,src,fini );
		dst[i] -= moveleft ( i,n,size,src,   0 );

		//set a value
		if (n)	dst[i] = DIP( dst[i],n );
	}
}

//	Smooth any buffer
void	CRank::AnySmo( int size,int *tab,int fini )
{
	//the work buffer
	int	buf[SRANK],
		  *mem;

	//if a small table
	if (fini < SRANK)
	{
		//build expectation and copy
		AnyMat( size,buf,tab,fini );
		StrCop(		 tab,buf,fini );
	}
	else//use heap
	if ( mem = new int[ fini+1 ] )
	{
		//build expectation and copy
		AnyMat( size,mem,tab,fini );
		StrCop(		 tab,mem,fini );
		delete	[] mem;//and free heap
	}
}

//	Smooth Rank
void	CRank::RanSmo( int size ) 
{
	AnySmo( size,Rank,SRANK-1 );
}

//	Smooth Corner
void	CRank::CorSmo( int size ) 
{
	AnySmo( size,Corn,SCORN-1 );
}

//	Smooth Lord
void	CRank::LorSmo( int size ) 
{
	AnySmo( size,Lord,SRANK-1 );
}

/**************************************
		Preprocessing the table
**************************************/

//	Raise to the height
int	CRank::Rraise( int *tab,int fini,int zero,int posi )
{
	//find the height
	for (int ival= zero; posi <= fini; posi++)
	{
		//skips if under water
		if (ival <= tab[posi])
			 ival  = tab[posi];
		else	
		if (ival >  zero)
			break;
	}
	//a position
	return posi;
}

//	Find the foot of the height
int	CRank::Rlower( int *tab,int fini,int zero,int posi )
{
	//find the foot
	for (int ival= zero; posi <= fini; posi++)
	{
		//skips if under water
		if (ival >= tab[posi])
			 ival  = tab[posi];
		else	
		if (ival <  zero)
			break;
	}
	//a position
	return posi;
}

//	Find floating threshold
int	CRank::Rfloat( int *tab,int fini,int zero,int hill )
{
	//try to carry out test
	for (int n = 10; n; n--)
	{
		//define height quantity
		int quan = 0;
		for (int i = 0; i <= fini;)
		{
			i = Rraise( tab,fini,zero,i );
			if (i < fini)	quan++; //found
			i = Rlower( tab,fini,zero,i );
		}

		//if find necessary data
		if (quan >= hill) break;

		//modify float-threshold
		zero	=	PER( zero,90 );
	}

	//final float
	return  zero;
}

/**************************************
	Correlation based on cosinus
**************************************/

//	The correlation based on cosin function
void	CRank::CorCos( int wing,int fini,int anti,int mami,int *dst,int *src )
{
	//carry out work in every point
	for (int i = 0; i <= fini; i++)
	{
		//local data
		int sum = 0,
			 cnt = 0;

		//right & left wings symmetric correlation
		for (int j = 0; j <= wing/2; j++,cnt += 4)
		{
			int ang = AH*j/wing; //angle
				
			//collects cosin correlation
			sum += cosm(src[ MAX( i-j,
											 0 )],	ang );
			sum += cosm(src[ MAX( i+j-wing,
											 0 )],AH-ang );
			sum += cosm(src[ MIN( i+j,
										 fini )],	ang );
			sum += cosm(src[ MIN( i-j+wing,
										 fini )],AH-ang );
		}

		//invert?		
		if (anti)
			sum = MAX( -8*sum/cnt );
		else
			sum = MAX( +8*sum/cnt );

		//save a maximum
		if (dst[i] < sum &&  mami)
			 dst[i] = sum;
		//save a minimum
		if (dst[i] > sum && !mami)
			 dst[i] = sum;
	}
}

//	Default correlation in the wing based on cos function
void	CRank::CorCos( int wing,int fini,int anti,int mami )
{
	CorCos( wing,fini,anti,mami,Corr,Hist );
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
