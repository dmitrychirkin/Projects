/**************************************
				Ifocus.cpp
	  Recognize the image focuses.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"assert.h"
#include		"mathem73.h"
#include		"moulds73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local definitions
//-------------------------------------
enum
{
	_TWIS_ = TEMP_T,
	_LOOK_
};

//-------------------------------------
//	Local tune constants
//-------------------------------------
static const
int	Clevel =  H3,					//level
	Cwhirl =   2,					//developed area
	Cloops = 120,					//degrees between loops
	Cabove =  62,					//water-level
	Clifts =   2,					//iterations to lift
	Cscope =   4;					//tether scope

/**************************************
		Tune to find out focuses
**************************************/

//	Tune to find out focuses
void CWork::IfTune(int dsth, int scrh)
{
	Srco = GetLay(FLOW_V, scrh);	//victory flow
	Shpo = GetLay(PROB_M, scrh);	//refined probability
	Sexo = GetLay(ARCH_D, scrh);	//arch direction
	Swoo = GetLay(_TWIS_, scrh);	//twist
	Smoo = GetLay(_LOOK_, scrh);	//latent
	Dsto = GetLay(MATH_I, dsth);	//indexes
   Dhpo = GetLay(FCLASS, dsth);	//fclass
   Dnxo = GetLay(FLOW_F, dsth);	//alpha
}

//	Tune in hierarchy projection
void	CWork::IfDeep( int dsth,int scrh )
{
	Srco = GetLay(	MATH_I,scrh );			//indexes
   Shpo = GetLay(	FCLASS,scrh );			//fclass
   Snxo = GetLay(	FLOW_F,scrh );			//alpha
	Sexo = GetLay(	ARCH_D,scrh );			//arch direction
	Dsto = GetLay(	MATH_I,dsth );			//indexes
	Dhpo = GetLay(	FCLASS,dsth );			//fclass
   Dnxo = GetLay(	FLOW_F,dsth );			//alpha
	Dexo = GetLay(	ARCH_D,dsth );			//arch direction
}

//-------------------------------------
//	Destroy communications 
//-------------------------------------
template <class T>
static void destroyifocus( T *p )
{
	p->DelLay( _TWIS_,p->Eche );
	p->DelLay( _LOOK_,p->Eche );
}

/**************************************
		Gap focus functions
**************************************/
static inline int ifturn( byte *p )
{
	return *p == FD || *p == FL || *p == FW;
}

/**************************************
		Virtual inner functions
**************************************/

//	Collect indignations
void	CWork::IfWide( int flow,int step )
{
	//have found focus?
	if(ifturn( Movo ))
	{
		//stores data
		Area = *Movo; Orie = *Joff; Case = *Eoff;
		Bask++;//calc
	}
}


//	Groop native focuses
int	CWork::IfImme(void)
{
	//tune in parameter
	int lims = PER(Qual, Cabove);
	int type = *Eoff&FF;

	//verify the latent
	if(*Noff ==  Foot)
		goto skip;
	*Noff  =  Foot;

	//restrict horizont
	if(*Joff < lims)
		goto skip;
	//is without focus?
	if(type == FN)
		goto goon;
	//some another area
	if(type != *Dhpo)
		goto skip;
	//if native focuses
	if(type != FL || coor(*Dnxo*2, *Movo*2) < Cloops)
	{
		//select maximum
		if(Thre<= *Joff)
		{
			Thre = *Joff; Loco =  Eoff;	Useo =  Joff;
		}

goon:	if(Qual < *Joff)
			Qual = *Joff;
		return 1;//goon;
	}

skip:	return 0;//skip;
}

//	Get presize orientation
int	CWork::IfRays( int step )
{
	//check if focus
	if (*Joff != FN)
	{
		//stops focus
		if (step > 2)
			return  1;
		else  //go on
			return  0;
	}

	//a real angle deflection
	Bask += Corn[scis( *Movo,
							 *Dnxo*2 )+AR];
	//gather!
	Team++  ;

	//go on..
	return 0;
}

/**************************************
		Virtual kernal functions
**************************************/

//	Recognize the focus type
void	CWork::IfPrep( void )
{
	//clear lay
	*Dsto = BM;
	*Dnxo =
	*Dhpo = FN;
	*Smoo = 00;
	*Swoo = 04;
}

//	Recognize the focus type
void CWork::IfIndi_2(void)
{
	//recognize any
	Joff = Shpo; //PROB_M
	DoMove(&Srco); DoKeep(&Useo); //FLOW_V
	//Treset(Re_v); Treset( Im_v );
	Re_v[0] = Re_v[4] = 0; Im_v[0] = Im_v[4] = 0;
	Spiral(Eche, Clas);
	if(Re_v[0] || Im_v[0])
		Flow[0] = atan(Re_v[0], Im_v[0])/2;
	else
		Flow[0] = *Useo;
	if(Re_v[4] || Im_v[4])
		Flow[4] = atan(Re_v[4], Im_v[4])/2;
	else
		Flow[4] = *Useo;
	Tcurve(Flow, Sexo, Useo); //save ARCH_D
}
void CWork::IfIndi(void)
{
	//recognize any
	Joff = Shpo; //PROB_M
	DoMove(&Srco); DoKeep(&Useo); //FLOW_V
	Treset(Re_v); Treset( Im_v );
	Spiral(Eche, Clas);
    Targum(Re_v, Im_v,  Flow,  Useo); //Get Flow
	Tcurve(Flow, Sexo, Useo); //save ARCH_D
	//verify border
	if(Razors())
		 return;
	//indignations!
	Trecog(Dhpo, Flow, quick); //save FCLASS
	//if focus exist
	if(ifturn(Dhpo))
	{
		Toscil(Flow, Useo, Dhpo, Dnxo); //save FLOW_F
	}
}

//Measure twist of curve
void CWork::IfTwis(void)
{
	//measure twist
	DoMove(&Sexo); DoKeep(&Useo); //ARCH_D
	Treset(Tw_v); //Treset(Quan);
	Area = 0;
	Spiral(Eche, Clas);

	//rotated twist
	int min_value = MIN(Min4(Tw_v[0], Tw_v[1], Tw_v[2], Tw_v[3]),
						Min4(Tw_v[4], Tw_v[5], Tw_v[6], Tw_v[7]));
	*Swoo += min_value/Area; //save _TWIS_
}

//	Lift up focuses to hills
void CWork::IfLift( void )
{
	//get focus type
	if (ifturn( Dhpo ))
	{
		//start horizon
		 Qual =	 Thre =  *Swoo;
		//wrap a latent
		if(++Foot==BM)
            Foot = 1;

		DoMove(&Smoo );	DoLink(&Noff );
		DoMove(&Swoo );	DoKeep(&Useo );	DoLink(&Joff );
		DoMove(&Dhpo );	DoKeep(&Loco );	DoLink(&Eoff );	DoMove(&Dnxo );
		Rounde(0xff, Eche);
		//old position?
		if(Loco == Dhpo)
			return;
		//stores focus
		//*Loco  = *Dhpo; //not needed
		//up new twist
		*Useo  = LIM( *Useo +(Proc = 1));
		//reset focuses
		*Dhpo = FN ;
	}
}
//	Enumerate indignations
void	CWork::IfEnum( void )
{
	//for indignation..
	if (ifturn( Dhpo ) && Hypo < _GEN_)
		*Dsto = Hypo++;
	else
		*Dsto = BM;//no
}

//	Spread indignations
void	CWork::IfWideV( void )
{
	//find indignations
	if(!ifturn( Dhpo ))
	{
		//gather region
		Basket(		 );
		DoMove(&Dsto );
		DoLink(&Eoff );
		DoMove(&Dnxo );
		DoLink(&Joff );
		DoMove(&Dhpo );
		Spiral( Eche );

		//is one focus?
		if (Bask != 1)
			return;

		//mark the area
		*Dsto = Case  ;
		*Dhpo = Area | FV;
		*Dnxo = Orie  ;
	}
}

//	Get presize ray orientation
void	CWork::IfRaysV( void )
{
	//clean up veil
	*Dhpo  &=  ~FV;

	//get focus type
	if (ifturn( Dhpo ))
	{
		//iteretive detail tether..
		for (int i = 0; i < Cscope; i++)
		{
			DoMove(&Dhpo );
			DoLink(&Joff );
			DoMove(&Srco );
			Basket(		 );
			Bresen(*Dnxo*2,
					  Cscope,
					  Eche );

			//relaxs tether
			if(Team)Bask /=
					  Team+i;

			//calculates new tether
			*Dnxo = upci( *Dnxo*2 +
								Bask )>>1;
		}
	}
}

//	Carry out projection
void	CWork::IfDeepV_integ( void )
{
	*Srco = *Dsto;
   *Shpo = *Dhpo;
   *Snxo = *Dnxo;
	*Sexo = *Dexo;
}

void	CWork::IfDeepV( void )
{
	*Sexo = *Dexo;
}

/**************************************
		Assemble <Ifocus> function
**************************************/
void Codex::Ifocus(int reih)
{
	//lows to modify angle parameters..
	int ray[] = {4, 0,0, 10,10, 45,1, AR,0 };
	int ang[] = {4, 0,0, 20,13, 45,45, AR, 8};
	int i;

	//if model flower wasn't prooved
	if(GetKey(CCLASS, Clevel) == -1)
	{		
		Pickup( PickuP );//previous works
	}

	//tune in cohere queue
	OldLay(Tops = IFOcus);
	WiRect(Eche = Clevel, 0);
	Foot = 1;      //trace

	//transform corner low
	CorGau(ang);CorSmo(2);
	for(i = 0; i < SCORN; i++)
   {
      Corn[i] *= 2;
   }

	//recognize focus area
   if (integ)
   {
	   Docvie = (tvii)&CWork::IfTune;
	   Docisi = (tv_v)&CWork::IfPrep;
	   Scener(Eche);
	   //develop indignations
      int max = Cwhirl;
   //   if (quick)
   //      max--; 
	   for(Clas = 0; Clas <= max; Clas++)
	   {
		   //recognize focus area
		   Docvie = (tvii)&CWork::IfTune;
		   if(Clas == Cwhirl)
		   { 
            Docexe = (tvii)&CWork::Argums_quick; 
            Docisi = (tv_v)&CWork::IfIndi;
         }
		   else
		   { 
            Docexe = (tvii)&CWork::Argums_I; 
            Docisi = (tv_v)&CWork::IfIndi_2;
         }
		   Scener(Eche);

		   //builds twist of flow
		   Docvie = (tvii)&CWork::IfTune;
		   Docisi = (tv_v)&CWork::IfTwis;
		   Docexe = (tvii)&CWork::Twists_I;
		   Scenei(2, Eche, Eche);
      }
	   //transform relaxation
	   CorGau(ray);CorSmo(4);
	   //memmove((void *)Corn, (void *)Ifocus_Corn_2, sizeof(Corn));

	   //----------------------------------
	   //	lift up all indignations to hill
	   //----------------------------------
	   for(i = 0; i < Clifts; i++)
	   {
		   do
		   {	
			   Proc = 0;//may be stop

			   //up any indignation..
			   Docvie = (tvii)&CWork::IfTune;
			   Docisi = (tv_v)&CWork::IfLift;
			   Docimm = (ti_v)&CWork::IfImme;
			   Scener(Eche);
		   }
		   while (Proc);

		   Hypo = 0;//indignation

		   //enumerate some graph
		   Docvie = (tvii)&CWork::IfTune;
		   Docisi = (tv_v)&CWork::IfEnum; //Mark MATH_I
		   Scenei(2, Eche, Eche);

		   //enlarge focus's area
		   Docvie = (tvii)&CWork::IfTune;
		   Docisi = (tv_v)&CWork::IfWideV;
		   Docexe = (tvii)&CWork::IfWide;
		   Scenei(2, Eche, Eche);

		   //measures focus alpha
	      Docvie = (tvii)&CWork::IfTune;
	      Docisi = (tv_v)&CWork::IfRaysV;
	      Docbre = (ti_i)&CWork::IfRays;
	      Scener(Eche);
	   }
	   //pierce hierarchie's lay
	   for(; reih < Eche; reih++)
	   {
		   //hierarchy projection
		   Docvie = (tvii)&CWork::IfDeep;
         if (integ)
		      Docisi = (tv_v)&CWork::IfDeepV_integ;
         else
		      Docisi = (tv_v)&CWork::IfDeepV;
		   Scenew(0, Eche, reih);
	   }
#ifdef SAVE_LAYERS
   saveLayer("ifocus_MATH_I.dat", MATH_I, 3);
   saveLayer("ifocus_FCLASS.dat", FCLASS, 3);
   saveLayer("ifocus_FLOW_F.dat", FLOW_F, 3);
   saveLayer("ifocus_ARCH_D.dat", ARCH_D, 3);
#endif
   	//destroy a local link
	   destroyifocus( this );
   }
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
