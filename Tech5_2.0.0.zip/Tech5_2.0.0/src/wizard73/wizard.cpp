/**************************************
				Wizard.cpp
	 Definitions for compatible.

			Author Gudkov V.U.
**************************************/

//	Header project files
#include    <stdio.h>
#include    <stdlib.h>
#include    <string.h>

#include		"access73.h"
#include		"assert.h"
#include		"inline73.h"
#include		"mathem73.h"
#include		"moulds73.h"
#include		"packed73.h"
#include		"sorter73.h"
#include		"wizard73.h"	
#include		"wibase73.h"	

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

bool integ = true;

//-------------------------------------
//	Models of indignations
//-------------------------------------
byte	Delta[] = { 0,158,135,113, 90, 68, 45, 23},
		Archs[] = {35, 30,  0,150,145,145,  0, 35},
		Loops[] = { 0,  3, 14, 50, 90,130,166,177},
		Whorl[] = {90,137,  0, 43, 90,137,  0, 43};

/**************************************
		Service <CBase> functions
**************************************/
#ifdef SAVE_LAYERS
bool CBase::saveLayer(const char *filename, int lay, int	 hier)
{
	byte* p = GetLay (lay, hier);
   if (!p)
      return false;
   char path[255];
#ifdef ANDROID
   strcpy (path, "/sdcard/TECH5/");
#elif _WINDOWS
   strcpy (path, "../../test/NIST14/layers-win/");
#else
   strcpy (path, "../../test/NIST14/layers-lin/");
#endif
   strcat (path, filename);
   FILE *f = fopen (path, "wb");
   if (!f)
      return false;
   fwrite (p, 1, Size[hier], f);
   if (f) fclose (f); 
   return true;
}
bool CBase::saveLink(const char *filename, SLink &slink)
{
   char path[255];
#ifdef ANDROID
   strcpy (path, "/sdcard/TECH5/");
#elif _WINDOWS
   strcpy (path, "e:/temp/layers/");
#else
   strcpy (path, "./layers/");
#endif
   strcat (path, filename);
   FILE *f = fopen (path, "wb");
   if (!f)
      return false;
   fwrite (&slink, 1, sizeof(SLink), f);
   if (f) fclose (f); 
   return true;
}

bool CBase::saveInt(const char *filename, int val)
{
   char path[255];
#ifdef ANDROID
   strcpy (path, "/sdcard/TECH5/");
#elif _WINDOWS
   strcpy (path, "e:/temp/layers/");
#else
   strcpy (path, "./layers/");
#endif
   strcat (path, filename);
   FILE *f = fopen (path, "wb");
   if (!f)
      return false;
   fwrite (&val, 1, sizeof(int), f);
   if (f) fclose (f); 
   return true;
}

bool g_writeLog = false;
#endif

//	Set lays number in every echelon
void	CBase::SetMap( const int *lay )
{
	//quantity of lays for echelons
	for (int i = 0; i < ECHEM; i++)
	{
		LayN[i] = MIN( lay[i],POWER );
	}
}

//	Delete document memory
void	CBase::DelDoc( void )
{
	//delete hierarchy
	if (Hier[0].Lays[0])
	{
		delete [] Hier[0].Lays[0];
		Hier[0].Lays[0] = 0;
	}
	if(I_Fisuna)
	{
		delete [] I_Fisuna;
		I_Fisuna = 0;
	}
	if(I_Fisunb)
	{
		delete [] I_Fisunb;
		I_Fisunb = 0;
	}
	if(I_Fisunc)
	{
		delete [] I_Fisunc;
		I_Fisunc = 0;
	}
	if(I_Fisund)
	{
		delete [] I_Fisund;
		I_Fisund = 0;
	}
	if(I_Fisunac)
	{
		delete [] I_Fisunac;
		I_Fisunac = 0;
	}
}

//	Delete fast table memory
void	CBase::DelTab( void )
{
	//delete a heap
	if (Dtab)
	{
		delete [] Dtab; 
		Dtab = 0;
	}
	//delete a heap
	if (Stab)
	{
		delete [] Stab; 
		 Stab = 0;
	}
}

//	Reset document
void	CBase::ResDoc( void )
{
	//reset optimization procedures
	for (int u = 0; u < _SET__; u++)
		 Sets[u]= 0;

	//reset the pyramidal structure
	for (int i = 0; i < ECHEM; i++)
	{
		//set default all lays and keys
		for (int j = 0; j < POWER; j++)
		{
			Hier[i].Unit	 =  0;
			Hier[i].Lays[j] =  0;
			Hier[i].Keys[j] = -1;
			Hier[i].Clks[j] = -1;
		}

		//no default
		Side[i] = 0;
		MaxX[i] = 0; 
		MaxY[i] = 0;
		Size[i] = 0;
	}
	//fast table
	Dtab = 0;
	Stab = 0;
	I_Fisuna = I_Fisunb = I_Fisunc = I_Fisund = I_Fisunac = 0;
}

//-------------------------------------
//		Protect and verify data
//-------------------------------------

//	Set module protection
int	CBase::SetMod( byte *src )
{
	//reads string area size of src
	int size;   ReadSz( src,size );
	//collect all bytes, untill end
	int i = 0,sm = 0;
//	for (; i < size-1;) sm += src[i++];
   for (; i < size-4;) sm += src[i++];
	//set past position - module fb
//	return src[size-1]  = sm % 251;
   src[size-4]  = 0;
   src[size-3]  = 0;
   src[size-2]  = 0;
   return src[size-1]  = sm % 251;
}

//	Check module protection
int	CBase::VerMod( byte *src )
{
	//reads string area size of src
	int size;	ReadSz( src,size );
	//collect all bytes, untill end
	int i = 0,sm = 0;
	for (; i < size-1;) sm += src[i++];
	//set past position - module fb
	return src[size-1] == sm % 251;
}

//-------------------------------------
//	CBase constructor & destructor
//-------------------------------------

//	CBase constructor
CBase::CBase( void )
{
	static 
	int	pyr[][ECHEM] = 
	{//for every echelon
		{ 7,23,23,52, 0},
      //{11,23,23,52, 0},
		{ 8,24,24,54, 0},
		{12+2,24,24,54+8, 0},
		{ 6, 4, 4, 4, 4},
		{ 9, 1, 1, 1, 0}
	};
   //if (quick)
   //{
   //   pyr[0][3] = 66;
   //   pyr[1][3] = 66;
   //   pyr[2][3] = 74;
   //}
   //else
   {
      pyr[0][3] = 52;
      pyr[1][3] = 54;
      pyr[2][3] = 62;
   }

	//pyramidal model
	PyrF	=	pyr[0] ,
	PyrR	=	pyr[1] ,
	PyrL	=	pyr[2] ,
	PyrT	=	pyr[3] ,
	PyrV	=	pyr[4] ;

	//set lays number
	SetMap(  PyrT  );

	WiRect();//region
	ResDoc();//resets
	Resume();//deaden
	Docuse  = &CBase::Deaden;
}

//	CBase destructor
CBase::~CBase( void )
{
	DelDoc();//delete
	DelTab();//delete
	ResDoc();//resets
	Resume();//clears
}

/**************************************
	CHues constructor & destructor
**************************************/

//	CHues destructor
CHues::CHues( void )
{
	//default palette
	corn hue[] = 
	{//	B G R
		0xffffff,
		0x30ffff,
		0xff2040,
		0xff9090,
		0x20ff40,
		0x00ff00,
		0x20c0ff
	};

	//default colour!
	HuSa	  = COLOUR;

	//default palette
	SetHue( SOURCE,
			  hue[0] );
	SetHue( PHOTIC,
			  hue[1],
			  hue[2] );
	SetHue( CCLASS,
			  hue[3] );
	SetHue( SKELET,
			  hue[4] );
	SetHue( FLOW_P,
			  hue[5],
			  hue[6] );
}

//	CHues destructor
CHues::~CHues( void )
{
}

/**************************************
		Service <CWork> functions
**************************************/

//	Reset data of CWork
void	CWork::ResDoc( void )
{
	//default
	Nmin	  =
	Nind	  = 0;
}

//-------------------------------------
//	CWork constructor & destructor
//-------------------------------------

CWork::CWork( void )
{
	ResDoc();

	int a;
	Whether_Pattern = true; //default is true
	for ( a = 0; a < 180; a++)
	{
		Scheme_LookupCm[a] = cosm(SCALE, a*2);
		Scheme_LookupSm[a] = sinm(SCALE, a*2);
	}
	int b;
	for (a = 0; a < 255; a++)
	{
		for (b = 0; b < 360; b++)
		{
			Bresen_LookupCm[a][b] = cosm(a, b);
			Bresen_LookupSm[a][b] = sinm(a, b);
		}
	}
	for(a=0; a<30; a++)
	{
		for(b=0; b<30; b++)
		{
			Furiew_dist_lookup[a][b] = dist(a, b);
		}
	}
	get_cogm_temp();

	Docisi_ptr  = &CBase::Deaden;
	Dociso_ptr  = &CBase::Deaden;


	Argums_Lookup0 = Argums_Lookup+180;
	for (a = -180 ; a <= 180; a++)
		Argums_Lookup0[a] = cosm( SCALE, a);

	for( a = 0; a < 180; a++)
	{
		Argums_LookupCosm[a] = cosm(ARGUMS_COSM_SCALE, 2 * a);
		Argums_LookupSinm[a] = sinm(ARGUMS_SINM_SCALE, 2 * a);
	}
}

//	CWork destructor
CWork::~CWork( void )
{
}

/**************************************
		Service <Codex> functions
**************************************/

//	Reset data of Codex
void	Codex::ResDoc( void )
{
	//set default DPI
	ImgDPI  =
	ManDPI  = DEFDPI;

	//set default Dir
	ImgDir  =
	ManDir  = DEFDIR;

	//do default info
	Root	  =	0x00;
	Tops    = SOUrce;
	Node	  =	0x00;

	//set default net
	TipNet  = NETMAX;

	//default
	ExMask  = 0; //ok
	ImMask  =
	Method  =
	Shrink  =
	Impose  =
	Number  =
	Qualit  =
	Densit  =
	ImType  = 0; //ok

	//default
	PFocus  =
	PPoint  =
	PTotal  =
	PRidge  =
	PAreas  =
	PLinks  = 0; //ok

	//default
	Passxy  = 
	Passan  = 20;
	
}

//-------------------------------------
//	Codex constructor & destructor
//-------------------------------------

//	Codex constructor
Codex::Codex( void )
{
	ResDoc();
   m_ISO_compatibe = false;
   m_quality = 0;
}

//	Codex destructor
Codex::~Codex( void )
{
}

/**************************************
			Get pattern type
**************************************/

//	Get nearest alpha of loop turning to flexure
static int toflex( SSign &dst,SSign &src )
{
	return turn( dst.Look*2,src.Beta*2 );
}

//	One loop
static int flexor( SSign f[],int size )
{
	//get indexes of loop, delta
	int i = Torder( f,size,FX );
	int j = Torder( f,size,FL );

	//measure pattern's topology
	if (toflex( f[i],f[j] ) > 0)
		return LOOP_R;
	else
		return LOOP_L;
}

//	One loop & one delta for plain loops
static int plloop(  SSign f[],int size )
{
	//get indexes of loop, delta
	int i = Torder( f,size,FL );
	int j = Torder( f,size,FD );

	//classify
	if(Tturns( f[j],f[i] ) < 0)
		return LOOP_R;
	else
		return LOOP_L;
}

//	One loop & one delta
static int tented(  SSign f[], const int size )
{
	//get indexes of loop, delta
	int i = Torder( f,size,FL );
	int j = Torder( f,size,FD );

	//measure pattern's topology
	int d = Tcompl( f[j],f[i] );

	//if tented arch
	if (ABS(d) < 14)
		return ARCH_T;
	//if normal loop
	if (ABS(d) > 33)
		return plloop( f,size );
	else
		return plloop( f,size )|
				 ARCH_T;
}

//	One whorl & may be 0..2 deltas
static int pocket( SSign f[],const int size )
{
	//defines index of one whorl 
	int i = Torder( f,size,FW ),
		 j = -1;

	//find nearest delta
	int u = 0,h,n = 99;
	for (; u < 2; u++)

	{
		//if real delta exist
		if ((h = Torder( f,size,FD,u )) != -1)
		{
			//select only best position
			if (n > (int)Tdists( f[i],f[h]))
			{
				 n = (int)Tdists( f[i],f[h]);
				 j = h;					//index
			}
		}
	}

	int addtype = 0;
	//is plain whorl ?
	if (n > 45)
		return	WHORLP;
	else
	if (n > 25) 
		addtype = WHORLP;

	//build a list copy
	SSign	  p[ NFOCUS];
	Tocopy( p,f,size );

	//a new indignation
	p[i].Type = FL;
	p[i].Beta = Tdirec( f[j],f[i] )/2;
	p[j].Type = FN;

	//classify loop and the whorl
	if (Tcubic( p,size,FD ) == 1)
	{
		if (plloop( p,size ) & LOOP_L)
			return LOOPCL | addtype;
		else
			return LOOPCR | addtype;
	}
	else
	{
		if (flexor( p,size ) & LOOP_L)
			return LOOPCL | addtype;
		else
			return LOOPCR | addtype;
	}
}

//	Double loop
static int loop_d( SSign f[],const int size )
{
	//defines index of one whorl 
	int i = Torder( f,size,FL,0 ),
		 j = Torder( f,size,FL,1 );

	//measure pattern's topology
	int a = Tcompl( f[j],f[i] ),
		 b = Tcompl( f[i],f[j] );


   int d = Tdists( f[j],f[i] );
   int beta =  ABS(a+b);

	if (beta < 30)
		return WHORLP;
	if (beta < 50 && beta*d < 2000)
		return WHORLP | LOOP_D;
	if (d > 45)
		return LOOP_D;

	//build a list copy
	SSign	  p[ NFOCUS];
	Tocopy( p,f,size );

	//a new indignation
	p[i].Type = FW;
	p[j].Type = FN;
	int one = pocket( p,size );

	Tocopy( p,f,size );

	//a new indignation
	p[i].Type = FN;
	p[j].Type = FW;
	int two = pocket( p,size );

	return one | two;
}

//-------------------------------------
//	Get pattern type
//-------------------------------------
void	Codex::SubDes( void )
{
	//don't use if left/right palmprints
	if (ImType == 'P' ||  ImType == 'S')
	{
		ExMask = PALMSX;
		return;//anknown
	}

	//get number of any focus type
	int loops = Tcubic( Indi,Nind,FL );
	int whorl = Tcubic( Indi,Nind,FW );
	int delta = Tcubic( Indi,Nind,FD );

	//classify pattern
	if (loops && whorl)
		ExMask = ACCIDS;
	else
	if (loops >  2)
		ExMask = ACCIDS;
	else
	if (whorl >  1)
		ExMask = ACCIDS;
	else
	if (delta >  2)
		ExMask = ACCIDS;
	else
	if (whorl == 1)
		ExMask = pocket( Indi,Nind );
	else
	if (loops == 2)
		ExMask = loop_d( Indi,Nind );
	else
	if (delta == 2)
		ExMask = WHORLP;
	else
	if (loops && delta)
		ExMask = tented( Indi,Nind );
	else
	if (loops == 1)
		ExMask = flexor( Indi,Nind );
	else
	if (delta == 1)
		ExMask = WHORLP;
	else
		ExMask = ARCH_P;
}

void	Codex::Design( void )
{
	SubDes();
	ImMask = (byte)ExMask;
	if(ExMask & (WHORLS & ~WHORLP))
		ImMask|= WHORLU;
}

void	Codex::DesImp( void )
{
	if(ImMask & (WHORLC | WHORLU))
	{
		if((ExMask & WHORLS) == 0)
			ExMask |= WHORLP;
	}
	if(ImMask & (LOOPLC | LOOPLU))
	{
		if((ExMask & LOOP_L) == 0)
			ExMask |= LOOP_L;
	}
	if(ImMask & (LOOPRC | LOOPRU))
	{
		if((ExMask & LOOP_R) == 0)
			ExMask |= LOOP_R;
	}
	if(ImMask & (ARCHSU))
	{
		if((ExMask & ARCH_T) == 0)
			ExMask |= ARCH_T;
	}
	if(ImMask & (ARCHSC))
	{
		if((ExMask & ARCH_P) == 0)
			ExMask |= ARCH_P;
	}
}

/**************************************
		Find centre position of axe
**************************************/

//	Get minimum of focus quality
static int qualit( SSign f[],const int size,int qual )
{
	//look over indignation's list
	int i = 0,w = 0,t = qual;
	for (; i < size; i++)
	{
		//check image safe
		switch (f[i].Type)
		{
			case FW: w += 2; break;
			case FL: w += 1; break;
			case FD: w -= 1; break;
			default:	continue; //go
		}

		//select a minimum
		if (t > f[i].Prob)
			 t = f[i].Prob;
	}

	//set quality and image safe
	return w == 0 ? t : t | 0x80;
}

//	Get geometric centre of focuses
static void subaxe( SSign f[],int * size,int type,int qual )
{
	//gets the order of a centre
	int j = Torder( f,*size,FX );
	
	//if absents
	if (j == -1)
	{
		//verify to insert
		if(*size == NFOCUS)
			return ;

		// image center
		j = (*size)++;//ok
		f[j].Type = FX; 
		f[j].Movx =	 0;
		f[j].Movy =	 0;
		f[j].Beta =  0;
	}

	//write parameters of center
	f[j].Look = f[j].Beta  +  AQ;
	f[j].Prob = qualit( f, *size, qual );
		
	//look over the list
	for (int i = 0,c = AF,k; i < *size; i++)
	{
		//collect only natives
		if (f[i].Type != type)
			continue;

		//select the best oriented centre
		if ((k = ABS( toflex( f[j],f[i] ))) < c)
		{
			c = k;//store position
			f[j].Movx = f[i].Movx;
			f[j].Movy = f[i].Movy;
		}
	}
}

//	Find centre of the finger
void	Codex::Centre( int qual )
{
	if (Tcubic( Indi,Nind,FW ))
		 subaxe( Indi,&Nind,FW,qual );
	else
	if (Tcubic( Indi,Nind,FL )) 
		 subaxe( Indi,&Nind,FL,qual );
	else
	if (Tcubic( Indi,Nind,FD )) 
		 subaxe( Indi,&Nind,FD,qual );
	else
		 subaxe( Indi,&Nind,-1,qual );
}

/**************************************
		Export/Import indignations
**************************************/

//	Export indignation
void	Codex::ExIndi( byte *dst,int &num )
{
	//work with focus
	num = Nind;  //OK
	if (!dst) return;
	StrDst(dst,(byte*)Indi,num*sizeof( SSign ));
}

//	Import indignation
void	Codex::ImIndi( byte *src,int &num )
{
	//work with focus
	Nind = num;	 //OK
	if (!src) return;
	StrDst((byte*)Indi,src,num*sizeof( SSign ));
}

//	Import indignation or delete it
void	Codex::ImIndi( SSign &src )
{
	//if new then add
	switch (src.Type)
	{
		case FW:
		case FL:
		case FD:	Indi[Nind++] = src;
					return;
	}

	//del indignation
	int i = Nature( src.Movx,src.Movy );
	for (--Nind; i > 0 && i < Nind; i++)
		//compression!
		Indi[i] = Indi[i+1];
}

/**************************************
  Export/Import image characteristics
**************************************/

//	Encode list of features
uint	Codex::EnFeat( byte *dst,SSign *src,uint size,uint *deg )
{
	//prepare
	uint	alin = 0,
			abit = 0;

	//correct conception of presentation
	deg[0] = Quants(Tmax_x( src,size ));
	deg[1] =	Quants(Tmax_y( src,size ));
	deg[3] =	Quants(Tmax_l( src,size ));

	//set conception for some bits
	for (int j = 0; j < 0x08; j++)
	{
		EnBits( dst,&alin,&abit,deg[j],4 );
	}

	//packing the list of minutiae
	for (uint i = 0; i < size; i++)
	{
		EnBits( dst,&alin,&abit,src[i].Movx,deg[0] );
		EnBits( dst,&alin,&abit,src[i].Movy,deg[1] );
		EnBits( dst,&alin,&abit,src[i].Type,deg[2] );
		EnBits( dst,&alin,&abit,src[i].Lace,deg[3] );
		EnBits( dst,&alin,&abit,src[i].Prob,deg[4] );
		EnBits( dst,&alin,&abit,src[i].Beta,deg[5] );
		EnBits( dst,&alin,&abit,src[i].Look,deg[6] );
		EnBits( dst,&alin,&abit,src[i].Curl,deg[7] );
	}

	//make even the active length
	return abit ? alin +1 : alin;
}

//-------------------------------------
//	Decode list of features
//-------------------------------------
int Codex::DeFeat( SSign *dst,uint *src,uint size )
{
	//set buffer of
	uint 	alin = 0,
			abit = 0,
			data = 0,
			temp = 0;

	//parameter!
	if (!size)	//initialization
		return 0; data =  src[0];

	//a header	
	DEBIT4( src,alin,abit,data,temp ); uint movx = temp;
	DEBIT4( src,alin,abit,data,temp ); uint movy = temp;
	DEBIT4( src,alin,abit,data,temp ); uint type = temp;
	DEBIT4( src,alin,abit,data,temp ); uint lace = temp;
	DEBIT4( src,alin,abit,data,temp ); uint prob = temp;
	DEBIT4( src,alin,abit,data,temp ); uint beta = temp;
	DEBIT4( src,alin,abit,data,temp ); uint look = temp;
	DEBIT4( src,alin,abit,data,temp ); uint curl = temp;

	//unpack indignations
	int i = 0;
	for (; (alin << 2) + (abit >> 3) + (abit & 7 ? 1 : 0) < size; i++)
	{
		DEBITS( src,alin,abit,data,temp,movx ); dst[i].Movx = temp;
		DEBITS( src,alin,abit,data,temp,movy ); dst[i].Movy = temp;
		DEBITS( src,alin,abit,data,temp,type ); dst[i].Type = temp;
		DEBITS( src,alin,abit,data,temp,lace ); dst[i].Lace = temp + HP*(quick? HL_Q : HL);
		DEBITS( src,alin,abit,data,temp,prob ); dst[i].Prob = temp;
		DEBITS( src,alin,abit,data,temp,beta ); dst[i].Beta = temp;
	}
	//unpack successful ?
	return  (alin << 2) + (abit >> 3) + (abit & 7 ? 1 : 0) == size ? i : RUINED;
}

//	Decode list of indignations
int	Codex::DeIndi( SSign *dst,byte *src )
{
	return DeFeat( dst,DFocus<uint*>(src),
							 QFocus<uint >(src));
}

//	Decode list of minutiaes
int	Codex::DeSign( SSign *dst,byte *src )
{
	return DeFeat( dst,DPoint<uint*>(src),
							 QPoint<uint >(src));
}

void Codex::GetSize(int &num)
{
	uint	bi_i[] = {0,0,5,7,6,8,0,0},
			bi_m[] = {0,0,1,7,8,8,0,0};

	//pack list of features
	PFocus = EnFeat(GetLay(LISTpI, H3), Indi, Nind, bi_i);
	PPoint = EnFeat(GetLay(LISTpM, H1), Sign, Nmin, bi_m);

	//combine fixed data...
	{Item.VeSign = VESIGN;}
	{Item.Number = Number;}
	{Item.ImgDPI = ImgDPI;}
    if (quick)
    {
//        Item.ImgDPI = (int)(Item.ImgDPI / K_CHANGE_DPI);
//        if (ABS(Item.ImgDPI - 500) < 5)
//            Item.ImgDPI = 500;
    }
	{Item.ManDPI = ManDPI;}
	{Item.Qualit =	Qualit;}
	{Item.Densit =	Densit;}
	{Item.ImMask =	ImMask;}
	{Item.ImType =	ImType;}
	{Item.Method =	Method;}
	{Item.Passxy = Passxy;}
	{Item.Passan = Passan;}
	{Item.TipNet = TipNet;}
	{Item.Size_X = * MaxX;}
	{Item.Size_Y = * MaxY;}
    if (quick)
    {
//        Item.Size_X = (int)(MaxX[0] * K_CHANGE_DPI);
//        Item.Size_Y = (int)(MaxY[0] * K_CHANGE_DPI);
//        Item.Size_X = (Item.Size_X + 3) / 4 * 4;
//        Item.Size_Y = (Item.Size_Y + 3) / 4 * 4;
    }
	{Item.PFocus =	PFocus;}
	{Item.PPoint =	PPoint;}
	{Item.PTotal =	PTotal;}
	{Item.PRidge =	PRidge;}
	{Item.PAreas =	PAreas;}
	{Item.PLinks =	PLinks;}

	{Item.Length =
	 Disp.DUnuse =
	(Disp.DOwner =
	(Disp.DLinks =
	(Disp.DAreas = 
	(Disp.DRidge = 
	(Disp.DTotal = 
	(Disp.DPoint = 
	(Disp.DFocus = sizeof( SItem ) +
						sizeof( SDisp ))+
								 PFocus  )+
								 PPoint  )+
								 PTotal	)+
								 PRidge	)+
								 PAreas	)+
//								 PLinks  )+1;}
								 PLinks  )+4;}

	//length of buffer
	num = Item.Length;
}
void Codex::ExGold(byte *dst)
{
	//write
	StrDst(
	StrDst(
	StrDst(
	StrDst(
	StrDst(
	StrDst(
	StrDst(
	StrDst( dst,(byte*)&Item,sizeof( SItem )),
					(byte*)&Disp,sizeof( SDisp )),
					GetLay( LISTpI,H3 ),PFocus  ),
					GetLay( LISTpM,H1 ),PPoint  ),
					GetLay( LIST_T,H3 ),PTotal  ),
					GetLay( LIST_R,H3 ),PRidge  ),
					GetLay( LIST_A,H3 ),PAreas  ),
					GetLay( LISTpL,H1 ),PLinks  );

	//protect data
	SetMod( dst );
}
/**************************************
		Export/Import temporary data
**************************************/

//	Export special data
void	Codex::ExData( byte *dst,int &num )
{
	//length of buffers
	num = 3*Size[H3]+5;
	if (!dst)	return;

	//write
	StrDst(
	StrDst(
	StrDst( dst+4,GetLay( CCLASS,H3 ),Size[H3] ),
					  GetLay( FLOW_L,H3 ),Size[H3] ),
					  GetLay( PROB_L,H3 ),Size[H3] );

	//protect the data
	SaveSz( dst,num );
	SetMod( dst );//ok
}

//	Import special data
int	Codex::ImData( byte *src,int &num )
{
	//verify module protection!
	if (VerMod( src ) == 0) 		return  MODULE;

	//read the temporary a data
	StrSrc( GetLay( PROB_L,H3 ),
	StrSrc( GetLay( FLOW_L,H3 ),
	StrSrc( GetLay( CCLASS,H3 ),src+4,Size[H3] ),
												 Size[H3] ),
												 Size[H3] );
											//form success
											return  SUCCES;
}

/**************************************
	Numerate fingerprints on tenprint
**************************************/
void	Codex::Finger( void )
{
	//local variables
	int	poxy[_TIP_],
			harm = 0xa0,
			left = 9999,
			tpos,
			inum;

	//compress the rectangle list
	int i = 0,tips = 0,thre = 0;
	for (; i < _TIP_; i++)
	{
		//compress the frames list
		if((Rect[tips] = Rect[i]).Rect)
		{
			tips++;//average height
			thre += (Rect[i].T_re +
						Rect[i].B_re)/2;
		}
	}

	//delete the absent fingers
	for (i = tips; i < _TIP_; i++)
	{
		Rect[i].Rect = 0;
	}

	//calc threshold
	if(tips) 
		thre /= tips;
	else
		return; //no

	//build xy frames position
	for (i = 0; i < tips; i++)
	{
		if(left > (poxy[i] = (Rect[i].R_re+Rect[i].L_re)/2))
			left =  poxy[i];
		if(thre <				(Rect[i].T_re+Rect[i].B_re)/2)
			poxy[i] = -poxy[i];
	}

	//numerate the finger rows..
	isortM( Rect,poxy,comp,tips-1 );

	//left position
	left  -=  harm;

	//numerate 1..5 finger
	for (i = 0,tpos = left,inum = 1; i < tips; i++)
	{
		//verify this row..
		if (poxy[i] > 0)
		{
			//verify existence of next finger
			if (poxy[i] - tpos < 3*harm/2)
			{
				tpos = poxy[i];//next
				Rect[i].Rect  = inum;
			}
			else
			{
				tpos += harm;	  i--;
			}
			inum++;	//goon
		}
	}

	//numerate 6..10 finger
	for (i = 0,tpos = left,inum = 6; i < tips; i++)
	{
		//verify this row..
		if (poxy[i] < 0)
		{
			//verify existence of next finger
			if (-poxy[i] - tpos < 3*harm/2)
			{
				tpos = -poxy[i];//next
				Rect[i].Rect  = inum;
			}
			else
			{
				tpos += harm;	  i--;
			}
			inum++;	//goon
		}
	}
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
