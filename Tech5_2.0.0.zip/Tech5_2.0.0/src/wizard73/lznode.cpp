/**************************************
				 LzNode.cpp
		A data compression Program.

			Edited by Gudkov V.U.
***************************************
	Auther 4/6/1989 Haruhiko Okumura.
***************************************/

//	Export & Import tune
#include "packed73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//	Local definitions
#define	LZRING		4096						//ring buffer
#define	LZ_LIM	   18							//length limit to match
#define	LZBASE		0							//character that will appear often
#define	LZDOOR		2							//threshold to encode string
#define	LZBYTE		4							//capacity of byte for length
#define	LZ_NIL		LZRING					//index for root of binary search trees

//-------------------------------------
//	Local variables
//-------------------------------------
static int	eyes,									//measure size
				mpos,									//match position
				mlen,									//longest match
				slen,									//source length
				sind,									//source index
				dind,									//destination index
				lson[LZRING +  1],				//left children
				rson[LZRING +257],				//right children
				papa[LZRING +  1];				//parents

static byte ring[LZRING +
					  LZ_LIM -  1],				//ring to facilitate string comparison
			  *sour,									//source
			  *dest;									//destination

/**************************************
			Inline functions
**************************************/

//	Tune in encode parameters
static inline void tune_en( byte *dst,byte *src )
{
	//set strings
	sour =   src;
	dest =   dst;

	//set indexes
	dind =LZBYTE;
	sind = 0;
	slen = 0;

	//for size queries
	eyes = (dst == 0);
}

//	Tune in decode parameters
static inline void tune_de( byte *dst,byte *src )
{
	//set strings
	sour =   src;
	dest =   dst;
	//set indexes
	sind =LZBYTE;
	dind = 0;
	slen = 0;

	//for size queries
	eyes = (dst == 0);
}

//	Set string length
static inline void SetSize( int &size )
{
	//put distributed start bytes..
	for (int i = 0; i < LZBYTE && !eyes; i++)
	{
		//distribute size to 4 bytes
		dest[i]  = (size >> (i<<3));
	}
}

//	Get string length
static inline void GetSize( int &size )
{
	//get distributed start bytes..
	for (int i = 0; i < LZBYTE; i++)
	{
		//gather distributed 4 bytes
		size += (sour[i] << (i<<3));
	}
}

//-------------------------------------
//	Get byte & put byte functions
//-------------------------------------

//	Get the next byte
static inline int get( void )
{
	//not exhausted..
	if (sind < slen)
		return sour[sind++];
	else
		//nothing
		return -1;
}

//	Put the next byte
static inline int put( int c )
{
	//if works
	if (!eyes)
		return dest[dind++] = c;
	else
		return		dind++;
}

/**************************************
		Kernal of Lempel-Zive packing
**************************************/

//	Initialize trees
static void InitTree( void )
{
	//the root of the tree for strings
	for (int i = LZRING +1; i <= LZRING +256; i++)
		rson[i] = LZ_NIL;

	//parent not used
	for (int j = 0; j < LZRING; j++) 
		papa[j] = LZ_NIL;
}

//	Insert a node
static void InsertNode( int r )
{
	//set start key & prepare
	byte	*key =  &ring[ r ];
	rson[r] =lson[r] =LZ_NIL;  
	mlen = 0; //reset longest

	//infinite loop
	int cmp, p;
	for (cmp = 1,p = LZRING +key[0] +1; ; )
	{
		//if positive
		if (cmp >= 0)
		{
			//if rson already exist
			if (rson[p] != LZ_NIL)
				p = rson[p];
			else
			{  
				//right node
				rson[p] = r;
				papa[r] = p;
				return; //OK
			}
		} 
		else 
		{
			//if already lson exist
			if (lson[p] != LZ_NIL) 
				p = lson[p];
			else 
			{  
				//left node
				lson[p] = r;  
				papa[r] = p;  
				return; //OK
			}
		}

		//find first item != zero
		int i;
		for (i = 1; i < LZ_LIM; i++)
			if ((cmp = key[i] - ring[p+i]) )
				break;

		//if longest match
		if (i > mlen)
		{
			mpos = p;//check position
			if ((mlen = i) >= LZ_LIM)  
				break;
		}
	}
	//rebuild new tree
	papa[r] = papa[p];  
	lson[r] = lson[p];  
	rson[r] = rson[p];
	papa[lson[p]] = r;  
	papa[rson[p]] = r;

	//switch parent nodes
	if(rson[papa[p]] == p)
		rson[papa[p]] = r;
	else                   
		lson[papa[p]] = r;

	//remove a p node
	papa[p] = LZ_NIL;
}

// Deletes node p from tree
static void DeleteNode( int p,int q = 0 )
{
	//if not in tree
	if (papa[p] == LZ_NIL)
		return;
	//find a branche
	if (rson[p] == LZ_NIL)
		q = lson[p];
	else 
	if (lson[p] == LZ_NIL)
		q = rson[p];
	else
	{
		//step down
		q = lson[p];

		//if rson not empty...
		if (rson[q] != LZ_NIL) 
		{
			//find r-branch
			do q = rson[q];  
			while (rson[q] != LZ_NIL);

			//rebuild tree structure
			rson[papa[q]] = lson[q];
			papa[lson[q]] = papa[q];

			//clean a dustbin
			lson[q] = lson[p];
			papa[lson[p]] = q;
		}
		//final rebuilding
		rson[q] = rson[p];
		papa[rson[p]] = q;
	}
	//refresh index
	papa[q] = papa[p];

	//switch parent nodes
	if (rson[papa[p]] == p) 
		rson[papa[p]] = q;  
	else 
		lson[papa[p]] = q;

	//delete a p node
	papa[p] = LZ_NIL;
}

/**************************************
				Pack data.
	0-3 bytes of source is it's length.
**************************************/
int	EnNode( byte *dst,byte *src )
{
	//local data...
	byte	code[17], 
			mask;
	int	last,
			head;

	//tune in procedure
	tune_en( dst,src );
	GetSize( slen/**/);
	
	//initialize
	InitTree();

	//original state
	code[0] = 0;//OK
	head = mask = 1;

	//initialize string buffer
	int i, s, r;
	for (i = 0,s = 0,r = LZRING - LZ_LIM; i < r; i++)
		ring[i] = LZBASE;

	//read F bytes into the last F bytes of the buffer
	int len, c;
	for (len = 0,c; len < LZ_LIM && (c = get()) != -1; len++)
		ring[r + len] = c; 

	//insert the F strings
	for (i = 1; i <= LZ_LIM; i++) 
		InsertNode( r-i );
	//insert read
	InsertNode(r);

	do 
	{
		//if length long near the end of text
		if (mlen > len) 
			 mlen = len; 
		//not long enough match
		if (mlen <= LZDOOR) 
		{
			//send byte
			mlen = 1;
			//send it's flag
			code[0] |= mask;
			//send uncoded
			code[head++] = ring[r];
		} 
		else 
		{
			//send position..length pair
			code[head++] = mpos;
			//note length >LZDOOR
			code[head++] = ((mpos >> 4) & 0xf0) | 
								 (mlen - (LZDOOR +1)); 
		}
		//shift mask left one bit
		if ((mask <<= 1) == 0) 
		{  
			//send at most 8 units of code together
			for (i = 0; i < head; i++) 
				put( code[i] );
			code[0] = 0;  
			head = mask = 1;
		}
		last = mlen;
		for (i = 0; i < last && (c = get()) != -1; i++) 
		{
			//deletes old
			DeleteNode(s);		
			//read bytes
			ring[s] = c;
			//extends for easier comparison
			if (s < LZ_LIM - 1) ring[s + LZRING] = c;
			//advance the position...
			s = (s +1) & (LZRING -1);  
			r = (r +1) & (LZRING -1);
			//ring[.r+F-1]
			InsertNode(r);
		}
		//after the ending
		while (i++ < last) 
		{
			//deletes old
			DeleteNode(s);					
			//buffer may be full...
			s = (s +1) & (LZRING -1);  
			r = (r +1) & (LZRING -1);
			//do not read but insert
			if (--len) InsertNode(r);
		}
	} while (len > 0);//until length of string is zero

	//send remaining code
	if (head > 1) 
	{
		for (i = 0; i < head; i++) 
			put( code[i] );
	}

	//save code size
	SetSize( dind );
	//tell code size
	return	dind  ;
}

/**************************************
	Denode: just the reverse of Ennode.
	0-3 bytes of source is it's length.
**************************************/
int	DeNode(  byte *dst,byte *src )
{
	//tune in procedure
	tune_de( dst,src );
	GetSize( slen/**/);

	//initialize string buffer
	int i, r;
	for (i = 0,r = LZRING -LZ_LIM; i < r; i++) 
		ring[i] = LZBASE;

	//infinite loop
	for (int c,j,flags = 0; ;) 
	{
		//uses higher byte cleverly to count eight
		if (((flags >>= 1) & 256) == 0) 
		{
			if ((c = get()) == -1)
				break;
			flags = c | 0xff00;
		}
		if (flags & 1) 
		{
			if ((c = get()) == -1) 
				break;
			put( c ); //OK
			//puts in ring
			ring[r++] = c;  
			r &= (LZRING -1);
		} 
		else 
		{
			if ((i = get()) == -1)
				break;
			if ((j = get()) == -1)
				break;
			i |= ((j & 0xf0) << 4);
			j = (j & 0x0f) +LZDOOR;
			for (int k = 0; k <= j; k++) 
			{
				c = ring[(i +k) & (LZRING -1)];
				put( c ); //OK
				//puts in ring
				ring[r++] = c;  
				r &= (LZRING -1);
			}
		}
	}

	//tell code size
	return   dind  ;
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
