/**************************************
				Mentor.cpp
			Library for teacher.

			 Author Gudkov V.U.
**************************************/

//	Header project files
#include		"access73.h"
#include		"inline73.h"
#include		"mathem73.h"
#include		"search73.h"
#include		"virtue73.h"
#include		"sorter73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//	Header system file
//#include		<stdio.h> 

/**************************************
			Random generator
**************************************/

//	Generate signed random
int	Coach::Random( void )
{
	return uran()-32767;
}

//	Set random parameter
int	Coach::Random( word *dst,word *src,int inum,int expr )
{
	while(1)
	{
		int nval = src[inum] + (src[inum]+5)*Random()*expr/(SPACE*TRAIN);
		while (nval <= 0)
			nval = -nval+1;
		while (nval >= 1000)
			nval -= nval/5;
		return dst[inum] = nval;
	}
}

int	Coach::Random( int expr )
{
	//int coef[] = {0,3,8,9,10,18,19,24,25,-1};
	//int coef[] = {0,3,8,9,10,19,25,-1};
	int coef[] = {0,3,8,9,10,18,19,24,25,-1};//growth

	int i = 0;
	for (; coef[i] != -1; i++)
	{
		Random( TabDat,Data,Disp+coef[i],expr );
	}
	return i;
}

/**************************************
		Estimates candidates quality
**************************************/

//	Measure quantity of native pairs
int	Coach::ATrust( CCand *src,int size )
{
	//look throw the model pairs..
	int i = 0,quan = 0;
	for (; i < Pair; i++)
	{
		//look throw the candidate list
		for (int j = 0; j < size; j++)
		{
			if (Inum[i] == src[j].CapI->Nord &&
				 Tnum[i] == src[j].CapT->Nord) 
			{
				quan++; 
				break ;
			}
		}
	}
	//percent of reliability
	return	100*quan/Pair;
}

//	May be native pair ?
int	Coach::ATrust( int ndst,int nsrc )
{
	//looks throw the model pairs
	for (int i = 0; i < Pair; i++)
	{
		if (Tnum[i] == ndst && Inum[i] == nsrc) 
			//success
			return 1;
	}

	//absent
	return 0;
}

//	Measure voting
int	Coach::Voting( int sure )
{
	//look throw the model pairs..
	int i = 0,qual = 0;
	for (; i < Pair; i++)
	{
		int same = 0,
			 pele = 0,
			 anum = 0;

		//look throw the candidate list
		for (int j = 0; j < Head; j++)
		{
			if (Inum[i] != Cand[j].CapI->Nord)
				continue;
			if (Tnum[i] == Cand[j].CapT->Nord)
				same += Cand[j].Simi +1;
			else
			{
				pele += Cand[j].Simi +1;
				anum += 1;
			}
		}

		if(anum) 
			pele /= anum;
		else
			pele  = same;
		//estimation
		if(same)
			qual += 1024*(sure	  )+ 
					  1024*(pele-same)/
							 (same+pele);
	}
	//this value
	return qual/Pair;
}

//	Get trajectory quality
int	Coach::QuPath( int sure )
{
	int base = 1,
		 same = 0,	
		 bnum = 0,
		 pele = 1,
		 pnum = 0;

	//simultaniously splitting
	for (int i = 0; i < Lays; i++)
	{
		Graph *lay = &Duke[i] ;
		CCand *can = lay->Cand;

		//look throw the candidate list
		for (int j = 0; j < lay->Head; j++)
		{
			//look throw the model pairs..
			int k = 0,find = 0;
			for (; k < Pair; k++)
			{
				if (Inum[k] == can[j].CapI->Nord &&
					 Tnum[k] == can[j].CapT->Nord)



				{
					 find++; break;
				}
			}
			if (i == Gold && find)
				same++;
			if (i == Gold)
				{base += can[j].Simi; bnum++;}
			if (i != Gold)
				{pele += can[j].Simi; pnum++;}
		}
	}
	if (pnum)
		pele /= pnum;
	if (bnum)
		base /= bnum;

	//estimation
	return 1024*(sure*same)/
							Pair + 
			 1024*(pele-base)/
					(pele+base);
}

/**************************************
		Print data to a file
**************************************/
/*
//	Print the pair of the nests

void	Coach::PrNest( char *str,char *tab,CNest *dst,CNest *src )
{
	FILE *f = fopen( str,"w" );
	if (f == NULL) return;
	CNest	*wrk;
	char	*swi;

	for (int n = 0; n < 2; n++)
	{
		if (n) {wrk = dst; swi = tab;}
		else	 {wrk = src; swi = TabNot;}

		if (swi == TabNot)	fprintf( f,"\nNOT    " );
		if (swi == TabEcr)	fprintf( f,"\nECR    " );
		if (swi == TabEcl)	fprintf( f,"\nECL    " );
		if (swi == TabBbr)	fprintf( f,"\nBBR    " );
		if (swi == TabBbl)	fprintf( f,"\nBBL    " );
		if (swi == TabBcr)	fprintf( f,"\nBCR    " );
		if (swi == TabBcl)	fprintf( f,"\nBCL    " );
		if (swi == TabEsr)	fprintf( f,"\nESR    " );
		if (swi == TabEsl)	fprintf( f,"\nESL    " );
		
		fprintf( f,"Nord=%3d,  Type=%1d,  Lace=%3d,  Beta=%3d,   Harm=%3d,\n",
						wrk->Nord, wrk->Type, wrk->Lace, wrk->Beta*2,wrk->Harm );

		for (int i = 0,n,j; i < wrk->Wnet; i++)
		{
			if ((n = swi[i]) < 0)
			{
				fprintf( f,"broken\n" ); continue;
			}
			fprintf( f,"%2d-%2d:",n,i );
			fprintf( f,"  D:");
			for (j = 0; j < _VIR_; j++) 
				if (wrk->Deal[j][n]) fprintf( f,"%1x,", wrk->Deal[j][n] );
				else						fprintf( f," ,");
			fprintf( f,"  I:");
			for (j = 0; j < _VIR_; j++) 
				if (wrk->Item[j][n])	fprintf( f,"%3d,", wrk->Item[j][n] );
				else						fprintf( f,"   ,");
			fprintf( f,"  S:");
			for (j = 0; j < _VIR_; j++) 
				if (wrk->Size[j][n])	fprintf( f,"%3d,", wrk->Size[j][n] );
				else						fprintf( f,"   ,");
			fprintf( f,"  P:");
			for (j = 0; j < _VIR_; j++) 
				if (wrk->Pink[j][n])	fprintf( f,"%1d,", wrk->Pink[j][n] );
				else						fprintf( f," ,");
			fprintf( f,"  U:");
			for (j = 0; j < _VIR_; j++) 
				if (wrk->Tree[j][n] && wrk->Tree[j][n]->Prox)	
											fprintf( f,"%1d,", wrk->Tree[j][n]->Prox );
				else						fprintf( f," ,");
			fprintf( f,"  F:");
			for (j = 0; j < _VIR_; j++) 
				if (wrk->Fine[j][n])	fprintf( f,"%3d,", wrk->Fine[j][n] );
				else						fprintf( f,"   ,");
			fprintf( f,"\n" );
		}
	}
	fclose( f );
}


//	Store klowledges
void	Coach::PrTune( char *str,word *buf )
{
	FILE *f;

	//try open the file
	if ((f = fopen( str,"w" )) != NULL)
	{
		//write data from buffer
		for (int i = 0; i < 256;)
		{
			fprintf( f,"\n");//ok
			//build data of group
			for (int j = 0; j < 16; j++,i++)
			{
				fprintf( f,"%3d,",buf[i] );
			}
		}
		//close all
		fclose( f );
	}
}

//	Print list of candidates
void	Coach::PrList( char *str )
{
	FILE *f;//print percent from original list
	double q = 100.0*Head/(Test.Nmin*Icon.Nmin);
	char	name[100];

	//rename special name
	int i = 0;
	for (; str[i]; i++)
		name[i] = str[i];
		name[i] =     0;
		name[i-5] =  'L';

	//try open the file
	if ((f = fopen( name,"w" )) != NULL)
	{
		double e = 0;
		double r = 0;
		//prints the all active list
		for (int j = 0; j < Head;)
		{
			int num = Cand[j].CapI->Nord ;

			//prints the list of candidate
			for (; j < Head && Cand[j].CapI->Nord == num; j++)
			{
				e += ATrust( Cand[j].CapT->Nord,num );//model
			}
		}
		r = 100.0*e/Pair;
		e = 100.0*e/Head;
		fprintf( f,"\nIcon > test  Glabal:%2.2f where natives:%2.2f Recognized:%2.2f ",q,e,r );

		//prints the all active list
		for (int i = 0; i < Head;)
		{
			int num = Cand[i].CapI->Nord ;
			fprintf( f,"\n%3d have",num );

			//prints the list of candidate
			for (; i < Head && Cand[i].CapI->Nord == num; i++)
			{
				fprintf( f,"\n     %3d",Cand[i].CapT->Nord);
				if (ATrust( Cand[i].CapT->Nord,num ))//model
				{
					fprintf( f,"*" );
				}
			}
		}
		//close all
		fclose( f );
	}
}

//	Print path document
void	Coach::PrPath( char *str )
{
	FILE *f;
	char	name[100];

	//rename special name
	int i = 0;
	for (; str[i]; i++)
		name[i] = str[i];
		name[i] =     0 ;
		name[i-5] =  'P';

	//try open the file
	if ((f = fopen( name,"w" )) != NULL)
	{
		//default interior
		fprintf( f,"Hori = %d  Lays = %d  Gold = %d\n",Hori,Lays,Gold );

		//look over all dukes
		for (int i = 0; i < Lays; i++)
		{
			Graph *src = &Duke[i]; int val = 0;		//set the base duke
			fprintf( f,"\nDuke %d, head=%d, format s-d\n",i,src->Head );

			//look over the path
			for (int j = 0; j < src->Head; j++)
			{
				fprintf( f,"%3d-%3d, Q:%4d,",	src->Cand[j].CapI->Nord,
														src->Cand[j].CapT->Nord,
														src->Cand[j].Simi );
				fprintf( f,"  :%2x",(src->Free[ src->Cand[j].CapI->Nord]&0x0f) +
										  (src->Free[ src->Cand[j].CapT->Nord]&0xf0));

				if (ATrust( src->Cand[j].CapT->Nord,src->Cand[j].CapI->Nord ))
				{
					fprintf( f," *" ); val++;
				}
					fprintf( f,"\n" );
			}
			fprintf( f,"			native %d, mark %d, recognized %2.2f\n",val,View[i],100.0*val/Pair );
		}
		//close all
		fclose( f );
	}
}
*/
/**************************************
			Mentors for searching
**************************************/

//	Resets mentor
void	Coach::Resets( void )
{
	for (int i = 0; i < PARAM; i++)
	{
		for (int j = 0; j < PSIZE; j++)
		{
			Rank[i][j] = 0;
		}
	}
}
/*
//	Expres mentor
void	Coach::Expres( char *str )
{
	//initialize tutor
	short	  qual =  0,
			  rval =  0;
	word	  best[256];
	
	//stores original parameter
	StrCop( best,TabDat,0xff );

	//from minimum of tolerance
	for (TabDat[0] = 15; TabDat[0] < 20; TabDat[0] += 1)
	{	
		for (TabDat[1] = 27; TabDat[1] < 40; TabDat[1] += 1)
		{
			for (TabDat[2] = 27; TabDat[2] < 40; TabDat[2] += 1)
			{
				//carry out work
				if(!CKnow::Expres( )) 
					return;	//skip

				//up reliability
				if ((rval= ATrust( Cand,Head )) > qual)

				{
					StrCop( best,TabDat,0xff );
					qual	= rval ;
					PrList( str );
				}
			}
		}
	}

	//store parameters
	PrTune( str,best );
	Rank[ 0][best[ 0]] += 2;
	Rank[ 1][best[ 1]] += 2;
	Rank[ 2][best[ 2]] += 2;
}

//	Reduce tutor
void	Coach::Reduce( char *str )
{
	//initialize tutor
	word	best[256];

	//stores original parameter
	StrCop( best,TabDat,0xff );

	//try any iteration
	for (int rval,qual = -9999,i = TRAIN; i > 0; i--)
	{
		Disp = 16;	
		//stores original parameter
		//TabDat[Disp+ 0] = best[Disp+ 0];
		//TabDat[Disp+ 6] = best[Disp+ 6];
		//TabDat[Disp+ 7] = best[Disp+ 7];
		//TabDat[Disp+11] = best[Disp+11];

		//change a table
//		Random( Disp+ 0,i*20 );
//		Random( Disp+ 6,i*20 );
//		Random( Disp+ 7,i*60 );
//		Random( Disp+11,i*60 );

		//carry out the work
		if(CKnow::Expres( ))
			CKnow::Reduce( );
		else
			return;	 //skip

		//estimate function reliability
		if ((rval= Voting(4)) >= qual)
		{
			StrCop( best,TabDat,0xff );
			qual	= rval ;
			PrList( str );
		}
	}

	//set best parameters
	PrTune( str,best );
	Rank[ 0][best[Disp+ 0]] += 2;
	Rank[ 1][best[Disp+ 6]] += 2;
	Rank[ 2][best[Disp+ 7]] += 2;
	Rank[ 3][best[Disp+11]] += 2;
}

//	Source tutor
void	Coach::Source( char *str )
{
	//initialize tutor
	word	  best[256];

	//stores original parameter
	StrCop( best,TabDat,0xff );

	Disp = 48;
	CKnow::Source();
	PrList( str );
return;
	//Cand[Head = 0].Simi = -1;
	//ExNest( &Test.Nest[38],&Icon.Nest[4],&Cand[Head] );
	//ExNest( TabNot,&Test.Nest[44],&Icon.Nest[4],&Cand[Head] );
	//PrNest( "e:\\tmp\\4.44",TabNot,&Test.Nest[44],&Icon.Nest[4] );
	//Cand[Head = 0].Simi = -1;
	//ExNest( TabEcl,&Test.Nest[38],&Icon.Nest[4],&Cand[Head] );
	//PrNest( "e:\\tmp\\4.38",TabEcl,&Test.Nest[38],&Icon.Nest[4] );
//return;
	//try any iteration
	for (int rval,qual = -9999,i = TRAIN; i > 0; i--)
	{
		Disp = 48;

		//change a table
		Random( TabDat,best,Disp+ 0,i*100 );
		//Random( TabDat,best,Disp+ 2,i* 20 );
		Random( TabDat,best,Disp+ 3,i*100 );
		Random( TabDat,best,Disp+ 8,i*100 );
		Random( TabDat,best,Disp+ 9,i*100 );
		Random( TabDat,best,Disp+10,i*100 );
		//Random( TabDat,best,Disp+18,i* 20 );
		Random( TabDat,best,Disp+19,i*100 );
		//Random( TabDat,best,Disp+24,i* 50 );
		Random( TabDat,best,Disp+25,i*100 );

		//carry out work
		CKnow::Source();

		//estimate function reliability
		if((rval = Voting(4)) > qual)
		{
			StrCop( best,TabDat,0xff );
			qual	= rval ;
			PrList( str );
		}
	}


	//set best parameters
	PrTune( str,best );
//	Rank[ 0][best[Disp+ 0]] += 2;
//	Rank[ 1][best[Disp+ 6]] += 2;
//	Rank[ 2][best[Disp+ 7]] += 2;
//	Rank[ 3][best[Disp+11]] += 2;
}

//	Tender tutor
void	Coach::Tender( char *str )
{
	//initialize tutor
	short	  qual =  0,
			  rval =  0;
	word	  best[256];																		  

	//stores original parameter
	StrCop( best,TabDat,0xff );

	//from minimum of tolerance
	for (TabDat[31] = 64,qual = 0; TabDat[31] > 0; TabDat[31]--)
	{	
		//carry out the work
		if(CKnow::Expres( ))
		{
			CKnow::Reduce( );
		}
		//up reliability
		if ((rval= ATrust( Cand,Head )) > qual)
		{
			StrCop( best,TabDat,0xff );
			qual	= rval ;
			PrList( str );
		}
	}

	//store parameters
	Rank[ 0][best[31]] += 2;
	PrTune( str,best );

}

//	Growth tutor
void	Coach::Growth( char *str )
{
	//initialize tutor
	word	  best[256];

	//stores original parameter
	StrCop( best,TabDat,0xff );

	//preparing the work
	if(CKnow::Expres())
		CKnow::Reduce();
	else
		CKnow::Source();

	//candidates..
	PrList( str );

	//carry out works
	CKnow::Gusher( );
	CKnow::Growth( );
	PrPath( str  );
return;

	//try any iteration
	for (int rval,qual = -9999,i = TRAIN; i > 0; i--)
	{

		//change a table
//		Random(  48,i*10  );
//		Random(  55,i*40  );
//		Random(  59,i*40  );
//		Random(  62,i*60  );

		//carry out works
		CKnow::Gusher( );
		CKnow::Growth( );

		//estimate <fun> reliability
		if ((rval = QuPath(1)) > qual)
		{
			StrCop( best,TabDat,0xff );
			qual	= rval ;
			PrPath( str  );
		}
	}

	//set best parameters
	PrTune( str,best );
	Rank[ 0][best[48]] += 2;
	Rank[ 1][best[55]] += 2;
	Rank[ 2][best[62]] += 2;
	Rank[ 3][best[59]] += 2;
}
*/
int	Coach::Method( int some )
{
	//preparing the work
	if(CKnow::Expres())
	{
		CKnow::Reduce();
//		return Voting(2);
	}
	else
		CKnow::Source();
//		return Voting(3);

	//carry out works
	CKnow::Gusher( );
	CKnow::Growth( );

	//get reliability
	//return QuPath(1);//one to one
	return QuPath(0);//one to all
	//return 0;
}
/*
#include <stdio.h>
#include <string.h>
//#include <io.h>
#include <fcntl.h>
#include <time.h>

void	Coach::Tutor( char *out,char *str )
{
	int result =  0;
	//initialize tutor
	StrCop( Data,TabDat,0xff );
	int len = 0;
	for (; str[len] != '*'; len++); 

	//try any iteration
	for (int expr = TRAIN; expr > 1; expr--)
	{
		int quality = 0;
		struct _finddata_t c_file;
		int hfile;
		char fname[80];

		for (int i = 0; fname[i] = str[i]; i++);

		 // Find first .c file in current directory
		if( (hfile = _findfirst( fname,&c_file )) == -1L )
			return;
		do
		{
			int fh;
			int bytesread;
			char buffer[6000];

			fname[len  ] = 0 ;
			fname[len-2] ='L';
			strcat( fname,c_file.name );

			// Open file for input
			if( (fh = _open( fname, _O_RDONLY | _O_BINARY )) == -1 )
				return;
			// Read in input 
			if( ( bytesread = _read( fh,buffer,c_file.size ) ) <= 0 )
				return;
			else
			{
				try			{Icon.Loader( (byte*)buffer );}
				catch( ... ){return;}
			}
			_close( fh );

			fname[len] = fname[len-2] ='F';
			_findfirst( fname,&c_file );
			// Open file for input
			if( (fh = _open( fname, _O_RDONLY | _O_BINARY )) == -1 )
				return;
			// Read in input 
			if( ( bytesread = _read( fh,buffer,c_file.size ) ) <= 0 )
				return;
			else
			{
				try	{Test.Loader( (byte*)buffer );}
				catch( ... ){return;}
			}
			_close( fh );

			fname[len] = fname[len-2] ='M';
			_findfirst( fname,&c_file );
			if( (fh = _open( fname, _O_RDONLY | _O_BINARY )) == -1 )
				return;
			Killer();
			// Read in input 
			if( ( bytesread = _read( fh,Line,c_file.size ) ) <= 0 )
				return;
			_close( fh );
			
			if (Parser() == 0)
			{
				return;
			}

			///////////////////////
			quality += Method(1);
			////////////////////////
		}
		// Find the rest of the .c files 
		while( _findnext( hfile, &c_file ) == 0 );

		_findclose( hfile );

		//estimate function reliability
		if(quality > result)
		{
			StrCop( Data,TabDat,0xff );
			result = quality;
		}

		//////////////////////////
		Random( expr );
		//////////////////////////
	}

	//set best parameters
	PrTune( out,Data );
}


void	Coach::Scaner( char *out,char *dst,char *src,char *mod )
{
	int result =  -1;
	//stores original parameter
	StrCop( Data,TabDat,0xff );
	int len = 0;
	for (; src[len] != '*'; len++); 

	//try any iteration
	for (int expr = TRAIN; expr > 0; expr -= 10)
	{
		struct _finddata_t s_file,
								 d_file,
								 m_file;
		int	shandle,
				dhandle;
		int	quality = 0,
				fh,
				bytesread;
		char	buffer[6000],
				sname[80],
				dname[80],
				mname[80];
		int	same = 0,
				snum = 0,
				pele = 0,
				pnum = 0;

		int i = 0;
		for (; sname[i] = src[i]; i++);

		 // find first source in directory
		if( (shandle = _findfirst( sname,&s_file )) == -1L )
			return;
		do
		{
			sname[len] = 0; strcat( sname,s_file.name );

			// Open file for input
			if( (fh = _open( sname, _O_RDONLY | _O_BINARY )) == -1 )
				return;
			// Read in input 
			if( ( bytesread = _read( fh,buffer,s_file.size ) ) <= 0 )
				return;

			_close( fh );
			try	
				{Icon.Loader( (byte*)buffer );}
			catch( ... )
				{return;}

			for (i = 0; mname[i] = mod[i]; i++);
			s_file.name[0] = 'M';
			mname[len] = 0; strcat( mname,s_file.name );

			_findfirst( mname,&m_file );
			if( (fh = _open( mname, _O_RDONLY | _O_BINARY )) == -1 )
				return;
			Killer();
			// Read in input 
			if( ( bytesread = _read( fh,Line,m_file.size ) ) <= 0 )
				return;
			_close( fh );
			if (Parser() == 0)
				return;


			for (i = 0; dname[i] = dst[i]; i++);

			 // find first source in directory
			if( (dhandle = _findfirst( dname,&d_file )) == -1L )
				return;
			do
			{
				dname[len] = 0; strcat( dname,d_file.name );

				// Open file for input
				if( (fh = _open( dname, _O_RDONLY | _O_BINARY )) == -1 )
					return;
				// Read in input 
				if( ( bytesread = _read( fh,buffer,d_file.size ) ) <= 0 )
					return;
				_close( fh );
				try	
					{Test.Loader( (byte*)buffer );}
				catch( ... )
					{return;}
				///////////////////////
				int temp = Method(1);
				if (Sstreq( d_file.name+1,s_file.name+1 ))
				{
					same += temp;	snum++;
				}
				else
				{
					pele += temp;	pnum++;
				}
				////////////////////////
			}
	  		//Find the rest of the .c files
			while( _findnext( dhandle, &d_file ) == 0 );

			_findclose( dhandle );
		}
		//Find the rest of the .c files
		while( _findnext( shandle, &s_file ) == 0 );

		_findclose( shandle );

		if(pnum) 
			pele /= pnum;
		if(same) 
			same /= snum;
		//estimation
		quality =	1024*(pele-same)/
							  (same+pele);

		//estimate reliability
		if(quality < result || result == -1)
		{
			StrCop( Data,TabDat,0xff );
			result = quality;
		}
		//////////////////////////
		Random( expr );
		//////////////////////////
	}

	//set best parameters
	PrTune( out,Data );
}
*/


#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
