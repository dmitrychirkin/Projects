/**************************************
				Source.cpp
	Generate images by micro gradient.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"mathem73.h"
#include		"sorter73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local tune constants
//-------------------------------------
static  const 
int	Clevel =  H0;					//native level

/**************************************
		Tune in source procedures
**************************************/

//	Tune red-green-blue palette
void	Charm::Charms( int dsth,int srch )
{
	//is gray image ?
	if(HuSa!= COLOUR)
		Swoo = GetLay( PALL_B,srch );		//blue palette
	else
	{
		Swoo = GetLay( PALL_B,srch );		//blue palette
		Smoo = GetLay( PALL_G,srch );		//green palette
		Seio = GetLay( PALL_R,srch );		//red palette
	}
}

//	Tune wizard
void	Charm::SoTune( int dsth,int srch )
{
		Srco = GetLay(	SOURCE,srch );		//source image
}

//-------------------------------------
//	Destroy comunications
//-------------------------------------
template <class T>
static void destroysource( T *p )
{
	//do nothing
}

/**************************************
			Kernal functions		
**************************************/

//	Build colored source
void	Charm::SoBows( void )
{
	//use gray image ?
	if (HuSa!= COLOUR)
		*Swoo = LIM( Brgb[*Srco] );
	else
	{
		*Swoo = LIM( Brgb[*Srco] );
		*Smoo = LIM( Grgb[*Srco] );
		*Seio = LIM( Rrgb[*Srco] );
	}
}

//	Build negative image
void	Charm::SoNega( void ) 
{
	*Srco = BM - *Srco;//+-
}

//	Build mirror image
void	Charm::SoMirr( void ) 
{
	//for left surface
	if (Srcx < Reax/2)
	{
		swap( *Srco,*( Srco+Reax-2*Srcx ));
	}
}

/**************************************
		Assemble <Source> function
**************************************/
void	Codex::Source( int magn,int subl )
{
	//the contrast and brightness law
	int low[] = {2, 85,85, 170,170};

	//verify dimensions
	magn = LIA( magn );
	subl = LIA( subl );

	//tune in procedure
	Tops =	  SOUrce	;
	Eche =	  Clevel	;

	//tree ?
	if(Root)
	{
		//lighting-darkening..
		low[1] += (subl-64)*3
								 /2;
		low[3] += (subl-64)*3
								 /2;

		//standard contrasting
		low[1] += (magn-64)/2;
		low[3] -= (magn-64)/2;
		
		//tune operator orders
		LorMod(low);LorSmo(1);

		//tune colour poligons
		PolHue(   Lord,OHue,
							OLum );

		//build colored source
		Docvie = (tvii)&Charm::SoTune;
		Docvic = (tvii)&Charm::Charms;
		Docisi =	(tv_v)&Charm::SoBows;
		Scener	(Eche)		;
	}
}

/**************************************
		Assemble <Invert> function
**************************************/
void	Codex::Invert( void )
{
	//sink ?
	if(Root)
		Root->Invert();//ok

	//tunes in start queue
	OldLay( Tops=RELoad );
	WiRect( Eche=Clevel,
							0 );

	//build image negative
	Docvie = (tvii)&Charm::SoTune;
	Docisi = (tv_v)&Charm::SoNega;
	Scener	(Eche)		;

	//destroy a local link
	destroysource( this );
}

/**************************************
		Assemble <Mirror> function
**************************************/
void	Codex::Mirror( void )
{
	//sink ?
	if(Root)
		Root->Mirror();//ok

	//tunes in start queue
	OldLay( Tops=RELoad );
	WiRect( Eche=Clevel,
							0 );

	//build image - mirror
	Docvie = (tvii)&Charm::SoTune;
	Docisi = (tv_v)&Charm::SoMirr;
	Scener	(Eche)		;

	//destroy a local link
	destroysource( this );
}


#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
