/**************************************
				Parser.cpp
		Translate the knowledges.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"search73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

/**************************************
			Check character
**************************************/

//	Verify allowed digit
static inline int blank( char c )
{
	return	0x20 == c || c == 0x09 ||
				0x0a == c || c == 0x0d;
}

//	Veryfy allowed character
static inline int alpha( char c )
{
	return	0x61 <= c && c <= 0x7a ||
				0x41 <= c && c <= 0x5a ||
				'_'  == c;
}

//	Verify allowed digit
static inline int numeric( char c )
{
	return	0x30 <= c && c <= 0x39;
}

//	Varify allowed digit and character
static inline int an( char c )
{
	return	alpha(c) || numeric(c);
}

/**************************************
			Get character
**************************************/

//	Get character
char	Coach::ThisCh( void )	
{
	return Line[Lptr];
}

//	Get character and advance
char	Coach::NextCh( void )
{
	return ThisCh() ? Line[Lptr++] : 0;
}

/**************************************
	Intellectual string processing
**************************************/

//	Skip blanks
void	Coach::Blanks( void )
{
	while (blank( ThisCh())) NextCh();
}

//	May be lines equal ?
int	Coach::Sstreq( char *dst,char *src )
{
	//look throw the string
	int i = 0;
	for (; src[i]; i++)
	{
		if (dst[i] != src[i]) 
			return 0;
	}
			return i;
}

//	May be lines equal on a dot ?
int	Coach::Astreq( char *dst,char *src )
{
	//look throw the string
	int i = 0;
	for (; i < 16; i++)
	{
		if (src[i] != dst[i])break;
		if (src[i] == 0)		break;
		if (dst[i] == 0)		break;
	}
		if (an(src[i]))	return 0;
		if (an(dst[i]))	return 0;
								return i;
}

//	Compare and skip it if without fail
int	Coach::Smatch( char *src )
{
	//skiping
	Blanks();
	int	 k;

	//proove the string
	if ((k = Sstreq( Line+Lptr,src )) != 0)
	{
		Lptr += k;
		return  1;
	}
		//unknown
		return 0;
}

//	Compare and skip it on a dot if without fail
int	Coach::Amatch( char *src )
{
	//skiping
	Blanks();
	int	 k;

	//proove the string
	if ((k = Astreq( Line+Lptr,src )) != 0)
	{
		Lptr += k;
		return  1;
	}
		//unknown
		return 0;
}
 
//	Read digit number
int	Coach::Number( void )
{
	int	value = 0,
			minus = 0;

	//privious set
	if (Smatch("+")) minus = 0;
	if (Smatch("-")) minus = 1;

	//read numeric
	while (numeric( ThisCh()))
	{
		value = value*10 + NextCh() - '0';
	}
	//up the sign
	return minus ? -value : value;
}

/**************************************
			Assemble translator
**************************************/

//	Prepare to translate
void	Coach::Killer( void )
{
	for (int i = 0; i < LLINE; i++) Line[i] = 0;
}

//	Translate knowledges
int	Coach::Parser( void )
{
	//resets
	Pair = 0;
	Lptr = 0;

	//verify a start of data
	if (Amatch( "begin") == 0)		
		return 0;

	//untill the end for data
	while (Amatch("end") == 0)
	{
		//if src begins...
		if (Amatch("src") != 0)
		{
			//parse a model syntax
			if (Smatch( "=" ) == 0)	
				return 0;
			//read minutiae number
			Inum[Pair]  = Number();
			//parse a model syntax
			if (Smatch( "," ) == 0)	
				return 0;
			if (Smatch("dst") == 0)	
				return 0;
			if (Smatch( "=" ) == 0)	
				return 0;
			//read minutiae number
			Tnum[Pair]  = Number();
			//parse a model syntax
			if (Smatch( ";" ) == 0)	
				return 0;
			Pair++; //ok
		}
		//if dst begins...
		if (Amatch("dst") != 0)
		{
			//parse a model syntax
			if (Smatch( "=" ) == 0)	
				return 0;
			//read minutiae number
			Tnum[Pair]  = Number();
			//parse a model syntax
			if (Smatch( "," ) == 0)	
				return 0;
			if (Smatch("src") == 0)	
				return 0;
			if (Smatch( "=" ) == 0)	
				return 0;
			//read minutiae number
			Inum[Pair]  = Number();
			//parse a model syntax
			if (Smatch( ";" ) == 0)	
				return 0;
			Pair++; //ok
		}
	}

	//success
	return 1;
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
