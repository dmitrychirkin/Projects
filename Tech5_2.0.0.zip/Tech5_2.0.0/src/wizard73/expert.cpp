/**************************************
				Expert.cpp
			 Build hierarchy 
		qiality & density fields.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"wizard73.h"
#include		"wibase73.h"


#ifdef SAVE_LAYERS
   bool openLog();
   void closeLog();
   void writeLog(char* s);
#endif



#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local enumerated type
//-------------------------------------
enum 
{
	_QUA_E = TEMP_T,
	_DEN_M
};

//-------------------------------------
//	Local tune constants
//-------------------------------------
static  //const
int	C_tune[] = {11,15,12},		//gradient-harmon balance
				Clevel	=	H3;				//native level

/**************************************
		Tune Expert procedure
**************************************/

//	Tune skeleton for future
void	CWork::ExSkel( int dsth,int srch )
{
	Srco = GetLay(	REFINE,srch );			//skeleton
	Shpo = GetLay(	SKELET,srch );			//skeleton
	Snxo = GetLay(	DIFFER,srch );			//difference
	Sexo = GetLay(	PROPHE,srch );			//prophecy
}

//	Tune kernal of expert
void	CWork::ExKern( int dsth,int srch )
{
	Srco = GetLay(	PROB_H,srch );			//harmon probability
	Shpo = GetLay(	CONC_H,srch );			//harmon concordance
	Snxo = GetLay(	CONC_G,srch );			//gradient concordance
	Swoo = GetLay(	DENSIT,dsth );			//density
	Dwoo = GetLay(	_DEN_M,dsth );			//minutiae density
	Dmoo = GetLay(	_QUA_E,dsth );			//quality
}

//	Tune professional findings
void	CWork::ExDeep( int dsth,int srch )
{
	Dsto = GetLay(	QUAL_E,dsth );			//quality
	Dhpo = GetLay(	QUAL_M,dsth );			//minutiae quality
	Dexo = GetLay(	DENS_M,dsth );			//minutiae density
	Dwoo = GetLay(	_DEN_M,dsth );			//minutiae density
	Dmoo = GetLay(	_QUA_E,dsth );			//quality
	Deio = GetLay(	FLOW_E,dsth );			//expert flow

	//skip source tuning if limit
	if (srch < Reih)		return ;

	Swoo = GetLay(	_DEN_M,srch );			//minutiae density
	Smoo = GetLay(	_QUA_E,srch );			//quality
}

//-------------------------------------
//	Destroy comunications
//-------------------------------------
template <class T>
static void destroyexpert( T *p )
{
	p->DelLay( _QUA_E,p->Eche );
	p->DelLay( _DEN_M,p->Eche );
}

/**************************************
			Virtual functions
**************************************/

//	Prepare skeleton lay
void	CWork::ExSkelV( void ) 
{
	//set a gap
	*Srco =
	*Shpo = BM;
	*Snxo =
	*Sexo = BA;
}

//	Measure harmon contrast
void	CWork::ExPrep( void )
{
	++Rank[*Srco];
}

//	Calculate kernal data
void CWork::ExKernV( void )
{
	//build module of the spectrum impulse
	int val = Rank[LIM( *Srco*BM/Hypo )]*Hypo/BM;

	//weighted probability and concordance
	int ang = LIH( DIP( *Snxo*C_tune[0] + *Shpo*C_tune[1], C_tune[2]));

	//formula to calculate pattern quality
	*Dmoo = LIM( cosm( val,ang )/2 + BA );	

	//formula to build density of manutiae
	*Dwoo = HP*(*Swoo - (quick? HL_Q : HL));
}

//	Immerse data into pyramid
void	CWork::ExFilt( void )
{
	//active echelon
	if (Eche > Reih)
	{
		*Smoo = *Dsto;
		*Swoo = *Dexo;
	}
}

//-------------------------------------
//		Virtual upper functions
//-------------------------------------

//Expert inner filter
void CWork::get_cogm_temp(void)
{
	//base impulse scheme
	int i = 0;
	for(int flow = 0; flow < AH; flow += 15)
	{
		cogm_temp_I[i][0] = cogm_temp_I[i][4] = cogm(32, cone(00, flow));
		cogm_temp_I[i][1] = cogm_temp_I[i][5] = cogm(32, cone(AQ, flow));
		cogm_temp_I[i][2] = cogm_temp_I[i][6] = cogm(32, cone(AR, flow));
		cogm_temp_I[i][3] = cogm_temp_I[i][7] = cogm(32, cone(AW, flow));
		cogm_temp_I[i][8] = 32; //pocket

		//base impulse weight
		cogm_div_I[i] = (cogm_temp_I[i][0] + cogm_temp_I[i][1] + 
			cogm_temp_I[i][2] + cogm_temp_I[i][3] + cogm_temp_I[i][4] +
            cogm_temp_I[i][5] + cogm_temp_I[i][6] + cogm_temp_I[i][7] + 
			cogm_temp_I[i][8]);
		i++;
	}
}
int CWork::Fiimpo_I(int *inf, int div)
{
	int fun[9];
	fun[0] = inf[0] * neighbors_I[0];
	fun[1] = inf[1] * neighbors_I[1];
	fun[2] = inf[2] * neighbors_I[2];
	fun[3] = inf[3] * neighbors_I[3];
	fun[4] = inf[4] * neighbors_I[4];
	fun[5] = inf[5] * neighbors_I[5];
	fun[6] = inf[6] * neighbors_I[6];
	fun[7] = inf[7] * neighbors_I[7];
	fun[8] = inf[8] * neighbors_I[8];
	return DIP( fun[0] + fun[1] + fun[2] + fun[3] + fun[4] + fun[5] +
				fun[6] + fun[7] + fun[8], div);
}

int	CWork::ExImpi( void )
{	
	//try impulse direction
	FiRead(neighbors_I, Dmoo, 0);	
	//for(Args = 0,*Dsto = BM; Args < AH; Args += 15)
	*Dsto = BM;
	for(int i = 0; i < 12; i++)
	{
		//up minimum quality
		if(*Dsto > (Bask = Fiimpo_I(cogm_temp_I[i], cogm_div_I[i]) ))
			 *Dsto =  Bask;
	}
	//set minutiaes quality
	*Dhpo = MAX(*Dsto - BA)*QH/ BA;
	//set minutiaes density
	*Dexo = Fiimpp( Dwoo );
	return 1;
}

//	Expert outward filter
int	CWork::ExImpo( void )
{	
	//reduce border quality
	*Dsto = PER(*Dmoo - BA,
							  84)
							+ BA;
	//set minutiaes quality
	*Dhpo = MAX(*Dsto - BA)
						   * QH
						   / BA;
	//set minutiaes density
	*Dexo =  *Dwoo;
					  return 1;
}

/**************************************
			 Build hierarchy 
		qiality & density fields.
**************************************/
void Codex::Expert(int reih)
{
	//laws to amplifier the probability
	int low[] = {3, 9,0, 60,90, BM,BM};
   if (quick)
   {
      C_tune[0] = 11;
      C_tune[1] = 10;
      C_tune[2] = 13;
   }
   else
   {
      C_tune[0] = 11;
      C_tune[1] = 15;
      C_tune[2] = 12;
   }

	//if concordance wasn't build
	if (GetKey(CONC_H, Clevel) == -1)
	{
		//previous works
		Harmon(HarmoN);
	}

	//tune in expert queue
	OldLay(Tops = EXPert);
	Reih = (reih);
	WiRect(Eche = Clevel, 0);

	//prepare skeleton lay
	Srco = GetLay(REFINE, H0); //skeleton
	Shpo = GetLay(SKELET, H0); //skeleton
	Snxo = GetLay(DIFFER, H0); //difference
	Sexo = GetLay(PROPHE, H0); //prophecy
	memset(Srco, BM, Size[H0]); memset(Shpo, BM, Size[H0]);
	memset(Snxo, BA, Size[H0]); memset(Sexo, BA, Size[H0]);

	//RanIni(0); //histogram
	memset(Rank, 0, sizeof(Rank));

	//a gradient procedure
	Srco = GetLay(PROB_H, Eche);//harmon probability
	for(int i = 0; i < Size[Eche]; i++)
	{
		++Rank[*Srco]; Srco++;
	}

	//get a histogram part
	Hypo = RanSha(2) +  1;

	//builds amplitude low
	RanMod(low);RanSmo(7);

	//setup new data field
	Docvie = (tvii)&CWork::ExKern;
	Docisi = (tv_v)&CWork::ExKernV;
	Scener(Eche);
#ifdef SAVE_LAYERS
    saveLayer("expert_DENSIT_1st.dat", DENSIT, 3);
    saveLayer("expert__DEN_M_1st.dat", _DEN_M, 3);
    saveLayer("expert__QUA_E_1st.dat", _QUA_E, 3);

    saveLayer("expert_QUAL_E_1st.dat", QUAL_E, 3);
    saveLayer("expert_QUAL_M_1st.dat", QUAL_M, 3);
    saveLayer("expert_DENS_M_1st.dat", DENS_M, 3);
    saveLayer("expert__DEN_M_1st.dat", _DEN_M, 3);
    saveLayer("expert_FLOW_E_1st.dat", FLOW_E, 3);


    saveLayer("expert_QUAL_E_2_1st.dat", QUAL_E, 2);
    saveLayer("expert_QUAL_M_2_1st.dat", QUAL_M, 2);
    saveLayer("expert_DENS_M_2_1st.dat", DENS_M, 2);
    saveLayer("expert__DEN_M_2_1st.dat", _DEN_M, 2);
    saveLayer("expert__QUA_E_2_1st.dat", _QUA_E, 2);
    saveLayer("expert_FLOW_E_2_1st.dat", FLOW_E, 2);

    saveLayer("expert_QUAL_E_1_1st.dat", QUAL_E, 1);
    saveLayer("expert_QUAL_M_1_1st.dat", QUAL_M, 1);
    saveLayer("expert_DENS_M_1_1st.dat", DENS_M, 1);
    saveLayer("expert__DEN_M_1_1st.dat", _DEN_M, 1);
    saveLayer("expert__QUA_E_1_1st.dat", _QUA_E, 1);
    saveLayer("expert_FLOW_E_1_1st.dat", FLOW_E, 1);
//    g_writeLog = true;
#endif

	//build  expert chart
	//get_cogm_temp();
	for (Eche = Clevel; Eche >= Reih; Eche--)
	{
		//hierarchy projection
		Docvie = (tvii)&CWork::ExDeep;
		Docupi = (ti_v)&CWork::ExImpi;
		Docupo = (ti_v)&CWork::ExImpo;
		Docisi =
		Dociso = (tv_v)&CWork::ExFilt;
		Scenei(0,Eche,Eche-1);
	}

#ifdef SAVE_LAYERS
    g_writeLog = false;
    saveLayer("expert_DENSIT.dat", DENSIT, 3);
    saveLayer("expert__DEN_M.dat", _DEN_M, 3);
    saveLayer("expert__QUA_E.dat", _QUA_E, 3);

    saveLayer("expert_QUAL_E.dat", QUAL_E, 3);
    saveLayer("expert_QUAL_M.dat", QUAL_M, 3);
    saveLayer("expert_DENS_M.dat", DENS_M, 3);
    saveLayer("expert__DEN_M.dat", _DEN_M, 3);
    saveLayer("expert_FLOW_E.dat", FLOW_E, 3);


    saveLayer("expert_QUAL_E_2.dat", QUAL_E, 2);
    saveLayer("expert_QUAL_M_2.dat", QUAL_M, 2);
    saveLayer("expert_DENS_M_2.dat", DENS_M, 2);
    saveLayer("expert__DEN_M_2.dat", _DEN_M, 2);
    saveLayer("expert__QUA_E_2.dat", _QUA_E, 2);
    saveLayer("expert_FLOW_E_2.dat", FLOW_E, 2);

    saveLayer("expert_QUAL_E_1.dat", QUAL_E, 1);
    saveLayer("expert_QUAL_M_1.dat", QUAL_M, 1);
    saveLayer("expert_DENS_M_1.dat", DENS_M, 1);
    saveLayer("expert__DEN_M_1.dat", _DEN_M, 1);
    saveLayer("expert__QUA_E_1.dat", _QUA_E, 1);
    saveLayer("expert_FLOW_E_1.dat", FLOW_E, 1);
#endif
   //destroy temporary links
	for (Eche = Clevel; Eche >= reih; Eche--)
	{
		//destroy a local link
		destroyexpert( this );
	}
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
