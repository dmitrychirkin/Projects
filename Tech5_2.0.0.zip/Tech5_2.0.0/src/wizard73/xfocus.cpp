/**************************************
				Xfocus.cpp
	Define more precisely focuses.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"assert.h"
#include		"mathem73.h"
#include		"moulds73.h"
#include		"sorter73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local definitions
//-------------------------------------

//	Lay's definition
enum
{
	_TWIS_ =	TEMP_T
};

//	Constants to rename
enum
{
	FAR_DD =	36,								//delta-delta
	FAR_WW = 48,								//whorl-whorl
	FAR_WL = 36,								//whorl-loop
	FAR_DL = 10,								//delta-loop
	FAR_LL = 40,									//loop-loop

	FAR_DD_Q = 28,								//delta-delta - quick processing
	FAR_WW_Q = 35,								//whorl-whorl - quick processing
	FAR_WL_Q = 27,								//whorl-loop - quick processing
	FAR_DL_Q = 7,								//delta-loop - quick processing
	FAR_LL_Q = 30								//loop-loop - quick processing
};

//-------------------------------------
//	Local tune constants
//-------------------------------------
static  const int	
   Cbound	 =   3,				//loop merging
	Clevel	 =  H3,				//level
	Ctwist	 =	 4,				//minimum twist
	Cprove	 =  50,				//gradient weight
	C_door	 =  60,				//threshold
	C_goon	 =  56,				//more design
	C_comp	 =  64,				//compactness
	Cwhirl	 =   4,				//spiral

	C_door_Q	 =  30,				//threshold
	C_goon_Q	 =  66,				//more design
	C_comp_Q	 =  74;				//compactness

/**************************************
 Tune to define position more accurate
**************************************/
void	CWork::XfTune( int dsth,int srch )
{
	Srco = GetLay( FLOW_M,srch  );		//flow
	Shpo = GetLay( QUAL_S,srch  );		//quality
   Snxo = GetLay( FCLASS,srch  );		//fclass
	Sexo = GetLay( ARCH_D,srch  );		//curve
	Sfno = GetLay(	MATH_I,srch  );		//index
	Swoo = GetLay(	_TWIS_,srch  );		//twist
	Smoo = GetLay( FLOW_F,srch  );		//alpha
	Seio = GetLay( PROB_G,srch  );		//gradient probability
}

//-------------------------------------
//	Destroy comunications 
//-------------------------------------
template <class T>
static void destroyxfocus( T *p )
{
	p->DelLay( _TWIS_,p->Eche );
	p->DelLay( PROB_V,p->Eche );
	p->DelLay( PROB_M,p->Eche );
	p->DelLay( PROB_G,p->Eche );
	p->DelLay( FLOW_M,p->Eche );
	p->DelLay( FLOW_V,p->Eche );
	p->DelLay( FLOW_F,p->Eche );
	p->DelLay( FCLASS,p->Eche );
	p->DelLay( QUAL_S,p->Eche );
	p->DelLay( ARCH_D,p->Eche );
	p->DelLay( GOAL_S,p->Eche );
	p->DelLay( MATH_I,p->Eche );
}

/**************************************
				Gap functions
**************************************/

//	Check base focuses
static inline	int ifturn( byte *p )
{
	return *p == FD ||
			 *p == FL ||
			 *p == FW;
}

//	Check focus area
static inline	int ifarea( byte *p )
{
	return *p == FS ||
			 ifturn(p);
}

/**************************************
		Reset all indignations
**************************************/
static inline void permit( SSign * p )
{
	//reset type & trust
	for (int i = 0; i < _GEN_; i++)
	{
		p[i].Type = FN;
		p[i].Lace =
		p[i].Prob =	00;
	}
}

/**************************************
		Simple inline functions
**************************************/

//	Select more reliability
static inline void select( SSign &a,SSign &b )
{
	//more reliability
	if (a.Prob > b.Prob)
		 b.Prob = 0;
	else
		 a.Prob = 0;
}

//	Set middle trustable focus
static inline void middle( SSign &a,SSign &b )
{
	b.Type = FW;
	b.Movx = EVE( a.Movx,b.Movx );
	b.Movy = EVE( a.Movy,b.Movy );
	b.Prob = MAX( a.Prob,b.Prob );
	a.Prob = 0 ;
}

//	Sort while renaming
static inline	int rename( SSign &a,SSign &b )
{
	return a.Prob > b.Prob;
}

/**************************************
			Rename indignations
**************************************/

//	Rename areas
void	CWork::Rename( int pos,int type )
{
	int	di[_GEN_];//distance
	int	in[_GEN_];//index...

	//measure focuses disposition
	for (int i = 0; i < Hypo; i++)
	{
		//if base focus's type
		if (Indi[i].Type & FF)
			di[in[i] = i] = Tdists( Indi[pos],Indi[i] );
		else
			di[in[i] = i] = 99999;
	}

	//sort indignation by metric
	isortM( in,di,more,Hypo -1 );

	//FD - analysis
	if (type == FD)
	{
      if (di[1] < (quick ? FAR_DD_Q : FAR_DD) && Indi[in[1]].Type == FD)
		{
			Case++; select( Indi[in[0]],Indi[in[1]] );
		}
	}
	//FW - analysis
	if (type == FW)
	{
      if (di[1] < (quick ? FAR_WW_Q : FAR_WW) && Indi[in[1]].Type == FW)
		{
			Case++; middle( Indi[in[0]],Indi[in[1]] );
		}
		else
         if (di[1] < (quick ? FAR_WL_Q : FAR_WL) && Indi[in[1]].Type == FL)
		{
			Case++; select( Indi[in[1]],Indi[in[1]] );
		}
	}
	//FL - analysis
	if (type == FL)
	{
		if (di[1] < (quick ? FAR_DL_Q : FAR_DL) && Indi[in[1]].Type == FD)
		{
			Case++; select( Indi[in[0]],Indi[in[0]] );
					  select( Indi[in[1]],Indi[in[1]] );
		}

		else//rename two far loops
         if (di[1] < (quick ? FAR_LL_Q : FAR_LL) && Indi[in[1]].Type == FL)
		{
			//get far loops metric
			int beta = MIN( ABS( Tcompl( Indi[in[0]],
												  Indi[in[1]] )),
								 ABS( Tcompl( Indi[in[1]],
												  Indi[in[0]] )));

			//classify two loops for probability merging
         if (di[1] <= (quick ? FAR_LL_Q : FAR_LL)  - sqri( Cbound*beta ))
			{
				Case++; middle( Indi[in[0]],Indi[in[1]] );
			}
		}
	}

	//compress indignation list
	isort( Indi,rename,Hypo-1 ); while (!Indi[Hypo-1].Prob) 
															Hypo--;
}
	
//	Rename some focuses
void	CWork::Rename( void )
{
	//repeat while success
	do
	{
		//do stop
		Case = 0;

		//look over all focuses
		for (int i = 0; i < Hypo-1 && !Case; i++)
		{
			//for special type
			switch (Indi[i].Type)
			{
				case FW:	Rename( i,FW ); break;
				case FL:	Rename( i,FL ); break;
				case FD:	Rename( i,FD ); break;
				default: /*  nothing  */ break;
			}
		}
	}
	while (Case);
}

/**************************************
			Proove indignations
**************************************/

//	Prognoze absent loop into loop pattern
static inline int _loop_( SSign &dea,SSign &deb,SSign &src )
{
	//loop-delta pattern statistic: 75 degree
	int delta = 75 - ABS( Tcompl( dea,src ));
	return	 MAX( cosm( src.Prob,delta*2 ));
}

//	Prognoze absent delta for loop pattern
static inline int delta_( SSign &dea,SSign &deb,SSign &src )
{
	//loop-delta pattern statistic: 75 degree
	int delta = 75 - ABS( Tcompl( src,dea ));
	return	 MAX( cosm( src.Prob,delta*2 ));
}

//	Prognoze absent whole into whole pattern
static inline int whole_( SSign &dea,SSign &deb,SSign &src )
{
	//delta-delta image statistic: 100 degree
	int delta = 100-coor( Tdirec( dea,src ),
								 Tdirec( deb,src ));
	return	 MAX( cogm( src.Prob,delta*1 ));
}

//	Prognoze absent delta into whole pattern
static inline int compl_( SSign &dea,SSign &deb,SSign &src )
{
	//delta-delta image statistic: 100 degree
	int delta =	100-coor( Tdirec( deb,dea ),
								 Tdirec( src,dea ));
	return	 MAX( cogm( src.Prob,delta*1 ));
}

//	Prognoze probability absent focuses
template <class P>
static int doscan( P comp,SSign src[],int hypo,int prob,int type,int a,int b )
{
	//select alone more probability focuses
	int next = -1;
	for (int i = 0,p; i < hypo; i++)
	{
		if ((src[i].Type & 0x80) == 0x00)
			continue;
		if ((src[i].Type & 0x7f) == type)
		{
			//try to prove pattern's type
			if(prob < (p = comp( src[a],src[b],src[i] )))
			{
				prob =  p;

				next =  i;
			}
		}
	}

	//have success
	if (next != -1)
	{
		//delete veil from focus
		src[next].Type &= ~0x80;
		return 1;
	}
	return 0;
}	

//-------------------------------------
//	Pick up proved focuses and store
//-------------------------------------
void	CWork::XfIndiV( void )
{
	//probability of indignations
	int i = 0;
	for (i = 0; i < Hypo; i++)
	{
		//do local link
		Basket(		 );
		DoMami(		 );
		ProLay( CCLASS,Indi[i].Movx,
							Indi[i].Movy,Eche,H0 );
		DoLink(&Hoff );
		ProLay( PROB_G,Indi[i].Movx,
							Indi[i].Movy,Eche,H0 );

		//get area data
		Spiral( Eche,
				  Clas );

		//set parameter
		Indi[i].Lace = LIM( Thre*Imax
										/Seat );
		Indi[i].Prob = LIM( Bask/Team );
	}

	//local data
	int prob = 0,
		 type = 0;

	//recalc focus probability 
	for (i = 0; i < Hypo; i++)
	{
		Indi[i].Prob = (Indi[i].Lace*(255-Cprove)+
							 Indi[i].Prob*Cprove )/255;

		//get maximum probability
		if (prob < 	Indi[i].Prob)
			 prob = 	Indi[i].Prob;
	}

	//compress indignation list
	isort( Indi,rename,Hypo-1 );

	//select trustable focuses
	for (i = 0; i < Hypo; i++)
	{
		//progress design ?
		if (!type)
		{
			if (Indi[i].Prob < PER(Thre, quick ? C_goon_Q : C_goon))
				 Indi[i].Type |= 0x80;
		}
		else
         if (Indi[i].Prob < PER(prob, quick ? C_comp_Q : C_comp))
				 Indi[i].Type |= 0x80;

			//untrustable ?
		if (prob         < PER(Thre, quick ? C_door_Q : C_door))
				 Indi[i].Type |= 0x80;

		//check image safe

		switch (Indi[i].Type)
		{
			case FW: type += 2; break;
			case FL: type += 1; break;
			case FD: type -= 1; break;
		}
	}

	//for fingerprint
	if (Cont == 'F')
	{
		int sign;

		do
		{
			sign = 0;

			//get number of any focus type
			int loops = Tcubic( Indi,Hypo,FL );
			int whole = Tcubic( Indi,Hypo,FW );
			int delta = Tcubic( Indi,Hypo,FD );

		 	//prognosis one loop if we have one delta
			if (delta == 1 && loops == 0 && whole == 0)
			{
            sign = doscan( _loop_, Indi,Hypo,prob/(quick ? 6 : 4),FL,
									Torder( Indi,Hypo,FD,0 ),
									Torder( Indi,Hypo,FD,0 ));
			}
			else//prognosis a delta if we have one loop
			if (delta == 0 && loops == 1 && whole == 0)
			{
				sign = doscan( delta_, Indi,Hypo,prob/(quick ? 6 : 4),FD,
									Torder( Indi,Hypo,FL,0 ),
									Torder( Indi,Hypo,FL,0 ));
			}
			else//prognosis whole if we have two deltas
			if (delta == 2 && loops == 0 && whole == 0)
			{
				sign = doscan( whole_, Indi,Hypo,prob/8,FW,
									Torder( Indi,Hypo,FD,0 ),
									Torder( Indi,Hypo,FD,1 ));
			}
			else//prognosis one delta for whole pattern
			if (delta == 1 && loops == 0 && whole == 1)
			{
				sign = doscan( compl_, Indi,Hypo,prob/4,FD,
									Torder( Indi,Hypo,FW,0 ),
									Torder( Indi,Hypo,FD,0 ));
			}
			else//prognosis one delta for whole pattern
			if (delta == 1 && loops == 2 && whole == 0)
			{
				sign = doscan( compl_, Indi,Hypo,prob/4,FD,
									Torder( Indi,Hypo,FL,0 ),
									Torder( Indi,Hypo,FD,0 ));
			}
			else//prognosis only loop for whole pattern
			if (delta == 2 && loops == 1 && whole == 0)
			{
				sign = doscan( whole_, Indi,Hypo,prob/4,FL,
									Torder( Indi,Hypo,FD,0 ),
									Torder( Indi,Hypo,FD,1 ));
			}
		}
		while (sign);
	}

	//copy prooved indignations
	for (int j = 0; j < Hypo && Nind < NFOCUS; j++)
	{
		//if any exist focus
		switch (Indi[j].Type)
		{
			case FW:
			case FL:
			case FD: Indi[j].Prob =
						Indi[j].Prob * QH	/ BM;
						Indi[Nind++] = Indi[j];
		}
	}
}

/**************************************
	Complicative cluster processing
**************************************/

//	Enlarge area of focus
void	CWork::XfWide( int flow,int step )
{
	//if area absent
	if(*Movo == FN)
		 *Movo =  FS;
}

//	Collect focus area data
void	CWork::XfIndi( int flow,int step )
{
	//collect probability!
	Bask += *Movo;	Team++;

	//collect prooved flow
	if(*Hoff & CG)	Imax++;
}

/**************************************
		Virtual upper functions
**************************************/

//	Enlarge the focus areas
void CWork::XfWideV( void )
{
	//have indignation?
	if(ifturn(Snxo))
	{
		DoMove(&Snxo);
		Spiral( Eche, Clas);
	}
	//do minimum twist
	*Swoo  =  Ctwist ;
}
//	Rebuild focus curvature 
void CWork::XfCurv( void )
{
	//if focus areas
	//if(ifarea(Snxo))
	if(*Snxo)
	{
		//measure flows
		Joff = Shpo;
		//DoMove(&Srco );
		//DoKeep(&Useo );
		Useo = Movo = Srco;
		Usex = Movx = Srcx;
		Usey = Movy = Srcy;
		Re_v[0] = Re_v[4] = 0;
		Im_v[0] = Im_v[4] = 0;
		
		Spiral( Eche, Clas );		
		if(Re_v[0] || Im_v[0])
			Flow[0] = atan(Re_v[0], Im_v[0])/2;
		else
			Flow[0] = *Useo;
		if(Re_v[4] || Im_v[4])
			Flow[4] = atan(Re_v[4], Im_v[4])/2;
		else
			Flow[4] = *Useo;
		Tcurve(Flow, Sexo, Useo);
	}
}
//	Measure twist of curve
void CWork::XfTwis( void )
{
	//if focus areas
	if (ifturn( Snxo ))
	{
		//measure twist
		DoMove(&Sexo );	DoKeep(&Useo );
		Treset( Tw_v );//	Treset( Quan );
		Area = 0;
		Spiral( Eche, Clas );
		//Tlevel( Tw_v, Quan );

		//rotated twist
		int min_value = MIN(Min4(Tw_v[0], Tw_v[1], Tw_v[2], Tw_v[3]),
						Min4(Tw_v[4], Tw_v[5], Tw_v[6], Tw_v[7]));
		*Swoo += min_value/Area; //save _TWIS_
	}
}
//	Select the best position
void	CWork::XfBest( void )
{
	//have indignation?
	if (ifturn( Snxo ))
	{
		int i = *Sfno;

		//indignation trustable
		if(Indi[i].Prob > *Swoo || i >= _GEN_)
			return;

		Indi[i].Movx = DipPyr( Srcx,H0,Eche );
		Indi[i].Movy = DipPyr( Srcy,H0,Eche );
		Indi[i].Prob = *Swoo;
		Indi[i].Type = *Snxo;
		Indi[i].Beta = *Smoo;

		//next focus's quantity
		Hypo = MAX( Hypo,i+1 );
	}
}

//	Enlarge the focus areas
void	CWork::XfTrue( void )
{
	++Rank[ *Seio ];
}

/**************************************
		Assemble <Xfocus> function
**************************************/
void Codex::Xfocus( int reih )
{
	//lows to modify angle parameters..
	int ang[] = {4, 0,0, 20,13, 45,45, AR, 8};

	//if stream quality was not built
	if(GetKey( QUAL_S,Clevel ) == -1)
	{
		Respon( RespoN ); //previous works
	}

	//tune in xfocus queue
	OldLay( Tops=XFOcus );
	Clas = Cwhirl;
	Cont = ImType;
	Nind = 0;
	Hypo = 0;

   if (integ)
   {
	   WiRect(Eche=reih, 0);
	   //reset indignations..
	   permit(Indi);
	   //probability polygons
	   RanIni(0);

	   //transform corner low
	   CorGau(ang);CorSmo(1);
   //	for(int i = 0; i < SCORN; i++)
   //		{Corn[i] *= 2;}

   	//enlarge focuses area 
	   Docvie = (tvii)&CWork::XfTune;
	   Docisi = (tv_v)&CWork::XfWideV;
	   Docexe = (tvii)&CWork::XfWide;
	   Scener(Eche);

	   //builds curve of flow 
	   Docvie = (tvii)&CWork::XfTune;
	   Docisi = (tv_v)&CWork::XfCurv;
      Docexe = (tvii)&CWork::Argums_I;
	   Scener(Eche);

      //builds twist of flow
	   Docvie = (tvii)&CWork::XfTune;
	   Docisi = (tv_v)&CWork::XfTwis;
	   Docexe = (tvii)&CWork::Twists_I;
	   Scener(Eche);

	   //select best position
	   Docvie = (tvii)&CWork::XfTune;
	   Docisi = (tv_v)&CWork::XfBest;
	   Scener(Eche);

	   //set native hierarchy
	   WiRect(Eche=Clevel,0);

	   //poligons probability
	   Docvie = (tvii)&CWork::XfTune;
	   Docisi = (tv_v)&CWork::XfTrue;
	   Scenei(2, Eche, Eche);

	   //calculates threshold
	   Thre = RanSha(16);

   	//renames general data
   	Rename(); //glue focus

	   //prove&prognose focus
	   Docexe = (tvii)&CWork::XfIndi;
	   XfIndiV();

   	//measure general data
      Centre(Thre*QH/BM);
	   Design();
   }


   //clear hierarchy link
   for(Eche = Clevel; Eche >= reih; Eche--)
   {
	   //destroy a local link
	   destroyxfocus( this );
   }

}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
