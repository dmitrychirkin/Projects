/**************************************
				Lights.cpp
   Build lights and shades of image.

			Author Gudkov V.U.
**************************************/

//	Header files
#include		"mathem73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local tune constants
//-------------------------------------
const		
static int	Clevel	= H0;					//level

/************************************** 
		Tune metallic sunlight
**************************************/
void	CWork::LiTune( int dsth,int srch )
{
	Srco = GetLay(	SOURCE  ,srch );		//source image
	Shpo = GetLay(	NORMAL  ,srch );		//normal image
	Dsto = GetLay(	LIGHTS+0,dsth );		//c-sunlight
	Dhpo = GetLay(	LIGHTS+1,dsth );		//d-sunlight
	Dnxo = GetLay(	LIGHTS+2,dsth );		//e-sunlight
	Dexo = GetLay(	LIGHTS+3,dsth );		//f-sunlight
}

/************************************** 
		Kernal subfunctions
**************************************/

//	Smoothing - it is important
void	CWork::LiNorm( void ) 
{
   if (quick)
   	*Shpo = Fiimpw( Srco );
   else
   	*Shpo = Fiimpr( Srco );
	
}

//	Smoothing - copy image
void	CWork::LiCopy( void )
{
	*Shpo = *Srco;//a copy;
}
//	Collect base histogram
void	CWork::LiRank( void )
{
	//accelerator
	if (Srcx & 1 & Srcy)
	{
		++Rank[ ABS( Fisunc( Shpo )>>2 )];
		++Rank[ ABS( Fisund( Shpo )>>2 )];
		++Rank[ ABS( Fisune( Shpo )>>2 )];
		++Rank[ ABS( Fisunf( Shpo )>>2 )];
	}
}

//	Quick light up image
void	CWork::LiSuns( void )
{
	int cdir = (Fisunc( Shpo ) << 5) /
										  Rlim;
	int ddir = (Fisund( Shpo ) << 5) /
										  Rlim;
	int edir = (Fisune( Shpo ) << 5) /
										  Rlim;
	int fdir = (Fisunf( Shpo ) << 5) /
										  Rlim;

	cdir = Rank[ LIM( cdir+BA )] - BA;
	ddir = Rank[ LIM( ddir+BA )] - BA;
	edir = Rank[ LIM( edir+BA )] - BA;
	fdir = Rank[ LIM( fdir+BA )] - BA;

	*Dsto	= (cdir*Lord[Rlim]>>8) + BA;
	*Dhpo	= (ddir*Lord[Rlim]>>8) + BA;
	*Dnxo	= (edir*Lord[Rlim]>>8) + BA;
	*Dexo	= (fdir*Lord[Rlim]>>8) + BA;
}

//	No light - only gray
void	CWork::LiGray( void )
{
	*Dsto =
	*Dhpo =
	*Dnxo =
	*Dexo = BA;
}

/**************************************
		Assembly <Lightf> function
**************************************/
void CWork::LiCalSuns(void)
{
	short *p_Fisuna, *p_Fisunb, *p_Fisunc, *p_Fisund;
	//Indx = MaxX[H0];
	Redx = MaxX[H0]; Redy = MaxY[H0];
	p_Fisuna = I_Fisuna + Redx;	p_Fisunb = I_Fisunb + Redx;
	p_Fisunc = I_Fisunc + Redx;	p_Fisund = I_Fisund + Redx;	
	Shpo += Redx;
	Incx = Redx+1; Decx = Redx-1; Reax = Redx;
	for(Srcy = 1; Srcy < Redy-1; Srcy++)
	{
		//*p_Fisuna = 0; *p_Fisunb = 0; *p_Fisunc = 0; *p_Fisund = 0;
		p_Fisuna++; p_Fisunb++; p_Fisunc++; p_Fisund++; Shpo++;
		for(Srcx = 1; Srcx < Redx-1; Srcx++)
		{
            //*p_Fisuna = Fisuna(Shpo); *p_Fisunb = Fisunb(Shpo); 
			*p_Fisuna = Fisune(Shpo); *p_Fisunb = Fisunf(Shpo); 
			*p_Fisunc = Fisunc(Shpo); *p_Fisund = Fisund(Shpo);
			if( (Srcx & 1) && (Srcy & 1) ) 
			{
				++Rank[ABS((*p_Fisunc) >> 2)]; ++Rank[ ABS((*p_Fisund) >> 2)];
				++Rank[ABS((*p_Fisuna) >> 2)]; ++Rank[ ABS((*p_Fisunb) >> 2)];
				//++Rank[ABS((-(*p_Fisuna)) >> 2)]; ++Rank[ ABS((-(*p_Fisunb)) >> 2)];
			}
			p_Fisuna++; p_Fisunb++; p_Fisunc++; p_Fisund++; Shpo++;
		}
		//*p_Fisuna = BA; *p_Fisunb = BA; *p_Fisunc = BA; *p_Fisund = BA;
		p_Fisuna++; p_Fisunb++; p_Fisunc++; p_Fisund++; Shpo++;
	}
}
void CWork::LiSaveSuns(void)
{
	short *p_Fisuna, *p_Fisunb, *p_Fisunc, *p_Fisund;
	//Indx = MaxX[H0];
	Redx = MaxX[H0]; Redy = MaxY[H0];
	p_Fisuna = I_Fisuna + Redx;	p_Fisunb = I_Fisunb + Redx;
	p_Fisunc = I_Fisunc + Redx;	p_Fisund = I_Fisund + Redx;
	memset(Dsto, BA, Redx); memset(Dhpo, BA, Redx);
	memset(Dnxo, BA, Redx); memset(Dexo, BA, Redx);
	Dsto += Redx; Dhpo += Redx; Dnxo += Redx; Dexo += Redx;

	for(Srcy = 1; Srcy < Redy-1; Srcy++)
	{
		*Dsto = BA; *Dhpo = BA; *Dnxo = BA; *Dexo = BA;
		p_Fisuna++; p_Fisunb++; p_Fisunc++; p_Fisund++;
		Dsto++; Dhpo++; Dnxo++; Dexo++;
		for(Srcx = 1; Srcx < Redx-1; Srcx++)
		{
			int cdir = (*p_Fisunc << 5)/Rlim;
			int ddir = (*p_Fisund << 5)/Rlim;
			int edir = ((*p_Fisuna) << 5)/Rlim;
			int fdir = ((*p_Fisunb) << 5)/Rlim;
			cdir = Rank[LIM(cdir + BA)];// - BA;
			ddir = Rank[LIM(ddir + BA)];// - BA;
			edir = Rank[LIM(edir + BA)];// - BA;
			fdir = Rank[LIM(fdir + BA)];// - BA;
			*Dsto = (cdir*Lord[Rlim]>>8) + BA;
			*Dhpo = (ddir*Lord[Rlim]>>8) + BA;
			*Dnxo = (edir*Lord[Rlim]>>8) + BA;
			*Dexo = (fdir*Lord[Rlim]>>8) + BA;

			p_Fisuna++; p_Fisunb++; p_Fisunc++; p_Fisund++;
			Dsto++; Dhpo++; Dnxo++; Dexo++;
		}
		*Dsto = BA; *Dhpo = BA; *Dnxo = BA; *Dexo = BA;
		p_Fisuna++; p_Fisunb++; p_Fisunc++; p_Fisund++;
		Dsto++; Dhpo++; Dnxo++; Dexo++;
	}
	memset(Dsto, BA, Redx); memset(Dhpo, BA, Redx);
	memset(Dnxo, BA, Redx); memset(Dexo, BA, Redx);
}
void Codex::Lightf( int reih )
{
	//laws to amplifier sunlight power 
	int sun[] = {3, 0,0, 32,16, BA,BA};

	//if source image absent - out
	if(GetKey(SOURCE, H0) == -1)
	{
		//exception	handling
		throw What = UNTIED;
	}             
	//tune in furiew queue
	OldLay(Tops = LIGhtf),
	Eche = Clevel;
   //verify real normalized image
	if(GetKey( NORMAL,H0 ) == -1)
	{
		//set filtered pattern
		Docvie = (tvii)&CWork::LiTune;
		Docisi = (tv_v)&CWork::LiNorm;
		Dociso = (tv_v)&CWork::LiCopy;
		Scenei( 2,Eche,Eche );
	}
	memset(Rank, 0, sizeof(Rank));

	//measures a histogram
	Shpo = GetLay(NORMAL, Eche); //normal image
	LiCalSuns();

	RanEnd(7);//find end
	RanGau(sun); RanSmo(4);
	LorLog();//contrast
   if(Rlim < 1) Rlim = 1;
	for(int i = 0; i < SRANK; i++)
	{
		Rank[i] -= BA;
	}

	//build filter pattern
	Dsto = GetLay(LIGHTS+0, Eche);	//c-sunlight
	Dhpo = GetLay(LIGHTS+1, Eche);	//d-sunlight
	Dnxo = GetLay(LIGHTS+2, Eche);	//e-sunlight
	Dexo = GetLay(LIGHTS+3, Eche);	//f-sunlight
	LiSaveSuns();

#ifdef SAVE_LAYERS
   saveLayer("lights_LIGHTS_0.dat", LIGHTS+0, 0);
   saveLayer("lights_LIGHTS_1.dat", LIGHTS+1, 0);
   saveLayer("lights_LIGHTS_2.dat", LIGHTS+2, 0);
   saveLayer("lights_LIGHTS_3.dat", LIGHTS+3, 0);
#endif
}
/**************************************
		Assembly <Lights> function
**************************************/

void Codex::Lights( int reih )
{
	//laws to amplifier sunlight power 
	int sun[] = {3, 0,0, 32,16, BA,BA};

	//if local flow absent
	if (GetKey( FLOW_L,H3 ) == -1)
	{
		//previous works
		Xfocus( XfocuS );
	}

	//tune in furiew queue
	OldLay( Tops=LIGhts ),
			  Eche=Clevel  ;
	//verify real normalized image
	if (GetKey( NORMAL,H0 ) == -1)
	{
		//set filtered pattern
		Docvie = (tvii)&CWork::LiTune;
		Docisi = (tv_v)&CWork::LiNorm;
		Dociso = (tv_v)&CWork::LiCopy;
		Scenei( 2,Eche,Eche );
	}
	RanIni( 0 ); //prepare

	//measures a histogram
	Docvie = (tvii)&CWork::LiTune;
	Docisi = (tv_v)&CWork::LiRank;
	Scenei( 2,Eche,Eche );

	RanEnd( 7 );//find end
	RanGau(sun);RanSmo(4);
	LorLog(   );//contrast
   if(Rlim < 1) Rlim = 1;

	//build filter pattern
	Docvie = (tvii)&CWork::LiTune;
	Docisi = (tv_v)&CWork::LiSuns;
	Dociso = (tv_v)&CWork::LiGray;
	Scenei( 2,Eche,Eche );


}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
