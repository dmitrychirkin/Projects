/**************************************
				Linker.cpp
	  Extract links for minutiaes.

			Author Gudkov V.U.
**************************************/

//	Header project file
//#include		"assert.h"
//#include		"mathem73.h"
#include		"moulds73.h"
#include		"packed73.h"
//#include		"sorter73.h"
#include		"wizard73.h"
#include		"wibase73.h"


#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */


//-------------------------------------
//	Local definitions
//-------------------------------------
enum
{
	_TEMP_ =	TEMP_T
};

//-------------------------------------
//	Local tune constants
//-------------------------------------
static const 
 int	Clevel =   H1,		//native level
		CAngle =    6,		//oscillate
		CAnmax =   48,		//limit
		C_tail =	9,		//tail length for order
		C_pink =	8,		//caution! 4..8
		Clinks = 9999;		//link size

/**************************************
			Tune communications
**************************************/
void	CWork::LiPrep( int dsth,int srch )
{
	Srco = GetLay(_TEMP_, srch);			//modulo N
	Shpo = GetLay(SKELET, srch);			//skelet
	Pack = GetLay(LISTpL, dsth);			//list of packed links
}

//-------------------------------------
//	Destroy comunications 
//-------------------------------------
template <class T>
static void destroylinker( T *p )
{
	p->DelLay( _TEMP_,H0	);
}

/**************************************
			Inline functions
**************************************/

//	Verify contrary of directions
static inline void cohere( int *orie,int *hypo )
{
	//contrary directions ?
	if (!simu( *orie,*hypo ))
	{
		*orie = reci( *orie );
	}
		//store new!
		*hypo = *orie;
}

//	Invert direction
static inline void invert( int *orie )
{
	*orie = reci( *orie );
}

/**************************************
			Helpfull functions
**************************************/

//	Read next base info
void	CWork::Lining( void )
{
	Harm = *ProRef( DENSIT, Movx, Movy, Eche, H0);
//	Area = *ProRef( FCLASS, Movx, Movy, Eche, H0);
	Orie = *ProRef( FLOW_E, Movx, Movy, Eche, H0);

}

//	Get rid of section
void	CWork::GetRid( void )
{
	//reset section
	for (int i = 0; i < Deep; i++)
	{
		//reset arms
		for (int j = 0; j < _ARM__; j++)
		{
			Link[i].Item[j] = -1;
			Link[i].Deal[j] = 
			Link[i].Pink[j] =  0;
		}
	}
}

/**************************************
  Sort minutiae to optimize capacity
**************************************/
void CWork::LiSort( void )
{
	int	sign[MAXPAL], tail[C_tail];
	int lens = 0;//C_tail;
	int nord = 0, pnum = 0;

	//reset the tail of the kernal
	for(int k = 0; k < C_tail; k++)
		tail[k] = 0;	

	//prepare some future frontier
	for(int l = 0; l < Nmin; l++)
		sign[l] =-1;
	sign[0] = 0;

	//sort it
	while (1)
	{
		//a trajectory
		int best = -1, next = 0;

		//select a next trajectory point 
		for(int j = 0, d; j < Nmin; j++)
		{
			//skip busy minutie 
			if (sign[j] !=  -1) continue;
			//measure kernal metric to select step
			int r = 10000; 
			for(int i = C_tail-lens,v; i < C_tail; i++)
			{
				v = Tdists(Sign[tail[i]], Sign[j]);
				//nearest lizard...
				if(r > v)//|| r < 0)
                    r = v;
			}
			d = Tdists(Sign[pnum], Sign[j]);

			//select a step based on a metric
			if(best > (d += r) || best < 0)
			{
				best = d; next = j;
			}
		}
		//if minutiae absent 
		if (best < 0) break;
	
		//renew the tail of the kernal
		int i;
		for(i = C_tail-lens+1; i < C_tail; i++)
			tail[i-1] = tail[i];
		tail[C_tail-1] = pnum;
		sign[pnum = next] = ++nord; 
		if(lens < C_tail) lens++;
	}

	//sort based on polar metric 
	bsort(Sign, sign, less, Nmin);
}
/**************************************
		Extract local morphology
**************************************/
void CWork::Lizard(int &idle, int *lows)
{
	//do morphology
	Morpho(Clinks);

	//investigate the all branches
	int i, beta, metr[_ARM__];
	for (i = 0; i < Narm; i++)
	{
		int	item = Arms[i].Item,
			deal = Arms[i].Deal,
			pink = Arms[i].Pink,
			linx = Arms[i].Movx,
			liny = Arms[i].Movy;
	
		//events
		if(deal)
		{
			//find nearest minutiae
			item = Native(linx, liny, item);
			//verifies section area
			pink  = pink <= Harm/3 + C_pink;
			//store a real minutiae
			Arms[i].Item  = item  ;
			//verifies section area
			Arms[i].Pink  = pink  ;
		}

		//parse event
		switch(deal)
		{
			case Ef:
			case E7:
			case Eb:
			case E3:	if (pink) idle |= 1;
			case E0:	Arms[i].Deal = deal;
						break;
			case E1:	//measure direction of the projection
						beta = atan(Sign[Arms[i].Item].Movx-Arms[i].Movx,
									Sign[Arms[i].Item].Movy-Arms[i].Movy);

						//define left and right local event..
						if (turn(Arms[i].Beta, beta) < 0 )
							//right event- 1
							Arms[i].Deal = 1;
						else//left event- 2
							Arms[i].Deal = 2;
						//defines contrary or phased minutiae
						if(!Tphase( Arms[i].Beta,Sign[item]))
							Arms[i].Deal |= 4;
						break;
						//unknown
		}
	}
	//do directions
	Orient( Harm );
	//arms turn to assignments
	for(i = 0; i < Narm; i++)
	{
		metr[i] = ABS( turn( Arms[i].Beta,Orie ));
	}
	//sort a metric
	bsort(Arms, metr, more, Narm);

	//turn clocwize up to base
	for (i = 0; i < Narm; i++)
	{
		metr[i] = cloc(Arms[i].Beta, Arms[0].Beta);
	}
	//sort a metric
	bsort(Arms, metr, less, Narm);

	//switch linkage in buffer
	for(i = 0; i < Narm; i++)
	{
		Link[lows[Nsec]].Deal[i] = Arms[i].Deal;
		Link[lows[Nsec]].Item[i] = Arms[i].Item;
		Link[lows[Nsec]].Pink[i] = Arms[i].Pink;
	}
}

/**************************************
	Shake ray to catch skeleton
**************************************/
int	CWork:: LiFind( int beta )
{
	//calculate survay for ray
	int lens = PER(Harm, 90);

	//increase a length of ray as far as possible
	for (int ends = lens<<1; lens < ends; lens++)
	{
		//oscillate left..right as far as possible
		for (int ang = 0,orie = beta; ABS(ang) <= CAnmax;)
		{
			//sets position
			//DoMove(&Helo );
			//DoLink(&Joff );
			Joff = Helo;
			//DoMove(&Loco );
			Movo = Loco; Movx = Locx; Movy = Locy;
			//find skeleton
			if(SkeSke(orie, cosm(lens, beta-orie)))
				return 1;
			//oscillate
			if(ang > 0)
				orie += (ang = -(ang + CAngle));
			else
				orie += (ang = -(ang - CAngle));
		}
	}

	//sorry !
	return 0;
}
/**************************************
			Set projections to link
**************************************/
void CWork::LiHand( void )
{
	//verify the list of minutiaes
	for(int i = 0; i < Nmin; i++)
	{
		int	linx = Sign[i].Movx, liny = Sign[i].Movy;
		int beta = Sign[i].Beta*2;

		//mounts modules then skeleton
		ProLay( _TEMP_,linx,liny,H0 );
		DoKeep(&Helo );
		ProLay( SKELET,linx,liny,H0 );
		DoKeep(&Loco );
		Lining();

		//survay for coloured skeleton
		Thre = decm(Harm, beta)/2 + 3;

		Joff = Helo; Movo = Loco;
		//hide skeleton
		*Joff = i & MO;		
		Colour(Thre);

		//catch the skeleton ?
		if(LiFind( beta+AR ))
		{
			*Movo = BP; *Joff = i&MO;
		}
		//catch the skeleton ?
		if(LiFind( beta-AR ))
		{
			*Movo =	BP; *Joff = i&MO;
		}

		//show skeleton
		DoMove(&Loco );
		Visual(Thre);

	}
}
/**************************************
			 Measure morphology 
			 for all minutiaes
**************************************/

//	Store linkages
void	CWork::LiSave( int type,int *deg )
{
	//a special local data
	int	d = MAXPAL,u = 0,
			i,	 //net
			j,	 //arm
			q;	 //quant

	//look section over the net
	for (i = 0; i < Deep;  i++)
	{
		//look section over the arm
		for (j = 0; j < _ARM__; j++)
		{
			//parse event & save
			if (Link[i].Deal[j])
			{
				//find low & high number
				if (d > Link[i].Item[j])
					 d = Link[i].Item[j];
				if (u < Link[i].Item[j])
					 u = Link[i].Item[j];

				//set event and the pink
				if((Link[i].Deal[j] & 3) == 3)
				{
					EnBits( Pack,&Nlin,&Nbit,Link[i].Deal[j],deg[0] );
					EnBits( Pack,&Nlin,&Nbit,Link[i].Pink[j],deg[3] );
				}
				else//set without a pink
					EnBits( Pack,&Nlin,&Nbit,Link[i].Deal[j],deg[1] );
			}
			else	//stores broken event
					EnBits( Pack,&Nlin,&Nbit,Link[i].Deal[j],deg[2] );

			//start
			if (!i)
			{
				if (type == BE)//a branch
					break;
				if (type == BB && j == 2)
					break;
			}		
			else
			if (j)break;
		}
	}

	//store low minutiae of the nest
	EnBits( Pack,&Nlin,&Nbit,d,deg[4] );
	
	//difference quant
	q = Quants( u-d );

	//store minutiae difference quant
	EnBits( Pack,&Nlin,&Nbit,q,deg[5] );

	//look section over the net
	for (i = 0; i < Deep; i++)
	{
		//look section over the arm
		for (j = 0; j < _ARM__; j++)
		{
			//parse event & save
			if (Link[i].Deal[j])
			{
				EnBits( Pack,&Nlin,&Nbit,Link[i].Item[j] - d,q );
			}
			//start
			if (!i)
			{
				if (type == BE)//a branch
					break;
				if (type == BB && j == 2)
					break;
			}		
			else
   		if (j)break;
		}
	}
}

//Build linkages
int	CWork::Linkup(void)
{
	//set conception for bit presentation
	int idle  = 0, lows[_NET_],	  
		 mask[]={4,3,2,1, Quants(Nmin), Quants(Quants(Nmin))};

	//set data
	 Nlin = 0; Nbit = 0; *lows = 0;

	//build hierarchy low for the section
	for(int r = 1,l = Twin; r < Twin;)
	{
		lows[l] = 2 * r; 
      l++;
      lows[r] = 2 * r - 1;
      r++;
	}

	//set conception for some bits 
	for(int j = 0; j < 0x06; j++)
	{
		EnBits(Pack,&Nlin,&Nbit,mask[j],4 );
	}

	//look over list of minutiaes
	for(int i = 0; i < Nmin; i++)
	{
		int	linx = Sign[i].Movx, liny = Sign[i].Movy, type = Sign[i].Type,
			beta = Sign[i].Beta*2;
		
		//mounts modules then skeleton
		ProLay( _TEMP_,linx,liny,H0 );
		DoKeep(&Helo);
		ProLay( SKELET,linx,liny,H0 );
		DoKeep(&Srco);

		//activate base
		//Active( linx, liny);
		Nact = i;

		//resets section
		GetRid();Nsec=0;

		//base position
		//DoMove(&Helo);
		//DoLink(&Joff);
		Joff = Helo;
		DoMove(&Srco);
		DoKeep(&Loco);
		Lining( );
		Orie=Hypo=beta;

		//base linkages
		Lizard(idle, lows);
		Colour(Harm);

		//get a section
		for (Nsec = 0001,idle = 0; Nsec < Twin && !idle; Nsec++)
		{
			//catch skeleton right
			if (LiFind(Hypo + AR))
			{
				//set previous!
				DoMove(&Loco );
				Visual(Harm);
				//next position
				DoMove(&Useo);
				DoKeep(&Loco);
				Joff = ProRef( _TEMP_,Movx,Movy,H0 );
				Lining();
				cohere( &Orie, &Hypo);
				invert( &Orie);
				//wing linkages
				Lizard(idle, lows);
				Colour(Harm);
			}
			else
				break;
		}

		//set previous!
		DoMove(&Loco);
		Visual(Harm);
		
		//base position
		//DoMove(&Helo);
		//DoLink(&Joff);
		Joff = Helo;
		DoMove(&Srco);
		DoKeep(&Loco);
		Lining();
		Orie=Hypo=beta;

		//hide skeleton		
		Colour(Harm);

		//get a section
		for(Nsec = Twin,idle = 0; Nsec < Deep && !idle; Nsec++)
		{
			//catch sceleton left
			if (LiFind( Hypo-AR ))
			{
				//set previous! 
				DoMove(&Loco);
				Visual(Harm);
				//next position
				DoMove(&Useo);
				DoKeep(&Loco);
				Joff =  ProRef(_TEMP_, Movx, Movy, H0);
				Lining();
				cohere(&Orie, &Hypo);
				//wing linkages
				Lizard(idle, lows);
				Colour(Harm);
			}
			else
				break;
		}

		//set previous! 
		DoMove(&Loco);
		Visual(Harm);

		//save linkages
		LiSave(type, mask);
	}

	//make even the active length
	return Nbit ? Nlin +1 : Nlin;
}
/**************************************
			Kernal preparing
**************************************/
/**************************************
			Extract linkages
**************************************/
void Codex::Linker( int reih )
{
	//if minutiaes weren't extracted
	if(GetKey( LIST_M,Clevel ) == -1)
	{		
		Minuti( MinutI ); //previous works
	}
	//tune in linker queue
	OldLay(Tops = LINker ),
	Eche = Clevel;
	Deep = TipNet;
	Twin = Deep/2+1;

	//optimize point order
	LiSort(); //sets order

	Srco = GetLay(_TEMP_, H0);
	memset(Srco, BM, Size[H0]);

	//something projection	
	LiHand(); //left-right

	//build the morphology
	Pack = GetLay(LISTpL, Eche);
	Docmin = (ti_i)&CWork::NativeI;
	PLinks = Linkup();

	//destroy a local link
	destroylinker( this );
}
/**************************************
		 Get detailed reference 
		to links of one minutiae
**************************************/

//	Parse one nest of next minutiae
int	Codex::Parser( int *deg,int type )
{
	int	lim,j; //local data

	//calculate depth of nest
	if(type == BE)	
		lim	=	Deep*2	- 1;
	else				
		lim	=	Deep*2	+ 1;

	//look section over a net
	for (j = 0; j < lim; j++)
	{
		//resets next link
		Nest.Deal[j]  =
		Nest.Pink[j]  =
		Nest.Item[j]  = 0;

		//read event from buffer
		if ((Nest.Deal[j]  = DeBits (Pack,&Nlin,&Nbit,deg[2])))
		{
			//if nothing projections
			if(Nest.Deal[j] == 3)
			{
				Nest.Deal[j] += DeBits( Pack,&Nlin,&Nbit,deg[2] ) << 2;
				Nest.Pink[j]  = DeBits( Pack,&Nlin,&Nbit,deg[3] );
			}
			else
				Nest.Deal[j] += DeBits( Pack,&Nlin,&Nbit,deg[3] ) << 2;
		}
	}

	//gets low number in the nest & quants
	int d = DeBits( Pack,&Nlin,&Nbit,deg[4] ),
		 q = DeBits( Pack,&Nlin,&Nbit,deg[5] );

	//look section over a net
	for (j = 0; j < lim; j++)
	{
		//does it was broken ?
		if(Nest.Deal[j])
		{
			//get the number
			Nest.Item[j]  = DeBits( Pack,&Nlin,&Nbit,q ) +(d);

			//restore events
			if(Sign[Nest.Item[j]].Type == BE)
					  Nest.Deal[j]			|= 8;	  //correction;
		}
	}
	//nest depth;
	return	lim;
}

//	Find & parse the nearest [x,y] nest
int	Codex::Parser( int posx,int posy )
{
	//try to recognize number of minutiae!
	if ((Nact = Native( posx,posy )) >= 0)
	{
		//reference to list of likages
		Pack = GetLay( LISTpL,Clevel );

                Nlin = 0;
                Nbit = 0;
		//do mask
		int deg[] =
		{
			DeBits( Pack,&Nlin,&Nbit, 4 ),
			DeBits( Pack,&Nlin,&Nbit, 4 ),
			DeBits( Pack,&Nlin,&Nbit, 4 ),
			DeBits( Pack,&Nlin,&Nbit, 4 ),
			DeBits( Pack,&Nlin,&Nbit, 4 ),
			DeBits( Pack,&Nlin,&Nbit, 4 )
		};

		//parse linkages while minutiae
		for (int i = 0; i <= Nact; i++)
		{
			Parser( deg,Sign[i].Type );
		}
	}

	//number !!
	return Nact;
}


#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
