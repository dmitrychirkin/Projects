/**************************************
				Curvat.cpp
		Build curvature field.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"moulds73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//	Lay's definition
enum
{
	_DIRS_ =	TEMP_T,
	_VALS_
};

//-------------------------------------
//	Local tune constants
//-------------------------------------
static const 
int	Clevel = H3,					//native level
				Cwhirl =  1,					//cluster size
				Ctwist = 45;					//contradict twist

/**************************************
		Tune to measure curvature
**************************************/
void	CWork::CuTune( int dsth,int srch )
{
	Snxo = GetLay(	ARCH_V,srch );			//value
	Sexo = GetLay(	ARCH_D,srch );			//direction
	Sfno = GetLay(	_VALS_,srch );			//t-value
	Dsto = GetLay(	FLOW_E,dsth );			//expert flow
	Dnxo = GetLay(	ARCH_V,dsth );			//value
	Dexo = GetLay(	ARCH_D,dsth );			//direction
	Dfno = GetLay(	_DIRS_,dsth );			//t-direction

	//process in native echelon ?
	if (srch != Clevel)	 return;
	Dhpo = GetLay(	PROB_L,dsth );			//local probability
}

//-------------------------------------
//	Destroy comunications 
//-------------------------------------
template <class T>
static void destroycurves( T *p )
{
	p->DelLay( _DIRS_,p->Eche );
	p->DelLay( _VALS_,p->Eche );
}

/**************************************
		Virtual upper functions
**************************************/

//	Do curvature projection
void	CWork::CuDeep( void )
{
	*Sexo =  *Dexo;
	*Snxo =
	*Sfno =  *Dnxo;
}

/**************************************
		Assemble <Curvat> function
**************************************/
//	Measure curvature field
void CWork::CuCurv( void )
{
	//measure flows
	Joff = Dhpo;
	Useo = Movo = Dsto;
	Usex = Movx = Srcx;
	Usey = Movy = Srcy;
	//Treset( Re_v ); //Treset( Im_v );
	Re_v[0] = Re_v[4] = 0; Im_v[0] = Im_v[4] = 0;
	Spiral( Eche, Clas);
	//Targum( Re_v, Im_v, Flow, Useo);
	if(Re_v[0] || Im_v[0])
		Flow[0] = atan(Re_v[0], Im_v[0])/2;
	else
		Flow[0] = *Useo;
	if(Re_v[4] || Im_v[4])
		Flow[4] = atan(Re_v[4], Im_v[4])/2;
	else
		Flow[4] = *Useo;

	//set curvature
	Tcurve( Flow, Dfno, Useo );
	Tcrook( Flow, Dnxo, Useo );
}

//	Curvature collision
void CWork::CuTwis(void)
{
	//measure twist
	//DoMove(&Dfno);
	//DoKeep(&Useo);
	Useo = Movo = Dfno;
	Usex = Movx = Srcx;
	Usey = Movy = Srcy;
	//Treset(Tw_v);
	memset(Tw_v, 0, sizeof(Tw_v));
	//Treset(Quan);
	//memset(Quan, 0, sizeof(Quan));
	Area = 0;
	Spiral(Eche);
	//Tlevel(Tw_v, Quan);

	//rotated twist
	Bask = MIN(Min4(Tw_v[0], Tw_v[1], Tw_v[2], Tw_v[3]),
			   Min4(Tw_v[4], Tw_v[5], Tw_v[6], Tw_v[7]));

	//check twist direction
	if(Bask/Area > Ctwist)
		*Dnxo =  0;

	//relation to the flow!
	if (turn(*Dfno*2, *Dsto) >= 0)
		*Dexo  =  1;
	else
		*Dexo  =  0;
}
void Codex::Curvat( int reih )
{
	//the law for gradient deviation...
	int ang[] = {3, 0,0, 42,42, AR,AR};

	//if the expert flow was not built
	if(GetKey(FLOW_E, Clevel) == -1)
	{
		//previous works
		Flower( FloweR );
	}

	//tune in curvat queue
	OldLay( Tops=CURvat );
	Eche = Clevel;
	Clas = Cwhirl  ;

	//transform corner low
	CorGau(ang);CorSmo(1);
	int i = 0;
	for(; i < SCORN; i++)
	{
		Corn[i] *= 2;
	}

	//measure curvature...
	unsigned char *original_Dsto = Dsto = GetLay(FLOW_E, Eche);//expert flow
	unsigned char *original_Dnxo = Dnxo = GetLay(ARCH_V, Eche);//value
	unsigned char *original_Dexo = GetLay(ARCH_D, Eche);			//direction
	unsigned char *original_Dfno = Dfno = GetLay(_DIRS_, Eche);//t-direction	
	unsigned char *original_Dhpo = Dhpo = GetLay(PROB_L, Eche);//local probability
  	Docexe = (tvii)&CWork::Argums_I;
	Redx = MaxX[Eche];
	Redy = MaxY[Eche];
	for(Srcy = 0; Srcy < Redy; Srcy++)
	{
		for(Srcx = 0; Srcx < Redx; Srcx++)
		{
            CuCurv();
            Dsto++; Dnxo++; Dfno++; Dhpo++;
		}
	}
	Docexe = &CBase::Deaden;
	//measure the twist...
	Dfno = original_Dfno; Dnxo = original_Dnxo;
	Dexo = original_Dexo; Dsto = original_Dsto;
	Docexe = (tvii)&CWork::Twists_I;
	for(Srcy = 0; Srcy < Redy; Srcy++)
	{
		for(Srcx = 0; Srcx < Redx; Srcx++)
		{
            CuTwis();
            Dfno++; Dnxo++; Dexo++; Dsto++;
		}
	}
	Docexe = &CBase::Deaden;

	//inject curvature down hierarchy
	int j, k, step, reih_1;
	int back_len_1, back_len_2;
	unsigned char *old_Snxo, *old_Sexo, *old_Sfno;

	for(Eche = Clevel; Eche > reih;)
	{
		
		//this level
		Dexo = original_Dexo;
		Dnxo = original_Dnxo;

		reih_1 = Eche-1;		
		step = Side[Eche]/Side[reih_1];
		back_len_1 = step*MaxX[reih_1]-step;
		back_len_2 = step*MaxX[reih_1];
		
		//upper level
		original_Dnxo = old_Snxo = GetLay(ARCH_V, reih_1); //value
		original_Dexo = old_Sexo = GetLay(ARCH_D, reih_1); //direction
		unsigned char *original_Sfno = old_Sfno = GetLay(_VALS_, reih_1); //t-value
		//Reax = MaxX[Eche]; Reay = MaxY[Eche];
		for(i = 0; i < Redy; i++)
		{
			Snxo = old_Snxo; Sexo = old_Sexo; Sfno = old_Sfno;
			for(j = 0; j < Redx; j++)
			{
				for(k = 0; k < step; k++)
				{
					memset(Sexo, *Dexo, step); 
               memset(Snxo, *Dnxo, step);
					memset(Sfno, *Dnxo, step);
					Snxo += MaxX[reih_1]; Sexo += MaxX[reih_1];	Sfno += MaxX[reih_1];
				}
				Snxo -= back_len_1;	Sexo -= back_len_1;	Sfno -= back_len_1;
				Dnxo++; Dexo++;
			}
			old_Snxo += back_len_2;	old_Sexo += back_len_2;	old_Sfno += back_len_2;
		}
		//smooth curvature ...
		Eche--;
		Redx = MaxX[Eche]; Redy = MaxY[Eche];
		Indx = Redx + 1; Dedx = Redx - 1;
		Snxo = original_Dnxo;
		Sfno = original_Sfno;
		for(i = 0; i < Redy; i++)
		{
			for(j = 0; j < Redx; j++)
			{
            if(i > 0 && i < Redy-1 && j > 0 && j < Redx-1)
            {
				   *Snxo = Fiimpn(Sfno);
            }
            else
               *Snxo = 0;
				Snxo++; Sfno++;
			}
		}
	}
#ifdef SAVE_LAYERS
    saveLayer("curvat_FLOW_E.dat", FLOW_E, 3);
    saveLayer("curvat_ARCH_V_3.dat", ARCH_V, 3);
    saveLayer("curvat_ARCH_D_3.dat", ARCH_D, 3);
    saveLayer("curvat__DIRS_.dat", _DIRS_, 3);
    saveLayer("curvat_PROB_L.dat", PROB_L, 3);
    
    saveLayer("curvat_ARCH_V_2.dat", ARCH_V, 2);
    saveLayer("curvat_ARCH_D_2.dat", ARCH_D, 2);
    saveLayer("curvat__VALS_.dat", _VALS_, 2);
#endif


	//delete temporary down hierarchy
	for (Eche = Clevel; Eche >=reih;)
	{
		//destroy a local link
		destroycurves( this ); 
		Eche--;
	}
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
