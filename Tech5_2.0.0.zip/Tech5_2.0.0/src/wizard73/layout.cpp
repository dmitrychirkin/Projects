/**************************************
				LayOut.cpp
  Contain scemes for image processing.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"assert.h"
#include		"mathem73.h"
#include		"sorter73.h"
#include		"wizard73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

#ifdef SAVE_LAYERS
   #include		<stdio.h>
   FILE * g_log = NULL;

   bool openLog()
   {
      char path[255];
   #ifdef ANDROID
      strcpy (path, "/sdcard/TECH5/");
   #else
      strcpy (path, "./layers/");
   #endif
      strcat (path, "log.txt");
      g_log = fopen (path, "wc");
      return g_log != 0;
   }

   void closeLog()
   {
      if (!g_log) 
         return;
      fclose (g_log);
      g_log = 0;
   }

   void writeLog(char* s)
   {
      fprintf (g_log, "%s", s);
      fflush(g_log);
   }
#endif

//--------------------------------------
//	Ring table to create spiral
//--------------------------------------
const 
static int	ring[] = {//move direction,skip items,direction from center

	//tiny ring
	0, 2,  0,	2, 3, 45,	4, 0, 90,	4, 3,135,
	6, 0,180,	6, 4,225,	0, 0,270,	0, 6,315,
	//small
	0, 4,338,	2, 0,  0,	2, 7, 23,	2, 5, 45,
	4, 0, 68,	4, 0, 90,	4, 7,113,	4, 5,135,   
	6, 0,158,	6, 0,180,	6, 8,203,   6, 6,225,	
	0, 0,248,	0, 0,270,	0, 9,293,	0, 7,315,	
	//medium	ring
	0, 5,324,	2,	0,342,	2,	0,  0,	2,	9, 18,
	2,	7, 36,	3,	5, 54,	4,	0, 72,	4,	0, 90,
	4,	9,108,	4,	7,126,	5,	5,144,	6,	0,162,
	6,	0,180,	6,10,198,	6,	8,216,	7,	6,234,
	0,	0,252,	0,	0,270,	0,11,288,	0,	9,306,
	//compact ring
	0,	7,315,	1,	5,330,	2,	0,345,	2,	0,  0,
	2,11, 15,	2,	9, 30,	3,	7, 45,	3,	5, 60,
	4,	0, 75,	4,	0, 90,	4,11,105,	4,	9,120,
	5,	7,135,	5,	5,150,	6,	0,165,	6,	0,180,
	6,12,195,	6,10,210,	7, 8,225,	7, 6,240,	
	0, 0,255,	0, 0,270,	0,13,285,	0,11,300,
	//large ring
	0, 9,309,	1, 7,322,	1, 5,335,	2, 0,348,
	2, 0,  0,	2,13, 13,	2,11, 26,	3, 9, 39,
	3, 7, 52,	3, 5, 65,	4, 0, 78,	4, 0, 90,
	4,13,103,	4,11,116,	5, 9,129,	5, 7,142,
	5, 5,155,	6, 0,168,	6, 0,180,	6,14,193,
	6,12,206,	7,10,219,	7, 8,232,	7, 6,245,
	0, 0,258,	0, 0,270,	0,15,283,	0,13,296
};

/***************************************
	  Function for any spiral low
***************************************/
//#include <stdio.h>
int	CBase::Spiral( int hier,int size,int util )
{
	//utilize echo
	Util  = util ;

	//for any size
	switch( size )
	{
		case	0:	size = 24;
					Seat = 8;
					break;
		case	1:	size = 72;
					Seat = 24;
					break;
		case	2:	size = 132;
					Seat = 44;
					break;
		case	3:	size = 204;
					Seat = 68;
					break;
		case	4:	size = 288;
					Seat = 96;
					break;
	}

	//describe spiral
	for (int i = 0,gap = 0,rap = 0; i < size; i += 3,rap++)
	{
		int dir = ring[i];//a situation
		int off = Move[hier].IncO[dir];

		//check lay edges
		if (Movx == Move[hier].FroX[dir] || Movy == Move[hier].FroY[dir])
			gap = ring[i+1];

		//a spiral x,y step
		Movx += Move[hier].IncX[dir];
		Movy += Move[hier].IncY[dir];

		//a spiral offset step
		Movo += off;
		Joff += off;
		Hoff += off;
		Noff += off;
		Eoff += off;
		
		//check gap
		if  (gap)
		{
			//fprintf(pFile, "%3d, %3d, NO CALL\n", Movx, Movy);
			--gap;			
		}
		else
		{
			//fprintf(pFile, "%3d, %3d, CALL\n", Movx, Movy);
			(this->*Docexe)( ring[i+2],rap );
		}
	}

	//fclose(pFile);

	//common spiral power
	return Seat;// = size/3;
}

/**************************************
			Base suppressing
**************************************/

//	Deaden code
void	CBase::Deaden( int dsth,int srch )
{
}

//	Deaden code
void	CBase::Deaden( void )
{
}

//	Deafen code
int	CBase::Deafen( void )
{
	return 0;
}

//	Spirit code
int	CBase::Spirit( void )
{
	return 1;
}

/**************************************
		Standard list of impulses
**************************************/
//-------------------------------------
//	Common sunlight
//-------------------------------------

//	Sunlight along g direction
inline int	CBase::Fisung( byte *src )
{
	return	-Fisunc( src );
}

//	Sunlight along h direction
inline int	CBase::Fisunh( byte *src )
{
	return	-Fisund( src );
}

//-------------------------------------
//	Broken line range impuls
//-------------------------------------
/**************************************
		Resume default tuning
**************************************/
void	CBase::Resume( void )
{
	//default tuning
	Docvie = &CBase::Deaden;
	Docvic = &CBase::Deaden;
	Docisi = &CBase::Deaden;
	Dociso = &CBase::Deaden;
	Docupi = &CBase::Spirit;
	Docupo = &CBase::Spirit;
	Docfni = &CBase::Deaden;
	Docfno = &CBase::Deaden;
	Docexe = &CBase::Deaden;
	Docimm = &CBase::Deafen;
	Docend = &CBase::Deaden;
	
	//reset position
	Srcx =
	Srcy = 
	Dstx =
	Dsty = 0;

	//delete offset of sources
	Srco = 
	Shpo = 
	Snxo = 
	Sexo = 
	Sfno = 
	Swoo = 
	Smoo = 
	Seio =
	Seao =
	Seco =
	Seeo =
	Semo =
	Sero =
	Seso =
	Seuo =
	Sezo = 0;

	//delete offset of destinations
	Dsto = 
	Dhpo =
	Dnxo =
	Dexo =
	Dfno = 
	Dwoo = 
	Dmoo =
	Deio =
	Deao =
	Deco =
	Deeo =
	Demo =
	Dero =
	Deso =
	Deuo =
	Dezo = 0;
}

/**************************************
		Preprocess x&y lugs
**************************************/

//	Delete hierarchy lug
inline void	CBase::DelLug( int step )
{
	//get x backstep
	if (Lugx = MAX( Srcx - Reax + step ))
	{
		Srcx -= Lugx,
		Srco -= Lugx,
		Shpo -= Lugx,
		Snxo -= Lugx,
		Sexo -= Lugx,
		Sfno -= Lugx,
		Swoo -= Lugx,
		Smoo -= Lugx,
		Seio -= Lugx,
		Seao -= Lugx,
		Seco -= Lugx,
		Seeo -= Lugx,
		Semo -= Lugx,
		Sero -= Lugx,
		Seso -= Lugx,
		Seuo -= Lugx,
		Sezo -= Lugx;
	}

	//get y backstep
	if (Lugy = MAX( Srcy - Reay + step ))
	{
		Srcy -= Lugy,
		Lugy *= Reax,
		Srco -= Lugy,
		Shpo -= Lugy,
		Snxo -= Lugy,
		Sexo -= Lugy,
		Sfno -= Lugy,
		Swoo -= Lugy,
		Smoo -= Lugy,
		Seio -= Lugy,
		Seao -= Lugy,
		Seco -= Lugy,
		Seeo -= Lugy,
		Semo -= Lugy,
		Sero -= Lugy,
		Seso -= Lugy,
		Seuo -= Lugy,
		Sezo -= Lugy;
	}
}

//	Restore hierarchy lug
inline void	CBase::SetLug( void )
{
	//advance
	if (Lugx)
	{
		Srco += Lugx;
		Shpo += Lugx;
		Snxo += Lugx;
		Sexo += Lugx;
		Sfno += Lugx;
		Swoo += Lugx;
		Smoo += Lugx;
		Seio += Lugx;
		Seao += Lugx,
		Seco += Lugx,
		Seeo += Lugx,
		Semo += Lugx,
		Sero += Lugx,
		Seso += Lugx,
		Seuo += Lugx,
		Sezo += Lugx;
		Srcx += Lugx;
	}

	//advance
	if (Lugy)
	{
		//advance
		Srco += Lugy,
		Shpo += Lugy,
		Snxo += Lugy,
		Sexo += Lugy,
		Sfno += Lugy,
		Swoo += Lugy,
		Smoo += Lugy,
		Seio += Lugy,
		Seao += Lugy,
		Seco += Lugy,
		Seeo += Lugy,
		Semo += Lugy,
		Sero += Lugy,
		Seso += Lugy,
		Seuo += Lugy,
		Sezo += Lugy;
		Lugy /= Reax;
		Srcy += Lugy;
	}
}

/**************************************
			Scan small fragment
**************************************/

//	Scan inner fragment
inline void	CBase::Fragmi( int step,int jump )
{
	//look over y
	for (register int j = 0,next = Reax-step; j < step; j++)
	{
		//look over x
		for (register int i = 0; i < step; i++)
		{
			//inner process
			(this->*Docisi)();

			//advance
			++Srco,
			++Shpo,
			++Snxo,
			++Sexo,
			++Sfno,
			++Swoo,
			++Smoo,
			++Seio,
			++Seao,
			++Seco,
			++Seeo,
			++Semo,
			++Sero,
			++Seso,
			++Seuo,
			++Sezo;
			++Srcx;
		}

		//do advance
		Srco += next,
		Shpo += next,
		Snxo += next,
		Sexo += next,
		Sfno += next,
		Swoo += next,
		Smoo += next,
		Seio += next,
		Seao += next,
		Seco += next,
		Seeo += next,
		Semo += next,
		Sero += next,
		Seso += next,
		Seuo += next,
		Sezo += next;

		Srcx -= step;
		Srcy++; //y++
	}

	//coordinates
	Srcy -= step;

	//restoring..
	Srco -= jump,
	Shpo -= jump,
	Snxo -= jump,
	Sexo -= jump,
	Sfno -= jump,
	Swoo -= jump,
	Smoo -= jump,
	Seio -= jump,
	Seao -= jump,
	Seco -= jump,
	Seeo -= jump,
	Semo -= jump,
	Sero -= jump,
	Seso -= jump,
	Seuo -= jump,
	Sezo -= jump;

	//inner process
	(this->*Docfni)();
}

//	Scan outward fragment
inline void	CBase::Fragmo( int step,int jump )
{
	//look over y
	for (register int j = 0,next = Reax-step; j < step; j++)
	{
		//look over x
		for (register int i = 0; i < step; i++)
		{
			//outward process
			(this->*Dociso)();

			//advance
			++Srco,
			++Shpo,
			++Snxo,
			++Sexo,
			++Sfno,
			++Swoo,
			++Smoo,
			++Seio,
			++Seao,
			++Seco,
			++Seeo,
			++Semo,
			++Sero,
			++Seso,
			++Seuo,
			++Sezo;
			++Srcx;
		}

		//do advance
		Srco += next,
		Shpo += next,
		Snxo += next,
		Sexo += next,
		Sfno += next,
		Swoo += next,
		Smoo += next,
		Seio += next,
		Seao += next,
		Seco += next,
		Seeo += next,
		Semo += next,
		Sero += next,
		Seso += next,
		Seuo += next,
		Sezo += next;

		Srcx -= step;
		Srcy++; //y++
	}

	//coordinates
	Srcy -= step;

	//restoring..
	Srco -= jump,
	Shpo -= jump,
	Snxo -= jump,
	Sexo -= jump,
	Sfno -= jump,
	Swoo -= jump,
	Smoo -= jump,
	Seio -= jump,
	Seao -= jump,
	Seco -= jump,
	Seeo -= jump,
	Semo -= jump,
	Sero -= jump,
	Seso -= jump,
	Seuo -= jump,
	Sezo -= jump;

	//outward process
	(this->*Docfno)();
}

/**************************************
	Functions to scan hierarchy lays
**************************************/

//	Carry out kernal work in rectangle
void	CBase::Scener( int srch )
{
	//start parameters
	Reax = MaxX[srch];
	Reay = MaxY[srch];
	Redx = MaxX[srch];
	Redy = MaxY[srch];
	Incx = Reax +   1;
	Decx = Reax -   1;
	Indx = Redx +   1;
	Dedx = Redx -   1;

	//base envorinment
	Vide[0] =		 1;
	Vide[1] =	 Incx;
	Vide[2] =	 Reax;
	Vide[3] =	 Decx;
	Vide[4] =		-1;
	Vide[5] =	-Incx;
	Vide[6] =	-Reax;
	Vide[7] =	-Decx;

	//no removal & callback
	Remo = Remv = Call = 0;

	//tune a scan procedure
	(this->*Docvie)(srch,
						 srch );
	(this->*Docvic)(srch,
						 srch );

	//if birth of a new lay
	if (Call)
		(this->*Docuse)(  );

	//look over y
	for (Srcy = Dsty = 0; Srcy < Reay; Srcy++,Dsty++)
	{
		//look over x
		for (Srcx = Dstx = 0; Srcx < Reax; Srcx++,Dstx++)
		{
			//is it into rectangle ?
			if (InRect( Srcx,Srcy ))
				(this->*Docisi)();
			else
				(this->*Dociso)();

			//quick advance source -x-
			++Srco,
			++Shpo,
			++Snxo,
			++Sexo,
			++Sfno,
			++Swoo,
			++Smoo,
			++Seio;

			//quick advance destination -x-
			++Dsto,
			++Dhpo,
			++Dnxo,
			++Dexo,
			++Dfno,
			++Dwoo,
			++Dmoo,
			++Deio;
		}
	}

	//expire!
	Resume();
}


//	Carry out kernal work while scaning
void	CBase::Scenes( int scan,int retr,int dsth,int srch )
{
#ifdef SAVE_LAYERS
   char msg[255];
   if (g_writeLog)
   {
      openLog();
      sprintf (msg, "open log file\n");
      writeLog(msg);
   }
#endif

_DBG_INFO( "CONTROL POINT LAYOUT PREPARE\n" );
	//start parameters
	Reax = MaxX[srch];
	Reay = MaxY[srch];
	Redx = MaxX[dsth];
	Redy = MaxY[dsth];
	Incx = Reax +   1;
	Decx = Reax -   1;
	Indx = Redx +   1;
	Dedx = Redx -   1;

	//base envorinment
	Vide[0] =		 1;
	Vide[1] =	 Incx;
	Vide[2] =	 Reax;
	Vide[3] =	 Decx;
	Vide[4] =		-1;
	Vide[5] =	-Incx;
	Vide[6] =	-Reax;
	Vide[7] =	-Decx;

	//step back border
	int retx = Redx-
				  retr-1,
		 rety = Redy-
				  retr-1;

	//tuning scan parameter
  	int step = Side[dsth] /
				  Side[srch] ,
		 jump = Reax*step  ;

	//no removal & callback
	Remo = Remv = Call = 0;

_DBG_INFO( "CONTROL POINT LAYOUT TUNE SCAN\n" );
	//tune a scan procedure
	(this->*Docvie)(dsth,
						 srch );
	(this->*Docvic)(dsth,

						 srch );

_DBG_INFO( "CONTROL POINT LAYOUT NEW LAY\n" );
	//if birth of a new lay
	if (Call)
		(this->*Docuse)(  );

	//calculate disposition
	switch (scan)
	{
		case 0: break;//skip
		case 1: Remv = step/
								2;
				  Remo = Incx*
							Remv;
		case 2: break;//skip
	}

_DBG_INFO( "CONTROL POINT LAYOUT LOOPS\n" );
_DBG_INFO_1( "  MAXY = %d\n", Redy );
_DBG_INFO_1( "  MAXX = %d\n", Redx );
	//look over y
	for (Srcy = Dsty = 0; Dsty < Redy; Dsty++)
	{      
		//look over x
		for (Srcx = Dstx = 0; Dstx < Redx; Dstx++)
		{
#ifdef SAVE_LAYERS
   if (g_writeLog)
   {
         sprintf (msg, "Dsty=%d Dstx=%d\n", Dsty, Dstx);
         writeLog (msg);
   }
#endif

         _DBG_INFO_2( "X:%4d | Y: %4d", Dstx, Dsty );
         
			//delete lug !
			DelLug( step );

			//if inward
			if (retr == 0)
				{if (scan) (this->*Docisi)(); else if ((this->*Docupi)()) Fragmi(step,jump);}
			else//outward
			if (Dstx < retr)
				{if (scan) (this->*Dociso)(); else if ((this->*Docupo)()) Fragmo(step,jump);}
			else//outward
			if (Dsty < retr)
				{if (scan) (this->*Dociso)(); else if ((this->*Docupo)()) Fragmo(step,jump);}
			else//outward
			if (Dstx > retx)
				{if (scan) (this->*Dociso)(); else if ((this->*Docupo)()) Fragmo(step,jump);}
			else//outward
			if (Dsty > rety)
				{if (scan) (this->*Dociso)(); else if ((this->*Docupo)()) Fragmo(step,jump);}
			else//inward
				{if (scan) (this->*Docisi)(); else if ((this->*Docupi)()) Fragmi(step,jump);}

			//restore lug
			SetLug();

			//advance source -x-
			Srco += step,
			Shpo += step,
			Snxo += step,
			Sexo += step,
			Sfno += step,
			Swoo += step,
			Smoo += step,
			Seio += step,
			Seao += step,
			Seco += step,
			Seeo += step,
			Semo += step,
			Sero += step,
			Seso += step,
			Seuo += step,
			Sezo += step,
			Srcx += step;

			//advance destination -x-
			++Dsto,
			++Dhpo,
			++Dnxo,
			++Dexo,
			++Dfno,
			++Dwoo,
			++Dmoo,
			++Deio,
		   ++Deao,
		   ++Deco,
		   ++Deeo,
		   ++Demo,
		   ++Dero,
		   ++Deso,
		   ++Deuo,
		   ++Dezo;
		}

		//advance source -y-
		if (step > 1)
		{
			Srco += jump-Srcx,
			Shpo += jump-Srcx,
			Snxo += jump-Srcx,
			Sexo += jump-Srcx,
			Sfno += jump-Srcx,
			Swoo += jump-Srcx,
			Smoo += jump-Srcx,
			Seio += jump-Srcx,
			Seao += jump-Srcx,
			Seco += jump-Srcx,
			Seeo += jump-Srcx,
			Semo += jump-Srcx,
			Sero += jump-Srcx,
			Seso += jump-Srcx,
			Seuo += jump-Srcx,
			Sezo += jump-Srcx;
		}

		//advance source -y-
		Srcy += step;
	}
_DBG_INFO( "CONTROL POINT LAYOUT RESUME\n" );

	//expire!
	Resume();
_DBG_INFO( "CONTROL POINT LAYOUT OUT\n" );
#ifdef SAVE_LAYERS
   if (g_writeLog)
      closeLog();
#endif

}

//	Inner process function
void	CBase::Scenei( int scan,int dsth,int srch )
{
	Scenes( scan,1,dsth,srch );
}

//	Whole process function
void	CBase::Scenew( int scan,int dsth,int srch )
{
	Scenes( scan,0,dsth,srch );
}

/**************************************
	Functions for detailed work
**************************************/

//	Check existing lay
int	CBase::GetKey( int nkey,int hier )
{
	//find signed lay
	for (int i = 0; i < LayN[hier]; i++)
	{
		//if nkey OK
		if (Hier[hier].Keys[i] == nkey)
		{
			//success
			return i;
		}
	}

	//have not
	return -1;
}


//	Get refer to lay for key
byte*	CBase::GetLay( int nkey,int hier )
{	
	int units = 0;//the power

	//try find the lay
	for (int i = 0; i < LayN[hier]; i++)
	{
		//get named lay
		if (nkey == Hier[hier].Keys[i])
			return	Hier[hier].Lays[i];	
		if (	-1 !=	Hier[hier].Keys[i])
			units++;
	}
		//find maximum
		if (Hier[hier].Unit < units +1)
			Hier[hier].Unit = units +1;

	//find a free lay
	for (int j = 0; j < LayN[hier]; j++)
	{
		//is freedom ?
		if (Hier[hier].Keys[j] == -1)
		{
			Call++;  //congratulation!
			Hier[hier].Keys[j] = nkey;
			Hier[hier].Clks[j] = Tops;
			return Hier[hier].Lays[j];
		}
	}

	//ref zero
	return  0;
}

//	Free the lay with special key
void	CBase::DelLay( int nkey,int hier )
{
	//find signed lay
	for (int i = 0; i < LayN[hier]; i++)
	{
		//if lay with this key exist
		if (Hier[hier].Keys[i] == nkey)
		{
			Hier[hier].Keys[i] = -1;
			Hier[hier].Clks[i] = -1;
			return;  //have success
		}
	}
}

//	Clear all old lays
void	CBase::OldLay( int time )
{
	//set hierarchy pointers
	for (int i = 0; i < ECHEM; i++)
	{
		//set lay pointer
		for (int j = 0; j < LayN[i]; j++)
		{
			if (Hier[i].Clks[j] >= time)
			{
				Hier[i].Keys[j] = -1;
				Hier[i].Clks[j] = -1;
			}
		}
	}
}

//	Set projection
void	CBase::ProLay( int nkey,int srcx,int srcy,int dsth,int srch )
{
	//calculate x projection
	Movx = srcx * Side[srch]/
					  Side[dsth];
	Movy = srcy * Side[srch]/
					  Side[dsth];
	Movo = Movy * MaxX[dsth]+
			 Movx					+
			 GetLay(nkey,dsth);
}

//	Get reference to position
byte*	CBase::ProRef( int nkey,int srcx,int srcy,int dsth,int srch )
{

	//calculate the reference
	return srcy * Side[srch]/
					  Side[dsth]* 
					  MaxX[dsth]+
			 srcx * Side[srch]/
					  Side[dsth]+
			 GetLay(nkey,dsth);
}

//	Get reference to source position
byte*	CBase::ProSrc( int nkey,int dsth,int srch )
{
	return ProRef( nkey,Srcx,Srcy,dsth,srch );
}

//	Dip position into the pyramid
int	CBase::DipPyr( int coor,int dsth,int srch )
{
	srch -= dsth;//relatively

	//calculates dip position
	return  (coor << srch)+ 
			  (	1 << srch)/2;
}

/**************************************
				Quick access
**************************************/
//	Set basket
inline void	CBase::Weight( int  item )
{
	Bask =*Movo*
			 item;
	Team = item;
}

/**************************************
			Process rectangle
**************************************/

//	Delete rectangle
inline void	CBase::DeRect( int eche )
{
	//set this rectangle
	L_re = MaxX[eche]-1,
	R_re = 0,

	T_re = MaxY[eche]-1,
	B_re = 0;
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
