/**************************************
				Filter.cpp
		 Filter the hole image.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local enumerated type
//-------------------------------------
enum
{
	_QUAL_ = TEMP_T
};

//-------------------------------------
//	Local tune constants
//-------------------------------------
static const 
int	Clevel = H1,					//native level
	Cwhirl =  1,					//cluster
	Climit = -0,					//threshold
	Crecur =  4;					//final iteration

//-------------------------------------
//	Section of local constants
//-------------------------------------

//	Harmon's pixel weight
static const 
byte Hw_normal[] =
{
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,		//harmon  0
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,		//harmon  1
	16, 0, 0, 0, 0, 0, 0, 0, 0, 0,		//harmon  2 //16
	16,16, 0, 0, 0, 0, 0, 0, 0, 0,		//harmon  3 //32
	 1,16, 1, 0, 0, 0, 0, 0, 0, 0,		//harmon  4 //18
	 0,16,16, 0, 0, 0, 0, 0, 0, 0,		//harmon  5 //32
	 0, 2,16, 2, 0, 0, 0, 0, 0, 0,		//harmon  6 //20
	 0, 0,16,16, 0, 0, 0, 0, 0, 0,		//harmon  7 //32
	 0, 0, 3,16, 3, 0, 0, 0, 0, 0,		//harmon  8 //22
	 0, 0, 0,16,16, 0, 0, 0, 0, 0,		//harmon  9 //32
	 0, 0, 0, 4,16, 4, 0, 0, 0, 0,		//harmon 10 //24
	 0, 0, 0, 0,16,16, 0, 0, 0, 0,		//harmon 11 //32
	 0, 0, 0, 0, 5,16, 5, 0, 0, 0,		//harmon 12 //26
	 0, 0, 0, 0, 0,16,16, 0, 0, 0,		//harmon 13 //32
	 0, 0, 0, 0, 0, 6,16, 6, 0, 0,		//harmon 14 //28
	 0, 0, 0, 0, 0, 0,16,16, 0, 0,		//harmon 15 //32
	 0, 0, 0, 0, 0, 0, 7,16, 7, 0,		//harmon 16 //30
	 0, 0, 0, 0, 0, 0, 0,16,16, 0		//harmon 17 //32
};

const 
static byte Hw_quick[] =
{
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,		//harmon  0
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,		//harmon  1
	 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,		//harmon  2
	 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,		//harmon  3
	 1, 1, 0, 0, 0, 0, 0, 0, 0, 0,		//harmon  4
	 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,		//harmon  5
	 0, 1, 1, 0, 0, 0, 0, 0, 0, 0,		//harmon  6
	 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,		//harmon  7
	 0, 0, 1, 1, 0, 0, 0, 0, 0, 0,		//harmon  8
	 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,		//harmon  9
	 0, 0, 0, 1, 1, 0, 0, 0, 0, 0,		//harmon 10
	 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,		//harmon 11
	 0, 0, 0, 0, 1, 1, 0, 0, 0, 0,		//harmon 12
	 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,		//harmon 13
	 0, 0, 0, 0, 0, 1, 1, 0, 0, 0,		//harmon 14
	 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,		//harmon 15
	 0, 0, 0, 0, 0, 0, 1, 1, 0, 0,		//harmon 16
	 0, 0, 0, 0, 0, 0, 0, 1, 0, 0			//harmon 17
};

byte Hw [180];

/**************************************
		Tune Filter procedures
**************************************/

//	Inspect context in first step
static  int in( int cont )
{
	return cont ? PROPHE : NORMAL;
}

//	Tune preparation
void	CWork::FiType( int dsth,int srch )
{
	Srco = GetLay(	CCLASS ,srch );		//c-class
   if (integ)
	   Shpo = GetLay(	FCLASS ,srch );		//focuses
	Dsto = GetLay(	GOAL_R ,dsth );		//ridge goal
	Dnxo = GetLay(	GOAL_F ,dsth );		//filter goal
	Dfno = GetLay(	QUAL_E ,dsth );		//quality
	Dmoo = GetLay(	GOAL_I ,dsth );		//iteration
	Dwoo = GetLay(	MORDER ,dsth );		//m-class
	Deio = GetLay(	_QUAL_ ,dsth );		//qiality
}

//	Tune common information
void	CWork::FiTune( int dsth,int srch )
{
	Dsto = GetLay(	ARCH_D ,dsth );		//arch direction
	Dhpo = GetLay(	FLOW_E ,dsth );		//expert flow
	Dnxo = GetLay(	GOAL_F ,dsth );		//filter goal
	Dexo = GetLay(	DENSIT ,dsth );		//density
	Dfno = GetLay(	QUAL_E ,dsth );		//quality
	Dwoo = GetLay(	ARCH_V ,dsth );		//arch value
	Dmoo = GetLay(	GOAL_I ,dsth );		//iteration
}

//	Tune harmon filter
void	CWork::FiHarmII( int dsth,int srch )
{
	Srco = GetLay(in(Star),srch );		//context lay
	Shpo = GetLay( DIFFER ,srch );		//harmon
}

//	Tune even filter
void	CWork::FiEven( int dsth,int srch )
{
	Srco = GetLay( DIFFER ,srch );		//harmon
	Shpo = GetLay( PROPHE ,srch );		//prophecy
}

//	Tune to binarize image
void	CWork::FiClas( int dsth,int srch )
{
	Srco = GetLay( PROPHE ,srch );		//prophecy
	Snxo = GetLay( REFINE ,srch );		//skeleton
	Sexo = GetLay( SKELET ,srch );		//and copy
}

//-------------------------------------
//	Destroy comunications
//-------------------------------------
template <class T>
static void destroyfilter( T *p )
{
	p->DelLay( _QUAL_,p->Eche );
}

/**************************************
		Some inline functions
**************************************/

//	Calulate curve direction
static inline int grad( byte *dirs,byte *flow )
{
	if (*dirs)
		return *flow+AR;
	else
		return *flow-AR;
}

//	Calulate harmon wing size
static inline int wing( byte *harm )
{
	return *harm/2 + 1;
}

/**************************************
			Usefull subfunction
			for upper functions
**************************************/

//	Prepare harmon wings
void CWork::FiHarm(void)
{
	//a sceme
	Tabp = 0; 
	Movo = 0;
    Movx = Movy = 0;
	int i = Breweb(grad(Dsto, Dhpo), *Dexo+1, H0, West);
	//scan the net of
	for(--i; i; i--)
	{
		//if equal or less
		if(dist( West[i].Movx,West[i].Movy ) <= *Dexo)
		{
			Tabp = (i+1)*10;
			break; //success
		}
	}

}

//	Calculate rays for curve line
void	CWork::FiRays( int size )
{
	//needle's parameter
	int curv = *Dwoo/05,
		 flow;

	//if set nothing - harmon
	if (size == 0)
		 size  = wing( Dexo );

	//get curvature direction
	flow = grad( Dsto,Dhpo );

	//do head
	Breset();
	Breweb( flow+AR-curv,size,H0,Head );

	//do tail
	Breset();
	Breweb( flow-AR+curv,size,H0,Tail );
}

//	Resize working areas
void	CWork::FiMode( int flow,int step )
{
	//working area ?
	if (*Movo & W5 ) 
		return; //out

	//skeleton area?
	if(*Joff && step < 8) 
		//unlock area
		*Movo &= ~W3;

		//local work
		*Movo |=  W6;
}

/**************************************
		Kernal inline subfunctions
**************************************/

//	Measure wings in inner areas
int	CWork::FiHrzi( void )
{
	//collect line signs
	register int i, n, sm, cn, w;
	//bool getin = false;
	cn = 0;
	for (i = 0,n = Tabp,sm = 0,w; West[i].IncO; i++,n++)
	{
		if(w = Hw[n])
		{
			sm += *(Srco+West[i].IncO)*w;
			sm += *(Srco-West[i].IncO)*w;
         if (quick)
			   cn += 2;//get quick value
         else
			   cn += w + w;//get quick value
			//getin = true;
		}
		//if stop into table
		if (cn && !w) break;
		//if(getin && !w) break;
	}
	//cn = S_Hw[Tabsp];

	//final average difference
	return *Srco - DIP( sm,cn);
}

//	Measure wings in outward areas
int	CWork::FiHrzo( void )
{
	//collect line signs
	register int i, n, sm, cn, w;
	for (i = 0,n = Tabp,sm = 0,cn = 0,w; West[i].IncO; i++,n++)
	{
		//if sign good
		if ((w = Hw[n]))
		{
			//check left edge
			if (L_Edge( West[i].Movx,West[i].Movy ))
			{
				sm += *(Srco+West[i].IncO)*w;
            if (quick)
				   cn += 1;//left count and sum..
            else
               cn += w;//left count and sum..
			}

			//check right edge
			if (R_Edge( West[i].Movx,West[i].Movy ))
			{
				sm += *(Srco-West[i].IncO)*w;
            if (quick)
				   cn += 1;//right count and sum..
            else
				   cn += w;//right count and sum..
			}
		}
		//if stop into table
		if (cn && !w) break;
	}

	//final average difference
	return *Srco - DIP( sm,cn);
}

//	Broken line evened impuls
int	CWork::FiLine( SStep *fwd,SStep *bck,byte *src )
{
	//reads center
	int sm = *src;

	//collect head
	register int i;
	for (i = 0; fwd[i].IncO && L_Edge(fwd[i].Movx, fwd[i].Movy); i++)
		sm += *(src + fwd[i].IncO );

	//collect tail
	register int j;
	for (j = 0; bck[j].IncO && L_Edge(bck[j].Movx, bck[j].Movy); j++)
		sm += *(src + bck[j].IncO );

	//final the broken line
	return	DIP( sm,i+j+1 );
}

/**************************************
		Virtual kernal functions
**************************************/

//	Sense active regions
void CWork::FiTypeV( void )
{
	//is region unlocked?
	//if((*Dnxo & W3) == 0)
	{
		//if any work absent..
		if((*Srco & C6) == 0)
			*Dnxo  = W5;
		else//if border
		if(Razors())
			*Dnxo  = W5;
		else//for focus
//		if (*Shpo & FF)
		if (integ && (*Shpo & FF))
		{
			*Dnxo  = W2;
			*Dmoo = Crecur-Lord[ *Deio*BM/Qual ]/BM;
		}
		else//full work
		{
			*Dnxo  = W4;
			*Dmoo = Crecur-Lord[ *Deio*BM/Qual ]/BM;
		}
	}
}

//-------------------------------------
//	Detailed function of filter
//-------------------------------------

//	Complicative inner harmon
void	CWork::FiFili( void ) 
{
	*Shpo = Rank[FiHrzi()/2 + BA];
}

//	Complicative outward harmon
void	CWork::FiFilo( void )
{
	*Shpo = Rank[FiHrzo()/2 + BA];
}

//	Build gray image
void	CWork::FiGray( void )
{
	*Shpo = BA;
}

//	Copy lay to another
void	CWork::FiCopy( void )
{
	*Shpo = *Srco;
}

//	Inner range impulse
void	CWork::FiRayi( void )
{
   if (quick)
      *Shpo = FiBros( Head,Tail,Srco );
   else
      *Shpo = FiBrom( Head,Tail,Srco );
}

//	Outward smoothed impulse
void	CWork::FiRayo( void )
{
	*Shpo = FiLine( Head,Tail,Srco );
}

//	Smooth indignation
void	CWork::FiIndi( void )
{
	*Shpo = Fiimpr( Srco,1 );
}

//-------------------------------------
//	Detailed binarize functions
//-------------------------------------

//	Binarize harmonized inner image
void	CWork::Binari( void )
{
	*Snxo = 
	*Sexo = FiHrzi() < Climit ? BU : BG;
}

//	Binarize harmonized outward image
void	CWork::Binaro( void )
{
	*Snxo = 
	*Sexo = FiHrzo() < Climit ? BU : BG;
}

//	Do nothing
void	CWork::FiNoth( void ) 
{
	*Snxo = 
	*Sexo = BM;
}

/**************************************
		Upper function for filter
**************************************/
//	Up function for inner harmons
int	CWork::FiHari( void )
{
	switch (*Dnxo)//& ~W6)
	{
		case W2:
		case W4: 
			Docisi = (tv_v)&CWork::FiFili; 
			FiHarm(); 
			return 1;
		case W5:	
			Docisi = (tv_v)&CWork::FiGray; /* OK */	
			return 1;
		default: /* can do nothing		- skip  */	
			return 0;
	}
}

//	Up function for outward harmons
int	CWork::FiHaro( void )
{
	switch (*Dnxo)// & ~W6)
	{
		case W2: 
		case W4: 
			Dociso = (tv_v)&CWork::FiFilo; 
			FiHarm(); 
			return 1;
		case W5:	
			Dociso = (tv_v)&CWork::FiGray; /* OK */	
			return 1;
		default: /* can do nothing		- skip  */	
			return 0;
	}
}
//	Up function for inner smoothing
int	CWork::FiEvei( void )
{
	switch (*Dnxo)//& ~W6)
	{
		case W4: 
			Docisi = (tv_v)&CWork::FiRayi; 
			FiRays(8);
			return 1;
		case W2:	
			Docisi = (tv_v)&CWork::FiIndi; /* OK */	
			return 1;
		case W5:	
			Docisi = (tv_v)&CWork::FiCopy; /* OK */	
			return 1;
		default: /* can do nothing		- skip  */	
			return 0;
	}
}

//	Up function for outward smoothing
int	CWork::FiEveo( void )
{
	switch (*Dnxo)// & ~W6)
	{
		case W4: 
			Dociso = (tv_v)&CWork::FiRayo; 
			FiRays(0);
			return 1;
		case W2:	
			Dociso = (tv_v)&CWork::FiIndi; /* OK */	
			return 1;
		case W5:	
			Dociso = (tv_v)&CWork::FiCopy; /* OK */	
			return 1;
		default: /* can do nothing		- skip  */	
			return 0;
	}
}

//	Up function to binarize inner image
int	CWork::FiBini( void )
{
	switch ((*Dnxo &= ~W1))// & ~W6)
	{
		case W2:
		case W4: 
			Docisi = (tv_v)&CWork::Binari; 
			FiHarm(); 
			return 1;
		case W5:	
			Docisi = (tv_v)&CWork::FiNoth; /* OK */	
			return 1;
		default: /* can do nothing		- skip  */	
			return 0;
	}
}

//	Up function to binarize outward image
int	CWork::FiBino( void )
{
	switch ((*Dnxo &= ~W1))// & ~W6)
	{
		case W2:
		case W4: 
			Dociso = (tv_v)&CWork::Binaro; 
			FiHarm(); 
			return 1;
		case W5:	
			Dociso = (tv_v)&CWork::FiNoth; /* OK */	
			return 1;
		default: /* can do nothing		- skip  */	
			return 0;
	}
}

//	Check recursive process
void	CWork::FiStop( void )
{
	//outward area?
	if(*Dnxo &  W5)
		*Dnxo |= W1;
	else//stop filter
	if(*Dmoo <= Star)
		*Dnxo |= W1;
	else//continue!
		Proc   = 01;
}

/**************************************
		Assembly <Filter> function
**************************************/
void Codex::Filter( int reih )
{
   if (quick)
      memmove (&Hw, &Hw_quick, sizeof (Hw_quick));
   else 
      memmove (&Hw, &Hw_normal, sizeof (Hw_normal));

	//the amplifier and smoothing law..
	int sun[] = {3, 0,30, 30,24, BA,BA};
	int rec[] = {3, 16,0, 32,48, BM,BM};

	//if goal wasn't defined
	if(GetKey( GOAL_F,Clevel ) == -1)
	{
		//previous works
		Laying(LayinG);
	}
	//tune in filter queue
	OldLay(Tops = FILter);
	WiRect(Eche = Clevel, 0);
	Clas = Cwhirl;
	Qual = 1;//reset

	//imprints superposed?
	if(Impose) rec[3]=160;

	//builds amplifier low
	RanGau(sun);RanSmo(9);

	//builds a quality low
	LorMod(rec);LorSmo(9);
	int i;
	for(i = 0; i < SRANK; i++)
	{
		Lord[i] = Crecur*Lord[i];
	}

	//sense active regions
	Dfno = GetLay(QUAL_E, Eche);		//quality	
	unsigned char *original_Deio = Deio = GetLay(_QUAL_, Eche);		//qiality
	for(i = 0; i < Size[Eche]; i++)
	{        
		*Deio= MAX(*Dfno - BA);
		Qual= MAX(Qual, *Deio);	
		Deio++; Dfno++;
	}

	//classify the regions
	Docvie = (tvii)&CWork::FiType;
	Docisi = (tv_v)&CWork::FiTypeV;
	Scener(Eche);

	//iteration procedure to filter
	for (Star = 0,Proc = 1; Star < Crecur && Proc; Star++)
	{
		//outstand harmonics..
		Docvie = (tvii)&CWork::FiHarmII;
		Docvic = (tvii)&CWork::FiTune;
		Docupi = (ti_v)&CWork::FiHari;
		Docupo = (ti_v)&CWork::FiHaro;
		Scenes( 0,5,Eche,H0 );

		Proc = 0;	 //do stop

		//outstand line along
		Docvie = (tvii)&CWork::FiEven;
		Docvic = (tvii)&CWork::FiTune;
		Docupi = (ti_v)&CWork::FiEvei;
		Docupo = (ti_v)&CWork::FiEveo;
		Docfni =
		Docfno = (tv_v)&CWork::FiStop;
		Scenes( 0,2,Eche,H0 );
	}

	//outstand harmonics..
	Docvie = (tvii)&CWork::FiClas;
	Docvic = (tvii)&CWork::FiTune;
	Docupi = (ti_v)&CWork::FiBini;
	Docupo = (ti_v)&CWork::FiBino;
	Scenes(0, 5, Eche, H0);

	//destroy a local link
	destroyfilter( this );
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
