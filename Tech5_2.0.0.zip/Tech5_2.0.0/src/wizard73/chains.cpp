/**************************************
				Chains.cpp
		  Parse of the chains.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"retain73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local tune constants
//-------------------------------------
static const 
 int	CAngle =  30;					//angle delta

/**************************************
		Build the skeleton tail
**************************************/


//	Analize divergence
void	Chain::Diverg( int head )
{
	if (--head < 0) head = _SPY_-1;

	//parse event of divergence
	if (*Walk[head].Movo == VL)
		Deal = E7;
	if (*Walk[head].Movo == VR)
		Deal = Eb;
	if (*Walk[head].Movo == VS)
		Deal = E3;
}

//	Extract minutiae on link
void	Chain::Aspire( int sign )
{
	//if this is native minutiae
	if ((this->*Docmin)( sign ))
		Deal = E0;
	else//no case
	if(sign > MO)
		Deal = E0;
	else
		Item = sign;
}

//	Create skeleton tail
void	Chain::Shrink( void )
{
	Tail = Head = P_go = 0;

	//stores start position
	Walk[Head].Movx = Movx;
	Walk[Head].Movy = Movy;
	Walk[Head].Movo = Movo;

	//advance buffer's head
	if (++Head == _SPY_)	//
			Head =  0;
}

//	Add recent position
void	Chain::Recent( void )
{
	//store recent position
	Walk[Head].Movx = Movx;
	Walk[Head].Movy = Movy;
	Walk[Head].Movo = Movo;
	

	//advance buffer's head
	if (++Head == _SPY_)	//
			Head =  0;

	//if ring was exhausted
	if (Tail != Head)//bite
		 return;

	//advance buffer's tail
	if (++Tail == _SPY_)	//
			Tail =  0;
}

//	Calulate alpha of path
int	Chain::Alphas( void )
{
	//get the alpha of the trajectory
	return	atan( Walk[Head].Movx-
						Walk[Tail].Movx,
						Walk[Head].Movy-
						Walk[Tail].Movy );
}

//	Calulate length of trace
int	Chain::Length( void )
{
	//get the size  of the trajectory
	return	dist(Walk[Head].Movx, Walk[Head].Movy, Walk[Tail].Movx, Walk[Tail].Movy);
}

/**************************************
		Functions to process arm
**************************************/

//	Reset arms data
void	Chain::ArmDel( void )
{
	//look over buffer
	for (int i = 0; i < _ARM__; i++)
	{
		//delete arms data
		Arms[i].Item = -1;
		Arms[i].Deal =
		Arms[i].Movx =
		Arms[i].Movy =
		Arms[i].Pink =
		Arms[i].Beta =  0;
	}
		Narm = 0; //delete
}

//	Builds the end of branch
void Chain::ArmEnd( void )
{
	//verifies quantity
	//if(Narm++ < _ARM__)
	{
		Arms[Narm].Movx = Movx;
		Arms[Narm].Movy = Movy;
		Arms[Narm].Movo = Movo;
		Narm++;
	}
}
//	Store measured beta
void	Chain::ArmDir( void )
{
	//verifies quantity
	if (Narm++ < _ARM__)
	{
		if (--Head < 0) Head = _SPY_-1;

		//set orientation of the branch
		Arms[Narm-1].Beta = Alphas();
	}
}
//	Store measured full data
void	Chain::ArmArm( void )
{
	//verifies quantity
	if (Narm++ < _ARM__)
	{
		if (--Head < 0) Head = _SPY_-1;

		//set information of the branch

		Arms[Narm-1].Pink =	Length() ;
		Arms[Narm-1].Movx =	Usex;
		Arms[Narm-1].Movy =	Usey;
		Arms[Narm-1].Movo =	Useo;
		Arms[Narm-1].Deal =	Deal;
		Arms[Narm-1].Item =	Item;
		Arms[Narm-1].Beta =	Alphas() ;
	}
}
/**************************************
					Kernal
			to process skeleton
**************************************/

int	Chain::SkeHidV( void )
{
	//check pixel
	switch( *Movo )
	{
		case BE:
		case BB:
		case BS:
		//case BP:
		//case BL:
		//case BR: 
				*Movo += BV;//mark
				 //Route[Route_size++] = Movo;
				 return	1;//goon
		case BU: *Movo += BV;//mark
				 //Route[Route_size++] = Movo;
		default: return	0;//stop
	}	
}
//	Reveal any skeleton
int	Chain::SkeRevV( void )
{		
	//check pixel
	switch( *Movo )
	{
		case VE:
		case VB:
		case VU:
		case VP:
		case VL:
		case VR:
		case VS:	*Movo -= BV;//restore
					return	1;//goon
		default: return	0;//stop
	}
}

//	Rub out any skeleton
int	Chain::SkeRubV( void )
{		
	//check pixel
	switch( *Movo )
	{
		case VE:
		case VB:
		case VU:
		case VP:
		case VL:
		case VR:
		case VS:	*Movo = BG;//wipe
					return	1;//goon
		default: return	0;//stop
	}
}

//	Get skeleton direction
int	Chain::SkeDirV( void )
{		
	//check pixel
	switch( *Movo )
	{
		case BS:
		case BP:
		case BL:
		case BR:
            *Movo += BV;//mark
			Recent();//tail
			Route[Route_size++] = Movo;
			return	1;//goon
		case BE:
		case BB:
		case BU:
			Recent();//tail
		default:
			return	0;//stop
	}
}
//	Restore  skeleton
int	Chain::SkeResV( void ) 
{
	//check pixel
	switch( *Movo )
	{
		case VP:
		case VL:
		case VR:
		case VS:	*Movo-= BV;//restore
					return	1;//goon
		default:	return	0;//stop
	}
}

//	Delete marked skeleton & minutiaes
int	Chain::SkeDelV( void ) 
{
	//check pixel
	switch( *Movo )
	{
		case VP:
		case VL:
		case VR:
		case VS:	*Movo = BG;//gap
					return	1;
		case BE:	*Movo = BG;//gap
					return	0;
		case BB:	*Movo = BS;//skeleton
		default:	return	0;//nothing
	}
}

//	Mark skeleton
int	Chain::SkeMrkV( void )
{		
	//check pixel
	switch( *Movo )
	{
		case BP:
		case BL:
		case BR:
		case BS: *Movo+= BV;//mark			
					return	1;//goon	
		default: return	0;//stop
	}
}

//	Find minutiae
int	Chain::SkeMinV( void )
{
	//check pixel
	switch( *Movo )
	{
		case BP:
		case BL:
		case BR:
		case BS:
			*Movo += BV;//mark
            Recent();//tail
			Route[Route_size++] = Movo;
			return	1;//goon
		case BE:
		case BB:	Recent  ();//tail
					Deal	=	1;//find
		default:	return	0;//stop
	}
}

//	Extract links
int	Chain::SkeLinV( void )
{
	//check pixel
	switch( *Movo )
	{
		case BP:	if ((this->*Docmin)(*Joff)) goto goon;
					Deal  = E1;//case
					DoKeep(&Useo );
					Aspire(*Joff );
					Recent  ();//tail
					return	0;//stop
		goon	 :
		case BL:
		case BR:
		case BS:	*Movo+= BV;//mark
					Recent  ();//tail
					return	1;//go on
		case BE:	Deal  = Ef;//case
					DoKeep(&Useo );
					Aspire(*Joff );
					Recent  ();//tail
					return	0;//stop
		case BB:	Diverg( Head );
					DoKeep(&Useo );
					Aspire(*Joff );
					Recent  ();//tail
					return	0;//stop
		case BU:	Deal  = E0;//case
		default:	return	0;//stop
	}
}


//	Encode cycle code
int	Chain::EChainV( void )
{
	//parse pixels
	switch (*Movo)
	{
		case BE:
		case BB:
		case BP:
		case BL:
		case BR:
		case BS:	*Movo = BG;//gaps
					Pack[Lpck++] = updi( D_go-P_go );
												P_go=D_go  ;
					return	1;//goon
		case BU:	*Movo = BG;//gaps
					Pack[Lpck++] = updi( D_go-P_go ); 
												P_go=D_go  ;
		default:	return	0;//stop
	}
}

//	Decode cycle code
int	Chain::DChain( void )
{
	*Movo = BS; //write

	//parse this buffer
	switch (Pack[Lpck])
	{
		case  0:
		case  1:
		case  2:
		case  3:
		case  4:
		case  5:
		case  6:
		case  7:	P_go = updi( Pack[Lpck++]+P_go );
	}

	//parse this buffer
	switch (Pack[Lpck])
	{
		case  0:
		case  1:
		case  2:
		case  3:
		case  4:
		case  5:
		case  6:
		case  7:	D_go = updi( Pack[Lpck  ]+P_go );
					return	1;//goon
		case BF:	return	0;//stop
	}
    return -1;
}

//-------------------------------------
//		Upper block for skeleton
//-------------------------------------

//	Hide skeleton
int	Chain::SkeHid( int nlen )
{
	Docimm = (ti_v)&Chain::SkeHidV; 
	Rounde( nlen,H0 ); 
	return Deal;
}

//	Reveal skeleton
int	Chain::SkeRev( int nlen )
{
	Docimm = (ti_v)&Chain::SkeRevV; 
	Rounde( nlen,H0 ); 
	return Deal;
}

int	Chain::SkeRub( int nlen )
{
	Docimm = (ti_v)&Chain::SkeRubV; 
	Rounde( nlen,H0 ); 
	return Deal;
}

//	Measure skeleton direction
int	Chain::SkeDir( int nlen )
{
	Docimm = (ti_v)&Chain::SkeDirV; 
	Rounde( nlen,H0 ); 
	return Deal;
}

//	Restore skeleton
int	Chain::SkeRes( int nlen )
{
	Docimm = (ti_v)&Chain::SkeResV; 
	Rounde( nlen,H0 ); 
	return Deal;
}

//	Delete skeleton
int	Chain::SkeDel( int nlen )
{
	Docimm = (ti_v)&Chain::SkeDelV; 
	Rounde( nlen,H0 ); 
	return Deal;
}

//	Mark skeleton
int	Chain::SkeMrk( int nlen )
{
	Docimm = (ti_v)&Chain::SkeMrkV; 
	Rounde( nlen,H0 ); 
	return Deal;
}

//	Find minutiae in skeleton
int	Chain::SkeMin( int nlen )
{
	Deal = 0; 
	Docimm = (ti_v)&Chain::SkeMinV; 
	Rounde( nlen,H0 ); 
	return Deal;
}

//	Find minutiae link
int	Chain::SkeLin( int nlen )
{
	Deal = 0; 
	Docimm = (ti_v)&Chain::SkeLinV; 
	Rounde( nlen,H0 ); 
	return Deal;
}

//	Encode skeleton chain
int	Chain::EChain( int nlen )
{
	Tree++; 
	Docimm = (ti_v)&Chain::EChainV; 
	Runner( nlen,H0 ); 
	return Pack[Lpck++] = BF;
}

/**************************************
		Look around into the box
**************************************/

//	Do assignment for the branch
void	Chain::Assign( int nlen )
{
	Arms[Narm].Join = Movo; (this->*Docbox)(nlen);
}

//	Do assignment into the box
void	Chain::Boxers( int nlen )
{
	//stack data
	CCopy	  copy;
	Tree  =	 00;
	H_go  =	 H0;

	//for skeleton
	if(*Movo < BG)
	{
		//encode this position
		copy.EnMask(this, BG);

		//look over nearest environment
		for(int i = 0; i < _DIR_; i++)
		{
			copy.Retain(this);
			Shrink();
			MvStep(D_go = i);
			if(*Movo < BG) 
				Assign(nlen);
			copy.Repair(this);
		}

		//decode this position
		copy.DeMask(this, BG);

	}
}

/**************************************
	Complicative skeleton functions
**************************************/

//	Watch sprout untill minutiae
void Chain::SkeRes_1(void)
{
	for(int i = 0; i < Route_size; i++)
		*(Route[i]) -= BV;
}
int	Chain::Sprout( int nlen )
{
	//minutiae was found ?
	Route_size = 0;
	if(SkeMin( nlen ) == 0)
		SkeRes_1();//SkeRes( nlen );
	else
	{
		//step back track of the branch
		if (--Head < 0) Head = _SPY_-1;
		
		//this rule to prove the branch
		if(Length() <= tanm( nlen, cone(Alphas(), Beta)))
		{
			SkeDel( nlen );
			Tree++; //event
		}
		else//do not acute
			SkeRes( nlen );
	}

	//a final event
	return	Deal ;
}

//	Direct glance along skeleton
int	Chain::Glance( int nlen )
{
	//get direction
	Route_size = 0;
	SkeDir(nlen);
	ArmDir();
	SkeRes_1();//SkeRes(nlen);

	//a final event
	return	Deal ;
}
//	Follow the link
int	Chain::Follow( int nlen )
{
	//if find minutiae
	if(SkeLin( nlen ))
	{
		ArmArm(		 );
		SkeRes( nlen );
	}
	else//breaken link
	{
		Narm++; //break
		SkeRes( nlen );
	}

		//a final event
		return	Deal ;
}

/**************************************
			Main functions for 
					<Chain> 
					 class
**************************************/

//	Correct short branches
void Chain::Branch( int nlen,int orie )
{
	//correct branches into box
	Docbox = (ti_i)&Chain::Sprout; //UP

	//verify pixel
	Beta = orie;
	Boxers(nlen);

	//verify pixel
	switch (*Movo)
	{
		case BE:
			if(Tree == 1)
                *Movo = BG;
            break;
		case BB:
            if(Tree == 3)
                *Movo = BG;
			else
			{
				if(Tree == 2)
                    *Movo = BE;
				else
				{
					if(Tree == 1)
						*Movo = BS;
				}
			}
			//break;
	}
}

//	Hide branches
void	Chain::Colour( int nlen )
{
	//hide branches of skeleton
	Docbox = (ti_i)&Chain::SkeMrk; //UP

	//verify pixel
	switch (*Movo)
	{
		case BS:	*Movo += BV;
		case BE:
		case BB:	Boxers( nlen );
					break;
	}
}

//	Visual branches
void	Chain::Visual( int nlen )
{
	//show branches of skeleton
	Docbox = (ti_i)&Chain::SkeRes; //UP

	//verify pixel
	switch (*Movo)
	{
		case VS:	*Movo -= BV;///
		case BE:
		case BB:	Boxers( nlen );
					break;
	}
}
//	Measure branches orientation
void Chain::Orient(int nlen)
{
	Narm = 0;  //reset branches
	//direct glance of branches
	Docbox = (ti_i)&Chain::Glance; //UP
	Boxers( nlen );
}
//	Define link connections
void Chain::Morpho( int nlen )
{
	ArmDel();  //reset branches

	//build the link conections
	Docbox = (ti_i)&Chain::Follow; //UP
	Boxers(nlen);
}
//	Define possible crossing
int	Chain::Crossd( int nlen )
{
	ArmDel();//reset all possible branches

	//define four branches
	//Route_size = 0;
	Docend = (tv_v)&Chain::ArmEnd;
	Docbox = (ti_i)&Chain::SkeHid;
	Boxers( nlen );
	Docend = (tv_v)&CBase::Deaden;

	//correct all branches around this box
	if(Narm == 4)
	{
		Docbox = (ti_i)&Chain::SkeRub;
		Boxers( nlen ); //carry out assignment
		//SkeRub(nlen);
		*Movo = BG;  return 1;
	}
	else
	{
		Docbox = (ti_i)&Chain::SkeRev;
		Boxers( nlen ); //carry out assignment
		//SkeRes_1();
		return 0;
	}
}
//	Encode two skeleton chains
void	Chain::Chaine( int nlen )
{
	//build the chain conection
	Docbox = (ti_i)&Chain::EChain; //UP

	//verify pixel
	switch (*Movo)
	{
		case BP:	
		case BL:
		case BR:
		case BS:	*Movo += BV;///
					Boxers( nlen );
					break;
	}
	//code is reserved
	while (2 > Tree++)
			Pack[Lpck++] = BF;///
}

//	Decode two skeleton chains
int	Chain::Chaind( int nlen )
{
	//restore a chain conection
	Docimm = (ti_v)&Chain::DChain; //UP

	//stack data
	CCopy	  copy;
	Tree  =	 00;
	H_go	=	 H0;

	//unwrap two branches of skeleton 
	for (*Movo = BS; Tree < 2; Tree++)
	{
		copy.Retain( this );
		P_go = 0;	UnWrap( nlen,H0 ); if( Pack[Lpck] == BF) Lpck++;
		copy.Repair( this );
	}
	//verify branch
	return	SUCCES;
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
