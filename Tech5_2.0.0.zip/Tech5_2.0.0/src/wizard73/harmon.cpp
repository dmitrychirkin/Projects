/**************************************
				Harmon.cpp
		 Recognize local spectrum.

	  Kernal modified work based on
      patent US 5291426 G06F15/20

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"mathem73.h"
#include		"moulds73.h"
#include		"sorter73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local enumerated type
//-------------------------------------
enum 
{
	_HARM_ = TEMP_T
};

//-------------------------------------
//	Local tune constants
//-------------------------------------
static //const 
 int	Coasis[]	= { 2,6,9},			//+quality,-laplasian,/thershold
				Cpress	=  24,				//press low frequence
				Cconch	= 240,				//adaptation in degree
				Clevel	=  H3,				//native level
				Cdelta	=   3,				//cluster size
				C_mult	= 116,				//scaling
				Cfines	=  67;				//edge penalty (SQR)

//	Pressing models
static const
 byte	Hlaw[] = //for harmons HL..HH
{
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,// 4
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,// 6
	 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,// 8
	16, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	16,16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,//10
	16,16, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	16,16,16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,//12
	16,16,16, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	16,16,16,16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,//14
	16,16,16,16, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	16,16,16,16,16, 0, 0, 0, 0, 0, 0, 0, 0, 0,//16
	16,16,16,16,16, 9, 0, 0, 0, 0, 0, 0, 0, 0
};

/**************************************
		Tune Harmon procedures
**************************************/

//	Kernal tuning
void	CWork::HaTune( int dsth,int srch )
{
	//source
	Srco = GetLay(	_HARM_	,srch );		//temporary
	Snxo = GetLay(	SPEC_S+ 0,srch );		// 4 harmon
	Sexo = GetLay(	SPEC_S+ 1,srch );		// 5 harmon
	Sfno = GetLay(	SPEC_S+ 2,srch );		// 6 harmon
	Swoo = GetLay(	SPEC_S+ 3,srch );		// 7 harmon
	Smoo = GetLay(	SPEC_S+ 4,srch );		// 8 harmon
	Seio = GetLay(	SPEC_S+ 5,srch );		// 9 harmon
	Seao = GetLay(	SPEC_S+ 6,srch );		//10 harmon
	Seco = GetLay(	SPEC_S+ 7,srch );		//11 harmon
	Seeo = GetLay(	SPEC_S+ 8,srch );		//12 harmon
	Semo = GetLay(	SPEC_S+ 9,srch );		//13 harmon
	Sero = GetLay(	SPEC_S+10,srch );		//14 harmon
	Seso = GetLay(	SPEC_S+11,srch );		//15 harmon
	Seuo = GetLay(	SPEC_S+12,srch );		//16 harmon
	Sezo = GetLay(	SPEC_S+13,srch );		//17 harmon
	//destination
	Dsto = GetLay(	PROB_H	,dsth );		//harmon probability
	Dhpo = GetLay(	CONC_H	,dsth );		//harmon concordance
	Dnxo = GetLay(	SPEC_O+ 0,dsth );		// 4 harmon
	Dexo = GetLay(	SPEC_O+ 1,dsth );		// 5 harmon
	Dfno = GetLay(	SPEC_O+ 2,dsth );		// 6 harmon
	Dwoo = GetLay(	SPEC_O+ 3,dsth );		// 7 harmon
	Dmoo = GetLay(	SPEC_O+ 4,dsth );		// 8 harmon
	Deio = GetLay(	SPEC_O+ 5,dsth );		// 9 harmon
	Deao = GetLay(	SPEC_O+ 6,dsth );		//10 harmon
	Deco = GetLay(	SPEC_O+ 7,dsth );		//11 harmon
	Deeo = GetLay(	SPEC_O+ 8,dsth );		//12 harmon
	Demo = GetLay(	SPEC_O+ 9,dsth );		//13 harmon
	Dero = GetLay(	SPEC_O+10,dsth );		//14 harmon
	Deso = GetLay(	SPEC_O+11,dsth );		//15 harmon
	Deuo = GetLay(	SPEC_O+12,dsth );		//16 harmon
	Dezo = GetLay(	SPEC_O+13,dsth );		//17 harmon
}

//	Tune hierarchy projection
void	CWork::HaDeep( int dsth,int srch )
{
	//source
	Srco = GetLay(	_HARM_	,srch );		//temporary
	Snxo = GetLay(	SPEC_O+ 0,srch );		// 4 harmon
	Sexo = GetLay(	SPEC_O+ 1,srch );		// 5 harmon
	Sfno = GetLay(	SPEC_O+ 2,srch );		// 6 harmon
	Swoo = GetLay(	SPEC_O+ 3,srch );		// 7 harmon
	Smoo = GetLay(	SPEC_O+ 4,srch );		// 8 harmon
	Seio = GetLay(	SPEC_O+ 5,srch );		// 9 harmon
	Seao = GetLay(	SPEC_O+ 6,srch );		//10 harmon
	Seco = GetLay(	SPEC_O+ 7,srch );		//11 harmon
	Seeo = GetLay(	SPEC_O+ 8,srch );		//12 harmon
	Semo = GetLay(	SPEC_O+ 9,srch );		//13 harmon
	Sero = GetLay(	SPEC_O+10,srch );		//14 harmon
	Seso = GetLay(	SPEC_O+11,srch );		//15 harmon
	Seuo = GetLay(	SPEC_O+12,srch );		//16 harmon
	Sezo = GetLay(	SPEC_O+13,srch );		//17 harmon
	//destination
	Dsto = GetLay(	_HARM_	,dsth );		//temporary
	Dhpo = GetLay(	DENSIT	,dsth );		//density
	Dnxo = GetLay(	FLOW_E	,dsth );		//expert flow
}

//-------------------------------------
//	Destroy comunications 
//-------------------------------------
template <class T>
static void destroyharmon( T *p )
{
	//clear density sublays
	for (int i = 0; i < _HAR_; i++)
	{
		p->DelLay( SPEC_O+i,p->Eche );
		p->DelLay( SPEC_S+i,p->Eche );
	}
		//delete temporary lays  !
		p->DelLay( _HARM_  ,p->Eche );
}

/**************************************
		Simple inline functions
**************************************/

static inline void _pressQ( int *_Dst,int *_Src)
	{//press low spectrum
	int _Len = HH_Q + 0,
		 _Sup = 1,
		 _Max = 1;

	for (int i = 0; i < HH_Q; i++)
		{//find old extrems
		if(_Sup  < _Src[i])
			_Sup  = _Src[i];
		
		_Dst[i] = _Src[i]*( _Len-i ); //press

		//find new extrem
		if(_Max  < _Dst[i])
			_Max  = _Dst[i];
		}

	for (int j = 0; j < HH_Q; j++)
		{//calc limitations
		_Dst[j] = _Dst[j]*_Sup/_Max;
		}
	}

//	Function to press low spectrum
static inline void _press( int *dst,int *src )
{
	//scanner of frequency of spectrum
	for (int j = 0,we; j < _HAR_; j++)
	{
		//look over spectrum
		int sm = 0;
		for (int i = 0; i < j; i++)
		{
			//find strongest frequency
			if ((we = Hlaw[_HAR_*j +i]))
			{
				//good high frequency ?
				if(sm < (we *= src[i]))
					sm =	we;
			}
		}

		//build new pressed frequency
		dst[j] = MAX( src[j] - sm/Cpress );
	}
}

//	Up some crumbs of harmon
template <class T>
static inline void _crumb( T *p, int *dst,int *src,int args,int harm, bool quick )
{
	//rebuild spectrum for selection
	for (int i = 0; i < _HAR_; i++)
	{
		//measures real window degree
		int an = args*( i+(quick? HL_Q : HL) -harm )/
						  ( 1		+harm );
		//restricts delta disposition
		an = LIM(an, -AR, +AR);
		//simple angle transformation
		if(an < 0)
		{
			an = p->Bresen_LookupSm[-an][-an];
		}
		else
		{
			an = p->Bresen_LookupSm[an][an];
		}
		//rebuilds window of spectrum
		dst[i] = p->Bresen_LookupCm[src[i]][an];
	}
}


//	Measure concordance
static inline void _conco( byte *dst,int *src,int harm, bool quick)
{
	int sm = 0,
		 cn = 0;

	//find tangents
	int goal = 0;
	for (int i = 1,k,c = harm-(quick? HL_Q : HL); i < harm; i++)
	{
		if ((k = c-i) >= 0)
		{
			sm += src[c]-src[k]; cn++;
		}
		if ((k = c+i) < _HAR_)
		{
			sm += src[c]-src[k]; cn++;
		}
		k  = C_mult*sm/( cn*src[c]+cn );

		//both the best
		goal = MAX( goal,k );
	}
	//set the best
	*dst = AR-LIR( goal ); //store
}

/**************************************
	  Kernal work based on prototype:
      patent US 5291426 G06F15/20
**************************************/

//	Get original spectrum
void	CWork::HaGeto( int *dst )
{
	dst[ 0] = *Dnxo;
	dst[ 1] = *Dexo;
	dst[ 2] = *Dfno;
	dst[ 3] = *Dwoo;
	dst[ 4] = *Dmoo;
	dst[ 5] = *Deio;
	dst[ 6] = *Deao;
	dst[ 7] = *Deco;
	dst[ 8] = *Deeo;
	dst[ 9] = *Demo;
	dst[10] = *Dero;
	dst[11] = *Deso;
	dst[12] = *Deuo;
	dst[13] = *Dezo;
}

//	Get rebuilt spectrum
void	CWork::HaGets( int *dst )
{
	dst[ 0] = *Snxo;
	dst[ 1] = *Sexo;
	dst[ 2] = *Sfno;
	dst[ 3] = *Swoo;
	dst[ 4] = *Smoo;
	dst[ 5] = *Seio;
	dst[ 6] = *Seao;
	dst[ 7] = *Seco;
	dst[ 8] = *Seeo;
	dst[ 9] = *Semo;
	dst[10] = *Sero;
	dst[11] = *Seso;
	dst[12] = *Seuo;
	dst[13] = *Sezo;
}

//	Put rebuilt spectrum
void	CWork::HaPuts( int *src )
{
	*Snxo = src[ 0];
	*Sexo = src[ 1];
	*Sfno = src[ 2];
	*Swoo = src[ 3];

	*Smoo = src[ 4];
	*Seio = src[ 5];
	*Seao = src[ 6];
	*Seco = src[ 7];
	*Seeo = src[ 8];
	*Semo = src[ 9];
	*Sero = src[10];
	*Seso = src[11];
	*Seuo = src[12];
	*Sezo = src[13];
}

/**************************************
		Spiral virtual subfunctions
**************************************/

//	Collect laplasian value
void	CWork::HaLapl( int flow,int step )
{
	//harmon ?
	if (*Movo)
	{
		Bask += EVK(*Srco - *Movo);
		Team++;
	}
}

//	Collect harmon
void	CWork::HaNear( int flow,int step )
{
	//harmon ?
	if (*Movo)
	{
		Bask += *Movo;
		Team++; //sum
	}
}

/**************************************
		Base virtual functions
**************************************/

//	Penalty for unhomogeneous
//	Get victory fulcrum
void CWork::HaHerz( void )
{
	//delete harmon
	*Srco = 0;

	//get main herz
	HaGeto(Spec);
   if (quick)
	   _pressQ(Prob,  Spec);
   else
	   _press(Prob,  Spec);
	HaPuts(Prob );
	Tmodah(Prob, Srco, 0, quick);
	if(*Srco)
	{
		Tmodam(Prob, Dsto, Srco, quick);
		++Lord[*Dsto];
	}
}

void CWork::HaLaplV( void )
{
	//harmon ?
	if (*Srco)
	{
		//measure delta
		//Basket();
		Bask = 0;
		Team = 1;
		//DoMove(&Srco );
		Movo = Srco;
		Movx = Srcx;
		Movy = Srcy;
		Spiral(Eche, Clas);
		//scale penalty
		Bask *= 0x02;

		++Rank[*Dhpo = LIM( Bask/Team + Fine*(Seat-Team)/Seat )];
	}
}
//	Clear unhomogeneous area
void	CWork::HaGood( void )
{
	//harmon ?
	if (*Srco)
	{
		//laplasian scaling
		Bask  = *Dhpo*Qual/
						  Thre;
		//prove oasis areas
		if(*Dsto *Coasis[0] - Bask*Coasis[1] < Qual/Coasis[2])
			*Srco = 0;//zero
	}
}

//	Look over neighbourhoods
void	CWork::HaNearV( void )
{
	//set spreading
		 *Dhpo =  0;
	//harmon exist?
	if (*Srco == 0)
	{
		//build density
		DoMove(&Srco );
		Basket(		 );
		Spiral( Eche,
				  Clas );

		//stores result
		if (Team < Clas+3)return;

		//stores result
		*Dhpo = DIP( Bask,Team );

		//localize data
		HaGets( Spec );
		_crumb(this, Prob, Spec, Args, *Dhpo, quick);
		Tmodah( Prob, Dhpo, 0, quick);

		//if past parse
		if (Clas == 0)	return;

		//verify harmon
		Tmodah( Spec, Dhpo,	Dhpo, quick);
	}
}

//	Develops supposed harmon
void	CWork::HaEthe( void )
{
	//harmon ?
	if (*Dhpo)
	{
		*Srco = *Dhpo;
		 Proc = 1;//go
	}
}

//	Get harmon concordance
void	CWork::HaQual( void )
{
	//verify error!
	if(*Srco == 0)
		*Srco = 10;

	//global module
	HaGeto( Spec );
	Tmodam( Spec, Dsto, 0, quick);
	//a concordance
	_conco( Dhpo, Spec, *Srco, quick);
}

//	Try crumbs projection
void	CWork::HaFilt( void )
{
	//localize data
	*Srco = *Dhpo ;
	//to adapt freq
	HaGets( Spec );
	_crumb(this, Prob, Spec, Args, *Srco, quick);
	Tmodah(Prob, Srco, 0, quick);
}

//	Smooth detailed harmon
void	CWork::HaWork( void )
{
	//smooth all
	if(Razors())
		HaImpo();
	else
		HaImpi();
}

//-------------------------------------
//	Upper virtual functions
//-------------------------------------

//	Smooth crumbs of harmon
int	CWork::HaImpi( void )
{
	//build oriented harmon
   if (quick)
      *Dhpo = FiList( Dsto,1,false );
   else
      *Dhpo = Fiimpo(*Dnxo, Dsto );

	return 1;
}

//	Copy crumbs of harmon
int	CWork::HaImpo( void )
{
	*Dhpo = *Dsto;return 1;
}

/**************************************
		Assembly <Harmon> function
**************************************/
void Codex::Harmon(int reih)
{
   if (quick)
   {
      Coasis[0] = 2;
      Coasis[1] = 6;
      Coasis[2] = 10;
   }
   else
   {
      Coasis[0] = 2;
      Coasis[1] = 6;
      Coasis[2] = 9;
   }
	//if the complex waves wasn't build
	if(GetKey( SPEC_O,Clevel ) == -1 )
	{
		//previous works
		Furiew( FurieW );
	}

	//tune in harmon queue
	OldLay(Tops = HARmon);
	Eche = Clevel;
	Fine = Cfines;
	Args = Cconch;
	Clas = Cdelta;
	Reih = (reih);

  	//setup better harmons
	memset(Lord, 0, sizeof(Lord));

	Docvie = (tvii)&CWork::HaTune;
	Docisi = (tv_v)&CWork::HaHerz;
	Scenew(2, Eche, Eche);
	Qual  = LorSha(1) + 1;
		
	//classify homogeneous
	unsigned char *original_Dsto = GetLay(PROB_H, Eche);//harmon probability
	unsigned char *original_Srco = GetLay(_HARM_, Eche);//temporary
	unsigned char *original_Dhpo = GetLay(CONC_H, Eche);//harmon concordance
	Docexe = (tvii)&CWork::HaLapl;
	Redx = MaxX[Eche]; Redy = MaxY[Eche];
	do
	{
		memset(Rank, 0, sizeof(Rank));
		Srco = original_Srco;
		Dhpo = original_Dhpo;
		for(Srcy = 0; Srcy < Redy; Srcy++)
		{
			for(Srcx = 0; Srcx < Redx; Srcx++)
			{
				if(*Srco)
				{
					//measure delta
					Bask = 0; Team = 1;
					Movo = Srco; Movx = Srcx; Movy = Srcy;
					Spiral(Eche, Clas);
					//scale penalty
					Bask *= 0x02;
					//build penalty
					++Rank[*Dhpo = LIM( Bask/Team + Fine*(Seat-Team)/Seat )];
				}
				Srco++; Dhpo++; 
			}
		}
	//define the threshold
	Thre  = RanSha(1) + 1;

	}while (Thre > Qual*2 && (Fine -= 2) > 20);
	Docexe = &CBase::Deaden;

	//delete unhomogeneous
	Srco = original_Srco;
	Dhpo = original_Dhpo;
	Dsto = original_Dsto;
	int value_1 = Qual/Coasis[2];
	int size = Size[Eche];
	for(int i = 0; i < size; i++)
	{
		if (*Srco)
		{
			//laplasian scaling
			Bask  = *Dhpo*Qual/Thre;
			//prove oasis areas
			if(*Dsto *Coasis[0] - Bask*Coasis[1] < value_1)
				*Srco = 0;//zero
		}
		Srco++; Dhpo++; Dsto++;
	}

	//spread oasis density
	do
	{
		//spread homogeneous area
		for (Proc = 1; Proc;)
		{
			//spread homogeneous..
			Docvie = (tvii)&CWork::HaTune;
			Docisi = (tv_v)&CWork::HaNearV;
			Docexe = (tvii)&CWork::HaNear;
			Scenew(2, Eche, Eche);

			Proc = 0;//stop spread

			//up all spreaded area
			Srco = original_Srco;
			Dhpo = original_Dhpo;
			for(int i = 0; i < size; i++)
			{
				if(*Dhpo)
				{
					*Srco = *Dhpo;
					Proc = 1;//go
				}
				Srco++; Dhpo++;
			}
			//previous tiny breath
			if (Clas > 0)	 break;
		}
	}
	while (--Clas >= 0);

	//measures concordance
	Docvie = (tvii)&CWork::HaTune;
	Docisi = (tv_v)&CWork::HaQual;
	Scenew(2, Eche, Eche);

	//do hierarchy projection
	for (Eche = Clevel; Eche > Reih; Eche--)
	{
		//inject harmon crumbs
		Docvie = (tvii)&CWork::HaDeep;
		Docupi = (ti_v)&CWork::HaImpi;
		Docupo = (ti_v)&CWork::HaImpo;
		Docisi =
		Dociso = (tv_v)&CWork::HaFilt;
		Scenei(0,Eche,Eche-1);
	}

	//smooth harmon crumbs
	Docvie = (tvii)&CWork::HaDeep;
	Docisi = (tv_v)&CWork::HaWork;
	Scenew( 2,Eche,Eche );

#ifdef SAVE_LAYERS
   saveLayer("harmon_CONC_H.dat", CONC_H, 3);
   saveLayer("harmon_SPEC_O_0.dat", SPEC_O + 0, 3);
   saveLayer("harmon_SPEC_O_1.dat", SPEC_O + 1, 3);
   saveLayer("harmon_SPEC_O_2.dat", SPEC_O + 2, 3);
   saveLayer("harmon_SPEC_O_3.dat", SPEC_O + 3, 3);
   saveLayer("harmon_SPEC_O_4.dat", SPEC_O + 4, 3);
   saveLayer("harmon_SPEC_O_5.dat", SPEC_O + 5, 3);
   saveLayer("harmon_SPEC_O_6.dat", SPEC_O + 6, 3);
   saveLayer("harmon_SPEC_O_7.dat", SPEC_O + 7, 3);
   saveLayer("harmon_SPEC_O_8.dat", SPEC_O + 8, 3);
   saveLayer("harmon_SPEC_O_9.dat", SPEC_O + 9, 3);
   saveLayer("harmon_SPEC_O_10.dat", SPEC_O + 10, 3);
   saveLayer("harmon_SPEC_O_11.dat", SPEC_O + 11, 3);
   saveLayer("harmon_SPEC_O_12.dat", SPEC_O + 12, 3);
   saveLayer("harmon_SPEC_O_13.dat", SPEC_O + 13, 3);


   saveLayer("harmon__HARM_.dat", _HARM_, 3);
   saveLayer("harmon_DENSIT.dat", DENSIT, 3);
   saveLayer("harmon_FLOW_E.dat", FLOW_E, 3);

   saveLayer("harmon__HARM_2.dat", _HARM_, 2);
   saveLayer("harmon_DENSIT_2.dat", DENSIT, 2);
   saveLayer("harmon_FLOW_E_2.dat", FLOW_E, 2);

   saveLayer("harmon__HARM__1.dat", _HARM_, 1);
   saveLayer("harmon_DENSIT_1.dat", DENSIT, 1);
   saveLayer("harmon_FLOW_E_1.dat", FLOW_E, 1);
#endif
	//destroy temporary links
	for (Eche = reih; Eche <= Clevel; Eche++)
	{
		//destroy a local link
		destroyharmon( this );
	}
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
