/**************************************
				Attrac.cpp
	Set indignations and measure flow.

			 Author Gudkov V.U.
**************************************/
#include		<string.h>

//	Header project file
#include		"inline73.h"
#include		"moulds73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local tune constants
//-------------------------------------
static //const 
int	tabrun[] = {9, 9, 10, 11, 13, 15},
				Clevel	= H3,					//native level
				Cwhirl	=  1,					//focus area
				Cnoise	=  7;					//noise
static //const 
int tabrun_2[] = {6, 6, 7, 8, 9, 11};
/**************************************
		Tune in <Attrac> process
**************************************/

//-------------------------------------
//	Destroy communications 
//-------------------------------------
template <class T>
static void destroyattrac( T *p )
{	
	for (int i = 0; i < 4; i++)
	{
		p->DelLay(LIGHTS + i,H0 );
	}
}

/**************************************
		Simple inline functions
**************************************/

//	Gap function
static inline int ifturn( byte *p )
{
	return *p == FD || *p == FL || *p == FW ;
}

//	Calculate free runner
static inline int	runrun( int hypo,int size )
{
	//if diagonal
	if (hypo & 1)
     	//return cosm( tabrun[size],AQ );
		return tabrun_2[size];
	else
		return tabrun[size]; //OK
}
/**************************************
		Virtual local subfunctions
**************************************/

//	Spread focus area
void	CWork::AtWide( int flow,int step )
{
	//have found focus?
	if (ifturn( Movo ))
	{
		//if found whorl
		if (*Movo &  FW)
			Bask += 8;
		else
		if (step < 8)
			Bask += 1;

		//stores data
		Area = *Movo;
		Orie = *Joff;
	}
}
/**************************************
			Virtual functions
**************************************/

//	Measure stream for areas
void CWork::AtFlowV( void )
{
	//short distance to indignation
	int inum, mini;
	for (inum = 0,mini = 5; inum < Nind; inum++)
	{
		//if an indignation exist
		if (Indi[inum].Type & FF)
		{
			Movx = ABS(Indi_x[inum]-Dstx);
			if(Movx >= mini)
				continue;
			Movy = ABS(Indi_y[inum]-Dsty);
			if(Movy >= mini)
				continue;
			Runs = dist(Movx, Movy);

			//select minimum
			if (mini > Runs)
				 mini = Runs;
		}
	}
	if(mini == 5)
	{
		return;
	}

	//set far free runners
	Runs = runrun( Hypo, mini );

	//forward and backward movement
	for (int anti = 0,best = 0; anti < 8; anti += 4)
	{
		int fwd = updi( Hypo+anti );
		int bck = redi( Hypo+anti );

		//white threads
		ReMove(&Srco );
		MvLayW( fwd,1+Runs/2,0,H0 );
		MvLayW( bck,  Runs,	1,H0 );
		DoKeep(&Prjo );

		//black threads
		ReMove(&Srco );
		MvLayI( fwd,1+Runs/2, 0, H0);
		MvLayI( bck,  Runs,	1, H0);
		DoKeep(&Useo );

		//synchro black
		DoMove(&Prjo );
		DoKeep(&Loco );
		DoMove(&Useo );
		Tr_i = LIM( Cnoise +
				 DIP( MvSynI( fwd,Runs,1,H0 ),Runs));
		Fl_i = uppi(  atan( Usex-Movx,Usey-Movy ));

		//synchro white
		DoMove(&Useo );
		DoKeep(&Loco );
		DoMove(&Prjo );
		Tr_w = LIM( Cnoise +
				 DIP( MvSynW( fwd,Runs,1,H0 ),Runs));
		Fl_w = uppi(  atan( Prjx-Movx,Prjy-Movy ));

		//local favourite
		if (Tr_i >=  best)
		{
			*Dwoo  =  Fl_i;
			*Dmoo  =
			 best  =  Tr_i;
		}
		//local favourite
		if (Tr_w >=  best)
		{
			*Dwoo  =  Fl_w;
			*Dmoo  =
			 best  =  Tr_w;
		}
	}
}

void CWork::AtWideV( void )
{
	//access available ?
	if(*Dnxo)
		return;
	{
		//tuning region
		Bask = 0;
		Joff = Dexo;
		//DoMove(&Dnxo );
		Movo = Dnxo;
		Movx = Srcx;
		Movy = Srcy;

		Spiral( Eche, Clas );

		//is one focus?
		if(Bask == 1 || Bask == 8)
		{
			//mark the area
			*Dexo = Orie;
			*Dnxo = Area | FV;
		}
	}
}

/**************************************
			Register focuses
**************************************/
void	CWork::AtRegi( int *num )
{
	//look throw indignation list
	for (int i = 0; i < *num; i++)
	{
		//check indignations and regist
		if (Indi[i].Movx >= MaxX[0]-1 ||
			 Indi[i].Movx <= 0			||
			 Indi[i].Movy >= MaxY[0]-1 ||
			 Indi[i].Movy <= 0 )	  
		{
			//if no center of image
			if (Indi[i].Type & FF)
			{
				--(*num); //reduce

				//delete a false indignation
				for (int j = i; j < *num; j++)
					Indi[j] = Indi[j+1];

				continue;//skip
			}
		}

		//indignations exist ?
		if (Indi[i].Type & FF)
		{
			//set focus type
			*ProRef( FCLASS,Indi[i].Movx,
								 Indi[i].Movy ) = 
								 Indi[i].Type   ;
			//set focus flow
			*ProRef( FLOW_F,Indi[i].Movx,
								 Indi[i].Movy ) = 
								 Indi[i].Beta   ;
		}
	}
}

/**************************************
		Assemble <Attrac> function
**************************************/
void Codex::Attrac( int reih)
{
   if (quick)
   {
      tabrun[0] = 7;
      tabrun[1] = 8;
      tabrun[2] = 9;
      tabrun[3] = 10;
      tabrun[4] = 11;
      tabrun[5] = 13;

      tabrun_2[0] = cosm( tabrun[0],AQ );
      tabrun_2[1] = cosm( tabrun[1],AQ );
      tabrun_2[2] = cosm( tabrun[2],AQ );;
      tabrun_2[3] = cosm( tabrun[3],AQ );;
      tabrun_2[4] = cosm( tabrun[4],AQ );;
      tabrun_2[5] = cosm( tabrun[5],AQ );;
/*
    	if(Nind == 0)
		{
         if (integ)
   		   Xfocus( XfocuS );
         else
         {
            Stream(StreaM);
         }
		}
*/
   }
   else
   {
      tabrun[0] = 9;
      tabrun[1] = 9;
      tabrun[2] = 10;
      tabrun[3] = 11;
      tabrun[4] = 13;
      tabrun[5] = 15;

      tabrun_2[0] = 6;
      tabrun_2[1] = 6;
      tabrun_2[2] = 7;
      tabrun_2[3] = 8;
      tabrun_2[4] = 9;
      tabrun_2[5] = 11;
   }
	//tune in attrac queue
	OldLay(Tops = ATTrac);
	Eche = Clevel;
	Clas = Cwhirl;

//   if (integ)
   {
	   int i;
	   for(i = 0; i < Nind; i++)
	   {
		   Indi_x[i] = Indi[i].Movx/Side[Eche];
		   Indi_y[i] = Indi[i].Movy/Side[Eche];
	   }
      if (!quick)
      {
	      //measure free runners
	      unsigned char *temp_FR, *temp_PR;
	      for (Hypo = 0; Hypo < 4; Hypo++)
	      {
		      Dwoo = GetLay(Hypo + FLOW_R, Eche);
		      Dmoo = GetLay(Hypo + PROB_R, Eche);
		      temp_FR = GetLay(Hypo + J_FR, Eche);
		      temp_PR = GetLay(Hypo + J_PR, Eche );
		      memmove(Dwoo, temp_FR, Size[Eche]);
		      memmove(Dmoo, temp_PR, Size[Eche]);		
      		
		      Srco = GetLay(Hypo + LIGHTS, H0 );//selected sunlit

            //Docvie = (tvii)&CWork::AtFlow;
	         Docisi = (tv_v)&CWork::AtFlowV;
	         Scenew (1, Eche, H0);		
	      }
      }
   	//prepare compositions
	   unsigned char *original_Dnxo = Dnxo = GetLay(FCLASS, Eche);
	   memset(Dnxo, FN, Size[Eche]);
	   AtRegi(&Nind); //regist
	   DesImp(	  ); //extype

      unsigned char *original_Dexo = Dexo = GetLay(FLOW_F, Eche);
	   Docisi = (tv_v)&CWork::AtWideV;
	   Docexe = (tvii)&CWork::AtWide;
	   Scenew( 2,Eche,Eche );

	   int j, k, step;
	   int back_len_1, back_len_2;
	   unsigned char *old_Srco, *old_Shpo;
	   for(; reih < Eche; reih++)
	   {
		   Dnxo = original_Dnxo; Dexo = original_Dexo;
		   step = Side[Eche]/Side[reih];
		   back_len_1 = step*MaxX[reih]-step; back_len_2 = step*MaxX[reih];
		   old_Srco = Srco = GetLay(FLOW_F, reih );//orientation
		   old_Shpo = Shpo = GetLay(FCLASS, reih );//indignation
		   for(i = 0; i < MaxY[Eche]; i++)
		   {
			   Srco = old_Srco; Shpo = old_Shpo;
			   for(j = 0; j < MaxX[Eche]; j++)
			   {
				   for(k = 0; k < step; k++)
				   {
					   memset(Srco, *Dexo, step); 
                  memset(Shpo, *Dnxo, step);
					   Srco += MaxX[reih]; 
                  Shpo += MaxX[reih];
				   }
				   Srco -= back_len_1; Shpo -= back_len_1;
				   Dnxo++;	Dexo++;
			   }
			   old_Srco += back_len_2; old_Shpo += back_len_2;
		   }
	   }
	   Dnxo=Dexo=Srco=Shpo=0;
   }
//   else
  //    Nind = 0;


	//destroy a local link
	destroyattrac( this );
}


#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
