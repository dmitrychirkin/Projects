/**************************************
				Conver.cpp
		Converter for the system sign.

			Author Gudkov V.U.
**************************************/

//	Header project files
#include		"access73.h"
#include		"inline73.h"
#include		"moulds73.h"
#include		"packed73.h"
#include		"wizard73.h"	
#include		"wibase73.h"	

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

/**************************************
		Structure for compatibility
**************************************/

#ifdef _WINDOWS
#pragma	pack( 1 )
#endif

//	Feature structure
struct	P_PACKED_1 SJoin
{
	word		Movx,								//x position
				Movy;								//y position
	byte		Type,								//type
				Lace,								//scale
				Prob,								//probability
				Beta;								//beta
};

//	Minutiaes structure
struct	P_PACKED_1 SIndi : SJoin
{
	byte		Look,								//look
				Curl;								//curvature
};

#ifdef _WINDOWS
#pragma	pack()
#endif

/**************************************
		Simple inline subfunction
**************************************/

//	Convert density
static inline int harm( int dens, bool quick )
{
	return MAX( dens*HP/10-HP*(quick? HL_Q : HL) );
}

//	Convert quality
static inline int qual( int qual )
{
//	return qual*QH/BA;
	return qual;
}

/**************************************
	Verify the kernal of signs
**************************************/
static int verify( SItem &item,SDisp &disp )
{
	//calculate length
	int length = sizeof( SItem ) -3			  +
					 sizeof( SDisp )				  + 
					 sizeof( SIndi ) *item.PFocus+
					 sizeof( SJoin ) *item.PPoint+
											item.PTotal+
											item.PRidge+
											item.PAreas+
											item.PLinks;

	//calculate displacement
	int dFocus = sizeof( SItem ) +
					 sizeof( SDisp ) -4			  ;
	int dPoint = sizeof( SIndi ) *item.PFocus+
												  dFocus;
	int dTotal = sizeof( SJoin ) *item.PPoint+
												  dPoint;
	int dRidge = 						item.PTotal+
												  dTotal;
	int dAreas = 						item.PRidge+
												  dRidge;
	int dLinks = 						item.PAreas+
												  dAreas;
	
	//check integrity
	if (length != item.Length)
		return -1;
	if (dFocus != disp.DFocus)
		return -2;
	if (dPoint != disp.DPoint)
		return -3;
	if (dTotal != disp.DTotal)
		return -4;
	if (dRidge != disp.DRidge)
		return -5;
	if (dAreas != disp.DAreas)
		return -6;
	if (dLinks != disp.DLinks)
		return -7;
	if (9		  != item.TipNet)
		return -8;
	if (item.VeSign != 70 &&
		 item.VeSign != 71	 )
		 return -9;

		//success
		return 0;
}

/**************************************
	Local convertor of list of sign
**************************************/
template <class T>
static int	Cosign( Codex *p,byte *dst,T *src,int size,int *deg, bool quick )
{
	//prepare bit
	uint nlin = 0,
		  nbit = 0;

	//set conception for bits presentation
	deg[0]= Quants(Tmax_x( src,size ));
	deg[1]= Quants(Tmax_y( src,size ));

	//set conception for some bits
	for (int j = 0; j < 0x08; j++)
	{
		EnBits( dst,&nlin,&nbit,deg[j],4 );
	}

	//packing the list of features
	for (int i = 0; i < size; i++)
	{
		//rebuild struct parameters
		byte	lace	=	harm( src[i].Lace, quick) ;
		byte	prob	=			src[i].Prob   ;
		if (sizeof( src ) == 10) prob = QH ;

		EnBits( dst,&nlin,&nbit,src[i].Movx,deg[0] );
		EnBits( dst,&nlin,&nbit,src[i].Movy,deg[1] );
		EnBits( dst,&nlin,&nbit,src[i].Type,deg[2] );
		EnBits( dst,&nlin,&nbit,		  lace,deg[3] );
		EnBits( dst,&nlin,&nbit,		  prob,deg[4] );
		EnBits( dst,&nlin,&nbit,src[i].Beta,deg[5] );
	}

	//make even the active length
	return nbit ? nlin +1 : nlin;
}

/**************************************
	Local convertor of list of regions
**************************************/
static int	Coarea( Codex *p,byte *dst,byte *src,int size,int type )
{
	int	iind = 4,
			maxx,
			maxy;
	//if it was a small fingerprint
	if (type == 'L' || type == 'F')
	{
		maxx = src[0];		size += 2;
		maxy = src[1];		iind	= 2;
	}
	else
	{
		maxx = src[0] + (src[1]<<8);
		maxy = src[2] + (src[3]<<8);
	}

	//copy old data to new position
	for (int i = 4; i < size; i++)
	{
		dst[i] = src[iind++];
	}

		//save the image size
		p->
		Item.Size_X = maxx*8;
		p->
		Item.Size_Y = maxy*8;

		//save area dimensions
		dst[0] = maxx >> 0  ;
		dst[1] = maxx >> 8  ;
		dst[2] = maxy >> 0  ;
		dst[3] = maxy >> 8  ;
		return	size		  ;
}

/**************************************
	Export container of all sign
**************************************/
int	Codex::Convrt( byte *dst,byte *src,int type )
{
	Item = *((SItem*) src						 );
	Disp = *((SDisp*)(src +sizeof(SItem) -4));

	//check integrity
	if ((What = verify( Item,Disp ))) 
		return What;

	Item.VeSign = VESIGN - 1;
	Item.ImType = ImType = type;
	Item.Qualit = qual( Item.Qualit );
	Item.Densit = harm( Item.Densit, quick );
	Nmin			=		  Item.PPoint  ;
	Deep			=		  Item.TipNet	;

	byte listpi[   500];
	byte listpm[ 20000];
	byte list_t[   300];
	byte list_r[     2];
	byte listpa[ 20000];
	byte link_l[100000];

	//convert indignations
	int dind[]	= {0,0,5,7,6,8,0,0};
	int dmin[]	= {0,0,1,7,8,8,0,0};

	//convert indignations
	Item.PFocus = 
		  PFocus = Cosign( this,listpi,DFocus<SIndi*>( src,4 ),
													 Item.PFocus, dind, quick);
	//convert minutiaes
	Item.PPoint = 
		  PPoint = Cosign( this,listpm,DPoint<SJoin*>( src,4 ),
													 Item.PPoint, dmin, quick);
	//	convert areas
	Item.PAreas = 
		  PAreas = Coarea( this,listpa,DAreas<byte *>( src,4 ),
													 Item.PAreas, type  );
	//convert total
		  PTotal =				
	Item.PTotal = 0; StrSrc( list_t,DTotal<byte *>( src,4 ),PTotal  );
	//	convert ridge
		  PRidge =
	Item.PRidge = 0; StrSrc( list_r,DRidge<byte *>( src,4 ),PRidge  );
	//convert fragment

	//	convert links
		  PLinks =
	Item.PLinks = Convrt(	 link_l,  DPoint<void*>( src,4 ),
												 DLinks<byte*>( src,4 ),
														  Item.PLinks	 );

	//assemble
	{Item.Length =
	 Disp.DUnuse =
	(Disp.DOwner =
	(Disp.DLinks =
	(Disp.DAreas = 
	(Disp.DRidge = 
	(Disp.DTotal = 
	(Disp.DPoint = 
	(Disp.DFocus = sizeof( SItem ) +
						sizeof( SDisp ))+
								 PFocus  )+
								 PPoint  )+
								 PTotal	)+
								 PRidge	)+
								 PAreas	)+
								 PLinks	)+4;}
	//write
	StrDst(
	StrDst(
	StrDst(
	StrDst(
	StrDst(
	StrDst(
	StrDst(
	StrDst( dst,(byte*)&Item,sizeof( SItem )),
					(byte*)&Disp,sizeof( SDisp )),
					listpi,PFocus  ),
					listpm,PPoint  ),
					list_t,PTotal  ),
					list_r,PRidge  ),
					listpa,PAreas  ),
					link_l,PLinks  );

	//protect data
	SetMod( dst );

	return Item.Length;
}

/**************************************
			Convert linkages
**************************************/
int	Codex::Convrt( byte *dst,void *min,byte *lin,int size )
{
	//set conception for bit presentation
	int  mask[]={4,3,2,1,Quants(Nmin-1),
								Quants(
								Quants(Nmin-1))};

	SJoin *pnt = (SJoin*)min;

        //set data
	Pack = dst;
        Nlin = 0;
	Nbit = 0;

	//set conception for some bits
	for (int k = 0; k < 0x06; k++)
	{
		EnBits(Pack,&Nlin,&Nbit,mask[k],4 );
	}
        
        


	int	i,	//net depth
			j,	//arm number
			w;	//byte spy

	//parse list of linkage untill the minutiae
	for (int curr = 0,scan = 0; curr < Nmin && scan < size; curr++)
	{
		//prepare
		GetRid();

		//look over the net
		for (i = 0,w = 0; i < Deep; i++)
		{
			//look over the arms
			for (j = 0; j < _ARM__; j++)
			{
				//read event in buffer
				Link[i].Deal[j] = (lin[scan] >> w) & 3;

				//if byte exausted
				if ((w += 2) == 8)
				{
					scan++;  w = 0;
				}

				//start
				if (!i)
				{
					if (pnt[curr].Type == BE /* one */)
						break;
					if (pnt[curr].Type == BB && j == 2)
						break;
					if (pnt[curr].Type ==  2 && j == 3)
						break;
				}
				else
				if (j)break;
			}
		}

		//not use more
		if (w) scan++;

		//look over the net
		for (i = 0; i < Deep; i++)
		{
			//look over the arms
			for (j = 0; j < _ARM__; j++)
			{
				//does it a broken ?
				if (Link[i].Deal[j])
				{
					//a finger
					if (ImType == 'F' || ImType == 'L')
					{
						Link[i].Item[j] = lin[scan++] << 0;
					}
					else//palm
					{
						Link[i].Item[j] = lin[scan++] << 0;
						Link[i].Item[j]+= lin[scan++] << 8;
					}

					//verify number of minutiae
					if(Link[i].Item[j]>= Nmin)
					{
						Link[i].Item[j] =	-1;
						Link[i].Deal[j] =  0;
					}
				}
			}
		}
		//clear crossing
		if(pnt[curr].Type == 2)
		{
			pnt[curr].Type =  BB;
			for (i = 0,w = 0; i < Deep; i++)
			{
				//look over the arms
				for (j = 0; j < _ARM__; j++)
				{
					//read event in buffer
					Link[i].Item[j] = -1;
					Link[i].Deal[j] =  0;
				}
			}
		}

		int ccb[] = {0,1,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0, 0, 1};
		int cce[] = {1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,-1,-1};
		int lge	 =	 0;

		//kernal to convert
		for (i = 0; i < Deep; i++)
		{
			//look over the arms
			for (j = 0; j < _ARM__; j++)
			{
				//read event in buffer
				if (Link[i].Deal[j] == 0)
					;
				else
				{
					int num = Link[i].Item[j];
					int sim = simu( pnt[num].Beta*2,pnt[curr].Beta*2 );
					int eve = (pnt[curr].Type == BE) ? cce[lge] : ccb[lge];

					if (Link[i].Deal[j] == 1)//right
					{
							Link[i].Deal[j] =  E0;
						if (pnt[num].Type == BE && !sim && eve == 0)
							Link[i].Deal[j] =  E9;
						if (pnt[num].Type == BE &&  sim && eve == 1)
							Link[i].Deal[j] =  E9;
						if (pnt[num].Type == BE &&  sim && eve == 0)
							Link[i].Deal[j] =  Ed;
						if (pnt[num].Type == BE && !sim && eve == 1)
							Link[i].Deal[j] =  Ed;

						if (pnt[num].Type == BB && !sim && eve == 0)
							Link[i].Deal[j] =  E1;
						if (pnt[num].Type == BB &&  sim && eve == 1)
							Link[i].Deal[j] =  E1;
						if (pnt[num].Type == BB &&  sim && eve == 0)
							Link[i].Deal[j] =  E5;
						if (pnt[num].Type == BB && !sim && eve == 1)
							Link[i].Deal[j] =  E5;
					}
					else
					if (Link[i].Deal[j] == 2)//left
					{
							Link[i].Deal[j] =  E0;
						if (pnt[num].Type == BE && !sim && eve == 0)
							Link[i].Deal[j] =  Ea;
						if (pnt[num].Type == BE &&  sim && eve == 1)
							Link[i].Deal[j] =  Ea;
						if (pnt[num].Type == BE &&  sim && eve == 0)
							Link[i].Deal[j] =  Ee;
						if (pnt[num].Type == BE && !sim && eve == 1)
							Link[i].Deal[j] =  Ee;

						if (pnt[num].Type == BB && !sim && eve == 0)
							Link[i].Deal[j] =  E2;
						if (pnt[num].Type == BB &&  sim && eve == 1)
							Link[i].Deal[j] =  E2;
						if (pnt[num].Type == BB &&  sim && eve == 0)
							Link[i].Deal[j] =  E6;
						if (pnt[num].Type == BB && !sim && eve == 1)
							Link[i].Deal[j] =  E6;
					}
					else
					if (Link[i].Deal[j] == 3)//point
					{
						int nmore[] = {-1,3,4,5,6,7,8,-1,-1};
							Link[i].Deal[j] =  E0;
						if (pnt[num].Type == BE)
							Link[i].Deal[j] =  Ef;
						else
						if (pnt[num].Type == BB && !sim && eve == 0)
							Link[i].Deal[j] =  E3;
						else
						if (pnt[num].Type == BB &&  sim && eve == 1)
							Link[i].Deal[j] =  E3;
					}
				}

				lge++;
				//start
				if (!i)
				{
					if (pnt[curr].Type == BE /* one */)
						break;
					if (pnt[curr].Type == BB && j == 2)
						break;
				}
				else
				if (j)break;
			}
		}

		//save linkages
		LiSave( pnt[curr].Type,
				  mask );
	}

	//make even the active length
	return Nbit ? Nlin +1 : Nlin;
}


#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
