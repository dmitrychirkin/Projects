/**************************************
				 Swells.cpp
			Swell pattern flow.

			Author Gudkov V.U.
***************************************/

//	Header project file
#include		"assert.h"
#include		"mathem73.h"
#include		"moulds73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local definitions
//-------------------------------------
enum
{
	_SOUR_ = TEMP_T,
	_FLOW_,
	_PROB_
};

//-------------------------------------
//	Local tune constants
//-------------------------------------
static const 
 int	C_qual[] = {92,85},			//quality loss
				Clevel	=  H3,				//native level
				Corder	=   4,				//man orders
				Cfocus	=	 2,				//focus area
				C_iter	=   3;				//iterations

//	Wave mask to calculate situation
static const
byte	mask[] = 
{
	0,  0,  0,  0,  0,  0,  0, 26,  0, 27,  0,  0,  0,  0, 28, 27, //   0
	0, 20, 29,  0,  0,  0,  0, 42,  0,  0,  0, 44, 30, 46, 29, 28, //  16
	0, 21, 22,  0, 31,  0,  0, 34,  0,  0,  0,  0,  0,  0, 44, 44, //  32
	0,  0,  0, 36,  0,  0, 46, 34, 16, 40, 32, 40, 31, 39, 30, 29, //  48
	0,  0, 23,  0, 24,  0,  0, 42, 17,  0,  0,  0,  0,  0, 36, 35, //  64
	0,  0,  0,  0,  0, 66,  0,  0,  0,  0,  0,  0, 46,  0, 46, 36, //  80
	0,  0,  0, 38,  0,  0, 32, 34,  0,  0,  0,  0, 32,  0, 36, 73, //  96
  18, 34, 42, 42, 34,  0, 42, 34, 17, 34, 41, 67, 16, 40, 31, 46, // 112
	0,  0,  0, 24, 25,  0,  0, 25, 26,  0,  0, 40,  0, 42, 44, 26, // 128
  19,  0,  0, 32,  0,  0,  0, 42,  0, 36,  0, 32, 38, 38, 37, 27, // 144
	0,  0,  0, 40,  0,  0,  0, 33,  0,  0, 64,  0,  0,  0,  0, 34, // 160
	0, 36,  0, 32,  0,  0,  0, 75, 32, 40,  0, 32, 32, 77, 38, 44, // 176
	0, 22,  0, 23,  0, 38, 40, 24,  0, 46,  0, 40, 32, 46, 36, 25, // 192
	0, 38,  0, 47,  0,  0,  0, 32, 34, 46,  0, 69, 38, 38, 79, 42, // 208
  20, 21, 36, 22, 44, 38, 44, 23, 36, 45,  0, 46, 44, 71, 36, 40, // 224
  19, 20, 36, 21, 43, 44, 65, 38, 18, 19, 42, 36, 17, 34, 32, 64  // 240
};

/**************************************
			Tune communications
**************************************/

//	Tune to generate wavelet flow
void	CWork::SwTune( int dsth,int srch )
{
	Srco = GetLay(	CCLASS,srch );			//common class
	Shpo = GetLay(	FLOW_L,srch );			//local flow
	Snxo = GetLay(	PROB_L,srch );			//local probability
	Sexo = GetLay(	FLOW_F,srch );			//focus alpha
	Sfno = GetLay(	_SOUR_,srch );			//source
	Seio = GetLay(	DORDER,srch );			//man direction
	Dsto = GetLay(	FLOW_P,dsth );			//pattern flow
   Dnxo = GetLay(	FCLASS,dsth );			//focus class
	Dwoo = GetLay(	_FLOW_,dsth );			//new flow
	Dmoo = GetLay(	_PROB_,dsth );			//new probability
}

//-------------------------------------
//	Destroy communications
//-------------------------------------
template <class T>
static void destroyswells( T *p )
{
	p->DelLay( _SOUR_,p->Eche );
	p->DelLay( _FLOW_,p->Eche );
	p->DelLay( _PROB_,p->Eche );
}

/**************************************
				Gap function
**************************************/
static inline int	ifturn( byte *p )
{
	return *p == FD ||
			 *p == FL ||
			 *p == FW;
}

/**************************************
		Virtual local subfunctions
**************************************/

//	Write pattern focus flow
int	CWork::SwFlow( int step )
{
	int i = petx( Orie ),
		 d = 0,  //direction..
		 n = 0;  //the part of

	//indignation?
   if (integ)
   {
	   switch (*Dnxo)
	   {
		   case FD:	d = Delta[i]+ *Sexo*2; n = 1;	
					   break;
		   case FL:	d = Loops[i]+ *Sexo*2; n = 1;
					   break;
		   case FW:	d = Whorl[i]+ *Sexo*2; n = 2;
					   break;
	   }
   }
	//set flow
	if (!Cont)
	{
		//renew flow
		d  +=  Bask;
		//mark model
		*Joff |= C5;
		//store flow
		*Movo = uppi( d + Corn[ 
								scis( Flow[i],d )+AR ]/n );
	}
	else//turn
	if (!step)
	{
		Team++;	 Bask += scis( Flow[i],d );
	}
	//continue
	return  0;
}

//	Do scheme for pattern flow
void CWork::Scheme( void )
{
	//look around regions and collect information
	int im = 0, re = 0;
	for (int i = 0; i < _DIR_; i++)
	{
		//previous step was found ?
		if (*(Sfno+Vide[i]) < Star)
		{
			//measure an event
			Case	 +=  1 << i;
			//a characteristic
			re += Scheme_LookupCm[*(Dsto+Vide[i])];
			im += Scheme_LookupSm[*(Dsto+Vide[i])];
		}
	}

	//verifies mask
	if (mask[Case])
	{
		//estimate the model orientation
		Args = atan(re, im)/2;
		Hypo = Corn[scis(Args, *Dsto) + AR];

		//adaptate flow
		if (*Srco & C4)
			Hypo = uppi( Args - Hypo/1 );
		else
      {
         if (quick)
			   Hypo = uppi( Args - Hypo/2 );
         else
			   Hypo = uppi( Args - Hypo/3 );
      }
		//get frontal attack orientation
		Orie = (mask[Case] & 0xf)*AF/16;

		//verifies frontal attack sector
		if (cone( Orie,Args ) >= Open )
		{
			//put a model
			*Dsto = Hypo;
			*Sfno = Star;
		}
	}
}
/**************************************
			Virtual functions
**************************************/

//	Prepare pattern flow
void	CWork::SwPrep( void )
{
	//gain foot-hold
	if(*Srco &   CG)
		*Srco |=  C4;

		//reset model
		*Srco &= ~C5;
		*Dsto  = *Shpo;
}

//	Set model of indignation
void CWork::SwFlowV( void )
{
	//access available?
	if (ifturn( Dnxo ))
	{
		//measure flows
		//DoMove(&Snxo );
		//DoLink(&Joff );
		Joff = Snxo;

		//DoMove(&Sexo );
		//DoKeep(&Useo );
	    Useo = Sexo;
		Usex = Srcx;
		Usey = Srcy;

		//DoMove(&Shpo);
		Movo = Shpo;
		Movx = Srcx;
		Movy = Srcy;

		//Treset( Re_v );
		memset(Re_v, 0, sizeof(Re_v));
		//Treset( Im_v );
		memset(Im_v, 0, sizeof(Im_v));

		Spiral( Eche, Clas, 0x02 );
		Targum( Re_v, Im_v, Flow, Shpo );
		//reset turning
		Basket();
	}
	else
		return;  //exit

	//get turning of indignation
	for (Cont = 1,Orie = 0; Orie < AF; Orie += AQ)
	{
		//DoMove(&Srco );
		//DoLink(&Joff );
		Joff = Srco;
		//DoMove(&Dsto );
		Movo = Dsto;
		Movx = Srcx;
		Movy = Srcy;

		Bresen(upco(*Sexo*2 + Orie ), 2, Eche);
	}

	//cutoff indignation turning
	Bask = Corn[ Bask/Team+AR ];

	//do around indignation flow
	for (Cont = 0,Orie = 0; Orie < AF; Orie += AQ)
	{
		//DoMove(&Srco );
		//DoLink(&Joff );
		Joff = Srco;
		//DoMove(&Dsto );
		Movo = Dsto;
		Movx = Srcx;
		Movy = Srcy;

		Bresen(upco(*Sexo*2 + Orie ), 2, Eche);
	}
}
//	Set man order
//void	CWork::SOrder( void )
//{
//	//gain a foot-hold
//	if(*Seio  <  BM)
//	{
//		*Dsto  = *Seio;
//		*Srco |=  C5;
//	}
//
//	//collect models
//	if(*Srco &   C5)
//		 Cont++;
//}

//	Set start source
void	CWork::SwSour( void )
{	
   if (quick)
   {
	   //can believe?
	   if(*Srco & C5)
		   *Sfno =  0;
	   else
	   if(*Srco & C4)
		   *Sfno =  0;
	   else
		   *Sfno = BM;
   }
   else
   {
	   //sense man order
	   if(Cont < Corder)
	   {
		   //can believe?
		   if(*Srco & C5)
			   *Sfno =  0;
		   else
		   if(*Srco & C4)
			   *Sfno =  0;
		   else
			   *Sfno = BM;
	   }
	   else//indignation
		   if(*Srco & C5)
			   *Sfno =  0;
		   else//free
			   *Sfno = BM;
   }
}

//	Build frontier wave
void	CWork::Swellw( void )
{
	//is free region?
	if(*Sfno >  Star)
	{
		//read facet of rectangle
		if (!FaRect( Srcx,Srcy ))

		{
			Case	=  0;	Scheme(  );
		}
		else
		{
			*Sfno = FiMirr( Sfno );
			*Dsto = FiMirr( Dsto );
		}
	}
}

//	Accept the wave
void	CWork::SwTake( void )
{
	//accept frontier
	if(*Sfno == Star)
	{
		*Sfno =  0;
		 GoOn =  1;
	}
}

//	Re-join original regularity
void CWork::SwJoin( void )
{
	//upgrade flows
	Imax = GemReg_I( Dwoo, Dmoo, *Dsto );

	//a local delta
	Args = scis(*Dwoo, *Dsto);
	//local quality
	Thre += Imin = Bresen_LookupCm[*Dmoo][upci(2*Args)];

	//select the flow tolerance
	if (*Srco & C2)	Case = 1;
	else
	if (*Srco & C3)	Case = 0;
	else return  ;

	//if current deflexion large
	if (Imin > PER(Imax, C_qual[Case]))
		*Srco |=  C4;
	else
		*Srco &= ~C4;
}
//	Set the best flow
void	CWork::SwBest( void )
{
	//work backloop
	*Shpo =  *Dwoo;
	*Snxo =  *Dmoo;

	//leave a model
	if (*Srco & C5)
		return;

	//work backloop
	*Dsto =  *Shpo;
}

/**************************************
		Assembly <Swells> function
**************************************/
void Codex::Swellw_edges_1(int tempt_Indx, int tempt_Redx, int tempt_Dedx)
{
	int j;
    if(*Sfno > Star)
	{
		*Sfno = *(Sfno + tempt_Indx);
		*Dsto = *(Dsto + tempt_Indx);
	}
	Sfno++; Dsto++;
	for(j = 2; j < MaxX[Eche]; j++)
	{
		if(*Sfno > Star)
		{
			*Sfno = *(Sfno + tempt_Redx);
			*Dsto = *(Dsto + tempt_Redx);
		}
		Sfno++; Dsto++;
	}
	if(*Sfno > Star)
	{
		*Sfno = *(Sfno + tempt_Dedx);
		*Dsto = *(Dsto + tempt_Dedx);
	}
	Sfno++; Dsto++;
}

void Codex::Swellw_edges_2(int tempt_Indx, int tempt_Redx, int tempt_Dedx)
{
	int j;
	if(*Sfno > Star)
	{
		*Sfno = *(Sfno - tempt_Dedx);
		*Dsto = *(Dsto - tempt_Dedx);
	}
	Sfno++; Dsto++;
	for(j = 2; j < MaxX[Eche]; j++)
	{
		if(*Sfno > Star)
		{
			*Sfno = *(Sfno - tempt_Redx);
			*Dsto = *(Dsto - tempt_Redx);
		}
		Sfno++; Dsto++;
	}
	if(*Sfno > Star)
	{
		*Sfno = *(Sfno - tempt_Indx);
		*Dsto = *(Dsto - tempt_Indx);
	}

}
void Codex::Swellw_inner()
{
	for(int j = 2; j < MaxY[Eche]; j++)
	{
        if(*Sfno > Star)
		{
			*Sfno = *(Sfno + 1);
			*Dsto = *(Dsto + 1);
		}
		Srco++;	Sfno++; Dsto++;
		for(int k = 2; k < MaxX[Eche]; k++)
		{
			if(*Sfno > Star)
			{
				Case = 0;
				Scheme();
			}
			Srco++;	Sfno++; Dsto++;
		}
        if(*Sfno > Star)
		{
			*Sfno = *(Sfno - 1);
			*Dsto = *(Dsto - 1);
		}
		Srco++;	Sfno++; Dsto++;
	}
}

void Codex::Swells( int reih )
{
	//restore wavelet flow to original
	int ang[] = {4, 0,0, 11,9, 64,6, AR, 0};

	//if indignations absent
	if (GetKey( FCLASS,Clevel ) == -1)
	{
		//previous works
		Attrac( AttraC );
	}

	//tune in swells queue
	OldLay( Tops=SWElls );
	Clas=Cfocus;
	WiRect(Eche=Clevel, 0);

	//tune in swells groop
	Sets[Tops] = Cont = 0;

	//transform corner low
	CorGau(ang);CorSmo(4);

	//prepare pattern flow
	unsigned char *original_Srco = Srco = GetLay(CCLASS, Eche);
	unsigned char *original_Shpo = Shpo = GetLay(FLOW_L, Eche);//local flow
	unsigned char *original_Snxo = GetLay(PROB_L, Eche);//local probability
	unsigned char *original_Sfno = Sfno = GetLay(_SOUR_, Eche);			//source
	unsigned char *original_Dsto = Dsto = GetLay(FLOW_P, Eche);//pattern flow
	unsigned char *original_Dwoo = GetLay(_FLOW_, Eche);//new flow
	unsigned char *original_Dmoo = GetLay(_PROB_, Eche);//new probability
	unsigned char *original_PR_4[4], *original_FR_4[4];
#ifdef SAVE_LAYERS
   saveLayer("swells_CCLASS_3_0.dat", CCLASS, 3);
   saveLayer("swells_FLOW_L_3_0.dat", FLOW_L, 3);
   saveLayer("swells_FLOW_P_3_0.dat", FLOW_P, 3);
   saveLayer("swells_PROB_R_3_0.dat", PROB_R + 0, 3);
   saveLayer("swells_PROB_R_3_1.dat", PROB_R + 1, 3);
   saveLayer("swells_PROB_R_3_2.dat", PROB_R + 2, 3);
   saveLayer("swells_PROB_R_3_3.dat", PROB_R + 3, 3);
   saveLayer("swells_FLOW_R_3_0.dat", FLOW_R + 0, 3);
   saveLayer("swells_FLOW_R_3_1.dat", FLOW_R + 1, 3);
   saveLayer("swells_FLOW_R_3_2.dat", FLOW_R + 2, 3);
   saveLayer("swells_FLOW_R_3_3.dat", FLOW_R + 3, 3);
#endif
	int i;
	for(i = 0; i < 4; i++)
	{
		original_PR_4[i] = GetLay(PROB_R+i, Eche);
		original_FR_4[i] = GetLay(FLOW_R+i, Eche);
	}

	memmove(Dsto, Shpo, Size[Eche]);
	
	for(i = 0; i < Size[Eche]; i++)
	{
        if(*Srco & CG)
            *Srco |= C4;
		Srco++;
	}
#ifdef SAVE_LAYERS
   saveLayer("swells_FLOW_P_3_1.dat", FLOW_P, 3);
#endif
   if (!quick && integ)
//   if (!quick)
   {
	   //model of indignation
	   Docvie = (tvii)&CWork::SwTune;
	   Docisi = (tv_v)&CWork::SwFlowV;
      Docexe = (tvii)&CWork::Argums_quick;
	   Docbre = (ti_i)&CWork::SwFlow;
	   Scener	(Eche);
   }
#ifdef SAVE_LAYERS
   saveLayer("swells_FLOW_P_3_2.dat", FLOW_P, 3);
#endif
	//recognize man orders
   if (!quick)
   {
	   Srco = original_Srco;
	   for(i = 0; i < Size[Eche]; i++)
	   {
           if(*Srco & C5)
               Cont++;
           Srco++;
	   }
   }
#ifdef SAVE_LAYERS
   saveLayer("swells_FLOW_P_3_3.dat", FLOW_P, 3);
#endif

   //while gradient growth ! 
	int tempt_Indx = MaxX[Eche] + 1;
	int tempt_Redx = MaxX[Eche];
	int tempt_Dedx = MaxX[Eche] - 1;
	bool temp_bool = (Cont < Corder);
	for (i = C_iter; i; )
	{
		//build wavelet source
		Sfno = original_Sfno;
		Srco = original_Srco;
		int j = 0;
		for(; j < Size[Eche]; j++)
		{
//         if (quick)
         if (integ)
         {
	         if(*Srco & C5)
		         *Sfno =  0;
            else 
            {
	            if(*Srco & C4)
		            *Sfno =  0;
	            else
		            *Sfno = BM;
            }
         }
         else
         {
            if(*Srco & C4)
	            *Sfno =  0;
            else
	            *Sfno = BM;
         }

/*         else
         {
			   if(*Srco & C5)	
               *Sfno =  0;
			   else
			   {
				   if(temp_bool)
				   {
					   if(*Srco & C4) *Sfno =  0;
					   else *Sfno = BM;
				   }
				   else *Sfno = BM;
			   }
         }
*/
			Srco++;	Sfno++;
		}

		//develop sources wave
		for (Open = 66,Star = 7,GoOn = 1; GoOn || Open;)
		{
			GoOn = 0;		// stop

			//develop the frontier

			Sfno = original_Sfno;
			Dsto = original_Dsto;
			Srco = original_Srco + tempt_Redx;
			
			Swellw_edges_1(tempt_Indx, tempt_Redx, tempt_Dedx);
			Swellw_inner();
			Swellw_edges_2(tempt_Indx, tempt_Redx, tempt_Dedx);

			//then accept frontier
			Sfno = original_Sfno;
			for(int j = 0; j < Size[Eche]; j++)
			{
                if(*Sfno == Star)
				{ *Sfno = 0; GoOn = 1; }
				Sfno++;
			}

			//open working sectors
			if (Open)	Open -= 2;
		}

		//iteration exhausted?
		if (!(--i)) break;
		Thre =  0;

		//regulate local flows
		Dmoo = original_Dmoo; Dwoo = original_Dwoo;
		Dsto = original_Dsto; Srco = original_Srco;
		memmove(PR_4, original_PR_4, 4*sizeof(unsigned char *));
		memmove(FR_4, original_FR_4, 4*sizeof(unsigned char *));
		for(j = 0; j < Size[Eche]; j++)
		{
			SwJoin();
			Dmoo++; Dwoo++; Dsto++; Srco++;
			PR_4[0]++; PR_4[1]++; PR_4[2]++; PR_4[3]++;
			FR_4[0]++; FR_4[1]++; FR_4[2]++; FR_4[3]++;
		}

		//check growth of quality 
		if (Sets[SWElls] >  Thre)
			 break;
		else
		{
			//set extremum quality
			Sets[SWElls]  =  Thre;

			memmove(original_Shpo, original_Dwoo, Size[Eche]);
			memmove(original_Snxo, original_Dmoo, Size[Eche]);
			Srco = original_Srco; Shpo = original_Shpo;
			Dsto = original_Dsto;
			for(int j = 0; j < Size[Eche]; j++)
			{
                if(!(*Srco & C5))
					*Dsto =  *Shpo;;
				Shpo++; Srco++; Dsto++;
			}
		}
	}
#ifdef SAVE_LAYERS
   bool res = true;
   res = saveLayer("swells_FLOW_P_3_4.dat", FLOW_P, 3);
   res = saveLayer("swells_FCLASS_3.dat", FCLASS, 3);
#endif
	//destroy a local link
	destroyswells( this );
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
