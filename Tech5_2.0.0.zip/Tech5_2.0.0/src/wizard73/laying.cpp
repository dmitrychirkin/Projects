/**************************************
				 Laying.cpp
		 Laying out the pattern.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"mathem73.h"
#include		"moulds73.h"
#include		"sorter73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local enumerated type
//-------------------------------------
enum 
{
	_TEMP_ =	TEMP_T,
	_MATH_		
};

//-------------------------------------
//	Local tune constants
//-------------------------------------
static //const 
 int	Cfills[] = {53,17},			//filling max,min
				Clevel	=  H3,				//level
				CQuali	= 131,				//quality
				Crange[] = {255,180,300};	//classify
/**************************************
		Tune Laying procedures
**************************************/

//	Tune complicative metric
void	CWork::LaTune( int dsth,int srch )
{
	Srco = GetLay(	NORMAL,srch );			//normalized
	Dsto = GetLay(	CCLASS,dsth );			//common class
	Dhpo = GetLay(	QUAL_E,dsth );			//quality
	Dexo = GetLay(	_MATH_,dsth );			//ground
}

//	Tune group procedure
void	CWork::LaArea( int dsth,int srch )
{
	Srco = GetLay(	CCLASS,srch );			//common class
	Shpo = GetLay( _MATH_,srch );			//ground
	Snxo = GetLay(	MORDER,srch );			//man's class
	Dsto = GetLay(	_TEMP_,dsth );			//temporary
	Dhpo = GetLay(	QUAL_E,dsth );			//quality
	Dnxo = GetLay(	GOAL_F,dsth );			//filter goal
	Deio = GetLay(	GOAL_R,dsth );			//ridge goal
}

//	Tune to do projection
void	CWork::LaDeep( int dsth,int srch )
{
	Srco = GetLay(	 CCLASS,srch );		//common class
	Dsto = GetLay(	 CCLASS,dsth );		//common class
}

//-------------------------------------
//	Destroy comunications
//-------------------------------------
template <class T>
static void destroylaying( T *p )
{
	p->DelLay( _TEMP_,p->Eche );
	p->DelLay( _MATH_,p->Eche );
}

/**************************************
			Rules to classify
**************************************/

//	Rule to build paper histogram
static inline int	histog( byte *src,byte *qua, bool quick)
{
	//local data
	int qang = MAX(*qua - BA)*AR/BA;
	int sang = *src*AR/BM;
	//some paper
   if (quick)
   	return cogm( sigm( BM,sang ), qang );
   else
      return cogm( cogm( sigm(BM, sang), qang), qang);
}
//	Reconstruction while grouping
static inline void recogn( byte *dst,int info,int seat )
{
	//gets filling
	int fill= CHA(seat- info+1, info);

	//a rich image
	if (fill > Cfills[0])
		*dst = 2;
	else//no image
	if (fill < Cfills[1])
		*dst = 0;
	else//frontier
		*dst = 1;
}

/**************************************
		Recignize paper threshold
**************************************/
void	CWork::LaDoor( void )
{
	int prob = Crange[0];
	int hill = Crange[2];

	//find first maximum
	for (int i = SRANK-1; i > Crange[1]; i--)
	{
		//if step by step up
		if (Rank[i] > hill)
		{
			prob = i;//save
			hill = Rank[i];
		}
		else//hill was found
		if (hill > Crange[2])
			break;
	}

	//reduce it
	hill /=  3;

	//get indent on the slope
	int j;
	for (j = prob; j > Crange[1]; j--)
	{
		//if slope end
		if (Rank[j] < hill)
		{
			break;
		}
	}

	//the final probability
	Thre = MAX( 2*j-prob );
}

/**************************************
		Virtual cluster functions
**************************************/

//	Collect nearest shpere
void	CWork::Sphere( int flow,int step )
{
	//check an environment
	if ((*Movo & CZ) == 0)
	{
		//inner area!
		if (step < 8)
			++Inna;
		else
			++Outa;
	}
}


//	Find local maximum and minimum
void	CWork::MaxMin( int flow,int step )
{
	//find maximum...
	if (Imax < *Movo)
		 Imax = *Movo;

	//find minimum...
	if (Imin > *Movo)
		 Imin = *Movo;
}

/**************************************
		Virtual kernal functions
**************************************/

void CWork::LaRank(void)
{
	int step = Side[Eche]/Side[H0];
//	int back_len_1 = MaxX[H0] - step;
//	int back_len_2 = step*MaxX[H0] - step;
//	int back_len_3 = (step-1)*MaxX[H0];
   int step1 = MaxX[H0] * step;
   int step2 = step;
   int step3 = MaxX[H0];
	Reax = MaxX[Eche]; Reay = MaxY[Eche];
	int i, j, k, m;
	bool good;	
   byte *save1 = Srco;
   byte *save2 = Srco;
   byte *save3 = Srco;
	for(i = 0; i < Reay; i++)
	{		
      save1 = Srco;
		for(j = 0; j < Reax; j++)
		{
			if(*Dhpo > CQuali) good = true;
			else good = false;
         save2 = Srco;
			for(k = 0; k < step; k++)
			{
            save3 = Srco;
				for(m = 0; m < step; m++)
				{
					if(good) --Rank[histog(Srco, Dhpo, quick)];
					else ++Rank[histog(Srco, Dhpo, quick)];
					Srco++; 
				}
//				Srco += back_len_1;
            save3 += step3;
            Srco = save3;
			}
//			Srco -= back_len_2; 
         Dhpo++;
         save2 += step2;
         Srco = save2;
		}
//		Srco += back_len_3;
      save1 += step1;
      Srco = save1;
	}
}
void CWork::LaMarkPaper(void)
{
	Reax = MaxX[Eche]; Reay = MaxY[Eche];
	int step = Side[Eche]/Side[H0];
//	int back_len_1 = MaxX[H0] - step;
//	int back_len_2 = step*MaxX[H0] - step;
//	int back_len_3 = (step-1)*MaxX[H0];
   int step1 = MaxX[H0] * step;
   int step2 = step;
   int step3 = MaxX[H0];

	int i, j, k, m;
	Team = step*step;
   byte *save1 = Srco, *save2 = Srco, *save3 = Srco;
	for(i = 0; i < Reay; i++)
	{	
      save1 = Srco;
		for(j = 0; j < Reax; j++)
		{
			Bask = 0;
         save2 = Srco;
			for(k = 0; k < step; k++)
			{
            save3 = Srco;
				for(m = 0; m < step; m++)
				{
					//if(Eche == Clevel) Bask += *Deio;
					Bask += histog(Srco, Dhpo, quick);
					Srco++;
				}
//				Srco += back_len_1;
            save3 += step3;
            Srco = save3;
			}
			*Dexo = DIP(Bask, Team);
			if(Eche == Clevel)
			{
				*Dsto &= ~CA;
				if(*Dexo > Thre) *Dsto |= C1;
			}
//			Srco -= back_len_2; Dhpo++; Dexo++; Dsto++;
//			Srco -= back_len_2; 
         save2 += step2;
         Srco = save2;

         Dhpo++; Dexo++; Dsto++;
		}
//		Srco += back_len_3;
      save1 += step1;
      Srco = save1;
	}
}

//	Group inner regions
void	CWork::LaEyei( void )
{
	//exclude if previous marked
	if (*Srco & C1 && Bits & C7)
		return;

	//measure local environments
	int u = FiBite( Srco,Bits );

	//if image
   if (quick)
   {
  	   if (3 > u)
		   *Dsto = 0;
	   else//edge
	   if (u > 5)
		   *Dsto = 2;
	   else
		   *Dsto = 1;
   }
   else
   {
	   if (2 > u)
		   *Dsto = 0;
	   else//edge
	   if (7 > u)
		   LaEyeo( );
	   else//area
		   *Dsto = 2;
   }
}

//	Group frontier regions
void	CWork::LaEyeo( void )
{
	//exclude if previous marked
	if (*Srco & C1 && Bits & C7)
		return;

	//mark frontier
	DoMove(&Srco );
	Tmidst(*Srco&
			   Bits,
			  &Inna,
			  &Outa );
	Spiral( Eche,
			  Clas );
	recogn( Dsto,
			  Inna+
			  Outa,
			  Seat );
}

//	Remark frontier regions
void	CWork::LaMark( void )
{
	//exclude if previous marked
	if (*Srco & C1 && Bits & C7)
		return;

	//build cluster
	int	size	 = H4-Clas,
			papa[] = {7,2,9},
			zone[] = {4,1,9};
   if (quick)
   {
      papa[0] = 9;
      papa[1] = 1;
      papa[2] = 9;
      zone[0] = 4;
      zone[1] = 4;
      zone[2] = 9;
   }
   else
   {
      papa[0] = 7;
      papa[1] = 2;
      papa[2] = 9;
      zone[0] = 4;
      zone[1] = 1;
      zone[2] = 9;
   }

	//rich region ?
	if (*Dsto == 2)
		*Srco |=  Bits;
	else//the image
	if (*Dsto == 0)
		*Srco &= ~Bits;
	else//look area
	if (Bits == C1)
	{
		//adaptate area
		DoMove(&Shpo );
		DoMami(*Movo );
		Spiral( Eche,
				  size );

		//remark paper area for pattern
		if(less( *Shpo,FiDoor( papa )))
			*Srco |=  Bits;
		else
			*Srco &= ~Bits;
	}
	else
	{
		//adaptate area
		DoMove(&Dhpo );
		DoMami(*Movo );
		Spiral( Eche,
				  size );

		//remark zone  area for pattern
		if(more( *Dhpo,FiDoor( zone )))
			*Srco |=  Bits;
		else
			*Srco &= ~Bits;
	}
}

//	Do class projection
void	CWork::LaInje( void )
{
	//if first paper
	if (Bits ==	 C1)
		*Srco = *Dsto;
	else//the bearer
	if(*Srco &	 C1)
		return; //out
	else//set region
	if(*Dsto &   C7)
		*Srco |=  C7;
}

//	Mark bad areas
void	CWork::LaAreaV( void )
{
	//this nothing bearer?
	if ((*Srco & C1) == 0)
	{
		//under threshold?
		if(*Dhpo >   Thre)
			*Srco &= ~Bits;
		else
			*Srco |=  Bits;
	}
}

/**************************************
		Assembly <Laying> function
**************************************/
//	Execute man order & activate
void Codex::Laying( int reih )
{
   CQuali    = 131;
   Cfills[0] = 53;
   Cfills[1] = 17;

   //if was not professional findings
	if (GetKey(DENS_M, Clevel) == -1)
	{
		//previous works
		Expert(ExperT);
	}
	//tune in laying queue
	OldLay(Tops = LAYing);
	Eche = Clevel;
	Reih = (reih);
	//RanIni(0);
	memset(Rank, 0, sizeof(Rank));

	unsigned char *original_Srco = GetLay(NORMAL, H0);//normalized
	unsigned char *original_Dhpo = GetLay(QUAL_E, Eche);//quality
	Srco = original_Srco; Dhpo = original_Dhpo;
	//get Rank[]
	LaRank();
	//recognizes trustable
	RanSmo(1); RanSmo(5); RanSmo(3); LaDoor();
	unsigned char *original_CClass[4];
	for(int i = 1; i <= 3; i++)
	{original_CClass[i] = GetLay(CCLASS, i);}
	//unsigned char *original_Temp;

	//relaxing paper in every hierarchy
	for(Eche = Clevel,Bits = C1; Eche >= Reih; Eche--)
	{
		//junior hierarchy
		if (Eche < Clevel)
		{
			//copy senior - junior
			Docvie = (tvii)&CWork::LaDeep;
			Docisi = (tv_v)&CWork::LaInje;
			Scenew(0, Eche+1,Eche);
		}

		//build paper's metric
		if(Eche == Clevel) Dhpo = original_Dhpo;
		else Dhpo = GetLay(QUAL_E, Eche);
		Srco = original_Srco;
		Dexo = GetLay(_MATH_, Eche);//ground
		//Dsto = GetLay(CCLASS, Eche);//common class
		Dsto = original_CClass[Eche];
		LaMarkPaper();

		//remark frontier, then group paper
		for (Clas = Eche; Clas > 0; Clas--)
		{
	 		//group the paper area
			Docvie = (tvii)&CWork::LaArea;
			Docisi = (tv_v)&CWork::LaEyei;
			Dociso = (tv_v)&CWork::LaEyeo;
			Docexe = (tvii)&CWork::Sphere;
			Scenei( 2,Eche,Eche );

			//up a grouping result
			Docvie = (tvii)&CWork::LaArea;
			Docisi = (tv_v)&CWork::LaMark;
			Docexe = (tvii)&CWork::MaxMin;
			Scenew( 2,Eche,Eche );
		}
	}

	//preparing zone
   if (quick)
      Thre = CQuali+0;
   else
      Thre = CQuali+1;

	//relaxing bad zone in every hierarchy
	for (Eche = Clevel,Bits = C7; Eche >= reih; Eche--)
	{
		//junior hierarchy
		if (Eche < Clevel)
		{
			//copy senior - junior
			Docvie = (tvii)&CWork::LaDeep;
			Docisi = (tv_v)&CWork::LaInje;
			Scenew(0,Eche+1,Eche);
		}
		else
		{
			//mark unclear regions
			Docvie = (tvii)&CWork::LaArea;
			Docisi = (tv_v)&CWork::LaAreaV;
			Scenew( 2,Eche,Eche );
		}

		//remark frontier, then group areas
		for (Clas = Eche; Clas > 0; Clas--)
		{
	 		//grouping region area
			Docvie = (tvii)&CWork::LaArea;
			Docisi = (tv_v)&CWork::LaEyei;
			Dociso = (tv_v)&CWork::LaEyeo;
			Docexe = (tvii)&CWork::Sphere;
			Scenei( 2,Eche,Eche );

			//up a grouping result
			Docvie = (tvii)&CWork::LaArea;
			Docisi = (tv_v)&CWork::LaMark;
			Docexe = (tvii)&CWork::MaxMin;
			Scenew( 2,Eche,Eche );
		}

		//activate & up orders
		//Docvie = (tvii)&CWork::LaArea;
		//Docisi = (tv_v)&CWork::LOrder;
		//Scenew(2, Eche, Eche);
		Srco = original_CClass[Eche];
		Dnxo = GetLay(GOAL_F, Eche);//filter goal
		Deio = GetLay(GOAL_R, Eche);//ridge goal
		memset(Dnxo, 0, Size[Eche]);
		memset(Deio, 0, Size[Eche]);
		for(int i = 0; i < Size[Eche]; i++)
		{
            if((*Srco & CZ) == 0)
			{
				*Srco |= C6;
			}
			Srco++;
		}
	}

	//erase temporary link
	for(Eche = Clevel; Eche >= Reih; Eche--)
	{
		//destroy a local link
		destroylaying(this);
	}
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
