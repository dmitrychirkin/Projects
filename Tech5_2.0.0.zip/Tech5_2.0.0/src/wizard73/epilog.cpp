/**************************************
				Epilog.cpp
	  Measure image & focus scale.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"access73.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local tune constants
//-------------------------------------
static  const 
int	Clevel =  H3,					//native level
				Cwhirl =   4;					//claster size

/**************************************
		Tune Epilog procedures
**************************************/

//	Tune kernal procedure
void	CWork::EpTune( int dsth,int srch )
{
	Srco = GetLay(	CCLASS,srch );			//c-class
	Pack = GetLay( LIST_A,dsth );			//packing
}

//	Tune projection
void	CWork::EpDeep( int dsth,int srch )
{
	Srco = GetLay( MORDER,srch );			//man's order
	Dsto = GetLay( MORDER,dsth );			//man's order
}

//-------------------------------------
//	Destroy comunications 
//-------------------------------------
template <class T>
static void destroyepilog( T *p )
{
	for(int i = 0; i < 4; i++)
	{
		p->DelLay(J_FR + i, H3);
		p->DelLay(J_PR + i, H3);
	}
}
/**************************************
		Collect original density
**************************************/
void	CWork::EpHarm( int flow,int step )
{
	//read original harmon 
	if ((*Joff & CZ) == 0)
	{
		Qran += *Movo;
		Team++; //sum
		Pran += *Hoff;
	}	
		Qran += *Movo;
		Team++; //sum
		Pran += *Hoff;
}

/**************************************
			Virtual functions
**************************************/

//	Collect detailed regions
void	CWork::EpZone( void )
{
	if ((*Srco & CZ) == 0)
		Bask++;
	else
		Bask--;
}

//	Prepare regions
int	CWork::EpPrep( void )
{
	//regions
	Basket();
	return 1;
}

//	Write list of regions
void	CWork::EpList( void )
{
	//write list of regions
	while ((Calc -= BM) > 0)
	{
		Pack[Lpck++] = BM;
		Pack[Lpck++] =  0;
	}

	//add remainder of list
	Pack[Lpck++] = Calc +BM;

	//adapt new region info
	Calc = 1;  Qual = !Qual;
}

//	Pack regions of image
void	CWork::EpPack( void )
{
	//good area ?
	if (Bask > 0)
	{
		//continue ?
		if (Qual)
			Calc++;
		else//a list
			EpList();
	}
	else//bad area
	{
		//continue ?
		if (!Qual)
			Calc++;
		else//a list
			EpList();
	}
}

//	Set region projection
void	CWork::EpDeepV( void )
{
	*Srco = *Dsto;
}

/**************************************
	Measure density for indignations
**************************************/
void	CWork::IScale( void )
{
	//look over indignations list
	for (int i = 0; i < Nind; ++i)
	{
		//mount class to analize field
		ProLay( CCLASS,Indi[i].Movx,
							Indi[i].Movy );
		DoLink(&Joff );

		//seek to region quality field
		ProLay( QUAL_M,Indi[i].Movx,
							Indi[i].Movy );
		DoLink(&Hoff );

		//set density to analize field
		ProLay( DENS_M,Indi[i].Movx,
							Indi[i].Movy );
		//collects area
		Basket(		 );
		Rreset(		 );
		Spiral( Eche,
				  Clas );

		//store density of indignation
		Indi[i].Lace = DIP(Qran,Team);
		Indi[i].Prob = DIP(Pran,Team);
	}
}

/**************************************
		Assemble <Epilog> function
**************************************/
void Codex::Epilog(int reih)
{	
   bool moTemplate = false;
   if (!moTemplate)
   {
      if(GetKey( LISTpL,H1 ) == -1) //linkages were extracted ?
      {
         Linker( LinkeR ); //previous works
      }
   }
	//tune in epilog queue
	OldLay( Tops=EPIlog );
   Eche=Clevel;
   Clas=Cwhirl	;

	//measure total metric
	PTotal = Rtotal();//OK

	//indignations density
	Docexe = (tvii)&CWork::EpHarm;
	IScale(); //large area
//		Centre(); //new center

	//free place for x & y
	Lpck= 4;Qual= Calc= 0;
/*
   if (quick) // correct information to right DPI
   {
      // correct the minutiae information
      for(int i = 0; i < Nmin; i++) 
      {
            Sign[i].Movx = (int)( Sign[i].Movx * K_CHANGE_DPI);
            Sign[i].Movy = (int)( Sign[i].Movy * K_CHANGE_DPI);
      }
      // correct the singularity information
      for(int i = 0; i < Nind; i++) 
      {
            Indi[i].Movx = (int)( Indi[i].Movx * K_CHANGE_DPI);
            Indi[i].Movy = (int)( Indi[i].Movy * K_CHANGE_DPI);
      }
      // correct the bad zone information
      int newX = (int)(MaxX[0] * K_CHANGE_DPI);
      newX  = (newX + 3) / 4 * 4;
 		newX = newX / 2 +  newX % 2;
 		newX = newX / 2 +  newX % 2;
 		newX = newX / 2 +  newX % 2;

      int newY = (int)(MaxY[0] * K_CHANGE_DPI);
      newY = (newY + 3) / 4 * 4;
 		newY = newY / 2 +  newY % 2;
 		newY = newY / 2 +  newY % 2;
 		newY = newY / 2 +  newY % 2;
      correctBadArea(newX, newY);
   }
   else
*/
   {
	   //pack pattern regions
	   Docvie = (tvii)&CWork::EpTune;
	   Docisi = (tv_v)&CWork::EpZone;
	   Docupi = (ti_v)&CWork::EpPrep;
	   Docfni = (tv_v)&CWork::EpPack;
	   Scenew(  0,Eche,H1  );
	   EpList(); PAreas=Lpck;

	   //store lay dimensions
	   Pack[0]=MaxX[Eche]>>0;
	   Pack[1]=MaxX[Eche]>>8;
	   Pack[2]=MaxY[Eche]>>0;
	   Pack[3]=MaxY[Eche]>>8;
   }
#ifdef SAVE_LAYERS
   saveLayer("epilog_LIST_A.dat", LIST_A, 3);
#endif

	//destroy a local link
	if(Whether_Pattern)
        destroyepilog( this );
}
/*
void Codex::correctBadArea(int newX, int newY) 
{
    byte *newArea = new byte[newX * newY];
    if (!newArea)
        return;
    int locX = 0, locY = 0;
    byte *p = 0;
    int count = 0;
	int y = 0;
    for(; y < newY; y++)
    {
        locY = (int)(y / K_CHANGE_DPI);
        for(int x = 0; x < newX; x++)
        {
            locX = (int)(x / K_CHANGE_DPI);
            p = ProRef	(CCLASS, locX, locY, 3, 3);
            if (*p & CZ)
                newArea[count++] = C7;
            else
                newArea[count++] = C6;
        }
    }
	Pack = newArea;	
	Lpck= 4;Qual= Calc= 0;
    count = 0;
    for(y = 0; y < newY; y++)
    {
        for(int x = 0; x < newX; x++)
        {
            if (newArea[count++] == C6)
                Bask = 1;
            else
                Bask = 0;
            EpPack ();
        }
    }
    EpList(); PAreas=Lpck;

	//store lay dimensions
	Pack[0]=newX >> 0;
	Pack[1]=newX >> 8;
	Pack[2]=newY >> 0;
	Pack[3]=newY >> 8;

    StrDst (GetLay (LIST_A, H3), newArea, PAreas);

    if (newArea)
        delete newArea;
}
*/
/**************************************
		  Try to unpack regions
**************************************/

//	Decode list of areas
int	Codex::DeArea( byte *dst,byte *src )
{
	//do local data
	uint  temp = QAreas<uint >( src ),
			lpck = 4,
			qual = 0;
	//local pointer
	byte *pack = DAreas<byte*>( src ),
		  *movo = dst;	

	//verify length
	if(temp < lpck)
		return RUINED;

	//restore x&y dimension
	Reax = (pack[1] << 8) +
			  pack[0]	    ;
	Reay = (pack[3] << 8) +
			  pack[2]	    ;

	//tune the first length
	uint	size = Reax*Reay,
			calc = pack[lpck++ ];

	//unpack
	for (uint i  = 0; i < size; i++)
	{
		//if end phase
		if (calc == 0)
		{
			qual = !qual; temp--;
			calc =  pack[lpck++];
		}
		//if end phase
		if (calc == 0)
		{
			qual = !qual; temp--;
			calc =  pack[lpck++];
		}
		//unwrap
		if (calc)
		{
			//mark an area
			if (qual == 0)
				*movo = C7;
			else
				*movo = C6;

			//advance data
				 movo++;
				 calc--;
		}
	}

	//verify the list
	return temp == 5 ? SUCCES : 
							 RUINED ;
}

//	Import region list to rebuild
int	Codex::DeArea( byte *src )
{
	//default destination for regions
	Dsto = GetLay( MORDER,Eche = H3 );

	//if could unpack list of regions
	if (DeArea( Dsto,src ) == SUCCES)
	{
		//perform hierarchy projection
		for (Reih = H1; Reih < Eche; Reih++)
		{
			//do simple projection
			Docvie = (tvii)&CWork::EpDeep;
			Docisi = (tv_v)&CWork::EpDeepV;
			Scenew( 0,Eche,Reih );
		}
	}
	else
		return RUINED;
		//that success
		return SUCCES;
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
