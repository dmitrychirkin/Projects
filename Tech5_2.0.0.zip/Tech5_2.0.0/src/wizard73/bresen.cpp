/**************************************
				Bresen.cpp
    Bresenham's moving algorithm.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"assert.h"
#include		"wizard73.h"
#include		"wibase73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

//-------------------------------------
//	Local tune constants
//-------------------------------------
static const
byte mask[ ]= 
{
	1,  1,  1,  2,  1,  0, 34,  0,  1,  1,  1,  2, 34,  0,  0,  0, //   0
	1,  1,  1,  2,  0,  0,  0,  0, 66, 66, 66,  0,  0,  0,  0,  0, //  16
	1,  1,  1,  2,  1,  0, 34,  0,  1,  0,  0,  0, 34,  0,  0,  0, //  32
  66, 66, 66,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, //  48
	1,  0,  1,  0,  1,  0, 34,  0,  1,  0,  0,  0, 34,  0,  0,  0, //  64
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, //  80
  98,  0, 98,  0, 98,  0,  0,  0, 98,  0,  0,  0,  0,  0,  0,  0, //  96
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, // 112
	1,  2,  1,  0,  1,  0, 34,  0,  1,  2,  0,  0, 34,  0,  0,  0, // 128
	1,  2,  0,  0,  0,  0,  0,  0, 66,  0,  0,  0,  0,  0,  0,  0, // 144
	1,  2,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, // 160
  66,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, // 176
  98,  0, 98,  0, 98,  0,  0,  0, 98,  0,  0,  0,  0,  0,  0,  0, // 192
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, // 208
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, // 224
	0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0  // 240
};

/**************************************
	Bresenham's kernal subfunctions
**************************************/

//	Check movement limit
int 	Coral::Margin( void )
{
	return Movx > Limx ||
			 Movy > Limy ||
			 Movx < 0    ||
			 Movy < 0;
}

//	Calculate moving parameters
void	Coral::Pitchs( int hier )
{
	//image limitation..
	Limx = MaxX[hier]-1;
	Limy = MaxY[hier]-1;

	//pitches & services
	Oinc = MaxX[hier]-0;
	Xinc = 1;
	Yinc = 1;
	Deal =
	Cnti = 0;

	//correct pitches
	if (Difx < 0)
		Xinc = -Xinc;
	if (Dify < 0)
	{
		Yinc = -Yinc;
		Oinc = -Oinc;
	}

	//if steep steps
	if (Absx > Absy)
	{
		Binc = Absy+Absy;
		Dexp = Binc-Absx;
		Ainc = Absy-Absx;
	}
	else//if abrupt
	{
		Binc = Absx+Absx;
		Dexp = Binc-Absy;
		Ainc = Absx-Absy;
	}

	//final value
	Ainc += Ainc;
}

//	The kernal of Bresenham's movement
void	Coral::Bresen( void )
{
	//if steep line


	if (Absx > Absy)
	{
		//untill the end
		for (;Absx; Absx--,Cnti++)
		{
			//do always
			Joff += Xinc;
			Hoff += Xinc;
			Noff += Xinc;
			Eoff += Xinc;
			Movo += Xinc;
			Movx += Xinc;

			//check sign of movement
			if (Dexp < 0)
				Dexp += Binc;
			else
			{
				//do sometimes
				Dexp += Ainc;
				Joff += Oinc;
				Hoff += Oinc;
				Noff += Oinc;
				Eoff += Oinc;
				Movo += Oinc;
				Movy += Yinc;
			}
			
			//check all image borders
			if (Margin())
				return;

			if((this->*Docbre)(Cnti))
				return;
		}
	}
	else
	{
		//do something
		for (;Absy; Absy--,Cnti++)
		{
			//do always
			Joff += Oinc;
			Hoff += Oinc;
			Noff += Oinc;
			Eoff += Oinc;
			Movo += Oinc;
			Movy += Yinc;

			//check sign of movement
			if (Dexp < 0)
				Dexp += Binc;
			else
			{
				//do sometimes
				Dexp += Ainc;
				Joff += Xinc;
				Hoff += Xinc;
				Noff += Xinc;
				Eoff += Xinc;
				Movo += Xinc;
				Movx += Xinc;
			}

			//check all image borders

			if (Margin())
				return;
			if((this->*Docbre)(Cnti))
				return;
		}
	}
}

//	The quick Bresenham's movement
void  Coral::Bresen( SStep *web )
{
	//if steep line
	if (Absx > Absy)
	{
		//untill the end
		for (; Cnti < Absx; Cnti++)
		{
			//do always
			Movo += Xinc;
			Movx += Xinc;

			//check sign of movement
			if (Dexp < 0)
				Dexp += Binc;
			else
			{
				//do sometimes
				Dexp += Ainc;
				Movo += Oinc;
				Movy += Yinc;
			}

			//if web exist -> new position
			if (web)
			{
				web[Cnti].Movx = Movx;
				web[Cnti].Movy = Movy;
				web[Cnti].IncO = (int_t)Movo;
			}
		}
	}
	else
	{
		//untill the end
		for (; Cnti < Absy; Cnti++)
		{
			//do always
			Movo += Oinc;
			Movy += Yinc;

			//check sign of movement
			if (Dexp < 0)
				Dexp += Binc;
			else
			{
				//do sometimes
				Dexp += Ainc;
				Movo += Xinc;
				Movx += Xinc;
			}

			//if web exist -> new position
			if (web)
			{

				web[Cnti].Movx = Movx;
				web[Cnti].Movy = Movy;
				web[Cnti].IncO = (int_t)Movo;
			}
		}
	}

	//if web exist -> end position
	if (web)
	{
		web[Cnti].Movx =
		web[Cnti].Movy = 0;
		web[Cnti].IncO = (int_t)0;	 //end
	}
}

/**************************************
		Bresenham's moving functions
**************************************/

//	Bresenham's algorithm from source to destination
int	Coral::Bresen( int desx,int desy,int soux,int souy,int hier )
{
	//calculate movement data
	Absx = ABS( Difx =desx-
							soux );
	Absy = ABS( Dify =desy-
							souy );

	//carry out the movements
	Pitchs( hier ); Bresen();
	return  Cnti;	//quantity
}

//	Bresenham's algorithm for direction
int	Coral::Bresen( int flow,int lens,int hier )
{
	//calculate movement data
	Difx = Bresen_LookupCm[lens][upci(flow)];//cosm( lens,flow );	
	Dify = Bresen_LookupSm[lens][upci(flow)];
	Absx = ABS ( Difx );//abs
	Absy = ABS ( Dify );//abs

	//carry out the movements
	Pitchs( hier ); 
	Bresen();
	return  Cnti;	//quantity
}

//	Quick Bresenham's algorithm
int	Coral::Breweb( int flow,int lens,int hier,SStep *web )
{
	//calculate movement data
	Difx = Bresen_LookupCm[lens][upci(flow)];
	Dify = Bresen_LookupSm[lens][upci(flow)];

	Absx = ABS ( Difx );//abs
	Absy = ABS ( Dify );//abs

	//carry out the movements
	Pitchs(hier);
	Bresen(web);

	return  Cnti;	//quantity
}
int	Coral::Breweb_Furiew(int flow, int lens,int hier, SStep *web)
{
	//calculate movement data
	Difx = Bresen_LookupCm[lens][upci(flow)];
	Dify = Bresen_LookupSm[lens][upci(flow)];

	Absx = ABS( Difx );//abs
	Absy = ABS( Dify );//abs

	//carry out the movements
	Pitchs(hier);
	Bresen_Furiew(web);

	return  Cnti;	//quantity
}
void Coral::Bresen_Furiew(SStep *web)
{
	//if steep line
	if (Absx > Absy)
	{
		//untill the end
		for (; Cnti < Absx; Cnti++)
		{
			//do always
			Movo += Xinc;
			//Movx += Xinc;

			//check sign of movement
			if (Dexp < 0)
				Dexp += Binc;
			else
			{
				//do sometimes
				Dexp += Ainc;
				Movo += Oinc;
				//Movy += Yinc;
			}

			//if web exist -> new position
			if (web)
			{
				//web[Cnti].Movx = Movx;
				//web[Cnti].Movy = Movy;
				web[Cnti].IncO = (int_t)Movo;
			}
		}
	}
	else
	{
		//untill the end
		for (; Cnti < Absy; Cnti++)
		{
			//do always
			Movo += Oinc;
			//Movy += Yinc;

			//check sign of movement
			if (Dexp < 0)
				Dexp += Binc;
			else
			{
				//do sometimes
				Dexp += Ainc;
				Movo += Xinc;
				//Movx += Xinc;
			}

			//if web exist -> new position
			if (web)
			{

				//web[Cnti].Movx = Movx;
				//web[Cnti].Movy = Movy;
				web[Cnti].IncO = (int_t)Movo;
			}
		}
	}

	//if web exist -> end position
	if (web)
	{
		//web[Cnti].Movx =
		//web[Cnti].Movy =
		web[Cnti].IncO = 0;	 //end
	}
}
//	Futher injection Bresenham's algorithm
int	Coral::Breinj( int flow,int lens,int hier,SStep *web )
{
	//calculate movement data
	Difx+= cosm( lens,flow );
	Dify+= sinm( lens,flow );
	Absx = ABS ( Difx );//abs
	Absy = ABS ( Dify );//abs

	//do a special injections
	Bresen(web); return Cnti;
}

/**************************************
				Functions
		 to process skeleton
**************************************/

//	Catch sceleton
int	Coral::SkeSkeI( int step )
{
	//check pixel
	switch(*Movo)
	{
		case BS:
			DoKeep(&Useo );
			Deal = 1;
			return 1;//found
		case VP:
		case VL:
		case VR:
		case VS:
		case BG:
			return 0;//gap
		default:	
			return 1;//stop
	}
}
//	Find skeleton ending
int	Coral::SkeEndI( int step )
{	
	//check pixel
	switch( *Movo )
	{
		case BE: DoKeep(&Useo );
			Deal = 1;
			return 1;//found
		case BG:	
			return 0;//gap
		default:	
			return 1;//stop
	}
}

//	Catch outward area
int	Coral::SkeOutI( int step )
{
	//check pixel
	switch( *Movo )
	{
		case BM: Deal = 1;//found
			return 1;
		default:	
			return 0;//goon
	}
}

//	Draw skeleton
int	Coral::SkeSet( int step )
{
	//if outward area
	if ( *Movo == BM)
		//stop draw
		return   1;

	//parameters..
	int	msk = 1,
			env = 0;

	//look around small environment
	for (int d = 0; d < _DIR_; d++)
	{
		//read pixel for translation
		if (*(Movo + Vide[d]) <= BS)
			//add index
			env += msk;

			//next mask
			msk += msk;
	}

	//if the skeleton
	if ( mask[ env ] & 1)
		//set pixel
		*Movo = BS;
	if ( mask[ env ] & 2)
	{
		byte *curr = Movo+Vide[ mask[ env ]>>4 ];
		//set pixel
		*Movo = BS;
		*curr = BG;
	}

		//continue!
		return   0;
}

//-------------------------------------
//		Block of upper functions
//			to process sceleton
//-------------------------------------

//	Catch the skeleton
int	Coral::SkeSke( int flow,int lens,int hier )
{
	Docbre = (ti_i)&Coral::SkeSkeI; 
	Bresen( flow,lens,hier ); 
	return Deal;
}

//	Find skeleton end
int	Coral::SkeEnd( int flow,int lens,int hier )
{
	Docbre = (ti_i)&Coral::SkeEndI; 
	Bresen( flow,lens,hier ); 
	return Deal;

}

//	Catch the outwar area
int	Coral::SkeOut( int flow,int lens,int hier )
{
	Docbre = (ti_i)&Coral::SkeOutI; 
	Bresen( flow,lens,hier ); 
	return Deal;
}

/**************************************
	Draw sceleton from moving position
**************************************/
void	Coral::Pastes( int desx,int desy )
{
	(this->*(Docbre=(ti_i)&Coral::SkeSet))(0);
	Bresen( desx,desy,Movx,Movy,  H0);
}


#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
