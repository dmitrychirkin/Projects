/**************************************
				Expres.cpp
	Express estimation of the nests.

			Author Gudkov V.U.
**************************************/

//	Header project files
#include		"mathem73.h"
#include		"search73.h"
#include		"virtue73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

/**************************************
		Estimates indignation area
**************************************/
int	CKnow::Expres( CNest *dst,CNest *src )
{
	//reset entries
	int	goin = 0,
			size,
			azim,
			beta,
			i,j ;

	//look over sour-indignations
	for (i = 0; i < src->Gene; i++)
	{
		//set up the sour-geometry 
		SGeom *srg = &src->Geom[i];

		//look over dest-indignations
		for (j = 0; j < dst->Gene; j++)
		{
			//set up the dest-geometry
			SGeom *dsg = &dst->Geom[j];

			//gets distance difference
			if (srg->Size > dsg->Size)
				 size	= (srg->Size-dsg->Size) - dsg->Size/4 - 
															  TbFine(0);
			else
				 size	= (dsg->Size-srg->Size) - srg->Size/4 - 
															  TbFine(0);

				 //gets vector rotation
				 azim	= coor( srg->Azim,dsg->Azim ) -  //rule
															  TbFine(1);
				 beta	= coor( srg->Beta,dsg->Beta ) -	//rule
															  TbFine(2);

			//look any type of indignation
			switch (srg->Type + dsg->Type)
			{
				case  2:	//whorl-whorl
							if (size > 0 || azim > 0)	continue;
							break;
				case  3: //whorl-loop
							if (size > 0 || azim > 0)	continue;
							break;
				case  4: //loop-loop
							if (size > 0 || beta > 0)	continue;
							break;
				case 16:	//delta-delta
							if (size > 0 || azim > 0)	continue;
							break;
				default:										continue;
			}
			//setup the veil
			srg->Type |= FV;
			dsg->Type |= FV;
		}
	}
	
	//verify free sour-indignations
	for (i = 0; i < src->Gene; i++)
	{
		//set up the sour-geometry 
		SGeom *srg = &src->Geom[i];

		//verify free dest-indignations
		for (j = 0; j < dst->Gene; j++)
		{
			//set up the dest-geometry
			SGeom *dsg = &dst->Geom[j];

			//look any type of indignation
			switch (srg->Type + dsg->Type)
			{
				case  2:
				case  3:
				case  4:
				case 16: goin++;
				default: break ;
			}
		}
	}

	//restore sour-indignations
	for (i = 0; i < src->Gene; src->Geom[i++].Type &= ~FV);

	//restore dest-indignations
	for (j = 0; j < dst->Gene; dst->Geom[j++].Type &= ~FV);
	
	//the entries;
	return	goin;
}

/**************************************
		Build the first candidates
**************************************/
int	CKnow::Expres( void )
{
	//pair nest
	CNest	*dst,
			*src;

	//preparing
	Disp = 0x0;
	Head =
	Tail = 0x0;

	//look throw the list of icon nests
	for (uint i = 0; i < Icon.Nmin; i++)
	{
		//do base source nest and verify
		if(!(src = &Icon.Nest[i])->Gene)
			return 0;

		//look throw the list of test nests
		for (uint j = 0; j < Test.Nmin; j++)
		{
			//do destination nest and verify
			if(!(dst = &Test.Nest[j])->Gene)
				return 0;

			//express analysis for minutiae candidates
			if (Expres( dst,src ) == 0 && Head < _KEY_)
			{
				Cand[Head  ].CapI = src;
				Cand[Head++].CapT = dst;
			}
		}
	}

	//candidates
	return Head;
}


#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
