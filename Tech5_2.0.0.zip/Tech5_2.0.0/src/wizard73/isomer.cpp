/**************************************
				Isomer.cpp
		Build hyper & multy graph.

			Author Gudkov V.U.
**************************************/

//	Header project files
#include		"access73.h"
#include		"moulds73.h"
#include		"search73.h"
#include		"virtue73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

/**************************************
		Local inline functions
**************************************/

//	Get distance between two points
static inline int	resize( CNest &dst,CNest &src )
{
	return Tdists( dst,src )*_MUL_/src.Harm;

}

//	Gap function for hyperarc
static inline int hyarch( CNest *con,word next,int narc )
{
	return con->Deal[0][next]	  &&
			 con->Prox && narc < _HYP_;
}

//	Gap function for conquer
static inline int conque( CNest *con,CNest *src,word next )
{
	return con->Pink[0][next]	  &&
			 con->Deal[0][next]	  &&
			 con->Tree[0][next]->Nord != src->Nord;
}

//	Gap function for crossing
static inline int across( CNest *dst,CNest *src,word iden,word link )
{
	return src->Pink[0][link]	  &&
			 dst->Pink[0][iden];
}

//	Calculate the mirror
static inline int mirror( CNest *dst,word iden )
{
	return dst->Type == BE ? EndCro[iden] : BifCro[iden];
}

/**************************************
			Prepare virtual nests
**************************************/
void	CArch::Resets( char *tab, CNest *dst,CNest *src )
{
	//reset all alternative links in to nest
	for (register int i = 0; i < src->Wnet; i++)
	{
		//resets alternative branches..
		for (register int u = 1; u < _VIR_; u++)
		{
			src->Tree[u][i] = 00;
			src->Item[u][i] =
			src->Size[u][i] =
			src->Fine[u][i] =
			src->Pink[u][i] =
			src->Deal[u][i] = E0;
		}
	}

	//reset all alternative links in to nest
	for (register int j = 0; j < dst->Wnet; j++)
	{
		//resets alternative branches..
		for (register int u = 1; u < _VIR_; u++)
		{
			dst->Tree[u][j] = 00;
			dst->Item[u][j] =
			dst->Size[u][j] =
			dst->Fine[u][j] =
			dst->Pink[u][j] =
			dst->Deal[u][j] = E0;
		}
	}
}

/**************************************
			Generate multi - graph
		for first & second mutation.
**************************************/

//	Extend one virtual multi-arch
void	CArch::MuArch( char *tab,CNest *net,word link,byte even,word fine )
{
	//link out of the nest?
	if (tab[link] < net->Wnet)
	{
		//find free position in the nest
		for (int u = 1; u < _VIR_; u++ )
		{
			//if free virtual possibility
			if(net->Deal[u][tab[link]] == E0)
			{
				net->Fine[u][tab[link]] =  fine ;		 //new!
				net->Tree[u][tab[link]] =	net->Tree[0][link];
				net->Pink[u][tab[link]] =	net->Pink[0][link];
				net->Item[u][tab[link]] =	net->Item[0][link];
				net->Size[u][tab[link]] =	net->Size[0][link];
				net->Deal[u][tab[link]] =	even ;		 break;
			}
		}
	}
}

//-------------------------------------
//	Build the virtual multi-arches
//-------------------------------------
void	CArch::MuArch( char *tab,CNest *dst,CNest *src )
{
	//look through all the links
	for (word i = 0,j; i < src->Wnet; i++)
	{
		//link out of the nest?
		if ((j = tab[i]) < dst->Wnet) 
		{
			//extracts knowledges
			switch (TabVir[src->Deal[0][i] + (dst->Deal[0][j] << 4)])
			{
				//group AV
				case  1: MuArch( dst->Type? EndswR : BifswR,dst,j,E1,TbFine(2));
							break;
				case  2:	MuArch( dst->Type? EndswL : BifswL,dst,j,E2,TbFine(2));
							break;
				case  3:	MuArch( dst->Type? EndswR : BifswR,dst,j,E5,TbFine(2));
							break;
				case  4:	MuArch( dst->Type? EndswL : BifswL,dst,j,E6,TbFine(2));
							break;
				//group BV
				case 20:	MuArch( dst->Type? EndswR : BifswR,dst,j,E1,TbFine(3));
							break;
				case 21:	MuArch( dst->Type? EndswL : BifswL,dst,j,E2,TbFine(3));
							break;
				case 22:	MuArch( dst->Type? EndswL : BifswL,dst,j,E6,TbFine(3));
							break;
				case 23:	MuArch( dst->Type? EndswR : BifswR,dst,j,E5,TbFine(3));
							break;
				case 24:	MuArch( dst->Type? EndswR : BifswR,dst,j,E9,TbFine(3));
							break;
				case 25:	MuArch( dst->Type? EndswR : BifswR,dst,j,Ed,TbFine(3));
							break;
			}

			//extracts knowledges
			switch (TabVir[dst->Deal[0][j] + (src->Deal[0][i] << 4)])
			{
				//group AV
				case  1:	MuArch( src->Type? EndswR : BifswR,src,i,E1,TbFine(2));
							break;
				case  2:	MuArch( src->Type? EndswL : BifswL,src,i,E2,TbFine(2));
							break;
				case  3:	MuArch( src->Type? EndswR : BifswR,src,i,E5,TbFine(2));
							break;
				case  4:	MuArch( src->Type? EndswL : BifswL,src,i,E6,TbFine(2));
							break;
				//group BV
				case 20:	MuArch( src->Type? EndswR : BifswR,src,i,E1,TbFine(3));
							break;
				case 21:	MuArch( src->Type? EndswL : BifswL,src,i,E2,TbFine(3));
							break;
				case 22:	MuArch( src->Type? EndswL : BifswL,src,i,E6,TbFine(3));
							break;
				case 23:	MuArch( src->Type? EndswR : BifswR,src,i,E5,TbFine(3));
							break;
				case 24:	MuArch( src->Type? EndswR : BifswR,src,i,E9,TbFine(3));
							break;
				case 25:	MuArch( src->Type? EndswR : BifswR,src,i,Ed,TbFine(3));
							break;
			}
		}
	}
}

/**************************************
			Generate hyper-graph 
		  for unstable minutiae.
**************************************/

//	Hyper-arch recursion
void	CArch::HyArch( CNest *src,word link,word next,word fine )
{
	//do hyperarch based on hypergraph
	CNest	 *con =	src->Tree[0][link],
			 *fin	=	con->Tree[0][next];

	//if have hyperarch in graph
	if (hyarch( con,next,Narc ))
	{
		//new apex in path of hyperarch
		Apex[Narc++] = src->Nord;	//++

		//is hyperarch as pseudograpf ?
		for (int i = 0; i < Narc ; i++)
			if (fin->Nord == Apex[i])				return;

		//get free position in the nest
		for (int u = 1; u < _VIR_; u++)
		{
			//free virtual arch enable ?
			if(Root->Deal[u][link] == E0)
			{
				Root->Fine[u][link] = fine ;		 //new!
				Root->Tree[u][link] = con->Tree[0][next];
				Root->Pink[u][link] = con->Pink[0][next];
				Root->Item[u][link] = con->Item[0][next];
				Root->Deal[u][link] = con->Deal[0][next];
				Root->Size[u][link] = resize(*fin,*src );
											 break;		 //out!
			}
		}

		//build futher hyperarch
		HyArch( con,next,fine );
	}
}

//	Trace one hyper-arch
void	CArch::HyArch( CNest *src,word link,word fine )
{
	//knowledges from source
	switch (src->Deal[0][link])
	{
		case E1:	HyArch( src,link,6,fine );
					break;
		case E2:	HyArch( src,link,3,fine );
					break;
		case E5:	HyArch( src,link,4,fine );
					break;
		case E6:	HyArch( src,link,5,fine );
					break;
		case E9:	HyArch( src,link,4,fine );
					break;
		case Ea:	HyArch( src,link,1,fine );
					break;
		case Ed:	HyArch( src,link,2,fine );
					break;
		case Ee:	HyArch( src,link,3,fine );
					break;
	}
}

//-------------------------------------
//	Build virtual hyper-arches
//-------------------------------------
void	CArch::HyArch( char *tab,CNest *dst,CNest *src )
{
	//look through all the links
	for (word i = 0,j; i < src->Wnet; i++)
	{
		//link out of the nest ?
		if ((j = tab[i]) < dst->Wnet)
		{
			Narc = 0; HyArch( Root = src,i,TbFine(8));
			Narc = 0; HyArch( Root = dst,j,TbFine(8));
		}
	}
}

/**************************************
	Complement conquer projections
**************************************/

//	Add one conquer event
void	CArch::Conque( CNest *src,word link,word next,word fine )
{
	//do multiarch based on multigraph
	CNest	 *con =	src->Tree[0][link],
			 *fin	=	con->Tree[0][next];

	//have we conquer minutiae?
	if (conque( con,src,next ))
	{
		//get free position in the nest
		for (int u = 1; u < _VIR_; u++)
		{
			//free virtual arch enable ?
			if(Root->Deal[u][link] == E0)
			{
				Root->Fine[u][link] = fine ;		 //new!
				Root->Tree[u][link] = con->Tree[0][next];
				Root->Pink[u][link] = con->Pink[0][next];
				Root->Item[u][link] = con->Item[0][next];
				Root->Deal[u][link] = con->Deal[0][next];
				Root->Size[u][link] = resize(*fin,*src );
											 break;		 //out!
			}
		}
	}
}

//	Build conquer events
void	CArch::Conque( char *tab,CNest *dst,CNest *src )
{
	//build conquer projection
	for (word i = 0,j; i < src->Wnet; i++ )
	{
		//link out of the nest?
		if ((j = tab[i]) < dst->Wnet) 
		{
			//extracts knowledges from source
			switch (TabCon[src->Deal[0][i] + (dst->Deal[0][j] << 4)])
			{
				//group B
				case 20:
				case 21:
				case 22:
				case 23:
				case 24:
				case 25:	
				case 26:	Conque( Root = src,i,6,TbFine(9)); 
							break;
				//group C
				case 30:
				case 31:
				case 32:
				case 33:
				case 34:
				case 35: 
				case 36:	Conque( Root = src,i,3,TbFine(9)); 
							break;
				//group D
				case 40:
				case 41:
				case 42:
				case 43:
				case 44:
				case 45: 
				case 46:	Conque( Root = src,i,4,TbFine(9)); 
							break;
				//group E
				case 50:
				case 51:
				case 52:
				case 53:
				case 54:
				case 55: 
				case 56:	Conque( Root = src,i,5,TbFine(9)); 
							break;
				//group F
				case 60:
				case 61:
				case 62:
				case 63:
				case 64:
				case 65: 
				case 66:	Conque( Root = src,i,4,TbFine(9)); 
							break;
				//group G
				case 70:
				case 71:
				case 72:
				case 73:
				case 74:
				case 75: 
				case 76:	Conque( Root = src,i,1,TbFine(9)); 
							break;
				//group H
				case 80:
				case 81:
				case 82:
				case 83:
				case 84:
				case 85: 
				case 86:	Conque( Root = src,i,2,TbFine(9)); 
							break;
				//group I
				case 90:
				case 91:
				case 92:
				case 93:
				case 94:
				case 95: 
				case 96:	Conque( Root = src,i,3,TbFine(9)); 
							break;
			}

			//extracts knowledges from destination
			switch (TabCon[dst->Deal[0][j] + (src->Deal[0][i] << 4)])
			{
				//group B
				case 20:
				case 21:
				case 22:
				case 23:
				case 24:
				case 25: 
				case 26:	Conque( Root = dst,j,6,TbFine(9)); 
							break;
				//group C
				case 30:
				case 31:
				case 32:
				case 33:
				case 34:
				case 35: 
				case 36:	Conque( Root = dst,j,3,TbFine(9)); 
							break;
				//group D
				case 40:
				case 41:
				case 42:
				case 43:
				case 44:
				case 45: 
				case 46:	Conque( Root = dst,j,4,TbFine(9)); 
							break;
				//group E
				case 50:
				case 51:
				case 52:
				case 53:
				case 54:
				case 55: 
				case 56:	Conque( Root = dst,j,5,TbFine(9)); 
							break;
				//group F
				case 60:
				case 61:
				case 62:
				case 63:
				case 64:
				case 65: 
				case 66:	Conque( Root = dst,j,4,TbFine(9)); 
							break;
				//group G
				case 70:
				case 71:
				case 72:
				case 73:
				case 74:
				case 75: 
				case 76:	Conque( Root = dst,j,1,TbFine(9)); 
							break;
				//group H
				case 80:
				case 81:
				case 82:
				case 83:
				case 84:
				case 85: 
				case 86:	Conque( Root = dst,j,2,TbFine(9)); 
							break;
				//group I
				case 90:
				case 91:
				case 92:
				case 93:
				case 94:
				case 95: 
				case 96:	Conque( Root = dst,j,3,TbFine(9)); 
							break;
			}
		}
	}
}

/**************************************
		Rebuild nest if crossing
**************************************/

//	Add one crossing event
void	CArch::Across( CNest *net,word link,word from,byte even,word fine )
{
	//get free position in the nest
	for (int u = 1; u < _VIR_; u++)
	{
		//if free virtual enable
		if(net->Deal[u][link] == E0)
		{
			net->Fine[u][link] = fine;			 //new!
			net->Tree[u][link] =	net->Tree[0][from];
			net->Pink[u][link] =	net->Pink[0][from];
			net->Item[u][link] =	net->Item[0][from];
			net->Size[u][link] =	net->Size[0][from];
			net->Deal[u][link] =	even; 		 break;
		}
	}
}

//	Build crossing events
void	CArch::Across( char *tab,CNest *dst,CNest *src )
{
	//rebuilds nests for crossing
	for (int i = 0,j,t; i < src->Wnet; i++)
	{
		//calc link for dest & verify
		if ((j = tab[i]) < dst->Wnet)
		{
			//verify external crossing
			if (across( dst,src,j,i ) && (t = mirror( dst,j )) != -1)
			{
				//extracts knowledges from source
				switch (TabCro[src->Deal[0][i] + (dst->Deal[0][t] << 4)])
				{
					//group C1
					case  1:						 Across( dst,j,t,Ef,TbFine(10));
								break;
					//group C2
					case 10:
					case 11:	if (!(i & 1)) Across( dst,j,t,Ef,TbFine(10));
								break;
					case 12:
					case 13:
					case 14:	if (!(i & 1)) Across( dst,j,t,Ee,TbFine(10));
								break;
					//group C3
					case 30:
					case 31: if (i & 1) Across( dst,j,t,Ef,TbFine(10));
								break;
					case 32:
					case 33:
 					case 34:	if (i & 1) Across( dst,j,t,Ed,TbFine(10));
								break;
					//group C4
					case 60:
					case 61: if (!(i & 1)) Across( dst,j,t,E3,TbFine(10));
								break;
					case 62:
					case 63:	if (!(i & 1)) Across( dst,j,t,E2,TbFine(10));
								break;
					//group C5
					case 80:
					case 81:	if (i & 1) Across( dst,j,t,E3,TbFine(10));
								break;
					case 82:
					case 83:	if (i & 1) Across( dst,j,t,E1,TbFine(10));
								break;
				}
			}

			//verify external crossing
			if (across( dst,src,j,i ) && (t = mirror( src,i )) != -1)
			{
				//extracts knowledges from destination
				switch (TabCro[dst->Deal[0][j] + (src->Deal[0][t] << 4)])
				{
					//group C1
					case  1:						 Across( src,i,t,Ef,TbFine(10));
								break;
					//group C2
					case 10:
					case 11:	if (!(i & 1)) Across( src,i,t,Ef,TbFine(10));
								break;
					case 12:
					case 13:
					case 14:	if (!(i & 1)) Across( src,i,t,Ee,TbFine(10));
								break;
					//group C3
					case 30:
					case 31: if (i & 1) Across( src,i,t,Ef,TbFine(10));
								break;
					case 32:
					case 33:
					case 34:	if (i & 1) Across( src,i,t,Ed,TbFine(10));
								break;
					//group C4
					case 60:
					case 61: if (!(i & 1)) Across( src,i,t,E3,TbFine(10));
								break;
					case 62:
					case 63:	if (!(i & 1)) Across( src,i,t,E2,TbFine(10));
								break;
					//group C5
					case 80:
					case 81:	if (i & 1) Across( src,i,t,E3,TbFine(10));
								break;
					case 82:
					case 83:	if (i & 1) Across( src,i,t,E1,TbFine(10));
								break;
				}
			}
		}
	}
}

/**************************************
		Generate isomorphism
**************************************/
void	CArch::Isomer( char *tab,CNest *dst,CNest *src )
{
	//prepare future nests
	Resets( tab,dst,src );

	//generates multi-arch
	MuArch( tab,dst,src );

	//generates hyper-arch
	HyArch( tab,dst,src );

	//interlocked conquers
	Conque( tab,dst,src );

	//rebuilds if crossing
	Across( tab,dst,src );
}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */
