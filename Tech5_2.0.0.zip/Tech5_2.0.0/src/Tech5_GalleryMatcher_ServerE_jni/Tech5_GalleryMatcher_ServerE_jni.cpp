// Tech5_GalleryMatcher_ServerE_jni.cpp : Defines the exported functions for the DLL application.
//
#if defined(_WINDOWS)|| defined(_WIN32_WCE)
#include <Windows.h>
#else
#include <string.h>
#endif // _WINDOWS
#include "coreSdk.h"
#include "Tech5_GalleryMatcher_ServerE.h"

#ifndef MAX_TEMPLATE_SIZE
#define MAX_TEMPLATE_SIZE		         12 * 1024	// maximum size of the template ver. 7.3 in bytes
#endif // MAX_TEMPLATE_SIZE


////		BEGIN OF TEMPLATECREATOR
#include "tech5_com_TemplateCreator.h"
/*
 * Class:     tech5_com_TemplateCreator
 * Method:    create_
 * Signature: ()J
 */
JNIEXPORT jlong JNICALL Java_tech5_com_TemplateCreator_create_1
  (JNIEnv *, jobject)
{
	jlong sdk_handle = 0;
	Tech5Finger::TemplateCreator* m_creator = 0;

	try
	{
		m_creator = Tech5Finger::TemplateCreator::create();
		sdk_handle = (jlong)m_creator;
	}
	catch(...)
	{
	}
	return sdk_handle;
}

/*
 * Class:     tech5_com_TemplateCreator
 * Method:    cancel_
 * Signature: (J)V
 */
JNIEXPORT void JNICALL Java_tech5_com_TemplateCreator_cancel_1
  (JNIEnv *, jobject, jlong sdk_handle)
{
	Tech5Finger::TemplateCreator* m_creator = 0;
	try
	{
		m_creator = (Tech5Finger::TemplateCreator*)sdk_handle;
		if(m_creator)
			Tech5Finger::TemplateCreator::cancel(m_creator);
	}
	catch(...)
	{
	}
	m_creator = 0;
}

/*
 * Class:     tech5_com_TemplateCreator
 * Method:    initLicense_
 * Signature: (JLjava/lang/String;)Z
 */
JNIEXPORT jboolean JNICALL Java_tech5_com_TemplateCreator_initLicense_1
  (JNIEnv *env, jobject, jlong sdk_handle, jstring jlicenseFile)
{
	jboolean result = 0;
	Tech5Finger::TemplateCreator* m_creator = 0;
	try
	{
		const char *name = env->GetStringUTFChars (jlicenseFile, &result);
		if (result)
		{
			m_creator = (Tech5Finger::TemplateCreator*)sdk_handle;
			if(m_creator)
				m_creator->initLicense(name) ? result = 1 : result = 0;
		env->ReleaseStringUTFChars (jlicenseFile, name);
		name = 0;
		}
	}
	catch(...)
	{
		result = 0;
	}
	m_creator = 0;
	return result;
}

/*
 * Class:     tech5_com_TemplateCreator
 * Method:    createTemplate_
 * Signature: (JLtech5/com/RawImage;Ljava/lang/Integer;Ljava/lang/Byte;)I
 */
JNIEXPORT jint JNICALL Java_tech5_com_TemplateCreator_createTemplate_1__JLtech5_com_RawImage_2Ljava_lang_Integer_2Ljava_lang_Byte_2
  (JNIEnv *env, jobject obj, jlong sdk_handle, jobject jRawImage, jobject jTemplSize, jobject jQuality)
{
	jint retVal = 0;
	unsigned int templSize	= 0;
	unsigned char	quality = 0;
	Tech5Finger::RawImage	m_raw;
	Tech5Finger::TemplateCreator* m_creator = 0;

	jclass cls					= 0;
	jmethodID mid				= 0;
	jclass dibimage_class	= 0;
	jfieldID fid	= 0;
	jbyteArray m_image = 0;

	try
	{

		if(!(dibimage_class = env->GetObjectClass(jRawImage)))
			throw Tech5Finger::WRONG_PARAMETRS;

		fid = env->GetFieldID(dibimage_class, "m_finger", "I");
		m_raw.m_finger = (FINGERS)env->GetIntField(dibimage_class,fid);

		fid = env->GetFieldID(dibimage_class, "m_width", "I");
		m_raw.m_width = env->GetIntField(dibimage_class,fid);

		fid = env->GetFieldID(dibimage_class, "m_height", "I");
		m_raw.m_height = env->GetIntField(dibimage_class,fid);
		
		fid = env->GetFieldID(dibimage_class, "m_image", "[B");
		m_image = (jbyteArray)env->GetObjectField(dibimage_class,fid);
		int dib_length = env->GetArrayLength (m_image);
		if(dib_length == 0)
			throw Tech5Finger::WRONG_PARAMETRS;
		m_raw.m_image = new unsigned char[dib_length];
		env->GetByteArrayRegion (m_image, 0, dib_length, (jbyte*)(m_raw.m_image));


		m_creator = (Tech5Finger::TemplateCreator*)sdk_handle;
		if(!m_creator)
			throw Tech5Finger::WRONG_PARAMETRS;

		retVal = m_creator->createTemplate(m_raw,templSize,quality);

		if( retVal == Tech5Finger::SUCCESS )
		{
			// set quality
			 if(!(cls = env->GetObjectClass(jQuality)))
				 throw Tech5Finger::UNKNOWN_EXCEPTION;
			 if (!(mid = env->GetMethodID (cls, "<init>", "(B)V")))
				 throw Tech5Finger::UNKNOWN_EXCEPTION;
			 env->CallVoidMethod (jQuality, mid, quality);
			 // set template size
			 if(!(cls = env->GetObjectClass(jTemplSize)))
				 throw Tech5Finger::UNKNOWN_EXCEPTION;
			 if (!(mid = env->GetMethodID (cls, "<init>", "(I)V")))
				 throw Tech5Finger::UNKNOWN_EXCEPTION;
			 env->CallVoidMethod (jTemplSize, mid, templSize);
		}
	}
	catch( int err)
	{
		retVal = err;
	}
	catch(...)
	{
		retVal = Tech5Finger::UNKNOWN_EXCEPTION;
	}
	m_creator = 0;
	return retVal;
}

/*
 * Class:     tech5_com_TemplateCreator
 * Method:    createTemplate_
 * Signature: (JLtech5/com/WsqImage;Ljava/lang/Integer;Ljava/lang/Byte;)I
 */
JNIEXPORT jint JNICALL Java_tech5_com_TemplateCreator_createTemplate_1__JLtech5_com_WsqImage_2Ljava_lang_Integer_2Ljava_lang_Byte_2
  (JNIEnv *env, jobject obj, jlong sdk_handle, jobject jWsqImage, jobject jTemplSize, jobject jQuality)
{
  	jint retVal = 0;
	unsigned int templSize	= 0;
	unsigned char	quality = 0;
	Tech5Finger::WsqImage	m_wsq;
	Tech5Finger::TemplateCreator* m_creator = 0;

	jclass cls					= 0;
	jmethodID mid				= 0;
	jclass dibimage_class	= 0;
	jfieldID fid	= 0;
	jbyteArray m_image = 0;

	try
	{

		if(!(dibimage_class = env->GetObjectClass(jWsqImage)))
			throw Tech5Finger::WRONG_PARAMETRS;

		fid = env->GetFieldID(dibimage_class, "m_finger", "I");
		m_wsq.m_finger = (FINGERS)env->GetIntField(jWsqImage,fid);

		fid = env->GetFieldID(dibimage_class, "m_size", "I");
		m_wsq.m_size = env->GetIntField(jWsqImage,fid);

		fid = env->GetFieldID(dibimage_class, "m_wsq", "[B");
		m_image = (jbyteArray)env->GetObjectField(jWsqImage,fid);
		jsize dib_length = env->GetArrayLength (m_image);
		if(dib_length > m_wsq.m_size)
			throw Tech5Finger::WRONG_PARAMETRS;
		m_wsq.m_wsq = new unsigned char[m_wsq.m_size];
		env->GetByteArrayRegion (m_image, 0, dib_length, (jbyte*)(m_wsq.m_wsq));


		m_creator = (Tech5Finger::TemplateCreator*)sdk_handle;
		if(!m_creator)
			throw Tech5Finger::WRONG_PARAMETRS;

		retVal = m_creator->createTemplate(m_wsq,templSize,quality);

		if( retVal == Tech5Finger::SUCCESS )
		{
			// set quality
			 if(!(cls = env->GetObjectClass(jQuality)))
				 throw -1;
			 if (!(mid = env->GetMethodID (cls, "<init>", "(B)V")))
				 throw -1;
			 env->CallVoidMethod (jQuality, mid, quality);
			 // set template size
			 if(!(cls = env->GetObjectClass(jTemplSize)))
				 throw -1;
			 if (!(mid = env->GetMethodID (cls, "<init>", "(I)V")))
				 throw -1;
			 env->CallVoidMethod (jTemplSize, mid, templSize);
		}
	}
	catch( int err )
	{
		retVal = err;
	}
	catch(...)
	{
	}
	m_creator = 0;
	return retVal;
}

/*
 * Class:     tech5_com_TemplateCreator
 * Method:    getTemplate_
 * Signature: (J[B)V
 */
JNIEXPORT void JNICALL Java_tech5_com_TemplateCreator_getTemplate_1
  (JNIEnv *env, jobject, jlong sdk_handle, jbyteArray jTemplate)
{
	Tech5Finger::TemplateCreator* m_creator = 0;
	unsigned char* fpTemplate = 0;
	try
	{
		int templSize = env->GetArrayLength (jTemplate);
		fpTemplate = new unsigned char[templSize];
		m_creator = (Tech5Finger::TemplateCreator*)sdk_handle;
		if(m_creator)
		{
			m_creator->getTemplate(fpTemplate);
		// set template
			env->SetByteArrayRegion (jTemplate, 0, templSize, (jbyte*)fpTemplate);
		}

	}
	catch(...)
	{
	}
	if(fpTemplate)
		delete[] fpTemplate, fpTemplate = 0;
	m_creator = 0;
}

////        BEGIN OF FPTEMPLATECHECKER

#include "tech5_com_FpTemplateChecker.h"

/*
 * Class:     tech5_com_FpTemplateChecker
 * Method:    create_
 * Signature: ()J
 */
JNIEXPORT jlong JNICALL Java_tech5_com_FpTemplateChecker_create_1
  (JNIEnv *env, jobject)
{
	jlong sdk_handle = 0;
	Tech5Finger::FpTemplateChecker* m_checker = 0;

	try
	{
		m_checker = Tech5Finger::FpTemplateChecker::create();
		sdk_handle = (jlong)m_checker;
	}
	catch(...)
	{
	}
	return sdk_handle;
}

/*
 * Class:     tech5_com_FpTemplateChecker
 * Method:    cancel_
 * Signature: (J)V
 */
JNIEXPORT void JNICALL Java_tech5_com_FpTemplateChecker_cancel_1
  (JNIEnv *env, jobject, jlong sdk_handle)
{
	Tech5Finger::FpTemplateChecker* m_checker = 0;
	try
	{
		m_checker = (Tech5Finger::FpTemplateChecker*)sdk_handle;
		if(m_checker)
			Tech5Finger::FpTemplateChecker::cancel(m_checker);
	}
	catch(...)
	{
	}
	m_checker = 0;
}

/*
 * Class:     tech5_com_FpTemplateChecker
 * Method:    check_
 * Signature: (J[B)Z
 */
JNIEXPORT jboolean JNICALL Java_tech5_com_FpTemplateChecker_check_1
  (JNIEnv *env, jobject, jlong sdk_handle, jbyteArray jTemplate)
{
	jboolean retVal = 0;
	Tech5Finger::FpTemplateChecker* m_checker = 0;
	unsigned char*	fpTemplate = 0;
	try
	{
		int templSize1 = env->GetArrayLength (jTemplate);
		if( templSize1 <= 0)
			throw -1;
		fpTemplate = new unsigned char[templSize1];
		if (!fpTemplate)
			throw -1;
		env->GetByteArrayRegion (jTemplate, 0, templSize1, (jbyte*)fpTemplate);
		m_checker = (Tech5Finger::FpTemplateChecker*)sdk_handle;
		if(m_checker)
			if( m_checker->check(fpTemplate))
				retVal = 1;
	}
	catch(...)
	{
	}
	if(fpTemplate)
		delete[] fpTemplate, fpTemplate = 0;
	m_checker = 0;
	return retVal;
}

////        END OF FPTEMPLATECHECKER


////		BEGIN OF MATCHER
#include "tech5_com_Matcher.h"
/*
 * Class:     tech5_com_Matcher
 * Method:    create_
 * Signature: ()J
 */
JNIEXPORT jlong JNICALL Java_tech5_com_Matcher_create_1
  (JNIEnv *, jobject)
{
	jlong sdk_handle = 0;
	Tech5Finger::Matcher* m_matcher = 0;

	try
	{
		m_matcher = Tech5Finger::Matcher::create();
		sdk_handle = (jlong)m_matcher;
	}
	catch(...)
	{
	}
	return sdk_handle;

}

/*
 * Class:     tech5_com_Matcher
 * Method:    cancel_
 * Signature: (J)V
 */
JNIEXPORT void JNICALL Java_tech5_com_Matcher_cancel_1
  (JNIEnv *, jobject, jlong sdk_handle)
{
	Tech5Finger::Matcher* m_matcher = 0;
	try
	{
		m_matcher = (Tech5Finger::Matcher*)sdk_handle;
		if(m_matcher)
			Tech5Finger::Matcher::cancel(m_matcher);
	}
	catch(...)
	{
	}
	m_matcher = 0;
}

/*
 * Class:     tech5_com_Matcher
 * Method:    initLicense_
 * Signature: (JLjava/lang/String;)Z
 */
JNIEXPORT jboolean JNICALL Java_tech5_com_Matcher_initLicense_1
  (JNIEnv *env, jobject, jlong sdk_handle, jstring jlicenseFile)
{
	jboolean result = 0;
	Tech5Finger::Matcher* m_matcher = 0;
	try
	{
		const char *name = env->GetStringUTFChars (jlicenseFile, &result);
		if (result)
		{
			m_matcher = (Tech5Finger::Matcher*)sdk_handle;
			if(m_matcher)
				m_matcher->initLicense(name) ? result = 1 : result = 0;
		env->ReleaseStringUTFChars (jlicenseFile, name);
		name = 0;
		}
	}
	catch(...)
	{
		result = 0;
	}
	m_matcher = 0;
	return result;
}

/*
 * Class:     tech5_com_Matcher
 * Method:    verify_record_
 * Signature: (JLtech5/com/MatchingParameters;[[B[[BLjava/lang/Double;)J
 */
JNIEXPORT jlong JNICALL Java_tech5_com_Matcher_verify_1record_1
  (JNIEnv *env, jobject, jlong sdk_handle, jobject jmatchingParameters, jobjectArray jtpTemplate1, jobjectArray jtpTemplate2, jobject jscore)
{
	jlong result = -1;
	Tech5Finger::Matcher* m_matcher = 0;
	Tech5Finger::MatchingParameters matchingParameters;
	TpTemplate tpTemplate1;
	TpTemplate tpTemplate2;
	double score = 0.0;

	jclass cls					= 0;
	jmethodID mid				= 0;
	jclass MatchingParams_class	= 0;
	jfieldID fid	= 0;

	try
	{
		if(!(MatchingParams_class = env->GetObjectClass(jmatchingParameters))) throw -1;

		fid = env->GetFieldID(MatchingParams_class, "matchingMode", "I");
		matchingParameters.matchingMode = (MATCHING_MODE)env->GetIntField(jmatchingParameters,fid);

		fid = env->GetFieldID(MatchingParams_class, "maxAngle", "I");
		matchingParameters.maxAngle = env->GetIntField(jmatchingParameters,fid);

		fid = env->GetFieldID(MatchingParams_class, "maxAngleThumbs", "I");
		matchingParameters.maxAngleThumbs = env->GetIntField(jmatchingParameters,fid);

		fid = env->GetFieldID(MatchingParams_class, "searchSpeed", "I");
		matchingParameters.searchSpeed = env->GetIntField(jmatchingParameters,fid);

		for(int i = 0; i < 10; i++)
		{
			 jbyteArray m_tpl1 = (jbyteArray) env->GetObjectArrayElement(jtpTemplate1,i);
			 jbyteArray m_tpl2 = (jbyteArray) env->GetObjectArrayElement(jtpTemplate2,i);
			 if(m_tpl1)
			 {
				 jsize len = env->GetArrayLength(m_tpl1);
				 if(len > 0 && len < (MAX_TEMPLATE_SIZE+1))
					 tpTemplate1.templ[i] = new unsigned char[len];
				 else
					 continue;
				 env->GetByteArrayRegion (m_tpl1, 0, len, (jbyte*)(tpTemplate1.templ[i]));
			 }
			 if(m_tpl2)
			 {
				 jsize len = env->GetArrayLength(m_tpl2);
				 if(len > 0 && len < (MAX_TEMPLATE_SIZE+1))
					 tpTemplate2.templ[i] = new unsigned char[len];
				 else
					 continue;
				 env->GetByteArrayRegion (m_tpl2, 0, len, (jbyte*)(tpTemplate2.templ[i]));
			 }
		}

		m_matcher = (Tech5Finger::Matcher*)sdk_handle;
		if(m_matcher)
			result = m_matcher->verify_record(matchingParameters,tpTemplate1,tpTemplate2,score);
		if(result == Tech5Finger::SUCCESS)
		{
			// set score
			 if(!(cls = env->GetObjectClass(jscore)))
				 throw -1;
			 if (!(mid = env->GetMethodID (cls, "<init>", "(D)V")))
				 throw -1;
			 env->CallVoidMethod (jscore, mid, score);
		}
	}
	catch(...)
	{
		result = 0;
	}
	for(int i = 0; i < 10; i++)
	{
		if(tpTemplate1.templ[i])
			delete[] tpTemplate1.templ[i], tpTemplate1.templ[i] = 0;
		if(tpTemplate2.templ[i])
			delete[] tpTemplate2.templ[i], tpTemplate2.templ[i] = 0;
	}
	m_matcher = 0;
	return result;
}

/*
 * Class:     tech5_com_Matcher
 * Method:    insertRecord_
 * Signature: (JLjava/lang/String;Ltech5/com/TpTemplate;)I
 */
JNIEXPORT jint JNICALL Java_tech5_com_Matcher_insertRecord_1
  (JNIEnv *env, jobject, jlong sdk_handle, jstring jId, jobjectArray jTemplates)
{
	jint result = -1;
	Tech5Finger::Matcher* m_matcher = 0;
	TpTemplate tpTemplate;
	std::string description = "";

	const char *name = 0;

	try
	{
		jboolean isCopied;
		name = env->GetStringUTFChars (jId, &isCopied);
		if(!isCopied)
			throw Tech5Finger::WRONG_PARAMETRS;
		else
			description = name;

		for(int i = 0; i < 10; i++)
		{
			 jbyteArray m_tpl1 = (jbyteArray) env->GetObjectArrayElement(jTemplates,i);
			 if(m_tpl1)
			 {
				 jsize len = env->GetArrayLength(m_tpl1);
				 if(len > 0 && len < (MAX_TEMPLATE_SIZE+1))
				 {
					 tpTemplate.templ[i] = new unsigned char[len];
					 env->GetByteArrayRegion (m_tpl1, 0, len, (jbyte*)(tpTemplate.templ[i]));
				 }
				 else
					 tpTemplate.templ[i] = 0;
			 }
			 else
				 tpTemplate.templ[i] = 0;
		}

		m_matcher = (Tech5Finger::Matcher*)sdk_handle;
		if(m_matcher)
			result = m_matcher->insertRecord(description,tpTemplate);
		env->ReleaseStringUTFChars (jId, name);
	}
	catch(...)
	{
		result = 0;
	}
	for(int i = 0; i < 10; i++)
	{
		if(tpTemplate.templ[i])
			delete[] tpTemplate.templ[i], tpTemplate.templ[i] = 0;
	}
	name = 0;
	m_matcher = 0;
	return result;
}

/*
 * Class:     tech5_com_Matcher
 * Method:    deleteRecord_
 * Signature: (JLjava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_tech5_com_Matcher_deleteRecord_1
  (JNIEnv *env, jobject, jlong sdk_handle, jstring jId)
{
	jint result = -1;
	Tech5Finger::Matcher* m_matcher = 0;
	std::string description = "";

	const char *name = 0;

	try
	{
		jboolean isCopied;
		name = env->GetStringUTFChars (jId, &isCopied);
		if(!isCopied)
			throw Tech5Finger::WRONG_PARAMETRS;
		else
			description = name;

		m_matcher = (Tech5Finger::Matcher*)sdk_handle;
		if(m_matcher)
			result = m_matcher->deleteRecord(description);
		env->ReleaseStringUTFChars (jId, name);
	}
	catch(...)
	{
		result = 0;
	}
	name = 0;
	m_matcher = 0;
	return result;
}

/*
 * Class:     tech5_com_Matcher
 * Method:    getFinalGallerySize_
 * Signature: (J)J
 */
JNIEXPORT jlong JNICALL Java_tech5_com_Matcher_getFinalGallerySize_1
  (JNIEnv *, jobject, jlong sdk_handle)
{
	jlong result = 0;
	Tech5Finger::Matcher* m_matcher = 0;
	try
	{
		m_matcher = (Tech5Finger::Matcher*)sdk_handle;
		if(m_matcher)
			result = m_matcher->getFinalGallerySize();
	}
	catch(...)
	{
		result = 0;
	}
	m_matcher = 0;
	return result;
}

/*
 * Class:     tech5_com_Matcher
 * Method:    identify_record_
 * Signature: (JLtech5/com/MatchingParameters;[[BII)Ljava/util/ArrayList;
 */
JNIEXPORT jobject JNICALL Java_tech5_com_Matcher_identify_1record_1
(JNIEnv *env, jobject jobj, jlong sdk_handle, jobject jMatchParams, jobjectArray jTemplArray, jint jnumberOfThreads, jint jcandidate_list_length)
{
	jint result = -1;
	Tech5Finger::Matcher* m_matcher = 0;
	Tech5Finger::MatchingParameters matchingParameters;
	TpTemplate tpTemplate;
	jclass MatchingParams_class	= 0;
	jfieldID fid	= 0;
	std::vector<Tech5Finger::candidates_string> candidate_list;
	uint32_t numOfThreads = jnumberOfThreads;
	uint32_t cand_list_length = jcandidate_list_length;

	jobject candidatesArrayList = 0;

	try
	{
		if(!(MatchingParams_class = env->GetObjectClass(jMatchParams)))
			throw -1;

		fid = env->GetFieldID(MatchingParams_class, "matchingMode", "I");
		matchingParameters.matchingMode = (MATCHING_MODE)env->GetIntField(jMatchParams,fid);

		fid = env->GetFieldID(MatchingParams_class, "maxAngle", "I");
		matchingParameters.maxAngle = env->GetIntField(jMatchParams,fid);

		fid = env->GetFieldID(MatchingParams_class, "maxAngleThumbs", "I");
		matchingParameters.maxAngleThumbs = env->GetIntField(jMatchParams,fid);

		fid = env->GetFieldID(MatchingParams_class, "searchSpeed", "I");
		matchingParameters.searchSpeed = env->GetIntField(jMatchParams,fid);

		for(int i = 0; i < 10; i++)
		{
			 jbyteArray m_tpl1 = (jbyteArray) env->GetObjectArrayElement(jTemplArray,i);
			 if(m_tpl1)
			 {
				 jsize len = env->GetArrayLength(m_tpl1);
				 if(len > 0 && len < (MAX_TEMPLATE_SIZE+1))
				 {
					 tpTemplate.templ[i] = new unsigned char[len];
					 env->GetByteArrayRegion (m_tpl1, 0, len, (jbyte*)(tpTemplate.templ[i]));
				 }
				 else
					 tpTemplate.templ[i] = 0;
			 }
			 else
				 tpTemplate.templ[i] = 0;
		}

		m_matcher = (Tech5Finger::Matcher*)sdk_handle;
		if(m_matcher)
			result = m_matcher->identify_record(matchingParameters,tpTemplate, numOfThreads, cand_list_length,candidate_list);


		if(result == Tech5Finger::SUCCESS)
		{
			// build candidatesArrayList
			jclass clsCand = env->FindClass("tech5/com/candidates_string");
			jmethodID mid_Candidate =  env->GetMethodID(clsCand, "<init>", "(Ljava/lang/String;F)V");
			jclass arrayClass = env->FindClass("java/util/ArrayList");
			if (arrayClass == 0)
				throw 0;
			jmethodID mid_init =  env->GetMethodID(arrayClass, "<init>", "()V");
			if (mid_init == 0)
				throw 0;
			candidatesArrayList = env->NewObject(arrayClass, mid_init);
			if (candidatesArrayList == 0)
				throw 0;
			jmethodID mid_add = env->GetMethodID(arrayClass, "add", "(Ljava/lang/Object;)Z");
			if( mid_add == 0 )
				throw 0;
			
			for( int i = 0; i < candidate_list.size(); i++)
			{
				jstring juid = env->NewStringUTF(candidate_list.at(i).uid.c_str());
				jfloat jscore = candidate_list.at(i).score;

				jobject candidateObj = env->NewObject(clsCand, mid_Candidate,juid,jscore);

				env->CallBooleanMethod(candidatesArrayList, mid_add, candidateObj);
			}
		}
	}
	catch(...)
	{
		result = 0;
	}
	for(int i = 0; i < 10; i++)
	{
		if(tpTemplate.templ[i])
			delete[] tpTemplate.templ[i], tpTemplate.templ[i] = 0;
	}
	m_matcher = 0;
	return candidatesArrayList;
}

/////		END OF MATCHER