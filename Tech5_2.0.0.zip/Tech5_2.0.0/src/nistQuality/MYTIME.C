/***********************************************************************
      LIBRARY: LFS - NIST Latent Fingerprint System

      FILE:    MYTIME.C
      AUTHOR:  Michael D. Garris
      DATE:    03/16/1999

      Contains global variable definitions used to record timings by
      the NIST Latent Fingerprint System (LFS).
***********************************************************************/

/* Total time: including all initializations                            */
/*           : excluding all I/O except for required HO39 input image   */
/*             (This is done to contrast the fact that the NIST GENHO39 */
/*              eliminates the need for this extra read.)               */
unsigned long total_timer;
float total_time = 0.0;   /* time accumulator */

/* IMAP generation time: excluding initialization */
unsigned long imap_timer;
float imap_time = 0.0;   /* time accumulator */

/* Binarization time: excluding initialization */
unsigned long bin_timer;
float bin_time = 0.0;   /* time accumulator */

/* Minutia Detection time */
unsigned long minutia_timer;
float minutia_time = 0.0;   /* time accumulator */

/* Minutia Removal time */
unsigned long rm_minutia_timer;
float rm_minutia_time = 0.0; /* time accumulator */

/* Neighbor Ridge Counting time */
unsigned long ridge_count_timer;
float ridge_count_time = 0.0; /* time accumulator */
