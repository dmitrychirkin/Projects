/***********************************************************************
      LIBRARY: LFS - NIST Latent Fingerprint System

      FILE:    FREE.C
      AUTHOR:  Michael D. Garris
      DATE:    03/16/1999

      Contains routines responsible for deallocating
      memories required by the NIST Latent Fingerprint System (LFS).

***********************************************************************
               ROUTINES:
                        free_dir2rad()
                        free_dftwaves()
                        free_rotgrids()
                        free_dir_powers()
***********************************************************************/

#include <stdio.h>
#include "LFS.H"

/*************************************************************************
**************************************************************************
#cat: free_dir2rad - Deallocates memory associated with a DIR2RAD structure

   Input:
      dir2rad - pointer to memory to be freed
*************************************************************************/
void free_dir2rad(DIR2RAD *dir2rad)
{
   free(dir2rad->cos);
   free(dir2rad->sin);
   free(dir2rad);
}

/*************************************************************************
**************************************************************************
#cat: free_dftwaves - Deallocates the memory associated with a DFTWAVES
#cat:                 structure

   Input:
      dftwaves - pointer to memory to be freed
**************************************************************************/
void free_dftwaves(DFTWAVES *dftwaves)
{
   int i;

   for(i = 0; i < dftwaves->nwaves; i++){
       free(dftwaves->waves[i]->cos);
       free(dftwaves->waves[i]->sin);
       free(dftwaves->waves[i]);
   }
   free(dftwaves->waves);
   free(dftwaves);
}

/*************************************************************************
**************************************************************************
#cat: free_rotgrids - Deallocates the memory associated with a ROTGRIDS
#cat:                 structure

   Input:
      rotgrids - pointer to memory to be freed
**************************************************************************/
void free_rotgrids(ROTGRIDS *rotgrids)
{
   int i;

   for(i = 0; i < rotgrids->ngrids; i++)
      free(rotgrids->grids[i]);
   free(rotgrids->grids);
   free(rotgrids);
}

/*************************************************************************
**************************************************************************
#cat: free_dir_powers - Deallocate memory associated with DFT power vectors

   Input:
      powers - vectors of DFT power values (N Waves X M Directions)
      nwaves - number of DFT wave forms used
**************************************************************************/
void free_dir_powers(double **powers, const int nwaves)
{
   int w;

   for(w = 0; w < nwaves; w++)
      free(powers[w]);

   free(powers);
}

