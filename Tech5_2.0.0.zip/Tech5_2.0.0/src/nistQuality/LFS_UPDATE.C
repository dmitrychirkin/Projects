/***********************************************************************
      LIBRARY: LFS - NIST Latent Fingerprint System

      FILE:    UPDATE.C
      AUTHOR:  Michael D. Garris
      DATE:    09/14/2004

      Routines responsible for taking LFS results and updating
      structures such as ANSI/NIST.

***********************************************************************
               ROUTINES:
                        update_ANSI_NIST_lfs_results()

***********************************************************************/

#include <stdio.h>
#include "LFS.H"
#include "AN2K.H"


/*************************************************************************
**************************************************************************
#cat: update_ANSI_NIST_lfs_results - Updates an ANSI/NIST structure by creating
#cat:             and inserting a new Type-9 record containing the detected
#cat:             minutiae and a Type-13 or 14 record containing the
#cat:             resulting binarized image from LFS.

   Input:
      ansi_nist - ANSI/NIST structure to be modified
      minutiae  - structure containing the detected minutiae
      idata     - binarized fingerprint image data
      iw        - width (in pixels) of the binarized image
      ih        - height (in pixels) of the binarized image
      id        - pixel depth (in bits) of the binarized image
      ppmm      - the scan resolution (in pixels/mm) of the binarized image
      img_idc   - the image record's IDC
      img_imp   - the image record's impression type (IMP)
   Output:
      ansi_nist - the modified ANSI/NIST structure
   Return Code:
      Zero     - successful completion
      Negative - system error
**************************************************************************/
int update_ANSI_NIST_lfs_results(ANSI_NIST *ansi_nist, MINUTIAE *minutiae,
                     unsigned char *idata, const int iw, const int ih,
                     const int id, const double ppmm, const int img_idc,
                     const int img_imp)
{
   int ret, ilen;
   RECORD *type_9, *imgrecord;

   if(minutiae->num > 0){
      /* Convert Minutiae list to Standard Type-9 Record. */
      if(ret = minutiae2type_9(&type_9, img_idc, minutiae, iw, ih, ppmm)){
         return(ret);
      }

      /* Insert Type-9 record at end of input ANSI/NIST file. */
      if(ret = insert_ANSI_NIST_record_frmem(ansi_nist->num_records,
                                             type_9, ansi_nist)){
         free_ANSI_NIST_record(type_9);
         return(ret);
      }
   }


   /* Convert image pixmap to a tagged field image record based */
   /* on the Impression Type of the input image. */
   switch(id){
      case 1:
         ilen = (iw>>3) * ih;
         break;
      case 8:
         ilen = iw * ih;
         break;
      case 24:
         ilen = iw * ih * 3;
         break;
      default:
         fprintf(stderr, "ERROR : update_ANSI_NIST_lfs_results : ");
         fprintf(stderr, "image pixel depth = %d != {1,8,24}\n", id);
         return(-2);
   }
   
   if(ret = fingerprint2tagged_field_image(&imgrecord, idata, ilen,
                                           iw, ih, id, ppmm,
                                           COMP_NONE, img_idc,
                                           img_imp, LFS_VERSION_STR)){
      return(ret);
   }

   /* Insert Binary Image record at end of input ANSI/NIST file. */
   if(ret = insert_ANSI_NIST_record_frmem(ansi_nist->num_records,
                                          imgrecord, ansi_nist)){
      free_ANSI_NIST_record(imgrecord);
      return(ret);
   }

   /* Return normally. */
   return(0);
}
