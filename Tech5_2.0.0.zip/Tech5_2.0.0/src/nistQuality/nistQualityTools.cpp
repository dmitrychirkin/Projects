//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
#include "NFIQ.H"

// Finger quality values
enum NIST_QUALITY
{
   QUAL_POOR      =  20,    // NFIQ value 5
   QUAL_FAIR      =  40,    // NFIQ value 4
   QUAL_GOOD      =  60,    // NFIQ value 3
   QUAL_VGOOD     =  80,    // NFIQ value 2
   QUAL_EXCELLENT = 100     // NFIQ value 1
};

//////////////////////////////////////////////////////////////////////////
//
//
//
//////////////////////////////////////////////////////////////////////////
   int getNistQuality( unsigned char * img, int imgWidth, int imgHeight, float * confirmation )
   {
      int   nfiq;
      float conf = 0; 

      
      if ( comp_nfiq(&nfiq, &conf, img, imgWidth, imgHeight, 8, 500) < 0 )   return 0;
      if ( confirmation ) *confirmation = conf;
      
      switch( nfiq ) 
      {
         case 5 : return QUAL_POOR     ;   // NFIQ value 5
         case 4 : return QUAL_FAIR     ;   // NFIQ value 4
         case 3 : return QUAL_GOOD     ;   // NFIQ value 3
         case 2 : return QUAL_VGOOD    ;   // NFIQ value 2
         case 1 : return QUAL_EXCELLENT;   // NFIQ value 1
         default: return 0;
      }

      return 0;
   }