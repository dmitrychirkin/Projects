/***********************************************************************
      LIBRARY: LFS - NIST Latent Fingerprint System

      FILE:    LOG.C
      AUTHOR:  Michael D. Garris
      DATE:    08/02/1999

      Contains routines responsible for dynamically updating a log file
      during the execution of the NIST Latent Fingerprint System (LFS).

***********************************************************************
               ROUTINES:
                        open_logfile()
                        print2log()
                        close_logfile()
***********************************************************************/

#include "LOG.H"

/* If logging is on, declare global file pointer and supporting */
/* global variable for logging intermediate results.            */
FILE *logfp;
int avrdir;
float dir_strength;
int nvalid;

/***************************************************************************/
/***************************************************************************/
int open_logfile()
{
#ifdef LOG_REPORT
   if((logfp = fopen(LOG_FILE, "wb")) == NULL){
      fprintf(stderr, "ERROR : open_logfile : fopen : %s\n", LOG_FILE);
      return(-1);
   }
#endif

   return(0);
}

/***************************************************************************/
/***************************************************************************/
void print2log(char *fmt, ...)
{
#ifdef LOG_REPORT
   va_list ap;

   va_start(ap, fmt);
   vfprintf(logfp, fmt, ap);
   va_end(ap);
#endif
}

/***************************************************************************/
/***************************************************************************/
int close_logfile()
{
#ifdef LOG_REPORT
   if(fclose(logfp)){
      fprintf(stderr, "ERROR : close_logfile : fclose : %s\n", LOG_FILE);
      return(-1);
   }
#endif

   return(0);
}

