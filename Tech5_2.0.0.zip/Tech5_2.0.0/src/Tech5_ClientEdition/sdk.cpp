/*****************************************************************************
	sdk.cpp - implementation of Sdk class

*******************************************************************************/

#ifdef _WINDOWS
#include <windows.h>
#endif

#include <assert.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <wchar.h>

#include "Utilites.h"
#include "resource.h"
#include <coreSdk.h>
#include "Tech5_ClientEdition.h"
#include "sdk.h"
#include "ImageUtl.h"
#include "MessagesStrings.h"

#define MM_2_DOT(x)			((unsigned int)(x * DEF_DPI / 25.4))
#define DOT_2_MM(x)			((unsigned int)(x * 25.4 / DEF_DPI))

void cutImage(const unsigned char* src, unsigned char* dst, int oldWidth, int oldHeight, 
			  int x0, int y0, int newWidth, int newHeight, int colordepth) 
{
	if((x0 + newWidth) > oldWidth || (y0 + newHeight) > oldHeight) 
		return ;

	int shift = (y0 * oldWidth + x0) * colordepth;    

	unsigned char* tempSrc = (unsigned char*)src + shift;
	unsigned char* tempDst = dst;

	// copy image
	for(int i = 0; i < newHeight; i++ )
	{
		memcpy (tempDst, tempSrc, newWidth*colordepth);		
		tempSrc += oldWidth * colordepth;
		tempDst += newWidth * colordepth;
	}

}

long getOffset(LPBITMAPINFOHEADER pBmih)
{
	long s_offset =  pBmih->biSize;
	if (!pBmih)
		return s_offset;
	if( pBmih->biClrUsed )
		return s_offset + (pBmih->biClrUsed) * sizeof(RGBQUAD);

	unsigned short nBit = pBmih->biBitCount;
	if (nBit ==  1 || nBit ==  4 || nBit ==  8 )
		return s_offset + (sizeof(RGBQUAD) << nBit);

	if (nBit ==  16 || nBit == 24 || nBit == 32)
	{
		if( pBmih->biCompression == BI_BITFIELDS )
			return s_offset +  3 * sizeof(long);

		if( pBmih->biCompression == BI_RGB )
			return s_offset;
	}
	return -1;
}

long	instance_counter = -1;

wchar_t* ToWide(wchar_t *destination,char *source)
{
#if defined(WIN32)
	int cchWideChar=
		MultiByteToWideChar(
		CP_ACP,         // code page
		MB_PRECOMPOSED,         // character-type options
		source, // address of string to map
		-1,      // number of bytes in string
		0,  // address of wide-character buffer
		0        // size of buffer
		);

	MultiByteToWideChar(
		CP_ACP,
		MB_PRECOMPOSED,
		source,
		-1,
		destination,
		cchWideChar);
#else
	int cchWideChar = mbstowcs(0,source,0);
	mbstowcs(destination,source,cchWideChar);
#endif
	return destination;
}
char* ToChar(char* destination, wchar_t* source)
{
#if defined(WIN32) || defined(_WIN32_WCE)
	if (!WideCharToMultiByte(CP_ACP, NULL, source, -1, destination, S_MAX_DESCR_LEN, NULL, NULL))
	{
		destination = "";
	}
#else
	wcstombs(destination,source,S_MAX_DESCR_LEN);
#endif
	return destination;
}

Sdk::Sdk(int cores_count)
{
	m_maxAngle = MAX_ANGLE_DEF;
	m_searchParams.maxAngle = MAX_ANGLE_DEF;	
	m_searchParams.maxDisp = DOT_2_MM(MAX_DISP_DEF);	
	m_searchParams.searchSpeed = SEARCH_SPEED_DEF;
	m_hEvent = 0;
	m_iso_template = NULL;
	m_nist_template = NULL;
#ifdef HARDWARE_PROTECT
	m_license_init = 0;
	keyProtect = 0;
	m_protect = NULL;
#endif

#ifdef _WINDOWS
	InterlockedIncrement(&instance_counter);
#else
	instance_counter++;
#endif // WINDOWS

	m_cores_count = cores_count;
	// initialize IP, MA and DAPI
	if ((m_ip.init() != IP_OK) || 
		 (m_ma.init() != MA_OK)  
		) throw SE_LOW_MEMORY;
	if( allocate_Template_NIST(1,&m_nist_template) != SME_OK)
		throw SE_LOW_MEMORY;
	if( allocate_Template_ISO(1,&m_iso_template) != SME_OK)
		throw SE_LOW_MEMORY;
}

Sdk::~Sdk()
{
	if(m_iso_template)
		free_Template_ISO(&m_iso_template); m_iso_template = NULL;
	if(m_nist_template)
		free_Template_NIST(&m_nist_template); m_nist_template = NULL;
	// run protect control
#ifdef HARDWARE_PROTECT
	if(m_protect)
		delete m_protect;
	m_protect = NULL;
	keyProtect = 0;
	m_license_init = 0;
#endif // HARDWARE_PROTECT
#ifdef WIN32
	InterlockedDecrement(&instance_counter);
#else
	instance_counter--;
#endif
}

int Sdk::return_code_form(bool code_key, bool code_time)
{
	if (!code_key )
	{
		setError(SE_LICENSE_NOT_FOUND);
		return SE_LICENSE_NOT_FOUND;
	}
	else if(!code_key)
	{
		setError(SE_KEY);
		return SE_KEY;
	}
	if (!code_time)
	{
		setError(SE_TIME);
		return SE_TIME;
	}
	return SE_OK;
}


int Sdk::setLicenseFilename(const char* license_filename, long* extra_data, TECH5_PRODUCTS product)
{
#ifdef HARDWARE_PROTECT
	if(m_license_init == 1)
		return SE_OK;
	if(!license_filename)
	{
		setError(SE_LICENSE_NOT_FOUND);
		return SE_LICENSE_NOT_FOUND;
	}
	try
	{
		memset(m_licenseFileName,0,MAX_PATH*sizeof(m_licenseFileName[0]));
		memset(m_licenseFileName_wide,0,MAX_PATH*sizeof(m_licenseFileName_wide[0]));
		strncpy(m_licenseFileName,license_filename,MAX_PATH);
		ToWide(m_licenseFileName_wide,m_licenseFileName);
	}
	catch(...)
	{
		setError(SE_WRONG_POINTER);
		return SE_WRONG_POINTER;
	}
	setError(SE_HARDWARE);
	m_license_init = 0;
	keyProtect = 0;
	m_protect = new Tech5_Hardware_Protect(product);
	if(m_protect)
	{
		if( !m_protect->initLicense(m_licenseFileName_wide))
			return SE_HARDWARE;
		bool trial_version = false;
#ifdef TIME_PROTECT
		trial_version = true;
#else
		trial_version = false;
#endif// TIME_PROTECT

		if( !m_protect->parseLicense(trial_version))
			return SE_HARDWARE;
		if(m_protect->check_protect(trial_version))
		{
			setError(SE_OK);
			m_license_init = 1;
			keyProtect = 1;
			return SE_OK;
		}
		else
			return SE_HARDWARE;
	}
	else
		return SE_HARDWARE;
#else
	return SE_OK;
#endif // HARDWARE_PROTECT
}
int Sdk::key_protect_check()
{
#ifdef HARDWARE_PROTECT
	if(!m_license_init)
	{
		setError(SE_LICENSE_NOT_FOUND);
		return SE_LICENSE_NOT_FOUND;
	}
	bool is_good = false;
	try
	{
#ifdef TIME_PROTECT
		is_good = m_protect->check_protect(true);
#else
		is_good = m_protect->check_protect(false);
#endif// TIME_PROTECT
	}
	catch(...)
	{
		;
	}
	return is_good ? SE_OK : SE_HARDWARE;
#else
	return SE_OK;
#endif
}



/////////////////////////////////////////////////////////////////////////////////////////
//	PROSESS
/////////////////////////////////////////////////////////////////////////////////////////
/* 
	Processes set of fingerprint image and build the set of templates.
	Parameters:
	dib_image (input)    -	image structure that contains information about fingerprint
							NOTE: image should be uncompressed, 256 gray-level(8 bit per pixel),
							top-down and 500 dpi
	fpTemplate(output)	 - the buffer that receives the built template
		                   Memory for that buffer should be previously allocated by 
				           'allocateTemplates' function
	templSize (output)   - the variable that receives the size of built template
	quality   (output)   - the variable that receives the quality of fingerprint image
	maxWidth, maxHeight  - if this parameters > 0 and source image have size bigger than these
		                      values, then source image will cut to this size(input)
	Return Values:
	function returns IP_OK - if function succeeds, error code - otherwise
*/	
int Sdk::create_Template  (unsigned char* dib_image, FINGERS finger, unsigned char *fpTemplate, 
					unsigned int *templSize, unsigned char *quality, 
					unsigned int maxWidth, unsigned int maxHeight)
{
	int result = SE_OK;
	unsigned char* dib = NULL;
	int qual_ity = 0;

	try
	{
#ifdef HARDWARE_PROTECT
		key_protect_check() == SE_OK ? keyProtect = 1 : keyProtect = 0;
		if (!keyProtect && !m_license_init)
		{
			setError(SE_LICENSE_NOT_FOUND);
			throw SE_LICENSE_NOT_FOUND;
		}
		else if(!keyProtect)
		{
			throw SE_HARDWARE;
		}
#endif

		dib = dib_image;
		int width  = *((int*)(dib + 4) );
		int height = *((int*)(dib + 8));
		if (!dib || !fpTemplate)
		{
			setError(SE_WRONG_POINTER);
			throw SE_WRONG_POINTER;
		}
		CaptureData capData;
		capData.dib = (unsigned char*)dib;
		capData.numFinger = finger;
		TemplateData templ;
		templ.fpTemplate = fpTemplate;
		templ.numFinger = finger;
		ProcessParam param;
		param.maxWidth  = maxWidth;
		param.maxHeight = maxHeight;

		result = getIpError(m_ip.process (NULL, capData, templ, templSize, &qual_ity, &param));
		if (result != IP_OK) 
			throw result;
		*quality = qual_ity;
	}
	catch(int codeError)
	{
		result = codeError;
	}
	catch(...)
	{
		;
	}
	return result;
}
/* 
	Processes set of fingerprint image and build the set of templates.
	Parameters:
	dib_image (input)    -	DIBImage structure that contains information about fingerprint
							NOTE: image should be uncompressed, 256 gray-level(8 bit per pixel),
							top-down and 500 dpi
	fpTemplate(output)	 - the buffer that receives the built template
		                   Memory for that buffer should be previously allocated by 
				           'allocateTemplates' function
	templSize (output)   - the variable that receives the size of built template
	quality   (output)   - the variable that receives the quality of fingerprint image
	maxWidth, maxHeight  - if this parameters > 0 and source image have size bigger than these
		                      values, then source image will cut to this size(input)
	Return Values:
	function returns IP_OK - if function succeeds, error code - otherwise
*/	

int Sdk::create_TemplateEx  (	DIBImage dib_image, unsigned char *fpTemplate, 
									unsigned int *templSize, unsigned char *quality, 
									unsigned int maxWidth, unsigned int maxHeight)
{
	int result = SE_OK;
	unsigned char* dib = NULL;
	int qual_ity = 0;

	try
	{
#ifdef HARDWARE_PROTECT
		key_protect_check() == SE_OK ? keyProtect = 1 : keyProtect = 0;
		if (!keyProtect && !m_license_init)
		{
			setError(SE_LICENSE_NOT_FOUND);
			throw SE_LICENSE_NOT_FOUND;
		}
		else if(!keyProtect)
		{
			throw SE_HARDWARE;
		}
#endif
		dib = dib_image.image;
		int width  = ((BITMAPINFOHEADER*)dib)->biWidth;
		int height = ((BITMAPINFOHEADER*)dib)->biHeight;
		if (!dib || !fpTemplate)
		{
			setError(SE_WRONG_POINTER);
			throw SE_WRONG_POINTER;
		}
		CaptureData capData;
		capData.dib = (unsigned char*)dib;
		capData.numFinger = (FINGERS)dib_image.finger;
		TemplateData templ;
		templ.fpTemplate = fpTemplate;
		templ.numFinger = (FINGERS) dib_image.finger;
		ProcessParam param;
		param.maxWidth  = maxWidth;
		param.maxHeight = maxHeight;

		result = getIpError(m_ip.process(NULL,capData, templ, templSize, &qual_ity, &param));
		if (result != IP_OK) 
			throw result;
		*quality = qual_ity;
	}
	catch(int codeError)
	{
		result = codeError;
	}
	catch(...)
	{
		;
	}
	return result;
}
/////////////////////////////////////////////////////////////////////////////////////////
//	MATCH
/////////////////////////////////////////////////////////////////////////////////////////
/*
	Compares two templates
	fpTempl1   (input)  - the first template
	fpTempl2   (input)  - the second template
	similarity (output) - the variable that receives the value that shows 
				         how two fingerprints similarity one to other in percent
*/
int Sdk::match_Templates(const unsigned char* fpTempl1, const unsigned char* fpTempl2, 
		                          unsigned char *similarity, FINGERS finger_pos_1, FINGERS finger_pos_2)
{
	if (!fpTempl1 || !fpTempl2)
	{
		setError(SE_WRONG_POINTER);
		return SE_WRONG_POINTER;
	}
	int result = loadTemplate(fpTempl1,finger_pos_1);
	if (result != SE_OK) return result;

	return match_TemplatesEx(fpTempl2, similarity,finger_pos_2);
}

/*
	Next two functions have the same functionality as 'match' function but 
	allows you to perform the 1:many search more quickly.
	At first you should call 'loadTemplate' function for loading the first set of templates
	and then call 'matchEx' function for match with each of second set of templates
*/
int Sdk::loadTemplate(const unsigned char* fpTempl,FINGERS fingpos)
{
	int retValue = SE_UNKN_EXCEPTION;
	try
	{
		if (!fpTempl)
		{
			setError(SE_WRONG_POINTER);
			throw SE_WRONG_POINTER;
		}
		TemplateData data;
		data.numFinger = fingpos;
		data.fpTemplate = (unsigned char*)fpTempl;
		retValue =  getMaError(m_ma.loadTemplate(data.fpTemplate));
	}
	catch(int errCode)
	{
		retValue = errCode;
	}
	catch(...)
	{
		;
	}
	return retValue;
}

int Sdk::match_TemplatesEx(const unsigned char* fpTemplate, unsigned char *similarity,FINGERS fingpos)
{
	int resultResult = SE_OK;
	try
	{
		if (!fpTemplate)
		{
			setError(SE_WRONG_POINTER);
			throw SE_WRONG_POINTER;
		}
#ifdef HARDWARE_PROTECT
		key_protect_check() == SE_OK ? keyProtect = 1 : keyProtect = 0;
		if (!keyProtect && !m_license_init)
		{
			setError(SE_LICENSE_NOT_FOUND);
			throw SE_LICENSE_NOT_FOUND;
		}
		else if(!keyProtect)
		{
			throw SE_HARDWARE;
		}
#endif

		int sim = -1;
		TemplateData templ;
		templ.numFinger = fingpos;
		templ.fpTemplate = (unsigned char*)fpTemplate;
		resultResult = m_ma.matchEx (m_param, templ.fpTemplate, sim);
		resultResult = getMaError(resultResult);
		*similarity = (unsigned char)(sim / 100);
		if (*similarity > 100)
			*similarity = 100;
	}
	catch(int errCode)
	{
		resultResult = errCode;
	}
	catch(...)
	{
		resultResult = SE_UNKN_EXCEPTION;
	}
	return resultResult;
}





/*
	saves captured image to BMP file
	filename - output file name (input)
	pData - pointer to the DIB, that is returned by capture 
		functions (input)
*/
int Sdk::save2Bmp(const char* filename, const unsigned char* dib)
{
	if (!dib)
	{
		setError(SE_WRONG_POINTER);
		return SE_WRONG_POINTER;
	}
	// get offset to the image and size whole BMP
	LPBITMAPINFOHEADER bih = (LPBITMAPINFOHEADER)dib;
	DWORD sizeImage = bih->biSizeImage;
	if(bih->biSizeImage == 0)
		sizeImage = abs(bih->biHeight*bih->biWidth);
	int offset = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + sizeof(RGBQUAD) * 256;
	int sizeBmp = offset + sizeImage;

	// fill BITMAPFILEHEADER
	BITMAPFILEHEADER bfh;
	memset (&bfh, 0, sizeof (BITMAPFILEHEADER));
	bfh.bfType = 19778;
	bfh.bfOffBits = offset;
	bfh.bfSize = sizeBmp;

	FILE* f = fopen(filename, "wb");
	if (!f)
	{
		setError(SE_OPEN_FILE);
		return SE_OPEN_FILE;
	}
	size_t size1 = fwrite (&bfh, 1, sizeof (BITMAPFILEHEADER), f);
	size_t size2 = fwrite (dib, 1, sizeBmp - sizeof(BITMAPFILEHEADER), f);
	if (size1 != sizeof (BITMAPFILEHEADER) ||
		size2 != sizeBmp - sizeof(BITMAPFILEHEADER)) 
	{
		fclose (f);
		setError(SE_WRITE_FILE);
		return SE_WRITE_FILE;
	}
	fclose (f);

	return SE_OK;
}

int Sdk::save2BmpEx(unsigned char* bitmap_buffer, unsigned int* bitmap_size, const unsigned char* dib)
{
	if (!dib)
	{
		setError(SE_WRONG_POINTER);
		return SE_WRONG_POINTER;
	}

	*bitmap_size = 0;
	// get offset to the image and size whole BMP
	LPBITMAPINFOHEADER bih = (LPBITMAPINFOHEADER)dib;
	DWORD sizeImage = bih->biSizeImage;
	if(bih->biSizeImage == 0)
		sizeImage = abs(bih->biHeight*bih->biWidth);
	int offset = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + sizeof(RGBQUAD) * 256;
	int sizeBmp = offset + sizeImage;

	// fill BITMAPFILEHEADER
	BITMAPFILEHEADER bfh;
	memset (&bfh, 0, sizeof (BITMAPFILEHEADER));
	bfh.bfType = 19778;
	bfh.bfOffBits = offset;
	bfh.bfSize = sizeBmp;

	memcpy(bitmap_buffer,&bfh,sizeof (BITMAPFILEHEADER));
	memcpy(bitmap_buffer + sizeof (BITMAPFILEHEADER),dib,sizeBmp - sizeof(BITMAPFILEHEADER));
	*bitmap_size = sizeBmp;

	return SE_OK;
}

/*
	The function read BMP file and put image to dib buffer
	If the image resolution is not set in bitmap header, then it set to 500 DPI
	Parameters:
	filename      (input)   - input file name (input)
	size   (input-output)	- before the function call this variable should contains the 
	                          size the buffer pointed by dib. After call it contains the 
							  real size of data copied to dib.
	dib          (output)	- pointer to the buffer that receives the fingerprint image
							  Memory for that buffer should be allocated in application										
	Return Values:
	function returns SE_OK - if function succeeds, error code - otherwise
*/
int Sdk::readBmp (const char* filename, unsigned int *size, unsigned char* dib)
{
	FILE* f = NULL;
	int result = SE_OK;
	unsigned char* bitmap_buffer = 0;
	try 
	{
		f = fopen(filename, "rb");
		if (!f) throw SE_OPEN_FILE;
		// get file size
		if (fseek(f, 0, SEEK_END)) throw SE_READ_FILE;
		DWORD bmpSize = ftell (f);
		if (!bmpSize || bmpSize == -1) throw SE_READ_FILE;
		fseek(f,0,SEEK_SET);
		bitmap_buffer = new unsigned char[bmpSize];
		fread(bitmap_buffer,1,bmpSize,f);
		result = readBmpEx(bitmap_buffer,bmpSize,size,dib);
	}
	catch (int e)
	{
		result = e;
	}
	catch (...)
	{
		result = SE_UNKN_EXCEPTION;
	}
	if (f) fclose(f);
	if(bitmap_buffer) delete[] bitmap_buffer; bitmap_buffer = NULL;

	return result;
}

int Sdk::readBmpEx (const unsigned char* bitmap_buffer, unsigned int bitmap_buffer_size, unsigned int *size, unsigned char* dib)
{
	int result = SE_OK;
	unsigned char* dest = NULL;
	unsigned char *row_1 = NULL;
	int offset_read = 0;
	try 
	{
		offset_read += sizeof(BITMAPFILEHEADER);
		if (!bitmap_buffer_size || bitmap_buffer_size == -1) throw SE_READ_FILE;
		DWORD dibSize = bitmap_buffer_size - sizeof(BITMAPFILEHEADER);
		if (*size < dibSize)
		{
			*size = dibSize;
			throw SE_MORE_DATA;
		}

		if ( !dib) throw SE_WRONG_POINTER; 
		memcpy (dib, bitmap_buffer + offset_read, dibSize);

		// get BMP headers
		LPBITMAPINFOHEADER bih = (LPBITMAPINFOHEADER)dib;
		if (bih->biBitCount != 8 || bih->biCompression != BI_RGB || bih->biPlanes != 1)
			return SE_WRONG_DIB;
		if (bih->biClrUsed != 0 && bih->biClrUsed != 256)
			throw SE_WRONG_DIB;
		if (bih->biClrImportant != 0 &&bih->biClrImportant != 256)
			throw SE_WRONG_DIB;

		if( !bih->biXPelsPerMeter )
			bih->biXPelsPerMeter = DPI2PPM((DWORD)DEF_DPI);
		if( !bih->biYPelsPerMeter )
			bih->biYPelsPerMeter = DPI2PPM((DWORD)DEF_DPI);
		*size = dibSize;
	}
	catch (int e)
	{
		result = e;
	}
	catch (...)
	{
		result = SE_UNKN_EXCEPTION;
	}
	if(dest) delete dest; dest = NULL;
	if(row_1) delete row_1; row_1 = NULL;

	return result;
}

/*
	saves captured image to Wsq file
	filename - output file name (input)
	dib - pointer to the DIB, that is returned by capture 
		functions (input)
*/
int Sdk::save2Wsq(const char* filename, const unsigned char* dib, float compressionRate)
{
	int retValue = SE_OK;
	int image_size = 0;
	unsigned char* src = 0;
	unsigned char* outbuf = 0;
	unsigned char* temp_buf = 0;
	int width = 0;
	int height = 0;
	int chksum = 0;
	unsigned short impNumber = 45200;
	float fQualityWSQ = 15.0f;
	FILE* f = NULL;
	bool flip_h = false;
	void* Instance_wsq = NULL;

	try
	{
		if (!dib)
			throw SE_WRONG_POINTER;

		Instance_wsq = init_instance();
		if( !Instance_wsq)
			throw SE_WRONG_POINTER;

		LPBITMAPINFOHEADER bih = (LPBITMAPINFOHEADER)dib;
		image_size = bih->biSizeImage;
		width = bih->biWidth;
		height = bih->biHeight;
		if(height > 0)
		{
			flip_h = true;
		}
		else
			height = -height;
		if(image_size == 0)
			image_size = width*height;
		src = (unsigned char*)(dib + sizeof(BITMAPINFOHEADER) + 256*sizeof(RGBQUAD));
		outbuf = new unsigned char[image_size];
		memset(outbuf,0,image_size);
		if(flip_h)
		{
			temp_buf = new unsigned char[image_size];
			memset(temp_buf,0,image_size);
			flipH(src,temp_buf,width,height);
			src = temp_buf;
		}
		for (int i = 0; i < image_size; i+=10)
			chksum += (*(src+i) + (i << 1));

		int  wsq_size = wsq_encode (Instance_wsq, src, outbuf, width, height, fQualityWSQ, chksum);// ,impNumber);
		if(wsq_size < 0)
			throw SE_UNKN_EXCEPTION;
		// Write the pixels
		f = fopen(filename, "wb");
		if (!f)
		{
			throw SE_OPEN_FILE;
		}
		size_t size2 = fwrite (outbuf, 1, wsq_size, f);
		if ( size2 != wsq_size) 
		{
			throw SE_WRITE_FILE;
		}
	}
	catch(int e)
	{
		setError(e);
		retValue = e;
	}
	catch (...)
	{
		setError(SE_UNKN_EXCEPTION);
		retValue = SE_UNKN_EXCEPTION;
	}
	if(temp_buf)
		delete[] temp_buf; temp_buf = NULL;
	if(outbuf)
		delete[] outbuf; outbuf = NULL;
	if(f)
		fclose(f); f = NULL;
	if(Instance_wsq != NULL)
		cancel_instance(Instance_wsq);
	src = NULL;
	return retValue;
}

int Sdk::save2WsqEx(unsigned char* wsq_buffer, unsigned int *wsq_size, const unsigned char* dib, float compressionRate)
{
	int retValue = SE_OK;
	int image_size = 0;
	unsigned char* src = 0;
	unsigned char* outbuf = 0;
	unsigned char* temp_buf = 0;
	int width = 0;
	int height = 0;
	int chksum = 0;
	unsigned short impNumber = 45200;
	float fQualityWSQ = 15.0f;
	bool flip_h = false;
	void* Instance_wsq = NULL;

	try
	{
		if (!dib)
			throw SE_WRONG_POINTER;

		Instance_wsq = init_instance();
		if( !Instance_wsq)
			throw SE_WRONG_POINTER;

		LPBITMAPINFOHEADER bih = (LPBITMAPINFOHEADER)dib;
		image_size = bih->biSizeImage;
		width = bih->biWidth;
		height = bih->biHeight;
		if(height > 0)
		{
			flip_h = true;
		}
		else
			height = -height;
		if(image_size == 0)
			image_size = width*height;
		src = (unsigned char*)(dib + sizeof(BITMAPINFOHEADER) + 256*sizeof(RGBQUAD));
		outbuf = new unsigned char[image_size];
		memset(outbuf,0,image_size);
		if(flip_h)
		{
			temp_buf = new unsigned char[image_size];
			memset(temp_buf,0,image_size);
			flipH(src,temp_buf,width,height);
			src = temp_buf;
		}
		for (int i = 0; i < image_size; i+=10)
			chksum += (*(src+i) + (i << 1));

//		int  wsq_size = wsq_encode (src, outbuf, width, height, fQualityWSQ, chksum);// ,impNumber);
		int  wsq_size_1 = wsq_encode (Instance_wsq, src, outbuf, width, height, fQualityWSQ, chksum);// ,impNumber);
		if(wsq_size_1 < 0)
			throw SE_UNKN_EXCEPTION;
		// Write the pixels
		if((int)*wsq_size < wsq_size_1)
		{
			*wsq_size = wsq_size_1;
			throw SE_MORE_DATA;
		}

		if (!wsq_buffer)
			throw SE_WRONG_POINTER;

		memcpy(wsq_buffer,outbuf,wsq_size_1);
		*wsq_size = wsq_size_1;
	}
	catch(int e)
	{
		setError(e);
		retValue = e;
	}
	catch (...)
	{
		setError(SE_UNKN_EXCEPTION);
		retValue = SE_UNKN_EXCEPTION;
	}
	if(temp_buf)
		delete[] temp_buf; temp_buf = NULL;
	if(outbuf)
		delete[] outbuf; outbuf = NULL;
	if(Instance_wsq != NULL)
		cancel_instance(Instance_wsq);
	src = NULL;
	return retValue;
}

/*
	The function read Wsq file and put image to dib buffer
	If the image resolution is not set in bitmap header, then it set to 500 DPI
	Parameters:
	filename      (input)   - input file name (input)
	size   (input-output)	- before the function call this variable should contains the 
	                          size the buffer pointed by dib. After call it contains the 
							  real size of data copied to dib.
	dib          (output)	- pointer to the buffer that receives the fingerprint image
							  Memory for that buffer should be allocated in application										
	Return Values:
	function returns SE_OK - if function succeeds, error code - otherwise
*/

int Sdk::readWsqEx (const unsigned char* wsq_buffer, unsigned int wsq_buffer_size, unsigned int *size, unsigned char* dib)
{
	int result = SE_OK;
	unsigned char* dest = NULL;
	unsigned char *row_1 = NULL;
	LPBITMAPINFOHEADER pBih = NULL;
	int	lensrc = 0;
	int width = 0;
	int height = 0;
	int chksum = 0;
	void* Instance_wsq = NULL;
	unsigned char* bits = NULL;

	try
	{
		Instance_wsq = init_instance();
		if( !Instance_wsq)
			throw SE_WRONG_POINTER;

		lensrc = wsq_buffer_size;

		for (int i = 0; i < lensrc; i+=10)
			chksum += (*(wsq_buffer+i) + (i << 1));

//		int  res = wsq_decode (NULL, wsq_image,lensrc,&width,&height,chksum);
		int  res = wsq_decode (Instance_wsq, NULL,(unsigned char*) wsq_buffer,lensrc,&width,&height,chksum);
		if( res != EMPTY_SOURCE)
			throw "";

		DWORD rowLen = ((width + 3) >> 2) << 2;	// row length with align
		// get offset to the image and size whole DIB
		int m_offset = sizeof(BITMAPINFOHEADER) + sizeof(RGBQUAD) * 256;
		DWORD sizeImage = height *	rowLen;
		int m_size = m_offset + sizeImage;

		if ((int)*size < m_size)
		{
			*size = m_size;
			throw SE_MORE_DATA;
		}
		
		if (!dib) throw SE_WRONG_POINTER; 

		memset(dib, 0, m_size);

		// fill BITMAPINFOHEADER
		pBih = (LPBITMAPINFOHEADER)dib;  
		pBih->biSize = sizeof(BITMAPINFOHEADER);
		pBih->biWidth = width;
		pBih->biHeight = -(LONG)height;
		pBih->biPlanes = 1;
		pBih->biBitCount = 8;
		pBih->biCompression = BI_RGB;
		pBih->biSizeImage = sizeImage;
		pBih->biClrUsed = 256;
		pBih->biClrImportant = 256;
		pBih->biXPelsPerMeter = DPI2PPM(DEF_DPI);
		pBih->biYPelsPerMeter = DPI2PPM(DEF_DPI);

		// fill RGBQUAD
		LPRGBQUAD pRGBQ = (LPRGBQUAD)((unsigned char*)pBih + pBih->biSize);
		for( int i = 0; i < 256; i++ ) 
		{
			pRGBQ[i].rgbBlue	 =	
			pRGBQ[i].rgbGreen =	
			pRGBQ[i].rgbRed	 = i;	
		}

		bits = new unsigned char[m_size];
		memset(bits,0,m_size);
		res = wsq_decode (Instance_wsq, bits,(unsigned char*) wsq_buffer,lensrc,&width,&height,chksum);
		if(res > 0)
			*size = m_size;
	// copy image bytes

		unsigned char* dst = dib + m_offset;
		unsigned char* src = bits;
		// image bytes should already arranged
		for (int j = 0; j < height; j++)
		{
			memcpy(dst, src, width);
			dst += rowLen;
			src += width;
		}
	}
	catch (int e)
	{
		result = e;
	}
	catch (...)
	{
		result = SE_UNKN_EXCEPTION;
	}
	if(bits)
		delete[] bits; bits = 0;
	pBih = NULL;
	if(Instance_wsq != NULL)
		cancel_instance(Instance_wsq);
	return result;
}

int Sdk::readWsq (const char* filename, unsigned int *size, unsigned char* dib)
{
	FILE* hFile = NULL;
	int result = SE_OK;
	unsigned char* wsq_image = NULL;
	int	lensrc = 0;

	try
	{
		hFile = fopen(filename,"rb");
		if( hFile == NULL)
			throw SE_READ_FILE;
		fseek(hFile,0,SEEK_END);
		lensrc = ftell(hFile);

		wsq_image = new BYTE[lensrc];
		fseek(hFile,0,SEEK_SET);
		fread(wsq_image,1,lensrc,hFile);
		result = readWsqEx(wsq_image,lensrc,size,dib);

	}
	catch (int e)
	{
		result = e;
	}
	catch (...)
	{
		result = SE_UNKN_EXCEPTION;
	}
	if(wsq_image)
		delete wsq_image; wsq_image = NULL;
	if(hFile)
		fclose(hFile); hFile = NULL;
	return result;
}




/*
	draw captured image
	Parameters:
	dib   (input) - pointer to the DIB that is returned by capture  functions 
	parent(input) - handle of the parent window, where draw image
*/
int Sdk::drawImage(const unsigned char* dib, const void* parent)
{
#ifndef _WIN32_WCE
	if (!dib) return SE_WRONG_POINTER;
#ifdef _WINDOWS
	
	LPBITMAPINFO bi            = (LPBITMAPINFO)dib;
	LPBITMAPINFOHEADER bih     = (LPBITMAPINFOHEADER)dib;
	const unsigned char *image = dib + bih->biSize + sizeof(RGBQUAD) * 256;

	// get the drawing area context and size
	RECT rect;
	HWND hWnd = (HWND)parent; 
	HDC hDc = GetDC (hWnd);
	GetClientRect (hWnd, &rect);
	int width = abs(rect.right - rect.left);
	int height = abs(rect.bottom - rect.top);


	// calculate new size of drawing area for stretch image proportionally
	if( (float)abs(bih->biHeight) / bih->biWidth > (float)height / width) 
		width = int((float)bih->biWidth * height / abs(bih->biHeight));
	else
		height = int((float)abs(bih->biHeight) * width / bih->biWidth);

	::SetStretchBltMode(hDc, COLORONCOLOR);

	::StretchDIBits(hDc, 0, 0, width, height, 0, 0, 
				bih->biWidth, abs(bih->biHeight), image, bi, 
				DIB_RGB_COLORS, SRCCOPY ); 
#else
#endif // WIN32
#endif // _WIN32_WCE
   return SE_OK;
}


// set m_error value
bool Sdk::setError(const wchar_t* msg)
{
	if (!msg) 
	{
		*m_error = 0;
		return false;
	}
	else
		wcscpy(m_error,msg);
	return true;
}
// set m_error value
void Sdk::setError(const char* msg)
{
	if (!msg) 
		*m_error = 0;
	else
		ToWide(m_error, (char*)msg);
}

int Sdk::getIpError(int num)
{
	switch(num)
	{
	case IP_OK:
		return SE_OK;
	case IP_LOW_MEMORY:
		return SE_LOW_MEMORY;
	case IP_UNKNOWN_EXCEPTION:
		return SE_UNKN_EXCEPTION;
	case IP_WRONG_DIB:
		return SE_WRONG_DIB;
	case IP_IMAGE_TOO_BIG:
		return SE_IMAGE_TOO_BIG;
	case IP_WRONG_RESOLUTION:
		return SE_WRONG_RESOLUTION;
	case IP_NO_IMAGE:
		return SE_NO_IMAGE;
	case IP_PROCESSING:
		return SE_PROCESSING;
	case IP_WRONG_POINTER:
		return SE_WRONG_POINTER;
	default:
		return -1;
	}
}

int Sdk::getMaError(int num)
{
	switch(num)
	{
	case MA_OK:
		return SE_OK;
	case MA_LOW_MEMORY:
		return SE_LOW_MEMORY;
	case MA_UNKNOWN_EXCEPTION:
		return SE_UNKN_EXCEPTION;
	case MA_WRONG_TEMPLATE:
	case MA_LOAD:
		return SE_WRONG_TEMPLATE;
	case MA_MATCH:
		return SE_MATCH;
	case MA_NO_LOAD:
		return SE_NO_LOAD;
	case MA_WRONG_POINTER:
		return SE_WRONG_POINTER;
	default:
		return -1;
	}
}

int Sdk::getDapiError(Sensor sensor, int num)
{
	switch(num)
	{
	case DAPI_OK:
		return SE_OK;
	case DAPI_LOW_MEMORY:
		return SE_LOW_MEMORY;
	case DAPI_NOT_INITIALIZED:
		return	SE_NOT_OPEN_SENSOR;
	case DAPI_UNKN_EXCEPTION:
		return SE_UNKN_EXCEPTION;
	case DAPI_WRONG_POINTER:
		return SE_WRONG_POINTER;
	case DAPI_LOAD_SCANDLL:
		return SE_LOAD_SCANDLL;
	case DAPI_CANCEL:
		return SE_CANCEL;
	case DAPI_TIMEOUT:
		return SE_TIMEOUT;
	case DAPI_NOT_IMPLEMENTED:
		return SE_NOT_IMPLEMENTED;
	case DAPI_OPEN_SENSOR:
		return SE_OPEN_SENSOR;
	case DAPI_NO_SUCH_SENSOR:
		return SE_NO_SUCH_SENSOR;
	case DAPI_NOT_OPENED:
		return SE_NOT_OPEN_SENSOR;
	case DAPI_SPOOF_FINGER:
		return SE_SPOOF_IMAGE;
	default:
		return -1;
	}
}

// set m_error value, by error number
bool Sdk::setError(const int numError)
{
	if (numError == SE_SYSTEM || numError == SE_DEVICE)
		return true;

	int errorId;
	switch (numError)
	{
	case SE_OK:                
		errorId = IDE_OK;
		break;
	case SE_UNKN_EXCEPTION:
		errorId = IDE_UNKN_EXCEPTION;
		break;
	case SE_LOW_MEMORY:
		errorId = IDE_LOW_MEMORY;
		break;
	case SE_LOAD_SCANDLL:
		errorId = IDE_LOAD_SCANDLL;
		break;
	case SE_NOT_INITIALIZED:
		errorId = IDE_NOT_INITIALIZED;
		break;
	case SE_LOAD_RESOURSE_DLL:
		errorId = IDE_LOAD_RESOURCE_DLL;
		break;
	case SE_NOT_OPEN_SENSOR:
		errorId = IDE_NOT_OPEN_SENSOR;
		break;
	case SE_JNI:
		errorId = IDE_JNI;
		break;
	case SE_NO_IMAGE:
		errorId = IDE_NO_IMAGE;
		break;
	case SE_WRONG_POINTER:
		errorId = IDE_WRONG_POINTER;
		break;
	case SE_PROCESSING:
		errorId = IDE_PROCESSING;
		break;
	case SE_MATCH:
		errorId = IDE_MATCH;
		break;
	case SE_IMAGE_TOO_BIG:
		errorId = IDE_IMAGE_TOO_BIG;
		break;
	case SE_WRONG_DIB:
		errorId = IDE_WRONG_DIB;
		break;
	case SE_CANCEL:
		errorId = IDE_CANCEL;
		break;
	case SE_TIMEOUT:
		errorId = IDE_TIMEOUT;
		break;
	case SE_OPEN_SENSOR:
		errorId = IDE_OPEN_SENSOR;
		break;
	case SE_OPEN_FILE:
		errorId = IDE_OPEN_FILE;
		break;
	case SE_WRITE_FILE:
		errorId = IDE_WRITE_FILE;
		break;
	case SE_READ_FILE:
		errorId = IDE_READ_FILE;
		break;
	case SE_WRONG_RESOLUTION:
		errorId = IDE_WRONG_RESOLUTION;
		break;
	case SE_MORE_DATA:
		errorId = IDE_MORE_DATA;
		break;
	case SE_KEY:
		errorId = IDE_KEY;
		break;
	case SE_LICENSE_NOT_FOUND:
		errorId = IDE_WRONG_LICENSE;
		break;
	case SE_TIME:
		errorId = IDE_TIME;
		break;
	case SE_INIT:
		errorId = IDE_INIT;
		break;
	case SE_HARDWARE:
		errorId = IDE_HARDWARE_PROTECT;
		break;
	case SE_FAM:
		errorId = IDE_FAM_PROTECT;
		break;
	case SE_NOT_IMPLEMENTED:
		errorId = IDE_NOT_IMPLEMENTED;		
		break;
	case SE_NO_SUCH_SENSOR:	
		errorId = IDE_NO_SUCH_SENSOR;		
		break;
	case SE_NO_LOAD:
		errorId = SE_NO_LOAD;
		break;
	case SE_PROBE_PARSE:
		errorId = IDE_PROBE_PARSE;
		break;
	case SE_GALLERY_PARSE:
		errorId = IDE_GALLERY_PARSE;
		break;
	case SE_DIF_FING_ERR:
		errorId = IDE_DIF_FING_ERR;
		break;
	case SE_PARSE_TEMPL:
		errorId = IDE_PARSE_TEMPL;
		break;
	case SE_WRONG_TEMPLATE:
		errorId = IDE_WRONG_TEMPLATE;
		break;
	case SE_SPOOF_IMAGE:
		errorId = IDE_SPOOF_FINGER;
		break;
	case SE_NULL_TEMPLATE:
		errorId = IDE_NULL_TEMPLATE;
		break;
		
	default:
		errorId = -1;
		break;
	}
	int lang = 1033;
#if defined(WIN32) || defined(_WIN32_WINCE)
	lang = (int)GetUserDefaultLangID();
#else
	lang = 1033;
#endif
	LoadMessageString(errorId,m_error,S_MAX_DESCR_LEN,lang);
	return true;
}

/////////////////////////////////////////////////////////////////////////////////////////
//	SET PARAMETERS
/////////////////////////////////////////////////////////////////////////////////////////
//	Set search parameters
#define MIN_ANGLE	30
int Sdk::setSearchParams (const SearchParams* params)
{
	if (!params) return SE_WRONG_POINTER;
	try
	{
		if      (params->maxAngle > 180      ) m_searchParams.maxAngle = 180;
		else if (params->maxAngle < MIN_ANGLE) m_searchParams.maxAngle = MIN_ANGLE;
		else								            m_searchParams.maxAngle = params->maxAngle;	
			
		int MAX_DISP = (int)(MAX_DISP_DEF*25.4/DEF_DPI);
		int MIN_DISP = (int)(MAX_DISP_DEF*25.4/DEF_DPI/10);
		if      (params->maxDisp > MAX_DISP)   m_searchParams.maxDisp = MAX_DISP;
		else if (params->maxDisp < MIN_DISP)   m_searchParams.maxDisp = MIN_DISP;
		else						         		   m_searchParams.maxDisp = params->maxDisp;

		if      (params->searchSpeed > HIGHEST_MATCH_SPEED)	m_searchParams.searchSpeed = HIGHEST_MATCH_SPEED;
		else if (params->searchSpeed <     LOW_MATCH_SPEED)	m_searchParams.searchSpeed = LOW_MATCH_SPEED;
		else											               m_searchParams.searchSpeed = params->searchSpeed;

		m_param.maxAngle = m_searchParams.maxAngle;
		m_param.maxDisp = MM_2_DOT(m_searchParams.maxDisp);
		m_param.searchSpeed = m_searchParams.searchSpeed;
	}
	catch(...)
	{
		return SE_UNKN_EXCEPTION;
	}
	return SE_OK;
}

//	Get search parameters
const SearchParams* Sdk::getSearchParams ()
{
	return &m_searchParams;
}
const char* Sdk::getLastErrorMsg ()
{
	ToChar(m_error_descr,m_error);
	return (const char*)m_error_descr;
}

/*
	The function allocates memory for template variable
	Parameters:
	fpTempalte (input)- buffer for fingerprint template
	Return value:
	The function returns MA_OK if success and error code otherwise
*/
int Sdk::allocate_Template (unsigned char **fpTemplate)
{
	TemplateData templ;
	templ.numFinger = FINGPOS_RT;
	templ.fpTemplate = NULL;
	int result = m_ma.allocateTemplate(templ.fpTemplate);
	if (result == MA_OK)
		*fpTemplate = templ.fpTemplate;
	return result;
}

/*
	The function free memory that was allocated by 'allocateTemplate' function
	Parameters:
	fpTempalte (input)- buffer for fingerprint template
	Return value:
	The function returns MA_OK if success and error code otherwise
*/
int Sdk::free_Template (unsigned char **fpTemplate)
{
	TemplateData templ;
	templ.numFinger = FINGPOS_RT;
	templ.fpTemplate = *fpTemplate;
	int result = m_ma.freeTemplate (templ.fpTemplate);
	return result;
}
int Sdk::getMinexError(int numError)
{
	switch(numError)
	{
	case SME_OK:
		return SE_OK;
	case SME_IMAGE_SIZE:
		return SE_IMAGE_TOO_BIG; // Image size not supported
	case SME_PROCESS:
		return SE_PROCESSING;  // Unspecified error happened while extract 
		// minutiae
	case SME_IMPRESSION_TYPE:
		return SE_IMPRESSION_TYPE;  // Specified impression type is not supported
	case SME_NULL_TEMPLATE:
		return SE_NULL_TEMPLATE; // Failed to match templates – null probe or 
		// gallery template
	case SME_PROBE_PARSE:
		return SE_PROBE_PARSE;  // Failed to match templates – unable to parse 
		// probe template
	case SME_GALLERY_PARSE:
		return SE_GALLERY_PARSE;  // Failed to match templates – unable to parse 
		// gallery template
	case SME_WRONG_POINTER:
		return SE_WRONG_POINTER; // one of the pointer passed to the function is NULL
	case SME_WRONG_PARAM:
		return SE_WRONG_PARAMETER;  // one of the parameter passed to the function is 
		// out of range (e.g. finger number > 10)
	case SME_MATCH:
		return SE_MATCH; // Unspecified error happened while matching
	case SME_LOW_MEMORY:
		return SE_LOW_MEMORY;  // not enough memory
	case SME_UNKN_ERR:
		return SE_UNKN_EXCEPTION; // Unspecified error happened
	case SME_DIF_FING: // Two compared templates keep information about different fingers, 
		//  so nothing was matched   
		return SE_DIF_FING_ERR;
	case SME_SAME_FING: // array of rawImage structure has members with same value of 
		// 'finger' field   
		// NOTE: At this version of software you cannot put into template the information 
		//  about more than one impression of same finger. 
		return SE_SAME_FING_ERR;
	case SME_NULL_IMAGE: // passed image has zero size or pointer to the image is NULL  
		return SE_NULL_IMAGE;
	case SME_PARSE_TEMPL:  // error of parse template
		return SE_PARSE_TEMPL;
	case SME_DIF_FING_SIZE:  // fingerprint images have different size. 
		// NOTE: The fingerprint images those are passed to 'create_NIST_template' or 
		// 'create_ISO_template' function should be taken from the same sensor 
		// and have the same size 
		return SE_DIF_FING_SIZE_ERR;
	default:
		return -1;
	}
	return SE_OK;
}

int Sdk::create_Template_NIST (unsigned int numFingers, DIBImage *dibImage, 
							   unsigned char *templ, unsigned char* quality, int *templ_size, int maxTemplateSize, bool certifiedSensor, unsigned short sensorID)
{
	RawImage* rawImage = NULL;
	unsigned char* temporary_image[10];
	bool delete_temp_image[10];
	int code_ret = SE_OK;
	bool use_minex = false;
	try
	{
#ifdef HARDWARE_PROTECT
		key_protect_check() == SE_OK ? keyProtect = 1 : keyProtect = 0;
		if (!keyProtect && !m_license_init)
		{
			setError(SE_LICENSE_NOT_FOUND);
			throw SE_LICENSE_NOT_FOUND;
		}
		else if(!keyProtect)
		{
			throw SE_HARDWARE;
		}
#endif
		for(int i = 0; i < 10; i++)
		{
			temporary_image[i] = 0;
			delete_temp_image[i] = false;
		}

		rawImage = new RawImage[numFingers];
		for(unsigned int i = 0; i < numFingers; i++)
		{
			LPBITMAPINFOHEADER m_bih = (LPBITMAPINFOHEADER)dibImage[i].image;

			if (m_bih->biBitCount != 8 || m_bih->biCompression != BI_RGB || m_bih->biPlanes != 1)
				throw SE_WRONG_DIB;
			if (m_bih->biClrUsed != 0 && m_bih->biClrUsed != 256)
				throw SE_WRONG_DIB;
			if (m_bih->biClrImportant != 0 && m_bih->biClrImportant != 256)
				throw SE_WRONG_DIB;
			DWORD dpi_low = DEF_DPI-2;
			DWORD dpi_high = DEF_DPI + 2;
			if (m_bih->biXPelsPerMeter < (int)DPI2PPM(dpi_low) ||  m_bih->biXPelsPerMeter > (int)DPI2PPM(dpi_high))
				throw SE_WRONG_RESOLUTION;
			if (m_bih->biYPelsPerMeter < (int)DPI2PPM(dpi_low) || m_bih->biYPelsPerMeter > (int)DPI2PPM(dpi_high))
				throw SE_WRONG_RESOLUTION;

			rawImage[i].finger = dibImage[i].finger;
			rawImage[i].impression_type = dibImage[i].impression_type;
			rawImage[i].height = (WORD)abs(m_bih->biHeight);
			rawImage[i].width  = (WORD)((m_bih->biWidth+3)/4*4);
			if(m_bih->biHeight < 0 )
			{
				temporary_image[i] = dibImage[i].image + getOffset(m_bih);
			}
			else
			{
				long size_image = m_bih->biSizeImage > 0 ? m_bih->biSizeImage : m_bih->biWidth*m_bih->biHeight;
				temporary_image[i] = new unsigned char[ size_image ];
				flipH(dibImage[i].image + getOffset(m_bih),temporary_image[i],rawImage[i].width, rawImage[i].height);
				delete_temp_image[i] = true;
			}
			rawImage[i].image = temporary_image[i];
		}
		use_minex = true;
		unsigned int tpl_size = 0;
		unsigned char quality_in = 0;
		code_ret = create_NIST_template(numFingers,rawImage,templ,&tpl_size,quality,maxTemplateSize,NULL,certifiedSensor,sensorID);
		if(code_ret== SME_OK)
		{
			unsigned int numberFingers = numFingers;
			unsigned char qual[MAX_FINGERS];
			unsigned char finger[MAX_FINGERS];
			unsigned char numMinutiae[MAX_FINGERS];
			Minutiae	minutiae[MAX_FINGERS][MAX_MINUTIAE];
			unsigned short width = 0;
			unsigned short height = 0;
			if(SME_OK == readNISTtemplate(numberFingers,templ,numMinutiae,minutiae,width,height,qual,finger))
			{
				for(unsigned int i = 0; i < numberFingers; i++)
					quality[i] = qual[i];
			}
			*templ_size = (int)tpl_size;
		}
	}
	catch(int err)
	{
		code_ret = err;
	}
	catch(...)
	{
		;
	}
	if(rawImage)
		delete rawImage;
	for(int i = 0; i < 10; i++)
	{
		if(delete_temp_image[i] == true)
			delete[] temporary_image[i]; temporary_image[i] = 0; delete_temp_image[i] = false;
	}
	if(use_minex)
		code_ret = getMinexError(code_ret);
	setError(code_ret);
	return code_ret;
}
int Sdk::create_Template_ISO (unsigned int numFingers, DIBImage *dibImage, 
							  unsigned char *templ, unsigned char* quality, int *templ_size, int maxTemplateSize ,bool certifiedSensor, unsigned short sensorID)
{
	RawImage* rawImage = NULL;
	int code_ret = SE_OK;
	bool use_minex = false;
	unsigned char* temporary_image[10];
	bool delete_temp_image[10];

	try
	{
#ifdef HARDWARE_PROTECT
		key_protect_check() == SE_OK ? keyProtect = 1 : keyProtect = 0;
		if (!keyProtect && !m_license_init)
		{
			setError(SE_LICENSE_NOT_FOUND);
			throw SE_LICENSE_NOT_FOUND;
		}
		else if(!keyProtect)
		{
			throw SE_HARDWARE;
		}
#endif
		for(int i = 0; i < 10; i++)
		{
			temporary_image[i] = 0;
			delete_temp_image[i] = false;
		}
		rawImage = new RawImage[numFingers];
		for(unsigned int i = 0; i < numFingers; i++)
		{
			LPBITMAPINFOHEADER m_bih = (LPBITMAPINFOHEADER)dibImage[i].image;
			if (m_bih->biBitCount != 8 || m_bih->biCompression != BI_RGB || m_bih->biPlanes != 1)
				throw SE_WRONG_DIB;
			if (m_bih->biClrUsed != 0 && m_bih->biClrUsed != 256)
				throw SE_WRONG_DIB;
			if (m_bih->biClrImportant != 0 && m_bih->biClrImportant != 256)
				throw SE_WRONG_DIB;
			DWORD dpi_low = DEF_DPI-2;
			DWORD dpi_high = DEF_DPI + 2;
			if (m_bih->biXPelsPerMeter < (int)DPI2PPM(dpi_low) ||  m_bih->biXPelsPerMeter > (int)DPI2PPM(dpi_high))
				throw SE_WRONG_RESOLUTION;
			if (m_bih->biYPelsPerMeter < (int)DPI2PPM(dpi_low) || m_bih->biYPelsPerMeter > (int)DPI2PPM(dpi_high))
				throw SE_WRONG_RESOLUTION;

			rawImage[i].finger = dibImage[i].finger;
			rawImage[i].impression_type = dibImage[i].impression_type;
			rawImage[i].height = (WORD)abs(m_bih->biHeight);
			rawImage[i].width = (WORD)((m_bih->biWidth+3)/4*4);
			if(m_bih->biHeight < 0 )
			{
				temporary_image[i] = dibImage[i].image + getOffset(m_bih);
			}
			else
			{
				long size_image = m_bih->biSizeImage > 0 ? m_bih->biSizeImage : m_bih->biWidth*m_bih->biHeight;
				temporary_image[i] = new unsigned char[ size_image ];
				flipH(dibImage[i].image + getOffset(m_bih),temporary_image[i],rawImage[i].width, rawImage[i].height);
				delete_temp_image[i] = true;
			}
			rawImage[i].image = temporary_image[i];
		}
		use_minex = true;
		unsigned int tpl_size = 0;
		code_ret = create_ISO_template(numFingers,rawImage,templ,&tpl_size,quality,maxTemplateSize,NULL,certifiedSensor,sensorID);
		if(code_ret== SME_OK)
		{
			unsigned int numberFingers = numFingers;
			unsigned char qual[MAX_FINGERS];
			unsigned char finger[MAX_FINGERS];
			unsigned char numMinutiae[MAX_FINGERS];
			Minutiae	minutiae[MAX_FINGERS][MAX_MINUTIAE];
			unsigned short width = 0;
			unsigned short height = 0;
			int retCode = readISOtemplate(numberFingers,templ,numMinutiae,minutiae,width,height,qual,finger);
			if(SME_OK == retCode)
			{
				for(unsigned int i = 0; i < numberFingers; i++)
					quality[i] = qual[i];
			}
			*templ_size = (int)tpl_size;
		}
	}
	catch(int err)
	{
		code_ret = err;
	}
	catch(...)
	{
		;
	}
	if(rawImage)
		delete rawImage;
	for(int i = 0; i < 10; i++)
	{
		if(delete_temp_image[i] == true)
			delete[] temporary_image[i]; temporary_image[i] = 0; delete_temp_image[i] = false;
	}
	if(use_minex)
		code_ret = getMinexError(code_ret);
	setError(code_ret);
	return code_ret;
}

int Sdk::match_Templates_NIST (const unsigned char *probeTemplate, const unsigned char *galleryTemplate, unsigned char *score)
{
	int code_ret = SE_OK;
	bool use_minex = false;
	try
	{
#ifdef HARDWARE_PROTECT
		key_protect_check() == SE_OK ? keyProtect = 1 : keyProtect = 0;
		if (!keyProtect && !m_license_init)
		{
			setError(SE_LICENSE_NOT_FOUND);
			throw SE_LICENSE_NOT_FOUND;
		}
		else if(!keyProtect)
		{
			throw SE_HARDWARE;
		}
#endif
		use_minex = true;
		int similarity = 0;
		code_ret = match_NIST_templates(probeTemplate,galleryTemplate,m_maxAngle,&similarity);
		if(code_ret == SME_OK)
		{
			*score = (unsigned char)(similarity/100);
		}
		else
			*score = 0;
		code_ret = getMinexError(code_ret);
	}
	catch(int aa)
	{
		code_ret = aa;
	}
	catch(...)
	{
		code_ret = SE_UNKN_EXCEPTION;
	}
	setError(code_ret);
	return code_ret;
}

int Sdk::match_Templates_ISO (const unsigned char *probeTemplate, const unsigned char *galleryTemplate, unsigned char *score)
{
	int code_ret = SE_OK;
	bool use_minex = false;
	try
	{
#ifdef HARDWARE_PROTECT
		key_protect_check() == SE_OK ? keyProtect = 1 : keyProtect = 0;
		if (!keyProtect && !m_license_init)
		{
			setError(SE_LICENSE_NOT_FOUND);
			throw SE_LICENSE_NOT_FOUND;
		}
		else if(!keyProtect)
		{
			throw SE_HARDWARE;
		}
#endif
		use_minex = true;
		int similarity = 0;
		code_ret = match_ISO_templates(probeTemplate,galleryTemplate,m_maxAngle,&similarity);
		if(code_ret == SME_OK)
		{
			*score = (unsigned char)(similarity/100);
		}
		else
			*score = 0;
		code_ret = getMinexError(code_ret);
	}
	catch(int aa)
	{
		code_ret = aa;
	}
	catch(...)
	{
		code_ret = SE_UNKN_EXCEPTION;
	}
	setError(code_ret);
	return code_ret;
}
/////////////////////////////////////////////////////////////////////////////////////////
// Allocate templates
/////////////////////////////////////////////////////////////////////////////////////////

int Sdk::allocate_Template_NIST (unsigned int numFingers, unsigned char **nistTempl)
{
	int code_ret = allocateNISTtemplate(numFingers,nistTempl);
	code_ret = getMinexError(code_ret);
	setError(code_ret);
	return code_ret;
}

int Sdk::allocate_Template_ISO (unsigned int numFingers, unsigned char **isoTempl)
{
	int code_ret = allocateISOtemplate(numFingers,isoTempl);
	code_ret = getMinexError(code_ret);
	setError(code_ret);
	return code_ret;
}

int Sdk::free_Template_NIST(unsigned char **templ)
{
	int code_ret = freeNISTtemplate(templ);
	code_ret = getMinexError(code_ret);
	return code_ret;
}

int Sdk::free_Template_ISO(unsigned char **templ)
{
	int code_ret = freeISOtemplate(templ);
	code_ret = getMinexError(code_ret);
	return code_ret;
}
int Sdk::match_TECH5_NIST(const unsigned char *fpTemplate, const unsigned char *templateNIST, unsigned char *score)
{
	int similarity = 0;
	int code_ret = SE_OK;
	bool use_minex = false;
	unsigned char* nist_tpl = 0;
	try
	{
#ifdef HARDWARE_PROTECT
		key_protect_check() == SE_OK ? keyProtect = 1 : keyProtect = 0;
		if (!keyProtect && !m_license_init)
		{
			setError(SE_LICENSE_NOT_FOUND);
			throw SE_LICENSE_NOT_FOUND;
		}
		else if(!keyProtect)
		{
			throw SE_HARDWARE;
		}
#endif
		use_minex = true;
		allocateNISTtemplate(1,&nist_tpl);
		code_ret = convertToNIST((unsigned char*)fpTemplate,nist_tpl);
		if(code_ret != SME_OK)
			throw code_ret;
		code_ret = match_NIST_templates(nist_tpl,templateNIST,m_maxAngle,&similarity);
		if(code_ret == SME_OK)
			*score = (unsigned char)(similarity/100);
		else
			*score = 0;
	}
	catch(int aa)
	{
		code_ret = aa;
	}
	catch(...)
	{
		;
	}
	if(use_minex)
		code_ret = getMinexError(code_ret);
	if(nist_tpl)
		free_Template_NIST(&nist_tpl); nist_tpl = 0;
	setError(code_ret);
	return code_ret;
}
int Sdk::match_TECH5_ISO(const unsigned char *fpTemplate, const unsigned char *templateISO, unsigned char *score)
{
	int similarity = 0;
	int code_ret = SE_OK;
	bool use_minex = false;
	try
	{
#ifdef HARDWARE_PROTECT
		key_protect_check() == SE_OK ? keyProtect = 1 : keyProtect = 0;
		if (!keyProtect && !m_license_init)
		{
			setError(SE_LICENSE_NOT_FOUND);
			throw SE_LICENSE_NOT_FOUND;
		}
		else if(!keyProtect)
		{
			throw SE_HARDWARE;
		}
#endif
		use_minex = true;
		code_ret = convertToISO((unsigned char*)fpTemplate,m_iso_template);
		if(code_ret != SME_OK)
			throw code_ret;
		code_ret = match_ISO_templates(m_iso_template,templateISO,m_maxAngle,&similarity);
		if(code_ret == SME_OK)
			*score = (unsigned char)(similarity/100);
		else
			*score = 0;
	}
	catch(int aa)
	{
		code_ret = aa;
	}
	catch(...)
	{
		;
	}
	if(use_minex)
		code_ret = getMinexError(code_ret);
	setError(code_ret);
	return code_ret;
}
