#ifndef MESSAGE_STRINGS
#define MESSAGE_STRINGS

#include "resource.h"

int LoadMessageString(unsigned int message_id, wchar_t* buffer, int maxCount, int lang = 1033);

#endif