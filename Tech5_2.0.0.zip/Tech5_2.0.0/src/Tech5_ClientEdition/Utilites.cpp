/*****************************************************************************
	utilites.cpp - implementation function-utilites declared in utilites.h

	
   Author A.Mosunov
   Version 2.2.1 of 31.05.2004

*******************************************************************************/
#include <string.h>

#include <stdio.h>
#include <stdlib.h>
#include <sfsDef.h>
#include "Utilites.h"

#ifdef _WINDOWS
#include "pefile.h"

#ifndef S_MAX_DESCR_LEN 		     // maximum length of error description in characters
#define S_MAX_DESCR_LEN 		255     // maximum length of error description in characters
#endif

// get system error description
void getSystemError(wchar_t* err)
{

	char temp[S_MAX_DESCR_LEN];
	getSystemError(temp);
#ifdef WIN32
	if (!MultiByteToWideChar (CP_ACP, NULL, temp, -1, err, S_MAX_DESCR_LEN))
		err[0] = L'\0';
#else
	int cchWideChar = mbstowcs(0,temp,0);
	if(err == NULL)
		err = new wchar_t[cchWideChar+1];
	mbstowcs(err,temp,cchWideChar);
#endif
}

void getSystemError(char* err)
{
#ifdef _WINDOWS
#if defined(UNICODE) || defined (_UNICODE)
	err[0] = '\0';
	wchar_t* buffer = NULL;
	int numError = GetLastError();
	if (FormatMessage (FORMAT_MESSAGE_ALLOCATE_BUFFER | 
						FORMAT_MESSAGE_FROM_SYSTEM | 
						FORMAT_MESSAGE_IGNORE_INSERTS,
		    			NULL, numError,
//    					MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
    					MAKELANGID(LANG_ENGLISH, SUBLANG_DEFAULT), // English language
    					buffer, 0, NULL)
		)
		WideCharToMultiByte(CP_ACP,WC_DEFAULTCHAR,buffer,-1,err,S_MAX_DESCR_LEN,0,0);
	LocalFree( buffer );
#else
	err[0] = '\0';
	char* buffer = NULL;
	int numError = GetLastError();
	if (FormatMessageA (FORMAT_MESSAGE_ALLOCATE_BUFFER | 
						FORMAT_MESSAGE_FROM_SYSTEM | 
						FORMAT_MESSAGE_IGNORE_INSERTS,
		    			NULL, numError,
//    					MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
    					MAKELANGID(LANG_ENGLISH, SUBLANG_DEFAULT), // English language
    					buffer, 0, NULL)
		)
	strncpy (err, buffer, S_MAX_DESCR_LEN - 1);
	LocalFree( buffer );
#endif // UNICODE
#else
	err[0]='\0';
#endif
 }

#endif // WIN32



/*
	get checksums
	name - filename
	headercheckSum - checksum readed from optional header PE-file
	checkSum - calculated checksum
*/
bool getCheckSums (char* name, unsigned long& headerSum, unsigned long& checkSum)
{
 	unsigned char* p = NULL;
 
	// open file 
	FILE* f = fopen (name, "rb");
	long length = 0; // file length
	if (!f) return false;
	// get length of the file
	if (fseek(f, 0, SEEK_END)) return false;
	length = ftell (f);
	if (!length || length == -1) return false;
	if (fseek(f, 0, SEEK_SET)) return false;
	// read file to p
	p = new unsigned char[length];
	if(!p) return false;
	memset(p, 0x00, length);
	size_t len = fread (p, 1, length, f);
	fclose(f);
 	if (len != (size_t)length)
	{
		delete p;
		return false;
	}

#ifdef _WINDOWS
	// read checksum from image optional header 
	PIMAGE_OPTIONAL_HEADER    pHeader;
	pHeader = (PIMAGE_OPTIONAL_HEADER)OPTHDROFFSET (p);
	headerSum = pHeader->CheckSum;

	// calculating checksum
	pHeader->CheckSum = 0;
	checkSum = (DWORD)calkChecksum(p, length);
#endif

	if (p) delete p;
	return true;
}

/*
	calculating and return checksum for memory block
	s - point to the memory block
	n - size of the memory block
*/
int calkChecksum(register unsigned char *s, register int n)
{
	register short sum;
	register unsigned short t;
	register short x;
	sum = -1;
	x = 0;
	do
	{
		if (sum < 0)
		{
			sum <<= 1;
			sum++;
		}
		else
			sum <<= 1;
		t = sum;
		sum += *s++ & 0377;
		x += sum^n;
		if ((unsigned short)sum <= t)
			sum ^= x;
	} while (--n > 0);

	return (sum);

	return 0;
}
