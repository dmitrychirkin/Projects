/*****************************************************************************
	sdk.h - CSdk class

*******************************************************************************/
#ifndef SDK_H_
#define SDK_H_

#include <stdlib.h>
#include <string.h>

#ifndef _WINDOWS
typedef void*	HANDLE;
typedef void*	HWND;
#endif

#ifndef MAX_PATH
#define MAX_PATH          260
#endif

#if defined( linux) || defined(ANDROID)
#include <pthread.h>
#endif

#include "Utilites.h"
#include "sfsDef.h"
#include "libMinexFull.h"
#include <swsq31.h>

#include "ip.h"

#include "ma100.h"

#include "hardwarebind.h"

#define DO_NOT_USE_SYNC	1
#define USE_CRITICAL_SECTION	1

#define INIT_VALUE 0x12345678
#ifndef CHECK
#define CHECK(x) if((x) != CE_OK) return x
#endif // CHECK
#define INIT(x)     {if (!x || !x->isInit()) return SE_INIT; x->setError(SE_OK);}
#define INIT2(x)    {if (!x || !x->isInit()) return NULL; x->setError(SE_OK);}
#define INIT3(x)     {if (!x || !x->isInit()) return SE_INIT;}

using namespace accelMatch;

class Sdk
{
	long					m_init;         // value that use for check if class was really initialized
	SearchParams			m_searchParams;	// search parameters
	SearchParam				m_param;// real search parameters
	int						m_cores_count;
	Ip		   				m_ip;
	Ma100						m_ma;
	wchar_t					m_error[S_MAX_DESCR_LEN]; // error description
	char					m_error_descr[S_MAX_DESCR_LEN]; // error description
	unsigned long			m_hEvent;
	int						m_maxAngle;	//max angle for minex
	unsigned char*			m_nist_template;
	unsigned char*			m_iso_template;
#ifdef	HARDWARE_PROTECT
	char					m_licenseFileName[MAX_PATH];
	wchar_t					m_licenseFileName_wide[MAX_PATH];
	unsigned short			m_license_init;
	int						keyProtect;
	Tech5_Hardware_Protect* m_protect;
#endif

	__inline int return_code_form(bool code_key, bool code_time);

	int RangedRandDemo( int range_min, int range_max )
	{
		// Generate random numbers in the half-closed interval
		// [range_min, range_max). In other words,
		// range_min <= random number < range_max
		int u = (int)( (double)rand() / (RAND_MAX + 1) * (range_max - range_min) + range_min);
		return u;
	}

	int wsqCheckSum (BYTE *src,  int lensrc)
	{
		int sum=0;
		for (int i = 0; i < lensrc; i+=10)
			sum += (*(src+i) + (i << 1));
		return sum;
	}

public:
	Sdk(int cores_count);
	~Sdk();

	void init() {m_init = INIT_VALUE;}	
	bool isInit() {return (m_init == INIT_VALUE);}
	// Set search parameters
	int setSearchParams (const SearchParams* params);
	// Get search parameters
	const SearchParams* getSearchParams ();
	// Set license path
	int setLicenseFilename(const char* license_filename, long* extra_data, TECH5_PRODUCTS product);
	char* getLicenseFilename(){return "";}
	bool Hardware_Protect_Check();
	int key_protect_check();


	//PROCESS
	/* 
	Processes set of fingerprint image and build the set of templates.
	Parameters:
	dib_image (input)    -	image structure that contains information about fingerprint
							NOTE: image should be uncompressed, 256 gray-level(8 bit per pixel),
							top-down and 500 dpi
	fpTemplate(output)	 - the buffer that receives the built template
							Memory for that buffer should be previously allocated by 
							'allocateTemplates' function
	templSize (output)   - this variable receives the size of built template
	quality   (output)   - this variable receives the quality of fingerprint image
	maxWidth, maxHeight  - if this parameters > 0 and source image have size bigger than these
		                      values, then source image will cut to this size(input)
	Return Values:
	function returns IP_OK - if function succeeds, error code - otherwise
	*/	
	int create_Template (unsigned char* dib_image, FINGERS fing_num, unsigned char *fpTemplate, 
						unsigned int *templSize, unsigned char *quality,
						unsigned int maxWidth = MAX_WIDTH, unsigned int maxHeight = MAX_HEIGHT);

	/* 
	Processes set of fingerprint image and build the set of templates.
	Parameters:
	dib_image (input)    -	DIBImage structure that contains information about fingerprint
							NOTE: image should be uncompressed, 256 gray-level(8 bit per pixel),
							top-down and 500 dpi
	fpTemplate(output)	 - the buffer that receives the built template
							Memory for that buffer should be previously allocated by 
							'allocateTemplates' function
	templSize (output)   - this variable receives the size of built template
	quality   (output)   - this variable receives the quality of fingerprint image
	maxWidth, maxHeight  - if this parameters > 0 and source image have size bigger than these
		                      values, then source image will cut to this size(input)
	Return Values:
	function returns IP_OK - if function succeeds, error code - otherwise
	*/	
	int create_TemplateEx (DIBImage dib_image, unsigned char *fpTemplate, 
		unsigned int *templSize, unsigned char *quality,
		unsigned int maxWidth = MAX_WIDTH, unsigned int maxHeight = MAX_HEIGHT);

//	return last error description
//	const char* getLastErrorMsg (){return m_error;}
	const char* getLastErrorMsg ();
	// set m_error value, by error number
	bool setError(const int number);
	// set m_error value
	void setError(const char* msg);
	bool setError(const wchar_t* msg);
	int getMinexError(int numError);

// TOOLS
	/*
	saves captured image to BMP file
	Parameters:
	filename (input) - output file name 
	dib      (input) - pointer to the DIB, that is returned by capture 
						functions 
	*/
	int save2Bmp(const char* filename, const unsigned char* dib);
	int save2BmpEx(unsigned char* bitmap_buffer, unsigned int* bitmap_size, const unsigned char* dib);
	/*
	The function read BMP file and put image to dib buffer
	If the image resolution is not set in bitmap header, then it set to 500 DPI
	Parameters:
	filename      (input)   - input file name (input)
	size   (input-output)	- before the function call this variable should contains the 
	                          size the buffer pointed by dib. After call it contains the 
							  real size of data copied to dib.
	dib          (output)	- pointer to the buffer that receives the fingerprint image
							  Memory for that buffer should be allocated in application										
	Return Values:
	function returns CE_OK - if function succeeds, error code - otherwise
	*/
	int readBmp (const char* filename, unsigned int *size, unsigned char* dib);
	int readBmpEx (const unsigned char* bitmap_buffer, unsigned int bitmap_buffer_size ,unsigned int *size, unsigned char* dib);

	/*
	saves captured image to WSQ file
	Parameters:
	filename (input) - output file name 
	dib      (input) - pointer to the DIB, that is returned by capture 
						functions 
	compressionRate() - compression image coefficient
	*/
	int save2Wsq(const char* filename, const unsigned char* dib, float compressionRate);
	int save2WsqEx(unsigned char* wsq_buffer, unsigned int *wsq_size, const unsigned char* dib, float compressionRate);
	/*
	The function read WSQ file and put image to dib buffer
	If the image resolution is not set in bitmap header, then it set to 500 DPI
	Parameters:
	filename      (input)   - input file name (input)
	size   (input-output)	- before the function call this variable should contains the 
	                          size the buffer pointed by dib. After call it contains the 
							  real size of data copied to dib.
	dib          (output)	- pointer to the buffer that receives the fingerprint image
							  Memory for that buffer should be allocated in application										
	Return Values:
	function returns CE_OK - if function succeeds, error code - otherwise
	*/
	int readWsq (const char* filename, unsigned int *size, unsigned char* dib);
	int readWsqEx (const unsigned char* wsq_buffer, unsigned int wsq_buffer_size, unsigned int *size, unsigned char* dib);



	/*
	draw captured image
	Parameters:
	dib   (input) - pointer to the DIB that is returned by capture  functions 
	parent(input) - handle of the parent window, where draw image
	*/
	int drawImage(const unsigned char* dib, const void* parent);
	/*
	The function allocates memory for template variable
	Parameters:
	fpTempalte (input)- buffer for fingerprint template
	Return value:
	The function returns MA_OK if success and error code otherwise
	*/
	int allocate_Template (unsigned char** fpTemplate);
	/*
	The function free memory that was allocated by 'allocateTemplate' function
	Parameters:
	fpTempalte (input)- buffer for fingerprint template
	Return value:
	The function returns MA_OK if success and error code otherwise
	*/
	int free_Template (unsigned char** fpTemplate);

	// MATCH
	/*
	Compares two templates
	Parameters:
	fpTempl1   (input)  - the first fingerprint template
	fpTempl2   (input)  - the second fingerprint template
	similarity (output) - this variable receives the value that shows 
				         how two fingerprints similarity one to other in percent
	Return value:
	The function returns MA_OK if success and error code otherwise
	*/
	int match_Templates(const unsigned char* fpTempl1, const unsigned char* fpTempl2, 
		                          unsigned char *similarity,FINGERS fingpos_1, FINGERS fingpos_2);
/*
	Next two functions have the same functionality as 'match' function but 
	allows you to perform the 1:many search more quickly.
	At first you should call 'loadTemplate' function for loading the first template
	and then call 'matchEx' function for match with each of second templates
*/
	int loadTemplate(const unsigned char* pTempl, FINGERS fingpos);
	int match_TemplatesEx(const unsigned char* pTempl, unsigned char *similarity, FINGERS fingpos);
	/*
	The function allocates memory for buffer that will receives INCITS 378 compliance template
	Parameters:
	numFingers (input)       : number of fingers informations about those will be put into template
	(one view per finger). Should be not more than MAX_FINGERS   
	NOTE: At this version of software template can keeps information about 
	up to two fingers.
	nistTempl  (input/output): buffer for INCITS 378 compliance template
	Return value:
	The function returns SME_OK if success and error code otherwise. 
	*/
	int allocate_Template_NIST (unsigned int numFingers, unsigned char** nistTempl);

	/*
	The function allocates memory for buffer that will receives ISO 19794-2 compliance template
	Parameters:
	numFingers (input)       : number of fingers informations about those will be put into template
	(one view per finger). Should be not more than MAX_FINGERS   
	NOTE: At this version of software template can keeps information about 
	up to two fingers.
	isoTempl  (input/output): buffer for ISO 19794-2 compliance template
	Return value:
	The function returns SME_OK if success and error code otherwise. 
	NOTE: At this version of software template can keeps information about up to two fingers
	*/
	int allocate_Template_ISO (unsigned int numFingers, unsigned char** isoTempl);

	/*
	The function frees memory that was allocated by one of 'allocateNISTtemplate' 
	or 'allocateISOtemplate' functions
	Parameters:
	templ (input) - buffer for template
	Return value:
	The function returns SME_OK if success and error code otherwise. 
	*/
	int free_Template_NIST (unsigned char** templ);

	/*
	The function frees memory that was allocated by one of 'allocateNISTtemplate' 
	or 'allocateISOtemplate' functions
	Parameters:
	templ (input) - buffer for template
	Return value:
	The function returns SME_OK if success and error code otherwise. 
	*/
	int free_Template_ISO (unsigned char** templ);

	/*
	The function takes a raw image as input and outputs the corresponding ANSI INCITS 378 
	compliant template. 
	Parameters:
	numFingers      (input) : number of source images
	rawImage        (input) : array of raw image structure, that contains information
	about source fingerprint images 
	templ           (output): The processed ISO 19794-2 compliant template.
	The memory for the template should be allocated by 'allocateNISTtemplate'
	function
	certifiedSensor (input) : is capture_Equipment comply with IQS (EFTS, Appendix F)?
	sensorID        (input) : Capture Equipment ID. The vendor determines the value for this field.
	Applications developers may obtain the values for these codes from the vendor.
	Return value:
	The function returns SME_OK if success and error code otherwise. 
	In case of failure the null template will be output.
	*/
	int create_Template_NIST (unsigned int numFingers, DIBImage *rawImage, 
		unsigned char *templ, unsigned char* quality, int *templ_size, int maxTemplaeSize = 0, bool certifiedSensor = false, unsigned short sensorID = 0);

	/*
	The function takes a raw image as input and outputs the corresponding ISO 19794-2 
	compliant template. 
	Parameters:
	numFingers      (input) : number of source images
	rawImage        (input) : array of raw image structure, that contains information
	about source fingerprint images 
	templ           (output): The processed ANSI INCITS 378 compliant template.
	The memory for the template should be allocated by 'allocateISOtemplate'
	function
	certifiedSensor (input) : is capture_Equipment comply with IQS (EFTS, Appendix F)?
	sensorID        (input) : Capture Equipment ID. The vendor determines the value for this field.
	Applications developers may obtain the values for these codes from the vendor. 
	Return value:
	The function returns SME_OK if success and error code otherwise. 
	In case of failure the null template will be output.
	*/
	int create_Template_ISO (unsigned int numFingers, DIBImage *rawImage, 
		unsigned char *templ, unsigned char* quality, int *templ_size, int maxTemplateSize = 0 ,bool certifiedSensor = false, unsigned short sensorID = 0);

	/*
	The function compares two ANSI INCITS 378 compliant templates and outputs a match score. 
	Parameters:
	probeTemplate    (input) : the first  ANSI INCITS 378 compliant template
	galleryTemplate  (input) : the second ANSI INCITS 378 compliant template
	score            (output): a similarity score resulting from comparison of 
	the templates.   
	Return value:
	The function returns SME_OK if success and error code otherwise. 
	NOTE: At this version of software templates (probeTemplate and galleryTemplate) can keeps information about 
	two fingers
	*/
	int match_Templates_NIST (const unsigned char* probeTemplate, const unsigned char* galleryTemplate,unsigned char* score);

	/*
	The function compares two ISO 19794-2 compliant templates and outputs a match score. 
	Parameters:
	probeTemplate    (input) : the first ISO 19794-2 compliant template
	galleryTemplate  (input) : the second ISO 19794-2 compliant template
	score            (output): a similarity score resulting from comparison of 
	the templates.   
	Return value:
	The function returns SME_OK if success and error code otherwise. 
	NOTE: At this version of software templates (probeTemplate and galleryTemplate) can keeps information about 
	two fingers
	*/
	int match_Templates_ISO (const unsigned char* probeTemplate, const unsigned char* galleryTemplate, unsigned char* score);

	/*
	The function compares TECH5 and ANSI INCITS 378 compliant templates and outputs a match score. 
	Parameters:
	fpTemplate    (input) : the TECH5 template
	templateNIST  (input) : the second ANSI INCITS 378 compliant template
	score            (output): a similarity score resulting from comparison of 
	the templates.   
	Return value:
	The function returns CE_OK if success and error code otherwise. 
	*/
	int match_TECH5_NIST(const unsigned char* fpTemplate, const unsigned char* templateNIST, unsigned char* score);
	/*
	The function compares TECH5 and ISO 19794-2 compliant templates and outputs a match score. 
	Parameters:
	fpTemplate  (input) : the TECH5 template
	galleryISO  (input) : the second ISO 19794-2 compliant template
	score            (output): a similarity score resulting from comparison of 
	the templates.   
	Return value:
	The function returns CE_OK if success and error code otherwise. 
	*/
	int match_TECH5_ISO(const unsigned char* fpTemplate, const unsigned char* templateISO, unsigned char* score);

protected:
// AUXILARY FUNCTIONS	
	int getIpError(int num);
	int getMaError(int num);
	int getDapiError(Sensor dapi, int num);
	int checkFieldNames();
	/*
	Captures fingerprint image from selected sensor and process it)
	*/
	int captureAndProcess();
};

#endif // SDK_H_

