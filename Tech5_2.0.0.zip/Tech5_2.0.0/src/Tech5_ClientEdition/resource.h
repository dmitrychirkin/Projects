//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by  SDK SE.rc
//
#define IDE_GET_MODULE_NAME             100
#define IDS_FILE_IS_CORRUPT             101
#define IDE_OK                          102
#define IDE_UNKN_EXCEPTION              103
#define IDE_SC_INIT                     104
#define IDE_LOAD_SCANDLL                105
#define IDE_INITSCAN                    106
#define IDE_SC_LOW_CAPACITY             107
#define IDE_SC_WRONG_TEMPLATE_NUMBER    108
#define IDE_NO_IMAGE                    109
#define IDE_WRONG_SIZE_IMAGE            110
#define IDE_NOT_OPEN_SENSOR             111
#define IDE_PROCESSING                  112
#define IDE_SC_NO_DATA                  113
#define IDE_LOW_MEMORY                  114
#define IDE_NOT_INITIALIZED             115
#define IDE_WRONG_POINTER               116
#define IDE_NO_SMART_CARD               117
#define IDE_WRONG_TEMPLATE1             118
#define IDE_WRONG_TEMPLATE2             119
#define IDE_MATCH                       120
#define IDE_CANCEL                      121
#define IDE_TIMEOUT                     122
#define IDE_WRONG_TEMPLATE              123
#define IDE_LOAD_RESOURCE_DLL           124
#define IDE_COM                         125
#define IDE_IDENTIFY                    126
#define IDE_CONN_STR_TOO_LONG           127
#define IDE_CONN_NULL                   128
#define IDE_TABLE_NAME_TOO_LONG         129
#define IDE_TABLE_NAME_NULL             130
#define IDE_FP_NAME_TOO_LONG            131
#define IDE_FP_NAME_NULL                132
#define IDE_ID_NAME_TOO_LONG            133
#define IDE_ID_NAME_NULL                134
#define IDE_OPEN_SENSOR                 135
#define IDE_ENROLL                      136
#define IDE_DB_NOT_OPENED               137
#define IDE_OPEN_FILE                   138
#define IDE_WRITE_FILE                  139
#define IDE_EMPTY_TABLE_NAME            140
#define IDE_EMPTY_TEMPL_FIELD_NAME      141
#define IDE_EMPTY_ID_FIELD_NAME         142
#define IDE_NO_DATA                     143
#define IDE_GET_TEMPL                   144
#define IDE_MORE_DATA                   145
#define IDE_REMOVE_TEMPL                146
#define IDE_KEY                         147
#define IDE_TIME                        148
#define IDE_READ_FILE                   149
#define IDE_WRONG_FORMAT                150
#define IDE_WRONG_RESOLUTION            151
#define IDE_INIT                        152
#define IDE_NOT_IMPLEMENTED             153
#define IDE_SENSOR_NAME                 154
#define IDE_IMAGE_TOO_BIG               155
#define IDE_NO_LOAD                     156
#define IDE_NO_SUCH_SENSOR              157
#define IDE_JNI                         158
#define IDE_WRONG_DIB                   159
#define IDE_WRONG_IMAGE                 160
#define IDE_WRONG_LICENSE               161
#define IDE_IMPRESSION_TYPE             162
#define IDE_SAME_FING_ERR               163
#define IDE_DIF_FING_SIZE_ERR           164
#define IDE_PROBE_PARSE                 165
#define IDE_GALLERY_PARSE               166
#define IDE_DIF_FING_ERR                167
#define IDE_PARSE_TEMPL                 168
#define IDE_HARDWARE_PROTECT            170
#define IDE_FAM_PROTECT                 171
#define IDE_SPOOF_FINGER                172
#define IDE_NULL_TEMPLATE               173

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        174
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
