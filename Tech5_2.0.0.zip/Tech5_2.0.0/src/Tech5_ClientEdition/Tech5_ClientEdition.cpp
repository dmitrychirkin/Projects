
#include <stdio.h>
#include "Utilites.h"
#include "resource.h"

#include <coreSdk.h>
#include "Tech5_ClientEdition.h"
#include "sdk.h"

#define pKey L"Software\\Tech5\\Tech5_ClientEdition"

/////////////////////////////////////////////////////////////////////////////////////////
int check(Sdk *sdk, int result)
{
	sdk->setError(result); 
	return result;
}

// read stored settings
int readSettings (TECH5_CLIENT &hSdk)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)

#ifdef WIN32
	DWORD type;
	HKEY	hKey = NULL;	
	DWORD temp = 0;
	DWORD size = sizeof (DWORD);		   
	SearchParams* searchParams = (SearchParams*)sdk->getSearchParams();	
	// open pKey registry key and save all parameters
	wchar_t* s = pKey;
	if (RegOpenKeyEx( HKEY_LOCAL_MACHINE, pKey, NULL, KEY_READ, &hKey) != ERROR_SUCCESS) 
		return SE_INIT;
	if (RegQueryValueEx (hKey, L"angle", NULL, &type, (LPBYTE)&temp, &size) == ERROR_SUCCESS) 
		searchParams->maxAngle = (WORD)temp;
	else
		searchParams->maxAngle = MAX_ANGLE_DEF;
	if (RegQueryValueEx (hKey, L"displacement", NULL, &type, (LPBYTE)&temp, &size) == ERROR_SUCCESS) 
		searchParams->maxDisp = (WORD)temp;  
	else 
		searchParams->maxDisp = MAX_DISP_DEF;
	if (RegQueryValueEx (hKey, L"searchSpeed", NULL, &type, (LPBYTE)&temp, &size) == ERROR_SUCCESS) 
		searchParams->searchSpeed = (MATCH_SPEED)temp;  
	else 
		searchParams->searchSpeed = (MATCH_SPEED)SEARCH_SPEED_DEF;
	
	RegCloseKey(hKey);
	sdk->setSearchParams (searchParams);
#endif // WIN32
	return SE_OK;
}
int initSDK(TECH5_CLIENT *hSdk, int cores_count)
{
	Sdk *sdk = NULL;
	try
	{
		sdk = new Sdk(cores_count);
	}
	catch(int e)
	{
		return e;
	}
	*hSdk = (TECH5_CLIENT)sdk;
	if(!*hSdk) return SE_LOW_MEMORY;
	sdk->init();
	// read settings from the registry
	readSettings (*hSdk);

	return SE_OK;
}

void closeSDK(TECH5_CLIENT *hSdk)
{
	Sdk *sdk = (Sdk*)*hSdk;
	if (!sdk || !sdk->isInit()) return;

	delete sdk; sdk = NULL;
	*hSdk = NULL;
}



int setSearchParams (TECH5_CLIENT hSdk, const SearchParams* params)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
	return sdk->setSearchParams (params);
}

const SearchParams* getSearchParams (TECH5_CLIENT hSdk)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT2(sdk)
	return sdk->getSearchParams ();
}

int setLicense(TECH5_CLIENT hSdk, const char* license_data, int* extra_data)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
		return sdk->setLicenseFilename(license_data,(long*)extra_data,TECH5_SDK_CLIENT);
}


int create_Template_NIST (TECH5_CLIENT hSdk, unsigned int numFingers, DIBImage *dibImage, 
									unsigned char *templ, unsigned char* quality, int *templ_size, int maxTemplateSize, bool certifiedSensor, unsigned short sensorID)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
		return check(sdk, sdk->create_Template_NIST (numFingers,dibImage,templ,quality,templ_size, maxTemplateSize,certifiedSensor,sensorID));
}

int create_Template_ISO (TECH5_CLIENT hSdk, unsigned int numFingers, DIBImage *dibImage, 
									unsigned char *templ, unsigned char* quality, int *templ_size, int maxTemplateSize, bool certifiedSensor, unsigned short sensorID)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
		return check(sdk, sdk->create_Template_ISO (numFingers,dibImage,templ,quality,templ_size, maxTemplateSize, certifiedSensor,sensorID));
}

int create_Template_Tech5 (TECH5_CLIENT hSdk, unsigned char* dib_image, FINGERS finger, unsigned char* fpTemplate,unsigned int *templSize, 
		 unsigned char* quality, unsigned int maxWidth, unsigned int maxHeight)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
	return check(sdk, sdk->create_Template (dib_image, finger, fpTemplate, templSize, quality, maxWidth, maxHeight));
}

int create_Template_Tech5Ex (TECH5_CLIENT hSdk, DIBImage dib_image, unsigned char* fpTemplate,unsigned int *templSize, 
		 unsigned char* quality, unsigned int maxWidth, unsigned int maxHeight)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
	return check(sdk, sdk->create_TemplateEx (dib_image, fpTemplate, templSize, quality, maxWidth, maxHeight));
}

int match_Templates_Tech5(TECH5_CLIENT hSdk, const unsigned char* fpTempl1, const unsigned char* fpTempl2, unsigned char* similarity)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
	return check(sdk, sdk->match_Templates (fpTempl1, fpTempl2, similarity,FINGPOS_RT,FINGPOS_RT));
}
int loadTemplate_Tech5(TECH5_CLIENT hSdk, const unsigned char* fpTempl1)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
	return check(sdk, sdk->loadTemplate (fpTempl1, FINGPOS_RT));
}

int match_Templates_Tech5Ex(TECH5_CLIENT hSdk, const unsigned char* fpTempl2, unsigned char* similarity)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
	return check(sdk, sdk->match_TemplatesEx (fpTempl2, similarity,FINGPOS_RT));
}

int match_Templates_NIST (TECH5_CLIENT hSdk, const unsigned char* probeTemplate, const unsigned char* galleryTemplate, unsigned char* score)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
		return check(sdk, sdk->match_Templates_NIST(probeTemplate,galleryTemplate,score));
}

int match_Templates_ISO (TECH5_CLIENT hSdk, const unsigned char* probeTemplate, const unsigned char* galleryTemplate, unsigned char* score)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
		return check(sdk, sdk->match_Templates_ISO(probeTemplate,galleryTemplate,score));
}
int match_Tech5_NIST(TECH5_CLIENT hSdk, const unsigned char* fpTemplate, const unsigned char* templateNIST, unsigned char* score)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
		return check(sdk, sdk->match_TECH5_NIST(fpTemplate,templateNIST,score));
}
int match_Tech5_ISO(TECH5_CLIENT hSdk, const unsigned char* fpTemplate, const unsigned char* templateISO, unsigned char* score)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
		return check(sdk, sdk->match_TECH5_ISO(fpTemplate,templateISO,score));
}
const char* getLastErrorMsg (TECH5_CLIENT hSdk)
{
	Sdk *sdk = (Sdk*)hSdk;
	if (!sdk || !sdk->isInit()) return NULL;
	return sdk->getLastErrorMsg();
}


int save2Bmp(TECH5_CLIENT hSdk,const char* filename, const unsigned char* dib)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
	return check(sdk, sdk->save2Bmp (filename, dib));
}

int readBmp (TECH5_CLIENT hSdk, const char* filename, unsigned int* size, unsigned char* dib)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
		return	check(sdk, sdk->readBmp(filename, size, dib));
}

int readBmpEx (TECH5_CLIENT hSdk, const unsigned char* bitmap_buffer, unsigned int bitmap_buffer_size, unsigned int* size, unsigned char* dib)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
		return	check(sdk, sdk->readBmpEx(bitmap_buffer, bitmap_buffer_size, size, dib));
}

int save2Wsq(TECH5_CLIENT hSdk,const char* filename, const unsigned char* dib, float compressionRate)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
	return check(sdk, sdk->save2Wsq(filename, dib, compressionRate));
}

int save2WsqEx(TECH5_CLIENT hSdk, unsigned char* wsq_buffer, unsigned int *wsq_size, const unsigned char* dib, float compressionRate)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
		return check(sdk, sdk->save2WsqEx( wsq_buffer, wsq_size, dib, compressionRate));
}

int readWsq(TECH5_CLIENT hSdk, const char* filename, unsigned int* size, unsigned char* dib)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
		return	check(sdk, sdk->readWsq(filename, size, dib));
}
int readWsqEx (TECH5_CLIENT hSdk, const unsigned char* wsq_buffer, unsigned int wsq_buffer_size, unsigned int* size, unsigned char* dib)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
		return	check(sdk, sdk->readWsqEx(wsq_buffer,wsq_buffer_size, size, dib));
}



int allocate_Template_Tech5 (TECH5_CLIENT hSdk, unsigned char** fpTemplate)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
	return check(sdk, sdk->allocate_Template(fpTemplate));
}

int allocate_Template_NIST (TECH5_CLIENT hSdk, unsigned int numFingers, unsigned char** nistTempl)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
		return check(sdk, sdk->allocate_Template_NIST(numFingers,nistTempl));
}

int allocate_Template_ISO (TECH5_CLIENT hSdk, unsigned int numFingers, unsigned char** isoTempl)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
		return check(sdk, sdk->allocate_Template_ISO(numFingers,isoTempl));
}
int free_Template_Tech5 (TECH5_CLIENT hSdk, unsigned char** fpTemplate)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT3(sdk)
	return sdk->free_Template(fpTemplate);
}

int free_Template_NIST (TECH5_CLIENT hSdk, unsigned char** templ)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT3(sdk)
	return sdk->free_Template_NIST(templ);
}

int free_Template_ISO (TECH5_CLIENT hSdk, unsigned char** templ)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT3(sdk)
	return sdk->free_Template_ISO(templ);
}


int drawImage(TECH5_CLIENT hSdk, const unsigned char* dib, void* parent)
{
	Sdk *sdk = (Sdk*)hSdk;
	INIT(sdk)
	return check(sdk, sdk->drawImage(dib, parent));
}

