#ifdef _WINDOWS

#include <windows.h>
#include <stdio.h>

#include "resource.h"
#include "utilites.h"

#include "coreSdk.h"

#include "Tech5_ClientEdition.h"
#include "sdk.h"


BOOL APIENTRY DllMain( HANDLE hModule,
					  DWORD  ul_reason_for_call,
					  LPVOID lpReserved
					  )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		break;
	case DLL_THREAD_ATTACH:
		break;
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}

#endif //_WINDOWS