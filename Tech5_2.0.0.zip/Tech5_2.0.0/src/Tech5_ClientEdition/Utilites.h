/*****************************************************************************
	utilites.h - declaration of the functions-utilites

	
   Author A.Mosunov
	Version 2.2.1 of 31.05.2004

*******************************************************************************/
#ifndef UTILITES_H_
#define  UTILITES_H_

#ifdef _WINDOWS
// get system message error
void getSystemError(char* err);
void getSystemError(wchar_t* err);
#endif // _WINDOWS

/*
	get checksums
	name - filename
	headercheckSum - checksum readed from optional header PE-file
	checkSum - calculated checksum
*/
bool getCheckSums (char* name, unsigned long& headerSum, unsigned long& checkSum);

/*
	calculating and return checksum for memory block
	p - point to the memoty block
	size - size of the memory block
*/
int calkChecksum(register unsigned char *s, register int size);

#endif // UTILITES_H_
