#ifndef SSE_PROXY_H_
#define SSE_PROXY_H_


#ifdef SSE_SUPPORT
   #include <emmintrin.h>
   #include <tmmintrin.h>
   #include <nmmintrin.h>
#endif
#include <stdio.h>

#include "coreSdk.h"

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)

   inline unsigned int pop( unsigned int _Val )
   {
      //p.76  accelerator bits in word
      _Val = _Val - ((_Val >> 1) & 0x55555555);
      _Val = (_Val & 0x33333333) + ((_Val >> 2) & 0x33333333);
      _Val = (_Val + (_Val >> 4)) & 0x0f0f0f0f;
      _Val = _Val + (_Val >> 8);
      _Val = _Val + (_Val >> 16);
      return _Val & 0x0000003f;
   }


typedef union  m128i_my 
{
#ifdef SSE_SUPPORT
      __m128i                m_128;          
#endif
      signed char            m128i_i8[16];
      signed short           m128i_i16[8];
      signed int             m128i_i32[4];    
      signed long long       m128i_i64[2];
      unsigned char          m128i_u8[16];
      unsigned short         m128i_u16[8];
      unsigned int           m128i_u32[4];
      unsigned long long     m128i_u64[2];
} m128i_my;

struct Accel 
{
      //__m128i item;             // number of minutiae(+1) on link 
      //__m128i accel;            // accelerator itself  
      m128i_my item;             // number of minutiae(+1) on link 
      m128i_my accel;            // accelerator itself  
};

#ifdef SSE_SUPPORT
   /*
      check support of SSE instructions
   */
   #ifdef _WINDOWS

      #define cpuid(info,x)    __cpuidex(info,x,0)

   #else
      #include <cpuid.h>
      //  GCC Inline Assembly
      inline void cpuid(int CPUInfo[4], int info)
      {
         unsigned int CPUInfo_u [4];
          __get_cpuid(info, &CPUInfo_u[0], &CPUInfo_u[1], &CPUInfo_u[2], &CPUInfo_u[3]);
          memcpy(CPUInfo, CPUInfo_u, sizeof(CPUInfo_u));
      }
   #endif

   inline bool check_SSE2 ()
   {
      int info[4];
      cpuid(info, 0);
      if (info[0] < 0x00000001)return false;

      cpuid(info, 0x00000001);
      return ((info[3] & ((int)1 << 26)) != 0);
   }

   inline bool check_SSE3 ()
   {
      int info[4];
      cpuid(info, 0);
      if (info[0] < 0x00000001)return false;

      cpuid(info, 0x00000001);
      return ((info[2] & ((int)1 << 0)) != 0);
   }

   inline bool check_SSSE3 ()
   {
      int info[4];
      cpuid(info, 0);
      if (info[0] < 0x00000001)return false;

      cpuid(info, 0x00000001);
      return ((info[2] & ((int)1 << 9)) != 0);
   }

   inline bool check_SSE4_1 ()
   {
      int info[4];
      cpuid(info, 0);
      if (info[0] < 0x00000001)return false;

      cpuid(info, 0x00000001);
      return ((info[2] & ((int)1 << 19)) != 0);
   }

   inline bool check_SSE4_2 ()
   {
      int info[4];
      cpuid(info, 0);
      if (info[0] < 0x00000001)return false;

      cpuid(info, 0x00000001);
      return ((info[2] & ((int)1 << 20)) != 0);
   }

   inline bool check_SSE ()
   {
      return check_SSE3();
   }
/*
   functions with using SSE instructions
*/
   static __m128i g_nul_res;
   inline unsigned  int getAccelSim  (Accel *aP, Accel *aG)
   {
      __m128i res = _mm_cmpeq_epi8 (aP->accel.m_128, aG->accel.m_128);
      __m128i dif = _mm_sad_epu8 (res, g_nul_res);
      return (((m128i_my*)&dif)->m128i_u32[0] + ((m128i_my*)&dif)->m128i_u32[2]);
   }

   inline m128i_my my_mm_abs_sub_epi8 (Accel *aP, Accel *aG)
   {
      __m128i res = _mm_abs_epi8(_mm_sub_epi8 (aP->accel.m_128, aG->accel.m_128));
      return *(m128i_my*)&res;
   }

   inline m128i_my my_mm_and_si128 (m128i_my *aP, m128i_my *aG)
   {
      __m128i res = _mm_and_si128 (*(__m128i*)aP, *(__m128i*)aG);
      return *(m128i_my*)&res;
   }
   // use SSE 4.2
   inline int getNum_1_bit(unsigned int a)
   {
//      return  _mm_popcnt_u32 (a);
      return  pop (a);
   }
   inline int calcSum_1_Bits(m128i_my &a)
   {
#ifdef X64
      return (int)_mm_popcnt_u64(a.m128i_u64[0]) + (int)_mm_popcnt_u64(a.m128i_u64[1]);
#else
      return pop (a.m128i_u32[0]) + pop (a.m128i_u32[1]) + pop (a.m128i_u32[2]) + pop (a.m128i_u32[3]);
#endif
   }

#else  // proxy functions  

   inline bool check_SSE ()
   {
      return true;
   }
   inline bool check_SSE2 ()
   {
      return true;
   }
   inline bool check_SSE3 ()
   {
      return true;
   }
   inline bool check_SSSE3 ()
   {
      return true;
   }
   inline bool check_SSE4_1 ()
   {
      return true;
   }
   inline bool check_SSE4_2 ()
   {
      return true;
   }

   inline unsigned  int getAccelSim  (Accel *aP, Accel *aG)
   {
      unsigned int result = 0;
      for(int i = 0; i < 16; i++)
      {
         if (aP->accel.m128i_u8[i] == aG->accel.m128i_u8[i])
            result += 255;
      }
      return result;
   }

   inline m128i_my my_mm_abs_sub_epi8 (Accel *aP, Accel *aG)
   {
      m128i_my result;
      for(int i = 0; i < 16; i++)
      {
         result.m128i_i8[i] = abs(aP->accel.m128i_i8[i] - aG->accel.m128i_i8[i]);
      }
      return result; 
   }

   inline m128i_my my_mm_and_si128 (m128i_my *aP, m128i_my *aG)
   {
      m128i_my res;
      for(int i = 0; i < 4; i++)
      {
         res.m128i_i32[i] = aP->m128i_i32[i] & aG->m128i_i32[i];
      }
      return res;
   }


   inline int getNum_1_bit(unsigned int a)
   {
      return  pop (a);
   }

   inline int calcSum_1_Bits(m128i_my &a)
   {
      return pop (a.m128i_u32[0]) + pop (a.m128i_u32[1]) + pop (a.m128i_u32[2]) + pop (a.m128i_u32[3]);
   }

#endif // SSE_SUPPORT
#pragma pack(pop, _CORE_PACKING)
} // namespace accelMatch{


#endif // SSE_PROXY_H_
