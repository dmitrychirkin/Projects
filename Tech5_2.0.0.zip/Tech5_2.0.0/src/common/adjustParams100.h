/*
   adjustParmams.h - declare function for adjusting score calculation parameters

   Copyright (C) 2006 Sonda Technologies Ltd.
   Author A.Mosunov
   13.06.2007
*/
#ifndef  ADJUST_PARAMS_H_
#define  ADJUST_PARAMS_H_

#include <omp.h>
#include <stdio.h>
#include "scoreParameters100.h"
#include "accelAdjust.h"
#include "score100.h"

namespace accelMatch{
#pragma pack(push,_CORE_PACKING)


extern size_t g_k_speed       [4][SPEED_PARAM_SIZE];
extern size_t g_k_speed_latent[4][SPEED_PARAM_SIZE];

#ifdef ADJUST
#define MAX_NUM_THREADS  24
extern FILE *g_maAdjGenFile      [MAX_NUM_THREADS];
extern FILE *g_maAdjImpFile      [MAX_NUM_THREADS];
extern bool g_maGenuineMatching  [MAX_NUM_THREADS];

extern FILE *g_accelAdjGenFile      [MAX_NUM_THREADS];
extern FILE *g_accelAdjImpFile      [MAX_NUM_THREADS];
extern bool g_accelGenuineMatching  [MAX_NUM_THREADS];

// functions for save score calculation source data
void getLogName      (bool accel, const char *name, char path[MAX_PATH], int probeRegNum = -1, char fingerP = -1, bool genuine = true);
FILE* openLog        (bool accel, const char *name, int num_thread, bool forRead, int probeRegNum, char fingerP, bool genuine);
void closeLog        (bool accel, int num_thread, bool genuine);
bool logStartMatch   (bool accel, int num_thread);
bool logFinishMatch  (bool accel, int num_thread, int score);
bool commitSaveParameters  (bool accel, int num_thread, bool commitData) ;
bool saveParameters        (ScoreParameters &param, MinData *minDataP, MinData *minDataG);
bool saveAccelParameters   (AccelScoreParam &param);
bool readAllMatchedGroups     (BYTE *&pos, BYTE *end, ScoreParameters **param, MinDataPacked **minDataP, MinDataPacked **minDataG, int &numGroups, int &score);
bool readAllAccelMatchedGroups(BYTE *&pos, BYTE *end, AccelScoreParam **param,                                                     int &numGroups, int &score);




//bool readAllMatchedGroups(BYTE *&pos, BYTE *end, ScoreParameters **param, MinData **minDataP, MinData **minDataG, int &numGroups);

//// functions for save parameters statictic data
//bool openAllHist (char *templDir, char *suffix);
//void closeAllHist();
//void saveParam (int index, int v);
//void saveParam (int index, float v);
//
//void clearHist ();
//void updateBestHist ();
//void updateAllHist ();
#endif

#pragma pack(pop)
} //namespace accelMatch{

#endif // ADJUST_PARAMS_H_