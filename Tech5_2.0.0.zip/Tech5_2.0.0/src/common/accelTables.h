#ifndef ACCEL_TABLES_H_
#define ACCEL_TABLES_H_

#include "accel.h"
#include "mathem100.h"

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)

#define DIST_TABLE_SIZE						512
#define DDIST_TOLERANCE_TABLE_SIZE     MAX_WIDTH


class AccelTables
{
	bool            m_init;
   BYTE            m_dDistToleranceTable1[DDIST_TOLERANCE_TABLE_SIZE];   // for speed 0
   BYTE            m_dDistToleranceTable2[DDIST_TOLERANCE_TABLE_SIZE];   // for speed 1...
   BYTE            m_angleCompTable[90][90][90];
   BYTE            m_accelDistTable[DIST_TABLE_SIZE]; 

public:
	AccelTables()
	{
		m_init = false;
		memset (m_accelDistTable,        0, sizeof (m_accelDistTable		));
      memset (m_dDistToleranceTable1,  0, sizeof (m_dDistToleranceTable1));
      memset (m_dDistToleranceTable2,  0, sizeof (m_dDistToleranceTable2));
      memset (m_angleCompTable,        0, sizeof (m_angleCompTable		));
//      memset (m_distCompareTable,     0, sizeof (m_distCompareTable   ));
	}
   bool init ()
   {
      if (m_init)
         return true;
      calcAccelDistTable(24, 1.1);
      calcDistToleranceTable (20, 25, 10000, 20, 100, 10000);
      calcAngleCompTable();
		m_init = true;
      return true;
   }
   BYTE getAngleDif(BYTE angleP, BYTE angleG, BYTE angle)
   {
      return  m_angleCompTable[angleP][angleG][angle];
//      return abs(normAngle(angleG - angleP - angle));
   }
	int getDist(unsigned int dist)
	{
		return dist >= DIST_TABLE_SIZE ? m_accelDistTable[DIST_TABLE_SIZE - 1] : m_accelDistTable[dist];
	}
	BYTE* getDistToleranceTable(int k)
	{
      if (k == 1) return m_dDistToleranceTable1;
      else        return m_dDistToleranceTable2;
	}
private:
   void calcDistToleranceTable (int a0, int a1, int a2, int b0, int b1, int b2)
   {
      int val = 0;
      for (int dist = 0; dist < DDIST_TOLERANCE_TABLE_SIZE; dist++)
		{
         val = a0 + dist / a1 + dist * dist / a2;
         m_dDistToleranceTable1[dist] = val < 255 ? val : 255;
         val = b0 + dist / b1 + dist * dist / b2;
         m_dDistToleranceTable2[dist] =  val < 255 ? val : 255;
		}
   }

   void calcAccelDistTable(unsigned int step, double k)
   {
      unsigned int distStep[MAX_ACCEL_LINK_DIST + 2]; 
      distStep[0] = 0;
      unsigned int m = 0;
      for(int i = 1; i < MAX_ACCEL_LINK_DIST + 2; i++)
      {
         distStep[i] = distStep[i - 1] + int(step * pow (k, i));
         if (distStep[i] >= DIST_TABLE_SIZE)
            distStep[i] = DIST_TABLE_SIZE;
         for(; m < distStep[i]; m++)               // accelDist shouldn't be 0, because zero value are used in calcAccel 
            m_accelDistTable[m] = i;					// for discover not taken links
      }
      for(; m < DIST_TABLE_SIZE; m++)
         m_accelDistTable[m] = MAX_ACCEL_LINK_DIST + 1;
   }

   void calcAngleCompTable()
   {
      for(unsigned int angP = 0; angP < 90; angP++)
         for(unsigned int angG = 0; angG < 90; angG++)
            for(unsigned int ang = 0; ang < 90; ang++)
               m_angleCompTable[angP][angG][ang] = abs(normQuarterAngle(angG - angP - ang));
   }

};


#pragma pack(pop)
} // namespace accelMatch{

#endif // ACCEL_TABLES_H_
