/**************************************
				Mathem.h
	Special mathematical functions.

			Author Gudkov V.U.
**************************************/

#include		<math.h>
#include		"common.h"

#ifndef MATHEM_ACCEL_H_
#define MATHEM_ACCEL_H_

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)

	//----------------------------------
	//			Random value
	//----------------------------------
	extern WORD	DatRan;

	//----------------------------------
	//	Mathematic tables
	//----------------------------------
	  
	extern int	TabSin[];
	  
	extern int	TabSig[];
	  
	extern int	TabTan[];
	  
	extern int	TabLog[];
	  
	extern BYTE	TabSqr[];

   extern float TabSinF[];

   extern float TabCosF[];
   
	/***********************************
			Simple inline library
	***********************************/

	//	Limit segment
	//static inline int	LIM	( int val,int beg = 0,int end = 255 )	
	//{
	//	return (val > end) ? end : 
	//			 (val < beg) ? beg : val;
	//}
	//	Limit segment 0..127
	//static inline int	LIA	( int val )
	//{
	//	return LIM( val,0,127 );
	//}
	//	Limit segment 0..90
	//static inline int	LIR	( int val )
	//{
	//	return LIM( val,0, 90 );
	//}
	//	Limit segment 0..180
	//static inline int	LIH	( int val )		
	//{
	//	return LIM( val,0,180 );
	//}
	//	Get absolute value
	//static inline int	ABS	( int val )		
	//{
	//	return (val > 0) ? val : -val;
	//}
	//	On zero
	//static inline int	VON	( int val )		
	//{
	//	return (val    ) ? val : 1;
	//}
	//	Select minimum
	//static inline int	MIN	( int aii,int bii = 0 )		
	//{
	//	return (aii < bii) ? aii : bii;
	//}
	//	Select maximum
	//static inline int	MAX	( int aii,int bii = 0 )		
	//{
	//	return (aii > bii) ? aii : bii;
	//}
	//	Get average value
	//static inline int	EVE	( int aii,int bii = 0 )		
	//{
	//	return (aii + bii)/2;
	//}
	//	Get square distance
	/*static inline int	EVK	( int aii,int bii = 0 )	
	{
		return aii*aii + bii*bii;
	}
	*///	Get chance
	//static inline int	CHA	( int aii,int bii = 0 )	
	//{
	//	return 99*aii/(aii + bii);
	//}
	//	Get percentage
	//static inline int	PER	( int aii,int bii = 0)		
	//{
	//	return (aii*bii)/100;
	//}
	//	Special division
	//static inline int	DIP	( int aii,int bii = 2)		
	//{
	//	return (aii > 0) ? (aii + bii/2)/VON( bii ):
	//							 (aii - bii/2)/VON( bii );
	//}

	/***********************************
				Digital library
	***********************************/

	//Interpolation: Lagrange method
	//static inline int lagran( int *tab,int x )
	//{
	//	int	 sum = 0;
	//	double num = 1,
	//			 den = 1;

	//	//use any number of nots, see tab[0]
	//	for (int j = tab[0]; j > 0; j--)
	//	{
	//		//start numerator & denominator
	//		num = den = 1;

	//		//calc numerator
	//		for (int n = tab[0]; n > 0; n--) 
	//			if (n != j) num *= (x /*fact*/ - tab[2*n-1]);

	//		//calc denominator
	//		for (int d = tab[0]; d > 0; d--) 
	//			if (d != j) den *= (tab[2*j-1] - tab[2*d-1]);

	//		//calc value
	//		sum += (int)((tab[2*j]*num)/den);
	//		}

	//	//final value
	//	return sum;
	//}

	//	Get square root
//	static inline int sqri( int val )
//	{
//		//negative !
//		if (val < 0)	
//			return 0;
//
//		//if small value-quick table
//		if (val < 65025)
//			return TabSqr[ val ];//ok
//		else
///*			return  (sqri( val/2 )*6+
//						sqri( val/3 )*6+
//						sqri( val/4 )*8+
//						sqri( val/5 )*6+
//						sqri( val/6 )*4 )/16;
//*/
//      return (int)(sqrt((float)val) + 0.5); 
//	}

	////	Get Evclid distance between two points
	//static inline DWORD dist (int x1,int y1, int x2 = 0, int y2 = 0)
	//{
	//	return sqri ( EVK(x1 - x2, y1 - y2) );
	//}

	////	Get autoscaled logarithm
	//static inline int logm( int ind,int end = 255 )
	//{
	//	return TabLog[ 255*ind/end ];
	//}

	////----------------------------------
	////	Random value generator
	////----------------------------------
	//static inline WORD uran( void )
	//{
	//	//random value
	//	return DatRan = 
	//			 DatRan * 317 + 17182;
	//}

	/***********************************
				Normalize angle
	***********************************/

	//	Normalize angle to 360 degree
	//static inline int upci( int ang )
	//{
	//	while(ang <    0) ang += 360;
	//	while(ang >= 360) ang -= 360;
	//	return ang;//angle is 0..359
	//}

	////	Normalize angle to 180 degree
	//static inline int uppi( int ang )
	//{
	//	while(ang <    0)	ang += 180;
	//	while(ang >= 180)	ang -= 180;
	//	return ang;//angle is 0..179
	//}

	//	Normalize directions to eight
	//static inline int updi( int dir )
	//{
	//	while(dir <    0)	dir += 0x8;
	//	while(dir >= 0x8)	dir -= 0x8;
	//	return dir;//direction  0..7
	//}

	////	Invert direction
	//static inline int redi( int dir )
	//{
	//	return updi( dir+4 ); //back
	//}

	////	Invert orientation
	//static inline int reci( int ang )
	//{
	//	return upci( ang+180 );//back
	//}

	/***********************************
			Trigonometrical library
	***********************************/

	//----------------------------------
	//			Direct functions
	//----------------------------------

	/*********************************************************************************/	

//	Get sin table value for any alpha
//static inline int sint( int alpha )
//{
//	alpha = upci(alpha);//normal
//
//	//kernal sint( args 0..360 )
//	if (alpha <=  90)	
//		return +TabSin[alpha		];
//	else
//	if (alpha <= 180)	
//		return +TabSin[180-alpha];
//	else
//	if (alpha <= 270)	
//		return -TabSin[alpha-180];
//	else
//		return -TabSin[360-alpha];
//}
////	Get sin table value for any alpha
//static inline float sinf( int alpha )
//{
//   alpha = upci( alpha );//normal
//   return TabSinF[ alpha ];
//}
//
////	Get sig table value for any alpha
//static inline int sigt( int alpha )
//{
//	alpha = upci(alpha);//normal
//
//	//kernal sint( args 0..360 )
//	if (alpha <=  90)	
//		return +TabSig[alpha		];
//	else
//	if (alpha <= 180)	
//		return +TabSig[180-alpha];
//	else
//	if (alpha <= 270)	
//		return -TabSig[alpha-180];
//	else
//		return -TabSig[360-alpha];
//}
//
////	Get cos table value for any alpha
//static inline int cost( int alpha )
//{
//	alpha = upci(alpha);//normal
//
//	//kernal cost( args 0..360 )
//	if (alpha <=  90)
//		return +TabSin[ 90-alpha];
//	else
//	if (alpha <= 180)
//		return -TabSin[alpha -90];
//	else
//	if (alpha <= 270)
//		return -TabSin[270-alpha];
//	else
//		return +TabSin[alpha-270];
//}
//
//static inline float cosf( int alpha )
//{
//   alpha = upci( alpha );//normal
//   return TabCosF[ alpha ];
//}
//
////	Get cog table value for any alpha
//static inline int cogt( int alpha )
//{
//	alpha = upci(alpha);//normal
//
//	//kernal cost( args 0..360 )
//	if (alpha <=  90)
//		return +TabSig[ 90-alpha];
//	else
//	if (alpha <= 180)
//		return -TabSig[alpha -90];
//	else
//	if (alpha <= 270)
//		return -TabSig[270-alpha];
//	else
//		return +TabSig[alpha-270];
//}
//
////	Get scaled sin value for any alpha	
///*********************************************************************************/
//
//static inline int sinm( int mul,int alpha )
//{
//	if ((mul *= sint( alpha )) >= 0)
//		return  ((+mul + 4096) >> 13);
//	else
//		return -((-mul + 4096) >> 13);
//}
//
//
////	Get scaled sig value for any alpha
//static inline int sigm( int mul,int alpha )
//{
//	if ((mul *= sigt( alpha )) >= 0)
//		return  ((+mul + 4096) >> 13);
//	else
//		return -((-mul + 4096) >> 13);
//}
//
//
//
////	Get scaled cos value for any alpha
////JRM 12-15-05 : see comment above
//
//
//static inline int cosm( int mul,int alpha )
//{
//	if ((mul *= cost( alpha )) >= 0)
//		return  ((+mul + 4096) >> 13);
//	else
//		return -((-mul + 4096) >> 13);
//}
//
//
////	Get scaled cog value for any alpha
//static inline int cogm( int mul,int alpha )
//{
//	if ((mul *= cogt( alpha )) >= 0)
//		return  ((+mul + 4096) >> 13);
//	else
//		return -((-mul + 4096) >> 13);
//}
//
////	Decompose vector - get max( x,y )
//static inline int decm( int mul,int alpha )
//{	
//	int vsin = ABS( sint( alpha ));
//	int vcos = ABS( cost( alpha ));
//
//	//decompositions
//	if (vsin > vcos)
//		return (mul*vsin +4096) >> 13;
//	else
//		return (mul*vcos +4096) >> 13;
//}
//
////	Get scaled tan value for any alpha
//static inline int tanm( int mul,int alpha )
//{
//	int vsin =	sint( alpha );
//	int vcos =	cost( alpha );
//
//	//nonzero
//	if (vcos)
//		return	DIP( mul*vsin,vcos );
//	else
//		return		  mul*vsin;//finit
//}
//
////----------------------------------
////			Reverse functions
////----------------------------------
//
////	Get index for table
//static inline int in( int da,int db )
//{
//	return ((da << 7) + db)/db;
//}
//
////	Get alpha for any d(x) & d(y)
//static inline int atan( int incx,int incy )
//{
//	//check d(x),d(y)
//	if (incx == 0)
//	{
//		if (incy == 0)
//			return   0;
//		else
//		if (incy >  0)
//			return  90;
//		else
//			return 270;
//	}
//	else
//	if (incy == 0)
//	{
//		if (incx >  0)
//			return   0;
//		else
//			return 180;
//	}
//
//	//do quadrant
//	int quad = 0;
//
//	//check  d(x)
//	if (incx < 0)
//	{
//		incx = -incx; quad += 1;
//	}
//	//check  d(y)
//	if (incy < 0)
//	{
//		incy = -incy; quad += 2;
//	}
//
//	//arctangent..
//	if (quad == 0)
//		if (incy > incx)
//			return 90 -TabTan[in( incx,incy )];
//		else
//			return	  TabTan[in( incy,incx )];
//	else
//	if (quad == 1)
//		if (incy > incx)
//			return 90 +TabTan[in( incx,incy )];
//		else
//			return 180-TabTan[in( incy,incx )];
//	else
//	if (quad == 2)
//		if (incy > incx)
//			return 270+TabTan[in( incx,incy )];
//		else
//			return 360-TabTan[in( incy,incx )];
//	else
//		if (incy > incx)
//			return 270-TabTan[in( incx,incy )];
//		else
//			return 180+TabTan[in( incy,incx )];
//}
//
///***********************************
//			Complex processing
//***********************************/
//
////	Scissors from b-vec to a-vec
//static inline int scis( int a,int b )
//{
//	//check <a> dimension
//	a = upci(a);
//	//check <b> dimension
//	b = upci(b);
//
//	//calculate parameter
//	int ang = a-b,
//		 abs = ABS( ang );
//
//	//if acute angle
//	if (abs <  90)
//		return ang;
//	else//if obtuse
//	if (abs < 270)
//	{
//		if (ang > 0)
//			return ang-180;
//		else
//			return ang+180;
//	}
//	else//if acute angle
//	{
//		if (ang > 0)
//			return ang-360;
//		else
//			return ang+360;
//	}
//}
//
////	Cone from b-vec to a-vec
//static inline int cone( int a,int b )
//{
//	//check <a> dimension
//	a = upci(a);
//	//check <b> dimension
//	b = upci(b);
//
//	//calculate parameter
//	int ang = ABS( a-b );
//
//	//if acute angle
//	if (ang <  90)
//		return ang;//ok
//	else
//	if (ang < 180)
//		return 180-ang;
//	else
//	if (ang < 270)
//		return ang-180;
//	else
//		return 360-ang;
//}
//
////	Nearest turn b-vec to a-vec
//static inline int turn( int a,int b )
//{
///*
//   int ang =  upci (a - b);
//   if (ang < 180)
//      return ang;
//   else
//      return ang - 360;
//*/
/////*
//	//check <a> dimension
//	a = upci(a);
//	//check <b> dimension
//	b = upci(b);
//
//	//calculate parameter
//	int ang = a - b;
//
//	//if less then one pi
//	if (ABS( ang ) < 180)
//		return ang;//ok
//	else
//	if (ang < 0)
//		return ang+360;
//	else
//		return ang-360;
////*/
//}
//
////	Nearest |turn| b-vec to a-vec
//static inline int coor( int a,int b )
//{
//	//check <a> dimension
//	a = upci(a);
//	//check <b> dimension
//	b = upci(b);
//
//	//calculate parameter
//	int ang = ABS( a-b );
//
//	//measure discordance
//	if (ang <  180)
//		return ang;//ok
//	else
//		return 360-ang;
//}
//
////	Turn b-vec clockwize to a-vec
//static inline int cloc( int a,int b )
//{
//	//check <a> dimension
//	a = upci(a);
//	//check <b> dimension
//	b = upci(b);
//
//	//calculate parameter
//	int ang = a-b;
//
//	//is delta clockwize?
//	if (ang >= 0)
//		return ang;//ok
//	else
//		return ang+360;
//}
//
////	Is vectors in phase ?
//static inline int simu( int a,int b )
//{
//	//check <a> dimension
//	a = upci(a);
//	//check <b> dimension
//	b = upci(b);
//
//	//calculate parameter
//	int ang = ABS( a-b );
//
//	//dos in phase	
//	if (ang <  90)
//		return 1;
//	else//no phase
//	if (ang < 270)
//		return 0;
//	else//in phase
//		return 1;
//}
//
///***********************************
//		Define petals for angle
//***********************************/
//
////	Define diagonal quadrant
//static inline int petq( int ang )
//{
//	ang = upci( ang ); //360
//
//	//divides area to petals
//	if (ang <  45)	return 0;
//	if (ang < 135)	return 2;
//	if (ang < 225)	return 4;
//	if (ang < 315)	return 6;
//	/* default */	return 0;
//}
//
////	Define common quadrant
//static inline int petr( int ang )
//{
//	ang = upci( ang ); //360
//
//	//divides area to petals
//	if (ang <  90)	return 1;
//	if (ang < 180)	return 3;
//	if (ang < 270)	return 5;
//	/* default */	return 7;
//}
//
////	Define small eight petals
//static inline int petx( int ang )
//{
//	ang = upci( ang ); //360
//
//	//divides area to petals
//	if (ang <  23)	return 0;
//	if (ang <  68)	return 1;
//	if (ang < 113)	return 2;
//	if (ang < 158)	return 3;
//	if (ang < 203)	return 4;
//	if (ang < 248)	return 5;
//	if (ang < 293)	return 6;
//	if (ang < 338)	return 7;
//	/* default */  return 0;
//}
//
////	Get concise direction
//static inline int upco( int ang )
//{  
//	return 45 * petx( ang );
//}
//
////	Get direction for any d(x) & d(y)
//static inline int adir( int incx,int incy )
//{
//	return petx( atan( incx,incy ));
//}
//
////----------------------------------
////	Derivative definitions
////----------------------------------
//#define Min4( a,b,c,d ) MIN( MIN( MIN( a,b ),c ),d )
//#define Max4( a,b,c,d ) MAX( MAX( MAX( a,b ),c ),d )
//#define MAS( a,b,c,d ) MAX( ABS( a+b ),ABS( c+d ) )
//#define ROT( a,b,c )	  (scis( a,b ) - scis( c,b ) )
//#define DIS( a,b,c )	  (scis( a,b ) + scis( c,b ) )
//#define ARC( a,b,c )	  (uppi( b + DIS( a,b,c )/2) )
//
//
////template <class T> 
////T normAngle (T angle)
////{
////   while (angle < -180)
////      angle += 360;
////   while (angle >= 180)
////      angle -= 360;
////   return angle;
////}


//static int normAngle (int angle)
//{
//   while (angle < -180)
//      angle += 360;
//   while (angle >= 180)
//      angle -= 360;
//   return angle;
//}





#pragma pack(pop)
} // namespace accelMatch{


#endif	// MATHEM_ACCEL_H_

