#define _USE_MATH_DEFINES
#include <math.h>
#include <stdlib.h>
#include <assert.h>

#include "accelData.h"
#include "compAccel.h"
#include "staticData.h"
#include "accelAdjust.h"
#include "adjustParams100.h"
#include "calcScore.h"
#include "adjustParam.h"


//long long g_numGroup_1st = 0;


namespace accelMatch{
#pragma pack(push, _CORE_PACKING)

   
BYTE accelHT[256][256];
BYTE notPairHT [256][256];


void thinOutMainGroup(AccelPair *mainGroup,  AccelPair *group)
{
   int num = group->m_size;
   int numMain = mainGroup->m_size;
   for(int i = 0; i < numMain; i++)
   {
      if (mainGroup->m_np[i] == -1)
         continue;
      for(int j = 0; j < num; j++)
      {
         if((mainGroup->m_np[i] == group->m_np[j]) && (mainGroup->m_ng[i] == group->m_ng[j]))
         {
            mainGroup->delPair(i);
            continue;
         }
      }
   }
}
void  addLinkItems  (Accel *aP, Accel *aG, AccelPair *group)
{
   if (!aP || !aG)
      return;
   int np = 0, ng = 0;
   m128i_my res = my_mm_abs_sub_epi8 (aP, aG);
    
   for(int i = 0; i < 16; i++)
   {
      if (!(np = aP->item.m128i_u8[i]))
         continue;
      if (!(ng = aG->item.m128i_u8[i]))
         continue;
      if (res.m128i_i8[i] > 1)
         continue;
      if (!group->canAdd(--np, --ng))
         continue;
      if (!group->isCompatible(np, ng))
            continue;
      group->addNext(np, ng);
   }
}
void expandGroupByLink(AccelPair *g, SortedAccel *aP, SortedAccel *aG, int start = 0)
{
   int np = 0, ng = 0;
   for(unsigned int k = start; k < g->m_size; k++) 
   {
      np = g->m_np[k];
      ng = g->m_ng[k];
      addLinkItems (aP->sortedAccel[np], aG->sortedAccel[ng], g);
   }
}

void expandGroupByLink_2nd(AccelPair *g, SortedAccel *aP, SortedAccel *aG)
{
   int np = 0, ng = 0;
   for(unsigned int k = 1; k < g->m_size; k++) 
   {
      np = g->m_np[k];
      ng = g->m_ng[k];
      addLinkItems (aP->sortedAccel[np], aG->sortedAccel[ng], g);
   }
}

void expandGroupByLink_1st(AccelPair *g, SortedAccel *aP, SortedAccel *aG)
{
   addLinkItems (aP->sortedAccel[g->m_np[0]], aG->sortedAccel[g->m_ng[0]], g);
}


// transfer minutiae to another coordinate system
void transferMinutiae(unsigned short   srcX, unsigned short  srcY,
							 short  *dstX, short *dstY, 
                      unsigned int    srcXc, unsigned int   srcYc, unsigned int    dstXc, 
							 unsigned int    dstYc, unsigned int angle, 
							 short &rotationRad, BYTE &rotationAngle)
{
   int x = srcX - srcXc;
   int y = srcY - srcYc;
   rotationRad = (short)dist(x, y);
	int ang = atan (x, y);
   *dstX = dstXc + cosm(rotationRad, ang + angle);
   *dstY = dstYc + sinm(rotationRad, ang + angle);
   rotationAngle = ang / 4;
}
// rotate and shift minutiae to combine with probe minutiae
bool transferMinutiaes( MinutiaeData   *srcMin, 
                        MinutiaeData   *dstMin, 
                        int             num,
                        unsigned int    srcXc, 
                        unsigned int    srcYc, 
                        unsigned int    dstXc, 
                        unsigned int    dstYc, 
                        unsigned int    angle,
								short          *rotationRad,
								BYTE           *rotationAngle)
{
   if (!srcMin || !dstMin) return false;

   for (int i = 0; i < num; i++ )
   {
      transferMinutiae (srcMin[i].x, srcMin[i].y, &dstMin[i].x, &dstMin[i].y, 
                        srcXc, srcYc, dstXc, dstYc, angle, rotationRad[i], rotationAngle[i]);
   }
   return true;
}

bool combineFingerprints(AccelPair *group, int numMinutiaeP, int numMinutiaeG, MinutiaeData *minutiaeG2P, 
									MinutiaeData *minutiaeP2G, int angleTol, ThreadData* threadData)
{
   if (abs(normQuarterAngle(group->m_angle)) > angleTol)
      return false;
   transferMinutiaes(group->m_minG, minutiaeG2P, numMinutiaeG, group->m_xcG, group->m_ycG, 
		group->m_xcP, group->m_ycP, 360 -group->m_angle * 4, threadData->m_radG, threadData->m_angG);
   transferMinutiaes(group->m_minP, minutiaeP2G, numMinutiaeP, group->m_xcP, group->m_ycP, 
		group->m_xcG, group->m_ycG, group->m_angle * 4, threadData->m_radP, threadData->m_angP);
   return true;
}

void calcFrame(int num, MinutiaeData *min, ::Frame &frame)
{
	memset(&frame, 0, sizeof(::Frame));
   for(int i = 0; i < num; i++)
   {
      if      (min[i].x < frame.left  ) frame.left   = min[i].x;
      else if (min[i].x > frame.right ) frame.right  = min[i].x;
      if      (min[i].y < frame.top   ) frame.top    = min[i].y;
      else if (min[i].y > frame.bottom) frame.bottom = min[i].y;
   }
}

inline void checkBadArea (MinutiaeData *min, int num, unsigned char *area, int areaWidth, int 
                          areaHeight, int reach, int tol, bool *exclude, bool *takenG)
{
   int x = 0, y = 0, sum = 0;
   int maxx = areaWidth;// width >> 3;
   int maxy = areaHeight;//height >> 3; 
   int rowlen = areaWidth;//(width & 7) ? maxx + 1 : maxx;
   for(int n = 0; n < num; n++)
   {
      if (takenG[n])
         continue;
      x = min[n].x >> 3;
      y = min[n].y >> 3;
      sum = 0;
      for (int j = y - reach; j <= y + reach; j++ ) 
      {
         if (j >= 0 && j < maxy) 
         {
            int shift = j * rowlen;
            for (int i = x - reach; i <= x + reach; i++) 
            {
               if (i >= 0 && i < maxx) 
                  if (area[shift + i] != 0x40) 
                     sum++;
            }
         }
      }
      exclude[n] = ( sum < tol);
   }
}


// find minutiae thouse can be behind of clear area of probe fingerprint
BYTE findExcludeG (AccelData *accelData, int probeFinger,  MinutiaeData *minG2P, int numMinutiaeG, bool *takenG, AccelPair *curGroup, bool *excludeG)
{
   int reach = 2;
   int tol = (2 * reach + 1) * (2 * reach + 1) * 5 / 6; 
   checkBadArea (minG2P, numMinutiaeG, accelData->m_areaP[probeFinger], accelData->m_areaWidthP[probeFinger], 
                  accelData->m_areaHeightP[probeFinger], reach, tol, excludeG, takenG);

   BYTE numExcludeG = 0;
   for(int ng = 0; ng < numMinutiaeG; ng++)
      if (excludeG[ng])
         numExcludeG++;

   return numExcludeG;
}

bool findExclude (AccelData *accelData, int probeFinger      , AccelPair *curGroup,
                  MinutiaeData *minP2G, int numMinutiaeP, bool *takenP,
                  MinutiaeData *minG2P, int numMinutiaeG, bool *takenG,
                  bool *excludeP      , bool *excludeG  ,
                  BYTE &numExcludeP   , BYTE &numExcludeG)
{
   ::Frame frameG;
   calcFrame(numMinutiaeG, curGroup->m_minG, frameG);
   numExcludeP = 0;
   for(int np = 0; np < numMinutiaeP; np++)
   {
      if (takenP[np])
         continue;
      if (  minP2G[np].x < frameG.left || minP2G[np].x > frameG.right 
         || minP2G[np].y < frameG.top  || minP2G[np].y > frameG.bottom
         ) 
      {
         excludeP[np] = true;
         numExcludeP++;
      }
   }
   numExcludeG = findExcludeG(accelData, probeFinger, minG2P, numMinutiaeG, takenG, curGroup, excludeG);

   return true;
}


bool expandGroupByGeometry (AccelData *accelData, AccelPair *curGroup, int numMinutiaeP, int numMinutiaeG, int angleTol,
                              MinutiaeData *minG2P, MinutiaeData *minP2G, bool * takenP, bool *takenG,
                              unsigned int threadNum)
{
    ThreadData* threadData = getThreadData (accelData, threadNum);
   if (!combineFingerprints(curGroup, numMinutiaeP, numMinutiaeG, minG2P, minP2G, angleTol, threadData))
      return false;
   MinutiaeData *minG = curGroup->m_minG;
   MinutiaeData *minP = curGroup->m_minP;
   for(unsigned int i = 0; i < curGroup->m_size; i++)
   {
      int np = curGroup->m_np[i];
      int ng = curGroup->m_ng[i];
      takenP[curGroup->m_np[i]] = true;
      takenG[curGroup->m_ng[i]] = true;
   }
//return true;
   int dx = 0, dy = 0, da = 0, maxDistErr = 0;
   for (int np = 0; np < numMinutiaeP; np++)
   {
      if (takenP[np]) // aready has a pair
         continue;
		maxDistErr = curGroup->getDistTolerance (threadData->m_radP[np]);
      for(int ng = 0; ng < numMinutiaeG; ng++)
      {
         if (takenG[ng]) // aready has a pair
				continue;
         dx = abs(minP[np].x - minG2P[ng].x); 
         if (dx > maxDistErr)
            continue;
         dy = abs(minP[np].y - minG2P[ng].y);
         if (dy > maxDistErr)
            continue;
         da = accelData->getAngleDif(minP[np].a, minG[ng].a, curGroup->m_angle); 
         if (da >= GROUP_ANGLE_TOL)
            continue;
         if (!curGroup->isCompatible(np, ng, true, takenP, takenG))
            continue;
         curGroup->addNext (np, ng);
         takenP[np] = true;
         takenG[ng] = true;
         break;                         // ���� ������� ���� break, �� ����� �����-�� ������� ��������������� ����� ��������� ng
      }
   }
   return true;
}

bool getGeometryDif (AccelData *accelData, int probeFinger, AccelPair *curGroup, 
                     MinutiaeData *minG2P,  int numMinutiaeG, 
                     BYTE &posDif, BYTE &minAngleDif, BYTE &angleDif, 
                     unsigned int threadNum)
{
   assert(accelData->m_allAccelP[probeFinger]);
   int numMinutiaeP = accelData->m_allAccelP[probeFinger]->numMinutiae;
   ThreadData* threadData = getThreadData (accelData, threadNum);
   MinutiaeData *minG = curGroup->m_minG;
   MinutiaeData *minP = curGroup->m_minP;
   int sumPosDif = 0, sumMinAngleDif = 0, sumAngleDif = 0, pos = 0;
//   int prob = 0, sumProb = 0;
  // int minRad = 0, maxRad = 0;
   for(unsigned int i = 0; i < curGroup->m_size; i++)
   {
      int np = curGroup->m_np[i];
      int ng = curGroup->m_ng[i];
      //prob = minP[np].p + minG[ng].p;
      //sumProb += prob;
      pos           = abs(minP[np].x - minG2P[ng].x) + abs(minP[np].y - minG2P[ng].y);// * prob;
      sumPosDif      += pos;
		sumMinAngleDif += accelData->getAngleDif(minP[np].a, minG[ng].a, curGroup->m_angle); 
      sumAngleDif    += accelData->getAngleDif(threadData->m_angP[np], threadData->m_angG[ng], curGroup->m_angle); 
    //  minRad = minAB (threadData->m_radP[np], threadData->m_radG[ng]);
    //  maxRad = maxAB (threadData->m_radP[np], threadData->m_radG[ng]);
   }

   //curGroup->m_posDif = curGroup->m_num ? sumPosDif / sumProb : 0;
   //curGroup->m_angleDif = curGroup->m_num ? sumMinAngleDif / sumProb : 0;
   posDif       = curGroup->m_num ? sumPosDif      / curGroup->m_num : 0;
   minAngleDif  = curGroup->m_num ? sumMinAngleDif / curGroup->m_num : 0;
   angleDif     = curGroup->m_num ? sumAngleDif    / curGroup->m_num : 0;

   return true;
}

int compareNests(AccelData *accelData, int threadNum, int np0, int ng0, MinutiaeData *minP, MinutiaeData *minG, int numMinP, int numMinG, 
                 bool *takenP, bool *takenG, int angle, Accel* aP, Accel *aG, bool *excludeP, bool *excludeG)
{
   int sim = 0;
   int np = 0, ng = 0;
   int numP = 0, numG = 0, count = 0, dif = 0;
   int maxDif = 3, mul = 3;
   m128i_my res = my_mm_abs_sub_epi8 (aP, aG);

#ifndef IP_73   
   short x0P = minP[np0].x;
   short y0P = minP[np0].y;
   short x0G = minG[ng0].x;
   short y0G = minG[ng0].y;
   int maxDistErr = 70, maxMinAngle = 20, maxAngle = 20;
   int score = 0;
   ThreadData* threadData = getThreadData (accelData, threadNum);

   for(int i = 0; i < 16; i++)
   {
      np = aP->item.m128i_u8[i];
      ng = aG->item.m128i_u8[i];
      if (np && !excludeP[np]) numP++;
      if (ng && !excludeG[ng]) numG++;
      if (!np || !ng)
         continue;
      if (!takenP[--np] || !takenG[--ng])
         continue;
      if (np == np0 || ng == ng0)
         continue;
      int distP = dist (x0P, y0P, minP[np].x, minP[np].y); 
      int distG = dist (x0G, y0G, minG[ng].x, minG[ng].y); 
      int ddist = abs (distP - distG) * 256 / maxAB(distP, distG);
      if (ddist > maxDistErr)
         continue;
		int minAngleDif = accelData->getAngleDif(minP[np].a, minG[ng].a, angle); 
static int maxMinAngleDif = 0;
if (maxMinAngleDif < minAngleDif) 
   maxMinAngleDif = minAngleDif;
      if (minAngleDif >maxMinAngle) 
         continue;
      int angleDif    = accelData->getAngleDif(threadData->m_angP[np], threadData->m_angG[ng], angle); 
static int maxAngleDif = 0;
if (maxAngleDif < angleDif) 
   maxAngleDif = angleDif;
      if (angleDif >maxAngle) 
         continue;
      score += (int)sqrt ((maxDistErr - ddist) * (maxMinAngle - minAngleDif) * (maxAngle - angleDif));
   }
   score = (numP + numG) ? score / (numP + numG) : 0;
   score /= 2;
   return score;
static int maxScore = 0;
if (maxScore < score) 
   maxScore = score;
#endif

   for(int i = 0; i < 16; i++)
   {
      np = aP->item.m128i_u8[i];
      ng = aG->item.m128i_u8[i];
      if (np && !excludeP[np]) numP++;
      if (ng && !excludeG[ng]) numG++;
      if (!np || !ng)
         continue;
      dif = res.m128i_i8[i];
      if ((dif < maxDif) || (i + 4 < 16 && (dif = abs(aP->accel.m128i_u8[i] - aG->accel.m128i_u8[i + 4])) < maxDif) ||
                            (i - 4 >= 0 && (dif = abs(aP->accel.m128i_u8[i] - aG->accel.m128i_u8[i - 4])) < maxDif))
      {
         sim += mul * (maxDif - dif);
         count++;
      }
   }
   return sim - (numP - count) - (numG - count);

}

int getTopologySim(AccelData *accelData, int threadNum, MinutiaeData *minP, MinutiaeData *minG, int numMinP, int numMinG, bool *takenP, bool *takenG, AccelPair *bestGroup, SortedAccel *sortedAccelP, SortedAccel *sortedAccelG, 
                     bool *excludeP, bool *excludeG)
{
   BYTE count = 0;
   int sim = 0;
   int num = bestGroup->m_num;
   Accel *accelP = NULL, *accelG = NULL;
   for (int i = 0; i < num; i++)
   {
      short np0 = bestGroup->m_np[i];
      short ng0 = bestGroup->m_ng[i];
      accelP = sortedAccelP->sortedAccel[np0];
      accelG = sortedAccelG->sortedAccel[ng0];
      if (!accelP || !accelG)
         continue;
      sim += compareNests(accelData, threadNum, np0, ng0, minP, minG, numMinP, numMinG, takenP, takenG, bestGroup->m_angle, accelP, accelG, excludeP, excludeG);
      count++;
   }
   return count ? sim / count : 0;
}

void getPairLenDif (AccelScoreParam &param, AccelPair *g, MinutiaeData *minP, MinutiaeData *minG, int numMinutieP, int numMinutiaeG)
{
   int pairLenDif = 0;
   int num = g->m_num;
   int np1 = 0, ng1 = 0, np2 = 0, ng2 = 0;  
   int distP = 0, distG = 0, minDist = 0, maxDist = 0, maxProbeDist = 0;
   int count = 0;
//   int prob = 0, probP = 0, sumProb = 0;
   for(int i = 0; i < num; i++)
   {
      np1 = g->m_np[i];
      ng1 = g->m_ng[i];
//      probP = minP[np1].p + minP[np2].p;
      for(int j = i + 1; j < num; j++)
      {
         np2 = g->m_np[j];
         ng2 = g->m_ng[j];
         distP = dist(minP[np1].x, minP[np1].y, minP[np2].x, minP[np2].y);
         distG = dist(minG[ng1].x, minG[ng1].y, minG[ng2].x, minG[ng2].y);
         if (maxProbeDist < distP) maxProbeDist = distP;
         maxDist = maxAB(distP, distG);
         minDist = minAB(distP, distG);
         if (minDist < 20)
            continue;
         //prob = probP + minG[ng1].p + minG[ng2].p;
         //sumProb += prob;
         pairLenDif += (100 - minDist * 100 / maxDist);// * prob; 
			count++;
      }
   }
	param.pairLenDif   = count  ? pairLenDif  / count  : 0;
   maxProbeDist /= 4;
   param.maxProbeDist = maxProbeDist > 255 ? 255 : maxProbeDist;
}

int compPairSets ( const void *g1, const void *g2 )
{
   return (*(AccelPair**)g2)->m_num - (*(AccelPair**)g1)->m_num;
}


int buildGroup(AccelData *accelData, int probeFinger, AccelSearchParam &matchParam, AccelPair *g, SortedAccel *aG, 
              MinutiaeData *minG, int numMinutiaeG, AccelPair **localGroup, 
               unsigned int minPointInLocalGroup_1st, unsigned int minPointInLocalGroup_2nd, BYTE qualityG, 
               unsigned int threadNum, AccelPair *bestGroup)
{
   int np = 0, ng = 0;
   int pos = 0;
   int score = 0, maxScore = 0;
   int num = g->m_size;
   int count = 0;
   int numCurGroup = 0, numGroup_1st = 0, numSortedGroup = 0;
   for(int i = 0; i < num; i++)
   {
      if (g->m_np[i] == -1)
         continue;
      AccelPair* curGroup = localGroup[numCurGroup];
      curGroup->clear();
      curGroup->addFirst(g->m_np[i], g->m_ng[i]);
      expandGroupByLink_1st (curGroup, &accelData->m_sortedAccelP[probeFinger], aG);
      if (curGroup->m_size < minPointInLocalGroup_1st) 
         continue;
      thinOutMainGroup(g, curGroup); 
      if (++numCurGroup >= MAX_LOCAL_GROUP_1ST)
         break;
   }
   // sort local groups by number of elements 
   qsort (localGroup, numCurGroup, sizeof(AccelPair*), compPairSets);
   numGroup_1st = numCurGroup;
   if (numGroup_1st > MAX_LOCAL_GROUP_2ND)
      numGroup_1st = MAX_LOCAL_GROUP_2ND;

//   g_numGroup_1st += numGroup_1st;
//return 0;
   for(int i = 0; i < numGroup_1st; i++)
   {
      AccelPair* curGroup = localGroup[i];
      if (!curGroup->m_size)
         continue;
//		curGroup->setDistToleranceTable (2);
      expandGroupByLink_2nd (curGroup, &accelData->m_sortedAccelP[probeFinger], aG);
      if (curGroup->m_size < minPointInLocalGroup_2nd) 
         continue;
      // clear  groups with same pairs
      for(int j = i + 1; j < numGroup_1st; j++)
      {
         AccelPair* newGroup = localGroup[j];
         if (curGroup->find (newGroup->m_np[0], newGroup->m_ng[0]))
            newGroup->clear();
      }
      curGroup->recalcData();
   }
//return 0;
   // sort local groups by number of elements 
   qsort (localGroup, numCurGroup, sizeof(AccelPair*), compPairSets);
   numSortedGroup = numCurGroup;
   if (numSortedGroup > MAX_SORTED_LOCAL_GROUP)
      numSortedGroup = MAX_SORTED_LOCAL_GROUP;

   
   for(int i = 0; i < numSortedGroup; i++)
   {
      AccelPair* curGroup = localGroup[i];
      if (curGroup->m_size < minPointInLocalGroup_2nd)
         break;
      // try to unite groups
      for(int j = i + 1; j < numCurGroup; j++)
      {
         AccelPair* newGroup = localGroup[j];
         if  (!newGroup->m_size)
            continue;
         if (!curGroup->canAdd (newGroup->m_np[0], newGroup->m_ng[0]))
            continue;
         //if (!curGroup->isCompatible(newGroup->m_np[0], newGroup->m_ng[0]))
         //   continue;
         //*curGroup += *newGroup;
         //newGroup->clear();

         //if (!curGroup->canAdd (newGroup->m_np[0], newGroup->m_ng[0])) // this pair already in current group
         //{
         //   newGroup->clear();
         //   continue;
         //}
         if (!curGroup->isCompatible(newGroup->m_np[0], newGroup->m_ng[0]))
            continue;
         curGroup->addNext (newGroup->m_np[0], newGroup->m_ng[0]);
         for(unsigned int k = 1; k < newGroup->m_size; k++)
         {
            if (!curGroup->canAdd (newGroup->m_np[k], newGroup->m_ng[k]))
               continue;
            if (!curGroup->isCompatible(newGroup->m_np[k], newGroup->m_ng[k]))
               continue;
            curGroup->addNext (newGroup->m_np[k], newGroup->m_ng[k]);
         }

//         *curGroup += *newGroup;
         newGroup->clear();


         //curGroup->addNext(newGroup->m_np[0], newGroup->m_ng[0]);
         //for(int k = 1; k < newGroup->m_num; k++)
         //{
         //   if (!curGroup->canAdd (newGroup->m_np[k], g->m_ng[k]))
         //      continue;
         //   if (!curGroup->isCompatible(newGroup->m_np[k], newGroup->m_ng[k]))
         //      continue;
         //   curGroup->addNext(newGroup->m_np[k], newGroup->m_ng[k]);
         //}

      }
      AccelScoreParam param;
      param.mainGroupSize  = curGroup->m_num;
		curGroup->recalcData();
//		curGroup->setDistToleranceTable (2);
      MinutiaeData minG2P[MAX_ACCEL_MIN], minP2G[MAX_ACCEL_MIN];
      assert (accelData->m_allAccelP[probeFinger]);
      int numMinutiaeP = accelData->m_allAccelP[probeFinger]->numMinutiae;
      bool takenP[MAX_ACCEL_MIN], takenG[MAX_ACCEL_MIN];
      memset (takenP, 0, sizeof(takenP));
      memset (takenG, 0, sizeof(takenG));
      if (!expandGroupByGeometry (accelData, curGroup, numMinutiaeP, numMinutiaeG, matchParam.maxAngle / 4,
                                    minG2P, minP2G, takenP, takenG, threadNum))
         continue;
      bool excludeP [MAX_ACCEL_MIN], excludeG [MAX_ACCEL_MIN];
      memset (excludeP, 0, sizeof(excludeP));
      memset (excludeG, 0, sizeof(excludeG));
      findExclude(accelData, probeFinger, curGroup, minP2G, numMinutiaeP, takenP, minG2P, numMinutiaeG, takenG, 
                        excludeP, excludeG, param.numExcludeP, param.numExcludeG); 
      // ����� ��������� ����������� ��������� � ����� � ���� ����� - �����!
      getGeometryDif (accelData, probeFinger, curGroup, minG2P, numMinutiaeG, param.posDif, 
                        param.minAngleDif, param.angleDif, threadNum);

      param.qualityP       = accelData->m_allAccelP[probeFinger]->quality;
      param.qualityG       = qualityG;
      param.numMinutiaeP   = accelData->m_allAccelP[probeFinger]->numMinutiae;
      param.numMinutiaeG   = numMinutiaeG;
      param.numFound       = curGroup->m_num;
//      score = calcScore(param);
//      if (score < 30)//50)
//         continue;
      param.topologySim = getTopologySim (accelData, threadNum, accelData->m_minP[probeFinger], minG, accelData->m_allAccelP[probeFinger]->numMinutiae, numMinutiaeG, takenP, takenG, curGroup, &accelData->m_sortedAccelP[probeFinger], aG, excludeP, excludeG);
      getPairLenDif (param, curGroup, accelData->m_minP[probeFinger], minG, accelData->m_allAccelP[probeFinger]->numMinutiae, numMinutiaeG);
#ifdef ADJUST
      saveAccelParameters(param);
//      g_numGroup++;
#endif // ADJUST
      score = calcScore(param, accelData->m_ipVer == 140 ? g_scoreParam_140 : g_scoreParam_73);
      if (maxScore < score)
      {
         maxScore = score;
         if (bestGroup) 
            *bestGroup = *curGroup;
      }
   }

   return maxScore;
}

#pragma pack(pop)
} // namespace accelMatch{
