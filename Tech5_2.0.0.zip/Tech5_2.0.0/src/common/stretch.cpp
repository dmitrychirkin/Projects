#include "stretch.h"

void stretch (unsigned int srcWidth, unsigned int srcHeight, unsigned int srcRow, 
              const BYTE* src, float kx, float  ky,
				   unsigned int *DstWidth, unsigned int *DstHeight, BYTE* dst)
{
	double k1 = 0, k2 = 0;
	unsigned int x = 0, y = 0;
	unsigned int i = 0, j = 0;
	unsigned int dstHeight = (unsigned int)(srcHeight * ky);
	unsigned int dstWidth  = (unsigned int)(srcWidth  * kx);
	unsigned int dstRow = 0;           /* destination/source matrix row lenght */
	int srcShift = 0;
   unsigned char* pd = (unsigned char*)dst;
		
	dstWidth = dstWidth   / 4 * 4;
   dstHeight = dstHeight / 4 * 4;
	dstRow = dstWidth;				

   for (j = 0; j < dstHeight; j++)
	{
		y = (unsigned int)(j / ky);
		if (y > srcHeight - 2) 
			y = srcHeight - 2;
		k1 = j / ky - y;

		srcShift = srcRow * y;
		for (i = 0; i < dstWidth - 1; i++)
		{
			x = (unsigned int)(i / kx);
			if (x > srcWidth - 2) 
				x = srcWidth - 2;
			k2 = i / kx - x;

			pd[i] = (unsigned char)(
				src[srcShift + x] * (1 - k1) * (1 - k2) + 
				src[srcShift + x + 1] * k2 * (1 - k1) + 
				src[srcShift + srcRow + x] * k1 * (1 - k2) + 
				src[srcShift + srcRow + x + 1] * k1 * k2 + 0.5);

		}
		pd[dstWidth - 1] = src[srcShift + srcWidth - 1];

		for (i = dstWidth; i < dstRow; i++)		/* arrange the row */
			pd[i] = 0;

		pd += dstRow;
	}
	/* change destination with to size of row, so image processing haven't problem */
	*DstWidth  = dstRow;
	*DstHeight = dstHeight;
}

template<class T>
inline double newton4 (T *y, double dx)
{
   return y[0] + dx  * (y[1] - y[0]) + dx * (dx - 1) * (y[2] + y[0] - 2 * y[1]) / 2 + 
      dx * (dx - 1) * (dx - 2) * (y[3] + y[1] - 2 * y[0]) / 6;
}

template<class T>
inline double newton3 (T *y, double dx)
{
   return y[0] + dx  * (y[1] - y[0]) + dx * (dx - 1) * (y[2] + y[0] - 2 * y[1]) / 2;
}

template<class T>
inline double newton2 (T *y, double dx)
{
   return y[0] + dx  * (y[1] - y[0]);
}



/*
	strech image (bpp - should be equal 8 and rows should be arrange on 4 bytes)
	srcWidth, srcHeight - size of the source image
	dstWidth, dstHeight - size of the destination image
	kx, ky - stretching coefficients
	src - source image
	dst - destination image
*/
void stretch4 (unsigned int srcWidth, unsigned int srcHeight, const BYTE* src, 
				   float kx, float  ky,
				   unsigned int *DstWidth, unsigned int *DstHeight, BYTE* dst)
{
	double dx = 0, dy = 0, x = 0, y = 0;
	int ix = 0, iy = 0;
	int i = 0, j = 0;
	int dstHeight = (int)(srcHeight * ky);
	int dstWidth  = (int)(srcWidth  * kx);
	int dstRow = 0, srcRow = 0;           /* destination/source matrix row lenght */
   unsigned char* pd = (unsigned char*)dst;
   unsigned char* ps = (unsigned char*)src;
   // brightness in 9 points of source image
   unsigned char b1[3], b2[3], b3[3];
   // brightness in 4 inner points
   double  t[3];
		
	dstWidth = dstWidth / 4 * 4;
	dstRow = dstWidth;				
	srcRow = ((srcWidth + 3) >> 2) << 2;		/* source matrix row lenght (we suppose that 
																rows in source matrix is arranged) */
	for (j = 0; j < dstHeight; j++)
	{
		y = j / ky;
      iy = (int)y;
      if (iy < 0)                  iy = 0;
      if (iy > (int)srcHeight - 3) iy = (int)srcHeight - 3;
		dy = y - iy;

		ps = (unsigned char*)src + srcRow * iy;
		for (i = 0; i < dstWidth; i++)
		{
			x = i / kx;
         ix = (int)x;
         if (ix < 0)                 ix = 0;
			if (ix > (int)srcWidth - 3) ix = (int)srcWidth - 3;
         dx = x - ix;
         
         b1[0] = ps[             ix    ];
         b1[1] = ps[             ix + 1];
         b1[2] = ps[             ix + 2];
         b2[0] = ps[srcRow     + ix    ];
         b2[1] = ps[srcRow     + ix + 1];
         b2[2] = ps[srcRow     + ix + 2];
         b3[0] = ps[srcRow * 2 + ix    ];
         b3[1] = ps[srcRow * 2 + ix + 1];
         b3[2] = ps[srcRow * 2 + ix + 2];
         t[0] = newton3 (b1, dx);
         t[1] = newton3 (b2, dx);
         t[2] = newton3 (b3, dx);
         double temp = newton3(t, dy);
         if (temp >= 255)
            pd[i] = 255;
         else if (temp <= 0)
            pd[i] = 0;
         else 
            pd[i] = (unsigned char)temp;
    
		}
		for (i = dstWidth; i < dstRow; i++)		/* arrange the row */
			pd[i] = 0;

		pd += dstRow;
	}
	/* change destination with to size of row, so image processing haven't problem */
	*DstWidth  = dstRow;
	*DstHeight = dstHeight;
}
