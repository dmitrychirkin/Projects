#include "calcScore.h"
#include "compAccel.h"
#include "win2lin.h"
#include "sfsDef.h"

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)

int g_scoreParam_73[SCORE_ACCEL_PARAM_SIZE] = 
{
    3300,         //   0, 
  120000,         //   1, 
   11000,         //   2, numFound
   67000,         //   3, mainGroupSize / maxPossibleFound
       0,         //   4, numFound / maxPossibleFound * minQ
   37000,         //   5, (numFound - mainGroupSize) / maxPossibleFound
     260,         //   6, posErr
       0,         //   7, 
    2700,         //   8, minAngleDif
     280,         //   9, topologySim
    4400,         //  10, pairLenDif 
       0,         //  11, 
     330,         //  12, angleDif
      22,         //  13, 
};  

// FVC2004-1
//int g_scoreParam_140[SCORE_ACCEL_PARAM_SIZE] =
//{
////      0,      1,      2,      3,      4,      5,      6,      7,      8,      9,     10,     11,     12,     13,
////   1632, 211100,  10450,  83692,     45,  90809,    240,      0,   3216,   3552,   3621,      0,    352,     15, // w = 95.00
////   1632, 211100,  10450,  83692,     45,  90809,    240,      0,   3216,    403,   3621,      0,    352,     15, // w = 94.34  scoreParam[9] only
////   1632, 211100,  10450,  10836,     13,  90809,    240,      0,   3216,    712,   3621,      0,    352,     28,// w = 94.74  scoreParam[3,4, 9] only
////   1632, 211100,  10450,  19642,     17,   3632,    240,      0,   3216,   1372,   3621,      0,    352,     25,// w = 94.78  scoreParam[3,4, 5, 9] only
////   -334,  21110,  10450,  23560,    -10,   6889,    240,      0,   3216,   1372,   3621,      0,    352,     28,// w = 94.87  scoreParam[0, 1, 3, 4, 5, 9] only
////   -145,  59544,  10450,  46629,     -2,  13563,    240,      0,   3216,   2673,    648,      0,    352,     26,// w = 94.87  scoreParam[0, 1, 3, 4, 5, 9, 10] only
////   -182,  59544,  10450,  46600,     -2,  20054,    240,      0,   3216,   2673,    852,      0,    352,     26,// w = 94.92  scoreParam[0, 1, 3, 4, 5, 9, 10, 12] only
////    -97,  59544,  10450,  44321,     -1,  32481,    240,      0,   2560,   2350,   1530,      0,    392,     26,// w = 95.00  scoreParam[0, 1, 3, 4, 5, 8, 9, 10, 12] only
//// -111, 103326,  10450,  87714,     -1,  71960,    124,      0,   3060,   5208,   1887,      0,    434,     32,// w = 95.07  scoreParam[0, 1, 3, 4, 5, 6, 8, 9, 10, 12] only
//   -644, 103296,   2090,  87714,     -1,  79156,    128,      0,   2754,   5168,   2040,      0,   1102,     32, // w = 95.07 
////      0,      0,      0,      0,      0,      0,      0,      0,      0,    568,      0,      0,      0,     64, // w = 94.34  scoreParam[9] only
////      0,      0,      0,   4514,     12,      0,      0,      0,      0,    312,      0,      0,      0,     27,// w = 94.74  scoreParam[3,4,9] only
////        0,      0,      0,   4514,     12,    118,      0,      0,      0,    312,      0,      0,      0,     27,// w = 94.76  scoreParam[3,4,5, 9] only
//};

// FVC_UNI
int g_scoreParam_140[SCORE_ACCEL_PARAM_SIZE] =
{
//      0,      1,      2,      3,      4,      5,      6,      7,      8,      9,     10,     11,     12,     13,
      -15, 211200,   6018, 131957,     -3,  88000,    177,      0,   9800,   2015,   3366,      0,   4335,     68,  // w = 94.85
};



int calcScore(AccelScoreParam &param, int *scoreParam)
{
   if (!param.numFound)
      return 0;
   BYTE minQ            = minAB(param.qualityP, param.qualityG); 
   int maxPossibleFound = minAB(param.numMinutiaeP - param.numExcludeP, param.numMinutiaeG - param.numExcludeG);

   int score = scoreParam[0] +  ((scoreParam[1] * minQ * minQ) >> 20) +
            (
          +  (int)(scoreParam[ 2] * pow ((float)param.numFound, 0.33f))
          +       (scoreParam[ 3] +  scoreParam[4] * minQ) *  param.mainGroupSize                   / maxPossibleFound
          +       (scoreParam[ 5]                        ) * (param.numFound - param.mainGroupSize) / maxPossibleFound
          -        scoreParam[ 6] * param.posDif * sqri(minQ) 
          -        scoreParam[ 8] * param.minAngleDif
          +        scoreParam[ 9] * param.topologySim
          -        scoreParam[10] * param.pairLenDif 
          -        scoreParam[12] * param.angleDif
              ) / 15;
   if (param.numFound < scoreParam[13])
      score = score * param.numFound / scoreParam[13];

   if      (score <         0) score =     0;
   else if (score > MAX_SCORE) score = MAX_SCORE;

   return score;
}



#pragma pack(pop)
} // namespace accelMatch{
