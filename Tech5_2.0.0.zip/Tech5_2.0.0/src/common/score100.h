/*
   score.h - declare function for score calculation

   Copyright (C) 2006 Sonda Technologies Ltd.
   Author A.Mosunov
   13.06.2007
*/
#ifndef  SCORE100_H_
#define  SCORE100_H_
#include "scoreParameters100.h"


namespace accelMatch {
#pragma pack(push,_CORE_PACKING)

#define SCORE_Q_PARAM_SIZE1     3  
#define SCORE_PG_PARAM_SIZE1      4  
#define SCORE_PG_Q_PARAM_SIZE1     (SCORE_Q_PARAM_SIZE1 * SCORE_PG_PARAM_SIZE1)  
#define SCORE_PG_Q_PARAM_SIZE2      2  
#define SCORE_PG_PARAM_SIZE2        7  
#define SCORE_Q_PARAM_SIZE2           3  
#define SCORE_GROUP_SIZE            17  
#define SCORE_COMMON_PARAM_SIZE      2  
#define SCORE_FOUND_PARAM_SIZE      10  
#define SPEED_PARAM_SIZE            20

enum CalcScoreTypeEnum
{
   BRANCH1         = 0,
   BRANCH2         = 1,
   ACCEL_BRANCH1   = 2,
   ACCEL_BRANCH2   = 3,
   ACCEL_QUICK     = 4,
//   LATENT_BRANCH1  = 5,
//   LATENT_BRANCH2  = 6,
};

struct CalcScoreType
{
   CalcScoreTypeEnum  type;
   char              *name; 
};
const CalcScoreType calcScoreTypes []= 
{
   { BRANCH1      , "BRANCH1"       } ,
   { BRANCH2      , "BRANCH2"       } ,
   { ACCEL_BRANCH1, "ACCEL_BRANCH1" } ,
   { ACCEL_BRANCH2, "ACCEL_BRANCH2" } ,
   { ACCEL_QUICK  , "ACCEL_QUICK"   } ,
};
const int NUM_CALC_SCORE_TYPES = sizeof(calcScoreTypes) / sizeof(calcScoreTypes[0]);


extern int g_k_score_pg_q       [NUM_CALC_SCORE_TYPES][SCORE_PG_Q_PARAM_SIZE1 ][SCORE_PG_Q_PARAM_SIZE2];
extern int g_k_score_pg         [NUM_CALC_SCORE_TYPES][SCORE_PG_PARAM_SIZE1   ][SCORE_PG_PARAM_SIZE2  ];
extern int g_k_score            [NUM_CALC_SCORE_TYPES][SCORE_GROUP_SIZE];
// common score coefficients
extern int g_k_score_common     [NUM_CALC_SCORE_TYPES][SCORE_COMMON_PARAM_SIZE];
// quality bounds for score coefficients 
extern int g_k_score_q_bounds   [NUM_CALC_SCORE_TYPES][SCORE_Q_PARAM_SIZE1  - 1];   
// minPG bounds for score coefficients 
extern int g_k_score_pg_bounds  [NUM_CALC_SCORE_TYPES][SCORE_PG_PARAM_SIZE1 - 1];
// score coefficients for probe unreliable found pair
extern int g_k_score_up_f_p     [NUM_CALC_SCORE_TYPES][SCORE_FOUND_PARAM_SIZE  ];
// score coefficients for gallery unreliable found pair
extern int g_k_score_up_f_g     [NUM_CALC_SCORE_TYPES][SCORE_FOUND_PARAM_SIZE  ];

int calculateScore(const ScoreParameters &param, MinData minDataP[MAX_MINUTIAE], MinData minDataG[MAX_MINUTIAE], 
                   const int k_score_pg_q          [NUM_CALC_SCORE_TYPES][SCORE_PG_Q_PARAM_SIZE1][SCORE_PG_Q_PARAM_SIZE2], 
                   const int k_score_pg            [NUM_CALC_SCORE_TYPES][SCORE_PG_PARAM_SIZE1  ][SCORE_PG_PARAM_SIZE2  ],
                   const int k_score               [NUM_CALC_SCORE_TYPES][SCORE_GROUP_SIZE       ],
                   const int k_score_common        [NUM_CALC_SCORE_TYPES][SCORE_COMMON_PARAM_SIZE],
                   const int k_score_minPG_bounds  [NUM_CALC_SCORE_TYPES][SCORE_PG_PARAM_SIZE1- 1],
                   const int k_score_minQ_bounds   [NUM_CALC_SCORE_TYPES][SCORE_Q_PARAM_SIZE1 - 1],
                   const int k_foundP              [NUM_CALC_SCORE_TYPES][SCORE_FOUND_PARAM_SIZE ], 
                   const int k_foundG              [NUM_CALC_SCORE_TYPES][SCORE_FOUND_PARAM_SIZE ]);

#pragma pack(pop)
} //namespace accelMatch{

#endif // SCORE100_H_
