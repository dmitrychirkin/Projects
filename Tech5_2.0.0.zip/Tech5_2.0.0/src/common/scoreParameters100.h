/*
   scoreParameters.h - declare the parameters, those are used in score calculation
*/
#ifndef  SCORE_PARAMETERS_H_
#define  SCORE_PARAMETERS_H_

#include <string.h>

#include "coreSdk.h"
#include "accelAdjust.h"


namespace accelMatch{
#pragma pack(push,_CORE_TIGHT)

/*
   NOTE: unreliable pair - a close pair of minutias, with opposite direction
*/
enum FOUND_STATUS : BYTE
{
   EXCLUDED                      =    0,   // excluded
   FOUND_FIRST                   =    1,   // found in first group
   FOUND_MAIN                    =    2,   // found in main group, but not in first group
   FOUND                         =    3,   // found, but not in first or main group
   NOT_FOUND                     =    4,   // not found
};

// status of unreliable pairs - pair of close minutias, with opposite direction
enum UnreliablePairStatus : BYTE
{
   NOT_UNRELIABLE_PAIR           = 0,   // minutiae is not belong to any unreliable pair 
   FOUND_UNRELIABLE_PAIR         = 1,   // minutiae is found
   NOT_FOUND_UNRELIABLE_PAIR     = 2,   // minutiae is not found
   EXCLUDED_UNRELIABLE_PAIR      = 3,   // minutiae is excluded
};


struct P_PACKED_1 MinData
{
   FOUND_STATUS         m_foundStatus;         // true if minutae was found  
   UnreliablePairStatus m_unreliablePairStatus; // status of unreliable minutiae pair
   BYTE                 m_unreliableSize;       // unreliable pair size (distance between minutiae in pair)
   BYTE                 m_unreliableRc;         // unreliable pair ridge count (rc between minutiae in pair)
   BYTE                 m_probability;          // minutiae probability

   MinData()
   {
      clear();
   }
   void clear()
   {
      memset (this, 0, sizeof(MinData));
   }
};
#ifdef ADJUST
struct P_PACKED_1 MinDataPacked
{
   BYTE  m_foundStatus          : 2;
   BYTE  m_probability          : 6;        
   BYTE  m_unreliablePairStatus : 2; 
   BYTE  m_unreliableSize       : 3;
   BYTE  m_unreliableRc         : 3;

   MinDataPacked()
   {
      clear();
   }
   void clear()
   {
      memset (this, 0, sizeof(MinDataPacked));
   }
   MinDataPacked& operator= (const MinData &data)
   {
      assert(data.m_foundStatus == FOUND_FIRST || data.m_foundStatus == FOUND_MAIN || data.m_foundStatus == FOUND || data.m_foundStatus == NOT_FOUND);
      assert(data.m_unreliablePairStatus < 4 && data.m_probability < 64 && data.m_unreliableRc < 8 && data.m_unreliableSize < 40);
      FOUND_STATUS foundStatus = (FOUND_STATUS)(data.m_foundStatus - 1);
      int          size        = data.m_unreliableSize / 5;
      this->m_foundStatus         = foundStatus;
      this->m_unreliableSize       = size      ;

      this->m_unreliablePairStatus = data.m_unreliablePairStatus;
      this->m_probability          = data.m_probability         ;
      this->m_unreliableRc         = data.m_unreliableRc        ;
      return *this;
   }

};
#endif

//#define MAX_UNRELIABLE_PAIR         (MAX_MINUTIAE / 2)
#define MAX_UNRELIABLE_PAIR_DIST    39
#define MAX_UNRELIABLE_PAIR_RC      5
//
//struct P_PACKED_1 UnreliablePair
//{
//   BYTE   m_probability;       // minutiae probability
//   BYTE   m_dist       ;       // distance between minutiae
//   BYTE   m_rc         ;       // ridge count between minutiae  
//};

struct P_PACKED_1 SingularData
{
   BYTE m_numDeltaP;
   BYTE m_numDeltaG;
   BYTE m_xcP, m_ycP;
   BYTE m_xcG, m_ycG;
   short m_angle;
   BYTE m_deltaP_x[3];
   BYTE m_deltaP_y[3];
   //BYTE m_deltaP_a[3];
   //BYTE m_deltaP_p[3];
   BYTE m_deltaP_scaleX[3];
   BYTE m_deltaP_scaleY[3];
   BYTE  m_deltaP_exclude[3];
   BYTE m_deltaG_x[3];
   BYTE m_deltaG_y[3];
   //BYTE m_deltaG_a[3];
   //BYTE m_deltaG_p[3];
   //BYTE m_deltaG_scaleX[3];
   //BYTE m_deltaG_scaleY[3];
   BYTE  m_deltaG_exclude[3];
   BYTE m_numCoreP;
   BYTE m_numCoreG;
   BYTE m_coreP_x[3];
   BYTE m_coreP_y[3];
   //BYTE m_coreP_a[3];
   BYTE m_coreP_scaleX[3];
   BYTE m_coreP_scaleY[3];
   //BYTE m_coreP_p[3];
   //BYTE m_coreP_t[3];
   BYTE m_coreP_exclude[3];
   BYTE m_coreG_x[3];
   BYTE m_coreG_y[3];
   BYTE m_coreG_a[3];
   //BYTE m_coreG_scaleX[3];
   //BYTE m_coreG_scaleY[3];
   //BYTE  m_coreG_p[3];
   BYTE m_coreG_t[3];
   BYTE m_coreG_exclude[3];
   BYTE m_centreScaleX;
   BYTE m_centreScaleY;
   BYTE m_corePR_x[3];
   BYTE m_corePR_y[3];
   BYTE m_corePR_a[3];
   BYTE m_deltaPR_x[3];
   BYTE m_deltaPR_y[3];
   //short m_deltaPR_a[3];
   SingularData() 
   {
      clear();
   }
   SingularData (const SingularData& data)
   {
      *this = data;
   }

   void clear ()
   {
      memset (this, 0, sizeof(SingularData));
   }
   SingularData& operator= (const SingularData& param)
   {
      memcpy (this, &param, sizeof(SingularData));
      return *this;
   }

};

struct P_PACKED_1 ScoreParameters
{
   BYTE   calcScoreType;
   BYTE   m_qualityP;
   BYTE   m_numFound; 
   BYTE   m_qualityG;

   BYTE   m_distErrR              [3]; // distance between minutiae error with taking scale into account
   BYTE   m_minRelAngleErr        [3]; // minutiae relative angle error (its same- with or without taking scale into account )
   BYTE   m_angleErr              [3]; // angle from minutiae to minutiae error
   BYTE   m_angleErr1             [3]; // angle from minutiae to minutiae error


   BYTE   m_relAngleErr           [3]; 
   WORD   m_topologySim           [3];
   BYTE   m_numExcludedP;
   BYTE   m_numExcludedG;
   BYTE   m_numNestP;
   BYTE   m_numNestG;


   //BYTE m_incompatibleSingular;
   //BYTE m_incompatibleSingularMinQ;

   //BYTE  m_numFlowError;
   //BYTE  m_flowAverangeErr;
   //short m_transitionDif[3];
   //BYTE m_numMissDeltas;
   //BYTE m_numMissCores;


   ScoreParameters() 
   {
      clear();
   }
   ScoreParameters (const ScoreParameters& param)
   {
      *this = param;
   }

   void clear ()
   {
      memset (this, 0, sizeof(ScoreParameters));
   }
   ScoreParameters& operator= (const ScoreParameters& param)
   {
      memcpy (this, &param, sizeof(ScoreParameters));
      return *this;
   }

};
#ifdef ADJUST
#define MAX_SCORE_PARAM_GROUPS   20

struct P_PACKED_1 ScoreParametersEx
{
   int             score   ;
   int             numGroup;
   ScoreParameters scoreParam   [MAX_SCORE_PARAM_GROUPS];
   MinData         minDataP     [MAX_SCORE_PARAM_GROUPS][MAX_MINUTIAE];
   MinData         minDataG     [MAX_SCORE_PARAM_GROUPS][MAX_MINUTIAE];

   ScoreParametersEx()
   {
      memset(this, 0, sizeof(ScoreParametersEx));
   }
};

struct P_PACKED_1 AccelScoreParamEx
{
   int             numGroup;
   AccelScoreParam scoreParam   [MAX_SCORE_PARAM_GROUPS];

   AccelScoreParamEx()
   {
      memset(this, 0, sizeof(AccelScoreParamEx));
   }
};


#endif // ADJUST
#pragma pack (pop)
} //namespace accelMatch{

#endif // SCORE_PARAMETERS_H_