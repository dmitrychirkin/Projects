#ifndef ADJUST_PARAM_H
#define ADJUST_PARAM_H

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)


static int g_adjustParam[] = 
{
   12,             // 0-  maximum minutiae quality, when there is no penalty if minutiae is not found
   12,             // 1 - angle tolerance for check that minutiae belong to right quadrant
   10,             // 2 - pairs that have similarity more than this threshold after accelerator matching, will be compared by matcher_2nd
};

#pragma pack(pop)
} // namespace accelMatch{

#endif // ADJUST_PARAM_H
