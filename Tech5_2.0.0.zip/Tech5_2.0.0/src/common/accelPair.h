#ifndef ACCEL_PAIR_H_
#define ACCEL_PAIR_H_


#include <assert.h>
#define _USE_MATH_DEFINES
#include <math.h>
#include "mathem100.h"
#include "accel.h"
#include "accelTables.h"


namespace accelMatch{
#pragma pack(push, _CORE_PACKING)

#define GROUP_ANGLE_TOL                7   // tolerance for angle difference of angles inside group 


struct AccelPair
{
   short			   *m_np;
   short			   *m_ng;        
   unsigned int   m_size;               // total number of items (including eliminated) 
   BYTE			   m_num;                // number of real items
   bool			   m_around180;
   int			   m_angle;
   int			   m_xcP;
   int			   m_ycP;
   int			   m_xcG;
   int			   m_ycG;
   int			   m_lastCalc;
   unsigned int	m_maxSize;
   
   MinutiaeData   *m_minP;
   MinutiaeData   *m_minG;
   AccelTables    *m_accelTables;
   BYTE           *m_curDistToleranceTable;

   
   AccelPair ()
   {
      m_np   = 0;
      m_ng   = 0;
      clear();
      m_minP = NULL;
      m_minG = NULL;
   }
   ~AccelPair()
   {
      if (m_np		) delete [] m_np  , m_np  = NULL;
      if (m_ng		) delete [] m_ng  , m_ng  = NULL;
   }

   bool init (unsigned int size = MAX_ACCEL_MIN)
   {
      return alloc (size);
   }

   AccelPair& operator=(const AccelPair &pair)
   {
      m_size            = pair.m_size; 
      m_num             = pair.m_num;            
      m_around180       = pair.m_around180;
      m_angle           = pair.m_angle;
      m_xcP             = pair.m_xcP;
      m_ycP             = pair.m_ycP;
      m_xcG             = pair.m_xcG;
      m_ycG             = pair.m_ycG;
      m_minP            = pair.m_minP;
      m_minG            = pair.m_minG;
      m_lastCalc        = pair.m_lastCalc;
      m_maxSize         = pair.m_maxSize;

      for (unsigned int i = 0; i < m_size; i++)
      {
         m_np  [i]  = pair.m_np  [i];
         m_ng  [i]  = pair.m_ng  [i];
      }
      return *this;
   }
   AccelPair& operator+=(const AccelPair &g)
   {
      int num = g.m_size;
      for(int i = 0; i < num; i++)
      {
         if (g.m_np[i] == -1)
            continue;
         addWithCheck(g.m_np[i], g.m_ng[i]);
      }
      return *this;
   }

   void clear()
   {
      m_size         = 0;
      m_num          = 0;
      m_around180    = 0;
      m_angle        = 0;
      m_lastCalc     = 0;
      m_xcP = m_ycP = m_xcG = m_ycG = 0;
   }
	void setDistToleranceTable(int k)
	{
		m_curDistToleranceTable = m_accelTables->getDistToleranceTable(k);
	}
	BYTE getDistTolerance(unsigned int dDist)
	{
		return m_curDistToleranceTable[dDist];
//      return  20 + dDist / 100 + dDist * dDist / 10000;
	}

   void init (MinutiaeData *minP, MinutiaeData *minG, AccelTables *accelTables, int k)
   {
      m_minP = minP;
      m_minG = minG;
      m_accelTables = accelTables; 
		setDistToleranceTable (k);
   }
   bool compDists(unsigned int dist1, unsigned int dist2)
   {
      return abs((int)dist1 - (int)dist2) <= getDistTolerance (minAB(dist1, dist2));
   }

   bool alloc(unsigned int size)
   {
      m_maxSize = size;
      m_np   = new short [size];
      m_ng   = new short [size];
      if (!m_np || !m_ng)
         return false;
      memset (m_np, 0, sizeof(m_np[0]) * size);
      memset (m_ng, 0, sizeof(m_ng[0]) * size);
      return true;
   }
   bool canAdd(int np, int ng)
   {
      for(unsigned int i = 0; i < m_size; i++)
      {
         if ((m_np[i] == np) || (m_ng[i] == ng))
            return false;
      }
      return true;
   }
   bool addWithCheck(int np, int ng)
   {
      if (!canAdd(np,ng))
         return false;
      return add(np, ng);
   }
   bool add(int np, int ng)
   {
      if   (!m_size) return addFirst(np, ng);
      else           return addNext (np, ng);    
   }

   bool addNext(int np, int ng)
   {
      assert (m_size < m_maxSize);
      //if (m_size >= m_maxSize)
      //   return false;
      m_np[m_size] = np;
      m_ng[m_size] = ng;
      m_size++;
      m_num++;

      return true;
   }
   bool addFirst(int np, int ng)
   {
      assert (!m_size);
      addNext( np, ng);
      m_angle = normQuarterAngle360(m_minG[ng].a - m_minP[np].a);
      if (abs(m_angle - 45) <= 22)  // around 180
         m_around180 = true;
      m_xcP = m_minP[np].x;
      m_ycP = m_minP[np].y;
      m_xcG = m_minG[ng].x;
      m_ycG = m_minG[ng].y;

      return true;
   }

   void delPair(int i)
   {
      m_np[i] = -1;
      m_num--;
   }
   bool findP(int np)
   {
      for(unsigned int i = 0; i < m_size; i++)
      {
         if (m_np[i] == np)
            return true;
      }
      return false;
   }
   bool findG(int ng)
   {
      for(unsigned int i = 0; i < m_size; i++)
      {
         if (m_ng[i] == ng)
            return true;
      }
      return false;
   }
   bool find(int np, int ng)
   {
      for(unsigned int i = 0; i < m_size; i++)
      {
         if (m_np[i] != np)
            continue;
         return (m_ng[i] == ng);
      }
      return false;
   }

   // recalculate angle rotation
   void recalcData ()
   {
      if (m_num < 2 || m_lastCalc == m_num) 
         return;
      int np = 0, ng = 0, count = 0;
      m_xcP = m_ycP = m_xcG = m_ycG = 0;
      for(unsigned int i = 0; i < m_size; i++)
      {
         np = m_np[i];
         ng = m_ng[i];
         if ( np == -1 ) 
            continue;
         m_xcP += m_minP[np].x;
         m_ycP += m_minP[np].y;
         m_xcG += m_minG[ng].x;
         m_ycG += m_minG[ng].y;
         count++;
      }
      if (!count)
         return;
      m_xcP /= count;
      m_ycP /= count;
      m_xcG /= count;
      m_ycG /= count;

		int distP= 0, distG = 0;
      int difAngle = 0, angP = 0, angG = 0;
      int dx = 0, dy = 0;
      int sumAngle = 0;
      int sumDistP = 0, sumDistG = 0;
//		int sumRadDif = 0;
      for(unsigned int i = 0; i < m_size; i++)
      {
         np = m_np[i];
         ng = m_ng[i];
         if ( np == -1 ) 
            continue;
         dx = m_minP[np].x - m_xcP;
         dy = m_minP[np].y - m_ycP;
         distP = dist(dx, dy);
         if (distP < 20)
            continue;
         angP = atan (dx, dy) / 4;
         dx = m_minG[ng].x - m_xcG;
         dy = m_minG[ng].y - m_ycG;
         distG = dist(dx, dy);
         sumDistP += distP;
         sumDistG += distG;
         angG = atan (dx, dy) / 4;
         difAngle = normQuarterAngle(angG - angP);
         if (m_around180)
            difAngle += (difAngle > 0 ? -1 : 1) * 45;
         sumAngle += difAngle * distP;
			count++;
      }
      if (!sumDistP)
         return;
      m_angle = sumAngle / sumDistP;
      m_angle = normQuarterAngle(m_angle);
      if (m_around180)
         m_angle = normQuarterAngle(m_angle - 45);
		m_angle = normQuarterAngle360(m_angle);
      m_lastCalc = m_num;
   }

   bool isCompatible (int np, int ng, bool lightCheck = false, bool *takenP = NULL, bool *takenG = NULL)
   {
      if (!m_num)             // any pair compatible with an empty group
         return true;         
      if (!checkMinAngles(np, ng)) 
         return false;
      int dx = m_minP[np].x - m_xcP;
      int dy = m_minP[np].y - m_ycP;
      unsigned int distP = dist(dx, dy);
      int angleP = atan (dx, dy) / 4;
      dx = m_minG[ng].x - m_xcG;
      dy = m_minG[ng].y - m_ycG;
      unsigned int distG = dist(dx, dy);
      if (!compDists (distP, distG))
         return false;
      int angleG = atan (dx, dy) / 4;
      int minDist = minAB(distP, distG);
		if (minDist > 20 &&  m_accelTables->getAngleDif (angleP, angleG, m_angle) > GROUP_ANGLE_TOL)
         return false;
      if (lightCheck)
         return true;
      unsigned int numErr = 0, errIndex = -1;
      for(unsigned int i = m_lastCalc ? 0 : 1; i < m_size; i++)
      {
         if ( m_np[i] == -1 ) 
            continue;
         distP = dist(m_minP[np].x - m_minP[m_np[i]].x, m_minP[np].y - m_minP[m_np[i]].y);
         distG = dist(m_minG[ng].x - m_minG[m_ng[i]].x, m_minG[ng].y - m_minG[m_ng[i]].y);
         if (!compDists (distP, distG))
         {
            if (numErr >= 1)
               return false;
            numErr++;
            errIndex = i;
         }
      }
      if (!numErr)
         return true;
      // there is a one problem minutiae. Compare it with new one and choose the better one
      if (isNewPairBetter(np, ng, errIndex))
      {
         if (takenP) takenP[np] = true, takenP[m_np[errIndex]] = false;
         if (takenG) takenG[ng] = true, takenG[m_ng[errIndex]] = false;
         m_np[errIndex] = np;
         m_ng[errIndex] = ng;
         m_lastCalc = 0;
         return false;    // return false, because no need to add new pair. It's already added!!!
      }
      return false;
   }

   // compare two pairs - old and new and choose the beteer one
   bool isNewPairBetter(int newP, int newG, unsigned int oldIndex)
   {
      return (calcSumErr(oldIndex, newP, newG) < calcSumErr(oldIndex, m_np[oldIndex], m_ng[oldIndex]));
   }

   int calcSumErr(unsigned int missIndex, int np, int ng)
   {
      int distP = 0, distG = 0, minDist = 0, maxDist = 0, err = 0;
      for(unsigned int i = 0; i < m_size; i++)
      {
         if ( m_np[i] == -1 || i == missIndex) 
            continue;
         distP = dist(m_minP[np].x - m_minP[m_np[i]].x, m_minP[np].y - m_minP[m_np[i]].y);
         distG = dist(m_minG[ng].x - m_minG[m_ng[i]].x, m_minG[ng].y - m_minG[m_ng[i]].y);
         minDist = minAB(distP, distG);
         maxDist = maxAB(distP, distG);
         err += maxDist * 256 / (minDist ? minDist : 1);
      }
      return err;
   }

   bool checkMinAngles (int np, int ng)
   {

		return (m_accelTables->getAngleDif (m_minP[np].a, m_minG[ng].a, m_angle) < GROUP_ANGLE_TOL * 2);
   }
   bool isFull()
   {
      return (m_size >= m_maxSize);
   }
};


#pragma pack(pop)
} // namespace accelMatch{


#endif   // ACCEL_PAIR_H_
