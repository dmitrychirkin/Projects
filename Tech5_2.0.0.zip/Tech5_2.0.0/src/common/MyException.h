#ifndef MY_EXCEPTION_H_
#define MY_EXCEPTION_H_

#include <string.h>

#define MSG_MAX_LEN  1024
#pragma pack(push, _CORE_PACKING)

class MyException
{
   int  m_code;
   char m_msg     [MSG_MAX_LEN + 1];
   char m_location[MSG_MAX_LEN + 1];

public:
   MyException()
   {
      clean();
   }
   void clean()
   {
      m_code        = 0;
      m_msg     [0] = 0;
      m_location[0] = 0;
   }
   MyException(int code)
   {
      clean();
      setCode     (code    );
   }
   MyException(int code, char *msg)
   {
      clean();
      setCode     (code    );
      setMsg      (msg     );
   }
   MyException(int code, char *msg, char *location)
   {
      clean();
      setCode     (code    );
      setMsg      (msg     );
      setLocation (location);
   }
   void setCode(int code)
   {
      m_code = code;
   }
   void setMsg(char *msg)
   {
      strncpy (m_msg, msg, MSG_MAX_LEN);
   }
   void setLocation(char *location)
   {
      strncpy (m_location, location, MSG_MAX_LEN);
   }
};
#pragma pack(pop)

#endif // MY_EXCEPTION_H_