#include <string.h>

#include "iniFile.h"

#pragma pack(push, _CORE_PACKING)

//#pragma warning(disable : 4996)

 
IniFile::IniFile ()
{
	m_f = NULL;
	*m_buffer = 0;
	*m_key = 0;
}

IniFile::~IniFile()
{
	close();
}

bool IniFile::openOrCreate(const char *name)
{
	if (!name || !strlen(name))
		return false;
	m_f = fopen(name, "r+");
	if (!m_f) m_f = fopen(name, "w+");  // file don't exist yet
	if (!m_f) return false;
	return true;
}

bool IniFile::create(const char *name)
{
	if (!name || !strlen(name))
		return false;
	m_f = fopen(name, "w");
	if (!m_f) return false;
	return true;
}

bool IniFile::open(const char *name)
{
	if (!name || !strlen(name))
		return false;
	m_f = fopen(name, "r");
	if (!m_f) return false;
	return true;
}

void IniFile::close()
{
	if (!m_f) return;
	fclose(m_f);
	m_f = NULL;
}

// get float value
int IniFile::getValue (const char *keyName, float *var, float defaultVal) 
{ 
	double d = 0.0;
	int result = getNumValue(keyName, &d, (double)defaultVal, atof);
	*var = (float)d;
    return result;
}
// get string value
int IniFile::getValue (const char *keyName, char *var, int *size,
							const char *defaultVal = NULL) 
{
	if (!m_f) return INI_OPEN;

	char *s = findKeyString (keyName);
	if (!s)	
		return safeCopyString (var, size, defaultVal);
	return safeCopyString (var, size, s);
}
/*
	Find in INI file the string in format:
	keyName=keyValue 
	and returns 'keyValue' if corresponded string is found and
	NULL  otherwise
*/
char* IniFile::findKeyString (const char *keyName)
{
	char *s = NULL;
	fseek(m_f, 0, SEEK_SET);
	strncpy (m_key, keyName, MAX_STRING_LEN);
	trim(m_key);
	while (fgets(m_buffer, MAX_STRING_LEN, m_f))
	{
	    trim(m_buffer);
		if( m_buffer[strlen(m_buffer) - 1] == '\n')
			m_buffer[strlen(m_buffer) - 1] = 0;	
		if (!_strnicmp(m_buffer, m_key, strlen(m_key)))
		{
			if (!(s = strchr(m_buffer, '='))) continue;
			return trim(s+ 1);
		}
	} 
	return NULL;
}
/////////////////////////////////////////////////////////////////////////////////
// AUXILARY FUNCTIONS
/////////////////////////////////////////////////////////////////////////////////
char* IniFile::trim(char *s, TRIM_MODE mode)
{
	if (mode == TRIM_LEFT || mode == TRIM_BOTH)
		while(s[0] == ' ') s++; 

	if (mode == TRIM_RIGHT || mode == TRIM_BOTH)
		while (s[strlen(s) - 1] == ' ')
			s[strlen(s) - 1] = 0;

	return s;
}

/*
	Put the size of 'src' string into '*dstSize' 
	If  the size of 'dst' ('dstSize') is enought then copies 'src' string into 'dst'
	and returns INI_OK, otherwise return INI_MORE_DATA
*/
int IniFile::safeCopyString(char *dst, int *dstSize, const char* src)
{
//	*dstSize = 0;
	*dst     = 0;
	if (!src) return INI_OK;

	int srcSize = (int)strlen(src) + 1;
	if (srcSize > *dstSize || !dst)
	{
		*dstSize = srcSize;
		return INI_MORE_DATA;
	}
	strcpy(dst, src);
	*dstSize = srcSize;

	return INI_OK;
}

bool checkBool(const char *s)
{
	return (!_strnicmp(s, "true", MAX_STRING_LEN)); 
}

int IniFile::getValue (const char *keyName, long long *var, long long defaultVal) 
{
	if (!m_f) return INI_OPEN;
	*var = defaultVal;
	char *s = findKeyString (keyName);
	if (!s) return INI_NOT_FOUND;
#ifdef _WINDOWS
	*var = (long long)_atoi64 (s);
#else
   *var = (long long) strtoull(s, 0, 10);
#endif

	return INI_OK;	
}

#pragma pack(pop)
