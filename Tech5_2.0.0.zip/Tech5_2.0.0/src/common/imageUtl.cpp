/*****************************************************************************
	ImageUtl.cpp - implementstion of utilites for work with images

   
*******************************************************************************/
#include <string.h>
#include <malloc.h>
#include "ImageUtl.h"
#include <math.h>

/*
 flip image horizontally
*/ 
void flipH (const unsigned char* src, unsigned char* dst, unsigned int width, unsigned int height)
{
	unsigned int i = 0;
   unsigned char* ps = (unsigned char*)(src + (height - 1) * width);
   unsigned char* pd = (unsigned char*)dst;

	for (; i < height; i++)
   {
		memcpy (pd, ps, width);
      pd += width;
      ps -= width;
   }
}

/*
 flip image vertically
*/ 
void flipV (const unsigned char* src, unsigned char* dst, unsigned int width, unsigned int height)
{
	unsigned int i = 0, j = 0;
   unsigned char* ps = (unsigned char*)src;
   unsigned char* pd = (unsigned char*)dst;
	for (; j < height; j++)
	{
		for (i = 0; i < width; i++)
			pd[i] = ps[width - i - 1];

      ps += width;
      pd += width;
	}
}

/*
 invert the image
*/ 
void invert (unsigned char* image, unsigned int width, unsigned int height)
{
	int i = 0;
	int size = width * height;
   unsigned char *p = image;
	for (i = 0; i < size; i++, p++)
		*p = 255 - *p;
 }
// rotate image on 90 degree clockwise or anticlockwise
// after conversion width and height have a new value
void rotate90(const unsigned char* src, unsigned char* dst, unsigned int *width,
			  unsigned int *height, bool clockwise)
{
   unsigned char* pd = (unsigned char*)dst;
	unsigned int i = 0, j = 0;
	unsigned int srcW = *width,  srcH = *height;  // old size
	unsigned int dstW = *height, dstH = *width;   // new size
	*width = dstW, *height = dstH;               
	
	if (clockwise)
		for (j = 0; j < dstH; j++)
		{
			for (i = 0; i < dstW; i++)
				pd[i] = src[(srcH - 1 - i) * srcW + j];
			pd += dstW;
		}
	else
		for (j = 0; j < dstH; j++)
		{
			for (i = 0; i < dstW; i++)
				pd[i] = src[(i + 1) * srcW - j - 1];
			pd += dstW;
		}
}

/*
	transform image from 32 to 8 bpp
	Parameters:
	image    (input) - pointer to source image
	width    (input)  - source image width (should be arranged on 4!!!)
	height   (input)  - source image height
*/
void trans32To8Bpp(BYTE *image, int width, int height)
{
	int i = 0, len = width * height;
	for(i = 0;  i < len; i++)
		image[i] = image[i << 2];
}



/* 
	cut part of the source image  and put it to the destination image
	src - source image
	srcWidth, srcHeight - size of source image 
	dst - destination image that is part of the source image
	x0, y0 width, height - define size and location of the cutting area 
	NOTE: 
		all X dimensions (x0, width srcWidth) in bytes (not in pixels)
		all Y dimensions (y0, height srcHeight) in pixels 
*/
bool cut (const unsigned char* src, unsigned int srcWidth, unsigned int srcHeight,
				unsigned int x0, unsigned int y0, unsigned int width, 
				unsigned int height, unsigned char* dst)
{
	int shift = y0 * srcWidth + x0;    
	unsigned char* pSrc = (unsigned char*)(src + shift);
	unsigned char* pDst = dst;
	unsigned int i = 0;

	if((x0 + width) > srcWidth || (y0 + height) > srcHeight) return false;
	
	
	/* copy image */
	for(i = 0; i < height; i++ )
	{
		memcpy (pDst, pSrc, width);		
		pSrc += srcWidth;
		pDst += width;
	}

	return true;
}


/*******************************************************************************************
  find finger location
*******************************************************************************************/
bool getDifferences (const unsigned char *image, unsigned int width, 
					 unsigned int height, int **dif)
{
	unsigned int x1 = 0, y1 = 0;
	int j = 0;
	unsigned int y = 0, x = 0;
	unsigned char *p = (unsigned char*)image, c = 0;
	int max = 0, min = 0;
	unsigned int width1  = width >> 2;
	unsigned int height1 = height >> 2;
	unsigned int height_ = height1 << 2;
	unsigned int width_  = width1 << 2;
	unsigned int rowLen  = ((width + 3) >> 2) << 2;

	int *dif1 = (int*)malloc (width1 * sizeof(int));
	if (!dif1) return false;
	memset (dif1, 0, width1 * sizeof(int));

	/*
	  go throughout image and find max brightness different and save these 
	  differences in dif array
	*/ 
	for( y = 0, y1 = 0; y < height_; y += 4, y1++, p += rowLen * 4) 
	{
		memset(dif[y1], 0, width1 * sizeof(int));
		for (x = 0, x1 = 0; x < width_; x += 4, x1++) 
		{
			max = 0; min = 255;
			for( j = -12; j < 12; j += 3 ) 
			{
				if (x + j >= 0 && x + j < width_) 
				{
					c = *(p + x + j);
					if( c > max ) max = c;
					if( c < min ) min = c;
				}
			}
			for( j = -10; j <= 10; j += 2 ) 
			{
				if( y + j >= 0 && y + j < height_) 
				{
					c = *(p + x + j * rowLen);
					if( c > max ) max = c;
					if( c < min ) min = c;
				}
			}
			dif1[x1] = max - min;
//			dif[y1][x1] = dif1[x1];
		}
		for( x1 = 2; x1 < width1 - 2; x1++ ) 
		{
			dif[y1][x1] = (dif1[x1] * 4 + dif1[x1 - 1] * 2 + dif1[x1 + 1] * 2 + 
							dif1[x1 - 2] + dif1[x1 + 2]) / 10;
		}
		dif[y1][0] = dif[y1][1] = dif[y1][2]; 
		dif[y1][width1 - 1] = dif[y1][width1 - 2] = dif[y1][width1 - 3];

	}
	if (dif1) free(dif1);
	return true;
}

/*
	Allocate memory for 'findFinger' function
	Parameters:
	width, heght - source image size (input)
	dif, top, bottom, left, right, excludeX, excludeY - pointers to temporary buffers 
														for 'findFinger' function (output)
*/
bool findFingerAlloc(int ***dif, int **top, int **bottom, int **left, int **right, 
					 int **excludeX, int **excludeY,  int width, int height)
{
	int i = 0;
	int width1  = width >> 2;
	int height1 = height >> 2;

	*dif	= (int**)  malloc  (height1 * sizeof(int));
	if (!*dif) return false;
	for(i = 0; i < height1; i++)
	{
		(*dif)[i]	= (int*)  malloc  (width1 *	sizeof(int));
		if (!(*dif)[i]) return false;
		memset((*dif)[i],  0, sizeof(int) * width1);
	}
	*top	  = (int*)  malloc  (width1  *	sizeof(int));
	*bottom	  = (int*)  malloc  (width1  * 	sizeof(int));
	*left	  = (int*)  malloc  (height1 *	sizeof(int));
	*right	  = (int*)  malloc  (height1 *	sizeof(int));
	*excludeX = (int*)  malloc  (height1 *	sizeof(int));
	*excludeY = (int*)  malloc  (width1 *	sizeof(int));

	return *top && *bottom && *left && *right && *excludeX && *excludeY;
}
/*
	Free memory, previously allocated by 'findFingerAlloc' function
	Parameters:
	width, heght - source image size (input)
	dif, top, bottom, left, right, excludeX, excludeY - pointers to temporary buffers 
														for 'findFinger' function (output)
*/
void findFingerFree(int ***dif, int **top, int **bottom, int **left, int **right, 
					 int **excludeX, int **excludeY, int width, int height)
{
	int i = 0;
	int height1 = height >> 2;
	if (*dif)
	{
		for(i = 0; i < height1; i++)
			if ((*dif)[i]) free((*dif)[i]);
		free (*dif);
	}
	if (*top)		free (*top);
	if (*bottom)	free (*bottom);
	if (*left)		free (*left);
	if (*right)		free (*right);
	if (*excludeX)  free (*excludeX);
	if (*excludeY)  free (*excludeY);
	*dif = NULL;
	*top = *bottom = *left = *right = *excludeX = *excludeY = NULL;
}

#define FAKE_BORDER_FIND_DEPTH    1    // depth of finding fake border process

void clearFakeBorder(int *left, int *right, int *top, int *bottom, int *excludeX, int *excludeY, int width, int height)
{
	int x = 0, y = 0, i = 0, j = 0;
	bool change = true;
	// remove the top/bottom border where no left/right border
	for (x = 0; x < width; x++ )
	{
		if (excludeY[x]) continue;
		change = true;
		if      (x < FAKE_BORDER_FIND_DEPTH)				i = 0;
		else if (x + FAKE_BORDER_FIND_DEPTH > width - 1)	i = width - 1 - FAKE_BORDER_FIND_DEPTH * 2;
		else												i = x - FAKE_BORDER_FIND_DEPTH;  
		for(j = 0; j <= FAKE_BORDER_FIND_DEPTH * 2; j++)
		{
			if (!excludeY[top[i + j]] && !excludeY[bottom[i + j]]) 
			{
				change = false;
				break;
			}
		}
		if (change)	excludeY[x] = 1;
	}
	// remove the left/right border where no top/bottom border
	for (y = 0; y < height; y++ )
	{
		if (excludeX[y]) continue;
		change = true;
		if      (y < FAKE_BORDER_FIND_DEPTH)				i = 0;
		else if (y + FAKE_BORDER_FIND_DEPTH > height - 1)	i = height - 1 - FAKE_BORDER_FIND_DEPTH * 2;
		else												i = y - FAKE_BORDER_FIND_DEPTH;  
		for(j = 0; j <= FAKE_BORDER_FIND_DEPTH * 2; j++)
		{
			if (!excludeX[left[i + j]] && !excludeX[right[i + j]]) 
			{
				change = false;
				break;
			}
		}
		if (change)	excludeX[y] = 1;
	}
}


void inflateArea (unsigned int *left, unsigned int *right, 
		  unsigned int *top, unsigned int *bottom, unsigned int x, unsigned int y)
{
	int dx = 0, dy = 0;
/*	dx = *right - *left - (((*right - *left) >> 2) << 2);
	dx >>= 1;
	dy = *bottom - *top - (((*bottom - *top) >> 2) << 2);
	dy >>= 1;
*/
	if (*top >= y + dy) *top  -= y + dy;
	else                *top   = 0;  
	*bottom += y - dy;
	if (*left >= x + dx) *left -= x + dx;
	else                 *left  = 0;
	*right  += x - dx;
}

#define DIF_ANALYSE_DEPTH    10    // depth of analyse of differences
#define DIF_ANALYSE_THR		 8     // threshold of differences for decision - there is fingerprint image here
#define DIF_ANALYSE_DEPTH1   20    // depth of analyse of differences
#define DIF_ANALYSE_THR1	 15    // threshold of differences for decision - there is fingerprint image here
/*
	The fucntion trying to find fingerprint image location
	image                        - point to source image bytes (input)
	                              It is supposed that image is get from BMP, so image rows is arranged on 4 bytes. 
	width, heght                  - source image size (input)
	Left, Right, Top, Bottom      - fingerprint image location (output)
	dif, top, bottom, left, right,
	excludeX, excludeY            - temporary buffers. These buffers should be allocate by 'findFingerAlloc' function
	                                before the first call of 'findFinger' and free by call of 'findFingerFree' 
*/
bool findFinger (const unsigned char *image, unsigned int width, 
				 unsigned int height, 
				 unsigned int *Left, unsigned int *Right, unsigned int *Top, 
				 unsigned int *Bottom, int *left, int *right, int *top, int *bottom, 
				 int **dif, int *excludeX, int *excludeY)
{
	int x = 0, y = 0, i = 0, j = 0, average = 0, count = 0;
	int max = 0, min = 0;
	int width1  = 0, height1 = 0;

	width1  = width >> 2;
	height1 = height >> 2;
	if (!image) return false;
	*Left = *Right = *Top = *Bottom = 0;
	
	if (!left || !right || !top || !bottom || !dif) 
      return false;
	
	/* get differences */
	if (!getDifferences (image, width, height, dif)) 
		return false;
		
	// find average value in dif array and subtract it from dif values 
	count = 0;
	average = 0;
	for (y = 0; y < height1; y++ )
	{
		for (x = 0; x < width1; x++) 
		{
			if( dif[y][x] > 10 ) 
			{
				average += dif[y][x]; 
				count++;
			}
		}
	}
	if (count) average = (average / count);
	for (y = 0; y < height1; y++ ) 
	{
		i = y * width1;
		for (x = 0; x < width1; x++) 
			dif[y][x] -= average;
	}
	// find maximum in dif array 
	max = 0;
	for (y = 0; y < height1; y++ ) 
	{
		for (x = 0; x < width1; x++)
			if( max < dif[y][x] ) 
				max = dif[y][x];
	}
	// if maximum <= 10 or average <= 10 then there is no fingerprint image 
	if (average <= 10)
		return true;

	// find minimum in dif array and consider all point where dif > 0.7 * min (min is always <= 0)
	// as points where can be a fingerprint image 
	min = 0;
	for (y = 0; y < height1; y++) 
	{
		for (x = 0; x < width1; x++) 
			if (min > dif[y][x]) 
				min = dif[y][x];
	}

	min = min * 7 / 10;
	max = max * 1000 / 1000;
	for (y = 0; y < height1; y++) 
	{
		i = y * width1;
		for (x = 0; x < width1; x++) 
		{
			if (dif[y][x] >= min && dif[y][x] <= max)	dif[y][x] = 1;
			else					dif[y][x] = 0;
		}
	}

	/* find left and right border */
	memset (left,	  0, height1 * sizeof(int));
	memset (right,    0, height1 * sizeof(int));
	memset (excludeX, 0, height1 * sizeof(int));
	for (y = 0; y < height1; y++ )
	{
		left[y] = width1 - 1; 
        for (x = 0; x <= width1 - DIF_ANALYSE_DEPTH; x++) 
		{
			if (!dif[y][x]) continue;
			count = 0;
			for (j  = x; j < x + DIF_ANALYSE_DEPTH; j++)
			{
				count += dif[y][j];
			}
			if (count >= DIF_ANALYSE_THR) 
			{
				left[y] = x + DIF_ANALYSE_DEPTH - count; 
				break;
			}
		}
		right[y] = left[y]; 
		for (x = width1 - DIF_ANALYSE_DEPTH; x > left[y]; x--) 
		{
			if (!dif[y][x + DIF_ANALYSE_DEPTH - 1]) continue;
			count = 0;
			for (j  = x; j < x + DIF_ANALYSE_DEPTH; j++)
			{
				count += dif[y][j];
			}
			if (count >= DIF_ANALYSE_THR) 
			{
				right[y] = x + count - 1; 
				break;
			}
		}
		/* if size of fingerprint image is < 40 (~2mm) then there is no fingerprint image in this column */
		if (right[y] - left[y] < 10) 
			excludeX[y] = 1;
	}
	/* find top and bottom border */
	memset (top,	  0, width1 * sizeof(int));
	memset (bottom,   0, width1 * sizeof(int));
	memset (excludeY, 0, width1 * sizeof(int));
	for (x = 0; x < width1; x++) 
	{
		top[x] = height1 - 1; 
		for (y = 0; y < height1 - DIF_ANALYSE_DEPTH; y++ ) 
		{
			if (!dif[y][x]) continue;
			count = 0;
			for (i  = y; i < y + DIF_ANALYSE_DEPTH; i++)
			{
				count += dif[i][x];
			}
			if (count >= DIF_ANALYSE_THR) 
			{
				top[x] = y + DIF_ANALYSE_DEPTH - count; 
				break;
			}
		}
		bottom[x] = top[x]; 
		for (y = height1 - DIF_ANALYSE_DEPTH; y > top[x]; y--) 
		{
			if (!dif[y + DIF_ANALYSE_DEPTH - 1][x]) continue;
			count = 0;
			for (i  = y; i < y + DIF_ANALYSE_DEPTH; i++)
			{
				count += dif[i][x];
			}
			if (count >= DIF_ANALYSE_THR) 
			{
				bottom[x] = y + count - 1; 
				break;
			}
		}
		/* if size of fingerprint image is < 40 (~2mm) then there is no fingerprint image in this column*/
		if (bottom[x] - top[x] < 10) 
			excludeY[x] = 1;
	}
	/* find Top and Botttom of whole image */
	*Top = height1, *Bottom = 0;
	for( x = 0; x < width1; x++ ) 
	{
		if(!excludeY[x]) 
		{
			if( (unsigned int)top[x]	< *Top )	*Top	= (unsigned int)top[x];
			if( (unsigned int)bottom[x]	> *Bottom )	*Bottom	= (unsigned int)bottom[x];
		}
	}
	/* find Left and Right of whole image */
	*Left = width1;
	*Right = 0;
	for (y = 0; y < height1; y++ ) 
	{
		if(!excludeX[y]) 
		{
			if ((unsigned int)left[y]	< *Left)	*Left	= (unsigned int)left[y];
			if ((unsigned int)right[y]	> *Right)	*Right	= (unsigned int)right[y];
		}
	}
	inflateArea (Left, Right, Top, Bottom, 5, 5);

	*Top	<<= 2;
	*Bottom	<<= 2;
	*Left	<<= 2;
	*Right	<<= 2;

	/* check final values */
	if (*Bottom > height)	*Bottom = height;
	if (*Right  > width)	*Right = width;
	if (*Bottom < *Top)		*Top = *Bottom;
	if (*Right	< *Left)	*Left = *Right;

	*Right  = *Left + (((*Right - *Left) >> 2) << 2);
	*Bottom = *Top  + (((*Bottom - *Top) >> 2) << 2);

	return true;
}

// cut 8 bpp image to be arranged on 4 bytes
// (newWidth = width / 4 * 4)
// memory for dstImage should be allocated by caller
// return the new width
int arrangeImageCut (int width, int height, const unsigned char *srcImage, const unsigned char *dstImage)
{
	unsigned char *dst = (unsigned char*)dstImage;
	unsigned char *src = (unsigned char*)srcImage;
	int newWidth = (width >> 2) << 2;  
	int row = 0;

	for(row = 0; row < height; row++)
	{
		memcpy (dst, src, newWidth);
		dst += newWidth;
		src += width;
	}
	return newWidth;
}

// aranged each row in image to be divided on 4 bytes
// (newWidth = (width + 3) / 4 * 4)
// memory for dstImage should be allocated by caller
// return the new width
int arrangeImage (int width, int height, const unsigned char *srcImage, const unsigned char *dstImage)
{
	unsigned char *dst = (unsigned char*)dstImage;
	unsigned char *src = (unsigned char*)srcImage;
	int newWidth = ((width + 3) >> 2) << 2;  
	int row = 0;

	for(row = 0; row < height; row++)
	{
		memcpy (dst, src, width);
		memset (dst + width, 0xff, newWidth - width);
		dst += newWidth;
		src += width;
	}
	return newWidth;
}

// change 8 bpp image to be arranged on 4 bytes
// (newWidth = (width + 3) / 4 * 4)
// and put it to the same buffer
// return the new width or 0 if an error happened 
// image buffer should be large enough for new image
int arrangeImage2 (int width, int height, unsigned char *image)
{
	int row = width;
	int rowLen = ((width + 3) >> 2) << 2;
	unsigned char *src = image;
	unsigned char *dst = image;
	unsigned char *temp = (unsigned char*)malloc(width * height);
	if (!temp) return false;
	memcpy(temp, image, width * height);
	src = temp;
	
	for(row = 0;  row < height; row++)
	{
		memcpy (dst, src, width);
		memset (dst + width, 0, rowLen - width);
		dst += rowLen;
		src += width;
	}
	if (temp) free (temp); 
	return rowLen;
}

// calculate histogram
void calcHistog(const unsigned char *image, unsigned int width, 
					unsigned int height, RECT rect, int hist[256])
{
   unsigned char *p = NULL;
   int x = 0, y = 0;
   for (; x < 256; x++)
	   hist[x] = 0;
   if ((unsigned int)rect.right  > width)  rect.right  = width;
   if ((unsigned int)rect.bottom > height) rect.bottom = height;
	
   p = (unsigned char*)image + rect.top * width;
   for (y = rect.top; y < rect.bottom; y++)
   {
      for (x = rect.left; x < rect.right; x++)
   	   hist[p[x]]++;
      p +=  width;
   }
}
#define MIN_BACKGROUND_BRIGHT      240
#define NORMALIZE_L_COEFF    0.01 
#define NORMALIZE_H_COEFF    0.01 
bool normalize (const unsigned char *image, unsigned int width, unsigned int height, 
                unsigned char *normImage)
{
   int i = 0, size = 0, reducedSize = 0, sum = 0;
   int thresholdL = 0, thresholdH = 0, low = 0, high = 0;
   RECT rect;
   int hist[256];
   float transK = 0.0;
   unsigned char *src = (unsigned char*)image;
   unsigned char *dst = normImage;

   if (!image || !normImage || !width || !height) 
      return false;

   size = width * height;
   memcpy (dst, src, size);
   // calulate histogram
   rect.top = rect.left = 0;
   rect.right = width;
   rect.bottom = height;
   calcHistog(src, width, height, rect, hist);
   
   // exclude clear background
   reducedSize = 0;
   for(i = 0; i < MIN_BACKGROUND_BRIGHT; i++)
      reducedSize += hist[i];

   // find the min and max bright of the image
   thresholdL = (int)(reducedSize * NORMALIZE_L_COEFF);
   thresholdH = (int)(reducedSize * NORMALIZE_H_COEFF);
   sum = 0;
   for(i = 0; i <= MIN_BACKGROUND_BRIGHT; i++)
   {
      sum += hist[i];
      if (sum > thresholdL)
      {
         low = i + 1;
         break;
      }
   }
   sum = 0;
   for(i = MIN_BACKGROUND_BRIGHT; i > low; i--)
   {
      sum += hist[i];
      if (sum > thresholdH)
      {
         high = i - 1;
         break;
      }
   }
   if (low >= high)
      return false;
   transK = (float)255.0 / (high - low);
//memcpy (dst, src, size);
   for(i = 0; i < size; i++)
   {
      if (*src < low) *dst = 0;
      else if (*src > high) *dst = 255;
      else
         *dst = (unsigned char)(transK * (*src - low ));
      src++;
      dst++;
   }

   return true;
}

/*
   return averange color of image bytes in given area
   parameters:
      image          - pointer to image bytes
      width, height  - image size
      x0, y0, w, h   - position of area
*/
unsigned char getAverangeColor(const unsigned char *image, int width, int height, int x0, int y0, int w, int h)
{
   int x = 0, y = 0, shift = 0;
   unsigned int sum = 0, count = 0;
   int xMax = x0 + w;
   int yMax = y0 + h;
   if (xMax > width || yMax > height)
      return 0;
   shift = y0 * width;
   for(y = y0; y < yMax; y++)
   {
      for(x = x0; x < xMax; x++)
      {
         sum += image[shift + x];
         count++;
      }
      shift += width;
   }
   return sum / count;
}
