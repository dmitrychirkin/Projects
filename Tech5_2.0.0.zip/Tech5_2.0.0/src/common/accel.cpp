#include <algorithm>
#include <functional>
#include <vector>

#include <assert.h>

#include "accelData.h"
#include "adjustParam.h"
#include "staticData100.h"
#include "mainAccel.h"

//using namespace LDS;

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)

#define MIN_FILL                 10       // minimum value of m_fill when accelerator can take part in full accelerator compare
#define MIN_FILL_LOW              3       // minimum value of m_fill_low when accelerator can take part in low byte of accelerator compare
#define MAX_NUM_FOR_ACCEL_CALC  128       // maximum number of minutiae that used for accel calculation in not full mode

//__int64 g_linkCount[16];
//__int64 g_numNests;
//__int64 g_fillCount[16];
//__int64 g_lowFillCount[8];
//__int64 g_highFillCount[8];

AccelTables  g_accelTables;

bool initAccelTables(AccelTables *&accelTables)
{
   bool init = true;
   #pragma omp critical 
   {
      init = g_accelTables.init();
   }
   accelTables = &g_accelTables;
   return init;
}


struct NestEx
{
   ESK::Sign	   *m_minutiae;
   int             m_num;           // number of minutiae   
   int             m_fill_high;     // number of minutiae in accelerator high byte 
   int             m_fill_low;      // number of minutiae in accelerator low byte
   int             m_fill_sort;     // special vaule that used for sorting by m_fill_low and m_fill_high
   int             m_quality;

   NestEx()
   {
      m_minutiae  = NULL;
      m_num       = -1;
      m_fill_high = -1;
      m_fill_low  = -1;
      m_fill_sort = -1;
      m_quality   = 0;
   }
   NestEx (ESK::Sign *minutiae, int num, int fill_low, int fill_high, int quality)
   {
      m_minutiae  = minutiae;
      m_num       = num;
      m_fill_low  = fill_low;
      m_fill_high = fill_high;
      m_fill_sort = fill_low + fill_high;
      m_quality   = quality;
   }
   ~NestEx()
   {
   }
   operator int() const
   {
      return m_fill_sort;   
   }
};

void getMinCenter(ESK::Sign *minutiae, int numMinutiae, int &xc, int &yc)
{
   if (!numMinutiae)
      return;
   xc = yc = 0;
   for(int k = 0; k < numMinutiae; k++)
   {
      xc += (int)minutiae[k].Movx;
      yc += (int)minutiae[k].Movy;

   }
   xc /= numMinutiae; 
   yc /= numMinutiae; 
}


inline bool isMinTaken (int item, int &nTaken, int *taken)
{
   for(int i = 0; i < nTaken; i++)
      if (item == taken[i])  
         return true;

   taken[nTaken++] = item;
   return false;
}

inline unsigned int  getDist(AccelTables *accelTables, ESK::twin_t size)
{
   if (size >= DIST_TABLE_SIZE)
      return MAX_ACCEL_LINK_DIST + 1;
	return accelTables->getDist(size);
}

inline int getMinutiaeQuality (ESK::Sign &numMinutiae)
{
   int prob  = numMinutiae.Prob; 
   int quality = prob & 0x3f;
   if (prob & 0x80)   
      quality = (quality + 1) / 2;
   return quality;
}

void calcAccelerator (AccelTables *accelTables, Accel &accel, BYTE &accelSign, ESK::Sign *minutiae, ESK::Link *link, ESK::Sign *allMinutiae, 
                      int &fillLow, int &fillHigh, int &quality)
{
   memset (&accel, 0, sizeof(Accel));
   accelSign = 0;//16;
   int dir = 0;
   fillHigh = 0;
   fillLow = 0;

   int qual = getMinutiaeQuality(*minutiae);
   if (qual < 2)
      return;
   int qualCount = 0;
   quality += qual;
   qualCount++;

   unsigned int maxLink = link->Cage;
   assert (maxLink <= 35);
   if ( !maxLink || maxLink > 35) 
      return;
   BYTE dist = 0;                   // distance between link minutiae and central minutiae    
   int deal = 0;                    // event number
   unsigned int q = 0;              // quadrant   
   unsigned int rc = 0;             // ridge count  
   unsigned int type = minutiae->Type;
   assert (type <= 1);
   if (type > 1)
      return;
   int item = 0;                 // minutiae number   
   if (maxLink > 32)
      maxLink = 32;
   int index = 0;
   bool quadrantChanged = false;
   
   // 1st pass - only real rc (without projections)
   for (unsigned int k = 0; k < maxLink; k++)       // go through links
   {
      if( !(deal = link->Knot[k].Deal ) ) 
         continue;
      assert (deal < 16);
      if (deal >= 16)
         continue;
      item = link->Knot[k].Item;                     
      if (item > 254)
         continue;
      q = getQuadrantEx (k, type, deal, quadrantChanged);     
      assert (q <= 3);
      if (q > 3)
         continue;
      if (quadrantChanged)
         continue;
      // get a real ridge count
      rc = abs (calcRidgeCount (type, k, deal));    
      assert (rc < 10);
//      rc = abs (ridgeCount[type][k]); 
      if (rc > 7)                          // we need to pack accelerator into 16 bytes (4 'rc/2' values in each of 4 quadrants)
         continue;
      // get distance
      dist = getDist(accelTables, link->Knot[k].Size); 
      if (!dist || dist > MAX_ACCEL_LINK_DIST)       // dist cannot be 0, because we are used the 0 value 
         continue;                                   // for indication that accelerator link is not taken  
      qual = getMinutiaeQuality (allMinutiae[item]);
      if (qual < 2)
         continue;
      quality += qual;
      qualCount++;
      index = (rc / 2) * 4 + q; 
      assert (index < 16);
      if (((m128i_my*)&accel.accel)->m128i_u8[index])    // already taken
         continue;
      // get direction
      dir = isSameDirection (deal, (MINUTIAE_TYPE)type, k) ? SAME_DIR_VAL : 0;
      ((m128i_my*)&accel.accel)->m128i_u8[index] = dist + dir;
      ((m128i_my*)&accel.item)->m128i_u8[index] = item + 1;
      if (index < 8)  
         fillLow++;
      else
         fillHigh++;
   }
   // calculate accelerator signature
   //unsigned char *v = ((m128i_my*)&accel.accel)->m128i_u8;
   //for(int i = 0; i < 16; i++)
   //{
   //   if (!v[i])
   //      continue;
   //   if   (v[i] & SAME_DIR_VAL) accelSign++;
   //   else                       accelSign--;   
   //}

   // 2nd pass - fill projections for not taken links 
   for (unsigned int k = 0; k < maxLink; k++)       // go through links
   {
      if( !(deal = link->Knot[k].Deal ) ) 
         continue;
      assert (deal < 16);
      if (deal >= 16)
         continue;
      item = link->Knot[k].Item;                     
      if (item > 254)
         continue;
      q = getQuadrantEx (k, type, deal, quadrantChanged);     
      assert (q <= 3);
      if (q > 3)
         continue;
      if (quadrantChanged)
         continue;
      // get ridge count
      rc = abs (ridgeCount[type][k]); 
      assert (rc < 10);
      if (rc > 7)                          // we need to pack accelerator into 16 bytes (4 'rc/2' values in each of 4 quadrants)
         continue;
//      qual = getMinutiaeQuality (allNest[item]);
//      if (qual < 1)
  //       continue;
      index = (rc / 2) * 4 + q;
      assert (index < 16);
      if (((m128i_my*)&accel.accel)->m128i_u8[index])    // already taken
         continue;
      // get distance
      dist = getDist(accelTables, link->Knot[k].Size); 
      if (!dist || dist > MAX_ACCEL_LINK_DIST)       // dist cannot be 0, because we are used the 0 value 
         continue;                                   // for indication that accelerator link is not taken  
      // get direction
      dir = isSameDirection (deal, (MINUTIAE_TYPE)type, k) ? SAME_DIR_VAL : 0;
      ((m128i_my*)&accel.accel)->m128i_u8[index] = dist + dir;
      ((m128i_my*)&accel.item)->m128i_u8[index] = item + 1;
      if (index < 8)  
         fillLow++;
      else
         fillHigh++;
   }
   quality /= qualCount;
   static unsigned char a_count = MIN_RANDOM_VAL;
   for(int i = 0; i < 16; i++)
      if (!((m128i_my*)&accel.item)->m128i_u8[i])
      {
         ((m128i_my*)&accel.accel)->m128i_u8[i] = a_count++;
         if (a_count < MIN_RANDOM_VAL) 
            a_count = MIN_RANDOM_VAL;
      }
   accelSign = fillLow + fillHigh;
}

void fillMinutiaeData (MinutiaeData *min, ESK::Sign *minutiae, int numNest)
{
   for(int i = 0; i < numNest; i++)
   {
      min[i].x    = (short)minutiae[i].Movx;
      min[i].y    = (short)minutiae[i].Movy; 
      min[i].a    = minutiae[i].Beta / 4;
   }
}

void fillAcceleratorData (AccelTables *accelTables, Accel *accel, BYTE *accelSign, ESK::Sign *minutiae, ESK::Link *link, 
               int numNest, vector<NestEx> &nestVec)
{
   int fillLow = 0, fillHigh = 0, quality = 0;
   for(int i = 0; i < numNest; i++)
   {
      calcAccelerator (accelTables, accel[i], accelSign[i], &minutiae[i], &link[i], minutiae, fillLow, fillHigh, quality);
      nestVec.push_back (NestEx (&minutiae[i], i, fillLow, fillHigh, quality));
   }
}

inline DWORD getMinDist (vector<NestEx> &nestVec, ESK::Sign *minutiae, int numItem, int x, int y)
{
   DWORD minDist = 1024, len = -1;
   vector<NestEx>::iterator p = nestVec.begin();
   for (int i = 0; p != nestVec.end() && i < numItem; i++, p++)
   {
      len = dist ((int)minutiae[p->m_num].Movx, (int)minutiae[p->m_num].Movy, x, y);
      if (len < minDist)
         minDist = len;
   }
   return minDist;
}

// resort the first subsetSize minutiae in a way to be distributed as much as possible
void resortTopAccel(vector<NestEx> &nestVec, ESK::Sign *minutiae, BYTE numNest, BYTE subsetSize)
{
   if (!subsetSize)
      return;
   if (subsetSize > numNest)
      subsetSize = numNest;
   // find minutiae center
   int xc = 0, yc = 0;
   getMinCenter(minutiae, numNest, xc, yc);
   // find closest to center minutiae in subset
   int num = -1, closestNum = -1;      // number of item that contains the closest to center minutiae
   DWORD len = -1, minLen = 1024;      // distance to minutiae center 
   for(int i = 0; i < subsetSize; i++)
   {
      num = nestVec[i].m_num;
      len = dist ((int)minutiae[num].Movx, (int)minutiae[num].Movy, xc, yc);
      if (len < minLen)
      {
         minLen = len;
         closestNum = i;
      }
   }
   if (closestNum == -1)
      return;
   // calculate the distance between all minutiae in subset
   //int distArray[MAX_MINUTIAE][MAX_MINUTIAE]; 
   //int n1 = -1, n2 = -1;              // number of minutiae
   //for(int i = 0; i < subsetSize; i++)
   //{
   //   n1 = nestVec[i].m_num;
   //   for(int j = i + 1; j < subsetSize; j++)
   //   {
   //      n2 = nestVec[j].m_num;
   //      distArray[n1][n2] = distArray[n2][n1] = dist (minutiae[n1].Movx, minutiae[n1].Movy, minutiae[n2].Movx, minutiae[n2].Movy);
   //   }
   //}
   // copy subset of nestVec to temporary vector
   vector<NestEx> temp;
   temp.assign (nestVec.begin(), nestVec.begin() + subsetSize);
   vector<NestEx>::iterator p = temp.begin();
   // put the closest to center minutiae on top
   nestVec[0] = temp[closestNum];
   temp[closestNum].m_num = -1;
   // step by step copy to nestVec minutiae that farthest from all already copied minutiae 
   int farthestNum = -1;               // number of item that contain the farthest minutiae
   DWORD maxDist = 0;
   for(int i = 1; i < subsetSize; i++)
   {
      maxDist = 0;
      farthestNum = -1;
      for(int j = 0; j < subsetSize; j++)
      {
         num = temp[j].m_num;
         if (num == -1)
            continue;
         len = getMinDist(nestVec, minutiae, i, (int)minutiae[num].Movx, (int)minutiae[num].Movy);
         if (len > maxDist)
         {
            maxDist = len;
            farthestNum = j;
         }
      }
      if (farthestNum == -1)
         continue;
      nestVec[i] = temp[farthestNum];
      temp[farthestNum].m_num = -1;
   }
}


void buildAccel (AllAccel &allAccel, vector<NestEx> &nestVec, ESK::Sign *minutiae, ESK::Link *link, size_t numNest, 
                  Accel *accel,BYTE *accelSign, MinutiaeData *minutiaeData, DWORD *accelSize, BYTE *accel_buf, 
                  bool isFull, bool eliminateFarMin)
{
   Accel sortedAccel [MAX_ACCEL_MIN];
   BYTE  accelNum    [MAX_ACCEL_MIN];
   BYTE  quality     [MAX_ACCEL_MIN];
   int k = 0;
   int num_fill[17], fill = 0, len = 0;
   memset (num_fill, 0, sizeof(num_fill));
   
   // for eliminate some minutiae, calculate minutiae center and find maximum acceptable distance for center
   int xc = 0, yc = 0;
   WORD maxDist = 1024; 
   WORD dist2center[MAX_ACCEL_MIN];
   if (eliminateFarMin)
   {
      getMinCenter(minutiae, (int)numNest, xc, yc);
      multiset <WORD, less<WORD> > distSet;
      for(int i = 0; i < numNest; i++)
      {
         if (minutiae[i].Prob & 0x40)  
         {
            dist2center[i] = 0;
            continue;
         }
         dist2center[i] = (WORD)dist ((int)minutiae[i].Movx, (int)minutiae[i].Movy, xc, yc);
         distSet.insert (dist2center[i]);
      }
      multiset <WORD, less<WORD> >::iterator p = distSet.begin();
      int count = MAX_NUM_FOR_ACCEL_CALC - 1;
      while(count--) p++;
      maxDist = *p;
   }
   unsigned int count = 0;
   for (unsigned int i = 0; i < numNest; i++)
   {
      if (!isFull && (minutiae[i].Prob & 0x40))   
         continue;
      if (eliminateFarMin && (dist2center[i] > maxDist))
         continue;
      k = nestVec[i].m_num;
      memcpy(&sortedAccel[count], &accel[k], sizeof(Accel));
      accelNum[count] = k;
      quality [count] = nestVec[i].m_quality;
      fill = nestVec[i].m_fill_low + nestVec[i].m_fill_high;
      num_fill[fill]++;
      if (!fill)
      {
         allAccel.numAccel = count;
         break; 
      }
      count++;
   }
   allAccel.numAccel = count;
   allAccel.num_fill_n[12] = num_fill[16];
   for(int i = 11; i >= 0; i--)
      allAccel.num_fill_n[i] = allAccel.num_fill_n[i + 1] + num_fill[i + 4];


   if (!isFull)
   {
      if (allAccel.numAccel > MAX_ACCEL) allAccel.numAccel = MAX_ACCEL;
      for(int i = 12; i >= 0; i--)
         if (allAccel.num_fill_n[i]  > MAX_ACCEL)
            allAccel.num_fill_n[i]  = MAX_ACCEL;
   }

   *accelSize = copyAccelData2buffer(accel_buf, &allAccel, minutiaeData, sortedAccel, accelNum/*, mainAccel, dist2Anchor*/, accelSign, quality);
}

void calcAccel_base(AccelTables *accelTables, ESK::Sign *minutiae, ESK::Link *link, size_t numNest, 
                    ESK::Sign *sing, size_t numSing, BYTE *area, WORD width, WORD height, DWORD *accelSize, BYTE *accel_buf, 
                    BYTE quality, BYTE patternType, BYTE *full_accel_buf)
{
   AllAccel     allAccel;
   Accel        accel        [MAX_ACCEL_MIN];
   BYTE         accelSign    [MAX_ACCEL_MIN];
   MinutiaeData minutiaeData [MAX_ACCEL_MIN];
//   BYTE         dist2Anchor [MAX_ACCEL_MIN]; 
   if (numNest > MAX_ACCEL_MIN)
      numNest = (BYTE)MAX_ACCEL_MIN;

   // in non full mode define if need eliminate some minutiae from accelerator
   // calculate number of minutiae those not near singular
   BYTE numFarSingularPoints = 0;
   if (numNest > MAX_NUM_FOR_ACCEL_CALC)
      for(BYTE i = 0; i < numNest; i++)
         if (!(minutiae[i].Prob & 0x40)) 
            numFarSingularPoints++;
   bool eliminateFarMin = !full_accel_buf && (numFarSingularPoints > MAX_NUM_FOR_ACCEL_CALC);

   // calulate number of reliable minutiae and modify fingerprint quality
   BYTE numRelPoints = 0;
   for(unsigned int i = 0; i < numNest; i++)
   {
      if (minutiae[i].Prob < 0x40) 
         numRelPoints++;
   }
   allAccel.numRelMin   = numRelPoints;
   allAccel.quality     = quality;
   allAccel.modQuality  = quality;
   if (numRelPoints < NUM_REL_POINTS) 
      allAccel.modQuality = BYTE(quality * numRelPoints   / NUM_REL_POINTS);
   if (quality && !allAccel.modQuality) allAccel.modQuality = 1;

   // fill minutiae data
   allAccel.numMinutiae = (BYTE)numNest;
   fillMinutiaeData (minutiaeData, minutiae, (int)numNest);
   // fill accelerator data
   vector<NestEx> nestVec;
   fillAcceleratorData (accelTables, accel, accelSign, minutiae, link, (int)numNest, nestVec);
   sort (nestVec.begin(), nestVec.end(), greater <int>());

   // build accel
   buildAccel (allAccel, nestVec, minutiae, link, numNest, accel, accelSign, minutiaeData, accelSize, accel_buf, false, eliminateFarMin);
   if (full_accel_buf)
   {
      DWORD fullAccelSize = 0;
      buildAccel (allAccel, nestVec, minutiae, link, numNest, accel, accelSign, minutiaeData, &fullAccelSize, full_accel_buf, true, false);
   }
}


#pragma pack(pop)
} // namespace accelMatch{
