#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "score100.h"
#include "adjustParams100.h"
#include "scoreParameters100.h"
#include "win2lin.h"


namespace accelMatch{
#pragma pack(push,_CORE_PACKING)
// HARD_UNI accel_ma by M1, w, FRR@FAR=10^-8 (all should be not worse and at least one of them better) , Brnach1-2 by ROC
int g_k_score_pg_q[NUM_CALC_SCORE_TYPES][SCORE_PG_Q_PARAM_SIZE1][SCORE_PG_Q_PARAM_SIZE2] =
{
	{ //BRANCH1
	//        	      0,	      1,
	/* 0*/  {	   1594,	    575,}, //  0,
	/* 1*/  {	   1583,	    597,}, //  1,
	/* 2*/  {	      0,	    600,}, //  2,
	/* 3*/  {	   1446,	    597,}, //  3,
	/* 4*/  {	   2487,	    600,}, //  4,
	/* 5*/  {	   1104,	    600,}, //  5,
	/* 6*/  {	    795,	    237,}, //  6,
	/* 7*/  {	   1011,	    264,}, //  7,
	/* 8*/  {	   1006,	    237,}, //  8,
	/* 9*/  {	   1595,	    597,}, //  9,
	/*10*/  {	   1235,	    600,}, // 10,
	/*11*/  {	    689,	    600,}, // 11,
	},
	{ //BRANCH2
	//        	      0,	      1,
	/* 0*/  {	   1229,	    372,}, //  0,
	/* 1*/  {	   1690,	    597,}, //  1,
	/* 2*/  {	    437,	    637,}, //  2,
	/* 3*/  {	   1813,	    543,}, //  3,
	/* 4*/  {	   2040,	    507,}, //  4,
	/* 5*/  {	   2168,	    488,}, //  5,
	/* 6*/  {	    785,	    210,}, //  6,
	/* 7*/  {	   1994,	    435,}, //  7,
	/* 8*/  {	   1052,	    354,}, //  8,
	/* 9*/  {	    178,	    600,}, //  9,
	/*10*/  {	    301,	    600,}, // 10,
	/*11*/  {	    689,	    600,}, // 11,
	},
	{ //ACCEL_BRANCH1
	//        	      0,	      1,
	/* 0*/  {	    876,	    258,}, //  0,
	/* 1*/  {	    884,	    280,}, //  1,
	/* 2*/  {	      0,	    330,}, //  2,
	/* 3*/  {	    795,	    318,}, //  3,
	/* 4*/  {	    910,	    300,}, //  4,
	/* 5*/  {	    896,	    288,}, //  5,
	/* 6*/  {	    472,	    246,}, //  6,
	/* 7*/  {	    600,	    246,}, //  7,
	/* 8*/  {	    620,	    306,}, //  8,
	/* 9*/  {	   1632,	    612,}, //  9,
	/*10*/  {	   1235,	    586,}, // 10,
	/*11*/  {	    689,	    586,}, // 11,
	},
	{ //ACCEL_BRANCH2
	//        	      0,	      1,
	/* 0*/  {	    696,	    208,}, //  0,
	/* 1*/  {	   1040,	    280,}, //  1,
	/* 2*/  {	   1974,	    330,}, //  2,
	/* 3*/  {	   1020,	    318,}, //  3,
	/* 4*/  {	   1173,	    312,}, //  4,
	/* 5*/  {	   1156,	    288,}, //  5,
	/* 6*/  {	    459,	    252,}, //  6,
	/* 7*/  {	    754,	    270,}, //  7,
	/* 8*/  {	    620,	    222,}, //  8,
	/* 9*/  {	   1836,	    444,}, //  9,
	/*10*/  {	   1501,	    493,}, // 10,
	/*11*/  {	    689,	    493,}, // 11,
	},
	{ //ACCEL_QUICK
	//        	      0,	      1,
	/* 0*/  {	   1020,	    208,}, //  0,
	/* 1*/  {	    867,	    280,}, //  1,
	/* 2*/  {	    350,	    330,}, //  2,
	/* 3*/  {	    795,	    318,}, //  3,
	/* 4*/  {	    936,	    306,}, //  4,
	/* 5*/  {	    896,	    288,}, //  5,
	/* 6*/  {	    477,	    207,}, //  6,
	/* 7*/  {	    600,	    246,}, //  7,
	/* 8*/  {	   1044,	    306,}, //  8,
	/* 9*/  {	   1750,	    364,}, //  9,
	/*10*/  {	    960,	    596,}, // 10,
	/*11*/  {	    689,	    586,}, // 11,
	},
};
int g_k_score_pg[NUM_CALC_SCORE_TYPES][SCORE_PG_PARAM_SIZE1][SCORE_PG_PARAM_SIZE2] =
{
	{ //BRANCH1
	//        	      0,	      1,	      2,	      3,	      4,	      5,	      6,
	/* 0*/  {	    636,	   2328,	      0,	    318,	   1050,	   6065,	   2075,}, //  0,
	/* 1*/  {	    780,	   6751,	      0,	    850,	   1045,	   1490,	    -20,}, //  1,
	/* 2*/  {	    765,	   1492,	     70,	    848,	   1224,	   1000,	   -375,}, //  2,
	/* 3*/  {	    368,	    611,	     40,	  11572,	     40,	    316,	   -375,}, //  3,
	},
	{ //BRANCH2
	//        	      0,	      1,	      2,	      3,	      4,	      5,	      6,
	/* 0*/  {	    130,	   4960,	      0,	   1567,	   3152,	    655,	   -325,}, //  0,
	/* 1*/  {	   1335,	   1685,	    331,	   1153,	   1622,	    296,	   -375,}, //  1,
	/* 2*/  {	    957,	    975,	     50,	    202,	   1224,	   1106,	   -351,}, //  2,
	/* 3*/  {	      0,	    194,	    430,	   4905,	     40,	      0,	   -375,}, //  3,
	},
	{ //ACCEL_BRANCH1
	//        	      0,	      1,	      2,	      3,	      4,	      5,	      6,
	/* 0*/  {	    636,	    700,	    288,	    318,	   1050,	   1547,	   -375,}, //  0,
	/* 1*/  {	    780,	   3906,	    138,	    850,	   1045,	    516,	   -375,}, //  1,
	/* 2*/  {	    765,	    969,	    350,	    848,	   1224,	   1000,	   -375,}, //  2,
	/* 3*/  {	    368,	   1040,	      0,	  11572,	     40,	    330,	   -375,}, //  3,
	},
	{ //ACCEL_BRANCH2
	//        	      0,	      1,	      2,	      3,	      4,	      5,	      6,
	/* 0*/  {	   1300,	    484,	     12,	   1104,	    864,	    884,	   -375,}, //  0,
	/* 1*/  {	    840,	   1272,	    357,	    915,	   1560,	    336,	   -375,}, //  1,
	/* 2*/  {	    810,	    936,	    255,	    864,	   1224,	   1000,	   -375,}, //  2,
	/* 3*/  {	      0,	    969,	    430,	  11572,	     40,	      0,	   -375,}, //  3,
	},
	{ //ACCEL_QUICK
	//        	      0,	      1,	      2,	      3,	      4,	      5,	      6,
	/* 0*/  {	    636,	    700,	    288,	    318,	   1050,	   1547,	   -375,}, //  0,
	/* 1*/  {	    780,	   3906,	    144,	    850,	   1045,	    516,	   -375,}, //  1,
	/* 2*/  {	    765,	    969,	    350,	    848,	   1224,	   1000,	   -375,}, //  2,
	/* 3*/  {	    368,	   1040,	     10,	  11572,	     40,	    330,	   -375,}, //  3,
	},
};

int g_k_score[NUM_CALC_SCORE_TYPES][SCORE_GROUP_SIZE] =
{
	//      0,      1,      2,      3,      4,      5,      6,      7,      8,      9,     10,     11,     12,     13,     14,     15,     16,
	{    1040,   1270,    924,     60,     55,      0,    312,      0,   2626,      0,     90,      0,      0,      0,   3393,      0,     40,}, // BRANCH1
	{    1040,   1300,    780,    638,    270,      0,    181,      0,   2350,      0,    386,      0,      0,      0,   4202,      0,    242,}, // BRANCH2
	{    1040,   1250,    780,     60,    275,      0,    312,      0,   2805,      0,     70,      0,      0,      0,   3570,      0,      0,}, // ACCEL_BRANCH1
	{    1040,   1300,    780,     50,    285,      0,    144,      0,   2350,      0,    550,      0,      0,      0,   4340,      0,    280,}, // ACCEL_BRANCH2
	{    1040,   1250,    780,     60,    275,      0,    312,      0,   2805,      0,     70,      0,      0,      0,   3570,      0,      0,}, // ACCEL_QUICK
};

int g_k_score_common[NUM_CALC_SCORE_TYPES][SCORE_COMMON_PARAM_SIZE] =
{
	//      0,      1,
	{     636,    255,}, // BRANCH1
	{     636,    255,}, // BRANCH2
	{     636,    255,}, // ACCEL_BRANCH1
	{     636,    255,}, // ACCEL_BRANCH2
	{     636,    255,}, // ACCEL_QUICK
};

int g_k_score_pg_bounds[NUM_CALC_SCORE_TYPES][SCORE_PG_PARAM_SIZE1 - 1] =
{
	//      0,      1,      2,
	{      13,     20,     60,}, // BRANCH1
	{      10,     20,     60,}, // BRANCH2
	{      13,     20,     60,}, // ACCEL_BRANCH1
	{      13,     20,     60,}, // ACCEL_BRANCH2
	{      13,     20,     60,}, // ACCEL_QUICK
};

int g_k_score_q_bounds[NUM_CALC_SCORE_TYPES][SCORE_Q_PARAM_SIZE1 - 1] =
{
	//      0,      1,
	{      30,    110,}, // BRANCH1
	{      30,     60,}, // BRANCH2
	{      30,     90,}, // ACCEL_BRANCH1
	{      30,     70,}, // ACCEL_BRANCH2
	{      30,    110,}, // ACCEL_QUICK
};

int g_k_score_up_f_p[NUM_CALC_SCORE_TYPES][SCORE_FOUND_PARAM_SIZE] =
{
	//      0,      1,      2,      3,      4,      5,      6,      7,      8,      9,
	{     338,    310,    640,    441,    768,    483,    194,    115,   3493,    390,}, // BRANCH1
	{     695,   2888,    673,    107,    769,    324,    274,     20,    422,    769,}, // BRANCH2
	{    1449,    350,    800,   1632,    768,    360,    804,    128,   3264,    390,}, // ACCEL_BRANCH1
	{     824,   3074,    720,    522,    645,     88,    630,     20,    731,    390,}, // ACCEL_BRANCH2
	{    1804,    350,    832,   1632,    525,    360,    912,    144,   3380,    390,}, // ACCEL_QUICK
};

int g_k_score_up_f_g[NUM_CALC_SCORE_TYPES][SCORE_FOUND_PARAM_SIZE] =
{
	//      0,      1,      2,      3,      4,      5,      6,      7,      8,      9,
	{     551,    314,    767,    567,    768,   1130,    259,     10,     60,    384,}, // BRANCH1
	{      98,     60,    174,    195,    768,    592,      0,      0,     10,    640,}, // BRANCH2
	{    2496,    742,    650,    517,    768,    420,    312,     40,    116,    516,}, // ACCEL_BRANCH1
	{      52,    672,    204,    361,    516,    440,    160,     70,     10,    640,}, // ACCEL_BRANCH2
	{      98,    882,    611,    517,    768,    192,    258,     40,    116,    516,}, // ACCEL_QUICK
};



/*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************



/*
   0  - minimum acceptable accelerators similarity
   1  - maximum percent of whole set pair of nests that should be passed to the next step after accelerator compare
   2  - maximum number pair of nests that should be passed to the next step after accelerator compare

   3  - minimum acceptable nests similarity
   4  - maximum percent of whole set pair of nests that should be passed to the next step after nests compare
   5  - maximum number of pair of nests that should be passed to the next step after nests compare

   6  - minimum acceptable virtual group size
   7  - maximum number of pair of nests for those buildGroup will be called in matchBranch2

   8  - minimum number of minutiae in a group after buildGroup
   9  - 

   10 - if after buildGroup a new group has less minutiae than this percent of minutiae in a previous group, refuse this group
   11 - maximum number of kernel groups for branch 1
   12 - percent of same pairs in kernal groups, when we unite these groups
   13 - maximum number of expand groups
   14 - maximum percent of nests pair those should be passed to the next step after compare by accelerator (in case of matching after Dima's accelerator matching)
   15 - maximum number pair of nests that should be passed to the next step after accelerator compare (in case of matching after Dima's accelerator matching)
   16 - maximum number of pair of nests that should be passed to the next step after nests compare (in case of matching after Dima's accelerator matching)
   17 - maximum number of kernel groupsfor branch 2
   18 - maximum number of pair of nests for those buildGroup will be called  in matchBranch1 

*/
size_t g_k_speed[][SPEED_PARAM_SIZE] = 
{
//    0     1     2     3      4       5     6     7    8     9    10    11     12    13    14   15   16   17   18   19   
//    { 2,   25,  200,    0,    30,     20,    3,    3,   4,    3,   40,   2,     90,   20,  100, 160,   6,  12,   1,   0},       // speed 0
    { 0,   25,   32,    0,   100,     20,    3,    3,   4,    3,   40,   2,     90,   20,  100, 160,   6,  12,   1,   0},       // speed 0
  
    
    {10,   10,  120,    10,   100,   100,    5,    3,   6,    5,  100,    0,     0,    0,   0,   0,   0,   0,   0,   0},       // speed 1
    
    {15,   8,  120,    10,   100,   100,    5,    3,   6,    5,  100,    0,     0,    0,   0,   0,   0,   0,   0,   0},       // speed 2
    
    {10,   10,  120,    10,   100,   100,    5,    3,   6,    5,  100,    0,     0,    0,   0,   0,   0,   0,   0,   0},       // speed 3
};

size_t g_k_speed_latent[][SPEED_PARAM_SIZE] = 
{
//    0     1     2     3      4       5     6     7    8     9    10    11     12    13   14   15   16   17   18   19   
    { 2,   20,  160,    0,   100,      6,    3,    3,   5,    3,   40,    3,    90,   20, 100, 160,   6,   3,   1,   0},       // speed 0
};


#ifdef ADJUST
#define MAX_ADJUST_BUFFER_SIZE        ((sizeof(ScoreParameters) + sizeof(MinData) * MAX_MINUTIAE * 2) * MAX_SCORE_PARAM_GROUPS * 2)
#define MAX_ACCEL_ADJUST_BUFFER_SIZE  (sizeof(AccelScoreParam) * MAX_SCORE_PARAM_GROUPS * 2)

char    g_marker[]       = "zz";
FILE   *g_maAdjGenFile        [MAX_NUM_THREADS];
FILE   *g_maAdjImpFile        [MAX_NUM_THREADS];
bool    g_maGenuineMatching   [MAX_NUM_THREADS];
BYTE    g_maAdjGenBuffer      [MAX_NUM_THREADS][MAX_ADJUST_BUFFER_SIZE];
BYTE    g_maAdjImpBuffer      [MAX_NUM_THREADS][MAX_ADJUST_BUFFER_SIZE];
size_t  g_maAdjGenSize        [MAX_NUM_THREADS];
size_t  g_maAdjImpSize        [MAX_NUM_THREADS];
bool    g_maWritePermission   [MAX_NUM_THREADS];

FILE   *g_accelAdjGenFile        [MAX_NUM_THREADS];
FILE   *g_accelAdjImpFile        [MAX_NUM_THREADS];
bool    g_accelGenuineMatching   [MAX_NUM_THREADS];
BYTE    g_accelAdjGenBuffer      [MAX_NUM_THREADS][MAX_ACCEL_ADJUST_BUFFER_SIZE];
BYTE    g_accelAdjImpBuffer      [MAX_NUM_THREADS][MAX_ACCEL_ADJUST_BUFFER_SIZE];
size_t  g_accelAdjGenSize        [MAX_NUM_THREADS];
size_t  g_accelAdjImpSize        [MAX_NUM_THREADS];
bool    g_accelWritePermission   [MAX_NUM_THREADS];


const size_t g_scoreSize = sizeof(WORD);
const size_t g_markerSize = strlen(g_marker);

//// name of files for parameters value statictic
//const char * g_histName[] = 
//{
//   "farDistErr",         // 1 
//   "globalDistErr",      // 2 
//   "farRelAngleErr",     // 4
//   "globalRelAngleErr",  // 5
//   "angleErr",           // 6
//   "typeErr",            // 7
//   "pairAngleErr",       // 8
//   "posErr",             // 9
//   "topologySim",        // 10
//   "divergeDif",         // 11
//   "flowDif",            // 12
//   "AccelDif",           // 13
//   "rcDif",              // 14
//   "sim",                // 15
//};
//
//#define NUM_HIST_NAME  sizeof(g_histName) / sizeof(g_histName[0])
//FILE * g_histLog[NUM_HIST_NAME];
//int g_hist[NUM_HIST_NAME][101];
//int g_bestHist[NUM_HIST_NAME][101];
//int g_allHist[NUM_HIST_NAME][101];


void getLogName(bool accel, const char *name, char path[MAX_PATH], int probeRegNum, char fingerP, bool genuine)
{
   if (probeRegNum >= 0 && fingerP >= 0)
      sprintf (path, "%s%s%s_%d_%d.bin", name, accel ? "Accel" : "", genuine ? "Gen" : "Imp", probeRegNum, fingerP);
   else
      sprintf (path, "%s%s.bin", name, accel ? "Accel" : "");
}



FILE* openLog(bool accel, const char *name, int num_thread, bool forRead, int probeRegNum, char fingerP, bool genuine)
{
   closeLog (accel, num_thread, genuine);
   FILE **f = NULL;
   if (accel) f = genuine ? &g_accelAdjGenFile [num_thread] : &g_accelAdjImpFile [num_thread];
   else       f = genuine ? &g_maAdjGenFile    [num_thread] : &g_maAdjImpFile    [num_thread];
   assert(*f == NULL);
   if (!name)
      return false;
   char path[MAX_PATH];
   getLogName (accel, name, path, probeRegNum, fingerP, genuine);
   *f = fopen(path, forRead ? "rb" : "wb");
   
   return *f;
}

void closeLog(bool accel, int num_thread, bool genuine)
{
   FILE **f = NULL;
   if (accel) f = genuine ? &g_accelAdjGenFile[num_thread] : &g_accelAdjImpFile[num_thread];
   else       f = genuine ? &g_maAdjGenFile   [num_thread] : &g_maAdjImpFile   [num_thread];
   if (*f) fclose(*f), *f = NULL;
}


bool commitSaveParameters(bool accel, int num_thread, bool commitData) 
{
   BYTE *buffer          = NULL;
   FILE *f               = NULL;
   size_t size           = 0;
   if (accel)
   {
      buffer            = g_accelGenuineMatching[num_thread] ? g_accelAdjGenBuffer[num_thread] : g_accelAdjImpBuffer[num_thread];
      f                 = g_accelGenuineMatching[num_thread] ? g_accelAdjGenFile  [num_thread] : g_accelAdjImpFile  [num_thread];
      size              = g_accelGenuineMatching[num_thread] ? g_accelAdjGenSize  [num_thread] : g_accelAdjImpSize  [num_thread];
   }
   else
   {
      buffer            = g_maGenuineMatching[num_thread] ? g_maAdjGenBuffer[num_thread] : g_maAdjImpBuffer[num_thread];
      f                 = g_maGenuineMatching[num_thread] ? g_maAdjGenFile  [num_thread] : g_maAdjImpFile  [num_thread];
      size              = g_maGenuineMatching[num_thread] ? g_maAdjGenSize  [num_thread] : g_maAdjImpSize  [num_thread];
   }
   if (!f || !buffer)
      return false;
   if (commitData)
      return (fwrite (buffer, 1, size, f) == size);
   else // write only marker, score and marker (in fact, marker and last 4 bytes from the fuffer
   {
      if (fwrite (g_marker, 1, g_markerSize, f) != g_markerSize)
         return false;
      size_t dataSize = g_markerSize + g_scoreSize;
      size_t offset = size - dataSize;
      return (fwrite (buffer + offset, 1, dataSize, f) == dataSize);
   }
   return true;
}

void writeData(BYTE *out, size_t &outSize, void *in, size_t inSize)
{
   assert(out && in);
   memcpy(out + outSize, in, inSize);
   outSize += inSize;
}
bool logStartMatch(bool accel, int num_thread)
{
   BYTE *buffer = NULL;
   size_t *size = 0;
   bool *writePermission = NULL;
   if (accel)
   {
      buffer            = g_accelGenuineMatching[num_thread] ?  g_accelAdjGenBuffer   [num_thread] :  g_accelAdjImpBuffer   [num_thread];
      size              = g_accelGenuineMatching[num_thread] ? &g_accelAdjGenSize     [num_thread] : &g_accelAdjImpSize     [num_thread];
      writePermission   = &g_accelWritePermission[num_thread];
   }
   else
   {
      buffer            = g_maGenuineMatching[num_thread] ?  g_maAdjGenBuffer   [num_thread] :  g_maAdjImpBuffer   [num_thread];
      size              = g_maGenuineMatching[num_thread] ? &g_maAdjGenSize     [num_thread] : &g_maAdjImpSize     [num_thread];
      writePermission   = &g_maWritePermission[num_thread];
   }
   if (!buffer)
      return false;
   *writePermission = true;
   *size = 0;
   writeData (buffer, *size, g_marker, g_markerSize);
   return true;
}


bool logFinishMatch(bool accel, int num_thread, int score)
{
   BYTE   *buffer = NULL;
   size_t *size   = 0;
   bool *writePermission = NULL;
   if (accel)
   {
      buffer            = g_accelGenuineMatching[num_thread] ?  g_accelAdjGenBuffer   [num_thread] :  g_accelAdjImpBuffer   [num_thread];
      size              = g_accelGenuineMatching[num_thread] ? &g_accelAdjGenSize     [num_thread] : &g_accelAdjImpSize     [num_thread];
      writePermission   = &g_accelWritePermission[num_thread];
   }
   else
   {
      buffer            = g_maGenuineMatching[num_thread] ?  g_maAdjGenBuffer   [num_thread] :  g_maAdjImpBuffer   [num_thread];
      size              = g_maGenuineMatching[num_thread] ? &g_maAdjGenSize     [num_thread] : &g_maAdjImpSize     [num_thread];
      writePermission   = &g_maWritePermission[num_thread];
   }
   if (!buffer)
      return false;
   writeData (buffer, *size, &score  , g_scoreSize );
   writeData (buffer, *size, g_marker, g_markerSize);
   *writePermission = false;
   return true;
}


bool saveParameters(ScoreParameters &param, MinData *minDataP, MinData *minDataG)
{
   int num_thread = omp_get_thread_num();
   BYTE *buffer     = g_maGenuineMatching[num_thread] ? g_maAdjGenBuffer   [num_thread] : g_maAdjImpBuffer   [num_thread];
   size_t &size     = g_maGenuineMatching[num_thread] ? g_maAdjGenSize     [num_thread] : g_maAdjImpSize     [num_thread];
   bool writePermission   = g_maWritePermission[num_thread];
   if (!writePermission)
      return true;
   if (!buffer)
      return false;
   writeData(buffer, size, &param, sizeof(ScoreParameters));

   MinDataPacked data;
   size_t sizeIn = sizeof(MinDataPacked);
   int count = 0;
   for (int i = 0; i < param.m_numNestP; i++)
   {
      if (  minDataP[i].m_foundStatus != FOUND_FIRST && minDataP[i].m_foundStatus != FOUND_MAIN 
         && minDataP[i].m_foundStatus != FOUND       && minDataP[i].m_foundStatus != NOT_FOUND )
         continue;
      data = minDataP[i];
//      writeData(buffer, size, &minDataP[i], sizeIn);
      writeData(buffer, size, &data, sizeIn);
      count++;
   }
   assert (count == (param.m_numNestP - param.m_numExcludedP));

   count = 0;
   for (int i = 0; i < param.m_numNestG; i++)
   {
      if (  minDataG[i].m_foundStatus != FOUND_FIRST && minDataG[i].m_foundStatus != FOUND_MAIN 
         && minDataG[i].m_foundStatus != FOUND       && minDataG[i].m_foundStatus != NOT_FOUND )
         continue;
      data = minDataG[i];
//      writeData(buffer, size, &minDataG[i], sizeIn);
      writeData(buffer, size, &data, sizeIn);
      count++;
   }
   assert (count == (param.m_numNestG - param.m_numExcludedG));
   writeData (buffer, size, g_marker, g_markerSize);

   return true;
}


bool saveAccelParameters(AccelScoreParam &param)
{
   int num_thread = omp_get_thread_num();
   bool writePermission   = g_accelWritePermission[num_thread];
   if (!writePermission)
      return true;
   BYTE *buffer     = g_accelGenuineMatching[num_thread] ? g_accelAdjGenBuffer   [num_thread] : g_accelAdjImpBuffer   [num_thread];
   size_t &size     = g_accelGenuineMatching[num_thread] ? g_accelAdjGenSize     [num_thread] : g_accelAdjImpSize     [num_thread];
   if (!buffer)
      return false;
   writeData(buffer, size, &param, sizeof(AccelScoreParam));
   writeData (buffer, size, g_marker, g_markerSize);

   return true;
}

bool isStartMarker(BYTE *pos)
{
   return !strncmp ((char*)pos, g_marker, g_markerSize);
}
bool isStopMarker(BYTE *pos)
{
   return !strncmp ((char*)pos, g_marker, g_markerSize);
}
bool isEndMarker(BYTE *pos)
{
   return !strncmp ((char*)(pos + sizeof(WORD)), g_marker, g_markerSize);
}

bool readOneGroup(BYTE *&pos, BYTE *end, ScoreParameters **param, MinDataPacked **minDataP, MinDataPacked **minDataG, int &numGroups)
{
   param[numGroups] = (ScoreParameters*)pos;
   size_t size = sizeof(ScoreParameters);
   pos += size;
   if (pos >= end)
      return false;
   minDataP[numGroups] = (MinDataPacked*)pos;
//   minDataP[numGroups] = (MinData*)pos;
   size = (param[numGroups]->m_numNestP - param[numGroups]->m_numExcludedP) * sizeof(MinDataPacked);
//   size = (param[numGroups]->m_numNestP - param[numGroups]->m_numExcludedP) * sizeof(MinData);
   pos += size;
   if (pos >= end)
      return false;
   minDataG[numGroups] = (MinDataPacked*)pos;
//   minDataG[numGroups] = (MinData*)pos;
   size = (param[numGroups]->m_numNestG - param[numGroups]->m_numExcludedG) * sizeof(MinDataPacked);
//   size = (param[numGroups]->m_numNestG - param[numGroups]->m_numExcludedG) * sizeof(MinData);
   pos += size;
   if (!isStopMarker(pos))
      return false;
   pos += g_markerSize;

   if (pos >= end)
      return false;

   numGroups++;
   return  true;
 }

bool readOneAccelGroup(BYTE *&pos, BYTE *end, AccelScoreParam **param, int &numGroups)
{
   param[numGroups] = (AccelScoreParam*)pos;
   size_t size = sizeof(AccelScoreParam);
   pos += size;
   if (!isStopMarker(pos))
      return false;
   pos += g_markerSize;
   if (pos >= end)
      return false;

   numGroups++;
   return  true;
 }


bool readAllMatchedGroups(BYTE *&pos, BYTE *end, ScoreParameters **param, MinDataPacked **minDataP, MinDataPacked **minDataG, int &numGroups, int &score)
//bool readAllMatchedGroups(BYTE *&pos, BYTE *end, ScoreParameters **param, MinData **minDataP, MinData **minDataG, int &numGroups)
{
   numGroups = 0;
   if (!pos)
      return false;
   if (!isStartMarker(pos))
      return false;
   pos += g_markerSize;
   if (isEndMarker(pos))  // no records
   {
      pos += g_markerSize + sizeof(WORD);
      return true;
   }
   if (!readOneGroup(pos, end, param, minDataP, minDataG, numGroups))
      return false;
   while (!isEndMarker(pos))
   {
      if (numGroups >= MAX_SCORE_PARAM_GROUPS)
      {
         printf ("numGroups > MAX_SCORE_PARAM_GROUPS(%d)\n", MAX_SCORE_PARAM_GROUPS);
         break;
      }
      if (!readOneGroup(pos, end, param, minDataP, minDataG, numGroups))
         return false;
   }
   score = *((WORD*)pos);
   pos += g_markerSize + sizeof(WORD);

   return (pos <= end);

}

bool readAllAccelMatchedGroups(BYTE *&pos, BYTE *end, AccelScoreParam **param, int &numGroups, int &score)
{
   numGroups = 0;
   if (!pos)
      return false;
   if (!isStartMarker(pos))
      return false;
   pos += g_markerSize;
   if (isEndMarker(pos))  // no records
   {
      pos += g_markerSize + sizeof(WORD);
      return true;
   }
   if (!readOneAccelGroup(pos, end, param, numGroups))
      return false;
   while (!isEndMarker(pos))
   {
      if (numGroups >= MAX_SCORE_PARAM_GROUPS)
      {
         printf ("numGroups > MAX_SCORE_PARAM_GROUPS(%d)\n", MAX_SCORE_PARAM_GROUPS);
         break;
      }
      if (!readOneAccelGroup(pos, end, param, numGroups))
         return false;
   }
   score = *((WORD*)pos);
   pos += g_markerSize + sizeof(WORD);

   return (pos <= end);
}
/*
void saveParam (int index, int val)
{
   if (val < 0)
      val = 0;
   if (val > 100)
      val = 100;
   g_hist[index][val]++;
}
void saveParam (int index, float v)
{
   return saveParam(index, (int)v);
}


bool openAllHist (char *templDir, char *suffix)
{
   char name[MAX_PATH];
   int num = sizeof(g_histName) / sizeof(g_histName[0]);
   memset (g_allHist, 0, sizeof(g_allHist));
   clearHist();

   for(int n = 0; n < num; n++)
   {
      g_histLog[n] = NULL;
      sprintf (name, "%s%s%s", templDir, g_histName[n], suffix);
      g_histLog[n] = fopen (name, "w");
      if (!g_histLog[n])
         return false;
   }
   return true;
}

void closeAllHist()
{
   int num = sizeof(g_histName) / sizeof(g_histName[0]);
   for(int n = 0; n < num; n++)
   {
      int max = 0;
      if (g_histLog[n])
      {
         for(int i = 0; i <= 100; i++)
            if (g_allHist[n][i] > max)
               max = g_allHist[n][i];
         double val = 0;
         for(int i = 0; i <= 100; i++)
         {
            val = max ? ((double)g_allHist[n][i] * 100 / max) : 0;
            fprintf (g_histLog[n], "%3d\t%10d\n", i, (int)val);
         }
         fclose (g_histLog[n]);
      }
   }
}
void clearHist ()
{
   memset (g_hist, 0, sizeof(g_hist));
}


void updateBestHist ()
{
   int num = sizeof(g_histName) / sizeof(g_histName[0]);
   
   for(int n = 0; n < num; n++)
      memcpy(g_bestHist[n], g_hist[n], sizeof(g_hist[n]));
}

void updateAllHist ()
{
   int num = sizeof(g_histName) / sizeof(g_histName[0]);
   
   for(int n = 0; n < num; n++)
      for(int i = 0; i <= 100; i++)
         g_allHist[n][i] += g_bestHist[n][i];
}
*/

#endif
#pragma pack(pop)
} //namespace accelMatch{

