#ifndef  MIX_FINGER_MATCHING_H_
#define MIX_FINGER_MATCHING_H_

#include <stdlib.h>

static inline unsigned int getMixHandFinger(unsigned int finger)
{
   switch(finger)
   {
   case 0:
      return 5;
      break;
   case 5:
      return 0;
      break;
   default:
      return 10 - finger;
      break;
   }
}

static inline bool isFirstMatchResultTT_better(MatchResultTT &first, MatchResultTT &second)
{
   if      (first.fusionScore > second.fusionScore) return true;
   else if (first.fusionScore < second.fusionScore) return false;
   else if (!first.fusionScore)                     return true;   
   // fusion score != 0 and different
   unsigned int numPairFirst = 0, numPairSecond = 0;
   for(unsigned int finger = 0; finger < 10; finger++)
   {
      if (first.galleryPair[finger]  != -1) numPairFirst++;
      if (second.galleryPair[finger] != -1) numPairSecond++;
   }
   return (numPairFirst > numPairSecond);
}

struct PairScore
{
   int fingerP;
   int fingerG;
   int score;

   PairScore()
   {
      clean();
   }
   void clean()
   {
      memset (this, 0, sizeof(PairScore));
   }
   void set(int fingerP, int fingerG, int score)
   {
      this->fingerP = fingerP;
      this->fingerG = fingerG;
      this->score   = score;
   }
   PairScore(const PairScore& pairScore)
   {
      *this = pairScore;
   }
   PairScore& operator= (const PairScore& pairScore)
   {
      this->fingerP = pairScore.fingerP;
      this->fingerG = pairScore.fingerG;
      this->score   = pairScore.score;
      return *this;
   }
   operator int () const
   {
      return this->score;
   }

};

static inline int comparePairScore (const void *val1, const void *val2) 
{
   return (((PairScore*)val2)->score - ((PairScore*)val1)->score);  
} 

static void chooseBestMatchedPairs(PairScore *score, unsigned int numPairScore, MatchResultTT &matchResultTT)
{
   matchResultTT.clearScore();
   if (!numPairScore) return;
   qsort (score, numPairScore, sizeof(score[0]), comparePairScore);

   for(unsigned int i = 0; i < numPairScore; i++)
   {
      if (!score[i].score)
         continue;
      matchResultTT.score[score[i].fingerP] = score[i].score;
      matchResultTT.galleryPair [score[i].fingerP] = score[i].fingerG;
      // clear all other pairs with fingerP == score[i].fingerP or fingerG == score[i].fingerG
      for (unsigned int j = i + 1; j < numPairScore; j++)
      {
         if ((score[j].fingerP == score[i].fingerP) || (score[j].fingerG == score[i].fingerG))
            score[j].score = 0;
      }
   }
}


#endif // MIX_FINGER_MATCHING_H_
