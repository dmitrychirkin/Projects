/*************************************************************************
   dib.cpp: - implementation of the CDib class
 
	CDib - class for work with DIB (device independent bitmap)
	
	Compatibility:
		Windows NT: Requires version 3.1 or later.
		Windows: Requires Windows 95 or later.
		Windows CE: Requires version 1.0 or later.


   Version 1.0 from 17.06.2002
*************************************************************************/
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include "dib.h"  

#ifdef _WINDOWS
   #ifndef  _WIN32_WCE 
   #include <vfw.h>
   #pragma comment(lib, "vfw32")
//   #pragma comment(lib, "Gdi32")
//   #pragma comment(lib, "User32")
   #endif
#endif

CDib::CDib()
{
	init();
}

CDib::CDib (const CDib& dib)
{
	init();
	setDib (dib.getDib(), dib.getSize());
}

DWORD CDib::getResolutionX ()
{
	LPBITMAPINFOHEADER pBmih = (LPBITMAPINFOHEADER)m_pDib;
	DWORD val = M2INCH (pBmih->biXPelsPerMeter);
	return val;
//	return M2INCH(((LPBITMAPINFOHEADER)m_pDib)->biXPelsPerMeter);
}

DWORD CDib::getResolutionY ()
{ 
	return M2INCH(((LPBITMAPINFOHEADER)m_pDib)->biYPelsPerMeter);
}

void CDib::setResolutionX (int dpi)
{ 
   if (!m_pDib)
      return;
   LPBITMAPINFOHEADER bih = (LPBITMAPINFOHEADER)m_pDib;
   bih->biXPelsPerMeter = INCH2M(dpi);
}

void CDib::setResolutionY (int dpi)
{ 
   if (!m_pDib)
      return;
   LPBITMAPINFOHEADER bih = (LPBITMAPINFOHEADER)m_pDib;
   bih->biYPelsPerMeter = INCH2M(dpi);
}

#ifdef _WINDOWS
bool CDib::setDib (const HANDLE hDib)
{
	if( !hDib ) return false;

	unsigned char* pDib = (unsigned char*)::GlobalLock(hDib);
	m_size =  (DWORD)::GlobalSize (hDib);

	// allocate memory for DIB 
	if (!allocDib(m_size))
	{
		init();
		return false;
	}
	try
	{
		memcpy(m_pDib, pDib, m_size);
	}
	catch (...)
	{
		return false;
	}
	// get offset to the image
	m_offset = getOffset((LPBITMAPINFOHEADER)m_pDib);
 
	::GlobalUnlock(hDib);
	return true;
}
#endif

CDib& CDib::operator= (const CDib& dib)
{
	setDib (dib.getDib(), dib.getSize());
	return *this;
}

CDib::~CDib()
{
	freeDib();	
}


bool CDib::setDib(const unsigned char* pDib, DWORD size)
{
	if(!pDib || !size) 
	{
		return false;
	}
	m_size = size;
	// allocate memory for DIB 
	if (!allocDib(size))
		return false;

	try
	{
		memcpy(m_pDib, pDib, m_size);
	}
	catch (...)
	{
		return false;
	}
	// get offset to the image
	m_offset = getOffset((LPBITMAPINFOHEADER)m_pDib);

	return true;
}

bool CDib::setDib(const unsigned char* pDib)
{
	if(!pDib) 
		return false;

	LPBITMAPINFO pBmi	= (LPBITMAPINFO)pDib;
	LPBITMAPINFOHEADER pBmih = &pBmi->bmiHeader;

	// get image size if image is compressed 
	// (if image isn't compressed then pBmih->biSizeImage already set correctly)
	DWORD strLength = 0;			// row length 
	DWORD strLengthAlign = 0;		// row length with align
	if( pBmih->biCompression == BI_RGB ||
						pBmih->biCompression == BI_BITFIELDS )
	{
		strLength = (pBmih->biWidth * pBmih->biBitCount + 7 ) >> 3; 
		strLengthAlign = ((pBmih->biWidth * pBmih->biBitCount + 31 ) >> 5) << 2; 
		pBmih->biSizeImage = abs(pBmih->biHeight) *	strLengthAlign;
	}

	// get offset to the image and size whole DIB
	m_offset = getOffset(pBmih);
	m_size = m_offset + pBmih->biSizeImage;

	// allocate memory for DIB 
	if (!allocDib(m_size))
	{
		init();
		return false;
	}

	// copy BITMAPINFO
	unsigned char* pTemp = m_pDib;
	memcpy (pTemp, pDib,	m_offset);
	pTemp += m_offset;
	pDib  += m_offset;

	// copy image bytes 
	if(pBmih->biCompression == BI_RGB || pBmih->biCompression == BI_BITFIELDS)  // if image isn't compessed
	{
		DWORD height = abs(pBmih->biHeight);				 // rows num
		DWORD delta = strLengthAlign - strLength; // align size
		for (DWORD i = 0; i < height; i++)
		{
			memcpy( pTemp, pDib, strLength );
			memset( pTemp + strLength, 0, delta );
			pTemp += strLengthAlign;
			pDib  += strLengthAlign;
		}
	}
	else      // if image is compessed
		memcpy( pTemp, pDib, pBmih->biSizeImage);

	return true;
}

int CDib::setDibFromBmp(const char* pBmp, const DWORD size)
{
	if(!pBmp) return DIB_NULL_POINTER;

	m_size = size - sizeof(BITMAPFILEHEADER);
	// allocate memory for DIB 
	if (!allocDib(m_size))
		return DIB_NO_MEMORY;

	try
	{
		memcpy(m_pDib, pBmp + sizeof(BITMAPFILEHEADER), m_size);
	}
	catch (...)
	{
		return DIB_UNKNOWN_EXCEPTION;
	}
   if (!checkDib (m_pDib))
      return DIB_WRONG_FORMAT;

	// get offset to the image
	m_offset = getOffset((LPBITMAPINFOHEADER)m_pDib);

	return DIB_OK;

}

bool CDib::checkDib (const unsigned char * dib)
{
   BITMAPINFOHEADER *bih = (BITMAPINFOHEADER*)dib;
   if (bih->biBitCount != 0 && bih->biBitCount != 1 && bih->biBitCount != 4  && bih->biBitCount != 8
       && bih->biBitCount != 16 && bih->biBitCount != 24 && bih->biBitCount != 32)
       return false;
   if (bih->biCompression != BI_RGB && bih->biCompression != BI_RLE8 && bih->biCompression != BI_BITFIELDS
      && bih->biCompression != BI_JPEG && bih->biCompression != BI_PNG)
      return false;
   if (bih->biPlanes != 1) 
      return false;
   if (bih->biSize > sizeof(BITMAPV5HEADER))
      return false;
   return true;
}


DWORD CDib::getWidth() const
{
	if (!m_pDib) return 0;
	return ((LPBITMAPINFOHEADER)m_pDib)->biWidth;
}

DWORD CDib::getWidthAlign() const
{
	if (!m_pDib) return 0;
   LONG width = ((LPBITMAPINFOHEADER)m_pDib)->biWidth;
   width = (width + 3) / 4 * 4;
	return width;
}

DWORD CDib::getHeight() const
{
	if (!m_pDib) return 0;
	return abs(((LPBITMAPINFOHEADER)m_pDib)->biHeight);
}

LONG CDib::getSignHeight() const
{
	if (!m_pDib) return 0;
	return ((LPBITMAPINFOHEADER)m_pDib)->biHeight;
}

unsigned char* CDib::getImage() const
{
	if (!m_pDib || !m_offset)  
		return NULL;

	return m_pDib + m_offset;
}


/*
	Paint matrix to parent window 
	x0, y0 - position of the top left corner of the image on context
	if direct = true - use write directly to video memory
*/
#ifdef _WINDOWS
BOOL CDib::paint(HWND parent, int x0, int y0, double &m, bool direct) const
{
	if (!m_pDib)	return FALSE;
	if (!parent)	return FALSE;
	RECT rect;
	::GetClientRect (parent, &rect);
	int width = rect.right - rect.left;
	int height = rect.bottom - rect.top;
	HDC dc = ::GetDC (parent);

	BOOL bSuccess = FALSE;      

	LPBITMAPINFO bi = (LPBITMAPINFO)m_pDib;  
	LPBITMAPINFOHEADER bih = &(bi->bmiHeader);  
	unsigned char* bits = getImage();

	if (!bih->biHeight || !bih->biWidth)
		return false;

	/* Make sure to use the stretching mode best for color pictures */
	::SetStretchBltMode(dc, COLORONCOLOR);
	m = 0;
	if((float)abs(bih->biHeight) / bih->biWidth > (float)height / width) 
	{
		m = (double)height / abs(bih->biHeight);
		width = int(bih->biWidth * m);
	}
	else
	{
		m = (double)width / bih->biWidth;
		height = int(abs(bih->biHeight) * m);
	}

	HDRAWDIB hdd = NULL;
	if( direct )
		hdd = DrawDibOpen();
	if(hdd)
	{
		bSuccess = ::DrawDibDraw( hdd, dc, x0, y0, width, height, 
					&bi->bmiHeader, bits, 0, 0, bih->biWidth,
					abs(bih->biHeight), 0 ); 
		DrawDibClose(hdd);
		if( bSuccess ) return bSuccess;
	}
	bSuccess = ::StretchDIBits(dc, x0, y0, width, height, 0, 0, 
				bih->biWidth, abs(bih->biHeight), bits, bi, 
				DIB_RGB_COLORS, SRCCOPY ); 
   return bSuccess;
}
#endif

/*
	Create 8 bpp grey DIB 
	pImage - point to the image bytes (image bytes should be already 
		arranged)
	width, height - image size in pixels
*/
bool CDib::create8BitGray(const unsigned char* image, DWORD width, DWORD height)
{
	// get offset to the image and size whole DIB
	m_offset = sizeof(BITMAPINFOHEADER) + sizeof(RGBQUAD) * 256;
	DWORD rowLen = ((width + 3) >> 2) << 2;	// row length with align
	DWORD sizeImage = height *	rowLen;
	m_size = m_offset + sizeImage;

	// allocate memory for DIB 
	if (!allocDib(m_size))
		return false;

	memset(m_pDib, 0, m_size);

	// fill BITMAPINFOHEADER
	LPBITMAPINFOHEADER pBmih = (LPBITMAPINFOHEADER)m_pDib;  
	pBmih->biSize = sizeof(BITMAPINFOHEADER);
	pBmih->biWidth = width;
	pBmih->biHeight = -(LONG)height;
	pBmih->biPlanes = 1;
	pBmih->biBitCount = 8;
	pBmih->biCompression = BI_RGB;
	pBmih->biSizeImage = sizeImage;
	pBmih->biClrUsed = 256;
	pBmih->biClrImportant = 256;
	
	// fill RGBQUAD
	LPRGBQUAD pRGBQ = (LPRGBQUAD)((LPSTR)pBmih + pBmih->biSize);
	for( int i = 0; i < 256; i++ ) 
	{
		pRGBQ[i].rgbBlue	 =	
		pRGBQ[i].rgbGreen =	
		pRGBQ[i].rgbRed	 = i;	
	}
	
	// copy image bytes
	unsigned char* bits = m_pDib + m_offset;
	if(!image)	return true;

	unsigned char* dst = bits;
	unsigned char* src = (unsigned char*)image;
	// image bytes should already arranged
	memset(bits, 0, sizeImage);
	for (DWORD j = 0; j < height; j++)
	{
		memcpy(dst, src, width);
		dst += rowLen;
		src += width;
	}
	return true;
}



// get offset to the image bytes
DWORD CDib::getOffset(LPBITMAPINFOHEADER pBmih)
{
	return pBmih->biSize + getColorTableSize(pBmih);
}

// get bmiColors size
DWORD CDib::getColorTableSize(LPBITMAPINFOHEADER pBmih)
{
	if (!pBmih) return 0;
	if( pBmih->biClrUsed )
		return (pBmih->biClrUsed) * sizeof(RGBQUAD);

	WORD nBit = pBmih->biBitCount;
	if (nBit ==  1 || nBit ==  4 || nBit ==  8 )
		return sizeof(RGBQUAD) << nBit;

	if (nBit ==  16 || nBit == 24 || nBit == 32)
	{
		if( pBmih->biCompression == BI_BITFIELDS )
			 return 3 * sizeof(DWORD);

		if( pBmih->biCompression == BI_RGB )
			return 0;
	}
   assert(false);
	return 0;
}

bool CDib::allocDib(DWORD size)
{
	if (!size) return false;
   if (size <= m_allocSize)
      return true;
   if (m_pDib)
      freeDib();

	m_pDib = new unsigned char [size];
	if (!m_pDib) return false;
   m_allocSize = size;

	return true;
}

void CDib::init()
{
	m_pDib = NULL;
	m_size = 0;
   m_allocSize = 0;
	m_offset = 0;
}

void CDib::freeDib()
{
	if (m_pDib)
	{
		delete[] m_pDib;
		m_pDib = NULL;
      m_allocSize = 0;
	}
}	


// cut part of the image
bool CDib::cut (unsigned int x0, unsigned int y0, unsigned int width, unsigned int height)
{
	if(!m_pDib || (x0 + width) > getWidth() || (y0 + height) > getHeight()) 
		return false;

	LPBITMAPINFOHEADER pOldBmih = (LPBITMAPINFOHEADER)m_pDib;  
	unsigned char* pOldBits = m_pDib + m_offset;

	// old size 
	int oldWidth  = ((pOldBmih->biWidth * pOldBmih->biBitCount + 31) >> 5) << 2; 
	int oldHeight = abs(pOldBmih->biHeight);

	// length of new matrix row
	DWORD strLength = ((width * pOldBmih->biBitCount + 31) >> 5) << 2; 
	// new image size	
	DWORD sizeImage = strLength * height;    // new size of matrix
	// allocate memory for new image 
	unsigned char* pDib = NULL;
	m_size = sizeImage +  m_offset;
	pDib = new unsigned char[m_size];
	if (!pDib) return false;
	memset (pDib, 0, m_size);
	unsigned char* pBits = pDib + m_offset;

	// create header
	memcpy (pDib, m_pDib, m_offset); 
	LPBITMAPINFOHEADER pBmih = (LPBITMAPINFOHEADER)pDib;  
	pBmih->biWidth = width;
	pBmih->biHeight = (pOldBmih->biHeight > 0) ? height : -(int)height;
	pBmih->biSizeImage = sizeImage;

	x0 = ((x0 * pOldBmih->biBitCount + 7) >> 3);
   bool needFlip = pOldBmih->biHeight > 0;
	if (needFlip) turnOverX();
	if (!cut (pOldBits, oldWidth, oldHeight, x0, y0, strLength, height, pBits))
	{
		delete[] pDib;
		return false;
	}

	delete[] m_pDib;
	m_pDib = pDib;
	if (needFlip) turnOverX();

	return true;
}

/* 
	cut part of the source image  and put it to the destination image
	pSrc - source image
	srcWidth, srcHeight - size of source image 
	pDst - destination image that is part of the source image
	x0, y0 width, height - define size and location of the cutting area 
	NOTE: 
		all X dimensions (x0, width srcWidth) in bytes (not in pixels)
		all Y dimensions (y0, height srcHeight) in pixels 
*/
bool CDib::cut (unsigned char* pSrc, unsigned int srcWidth, unsigned int srcHeight,
				unsigned int x0, unsigned int y0, unsigned int width, unsigned int height,
				unsigned char* pDst)
{
	if (!pSrc || !pDst) return false;
	if((x0 + width) > srcWidth || (y0 + height) > srcHeight) 
		return false;
	
	// shift to left-bottom corner of new matrix
	int shift = (srcHeight - height - y0) * srcWidth + x0;    

	unsigned char* tempSrc = pSrc + shift;
	unsigned char* tempDst = pDst;
	
	// copy image
	for(unsigned int i = 0; i < height; i++ )
	{
		memcpy (tempDst, tempSrc, width);		
		tempSrc += srcWidth;
		tempDst += width;
	}

	return true;
}

// turn image over X and change the sign of bih->biHeight
bool CDib::turnOverXex ()
{
	bool result = turnOverX ();
	LPBITMAPINFOHEADER bih = (LPBITMAPINFOHEADER)m_pDib;
	bih->biHeight = - bih->biHeight;
	return result;
}

// turn image over X
bool CDib::turnOverX ()
{
	if (!m_pDib) return false;

	DWORD rowLen = getRowLen(); 
	DWORD height = getHeight(); 	
	unsigned char* pImage = getImage();

	int size = m_size - m_offset;
	unsigned char* pTemp = new unsigned char[size];
	if (!pTemp) return false;
	memcpy (pTemp, pImage, size);

	for (unsigned int i = 0; i < height; i++)
		memcpy (pImage + i * rowLen, pTemp + (height - i - 1) * rowLen, rowLen);

	delete[] pTemp;
	return true;
}

// invert image color
bool CDib::invert ()
{
	if (!m_pDib) return false;

	DWORD rowLen = getRowLen(); 
	DWORD height = getHeight(); 	
	DWORD width  = getWidth(); 	
	unsigned char* image = getImage();

	for (unsigned int y = 0; y < height; y++)
   {
   	for (unsigned int x = 0; x < width; x++)
      {
		   image[x] = 255 - image[x];
      }
      image += rowLen;
   }
   return true;
}


// turn image over Y
bool CDib::turnOverY ()
{
	if (!m_pDib) return false;

	DWORD height = getHeight();
	DWORD width = getWidth();
	DWORD rowLen = getRowLen(); 
	unsigned char* pImage = getImage();

	int size = m_size - m_offset;
	unsigned char* pTemp = new unsigned char[size];
	if (!pTemp) return false;
	memcpy (pTemp, pImage, size);

	int shift = 0;
	for (unsigned int j = 0; j < height; j++)
	{
		shift = j * rowLen;
		for (unsigned int i = 0; i < width; i++)
		{
			pImage[shift + i] = pTemp[shift + width - i - 1];
		}
	}
	delete[] pTemp;
	return true;
}

// return length of row
DWORD CDib::getRowLen()
{
	if (!m_pDib) return 0;
	LPBITMAPINFOHEADER pBmih = (LPBITMAPINFOHEADER)m_pDib;  
	return ((pBmih->biWidth * pBmih->biBitCount + 31) >> 5) << 2; 
}

int CDib::readBmp (const TCHAR* filename)
{
	FILE* f = _tfopen(filename, _T("rb"));
	if (!f) 
      return DIB_FILE_OPEN;
	// get file size
	if (fseek(f, 0, SEEK_END)) 
      return DIB_FILE_READ;
	int bmpSize = ftell (f);
	if (!bmpSize || bmpSize == -1) 
      return DIB_FILE_READ;
	if (fseek(f, 0, SEEK_SET)) 
      return DIB_FILE_READ;
	
	// read file to pBmp
	char* pBmp = new char[bmpSize];
	if(!pBmp) 
      return DIB_NO_MEMORY;
	memset(pBmp, 0, bmpSize);
	size_t len = fread (pBmp, 1, bmpSize, f);
	fclose(f);
 	if (len != (size_t)bmpSize)
	{
		delete[] pBmp;
		return DIB_FILE_READ;
	}
	
	int result = setDibFromBmp(pBmp, bmpSize);
	
	delete[] pBmp;
	return result;
}

bool CDib::save2Bmp (const TCHAR *filename)
{
	if (!m_pDib) 
      return false;

	BITMAPFILEHEADER bfh;
	unsigned int headerSize = sizeof (BITMAPFILEHEADER);
	memset (&bfh, 0, headerSize);
	bfh.bfType = 19778;
	bfh.bfOffBits = m_offset + headerSize ;
	bfh.bfSize = m_size + headerSize ;

	FILE* f = _tfopen(filename, _T("wb"));
	if (!f) return false;
	size_t size = fwrite ((void*)&bfh, 1, headerSize, f);
	if (size != headerSize) 
	{
		fclose (f);
		return false;
	}
	size = fwrite ((void*)m_pDib, 1, m_size, f);
	fclose (f);
	if (size != m_size) 
		return false;
	
	return true;
}


DWORD CDib::getImageSize() const
{
	if (!m_pDib) return 0;
	LPBITMAPINFOHEADER pBmih = (LPBITMAPINFOHEADER)m_pDib;  
	DWORD strLengthAlign = ((pBmih->biWidth * pBmih->biBitCount + 31 ) >> 5) << 2; 

	return abs(pBmih->biHeight) * strLengthAlign; 
}

/*
	strech image
	srcWidth, srcHeight - size of the source image
	dstWidth, dstHeight - size of the destination image
	kx, ky - stretching coefficients
	pSrc - source image
	pDst - destination image
	bpp - bit per pixels
*/
void CDib::stretch (const WORD srcWidth, const WORD srcHeight, const BYTE* pSrc, 
				   const float kx, const float  ky,
				   WORD& dstWidth, WORD& dstHeight, BYTE* pDst, int bpp)
{
	if (!pSrc || !pDst) return;

	double k1, k2;
	WORD x, y;
	dstHeight = WORD(srcHeight * ky);
	dstWidth = WORD(srcWidth * kx);

	WORD srcRow = ((srcWidth * bpp + 31) >> 5) << 2;		// source matrix row lenght
	WORD dstRow = ((dstWidth * bpp + 31) >> 5) << 2;		// destination matrix row lenght

	int srcShift = 0, dstShift = 0;
	for (WORD j = 0; j < dstHeight; j++)
	{
		y = WORD(j / ky);
		if (y > srcHeight - 2) 
			y = srcHeight - 2;
		k1 = j / ky - y;

		srcShift = y * srcRow;
		dstShift = j * dstRow;
		for (WORD i = 0; i < dstWidth - 1; i++)
		{
			x = WORD(i / kx);
			if (x > srcWidth - 2) 
				x = srcWidth - 2;
			k2 = i / kx - x;

			pDst[dstShift + i] = (unsigned char)(
				pSrc[srcShift + x] * (1 - k1) * (1 - k2) + 
				pSrc[srcShift + x + 1] * k2 * (1 - k1) + 
				pSrc[srcShift + srcRow + x] * k1 * ( 1 - k2) + 
				pSrc[srcShift + srcRow + x + 1] * k1 * k2
				);

		}
		pDst[dstShift + dstWidth - 1] = pSrc[srcShift + srcWidth - 1];

		for (int i = dstWidth; i < dstRow; i++)		// arrange the lines
			pDst[dstShift + i] = 0;

	}

}

