/*************************************************************************
   fileUtils.cpp: - implementation of utilites for work with files
 

   Version 1.0 from 25.09.2004
*************************************************************************/
#ifdef _WINDOWS
#include <windows.h>
#include <shlobj.h>
//#pragma comment(lib, "Shell32.lib")
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#include <locale>
#include "fileUtl.h"
#include "win2linGdi.h"

#ifndef  _CRT_SECURE_NO_WARNINGS 
#define  _CRT_SECURE_NO_WARNINGS 
#endif
 

/*
   get length of opened file f
   return FU_OK if success or error code otherwise
   f   - pointer to the open file
   len - pointer to variable that received length of file
*/
int getFileLen(FILE *f, size_t& len) 
{
	if (!f) 
      return FU_NOT_OPEN;

	if (fseek (f, 0, SEEK_END))
	{
		fclose (f);
		return FU_READ;
	}
   fpos_t size;
	if (fgetpos (f, &size))
	{
		fclose (f);
		return FU_READ;
	}
	if (fseek (f, 0L, SEEK_SET))
	{
		fclose (f);
		return FU_READ;
	}
#ifdef _WINDOWS
   len = (size_t)size;
#else
   len = (size_t)size.__pos;
#endif
	return FU_OK;
}

/*	
   read len bytes from opened file into buffer
	return FU_OK if success or error code otherwise
	memory for the buffer should be allocated befor function call
   f      - pointer to the open file
	buffer - buffer where file will be read
	size   - before function call it contains the size of the buffer, after function call 
	         it contains the real size of data that were read
   len - number of bytes thouse should be read
*/
int readFileContent(FILE *f, unsigned char *buffer, size_t *size, size_t len) 
{
	if (!buffer) 
      return FU_WRONG_POINTER;
	if (!f) 
      return FU_WRONG_POINTER;

   if (*size < len)
      return FU_MORE_DATA;
   *size = fread (buffer, 1, (size_t)len, f);
	if (*size != len) 
      return FU_READ;
	
	return FU_OK;
}


/*
	read file filename into buffer
	return FU_OK if success or error code otherwise
	memory for the buffer should be allocated befor function call
   f      - pointer to the open file
	buffer - buffer where file will be read
	size   - before function call it contains the size of the buffer, after function call 
	         it contains the real size of data that were read
*/
int readFromFile(FILE *f, unsigned char *buffer, size_t *size) 
{
   int result = FU_OK;
   size_t len = 0;
   if ((result = getFileLen (f, len)) != FU_OK)
      return result;
   return readFileContent (f, buffer, size, len);
}

#ifdef _WINDOWS
/*
	read file filename into buffer
	return FU_OK if success or error code otherwise
	memory for the buffer should be allocated befor function call
	buffer - buffer where file will be read
	size   - before function call it contains the size of the buffer, after function call 
	         it contains the real size of data that were read
*/
int readFile(const wchar_t *filename, unsigned char *buffer, size_t *size) 
{
	if (!filename) return -1;

	FILE *f = _wfopen (filename, L"rb");
	if (!f) return FU_OPEN;
	int result = readFromFile(f, buffer, size);
	fclose(f);
	return result;
}
#endif

int readFile(const char *filename, unsigned char *buffer, size_t *size) 
{
	if (!filename) return -1;

	FILE *f = fopen (filename, "rb");
	if (!f) 
      return FU_OPEN;
	int result = readFromFile(f, buffer, size);
	fclose(f);
	return result;
}

#ifdef _WINDOWS
// save image to bmp (image is copy as is)
bool save2Bmp(TCHAR* filename, const unsigned char *image, unsigned int width, 
			  unsigned  int height)
{
	// get offset to the image and size whole BMP
	DWORD offset = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + sizeof(RGBQUAD) * 256;
	DWORD rowLen = ((width + 3) >> 2) << 2;	// row length with align
	DWORD sizeImage = height *	rowLen;
	DWORD sizeBmp = offset + sizeImage;

	// fill BITMAPFILEHEADER
	BITMAPFILEHEADER bfh;
	memset (&bfh, 0, sizeof (BITMAPFILEHEADER));
	bfh.bfType = 19778;
	bfh.bfOffBits = offset;
	bfh.bfSize = sizeBmp;

	// fill BITMAPINFOHEADER
	BITMAPINFOHEADER bih;  
	memset(&bih, 0, sizeof(BITMAPINFOHEADER));
	bih.biSize = sizeof(BITMAPINFOHEADER);
	bih.biWidth = width;
	bih.biHeight = -((int)height);
	bih.biPlanes = 1;
	bih.biBitCount = 8;
	bih.biCompression = BI_RGB;
	bih.biSizeImage = sizeImage;
	bih.biClrUsed = 256;
	bih.biClrImportant = 256;
	bih.biXPelsPerMeter = 500 * 10000 / 254;
	bih.biYPelsPerMeter = 500 * 10000 / 254;
	
	// fill RGBQUAD
	RGBQUAD pRGBQ[256];
	for( int i = 0; i < 256; i++ ) 
	{
		pRGBQ[i].rgbBlue  =	
		pRGBQ[i].rgbGreen =	
		pRGBQ[i].rgbRed	  = (BYTE)i;	
	}
	
	// copy image bytes
	if(!image)	return false;


	FILE* f = _tfopen(filename, _T("wb"));
	if (!f) return false;
	size_t size1 = fwrite (&bfh, 1, sizeof (BITMAPFILEHEADER), f);
	size_t size2 = fwrite (&bih, 1, sizeof (BITMAPINFOHEADER), f);
	size_t size3 = fwrite (pRGBQ, 1, sizeof (RGBQUAD) << 8, f);
	size_t size4 = fwrite (image, 1, sizeImage, f);
	if (size1 != sizeof (BITMAPFILEHEADER) ||
		size2 != sizeof (BITMAPINFOHEADER) ||
		size3 != sizeof (RGBQUAD) << 8     ||
		size4 != sizeImage) 
	{
		fclose (f);
		return false;
	}
	fclose (f);

	return true;
}

// save image to BMP with add padding at the end of each row 
// (if width % 4 != 0)
bool save2BmpP(TCHAR* filename, const unsigned char *image, unsigned int width, 
			  unsigned  int height)
{
	// get offset to the image and size whole BMP
	DWORD offset = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + sizeof(RGBQUAD) * 256;
	DWORD rowLen = ((width + 3) >> 2) << 2;	// row length with align
	DWORD sizeImage = height *	rowLen;
	DWORD sizeBmp = offset + sizeImage;

	// fill BITMAPFILEHEADER
	BITMAPFILEHEADER bfh;
	memset (&bfh, 0, sizeof (BITMAPFILEHEADER));
	bfh.bfType = 19778;
	bfh.bfOffBits = offset;
	bfh.bfSize = sizeBmp;

	// fill BITMAPINFOHEADER
	BITMAPINFOHEADER bih;  
	memset(&bih, 0, sizeof(BITMAPINFOHEADER));
	bih.biSize = sizeof(BITMAPINFOHEADER);
	bih.biWidth = width;
	bih.biHeight = -((int)height);
	bih.biPlanes = 1;
	bih.biBitCount = 8;
	bih.biCompression = BI_RGB;
	bih.biSizeImage = sizeImage;
	bih.biClrUsed = 256;
	bih.biClrImportant = 256;
	bih.biXPelsPerMeter = 500 * 10000 / 254;
	bih.biYPelsPerMeter = 500 * 10000 / 254;
	
	// fill RGBQUAD
	RGBQUAD pRGBQ[256];
	for( int i = 0; i < 256; i++ ) 
	{
		pRGBQ[i].rgbBlue  =	
		pRGBQ[i].rgbGreen =	
		pRGBQ[i].rgbRed	  = (BYTE)i;	
      pRGBQ[i].rgbReserved = 0;
	}
	
	// copy image bytes
	if(!image)	return false;


	FILE* f = _tfopen(filename, _T("wb"));
	if (!f) return false;
	size_t size1 = fwrite (&bfh, 1, sizeof (BITMAPFILEHEADER), f);
	size_t size2 = fwrite (&bih, 1, sizeof (BITMAPINFOHEADER), f);
	size_t size3 = fwrite (pRGBQ, 1, sizeof (RGBQUAD) << 8, f);
	if (size1 != sizeof (BITMAPFILEHEADER) ||
		size2 != sizeof (BITMAPINFOHEADER) ||
		size3 != sizeof (RGBQUAD) << 8     
		) 
	{
		fclose (f);
		return false;
	}
	if (rowLen == width)
	{
		if (fwrite (image, 1, sizeImage, f) != sizeImage)
		{
			fclose (f);
			return false;
		}
	}
	else
	{
		char *src = (char*)image; 
		char *pad[] = {0, 0, 0};
		for(unsigned int i = 0; i < height; i++)
		{
			if (fwrite (src, 1, width, f) != width ||
				fwrite (pad, 1, rowLen - width, f) != rowLen - width)
				{
					fclose (f);
					return false;
				}
			src += width;
		}
	}
	fclose (f);
	return true;
}
#endif

bool createDib (unsigned char **dib, const unsigned char * image, int width, int height)
{
	if (!image || !width || !height)	return false;

	// get offset to the image and size whole BMP
	int offset = sizeof(BITMAPINFOHEADER) + sizeof(RGBQUAD) * 256;
	DWORD rowLen = ((width + 3) >> 2) << 2;	// row length with align
	DWORD sizeImage = height *	rowLen;
	int sizeDib = offset + sizeImage;
	*dib = new(std::nothrow) unsigned char[sizeDib];
	if (!*dib) return false;

	// fill BITMAPINFOHEADER
	LPBITMAPINFOHEADER bih = (LPBITMAPINFOHEADER)*dib;  
	memset(bih, 0, sizeof(BITMAPINFOHEADER));
	bih->biSize = sizeof(BITMAPINFOHEADER);
	bih->biWidth = width;
	bih->biHeight = -height;
	bih->biPlanes = 1;
	bih->biBitCount = 8;
	bih->biCompression = BI_RGB;
	bih->biSizeImage = sizeImage;
	bih->biClrUsed = 256;
	bih->biClrImportant = 256;
	bih->biXPelsPerMeter = 500 * 10000 / 254;
	bih->biYPelsPerMeter = 500 * 10000 / 254;
	
	// fill RGBQUAD
	RGBQUAD *rgb = (RGBQUAD*)(*dib + bih->biSize);
	for( int i = 0; i < 256; i++ ) 
	{
		rgb[i].rgbBlue     =	
		rgb[i].rgbGreen    =	
		rgb[i].rgbRed	   = (BYTE)i;	
		rgb[i].rgbReserved = 0;
	}
	
	// copy image bytes
	unsigned char *temp = *dib + offset;
	for(int i = 0; i < height; i++)
	{
		memcpy(temp, image, width);
		memset(temp + width, 0, rowLen - width);
		temp += rowLen;
		image += width;
	}

	return true;
}



#if defined (_WINDOWS) && !defined(_WIN32_WCE)
/*
	write data from buffer to file. If file does not exist the function create it. 
	If the directory, that include in the full path, does not exist - function create it also
	Parameters:
	fullPath (input) - full path to the file
	buffer (input)   - data that should be copy to file
	size (input)     - size of the data shat should be write to the file
	Return value:
	true if function successfull and else otherwise
*/
bool saveFileDir (std::wstring &fullPath, unsigned char* buffer,  DWORD size)
{
	HANDLE f = CreateFileW (fullPath.c_str(), FILE_WRITE_DATA, 0, 0, CREATE_ALWAYS, 
							FILE_ATTRIBUTE_NORMAL, 0);
    if (f == INVALID_HANDLE_VALUE)  // maybe there is no such directory
	{
		// get name of the directory and name of the file
		std::wstring dir, name;
		size_t pos = fullPath.rfind (_T('\\'));
		if (pos == std::wstring::npos) return false;
		dir = fullPath.substr (0, pos);
		name = fullPath.substr (pos + 1, fullPath.size() - pos - 1);
		// change dir to wchar_t type
		wchar_t buffer[_MAX_PATH];
		wcscpy_s(buffer, _MAX_PATH, dir.c_str());
		if (SHCreateDirectoryExW (0, buffer, NULL) != ERROR_SUCCESS) return false;
		f = CreateFileW(fullPath.c_str(), FILE_WRITE_DATA, 0, 0, CREATE_ALWAYS, 
							FILE_ATTRIBUTE_NORMAL, 0);
	    if (f == INVALID_HANDLE_VALUE) return false;
	}
	DWORD bytesWritten = 0;
	BOOL result = WriteFile(f, buffer, size, &bytesWritten, 0);
	CloseHandle(f);
	if (!result || bytesWritten != size) return false;
	
	return true;
}
bool saveFileDir (std::string &fullPath, unsigned char* buffer, DWORD size)
{
   char path[_MAX_PATH], dir[_MAX_PATH], *name;
   strcpy(path, fullPath.c_str());
   size_t len = strlen(path);
   for(size_t i = 0; i < len; i++)
      if (path[i] == '/') path[i] = '\\';

   HANDLE f = CreateFileA (path, FILE_WRITE_DATA, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
    if (f == INVALID_HANDLE_VALUE)  // maybe there is no such directory
	{
		// get name of the directory and name of the file
      strcpy(dir, path);
		char *c = strrchr (dir, '\\');
      if (!c) return false;
      c[1] = '\0';
		name = strrchr (path, '\\');
      name++; 
		// change dir to wchar_t type
		if (SHCreateDirectoryExA (0, dir, NULL) != ERROR_SUCCESS) return false;
		f = CreateFileA(path, FILE_WRITE_DATA, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	    if (f == INVALID_HANDLE_VALUE) return false;
	}
	DWORD bytesWritten = 0;
	BOOL result = WriteFile(f, buffer, size, &bytesWritten, 0);
	CloseHandle(f);
	if (!result || bytesWritten != size) return false;
	
	return true;
}
/*
bool saveFileDir (std::basic_string<TCHAR> &fullPath, unsigned char* buffer, unsigned int size)
{
	HANDLE f = CreateFile(fullPath.c_str(), FILE_WRITE_DATA, 0, 0, CREATE_ALWAYS, 
							FILE_ATTRIBUTE_NORMAL, 0);
    if (f == INVALID_HANDLE_VALUE)  // maybe there is no such directory
	{
		// get name of the directory and name of the file
		std::basic_string<TCHAR> dir, name;
		int pos = fullPath.rfind (_T('\\'));
		if (pos == std::basic_string<TCHAR>::npos) return false;
		dir = fullPath.substr (0, pos);
		name = fullPath.substr (pos + 1, fullPath.size() - pos - 1);
		// change dir to wchar_t type
		wchar_t buffer[_MAX_PATH];
#ifdef UNICODE
		wcscpy(buffer, dir.c_str());
#else
		char temp[_MAX_PATH];
		strcpy(temp, dir.c_str());
		std::locale loc;
		std::use_facet<std::ctype<wchar_t> >(loc).widen 
			(temp, temp + strlen(temp), buffer);
		buffer[strlen(temp)] = 0;
#endif
		if (SHCreateDirectory (0, buffer) != ERROR_SUCCESS) return false;
		f = CreateFile(fullPath.c_str(), FILE_WRITE_DATA, 0, 0, CREATE_ALWAYS, 
							FILE_ATTRIBUTE_NORMAL, 0);
	    if (f == INVALID_HANDLE_VALUE) return false;
	}
	DWORD bytesWritten = 0;
	BOOL result = WriteFile(f, buffer, size, &bytesWritten, 0);
	CloseHandle(f);
	if (!result || bytesWritten != size) return false;
	
	return true;
}
*/
#endif

int saveFile (char *name, unsigned char *buffer, size_t size)
{
   FILE *f = fopen (name, "wb");
   if (!f)
      return FU_OPEN;
   bool result = (fwrite (buffer, 1, size, f) == size);
   fclose (f);
   return result ? FU_OK : FU_WRITE;
}

#ifdef _WINDOWS
int saveFile (wchar_t *name, unsigned char *buffer, size_t size)
{
   FILE *f = _wfopen (name, L"wb");
   if (!f)
      return FU_OPEN;
   bool result = (fwrite (buffer, 1, size, f) == size);
   fclose (f);
   return result ? FU_OK : FU_WRITE;
}
#endif

int saveFile (const char *name, unsigned char *buffer, size_t size)
{
   return saveFile((char*)name, buffer, size);
}

#ifdef _WINDOWS
int saveFile (const wchar_t *name, unsigned char *buffer, size_t size)
{
   return saveFile((wchar_t*)name, buffer, size);
}
#endif