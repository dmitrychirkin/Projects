#ifndef ACCEL_H_
#define ACCEL_H_

#include <assert.h>

#include "accelMatch.h"
#include "sse_proxy.h"


namespace accelMatch{
#pragma pack(push, _CORE_PACKING)

#define MAX_ACCEL               64                      // maximum number of minutiae that keeps in accelerator
#define NUM_REL_POINTS          64//32                  // number of reliable points when there is no penalty for quality
#define MAX_ACCEL_MIN          255                      // maximum number of minutiae in accelerator
#define SAME_DIR_VAL            16                      // addition to accelerator value for same direction    
#define MAX_ACCEL_LINK_DIST     (SAME_DIR_VAL - 2)      // maximum acceptable distance from central point to link point in accel
                                                        // we need to guarantie difference more than 1 for two values:                  
                                                        // (dir = 0, dist = MAX_ACCEL_LINK_DISP) and (dir = 1, dist = 0)
#define MIN_RANDOM_VAL          (SAME_DIR_VAL * 2)      // minimum value for fill the empty links of accelerator (it should be differ more 
                                                        // than 1 from the maximum possible real accelerator value




#pragma pack(push, 1)
struct P_PACKED_1 MinutiaeData
{
   short x;                   // minutiae x            // NOTE: cannot be unsigned, because after translation P2G or G2P can be negative
   short y;                   // minutiae y   
   BYTE  a;                   // minutiae angle
//   BYTE  p;                   // minutie probability
};
#pragma pack(pop)

//struct MainAccel
//{
//    __m128i accel[2];            // accelerators for: 0 - concordance minutiae  1 - opposite minutiae
//};



struct SortedAccel
{
    Accel *sortedAccel[MAX_ACCEL_MIN];
};

struct AnchorAccel
{
    Accel *accel;
    BYTE   dist;
    BYTE   fill;
    BYTE   num; 

    AnchorAccel()
    {
       accel = NULL;
       dist  = 0;
       fill  = 0;
       num   = 0;
    }
};

enum MainAccelMask
{
   MAIN_ACCEL_RIGHT_LOOP    = 1,
   MAIN_ACCEL_LEFT_LOOP     = 2,
   MAIN_ACCEL_WHORL         = 4,
   MAIN_ACCEL_UNKNOWN_LOOP  = (MAIN_ACCEL_RIGHT_LOOP  + MAIN_ACCEL_LEFT_LOOP),
   MAIN_ACCEL_UNKNOWN_TYPE  =  0xff,
};

#pragma pack(push, 1)
struct P_PACKED_1 AllAccel              // sizeof of this structure shouls be alligned to 16!!!        
{
   BYTE           numMinutiae;           // number of minutiae that keep in minutiae array
   BYTE           numAccel;              // whole number of accelerators that keep in accel array
   BYTE           quality;               // fingerprint quality   
   BYTE           num_fill_n[13];        // num_fill_n[k] number of accelerators with n + 4 link
   
   BYTE           patternType;           
   short          anchorX; 
   short          anchorY; 
//   short          anchorA; 
   BYTE           numRelMin;
   BYTE           modQuality;
   BYTE           reserved[9];  

   AllAccel()
   {
      clear();
   }
   void clear()
   {
      memset (this, 0, sizeof(AllAccel));
      anchorX = anchorY = -1;
   }
};
#pragma pack(pop)

inline unsigned int getAccelDataSize(AllAccel *allAccel)
{
   if (!allAccel)
      return 0;
   unsigned int size = sizeof(AllAccel) 
//            + sizeof(MainAccel)
//            + (sizeof(Accel) + 3 * sizeof(BYTE)) * allAccel->numAccel
//            + (sizeof(Accel) + 1 * sizeof(BYTE)) * allAccel->numAccel
            + (sizeof(Accel) + 2 * sizeof(BYTE)) * allAccel->numAccel
            + sizeof(MinutiaeData) * allAccel->numMinutiae;
   if (size % 16)
      size = (size + 15) / 16 * 16;
   return size;
                               
}

inline unsigned int copyAccelData2buffer(BYTE* buffer, AllAccel *header, 
                          MinutiaeData *minutiae, Accel *accel, BYTE *num
                          /*, MainAccel &mainAccel, BYTE *dist2Anchor*/, BYTE *accelSign, BYTE *quality)
{
   int fullSize = 0;
   // copy header
   unsigned int size = sizeof(AllAccel);
   memcpy(buffer, header, size);
   buffer   += size;
   fullSize += size;
   // copy accelerator
   size = sizeof(accel[0]) * header->numAccel;
   memcpy(buffer, accel, size);
   buffer   += size;
   fullSize += size;
   //// copy main accel
   //size = sizeof(MainAccel);
   //memcpy(buffer, &mainAccel, size);
   //buffer   += size;
   //fullSize += size;
   // copy distance to anchor point
   //size = sizeof(dist2Anchor[0]) * header->numAccel;
   //memcpy(buffer, dist2Anchor, size);
   //buffer   += size;
   //fullSize += size;
   // copy accelerator's number
   size = sizeof(num[0]) * header->numAccel;
   memcpy(buffer, num, size);
   buffer   += size;
   fullSize += size;
   //// copy accel sign
   //size = sizeof(accelSign[0]) * header->numAccel;
   //memcpy(buffer, accelSign, size);
   //buffer   += size;
   //fullSize += size;
   // copy accel quality
   size = sizeof(quality[0]) * header->numAccel;
   memcpy(buffer, quality, size);
   buffer   += size;
   fullSize += size;
   // copy minutiae
   size = sizeof(minutiae[0]) * header->numMinutiae;
   memcpy(buffer, minutiae, size);
   buffer   += size;
   fullSize += size;
   // add some 0 at the end to align accel on 16
   int paddingSize = (fullSize + 15) / 16 * 16 - fullSize;
   memset(buffer, 0, paddingSize);
   fullSize += paddingSize;
   return fullSize;
}

inline AllAccel* assignHeader (BYTE* buffer)
{
   return (AllAccel*)buffer;
}

inline  Accel* assignAccelerator (BYTE* buffer)
{
   return (Accel*)(buffer + sizeof(AllAccel));
}

//inline MainAccel* assignMainAccel (BYTE* buffer, AllAccel *header)
//{
//   return (MainAccel*)(buffer + sizeof(AllAccel) + sizeof(Accel) * header->numAccel);
//}

//inline BYTE* assignDist2Anchor (BYTE* buffer, AllAccel *header)
//{
//   return (BYTE*)(buffer + sizeof(AllAccel)// + sizeof(MainAccel)
//                         + sizeof(Accel)    * header->numAccel);
//}

inline BYTE* assignAcceleratorNum (BYTE* buffer, AllAccel *header)
{
   return (BYTE*)(buffer + sizeof(AllAccel) //+ sizeof(MainAccel)
                         + sizeof(Accel) * header->numAccel);
}

//inline BYTE* assignAcceleratorSign (BYTE* buffer, AllAccel *header)
//{
//   return (BYTE*)(buffer + sizeof(AllAccel) //+ sizeof(MainAccel)
//                         + (sizeof(Accel) + sizeof(BYTE)) * header->numAccel);
//}
//
inline BYTE* assignAcceleratorQuality (BYTE* buffer, AllAccel *header)
{
   return (BYTE*)(buffer + sizeof(AllAccel) //+ sizeof(MainAccel)
//                         + (sizeof(Accel) + 2 * sizeof(BYTE)) * header->numAccel);
                         + (sizeof(Accel) + 1 * sizeof(BYTE)) * header->numAccel);
}


inline MinutiaeData* assignMinutiae (BYTE* buffer, AllAccel *header)
{
   return (MinutiaeData*)(buffer + sizeof(AllAccel) //+ sizeof(MainAccel)
//                                 + (sizeof(Accel) + 3 * sizeof(BYTE)) * header->numAccel);
//                                 + (sizeof(Accel) + 1 * sizeof(BYTE)) * header->numAccel);
                                 + (sizeof(Accel) + 2 * sizeof(BYTE)) * header->numAccel);
}


inline void getSortedAccelerator (AllAccel *header, Accel *accel, BYTE  *accelNum, SortedAccel *sortedAccel)
{
   assert (header && sortedAccel && sortedAccel->sortedAccel && accel && accelNum);
   memset(sortedAccel->sortedAccel, 0, sizeof(sortedAccel->sortedAccel[0]) * header->numMinutiae);
   int numAccel = header->numAccel;
   for(int i = 0; i < numAccel; i++)
   {
      assert (accelNum[i] < header->numMinutiae);
      sortedAccel->sortedAccel[accelNum[i]] = &accel[i];
   }
}

//inline int compareDistAccel (const void* p1, const void* p2)
//{
//   return ((AnchorAccel*)p1)->dist - ((AnchorAccel*)p2)->dist;
//}
//
//inline void getAnchorSortedAccel (AllAccel *header, BYTE numAccel, Accel *accel, BYTE *dist2Anchor, BYTE *accelNum, AnchorAccel *anchorAccel)
//{
//   for (BYTE i = 0; i < numAccel; i++)
//   {
//      anchorAccel[i].accel = &accel[i];
//      anchorAccel[i].dist  = dist2Anchor[i];
//      anchorAccel[i].num   = accelNum[i];
//   }
//   int j = 0;
//   for (BYTE i = 16; i >= 4; i--)
//   {
//      BYTE num = header->num_fill_n[i - 4]; 
//      for(; j < num && j < numAccel; j++)
//        anchorAccel[j].fill = i;
//   }
//   qsort (anchorAccel, numAccel, sizeof(AnchorAccel), compareDistAccel);
//}
//
//inline void getAccelFill (AllAccel *header, BYTE *fill)
//{
//   BYTE numAccel = header->numAccel;
//   int j = 0;
//   for (BYTE i = 16; i >= 4; i--)
//   {
//      BYTE num = header->num_fill_n[i - 4]; 
//      for(; j < num && j < numAccel; j++)
//        fill[j] = i;
//   }
//}


#pragma pack(pop)
} // namespace accelMatch{

#endif  // ACCEL_H_



