#ifndef STATIC_DATA_100_H_
#define STATIC_DATA_100_H_

#include "coreSdk.h"

namespace accelMatch{
#pragma pack(push,_CORE_PACKING)
#define MAX_NUM_LINKS         35

   //   event description (link point)
#define ERO_   0xd  // right ending -><- (��������� ������ ������ ����)
#define EROX   0x9  // right beginning (�� ����)
#define ELO_   0xe  // left ending -><-
#define ELOX   0xa  // left beginning
#define ERV_   0x5  // right bifurcation closing -><-  (����� ������ ������ ����)
#define ERVX   0x1  // right bifurcation opening
#define ELV_   0x6  // left bifurcation closing -><-
#define ELVX   0x2  // left bifurcation openning
#define EO     0xf  // ending
#define EV     0x3  // bifurcation (����� �� ��������� �����)
#define EV1    0x7  // bifurcation anti clockwize (�� 1 �����)
#define EV2    0xb  // bifurcation clockwize

enum Transition
{
   NT       = 0,           // no transition

   TL_1     = NT + 1,      // 1st transiton  level
   E2LB_1   = TL_1 + 0,    // endian to left bifurcation
   E2RB_1   = TL_1 + 1,    // edian to right bifurcation
   B2RE_1   = TL_1 + 2,    // bifurcation to right endian
   B2LE_1   = TL_1 + 3,    // bifurcation to left endian
   TL_1_MAX = TL_1 + 3,

   TL_2     = TL_1 + 4,    // 2st transiton  level
   B2LB_2   = TL_2 + 0,    // bifurcation to left bifurcation  
   B2RB_2   = TL_2 + 1,    // bifurcation to right bifurcation 
   E2RE_2   = TL_2 + 2,
   E2LE_2   = TL_2 + 3,
   TL_2_MAX = TL_2 + 3,

   TL_3     = TL_2 + 4,    // 3rd transiton  level
   E2LB_3   = TL_3 + 0,
   E2RB_3   = TL_3 + 1,
   B2LE_3   = TL_3 + 2,
   B2RE_3   = TL_3 + 3,
   TL_3_MAX = TL_3 + 3,
   
   TL_4     = TL_3 + 4,    // 4th transiton  level
   B2LB_4   = TL_4 + 0,
   B2RB_4   = TL_4 + 1,
   E2LE_4   = TL_4 + 2,
   E2RE_4   = TL_4 + 3,
   TL_4_MAX = TL_1 + 4,

   TL_5     = TL_4 + 4,    // 5th transiton  level
   B2LE_5   = TL_5 + 0,
   B2RE_5   = TL_5 + 1,
   E2LB_5   = TL_5 + 2,
   E2RB_5   = TL_5 + 3,
   TL_5_MAX = TL_5 + 3,

   TL_6     = TL_5 + 4,    // 5th transiton  level
   B2LB_6   = TL_6 + 0,
   B2RB_6   = TL_6 + 1,
   E2LE_6   = TL_6 + 2,
   E2RE_6   = TL_6 + 3,
   TL_6_MAX = TL_6 + 3,

   MPT      = E2RE_6,     // maximum possible transiton
   _        = MPT  + 1,   // not allowed transition
   UNKN     = MPT  + 2    // unknown transition
};


// matrix for getting transition of the minutiae
// first index  - number of event on probe fingerprint
// second index - number of event on gallery fingerprint
extern Transition T2T[16][16];

extern int  TransitionMatrix[TL_3][MAX_NUM_LINKS];
// number of quadrants
extern unsigned int  Quadrant[2][MAX_NUM_LINKS];
// ridge count
extern int ridgeCount[2][MAX_NUM_LINKS];
extern int ridgeCountE[33][16];
extern int ridgeCountB[35][16];
//extern int ridgeCount[2][MAX_NUM_LINKS];
// ridge count correction for 4 quadrant and 16 events
//extern int rc_correct[4][16];
extern int  sum256[256];
// return 1 if link on the right and 0 - otherwise 
// first parameter type, second - link number
extern bool isRightLink[2][MAX_NUM_LINKS];
// return 1 if link in 1st or 2nd quadrant(up of section) and 0 - otherwise 
// first parameter type, second - link number
extern bool isUpLink[2][MAX_NUM_LINKS];
 // says if quadrant with given number if left
extern bool isLeftQuadrant[4]; 
extern bool isDownQuadrant[4];
extern bool isSameDir[16];
// change deal of pink link to deal of mirror link
   // change of link number for endian pink links
   //extern int endianPinkMirror[2][MAX_NUM_LINKS][2];
// mirror links number
extern int  linkMirror[2][MAX_NUM_LINKS];
extern int  oppositeQuadrants[4];
extern int  nextQuadrants[4];
extern int  mirrorQuadrants[4];
extern int  linkNumber[2][4][9];

#define MAX_ACCEL_VAL         2500             // = pow(50, 2)

inline int getTransitionLevel(Transition transition)
{
   if      (transition <  TL_1) return  0;
   else if (transition <  TL_2) return  1;
   else if (transition <  TL_3) return  2;
   else if (transition <  TL_4) return  3;
   else if (transition <  TL_5) return  4;
   else if (transition <  TL_6) return  5;
   else if (transition <=  MPT) return  6;
   else                         return -1;   
}
//*
inline bool isLeftProjection    ( int deal ) { return  ((deal==13)||(deal==9 )||(deal==5)||(deal==1)); }
inline bool isRightProjection   ( int deal ) { return  ((deal==14)||(deal==10)||(deal==6)||(deal==2)); }

inline bool isProjectionFromRight( int deal ) { return  ((deal==13)||(deal==9 )||(deal==5)||(deal==1)); }
inline bool isProjectionFromLeft ( int deal ) { return  ((deal==14)||(deal==10)||(deal==6)||(deal==2)); }
inline bool isProjection        ( int deal ) { return !((deal==15)||(deal==11)||(deal==7)||(deal==3)); }
// return true if link minutiae has same direction as central minutiae
inline bool isSameDirection     ( int deal, int quadrant )
{
   if ( isDownQuadrant[ quadrant ] )  return  isSameDir[deal];
   else                               return !isSameDir[deal];
}
inline bool isSameDirection     ( int deal, MINUTIAE_TYPE type, int linkNum )
{
   return isSameDirection( deal, Quadrant[type][linkNum] );
}
inline bool isRight             ( MINUTIAE_TYPE type, int linkNum)
{
   return isRightLink[(int)type][linkNum];
}
inline bool isUp                ( MINUTIAE_TYPE type, int linkNum)
{
   return isUpLink[(int)type][linkNum];
}
inline bool isUpQuad            ( int q   ) { return ( ( q == 1 ) || ( q == 2 ) ); }
inline bool isLeftQuad          ( int q   ) { return ( ( q == 0 ) || ( q == 1 ) ); }
inline bool isDownQuad          ( int q   ) { return ( ( q == 0 ) || ( q == 3 ) ); }
inline bool isEnding            ( int deal)
{
   return (deal == ERO_ || deal == EROX || deal == ELO_ || deal == ELOX || deal == EO);
}
inline bool isBifurcation       ( int deal)
{
   return !isEnding (deal);
}
inline bool isOppositeQuadrants ( int q1  , int q2)
{
   return (q1 == oppositeQuadrants[q2]);
}
inline bool isNextQuadrants     ( int q1  , int q2)
{
   return (q1 == nextQuadrants[q2]);
}
inline int  calcRidgeCount      ( int type, int link, int deal, unsigned int &quadrant ) 
{
   int rc = ( type == ENDING ? ridgeCountE[link][deal] : ridgeCountB[link][deal] );
/*
   if ( type == BIFURCATION ) 
   {
      if ( link == 1 && rc == -1 ) { quadrant = 0; return 0; }
      if ( link == 2 && rc ==  1 ) { quadrant = 3; return 0; }
   }
*/
   quadrant = Quadrant[type][link]; 

   if( isLeftQuad( quadrant ) )
   {
      if ( rc > 0 ) quadrant = nextQuadrants[ quadrant ];
   } 
   else 
   {
      if ( rc < 0 ) quadrant = nextQuadrants[ quadrant ];
   }

   return rc;
}
inline int  calcRidgeCount      ( int type, int link, int deal ) 
{
   return ( type == ENDING ? ridgeCountE[link][deal] : ridgeCountB[link][deal] );
/*
   int quadrant = 0; 
   return calcRidgeCount( type, link, deal, quadrant );
*/
}
//inline int  compareTransition   ( Transition t1, Transition t2 )
//{
//   if( t1 != NT && t2 != NT )
//   {
//      if     ( t1 < TL_2 ) t1 = TL_2;
//      else if( t1 < TL_3 ) t1 = TL_3;
//
//      if     ( t2 < TL_2 ) t2 = TL_2;
//      else if( t2 < TL_3 ) t2 = TL_3;
//   }
//
//   return  t1 - t2;
//}

inline unsigned int  getQuadrantEx  (unsigned int link, unsigned int type, unsigned int deal, bool &quadrantChanged)
{
   quadrantChanged = false;          // flag - if projection from another quadrant
   if (type == ENDING && link < 5) 
   {
      if (link == 0) 
      {
         if (deal ==  7)                
         {
            quadrantChanged = true;
            return 3;                     // ������!!!
         }
         else if (isProjectionFromLeft (deal)) 
         {
            quadrantChanged = true;
            return 3;
         }
      } 
      else
      {
         if (link == 2 && isProjectionFromRight (deal) ) 
         {
            quadrantChanged = true;
            return 2; 
         }
         else if (link == 3 && isProjectionFromLeft  (deal) ) 
         {
            quadrantChanged = true;
            return 1; 
         }
         else if (link == 4 && isProjectionFromRight (deal) ) 
         {
            quadrantChanged = true;
            return 0; 
         }
      }
   }
   else if (type == BIFURCATION && link < 7)
   {
      switch (link)
      {
      case 0: 
         if (deal == 11) 
         {
            quadrantChanged = true;
            return 2;                     // ������!!!
         }
         else if (isProjectionFromRight (deal) ) 
         {
            quadrantChanged = true;
            return 2; 
         }
         break;
      case 1: 
         if (isProjectionFromRight (deal) ) 
         {
            quadrantChanged = true;
            return 0;  
         }
         break;
      case 2: 
         if (isProjectionFromLeft  (deal) ) 
         {
            quadrantChanged = true;
            return 3;  
         }
         break;
      case 5: 
         if (isProjectionFromLeft  (deal) ) 
         {
            quadrantChanged = true;
            return 1;  
         }
         break;
      default: break;
      }
   }

   return Quadrant[type][link];
}


#pragma pack(pop)
} // namespace accelMatch{

#endif //STATIC_DATA_100_H_
