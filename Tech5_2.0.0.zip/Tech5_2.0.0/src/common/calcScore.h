#ifndef CALC_SCORE_H
#define CALC_SCORE_H

#include "accelAdjust.h"

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)

#define SCORE_ACCEL_PARAM_SIZE 14
extern int g_scoreParam_73[SCORE_ACCEL_PARAM_SIZE];
extern int g_scoreParam_140[SCORE_ACCEL_PARAM_SIZE];

int calcScore(AccelScoreParam &param, int *scoreParam);

#pragma pack(pop)
} // namespace accelMatch{

#endif // CALC_SCORE_H
