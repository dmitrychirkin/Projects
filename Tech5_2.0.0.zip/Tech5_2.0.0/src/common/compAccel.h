#ifndef COMP_ACCEL_H_
#define COMP_ACCEL_H_

#include "accelMatch.h"
#include "accelPair.h"
#include "win2lin.h"
#include "sse_proxy.h"


namespace accelMatch{
#pragma pack(push, _CORE_PACKING)


#define MAX_TRIPLETS                   64//128//64                   // maximum pairs after accel compare
#define MAX_SORTED_TRIPLETS            40//80//40                   // maximum pairs after accel compare, sorted by accel differences
#define MAX_LOCAL_GROUP_1ST            20//40//20                   // maximum local groups (minutiae with it's neighbours by link) before 1st pass
#define MAX_LOCAL_GROUP_2ND            20//40//20                   // maximum local groups (minutiae with it's neighbours by link) before 2nd pass
#define MAX_SORTED_LOCAL_GROUP         5                    // maximum local groups after sorting

unsigned int getMaximOneFingerFullAccelSize();


struct Triplet
{
   BYTE      i;
   BYTE      j;
   WORD    sim; 
};


// thin out the accel group
void thinOut (AccelPair &accelPair, AllAccel &ap, AllAccel &ag);
// NOTE: aP, aG should be sorted!

//static __m128i g_nul_res;
//inline unsigned  int getAccelSim  (Accel *aP, Accel *aG)
//{
//   __m128i res = _mm_cmpeq_epi8 (aP->accel, aG->accel);
//   __m128i dif = _mm_sad_epu8 (res, g_nul_res);
//   return (((m128i_my*)&dif)->m128i_u32[0] + ((m128i_my*)&dif)->m128i_u32[2]);//  >> 8;
//}

//inline unsigned int getMainAccelSim  (MainAccel *aP, MainAccel *aG)
//{
//   __m128i dif;
//   unsigned int sim = 0;
//   for (size_t i = 0; i < 2; i++)
//   {
//      dif = _mm_and_si128 (aP->accel[i], aG->accel[i]);
////    dif = _mm_xor_si128 (aP->accel, aG->accel);
//      sim += (BYTE)(_mm_popcnt_u64 (dif.m128i_u64[0]) + _mm_popcnt_u64 (dif.m128i_u64[1]));
//   }
//   return sim;
//}
//
//inline unsigned int getMainAccelFill  (MainAccel *aP)
//{
//   unsigned int fill = 0;
//   __m128i dif;
//   for (size_t i = 0; i < 2; i++)
//   {
//      dif = _mm_and_si128 (aP->accel[i], aP->accel[i]);
//      fill += (unsigned int)(_mm_popcnt_u64 (dif.m128i_u64[0]) + _mm_popcnt_u64 (dif.m128i_u64[1]));
//   }
//   return fill;
//}


inline int getNormalValueEx (int min, int max, int val)
{
   return (val - min) * 100 / (max - min);
}


#pragma pack(pop)
} // namespace accelMatch{


#endif   // COMP_ACCEL_H_
