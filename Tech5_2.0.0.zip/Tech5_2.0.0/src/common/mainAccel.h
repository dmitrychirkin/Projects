#ifndef MAIN_ACCEL_H_
#define MAIN_ACCEL_H_

#include <assert.h>

#include "accel.h"
#include "compAccel.h"
#include "Unwrap.h"

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)

const int MAIN_ACCEL_DIST_STEP    = 20;   
const int MAIN_ACCEL_DIST_D_STEP  = MAIN_ACCEL_DIST_STEP / 4;   
const int MAIN_ACCEL_MAX_DIST     = MAIN_ACCEL_DIST_STEP * 9 - 1;
const int MAIN_ACCEL_ANG_STEP     = 360 / 16 + 1;   
const int MAIN_ACCEL_ANG_D_STEP   = MAIN_ACCEL_ANG_STEP / 4;   

enum CONCORD_STATE
{
   CONCORD  = 0,
   OPPOSITE = 1,
   BOTH     = 2
};

//inline void addBit2MainAccel (MainAccel &mainAccel, unsigned int angleStep, unsigned int distStep, CONCORD_STATE concordState)
//{
//   assert (angleStep <= 15 && distStep <= 7); 
//   if (concordState == CONCORD  || concordState == BOTH) mainAccel.accel[0].m128i_u8[angleStep] |= 1 << distStep;
//   if (concordState == OPPOSITE || concordState == BOTH) mainAccel.accel[1].m128i_u8[angleStep] |= 1 << distStep;
//}
//
//inline void addBit2MainAccelEx (MainAccel &mainAccel, unsigned int angleStep, unsigned int distStep, 
//                                bool addDistLess, bool addDistMore, CONCORD_STATE concordState)
//{
//   addBit2MainAccel (mainAccel, angleStep, distStep, concordState);
//   if (addDistLess)
//   {
//      if (distStep > 0) addBit2MainAccel (mainAccel, angleStep, distStep - 1, concordState);
//   }
//   else if (addDistMore)
//   {
//      if (distStep < 7) addBit2MainAccel (mainAccel, angleStep, distStep + 1, concordState);
//   }
//}
//
//inline void calcMainAccel (MainAccel &mainAccel, int anchorX, int anchorY, int anchorA, ESK::Nest *nest, size_t numNest, 
//                           bool isSearch, BYTE &fill)
//{
//   int len = 0, angle = 0, ang = 0, distStep = 0, angleStep = 0, dStep = 0, dAngle = 0, addAngleStep = 0, concordAngle = 0;
//   bool addDistLess = false, addDistMore = false, addAngleLess = false, addAngleMore = false;
//   CONCORD_STATE concordState;
//   MainAccel tempAccel;
//   memset (&mainAccel, 0, sizeof(MainAccel));
//   memset (&tempAccel, 0, sizeof(MainAccel));
//   for (size_t i = 0; i < numNest; i++)
//   {
//      len = dist ((int)nest[i].Movx, (int)nest[i].Movy, anchorX, anchorY);
//      if (len > MAIN_ACCEL_MAX_DIST || len < MAIN_ACCEL_DIST_STEP - MAIN_ACCEL_DIST_D_STEP)    
//         continue;
//      distStep = (len - MAIN_ACCEL_DIST_STEP) / MAIN_ACCEL_DIST_STEP; 
//      assert (distStep < 8);
////      if (isSearch)
//      {
//         addDistLess = false, addDistMore = false;
//         dStep = len % MAIN_ACCEL_DIST_STEP; 
//         if      (dStep < MAIN_ACCEL_DIST_D_STEP                       ) addDistLess = true;
//         else if (dStep > MAIN_ACCEL_DIST_STEP - MAIN_ACCEL_DIST_D_STEP) addDistMore = true;
//      }
//      ang = atan ((int)nest[i].Movx - anchorX, (int)nest[i].Movy - anchorY);
//      angle = normAngle360(ang - anchorA);
//      angleStep = angle / MAIN_ACCEL_ANG_STEP;
//      assert(angleStep < 16);
////      if (isSearch)
//      {
//         addAngleLess = false, addAngleMore = false;
//         dAngle = angle % MAIN_ACCEL_ANG_STEP;
//         if      (dAngle < MAIN_ACCEL_ANG_D_STEP                                                             ) addAngleLess = true;
//         else if (dAngle > MAIN_ACCEL_ANG_STEP - MAIN_ACCEL_ANG_D_STEP || angle > 360 - MAIN_ACCEL_ANG_D_STEP) addAngleMore = true;
//      }
//      concordAngle = abs(normAngle (nest[i].Beta - anchorA));
//      if      (concordAngle <  80) concordState = CONCORD;
//      else if (concordAngle > 100) concordState = OPPOSITE;
//      else                         concordState = BOTH;  
//
//      addBit2MainAccelEx (mainAccel, angleStep, distStep, addDistLess, addDistMore, concordState);
//      addBit2MainAccel (tempAccel, angleStep, distStep, concordState);
//      if (addAngleLess || addAngleMore)
//      {
//         if      (addAngleLess) addAngleStep = (angleStep ==  0) ? 15 : angleStep - 1; 
//         else if (addAngleMore) addAngleStep = (angleStep == 15) ?  0 : angleStep + 1; 
//         addBit2MainAccelEx (mainAccel, addAngleStep, distStep, addDistLess, addDistMore, concordState);
//      }
//   }
//   fill = getMainAccelFill (&tempAccel);
////   fill = getMainAccelFill (&mainAccel);
//}
//
//
//inline void setMainAccel (AllAccel &allAccel, MainAccelMask mainAccelMask, MainAccel &mainAccel, int anchorX, int anchorY, int anchorA,
//                     ESK::Nest *nest, size_t numNest, bool isSearch)
//{
//   memset (&mainAccel, 0, sizeof(MainAccel));
//   allAccel.mainAccelType[0] = mainAccelMask;
//   if (anchorX < 0)
//      return;
//   BYTE fill = 0;
//   calcMainAccel (mainAccel, anchorX, anchorY, anchorA, nest, numNest, isSearch, fill);
//   allAccel.mainAccelFill[0] = fill;
//}
#pragma pack(pop)

} // namespace accelMatch{

#endif // MAIN_ACCEL_H_