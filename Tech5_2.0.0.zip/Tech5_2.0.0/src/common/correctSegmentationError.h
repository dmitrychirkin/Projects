/*
   �������� ��������� ���� ��������� ������ �����������.
   ���� �� ��� ������ ���� ������� � �������� �����������, �� ��� ������ �������  
   ������ �� probe ������������ ��� ��������� ������� ������ �� gallery
   ��� �������������� ������ ��� ����� ���� ������������ � ����������� ����������
   �������� ��������� ��� ������ ������� �� probe
   ��� ��������� ������ ������� ����������� �������������� ����� � ���� �� �����������, ��� �������� 
   ���� (���� ���� - ��� ���� ������� probe � ��� ��������� ������� gallery ��� ������� probe) ����������� 
   �� �������� sim � quality (� ������ ����������, � ��� ����� 0-� sim)
   ����� �������� ��������� �����, ������� � ������� ������� � ������������� �����
   ���� ����� ���� ��������� ���������, �� ���� (probe � ��������� �� galley) ����������� � ������� FingerPairSequences
   ��� ����������� ���� ������������ ������ ���� ������� ������� �� ���� �� ������������ ���, ��� ��� ������ ���������
*/

#ifndef CORRECT_SEGMENTATION_ERRORS_H
#define CORRECT_SEGMENTATION_ERRORS_H

#include <stdlib.h>

//#include "accelData.h"
#include "TpAccel.h"
#include "win2lin.h"
#include "speedParam.h"
#include "mathem100.h"
#include "checkFingerPairSequences.h"


namespace accelMatch{
#pragma pack(push, _CORE_PACKING)

#define MAX_CANDIDATE_MINUTIAE  16

class GalleryCandidate
{
   BYTE  m_galleryPos;
   BYTE  m_np[MAX_CANDIDATE_MINUTIAE];
   BYTE  m_ng[MAX_CANDIDATE_MINUTIAE];
   BYTE  m_size;
   int   m_sim;

public:
   GalleryCandidate()
   {
      memset (this, 0, sizeof(GalleryCandidate));
   }
   void clear()
   {
      m_size = 0;
   }
   int getSim () const
   {
      return m_size ? m_sim : 0;
   }
   void setSim (int sim)
   {
      m_sim = sim;
   }
   void setGalleryPos (BYTE galleryPos)
   {
      m_galleryPos = galleryPos;
   }
   BYTE getGalleryPos () const
   {
      return m_galleryPos;
   }
   
   void setCombinationData (AccelPair *bestGroup, int similarity)
   {
      if(!bestGroup)
         return;

      m_sim  = similarity;
      unsigned int size = minAB (bestGroup->m_size, MAX_CANDIDATE_MINUTIAE);
      unsigned int count = 0;
      for(unsigned int i = 0; i < size; i++)
      {
         if (bestGroup->m_np[i] < 0)
            continue;
         m_np[count] = (BYTE)bestGroup->m_np[i];
         m_ng[count] = (BYTE)bestGroup->m_ng[i];
         count++;
      }
      m_size = (BYTE)count;
   }
   void getCombinationData (BYTE *&np, BYTE *&ng, BYTE &accelGroupSize) 
   {
       np             = m_np;
       ng             = m_ng;
       accelGroupSize = m_size;
   }

};

class ProbePairs
{
   BYTE              m_probePos;          // position of probe finger     
   GalleryCandidate  m_galleryCand[10];   // candidate of gallery finger for given probe finger
   BYTE              m_quality;           // minimum quality of probe and best gallery fingers
   int               m_bestSim;           // result of matching corresponded probe with best gallery finger
   unsigned int      m_val;               // value that is used for sorting
   BYTE              m_size;              // number of GalleryCandidates 

public:
   ProbePairs ()
   {
      m_probePos = 0;
      m_quality  = 0;
      m_bestSim  = 0;
      m_val      = 0;
      m_size     = 0;
   }
   void clear()
   {
      m_size = 0;
      m_bestSim = 0;
   }
   void setProbePos (BYTE probePos)
   {
      m_probePos = probePos;
   }
   void add (BYTE galleryPos, BYTE qualityP, BYTE qualityG)
   {
//      assert (m_size < 4);
      if (!m_size)
         m_quality = minAB (qualityP, qualityG);
      else
         if (m_quality > qualityG) m_quality = qualityG; 
      if (!m_quality) m_quality = 1;
      m_galleryCand[m_size++].setGalleryPos (galleryPos);
   }

   int getIndex (BYTE galleryPos)
   {
      for(int i = 0; i < m_size; i++)
         if (m_galleryCand[i].getGalleryPos() == galleryPos)
            return i;
      return -1;
   }
   bool addWithCheck (BYTE galleryPos, BYTE qualityP, BYTE qualityG)
   {
      if (getIndex (galleryPos) != -1)
            return false;
      add (galleryPos, qualityP, qualityG);
      return true;
   }
   void setCombinationData (BYTE index, AccelPair *bestGroup, int similarity)
   {
      assert(bestGroup && index >= 0);// && index < 4);
      m_galleryCand[index].setCombinationData (bestGroup, similarity);
      if (m_bestSim < similarity)
         m_bestSim = similarity;
   }
   int getBestSim() const
   {
      return m_size ? m_bestSim : 0;
   }
   int getSim(BYTE index) const
   {
      assert (index < m_size);
      return (index < m_size) ? m_galleryCand[index].getSim() : 0;
   }
   BYTE getQuality () const
   {
      return m_size ? m_quality : 0;
   }
   BYTE getProbePos () const
   {
      return m_size ? m_probePos : 0;
   }
   BYTE getSize () const
   {
      return m_size;
   }
   BYTE getGalleryPos(BYTE index) 
   {
      assert (index < m_size);
      return (index < m_size) ? m_galleryCand[index].getGalleryPos () : 0;
   }
   void getCombinationData (BYTE index, BYTE *&np, BYTE *&ng, BYTE &accelGroupSize) 
   {
      assert (index < m_size);
      if (index >= m_size)
      {
         accelGroupSize = 0;
         return;
      }
      m_galleryCand[index].getCombinationData (np, ng, accelGroupSize);
   }
   void calcSortingVal ()
   {
      if   (!m_size)  m_val = 0;
      else            m_val = (m_bestSim << 8) + m_quality;
   }
   unsigned int getSortingVal () const
   {
      return m_val;
   }
};


static inline int compareFingerPairs (const void *val1, const void *val2) 
{
   return (*((ProbePairs**)val2))->getSortingVal() - (*((ProbePairs**)val1))->getSortingVal();
} 

class FingerPairsSet
{
   ProbePairs m_fingerPairs[10];
   ProbePairs *m_pFingerPairs[10];

public:
   FingerPairsSet()
   {
      clear();
   }
   FingerPairsSet(const FingerPairsSet& pairs)
   {
      *this = pairs;
   }
   FingerPairsSet& operator= (const FingerPairsSet& pairs)
   {
      memcpy(m_fingerPairs , pairs.m_fingerPairs , sizeof(ProbePairs ) * 10);
      memcpy(m_pFingerPairs, pairs.m_pFingerPairs, sizeof(ProbePairs*) * 10);
      return *this;
   }
   void clear()
   {
      for(int i = 0; i < 10; i++)
      {
         m_fingerPairs[i].setProbePos(i);
         m_fingerPairs[i].clear();
         m_pFingerPairs[i] = &m_fingerPairs[i];
      }
   }
   void add (unsigned int probePos, unsigned int galleryPos, AllAccel *allAccelP, AllAccel *allAccelG)//, unsigned int minNum, unsigned int maxNum)
   {
      assert(allAccelP && allAccelG);
      BYTE qualityP = allAccelP->modQuality;  // getModifiedQuality2 (allAccelP, minNum, maxNum);
      BYTE qualityG = allAccelG->modQuality;  // getModifiedQuality2 (allAccelG, minNum, maxNum);

      m_fingerPairs[probePos].add (galleryPos, qualityP, qualityG);
   }

   bool addWithCheck (BYTE probePos, BYTE galleryPos, AllAccel *allAccelP, AllAccel *allAccelG)//, unsigned int minNum, unsigned int maxNum)
   {
      assert(allAccelP && allAccelG);
      BYTE qualityP = allAccelP->modQuality;  // getModifiedQuality2 (allAccelP, minNum, maxNum);
      BYTE qualityG = allAccelG->modQuality;  // getModifiedQuality2 (allAccelG, minNum, maxNum);
      return m_fingerPairs[probePos].addWithCheck (galleryPos, qualityP, qualityG);
   }
   void sort ()
   {
      for (int i = 0; i < 10; i++)
         m_fingerPairs[i].calcSortingVal();
      qsort((void*)&m_pFingerPairs[0], 10, sizeof(m_pFingerPairs[0]), compareFingerPairs); 
   }
   BYTE getSortedQulaity (BYTE index)
   {
      return m_pFingerPairs[index]->getQuality();
   }
   BYTE getSortedProbePos (BYTE index)
   {
      return m_pFingerPairs[index]->getProbePos();
   }
   BYTE getSortedGalleryPos (BYTE index, BYTE subIndex)
   {
      return m_pFingerPairs[index]->getGalleryPos(subIndex);
   }
   BYTE getSortedSize (BYTE index)
   {
      return m_pFingerPairs[index]->getSize();
   }
   int getSortedSim (BYTE index)
   {
      return m_pFingerPairs[index]->getBestSim();
   }
   int getSortedSim (BYTE index, BYTE subIndex)
   {
      return m_pFingerPairs[index]->getSim(subIndex);
   }
   void getSortedCombineData (BYTE index, BYTE subIndex, BYTE *&np, BYTE *&ng, BYTE &accelGroupSize)
   {
      assert(index < 10);                          // � �� �������� �� subIndex �� 4? 
      m_pFingerPairs[index]->getCombinationData (subIndex, np, ng, accelGroupSize);
   }

   void addSortedGalleryCandidate (BYTE index, BYTE subIndex, AccelPair *bestGroup, int similarity)
   {
      assert(bestGroup);
      m_pFingerPairs[index]->setCombinationData (subIndex, bestGroup, similarity);
   }

};

// define finger pairs those should be matched from slaps
// return number of finger pairs for matching
inline void getSlapFingerPairs (AllAccel *allAccelP[10], AllAccel *allAccelG[10], FingerPairsSet *pairs, 
                                unsigned int minFingerPos, unsigned int maxFingerPos, BYTE slapErrP, BYTE slapErrG)
{
   unsigned int numProbeFingers = 0, numGalleryFingers = 0;
   for (unsigned int finger = minFingerPos; finger <= maxFingerPos; finger++)
   {
      if (allAccelP [finger]) numProbeFingers++;
      if (allAccelG [finger]) numGalleryFingers++;
   }
   if (!numProbeFingers || !numGalleryFingers) return;
   slapErrP &= numProbeFingers   && (numProbeFingers   < 4);
   slapErrG &= numGalleryFingers && (numGalleryFingers < 4);

   // check if corresponded probe and gallery finger can be on certain virtualPos position and add good pairs to collection
   for(unsigned int probePos = minFingerPos, numTakenP = 0; probePos <= maxFingerPos; probePos++)
   {
      if (!allAccelP[probePos]) continue;
      for(unsigned int virtualPos = minFingerPos + numTakenP; virtualPos  <= maxFingerPos - (numProbeFingers - numTakenP - 1); virtualPos++)
      {
         if (!slapErrP && virtualPos != probePos)
            continue;
         for(unsigned int galleryPos = minFingerPos, numTakenG = 0; galleryPos <= maxFingerPos; galleryPos++)
         {
            if (!allAccelG[galleryPos]) continue;
            numTakenG++;
            if (!slapErrG && virtualPos != galleryPos)
               continue;
            if ((virtualPos < minFingerPos + numTakenG - 1) || (virtualPos > maxFingerPos - (numGalleryFingers - numTakenG)))
               continue;
            pairs->addWithCheck (probePos, galleryPos, allAccelP[probePos], allAccelG[galleryPos]);
         }
      }
      numTakenP++;
   }
}


// define finger pairs those should be matched from mixed slaps
// return number of finger pairs for matching
inline void getSlapFingerPairs_mix (AllAccel *allAccelP[10], AllAccel *allAccelG[10], FingerPairsSet *pairs, 
                                unsigned int minFingerPosP, unsigned int maxFingerPosP, BYTE slapErrP, BYTE slapErrG)
{
   unsigned int maxFingerPosG = getMixHandFinger (minFingerPosP);
   unsigned int minFingerPosG = getMixHandFinger (maxFingerPosP);
     
   unsigned int numProbeFingers = 0, numGalleryFingers = 0;
   for (unsigned int fingerP = minFingerPosP, fingerG = minFingerPosG; fingerP <= maxFingerPosP; fingerP++, fingerG++)
   {
      if (allAccelP [fingerP]) numProbeFingers++;
      if (allAccelG [fingerG]) numGalleryFingers++;
   }
   if (!numProbeFingers || !numGalleryFingers) return;

   slapErrP &= numProbeFingers   && (numProbeFingers   < 4);
   slapErrG &= numGalleryFingers && (numGalleryFingers < 4);

   // check if corresponded probe and gallery finger can be on certain virtualPos position and add good pairs to collection
   for(unsigned int probePos = minFingerPosP, numTakenP = 0; probePos <= maxFingerPosP; probePos++)
   {
      if (!allAccelP[probePos]) continue;
      for(unsigned int virtualPosP = minFingerPosP + numTakenP; virtualPosP  <= maxFingerPosP - (numProbeFingers - numTakenP - 1); virtualPosP++)
      {
         if (!slapErrP && virtualPosP != probePos)
            continue;
         for(unsigned int galleryPos = minFingerPosG, numTakenG = 0; galleryPos <= maxFingerPosG; galleryPos++)
         {
            if (!allAccelG[galleryPos]) continue;
            numTakenG++;
            unsigned int virtualPosG = getMixHandFinger (virtualPosP); 
            if (!slapErrG && virtualPosG != galleryPos)
               continue;
            if ((virtualPosG < minFingerPosG + numTakenG - 1) || (virtualPosG > maxFingerPosG - (numGalleryFingers - numTakenG)))
               continue;
            pairs->addWithCheck (probePos, galleryPos, allAccelP[probePos], allAccelG[galleryPos]);
         }
      }
      numTakenP++;
   }
}

// define finger pairs those should be matched from thumbs
// return number of finger pairs for matching
inline void getThumbsFingerPairs (AllAccel *allAccelP[10], AllAccel *allAccelG[10], 
                                  FingerPairsSet *pairs, bool mixHandMode, BYTE thumbErrP, BYTE thumbErrG)
{
   unsigned int numProbeFingers = 0, numGalleryFingers = 0;
   for(unsigned int finger = 0; finger <= 5; finger += 5)
   {
      if (allAccelP[finger]) numProbeFingers++;
      if (allAccelG[finger]) numGalleryFingers++;
   }
   if (!mixHandMode && !(numProbeFingers == 1 || numGalleryFingers == 1)) 
      return;
   thumbErrP &= numProbeFingers   == 1;
   thumbErrG &= numGalleryFingers == 1;
   BYTE thumbErr = thumbErrP || thumbErrG;

   if (allAccelP[0])
   {
      if (allAccelG[0]            ) pairs->addWithCheck (0, 0, allAccelP[0], allAccelG[0]);
      if (allAccelG[5] && thumbErr) pairs->addWithCheck (0, 5, allAccelP[0], allAccelG[5]);
   }
   if (allAccelP[5])
   {
      if (allAccelG[5]            ) pairs->addWithCheck (5, 5, allAccelP[5], allAccelG[5]);
      if (allAccelG[0] && thumbErr) pairs->addWithCheck (5, 0, allAccelP[5], allAccelG[0]);
   }
}


inline void getFingerPairs_normal (AllAccel *allAccelP[10], AllAccel *allAccelG[10], FingerPairsSet *pairs)
{
   for(unsigned int finger = 0; finger < 10; finger++)
   {
      if (!allAccelP[finger] || !allAccelG[finger])
         continue;
      pairs->add (finger, finger, allAccelP[finger], allAccelG[finger]);
   }
}

inline void addSegErrCorrectionPairs(PersonalData *probePersonalData, PersonalData *galleryPersonalData,
                                     AllAccel *allAccelP[10], AllAccel *allAccelG[10], 
                                     FingerPairsSet *pairs, bool mixHandMode)
{
   if(!probePersonalData || !galleryPersonalData)
      return;
   BYTE leftSlapErrP  = probePersonalData->m_leftSlapError;
   BYTE rightSlapErrP = probePersonalData->m_rightSlapError;
   BYTE thumbErrP     = probePersonalData->m_thumbsError;
   BYTE leftSlapErrG  = galleryPersonalData->m_leftSlapError; 
   BYTE rightSlapErrG = galleryPersonalData->m_rightSlapError;
   BYTE thumbErrG     = galleryPersonalData->m_thumbsError;
   if (leftSlapErrP  || leftSlapErrG ) getSlapFingerPairs   (allAccelP, allAccelG, pairs, 6, 9,        leftSlapErrP , leftSlapErrG );
   if (rightSlapErrP || rightSlapErrG) getSlapFingerPairs   (allAccelP, allAccelG, pairs, 1, 4,        rightSlapErrP, rightSlapErrG);
   if (thumbErrP     || thumbErrG    ) getThumbsFingerPairs (allAccelP, allAccelG, pairs, mixHandMode, thumbErrP    , thumbErrG    );
}

inline void addSegErrCorrectionPairs_mix(PersonalData *probePersonalData, PersonalData *galleryPersonalData, 
                                     AllAccel *allAccelP[10], AllAccel *allAccelG[10], 
                                     FingerPairsSet *pairs, bool mixHandMode)
{
   if(!probePersonalData || !galleryPersonalData)
      return;
   BYTE leftSlapErrP  = probePersonalData->m_leftSlapError;
   BYTE rightSlapErrP = probePersonalData->m_rightSlapError;
   BYTE thumbErrP     = probePersonalData->m_thumbsError;
   BYTE leftSlapErrG  = galleryPersonalData->m_leftSlapError; 
   BYTE rightSlapErrG = galleryPersonalData->m_rightSlapError;
   BYTE thumbErrG     = galleryPersonalData->m_thumbsError;

   if (leftSlapErrP  || rightSlapErrG) getSlapFingerPairs_mix (allAccelP, allAccelG, pairs, 6, 9,        leftSlapErrP , rightSlapErrG);
   if (rightSlapErrP || leftSlapErrG ) getSlapFingerPairs_mix (allAccelP, allAccelG, pairs, 1, 4,        rightSlapErrP, leftSlapErrG );
   if (thumbErrP     || thumbErrG    ) getThumbsFingerPairs   (allAccelP, allAccelG, pairs, mixHandMode, thumbErrP    , thumbErrG);
}

inline void getFingerPairs_mixFingers (AllAccel *allAccelP[10], AllAccel *allAccelG[10], FingerPairsSet *pairs)
{
   for(int fingerP = 0; fingerP < 10; fingerP++)
   {
      if (!allAccelP[fingerP])
         continue;
      if (allAccelG[fingerP])
         pairs->add (fingerP, fingerP, allAccelP[fingerP], allAccelG[fingerP]);
      for(int fingerG = 0; fingerG < 10; fingerG++)
      {
         if (!allAccelG[fingerG] || (fingerG == fingerP))
            continue;
         pairs->add (fingerP, fingerG, allAccelP[fingerP], allAccelG[fingerG]);
      }
   }
}

inline void getFingerPairs_mixSlapsOrHands (AccelSearchParam &param, PersonalData *probePersonalData,
                                            PersonalData *galleryPersonalData, AllAccel *allAccelP[10], 
                                            AllAccel *allAccelG[10],  FingerPairsSet *pairs)
{
   for(unsigned int fingerP = 0; fingerP < 10; fingerP++)
   {
      if (!allAccelP[fingerP])
         continue;
      unsigned int fingerG = fingerP;
      if (allAccelG[fingerG])
         pairs->add (fingerP, fingerG, allAccelP[fingerP], allAccelG[fingerG]);
      if (param.matchingMode == CHECK_MIX_SLAP_MATCHING_MODE && (fingerP == 0 || fingerP == 5))
         continue;
      fingerG = getMixHandFinger (fingerP);
      if (allAccelG[fingerG])
         pairs->add (fingerP, fingerG, allAccelP[fingerP], allAccelG[fingerG]);
   }
   if (param.doSegErrCorrect && probePersonalData)       // add all possible pair of fingers from slaps and thumbs segmented with errors
   {
      addSegErrCorrectionPairs     (probePersonalData, galleryPersonalData, allAccelP, allAccelG, pairs, param.matchingMode == CHECK_MIX_HAND_MATCHING_MODE);
      addSegErrCorrectionPairs_mix (probePersonalData, galleryPersonalData, allAccelP, allAccelG, pairs, param.matchingMode == CHECK_MIX_HAND_MATCHING_MODE);
   }
}
inline void getSpeedParams (unsigned int searchSpeed, unsigned int speedParams[NUM_SPEED_PARAM], unsigned int ipVer, unsigned int numFingerPairs)
{
   unsigned int maxSearchSpeed = 0;
   if (ipVer ==  73)
   {
      if (numFingerPairs <= 1)
      {
         maxSearchSpeed = sizeof(g_speedParamsTT_73_1f ) / sizeof(g_speedParamsTT_73_1f [0]) - 1;
         if (searchSpeed > maxSearchSpeed)
            searchSpeed = maxSearchSpeed;
         memcpy(speedParams, g_speedParamsTT_73_1f  [searchSpeed], sizeof(speedParams[0]) * NUM_SPEED_PARAM);
      }
      else if (numFingerPairs <= 2)
      {
         maxSearchSpeed = sizeof(g_speedParamsTT_73_2f ) / sizeof(g_speedParamsTT_73_2f [0]) - 1;
         if (searchSpeed > maxSearchSpeed)
            searchSpeed = maxSearchSpeed;
         memcpy(speedParams, g_speedParamsTT_73_2f  [searchSpeed], sizeof(speedParams[0]) * NUM_SPEED_PARAM);
      }
      else if (numFingerPairs <= 8)
      {
         maxSearchSpeed = sizeof(g_speedParamsTT_73_4f ) / sizeof(g_speedParamsTT_73_4f [0]) - 1;
         if (searchSpeed > maxSearchSpeed)
            searchSpeed = maxSearchSpeed;
         memcpy(speedParams, g_speedParamsTT_73_4f  [searchSpeed], sizeof(speedParams[0]) * NUM_SPEED_PARAM);
      }
      else 
      {
         maxSearchSpeed = sizeof(g_speedParamsTT_73_10f ) / sizeof(g_speedParamsTT_73_10f [0]) - 1;
         if (searchSpeed > maxSearchSpeed)
            searchSpeed = maxSearchSpeed;
         memcpy(speedParams, g_speedParamsTT_73_10f  [searchSpeed], sizeof(speedParams[0]) * NUM_SPEED_PARAM);
      }
   }
   else
   {
      if (numFingerPairs <= 1)
      {
         maxSearchSpeed = sizeof(g_speedParamsTT_140_1f ) / sizeof(g_speedParamsTT_140_1f [0]) - 1;
         if (searchSpeed > maxSearchSpeed)
            searchSpeed = maxSearchSpeed;
         memcpy(speedParams, g_speedParamsTT_140_1f  [searchSpeed], sizeof(speedParams[0]) * NUM_SPEED_PARAM);
      }
      else if (numFingerPairs <= 2)
      {
         maxSearchSpeed = sizeof(g_speedParamsTT_140_2f ) / sizeof(g_speedParamsTT_140_2f [0]) - 1;
         if (searchSpeed > maxSearchSpeed)
            searchSpeed = maxSearchSpeed;
         memcpy(speedParams, g_speedParamsTT_140_2f  [searchSpeed], sizeof(speedParams[0]) * NUM_SPEED_PARAM);
      }
      else if (numFingerPairs <= 8)
      {
         maxSearchSpeed = sizeof(g_speedParamsTT_140_4f ) / sizeof(g_speedParamsTT_140_4f [0]) - 1;
         if (searchSpeed > maxSearchSpeed)
            searchSpeed = maxSearchSpeed;
         memcpy(speedParams, g_speedParamsTT_140_4f  [searchSpeed], sizeof(speedParams[0]) * NUM_SPEED_PARAM);
      }
      else 
      {
         maxSearchSpeed = sizeof(g_speedParamsTT_140_10f ) / sizeof(g_speedParamsTT_140_10f [0]) - 1;
         if (searchSpeed > maxSearchSpeed)
            searchSpeed = maxSearchSpeed;
         memcpy(speedParams, g_speedParamsTT_140_10f  [searchSpeed], sizeof(speedParams[0]) * NUM_SPEED_PARAM);
      }
   }
}

inline int chooseNumFingers(unsigned int searchSpeed, unsigned int ipVer, unsigned int speedParams[NUM_SPEED_PARAM], int numFingers, FingerPairsSet *pairs)
{
   // calculate number of real pairs 
   unsigned int numFingerPairs = 0;
   for(BYTE index = 0; index < 10; index++)
      if (pairs->getSortedQulaity (index))
         numFingerPairs++;
   
   if (numFingers > 0 && (int)numFingerPairs > numFingers ) 
      numFingerPairs = numFingers;

   getSpeedParams (searchSpeed, speedParams, ipVer, numFingerPairs);

   // choose number of finger pairs for matching if it's not defined
   if (numFingers == -1)
   {
//#ifdef IP_73
      //switch (param.searchSpeed)
      //{
      //case 0:
      //case 1:
         if      (numFingerPairs >= 2 && pairs->getSortedQulaity(1) >=  speedParams[54]) numFingers = 2;  
         else if (numFingerPairs >= 3 && pairs->getSortedQulaity(2) >=  speedParams[55]) numFingers = 3;  
         else                                                                            numFingers = 4;
      //   break;
      //case 2:
      //case 3:
      //case 4: 
      //   if      (count >= 2 && pairs->getSortedQulaity(1) >  speedParam[39]) numFingers = 2;  // 75
      //   else if (count >= 3 && pairs->getSortedQulaity(2) >  speedParam[40]) numFingers = 3;  //55
      //   else                                                     numFingers = 4;   
      //   break;
      //case 5:
      //   if      (count >= 2 && pairs->getSortedQulaity(1) >  65) numFingers = 2;
      //   else if (count >= 3 && pairs->getSortedQulaity(2) >  35) numFingers = 3;
      //   else                                                     numFingers = 4;   
      //   break;
      //case 6:
      //   if      (count >= 2 && pairs->getSortedQulaity(1) >  65) numFingers = 2;
      //   else if (count >= 3 && pairs->getSortedQulaity(2) >  10) numFingers = 3;
      //   else                                                     numFingers = 4;   
      //   break;
      //case 7:
      //   numFingers = 2;
      //   //if      (count >= 2 && pairs->getSortedQulaity(1) >  65) numFingers = 2;
      //   //else                                                     numFingers = 3;   
      //   break;
      //default:
      //   numFingers = 1;
      //   break;
      //}
//#else
//      switch (param.searchSpeed)
//      {
//      case 0:
//      case 1:
//         if      (count >= 2 && pairs->getSortedQulaity(1) >  80) numFingers = 2; 
//         else if (count >= 3 && pairs->getSortedQulaity(2) >  65) numFingers = 3;
//         else                                                     numFingers = 4;
//         break;
//      case 2:
//      case 3:
//      case 4:
//         if      (count >= 2 && pairs->getSortedQulaity(1) >  80) numFingers = 2;
//         else if (count >= 3 && pairs->getSortedQulaity(2) >  60) numFingers = 3;
//         else                                                     numFingers = 4;   
//         break;
//      case 5:
//         if      (count >= 2 && pairs->getSortedQulaity(1) >  65) numFingers = 2;
//         else if (count >= 3 && pairs->getSortedQulaity(2) >  35) numFingers = 3;
//         else                                                     numFingers = 4;   
//         break;
//      case 6:
//         if      (count >= 2 && pairs->getSortedQulaity(1) >  65) numFingers = 2;
//         else if (count >= 3 && pairs->getSortedQulaity(2) >  10) numFingers = 3;
//         else                                                     numFingers = 4;   
//         break;
//      case 7:
//         numFingers = 2;
//         //if      (count >= 2 && pairs->getSortedQulaity(1) >  65) numFingers = 2;
//         //else                                                     numFingers = 3;   
//         break;
//      default:
//         numFingers = 1;
//         break;
//      }
//#endif
   }
   if (numFingers <                   1) numFingers = 1;
   if (numFingers > (int)numFingerPairs) numFingers = numFingerPairs;

   return numFingers;
}

inline int getFingerPairs (AccelSearchParam &param, unsigned int ipVer, unsigned int speedParams[NUM_SPEED_PARAM], int numFingers, PersonalData *probePersonalData, 
                              AllAccel *allAccelP[10], TpAccel &gallery, FingerPairsSet *pairs)
{
   pairs->clear();
   AllAccel *allAccelG[10];
   for (int finger = 0; finger < 10; finger++)
      allAccelG[finger] =  assignHeader(gallery.m_accel[finger]);

   switch (param.matchingMode) 
   {
   case CHECK_MIX_FINGER_MATCHING_MODE:
      getFingerPairs_mixFingers (allAccelP, allAccelG, pairs);
      break;
   case CHECK_MIX_SLAP_MATCHING_MODE:
   case CHECK_MIX_HAND_MATCHING_MODE:
      getFingerPairs_mixSlapsOrHands (param, probePersonalData, gallery.m_personalData, allAccelP, allAccelG,  pairs);
      break;
   case NORMAL_MATCHING_MODE:
      getFingerPairs_normal (allAccelP, allAccelG, pairs);
      if (param.doSegErrCorrect)   // correct segmentation errors
         addSegErrCorrectionPairs (probePersonalData, gallery.m_personalData, allAccelP, allAccelG, pairs, param.matchingMode == CHECK_MIX_HAND_MATCHING_MODE);
      break;
   default:
      assert(false);
      break;
   }
   pairs->sort (); 
   
   return chooseNumFingers (param.searchSpeed, ipVer, speedParams, numFingers, pairs);
}


#pragma pack(pop)
} // namespace accelMatch{


#endif // CORRECT_SEGMENTATION_ERRORS_H
