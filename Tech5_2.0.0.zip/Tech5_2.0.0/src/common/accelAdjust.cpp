#ifdef ADJUST

#include "accelAdjust.h"
#include "fileUtl.h"

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)

//FILE *g_adjustFile = NULL;
//int g_probeId = 0, g_galleryId = 0, g_numGroup = 0, g_finger = 0;

//bool openLog(const char *name, bool forRead)
//{
//   if (forRead)
//      g_adjustFile = fopen(name, "rb");
//   else
//      g_adjustFile = fopen(name, "wb");
//   return (g_adjustFile != NULL);
//}
//
//void closeLog()
//{
//   if (!g_adjustFile)
//      return;
//   fclose(g_adjustFile);
//   g_adjustFile = NULL;
//}
//
//bool saveParameters(AccelScoreParam &param)
//{
//   if (!g_adjustFile)
//      return false;
//   char marker[] = "$$$";
//   size_t size = strlen(marker);
//   if (fwrite (marker, 1, size, g_adjustFile) != size)
//      return false;
//   size = sizeof(g_probeId);
//   //if (g_probeId >= 6000 ||  g_galleryId >= 6000)
//   //   return false;
//
//   if (fwrite (&g_probeId, 1, size, g_adjustFile) != size)
//      return false;
//   if (fwrite (&g_galleryId, 1, size, g_adjustFile) != size)
//      return false;
//   if (fwrite (&g_finger, 1, size, g_adjustFile) != size)
//      return false;
//   if (fwrite (&g_numGroup, 1, size, g_adjustFile) != size)
//      return false;
//   size = sizeof(AccelScoreParam);
//   if (fwrite (&param, 1, size, g_adjustFile) != size)
//      return false;
//   size = strlen(marker);
//   if (fwrite (marker, 1, size, g_adjustFile) != size)
//      return false;
//
//   return true;
//}
//
//bool readParameters(int &probeId, int &galleryId, int &finger, int &numGroup, AccelScoreParam &param)
//{
//   if (!g_adjustFile)
//      return false;
//   char marker[] = "$$$";
//   char buffer[20];
//   memset(buffer, 0, sizeof(buffer));
//   size_t size = strlen(marker);
//   if (fread (buffer, 1, size, g_adjustFile) != size)
//      return false;
//   if (strcmp (buffer, marker))
//      return false;
//   size = sizeof(probeId);
//   if (fread (&probeId, 1, size, g_adjustFile) != size)
//      return false;
//   if (fread (&galleryId, 1, size, g_adjustFile) != size)
//      return false;
//   if (fread (&finger, 1, size, g_adjustFile) != size)
//      return false;
//   if (fread (&numGroup, 1, size, g_adjustFile) != size)
//      return false;
//   size = sizeof(AccelScoreParam);
//   if (fread (&param, 1, size, g_adjustFile) != size)
//      return false;
//   size = strlen(marker);
//   if (fread (buffer, 1, size, g_adjustFile) != size)
//      return false;
//   if (strcmp (buffer, marker))
//      return false;
//   return true;
//}

#pragma pack(pop)
} // namespace accelMatch{



#endif // ADJUST
