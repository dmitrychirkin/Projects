#ifndef CHECK_FINGER_PAIR_SEQUENCES_H_
#define CHECK_FINGER_PAIR_SEQUENCES_H_

#include "accelMatch.h"

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)

static inline unsigned int getMixHandFinger(unsigned int finger)
{
   switch(finger)
   {
   case 0:
      return 5;
      break;
   case 5:
      return 0;
      break;
   default:
      return 10 - finger;
      break;
   }
}

static inline bool isRight (unsigned int finger)
{
   return finger < 5;
}
static inline bool isLeft (unsigned int finger)
{
   return finger >= 5;
}
static inline bool fromThumbs (unsigned int finger)
{
   return ((finger == 0) || (finger == 5));
}
static inline bool fromLeftSlap (unsigned int finger)
{
   return (finger >= 6);
}
static inline bool fromRightSlap (unsigned int finger)
{
   return (finger >= 1 && finger <= 4);
}

static inline bool fromSlaps (unsigned int finger)
{
   return fromLeftSlap (finger) || fromRightSlap (finger);
}


struct MatchedPair
{
   char probePos;
   char galleryPos;
};
/*
this class works correctly only if pair for mathcing will be taken from accelerator matching ('getFingerPairs' function)
because it's not check the correct of 1st pair in each slaps or thumbs and check only correct of next finger pairs sequences
*/
class FingerPairSequences
{
   MatchedPair    m_leftSlap [4];
   MatchedPair    m_rightSlap[4];
   MatchedPair    m_thumbs   [2];
   BYTE           m_numLeftSlapPairs;
   BYTE           m_numRightSlapPairs;
   BYTE           m_numThumbsPairs;
   bool           m_proveSlaps;         // true if we already prove that slaps  were mixed or not
   bool           m_mixSlaps;           // true if slaps  were mixed
   bool           m_segErr;             // true if there is thumbs or slap segmentation error and we do correction
   bool           m_thumbsError;        // true if there is thumbs         segmentation error and we do correction  
   bool           m_leftSlapError;      // true if there is left  slaps    segmentation error and we do correction  
   bool           m_rightSlapError;     // true if there is right slaps    segmentation error and we do correction  
   MATCHING_MODE  m_matchingMode; 
   bool           m_takenP[10];         // true if corresponded probe   position already assigned to some probe position   
   bool           m_takenG[10];         // true if corresponded gallery position already assigned to some probe position   
public:   
   FingerPairSequences(AccelSearchParam &accelParam, PersonalData *probePersonalData, PersonalData *galleryPersonalData,
                  BYTE *accelP[10], BYTE *accelG[10])
   {
      memset (this, 0, sizeof(FingerPairSequences));
      m_matchingMode   = accelParam.matchingMode;
      // calculate number of non null fingers in thumbs and slaps
      int numThumbsFingerP = 0, numLeftSlapFingerP = 0, numRightSlapFingerP = 0;
      int numThumbsFingerG = 0, numLeftSlapFingerG = 0, numRightSlapFingerG = 0;
      for(int finger = 0; finger < 10; finger++)
      {
         if (accelP[finger])
         {
            if      (finger == 0 || finger == 5) numThumbsFingerP++;
            else if (finger <  5               ) numRightSlapFingerP++;
            else                                 numLeftSlapFingerP++;
         }
         if (accelG[finger])
         {
            if      (finger == 0 || finger == 5) numThumbsFingerG++;
            else if (finger <  5               ) numRightSlapFingerG++;
            else                                 numLeftSlapFingerG++;
         }
      }
      if (accelParam.doSegErrCorrect)
      {
         if (numThumbsFingerP == 1 || numThumbsFingerG == 1)
            m_thumbsError    =  (probePersonalData->m_thumbsError || galleryPersonalData->m_thumbsError);
         if ((numLeftSlapFingerP && numLeftSlapFingerP < 4) || (numLeftSlapFingerG && numLeftSlapFingerG < 4))
            m_leftSlapError  = (probePersonalData->m_leftSlapError || galleryPersonalData->m_leftSlapError);
         if ((numRightSlapFingerP && numRightSlapFingerP < 4) || (numRightSlapFingerG && numRightSlapFingerG < 4))
            m_rightSlapError = (probePersonalData->m_rightSlapError || galleryPersonalData->m_rightSlapError);

         if ((m_matchingMode == CHECK_MIX_SLAP_MATCHING_MODE) || (m_matchingMode == CHECK_MIX_HAND_MATCHING_MODE))
            m_leftSlapError = m_rightSlapError = (m_leftSlapError || m_rightSlapError); 
         m_segErr = m_thumbsError || m_leftSlapError || m_rightSlapError;
      }

   }
   void add(BYTE probePos, BYTE galleryPos)
   {
      m_takenP [probePos  ] = true;
      m_takenG [galleryPos] = true;
      if      (probePos == 0 || probePos == 5) return addThumbsPair(probePos, galleryPos);
      else if (probePos <  5                 ) return addRightSlapPair(probePos, galleryPos);
      else                                     return addLeftSlapPair(probePos, galleryPos);
   }
   bool canAdd(BYTE probePos, BYTE galleryPos)
   {
      if (m_takenP[probePos] || m_takenG[galleryPos])
         return false;
      if ((m_matchingMode == NORMAL_MATCHING_MODE) && !m_segErr) 
         return (probePos == galleryPos);
      if (m_matchingMode == CHECK_MIX_FINGER_MATCHING_MODE) // for this mode enough if galleryPos is not taken
         return true;
      if      (probePos == 0 || probePos == 5) return checkThumbs   (probePos, galleryPos);
      else if (probePos <  5                 ) return checkRightSlap(probePos, galleryPos);
      else                                     return checkLeftSlap (probePos, galleryPos);
   }
private:
   void addThumbsPair(BYTE probePos, BYTE galleryPos)
   {
      assert(m_numThumbsPairs < 2 && (fromThumbs(galleryPos) || (m_matchingMode == CHECK_MIX_FINGER_MATCHING_MODE)));
      m_thumbs[m_numThumbsPairs].probePos   = probePos;
      m_thumbs[m_numThumbsPairs].galleryPos = galleryPos;
      m_numThumbsPairs++;
   }
   void addRightSlapPair(BYTE probePos, BYTE galleryPos)
   {
      assert(m_numRightSlapPairs < 4 && (!fromThumbs(galleryPos) || (m_matchingMode == CHECK_MIX_FINGER_MATCHING_MODE)));
      m_rightSlap[m_numRightSlapPairs].probePos   = probePos;
      m_rightSlap[m_numRightSlapPairs].galleryPos = galleryPos;
      m_numRightSlapPairs++;
      if (m_proveSlaps)
         return;
      m_proveSlaps = true;
      m_mixSlaps = fromLeftSlap (galleryPos);
   }
   void addLeftSlapPair(BYTE probePos, BYTE galleryPos)
   {
      assert(m_numLeftSlapPairs < 4 && (!fromThumbs(galleryPos) || (m_matchingMode == CHECK_MIX_FINGER_MATCHING_MODE)));
      m_leftSlap[m_numLeftSlapPairs].probePos   = probePos;
      m_leftSlap[m_numLeftSlapPairs].galleryPos = galleryPos;
      m_numLeftSlapPairs++;
      if (m_proveSlaps)
         return;
      m_proveSlaps = true;
      m_mixSlaps = fromRightSlap (galleryPos);
   }


   bool checkThumbs(BYTE probePos, BYTE galleryPos)
   {
      assert (m_numThumbsPairs < 2 && fromThumbs(galleryPos)); // should be true, because CHECK_MIX_FINGER_MATCHING_MODE
                                                               // mode already handled  
      switch(m_matchingMode)
      {
      case NORMAL_MATCHING_MODE:                  // thumbs cannot be mixed  
      case CHECK_MIX_SLAP_MATCHING_MODE:  
         if (!m_thumbsError || m_numThumbsPairs)  
            return (probePos == galleryPos);
         else                                     // there is a thumbs segmentation error and it's 1st thumbs pair (can be any)        
            return true;                             
      case CHECK_MIX_HAND_MATCHING_MODE:          // for this mode is enough that probePos and galleryPos are unique 
         return true;                             // (it's already checked)
      default:                                 
         assert(false);                           // CHECK_MIX_FINGER_MATCHING_MODE  already handled
         return true;
      };
   }
   bool checkLeftSlap (BYTE probePos, BYTE galleryPos)
   {
      assert(m_numLeftSlapPairs < 4 && !fromThumbs(galleryPos));// should be true, because CHECK_MIX_FINGER_MATCHING_MODE
                                                                // mode already handled  
      switch(m_matchingMode)
      {
      case NORMAL_MATCHING_MODE:              // slaps cannot be mixed  
         return checkLeftSlap_notMixed (probePos, galleryPos);

      case CHECK_MIX_SLAP_MATCHING_MODE:      // slaps can be mixed  
      case CHECK_MIX_HAND_MATCHING_MODE:    
         if (!m_proveSlaps)                   // it's 1st slaps pair
            return true;
         if (!m_mixSlaps)                     // equal no NORMAL_MATCHING_MODE  
            return checkLeftSlap_notMixed (probePos, galleryPos);
         else
            return checkLeftSlap_mixed    (probePos, galleryPos);
   
      default:                                 
         assert(false);                       // CHECK_MIX_FINGER_MATCHING_MODE  already handled 
         return true;
      };
   }
   // check left slap when slaps are not mixed
   bool checkLeftSlap_notMixed (BYTE probePos, BYTE galleryPos)
   {
      if (!fromLeftSlap(galleryPos)) return false;
      if (!m_leftSlapError)
         return (probePos == galleryPos);

      for(unsigned int i = 0; i < m_numLeftSlapPairs; i++)
      {
         assert((probePos != m_leftSlap[i].probePos) && (galleryPos != m_leftSlap[i].galleryPos));
         if (((probePos > m_leftSlap[i].probePos) && (galleryPos < m_leftSlap[i].galleryPos))
          || ((probePos < m_leftSlap[i].probePos) && (galleryPos > m_leftSlap[i].galleryPos)))
            return false;
      }
      return true;
   }
   // check left slap when slaps are mixed
   bool checkLeftSlap_mixed (BYTE probePos, BYTE galleryPos)
   {
      if (!fromRightSlap(galleryPos)) return false;
      if (!m_leftSlapError)
         return (probePos == getMixHandFinger(galleryPos));

      for(unsigned int i = 0; i < m_numLeftSlapPairs; i++)
      {
         assert((probePos != m_leftSlap[i].probePos) && (galleryPos != m_leftSlap[i].galleryPos));
         if (((probePos > m_leftSlap[i].probePos) && (galleryPos > m_leftSlap[i].galleryPos))
          || ((probePos < m_leftSlap[i].probePos) && (galleryPos < m_leftSlap[i].galleryPos)))
            return false;
      }
      return true;
   }

   bool checkRightSlap (BYTE probePos, BYTE galleryPos)
   {
      assert(m_numRightSlapPairs < 4 && !fromThumbs(galleryPos)); // should be true, because CHECK_MIX_FINGER_MATCHING_MODE
                                                                  // mode already handled  
      switch(m_matchingMode)
      {
      case NORMAL_MATCHING_MODE:              // slaps cannot be mixed  
         return checkRightSlap_notMixed (probePos, galleryPos);

      case CHECK_MIX_SLAP_MATCHING_MODE:      // slaps can be mixed  
      case CHECK_MIX_HAND_MATCHING_MODE:    
         if (!m_proveSlaps)                   // it's 1st slaps pair
            return true;
         if (!m_mixSlaps)                     // equal no NORMAL_MATCHING_MODE  
            return checkRightSlap_notMixed (probePos, galleryPos);
         else
            return checkRightSlap_mixed    (probePos, galleryPos);
   
      default:                                 
         assert(false);                       // CHECK_MIX_FINGER_MATCHING_MODE  already handled 
         return true;
      };
   }
   // check right slap when slaps are not mixed
   bool checkRightSlap_notMixed (BYTE probePos, BYTE galleryPos)
   {
      if (!fromRightSlap (galleryPos)) return false;
      if (!m_rightSlapError)
         return (probePos == galleryPos);

      for(unsigned int i = 0; i < m_numRightSlapPairs; i++)
      {
         assert((probePos != m_rightSlap[i].probePos) && (galleryPos != m_rightSlap[i].galleryPos));
         if (((probePos > m_rightSlap[i].probePos) && (galleryPos < m_rightSlap[i].galleryPos))
          || ((probePos < m_rightSlap[i].probePos) && (galleryPos > m_rightSlap[i].galleryPos)))
            return false;
      }
      return true;
   }
   // check right slap when slaps are mixed
   bool checkRightSlap_mixed (BYTE probePos, BYTE galleryPos)
   {
      if (!fromLeftSlap(galleryPos)) return false;
      if (!m_rightSlapError)
         return (probePos == getMixHandFinger(galleryPos));

      for(unsigned int i = 0; i < m_numRightSlapPairs; i++)
      {
         assert((probePos != m_rightSlap[i].probePos) && (galleryPos != m_rightSlap[i].galleryPos));
         if (((probePos > m_rightSlap[i].probePos) && (galleryPos > m_rightSlap[i].galleryPos))
          || ((probePos < m_rightSlap[i].probePos) && (galleryPos < m_rightSlap[i].galleryPos)))
            return false;
      }
      return true;
   }

}; // struct FingerPairSequences

#pragma pack(pop)
} // namespace accelMatch{
#endif // CHECK_FINGER_PAIR_SEQUENCES_H_
