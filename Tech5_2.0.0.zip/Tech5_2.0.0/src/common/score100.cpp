#include <math.h>
#include <assert.h>

#include "win2lin.h"
#include "score100.h"

namespace accelMatch{
#pragma pack(push,_CORE_PACKING)

int normalizeCorrectionProb(int correctionProb, int notFoundProb)
{
   if (correctionProb                >= 0) return  0           ;
   if (notFoundProb - correctionProb < 0 ) return -notFoundProb;
   return correctionProb;
}
void printfParam(ScoreParameters &param)
{
   printf ("\n");
   printf ("m_qualityP                 = %d\n", param.m_qualityP                 );
   printf ("m_qualityG                 = %d\n", param.m_qualityG                 );
   printf ("m_disrErrR       = %3d %3d %3d\n", param.m_distErrR      [0], param.m_distErrR      [1], param.m_distErrR      [2]);
   printf ("m_minRelAngleErr = %3d %3d %3d\n", param.m_minRelAngleErr[0], param.m_minRelAngleErr[1], param.m_minRelAngleErr[2]);
   printf ("m_angleErr       = %3d %3d %3d\n", param.m_angleErr      [0], param.m_angleErr      [1], param.m_angleErr      [2]);
   printf ("m_angleErr1      = %3d %3d %3d\n", param.m_angleErr1     [0], param.m_angleErr1     [1], param.m_angleErr1     [2]);
   printf ("m_relAngleErr    = %3d %3d %3d\n", param.m_relAngleErr   [0], param.m_relAngleErr   [1], param.m_relAngleErr   [2]);
   printf ("m_topologySim    = %3d %3d %3d\n", param.m_topologySim   [0], param.m_topologySim   [1], param.m_topologySim   [2]);
   printf ("m_numNestP                 = %d\n", param.m_numNestP                 );
   printf ("m_numNestG                 = %d\n", param.m_numNestG                 );
   //printf ("m_incompatibleSingul       = %d\n", param.m_incompatibleSingular     );
   //printf ("m_incompatibleSingularMinQ = %d\n", param.m_incompatibleSingularMinQ );
   //printf ("m_numFlowError             = %d\n", param.m_numFlowError             );
   //printf ("m_flowAverangeErr          = %d\n", param.m_flowAverangeErr          );
   //printf ("m_transitionDif  = %3d %3d %3d\n", param.m_transitionDif [0], param.m_transitionDif [1], param.m_transitionDif [2]);
   //printf ("m_numMissDeltas            = %d\n", param.m_numMissDeltas            );
   //printf ("m_numMissCores             = %d\n", param.m_numMissCores             );
   
   printf ("\n");
}
int getIndex (int val, const int *bounds, int size)
{
   for(int i = 0; i < size - 1; i++)
      if (val < bounds[i]) 
         return i;  
   return size - 1;     
}


int correctFoundProb(BYTE probability, int size, int rc, int maxRc, const int *k)
{
   if (size > MAX_UNRELIABLE_PAIR_DIST || rc >= maxRc / 128)
      return probability;
   if      (size < 10) return probability * 2048 / (k[0] + 1);
   else if (size < 20) return probability * 2048 / (k[1] + 1);
   else if (size < 30) return probability * 2048 / (k[2] + 1);
   else                return probability * 2048 / (k[3] + 1);
}

int correctNotFoundProb(BYTE probability, int size, int rc, int maxRc, const int *k)
{
   if (size > MAX_UNRELIABLE_PAIR_DIST || rc >= maxRc / 128)
      return probability;
   if      (size < 10) return probability * 32   / (k[0] + 1);
   else if (size < 20) return probability * 32   / (k[1] + 1);
   else if (size < 30) return probability * 32   / (k[2] + 1);
   else                return probability * 2048 / (k[3] + 1);
}

int correctProb(BYTE probability, MinData &minData, const int k_found[SCORE_FOUND_PARAM_SIZE])
{
   int resultProb = probability;
   if (minData.m_unreliablePairStatus == FOUND_UNRELIABLE_PAIR)
      resultProb = correctFoundProb    (probability, minData.m_unreliableSize, minData.m_unreliableRc, k_found[4], &k_found[0]);
   if (minData.m_unreliablePairStatus == NOT_FOUND_UNRELIABLE_PAIR)
      resultProb = correctNotFoundProb (probability, minData.m_unreliableSize, minData.m_unreliableRc, k_found[9], &k_found[5]);
   
   return resultProb;// < 100 ? (BYTE)resultProb : 100;
}

void calcProbs(MinData *minData, int numNests, const int k_found[SCORE_FOUND_PARAM_SIZE], int minNotFoundProb, 
                                               int &firstGroupSize, int &mainGroupSize, int &numFound, 
                                               int foundProb[3], int &notFoundProb, int &numExcluded, int &numNotFound)
{
   memset (foundProb, 0, sizeof(foundProb[0]) * 3);
   notFoundProb =  0, numExcluded  = 0, numNotFound = 0;
   int notCorrectedNotFoundProb = 0;

   int probability = 0;
   for(BYTE n = 0; n < numNests; n++)
   {
      probability    = minData[n].m_probability;
      if (probability < minNotFoundProb && minData[n].m_foundStatus == NOT_FOUND) 
         minData[n].m_foundStatus = EXCLUDED;
      if (minData[n].m_foundStatus == NOT_FOUND)
         notCorrectedNotFoundProb += probability;
      probability = correctProb (probability, minData[n], k_found);
      switch(minData[n].m_foundStatus)
      {
      case FOUND_FIRST:
         foundProb[0] += probability;
         firstGroupSize++;
         break;
      case FOUND_MAIN:
         foundProb[1] += probability;
         mainGroupSize++;
         break;
      case FOUND:
         foundProb[2] += probability;
         numFound++;
         break;
      case EXCLUDED:
         numExcluded++; 
         break;
      case NOT_FOUND:
         notFoundProb += probability;
         numNotFound++;
         break;
      default:
         assert(false);
         break;
      }
   }

   mainGroupSize += firstGroupSize;
   numFound      += mainGroupSize ;
   if (notFoundProb > notCorrectedNotFoundProb)
      notFoundProb = notCorrectedNotFoundProb;
}



int calculateScore(const ScoreParameters &param, MinData minDataP[MAX_MINUTIAE], MinData minDataG[MAX_MINUTIAE], 
                   const int k_score_pg_q          [NUM_CALC_SCORE_TYPES][SCORE_PG_Q_PARAM_SIZE1 ][SCORE_PG_Q_PARAM_SIZE2], 
                   const int k_score_pg            [NUM_CALC_SCORE_TYPES][SCORE_PG_PARAM_SIZE1   ][SCORE_PG_PARAM_SIZE2  ],
                   const int k_score               [NUM_CALC_SCORE_TYPES][SCORE_GROUP_SIZE       ],
                   const int k_score_common        [NUM_CALC_SCORE_TYPES][SCORE_COMMON_PARAM_SIZE],
                   const int k_score_minPG_bounds  [NUM_CALC_SCORE_TYPES][SCORE_PG_PARAM_SIZE1- 1],
                   const int k_score_minQ_bounds   [NUM_CALC_SCORE_TYPES][SCORE_Q_PARAM_SIZE1 - 1],
                   const int k_foundP              [NUM_CALC_SCORE_TYPES][SCORE_FOUND_PARAM_SIZE ], 
                   const int k_foundG              [NUM_CALC_SCORE_TYPES][SCORE_FOUND_PARAM_SIZE ])
{
   assert(param.calcScoreType < NUM_CALC_SCORE_TYPES);
   //printfParam(param);
   int  foundProbP[3], notFoundProbP = 0, numExcludedP = 0, numNotFoundP = 0;
   int  foundProbG[3], notFoundProbG = 0, numExcludedG = 0, numNotFoundG = 0;
   int firstGroupSize  = 0, mainGroupSize   = 0, numFound  = 0;
   int firstGroupSize1 = 0, mainGroupSize1  = 0, numFound1 = 0;
   int minNotFoundProbP = k_score_common[param.calcScoreType][0] / 128, minNotFoundProbG = k_score_common[param.calcScoreType][1] / 128;
   calcProbs (minDataP, param.m_numNestP, k_foundP[param.calcScoreType], minNotFoundProbP, firstGroupSize , mainGroupSize , numFound , foundProbP, notFoundProbP, numExcludedP, numNotFoundP);
   calcProbs (minDataG, param.m_numNestG, k_foundG[param.calcScoreType], minNotFoundProbG, firstGroupSize1, mainGroupSize1, numFound1, foundProbG, notFoundProbG, numExcludedG, numNotFoundG);
   assert (firstGroupSize == firstGroupSize1 && mainGroupSize == mainGroupSize1 && numFound == numFound1);

   if (!numFound)
      return 0;

   int minQ     = minAB (param.m_qualityP, param.m_qualityG); 
   if (!minQ) minQ = 1;
   int groupSize[3];
   groupSize[0] = firstGroupSize;
   groupSize[1] = mainGroupSize - firstGroupSize;
   groupSize[2] = numFound - mainGroupSize;

   
   int notFoundProb          = notFoundProbP + notFoundProbG;
   int allFoundProbP = foundProbP[0] + foundProbP[1] + foundProbP[2];
   int allFoundProbG = foundProbG[0] + foundProbG[1] + foundProbG[2];
   int allPossibleFoundProbP = allFoundProbP + notFoundProbP;
   int allPossibleFoundProbG = allFoundProbG + notFoundProbG;
   int maxPossibleFoundP     = param.m_numNestP - numExcludedP;
   int maxPossibleFoundG     = param.m_numNestG - numExcludedG;
   int minPG = minAB(maxPossibleFoundP, maxPossibleFoundG);
   int maxPG = maxAB(maxPossibleFoundP, maxPossibleFoundG);
   assert(minPG && maxPG);

   int index_PG   = getIndex (minPG, k_score_minPG_bounds[param.calcScoreType], SCORE_PG_PARAM_SIZE1 ); 
   int index_Q    = getIndex (minQ , k_score_minQ_bounds[param.calcScoreType] , SCORE_Q_PARAM_SIZE1); 
   int index_PG_Q = index_PG * SCORE_Q_PARAM_SIZE1 + index_Q; 

   int k0  = k_score_pg_q[param.calcScoreType][index_PG_Q][ 0];
   int k1  = k_score_pg  [param.calcScoreType][index_PG]  [ 0];
   int k2  = k_score_pg  [param.calcScoreType][index_PG]  [ 1];
   int k3  = k_score_pg  [param.calcScoreType][index_PG]  [ 2];
   int k4  = k_score_pg  [param.calcScoreType][index_PG]  [ 3];
   int k5  = k_score     [param.calcScoreType]            [ 0];
   int k6  = k_score     [param.calcScoreType]            [ 1];
   int k7  = k_score_pg  [param.calcScoreType][index_PG]  [ 4];
   int k8  = k_score_pg  [param.calcScoreType][index_PG]  [ 5];
   int k9  = k_score     [param.calcScoreType]            [ 2];
   int k10 = k_score     [param.calcScoreType]            [ 3];
   int k11 = k_score     [param.calcScoreType]            [ 4];
   int k12 = k_score     [param.calcScoreType]            [ 5];
   int k13 = k_score     [param.calcScoreType]            [ 6];
   int k14 = k_score     [param.calcScoreType]            [ 7];
   int k15 = k_score     [param.calcScoreType]            [ 8];
   int k16 = k_score     [param.calcScoreType]            [ 9];
   int k17 = k_score     [param.calcScoreType]            [10];
   int k18 = k_score     [param.calcScoreType]            [11];
   int k19 = k_score     [param.calcScoreType]            [12];
   int k20 = k_score     [param.calcScoreType]            [13];
   int k21 = k_score     [param.calcScoreType]            [14];
   int k22 = k_score     [param.calcScoreType]            [15];
   int k23 = k_score     [param.calcScoreType]            [16];
   int k24 = k_score_pg  [param.calcScoreType][index_PG]  [ 6];//k_score[param.calcScoreType][17];

   int k25 = k_score_pg_q[param.calcScoreType][index_PG_Q][1];

   int score =     
          +  (int)(k0 * param.m_topologySim[0] * groupSize[0] / (maxPossibleFoundP + maxPossibleFoundG) / (pow(param.m_distErrR[0], 0.5) + 1) / 2)
          +  (int)(k1 * param.m_topologySim[1] * groupSize[1] / (maxPossibleFoundP + maxPossibleFoundG) / (pow(param.m_distErrR[1], 0.5) + 1) / 2)
          +  (int)(k2 * param.m_topologySim[2] * groupSize[2] / (maxPossibleFoundP + maxPossibleFoundG) / (pow(param.m_distErrR[2], 0.5) + 1) / 2)
          
          -        k3 * param.m_distErrR[0] * groupSize[0] / (maxPossibleFoundP + maxPossibleFoundG) / 4
          -        k4 * param.m_distErrR[1] * groupSize[1] / (maxPossibleFoundP + maxPossibleFoundG) / 4
          -        k5 * param.m_distErrR[2] * groupSize[2] / (maxPossibleFoundP + maxPossibleFoundG) / 4

          +        k6 * foundProbP[0] / (allPossibleFoundProbP + 1) * 4 
          +        k7 * foundProbP[1] / (allPossibleFoundProbP + 1) * 4
          +        k8 * foundProbP[2] / (allPossibleFoundProbP + 1) * 4

          +        k9 * foundProbG[0] / (allPossibleFoundProbG + 1) * 4
          +        k10 * foundProbG[1] / (allPossibleFoundProbG + 1) * 4
          +        k11 * foundProbG[2] / (allPossibleFoundProbG + 1) * 4

          //-        k12 * param.m_minRelAngleErr[0] * groupSize[0] / (maxPossibleFoundP + maxPossibleFoundG) /  16 
          -        k13 * param.m_minRelAngleErr[1] * groupSize[1] / (maxPossibleFoundP + maxPossibleFoundG) /  16
          //-        k14 * param.m_minRelAngleErr[2] * groupSize[2] / (maxPossibleFoundP + maxPossibleFoundG) /  8

          -        k15 * param.m_angleErr[0]       * groupSize[0]  / (maxPossibleFoundP + maxPossibleFoundG) / 4
          //-        k16 * param.m_angleErr[1]       * groupSize[1]  / (maxPossibleFoundP + maxPossibleFoundG) / 256
          -        k17 * param.m_angleErr[2]       * groupSize[2]  / (maxPossibleFoundP + maxPossibleFoundG) / 32

          // ���� � � ������ ������ ���������������� �� ��������, �� �������� ...
          //-        k18 * param.m_relAngleErr[0]    * groupSize[0]   / (maxPossibleFoundP + maxPossibleFoundG) / 8
          //-        k19 * param.m_relAngleErr[1]    * groupSize[1]   / (maxPossibleFoundP + maxPossibleFoundG) / 256
          //-        k20 * param.m_relAngleErr[2]    * groupSize[2]   / (maxPossibleFoundP + maxPossibleFoundG) / 16

          -        k21 * param.m_angleErr1[0]      * groupSize[0]   / (maxPossibleFoundP + maxPossibleFoundG) / 32
          //-        k22 * param.m_angleErr1[1]      * groupSize[1]   / (maxPossibleFoundP + maxPossibleFoundG) / 128
          -        k23 * param.m_angleErr1[2]      * groupSize[2]   / (maxPossibleFoundP + maxPossibleFoundG) / 128

          
          +        k24 * 8 
          ;

   if (numFound < k25 / 8)                             
      score = score * numFound * 8 / k25;                 

   if      (score <         0) score =     0;
   else if (score > MAX_SCORE) score = MAX_SCORE;

   return score;
}

#pragma pack(pop)
} // namespace accelMatch{
