#ifndef ACCEL_DATA_H_
#define ACCEL_DATA_H_

#include <stdint.h>
#include <stdlib.h>
#ifdef USE_OMP
   #include <omp.h>
#endif

#include "Unwrap.h"
#include "accelPair.h"
#include "compAccel.h"
#include "accelTables.h"
#include "speedParam.h"
#include "correctSegmentationError.h"
#include "ma100.h"
#include "ma100_accel_TT.h"
#include "accelMatchEx.h"
#include "sse_proxy.h"

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)

#define MAX_UNPACKED_MINUTIAE       (4 * MAX_MINUTIAE) // maximum number of minutiae that can be unpacked
#define MAX_UNPACKED_SINGULAR       (4 * MAX_SINGULAR) // maximum number of singular that can be unpacked
#define MIN_RL_SIZE                 100
#define RL_SIZE_DIVISOR_1_MIB      512                 // minimum size of rl_size_divisor_1

extern AccelTables  g_accelTables;
bool initAccelTables(AccelTables *&accelTables);


struct ThreadData
{
   AccelPair     **m_localGroup;
   AccelPair      *m_bestGroup;
   RL_SET          m_rlSet;
   SS_RL_SET       m_ssRlSet;
   ESK::Unwrap    *m_unwrap;
	short          *m_radP; 
	short          *m_radG; 
	BYTE           *m_angP; 
	BYTE           *m_angG; 
   AccelPair       m_accelPair;
   SortedAccel     m_sortedAccelG;
   ESK::Link      *m_link;
   ESK::Sign      *m_minutiae;
   ESK::Sign      *m_sing;
   BYTE           *m_area;
   FingerPairsSet  m_pairSet;
   Triplet         m_t[MAX_TRIPLETS];

   Ma100_accel_TT  m_ma;
   //Ma200          m_ma;

   ThreadData()
   {
      m_localGroup      = NULL;
      m_bestGroup       = NULL;
      m_unwrap          = NULL;
		m_radP            = NULL;
		m_radG            = NULL;
		m_angP            = NULL;
		m_angG            = NULL;
      m_link            = NULL;
      m_minutiae        = NULL;
      m_sing            = NULL;
      m_area            = NULL;
      m_accelPair.clear();
   }
   bool alloc()
   {
      m_localGroup = new AccelPair*[MAX_LOCAL_GROUP_1ST];
      m_bestGroup  = new AccelPair;
      if (!m_localGroup || !m_bestGroup)
         return false;
      for(int i = 0; i < MAX_LOCAL_GROUP_1ST; i++)
      {
         m_localGroup[i] = new AccelPair;
         if (!m_localGroup[i] || !m_localGroup[i]->init())
            return false;
      }
      if (!m_accelPair.init() || !m_bestGroup->init())
         return false;
      m_unwrap = ESK::Unwrap::create();
      if (!m_unwrap) 
      {
//         printf ("Seems like Vova protect again!\n");
         return false;
      }
#if defined (_ESK_ID)
      m_unwrap->versor (_ESK_ID);
#endif
//      m_unwrap->factor ((ESK::LAUNCH)0, false);   // unpack distance between minutiae and topology
      m_unwrap->factor (false);                    // unpack distance between minutiae and topology
		m_radP      = new short[MAX_ACCEL_MIN];
		m_radG      = new short[MAX_ACCEL_MIN];
		m_angP      = new BYTE [MAX_ACCEL_MIN];
		m_angG      = new BYTE [MAX_ACCEL_MIN];
      m_link      = new ESK::Link [MAX_UNPACKED_MINUTIAE];        
      m_minutiae  = new ESK::Sign [MAX_UNPACKED_MINUTIAE];        
      m_sing      = new ESK::Sign [MAX_UNPACKED_SINGULAR];
      m_area      = new BYTE[MAX_WIDTH * MAX_HEIGHT / 8 / 8];
		return (m_radP && m_radG && m_angP && m_angG && m_link && m_minutiae && m_sing && m_area);
   }
   bool initMa(void *accelHandle)
   {
      return (m_ma.init (accelHandle) == MA_OK);
//      return (m_ma.init() == MA_OK);
   }
   ~ThreadData()
   {
      if (m_localGroup)
      {
         for(int i = 0; i < MAX_LOCAL_GROUP_1ST; i++)
            if (m_localGroup[i]) delete m_localGroup[i], m_localGroup[i] = NULL;
         delete [] m_localGroup, m_localGroup = NULL;
      }
      if (m_bestGroup) delete m_bestGroup, m_bestGroup = NULL; 
      
      if (m_unwrap) ESK::Unwrap::cancel(m_unwrap), m_unwrap = NULL;
		if (m_radP    ) delete [] m_radP    , m_radP     = NULL;   
		if (m_radG    ) delete [] m_radG    , m_radG     = NULL;   
		if (m_angP    ) delete [] m_angP    , m_angP     = NULL;   
		if (m_angG    ) delete [] m_angG    , m_angG     = NULL;   
		if (m_link    ) delete [] m_link    , m_link     = NULL;   
		if (m_minutiae) delete [] m_minutiae, m_minutiae = NULL;   
		if (m_sing    ) delete [] m_sing    , m_sing     = NULL;   
      if (m_area    ) delete [] m_area    , m_area     = NULL; 
   }
   void clearRl()
   {
      m_rlSet.clear();
   }
   void clear_ss_Rl()
   {
      m_ssRlSet.clear();
   }
};

struct AccelData
{
   bool            m_init;
   bool            m_initFinalMatching;
   ThreadData     *m_threadData; 
   unsigned int    m_numThreads;
   BYTE           *m_probeAccel     [10];
   BYTE           *m_probeFullAccel [10];
   BYTE           *m_areaP          [10];
   int             m_widthP         [10];
   int             m_heighP         [10];
   int             m_areaWidthP     [10];
   int             m_areaHeightP    [10];
   Accel          *m_accelP         [10]; 
//   BYTE           *m_accelSignP     [10];
//   MainAccel      *m_mainAccelP   [10]; 
   BYTE           *m_accelNumP      [10];
   MinutiaeData   *m_minP           [10];
   SortedAccel     m_sortedAccelP   [10]; 
   AllAccel       *m_allAccelP      [10];
   BYTE           *m_accelBuffer    [10];
//   AnchorAccel    *m_anchorAccelP [10]; 
   PersonalData    m_personalDataP;
	AccelTables    *m_accelTables;
   
   SS_RL          *m_rl          ;
   size_t          m_rlSize      ;
   uint64_t       *m_id          ; 
   BYTE          **m_galleryAccel; 
   TpTemplate     *m_galleryTemplate;
   uint64_t        m_realGallerySize;
   unsigned int    m_ipVer;
   
   AccelData()
   {
      memset(this, 0, sizeof(AccelData));
      m_numThreads   = 1;
      m_personalDataP.clear();
      m_ipVer = 73;
   }
   bool allocTemplates(unsigned int gallerySize)
   {
      freeTemplates();
      if (!gallerySize)
         return false;
      m_id              = new uint64_t        [gallerySize];
      m_galleryAccel    = new BYTE*           [gallerySize];
      m_galleryTemplate = new TpTemplate      [gallerySize];
	   return (m_id && m_galleryAccel && m_galleryTemplate);
   }
   void freeTemplates()
   {
      if (m_id             ) delete [] m_id             , m_id              = NULL;
      if (m_galleryAccel   ) delete [] m_galleryAccel   , m_galleryAccel    = NULL;
      if (m_galleryTemplate) delete [] m_galleryTemplate, m_galleryTemplate = NULL;
   }
   bool initFinalMatching (void *accelHandle, unsigned int &maxGallerySize)
   {
      int arrangeSize = 10 * 1024 * 1024;
      if (!maxGallerySize) maxGallerySize = arrangeSize;
      maxGallerySize = (maxGallerySize + arrangeSize - 1) / arrangeSize * arrangeSize;
      if (m_initFinalMatching) return true;
      if (!m_init)             return false;
      // allocate memory for recommended list
      m_rlSize = maxGallerySize / RL_SIZE_DIVISOR_1_MIB;
      if (m_rlSize < MIN_RL_SIZE) m_rlSize = MIN_RL_SIZE;
      m_rl              = new SS_RL        [m_rlSize];
		if (!m_rl)
			return false;
      // initialize ma in all threads
      for(unsigned int i = 0; i < m_numThreads; i++)
         if (!m_threadData[i].initMa(accelHandle))
            return false;
      m_initFinalMatching = true;
      return m_initFinalMatching;
   }
   bool init (unsigned int &numThreads, int ipVer)
   {
      if (m_init)
         return true;

      m_ipVer = ipVer;
      m_numThreads = 1;
#if defined (USE_OMP) & !defined (ADJUST) 
      m_numThreads = numThreads ? numThreads : omp_get_num_procs();
      omp_set_num_threads(1);
      omp_set_dynamic(0);// ��� �����, �������� �� 0 ��������, Ip110 �������� � ������������� ������!!!
                         // ����� ����, ���������, ��� � 0-� TECH5_FPM �������� ������� �������  �� �6-�8 (��. ������ �� 20.05.15)
#endif
//      m_init = alloc() && m_accelTables->init();
      m_init = alloc() && initAccelTables(m_accelTables);
      numThreads = m_numThreads;
      return m_init;
   }

   bool alloc()
   {
      free();
      m_threadData = new ThreadData[m_numThreads];
      for(unsigned int i = 0; i < m_numThreads; i++)
         if (!m_threadData[i].alloc())
            return false;
      int maxFullAccelSize = getMaximOneFingerFullAccelSize (); 
      int maxAreaSize = MAX_WIDTH * MAX_HEIGHT / 8 / 8;
//  		m_accelTables = new AccelTables();

      for (int i = 0; i < 10; i++)
      {
#ifdef SSE_SUPPORT
   #ifdef _WINDOWS
         m_accelBuffer    [i] = (BYTE*) _aligned_malloc(maxFullAccelSize, 16);
         m_probeFullAccel [i] = (BYTE*) _aligned_malloc(maxFullAccelSize, 16);
//         m_anchorAccelP[i] = (AnchorAccel*) _aligned_malloc(sizeof(AnchorAccel) * MAX_ACCEL_MIN, 16);
   #else 
         if(posix_memalign((void**)&m_accelBuffer[i],    16, maxFullAccelSize))
            m_accelBuffer[i] = NULL;
         if(posix_memalign((void**)&m_probeFullAccel[i], 16, maxFullAccelSize))
            m_probeFullAccel[i] = NULL;
//         if(posix_memalign((void**)&m_anchorAccelP[i], 16, sizeof(AnchorAccel) * MAX_ACCEL_MIN))
//            m_anchorAccelP[i] = NULL;
   #endif // _WINDOWS
#else
         m_accelBuffer    [i] = (BYTE*) malloc (maxFullAccelSize);
         m_probeFullAccel [i] = (BYTE*) malloc (maxFullAccelSize);
#endif // SSE_SUPPORT
         m_areaP[i] = new(std::nothrow) BYTE [maxAreaSize];

         if (!m_areaP[i] || !m_accelBuffer[i] || !m_probeFullAccel[i])// || !m_anchorAccelP[i]) 
            return false;
      }
      return true;
   }
   ~AccelData()
   {
      free();
   }
   void free()
   {
      if (m_threadData     ) delete [] m_threadData     , m_threadData      = NULL;
      if (m_rl             ) delete [] m_rl             , m_rl              = NULL;
      freeTemplates();
      for (int i = 0; i < 10; i++)
      {
         if (m_accelBuffer[i])
#if defined(_WINDOWS) && defined(SSE_SUPPORT) 
            _aligned_free (m_accelBuffer[i]), m_accelBuffer[i] = NULL;
#else
            ::free (m_accelBuffer[i]), m_accelBuffer[i] = NULL;
#endif

         if (m_probeFullAccel[i])
#if defined(_WINDOWS) && defined(SSE_SUPPORT) 
            _aligned_free (m_probeFullAccel[i]), m_probeFullAccel[i] = NULL;
#else
            ::free (m_probeFullAccel[i]), m_probeFullAccel[i] = NULL;
#endif
//         if (m_anchorAccelP[i])
#if defined(_WINDOWS) && defined(SSE_SUPPORT) 
//            _aligned_free (m_anchorAccelP[i]), m_anchorAccelP[i] = NULL;
#else
//            ::free (m_anchorAccelP[i]), m_anchorAccelP[i] = NULL;
#endif
         if (m_areaP[i]) 
         {
            delete [] m_areaP[i];
            m_areaP[i] = NULL;
         }
      }
   }
   void clearRl()
   {
      for (unsigned int i = 0; i < m_numThreads; i++)
         m_threadData[i].clearRl();
   }
   void clear_ss_Rl()
   {
      for (unsigned int i = 0; i < m_numThreads; i++)
         m_threadData[i].clear_ss_Rl();
   }
   void clearProbe(int finger = -1)
   {
      int startFinger = finger == -1 ? 0 : finger;
      int stopFinger  = finger == -1 ? 9 : finger;
      for(int i = startFinger; i <= stopFinger; i++)
      {
         m_accelNumP[i]      = 0;
         m_allAccelP[i]      = 0;      
      }
   }
	int getAngleDif (BYTE angleP, BYTE angleG, BYTE angle = 0)
	{
      assert (m_accelTables);
		return m_accelTables->getAngleDif (angleP, angleG, angle);
	}
};

inline unsigned int getThreadNum (AccelData *accelData)
{
   unsigned int threadNum = 0;
#ifdef USE_OMP
      threadNum = omp_get_thread_num() * (accelData->m_numThreads > 1);
#endif
   return threadNum;
}

inline ThreadData* getThreadData (AccelData *accelData, unsigned int threadNum)
{
   return &accelData->m_threadData[threadNum];
}


inline bool checkMinutiaeAngle(AccelData *accelData, BYTE angleP, BYTE angleG, BYTE angleTol)
{
   return (accelData->getAngleDif (angleP, angleG) <= angleTol);
}


void calcAccel_base(AccelTables *accelTables, ESK::Sign *minutiae, ESK::Link *link, size_t numNest, 
                    ESK::Sign *sing, size_t numSing, BYTE *area, WORD width, WORD height, DWORD *accelSize, BYTE *accelBuf, 
                    BYTE quality, BYTE patternType, BYTE *fullAccel = NULL);


int buildGroup(AccelData *accelData, int probeFinger, AccelSearchParam &param, AccelPair *g, SortedAccel *aG, 
              MinutiaeData *minG, int numMinutiaeG, AccelPair **localGroup, 
               unsigned int minPointInLocalGroup_1st, unsigned int minPointInLocalGroup_2nd, 
               BYTE qualityG, unsigned int threadNum, AccelPair *bestGroup = NULL);

inline void combineThreadsRl (AccelData *accelData, RL_SET &rlSet)
{
   assert (accelData && accelData->m_init);

   rlSet.clear();
   RL_SET::iterator p, pEnd;
   for (unsigned int i = 0; i < accelData->m_numThreads; i++)
   {
      p    = accelData->m_threadData[i].m_rlSet.begin();
      pEnd = accelData->m_threadData[i].m_rlSet.end();
      for(; p != pEnd; p++)
         rlSet.insert(*p);
   }
}
inline void combine_ssThreadsRl (AccelData *accelData, SS_RL_SET &rlSet)
{
   assert (accelData && accelData->m_init);

   rlSet.clear();
   SS_RL_SET::iterator p, pEnd;
   for (unsigned int i = 0; i < accelData->m_numThreads; i++)
   {
      p    = accelData->m_threadData[i].m_ssRlSet.begin();
      pEnd = accelData->m_threadData[i].m_ssRlSet.end();
      for(; p != pEnd; p++)
         rlSet.insert(*p);
   }
}


inline void fillRecomList (RL_SET &rlSet, RL *rl, size_t sizeRl)
{
   assert (rl);
   memset(rl, 0, sizeof(rl[0]) * sizeRl);

   RL_SET::iterator p = rlSet.begin();
   RL_SET::iterator pStop = rlSet.end();
   for(size_t i = 0; i < sizeRl && p != pStop; i++, p++)
   {
      rl[i].regNum = p->regNum;
      rl[i].finger = p->finger;
      rl[i].score  = p->score ;
   }
}

inline void fillRecomList (SS_RL_SET &rlSet, RL *rl, size_t sizeRl)
{
   assert (rl);
   memset(rl, 0, sizeof(rl[0]) * sizeRl);

   SS_RL_SET::iterator p = rlSet.begin();
   SS_RL_SET::iterator pStop = rlSet.end();
   for(size_t i = 0; i < sizeRl && p != pStop; i++, p++)
   {
      rl[i].regNum = p->regNum     ;
      rl[i].score  = p->fusionScore;
   }
}

inline void buildFinalRecomList (RL *rl, size_t sizeRl, uint64_t *id)
{
   assert (rl && id);

   for(size_t i = 0; i < sizeRl; i++)
   {
      if (!rl[i].score)
         break;
      rl[i].regNum = id[rl[i].regNum];
   }
}


inline void updateTopRecomList (SS_RL_SET &rlSet, size_t numUpdateRecords, RL *rl, size_t sizeRl)
{
   assert (rl);
   if (numUpdateRecords > sizeRl)
      numUpdateRecords = sizeRl;

   SS_RL_SET::iterator p = rlSet.begin();
   SS_RL_SET::iterator pStop = rlSet.end();
   for(size_t i = 0; i < numUpdateRecords && p != pStop; i++, p++)
   {
      rl[i].regNum = p->regNum     ;
      rl[i].score  = p->fusionScore;
   }
}

inline void checkSearchSpeedLT (AccelSearchParam &param)
{
   unsigned int maxSearchSpeed = sizeof(g_speedParamsLT) / sizeof(g_speedParamsLT[0]) - 1;
   if (param.searchSpeed > maxSearchSpeed)
      param.searchSpeed = maxSearchSpeed;
}

int loadProbeFinger (AccelData *accelData, BYTE *templ, int finger, unsigned int threadNum);
bool checkOneFingerAccel(BYTE *accel, bool fullCheck);
void compMainNests(AccelData *accelData, Triplet *t, AccelPair *accelPair, unsigned int *minSim, 
                          int numP, int numG, Accel *accelP, Accel *accelG, 
                          BYTE  *accelNumP, BYTE  *accelNumG,
                          MinutiaeData *minP, MinutiaeData *minG, int angleTol, 
                          AllAccel *allAccelP, AllAccel *allAccelG, unsigned int minFill);

#pragma pack(pop)
} // namespace accelMatch{

#endif  // ACCEL_DATA_H_



