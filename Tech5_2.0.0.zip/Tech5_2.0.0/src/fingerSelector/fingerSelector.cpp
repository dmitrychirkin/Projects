/*****************************************************************************
	fingerSelector.cpp - implementation of the finger selection (Fc) class 
	The Fc class is used for choose the best pair of fingers 
	for  matching in multifinger matching algorithm (MA) of Core Matching SDK

	The Core Matching SDK is the high-level tool, intended for easy creating
    of your own scalable biometric applications that use the person's fingerprint 
	for identification or verification purpose. 

*******************************************************************************/
#include <stdlib.h>
#include <memory.h>

#include "ma100.h"
#include "fingerSelector.h"
#include "sfsDef.h"
#include "win2lin.h"

#define _CRT_SECURE_NO_WARNINGS


Fs::Fs()
{
   m_num1 = m_num2 = 0;
}


int Fs::loadTemplate (unsigned int numFingers, TemplateData templSet[], 
                      Quality quality[], int &num)
{
   clear(quality, 10);
	if (numFingers <= 0 || numFingers > 10)	
      return MA_WRONG_FINGER_NUMBER;
	if (!templSet) 
      return MA_WRONG_POINTER;
	unsigned int finger = 0;

	for(unsigned int i = 0; i < numFingers; i++)
	{
		finger = templSet[i].numFinger;
		if (finger < 1 || finger > 10) 
         continue;
		if (!templSet[i].fpTemplate)   
         continue;
      TemplHeader * header = (TemplHeader*)templSet[i].fpTemplate;
		quality[finger - 1].set(finger, header->quality, (BYTE)header->points, header->relPoints);
	}
   num = numFingers;
	return MA_OK;
}

int Fs::loadTemplate1 (unsigned int numFingers, TemplateData templSet[])
{
	return loadTemplate (numFingers, templSet, m_quality1, m_num1);
}

int Fs::loadTemplate2 (unsigned int numFingers, TemplateData templSet[])
{
	return loadTemplate (numFingers, templSet, m_quality2, m_num2);
}

int compareQuality(const void *q1, const void* q2)
{
   Quality *quality1 = (Quality*)q1;
   Quality *quality2 = (Quality*)q2;

   if      (*quality1 > *quality2)   return -1;
   else if (*quality1 < *quality2)   return  1;
   else                              return 0;  
}
/*
	returns the numbers of finger pairs those available for match and
	ourputs the sorted list of fingerprints pairs  (the top number is the best pair)
*/
int Fs::getBestPairs(unsigned int numFinger[10], MATCHING_MODE  matchingMode)
{
	memset(numFinger, 0, sizeof(int) * 10);
	if (!m_num1 || !m_num2) 
      return 0;

	unsigned int i = 0;
	Quality quality[10];
   unsigned int maxPairs = 0;
   if (matchingMode == CHECK_MIX_FINGER_MATCHING_MODE)
   {
      for(i = 0; i < 10; i++)
         quality[i] = m_quality1[i];
      maxPairs = m_num1;
   }
   else
   {
      for(i = 0; i < 10; i++)
         quality[i] = m_quality1[i] + m_quality2[i];
      maxPairs = minAB(m_num1, m_num2);
   }
	qsort (quality, 10, sizeof(Quality), compareQuality);
	// get number of real pairs
   unsigned int numPairs = 0;
   int finger = 0;
   for(unsigned int i = 0; i < maxPairs; i++)
   {
      finger = quality[i].getFinger();
      if (finger)
         numFinger[numPairs++] = finger;
   }
	return numPairs;
}
