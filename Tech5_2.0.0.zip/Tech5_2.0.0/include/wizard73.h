/**************************************
            Wizard.h 
    Definitions for compatible.

			  Version 73
	  Patented topology system.

	    Author Gudkov V.U.
***************************************/
#include    <memory.h>
#include    <string.h>

//	Workspace definition
#include		"coreSdk.h"
#include		"./expimp73.h"
#include		"./typdef73.h"
#include		"assert.h"
#include		"./sorter73.h"
#include		"./mathem73.h"

//	Sentry
#if !defined (__WIZARD_73_H)
	#define __WIZARD_73_H

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

extern byte skeletMask[256];
extern bool integ;

	#define ARGUMS_COSM_SCALE_HALF  (128)
	#define ARGUMS_COSM_SCALE		(ARGUMS_COSM_SCALE_HALF*2)
	#define ARGUMS_SINM_SCALE_HALF	(128)
	#define ARGUMS_SINM_SCALE		(ARGUMS_SINM_SCALE_HALF*2)
   // coefficient of change image DPI for quick up the processing
   #define K_CHANGE_DPI             2//1.43
	
//#define SAVE_LAYERS
#ifdef SAVE_LAYERS
   extern bool g_writeLog;
#endif
	//	Image common definitions
   enum
   {
	   REMAIN	=	128,					//precision 32,64...
	   COLOUR	=	1,						//colour sign
	   MAXDPI	=	2000,					//maximum DPI
	   DEFDPI	=	500,					//normal DPI
	   MINDPI	=	125,					//minimum DPI
	   DEFDIR	=	0	,					//image axis x orientation
	   TIPDIR	=	(DEFDIR+90),		//image axis y orientation
	   LIMDPI	=	140,					//card DPI
	   _MAX_X	=	3000,					//max x size P,S
	   _MAX_Y	=	_MAX_X,				//max y size P,S
	   _MAL_X	=	MAX_WIDTH,//800,					//max x size L,F
	   _MAL_Y	=	MAX_HEIGHT,//_MAL_X,				//max y size L,F
	   _MIN_X	=	64,					//min x size
	   _MIN_Y	=	_MIN_X				//min y size
   };



	//	Definitions for limit
   enum
   {
	   MAXFIN	=	255,					//finger minutiaes
	   MAXPAL	=	2550,					//palm minutiaes
	   NFOCUS	=	16,						//focus bsize
	   VESIGN	=	73,						//sign version
	   NETMAX	=	(16+1),				//maximum section depth
	   NETMIN	=	(4 +1)				//minimum section depth
   };
	//	Extended image type
   enum
   {
	   PALMSX	=	0x0000,				//palmprint
	   ARCH_P	=	0x0001,				//plain arches
	   ARCH_T	=	0x0002,				//tented arches
	   LOOP_R	=	0x0004,				//plain right loops
	   LOOPAR	=	0x0008,				//curved right loops
	   LOOP_L	=	0x0010,				//plain left loops
	   LOOPAL	=	0x0020,				//curved left loops
	   WHORLP	=	0x0040,				//plain whorls
	   LOOPCR	=	0x0080,				//right central pocket loops
	   LOOPCL	=	0x0100,				//left central pocket loops
	   LOOP_T	=	0x0200,				//twin loops
	   LOOPLP	=	0x0400,				//lateral pocket loops
	   ACCIDS	=	0x0800,				//accidentals
	   LOOP_D	=	0x0600,				//double loops as collection
	   LOOPCP	=	0x0180,				//central pocket loops
	   WHORLS	=	0x0fc0,				//whorls collection
	   ARMADA	=	0x003c				//loops collection
   };

	//	Image type
   enum
   {
	   ARCHSC	=	0x01,					//classical arch
	   ARCHSU	=	0x02,					//tented arch
	   LOOPRC	=	0x04,					//classical right loop
	   LOOPRU	=	0x08,					//another right loop
	   LOOPLC	=	0x10,					//classical left loop
	   LOOPLU	=	0x20,					//another left loop
	   WHORLC	=	0x40,					//classical whorl
	   WHORLU	=	0x80					//complicated
   };
	//	Grid hierarchy definitions
   enum
   {
	   ECHE0		=	0,						//first echelon
	   ECHEM		=	5,						//echelon quantity
	   POWER		=	68,						//echelon power
	   GRAIN		=	4,						//grid grain [2,4,8..]
	   SCALE		=	64						//on a small scale
   };
	//	Special processing definitions
   enum
   {
	   _IND_		=	NFOCUS,				//indignations
	   _NET_		=	NETMAX,				//net power
	   _ARM__	=		4,						//arm quantity
	   _LIN_		=	(NETMAX*2 +1),		//maximum links
	   _SET__	=	100,					//queue process set
	   _PAL_		=	3,						//palette
	   _TIP_		=	10,						//tiptoe
	   _ROW_		=	2,						//rows on card
	   _GEN_		=	240,					//indignation prelimit
	   _DIR_		=	8,						//grid directions
	   _HAR_		=	14,						//harmons
	   _SPY_		=	16,						//spy tail
	   _FRM_		=	320,						//variations of formula
	   _PRI_		=	2,						//primary
	   _SEC_		=	5,						//secondary
	   _SUS_		=	3,						//sub-secondary
	   DAISY		=	(_DIR_+1),			//daisy
	   SSTEP		=	20,						//ray size > HH+end
	   SCONV		=	(17*17+1),			//huge convolution
	   SRANK		=	256,					//rank buffer size
	   SCORN		=	181,					//corner buffer size
	   SCROP		=	64						//crop buffer size
   };
	//	Rank for harmon
   enum
   {
	   HL			=	4, 					//min harmon
	   HH			=	(HL+_HAR_-1),		//max harmon
	   HP			=	8,						//harmon proportion
	   HL_Q		=	2, 					   //min harmon - quick processing
	   HH_Q		=	(HL_Q + _HAR_- 1)	//max harmon - quick processing
   };
	//	Rank for quality
   enum
   {
	   QL			=	0,						//min quality
	   QH			=	63						//max quality
   };
	//	Module quantity
   enum
   {
   	MO			=	127					//simple module
   };
	//	Degrees for gradient
   enum
   {
	   AC			=	23,						//23  degree
	   AQ			=	45,						//45  degree
	   AR			=	90,						//90  degree
	   AW			=	135,					//135 degree
	   AH			=	180,					//180 degree
	   AO			=	225,					//225 degree
	   AL			=	270,					//270 degree
	   AU			=	315,					//315 degree
	   AF			=	360,					//360 degree
	   AN			=	255					//nothing
   };
	//	Pixel bright definitions
   enum
   {
	   BM			=	0xff,					//maximum
	   BA			=	0x7f,					//average
	   BB			=	0x00,					//bifurcation
	   BE			=	0x01,					//enging
	   BU			=	0x03,					//hidrance
	   BP			=	0x04,					//projections
	   BL			=	0x05,					//left branch
	   BR			=	0x06,					//right branch
	   BS			=	0x07,					//skeleton
	   BF			=	0x08,					//flash
	   BV			=	0x10,					//veil
	   BG			=	0x80,					//skeleton gap (1 << 7)
	   BX			=	0x70,					//marked
	   VB			=	(BB|BV),				//veiled bifurcation
	   VE			=	(BE|BV),				//veiled ending
	   VU			=	(BU|BV),				//veiled hidrance
	   VP			=	(BP|BV),				//veiled projection
	   VL			=	(BL|BV),				//veiled left branch
	   VR			=	(BR|BV),				//veiled right branch
	   VS			=	(BS|BV)				//veiled skeleton
   };
	//	Class definitions
   enum
   {
	   C0			=	0x00,					//empty
	   C1			=	0x01,					//paper
	   C2			=	0x02,					//prooved flow
	   C3			=	0x04,					//supposed flow
	   C4			=	0x08,					//masked flow
	   C5			=	0x10,					//pattern flow
	   C6			=	0x20,					//working area
	   C7			=	0x40,					//bad area




	   C8			=	0x80,					//sign mask
	   CG			=	(C2|C3),				//groop flow
	   CZ			=	(C7|C1),				//complex zone
	   CA			=	(CZ|C6)				//any zone
   };
	//	Work definitions
   enum
   {
	   W0			=	0x00,					//nothing area
	   W1			=	0x01,					//veiled area
	   W2			=	0x02,					//focus area
	   W3			=	0x04,					//locked area
	   W4			=	0x08,					//common area
	   W5			=	0x10,					//without image
	   W6			=	0x20					//local work area
   };
	
	//	Hierarchy definitions
   enum
   {
	   H0			=	0x00,					//original
	   H1			=	0x01,					//detailed
	   H2			=	0x02,					//small
	   H3			=	0x03,					//base
	   H4			=	0x04					//large
   };
	//	Focus definitions
   enum
   {
	   FN			=	0x00,					//nothing
	   FW			=	0x01,					//whole
	   FL			=	0x02,					//loop
	   FD			=	0x08,					//delta
	   FX			=	0x10,					//axe
	   FF			=	(FW|FL|FD),			//any focus
	   FS			=	0x40,					//focus area
	   FV			=	0x80					//veiled focus
   };

	//	Ridge count definitions
   enum
   {
   	RM			=	0x1f,					//equal or more
	   RT			=	0x03					//threshold
   };
	//-------------------------------------
	//	Enumerator type for events
	//-------------------------------------
	enum
	{
		E0		= 0x0,								//broken
		Ed		= 0xd,								//right ending -><-
		E9		= 0x9,								//right ending	
		Ee		= 0xe,								//left ending -><-
		Ea		= 0xa,								//left ending
		E5		= 0x5,								//right bifurcation -><-
		E1		= 0x1,								//right bifurcation
		E6		= 0x6,								//left bifurcation -><-
		E2		= 0x2,								//left bifurcation 

		Ef		= 0xf,								//ending
		E3		= 0x3,								//bifurcation
		E7		= 0x7,								//bifurcation anti-clockwize
		Eb		= 0xb									//bifurcation clockwize
	};

	//-------------------------------------
	//	Enumerator type for errors
	//-------------------------------------
	enum ERRORS
	{
		SUCCES =  0,								//success
		DEFMEM = -1,								//no memory
		BIGIMG = -2,								//large image
		STUMPS = -3,								//tiny image
		NOTIMG = -4,								//nothing
		UNTIED = -5,								//incorrected process

		UNTYPE = -6,								//unknown image type
		MODULE = -7,								//module protection
		RUINED = -8,								//ruined data
		STATUS = -9									//corruption of status
	};

	//-------------------------------------
	//	Enumerator type for name of lays
	//-------------------------------------
	enum	
	{
		//image layers
		SOURCE =	0x00,								//source image
		NORMAL,										//normal image
      PARITY,
		NEEDLE,										//needle image
		REFINE,										//refine image

		SKELET,										//skeleton
		DIFFER,										//difference
		PROPHE,										//prophecy
		UNPACK,										//unpack skeleton
		TARGET,										//target
		LIGHTS,										//light

		//colour lays
		PALL_R = 0x10,								//red pallet
		PALL_G,										//green pallet
		PALL_B,										//blue pallet
		PHOTIC,										//photolay
		EMPIRE,										//empire wave
		SHADOW,										//shadow
		
		//flow type
		FLOW_L =	0x20,								//flow local
		FLOW_V,										//flow victory

		FLOW_M,										//flow model
		FLOW_P,										//flow pattern
		FLOW_E,										//flow expert
		FLOW_F,										//focus alpha
		FLOW_R,										//rich flow
		
		//curvature...
		ARCH_D =	0x30,								//direction
		ARCH_V,										//value

		//line density
		DENSIT =	0x38,								//the original
		DENS_M,										//for minutiae

		//the spectrum
		SPEC_O = 0x40,								//original
		SPEC_S = 0x60,								//synthetic

		//probability

		PROB_L =	0x70,								//local probability
		PROB_V,										//victory probability
		PROB_M,										//model probability
		PROB_G,										//gradient probability
		PROB_H,										//harmon probability
		CONC_G,										//gradient concordance
		CONC_H,										//harmon concordance
		PROB_R,										//rich probability

		//class field
		CCLASS = 0x80,								//the common
		FCLASS,										//for focus
		MORDER,										//for man's order
		DORDER,										//for man's direction

		//the quality
		QUAL_S = 0x90,								//for stream
		QUAL_E,										//expert
		QUAL_P,										//for pattern
		QUAL_M,										//for minutiae

		//mathematical
		MATH_I =	0x98,								//index

		//the goals
		GOAL_S = 0xa0,								//stream goal
		GOAL_F,										//filter goal
		GOAL_R,										//ridge goal
		GOAL_I,										//iterations
		GOAL_M,										//minutiae goal

		//the lists
		LIST_M = 0xb0,								//minutiae list
		LISTpM,										//packed minutiaes
		LISTpI,										//packed indignations
		LISTpL,										//packed links
		LIST_T,										//total metric

		LIST_R,										//ridge count
		LIST_A,										//regions list
		J_FR  = 0x0100,	//needs 4
		J_PR  = 0x0105,	//needs 4
		I_B = 0x0110,
		I_M,
		//temporary...
		TEMP_T = 0xf0,								//common
		TEMP_L = 0xff								//local
	};
	
	//-------------------------------------
	//	Enumerator type for processing
	//-------------------------------------
	enum
	{
		//finger order
		SOUrce = 0x00,
		RELoad,
		LIGhtf,
		STReam,
		COHere,
		PICkup,
		IFOcus,
		RESpon,
		XFOcus,
		LIGhts,
		ATTrac,
		SWElls,
		FLOwer,
		CURvat,
		FURiew,

		HARmon,
		EXPert,

		LAYing,
		FILter,
		SKElet,
		MINuti,
		LINker,
		EPIlog,

		//for tenprint
		TARget,
		FRAmes
	};

	//-------------------------------------
	//	Enumerator type for projection
	//-------------------------------------
	enum
	{
		//own levels
		LightF = -1,
		StreaM = -1,
		CoherE = -1,
		PickuP = -1,
		IfocuS = H1,
		RespoN = H1,
		XfocuS = H1,
		LightS = -1,
		AttraC = H1,
		SwellS = H1,
		FloweR = H1,
		CurvaT = H1,
		FurieW = H1,
		HarmoN = H1,
		ExperT = H1,
		LayinG = H1,
		FilteR = -1,
		SkeleT = -1,
		MinutI = -1,
		LinkeR = -1,
		EpiloG = -1,

		//own levels
		TargeT = H1,
		FrameS = -1
	};

	//packing alignment 
#ifdef _WINDOWS
	#pragma	pack(push, 1 )
#endif

	/**************************************
			Declarations of structures
	**************************************/

	//	Coordinate structure
	struct P_PACKED_1 WZD_EI SCoor
	{
		int		Movx,								//x position
	            Movy;								//y position
	};

	//	Pace structure
	struct P_PACKED_1 WZD_EI SPace

	{
      int		Movx,								//x position
	            Movy;								//y position
		byte*    Movo;								//o step
	};

	//	Step structure
	struct P_PACKED_1 WZD_EI SStep
	{
      int		Movx,								//x position
	            Movy;								//y position
		byte*    Movo;								//o step
		int_t		IncO;								//o step
		int	   Dose;								//pixel dose
	};

	//	Arms structure
	struct P_PACKED_1 WZD_EI SArms
	{
      int		Movx,								//x position
	            Movy;								//y position
		byte*    Movo;								//o step
		byte*    Join;								//o joining
		int		Deal,								//event
				   Item,								//number
				   Beta,								//alpha
				   Pink;								//ping-pong
	};

	//	Area structure
	struct P_PACKED_1 WZD_EI SArea
	{
      int		Movx,								//x position
	            Movy;								//y position
		byte*    Movo;								//o step
		int		IncO,								//o step
				   Dose;								//pixel dose
		int		FroX,								//x frontier
				   FroY;								//y frontier
	};


	//	Feature structure
	struct P_PACKED_1 WZD_EI SFeat
	{
            int     Movx,								//x position
                    Movy;								//y position
            byte    Type,								//type
                    Lace,								//scale
                    Prob,								//probability
                    Beta;								//beta
	};

	//	Minutiaes structure
	struct P_PACKED_1 WZD_EI SSign
	{
            int   Movx,								//x position
	          Movy;								//y position
            byte  Type,								//type
                  Lace,								//scale
                  Prob,								//probability
                  Beta;								//beta
            byte  Look,								//look
                  Curl;								//curvature
	};

	//	Rectangle structure
	struct P_PACKED_1 WZD_EI SRect
	{
		int		L_re,								//left	
				R_re,								//right
				T_re,								//top
				B_re;								//bottom
		byte	Rect,								//number
				Hold;								//holder
	};

	//	Link structure
	struct P_PACKED_1 WZD_EI SLink
	{
		int		Deal[_LIN_],					//event
					Item[_LIN_],					//items
					Pink[_LIN_];					//ping-pong
	};

	//	Moving table structure
	struct P_PACKED_1 WZD_EI SMove 
	{
		int		IncX[_DIR_],					//x step
					IncY[_DIR_],					//y step
					IncO[_DIR_],					//o step
					FroX[_DIR_],					//x frontier
					FroY[_DIR_];					//y frontier
	};

	//	Hierarchy structure
	struct P_PACKED_1 WZD_EI SHier 
	{
		byte*		Lays[POWER];					//lay refer
		int		Keys[POWER],					//lay key
					Clks[POWER],					//lay time
					Unit;								//active units
	};
	//	Classificator structure
	struct P_PACKED_1 WZD_EI STips 
	{
		word		Mask;
		byte		Loop,
					Ulna,
					Trac,
					InOu;
	};

	//	Henry structure
	struct P_PACKED_1 WZD_EI Henry 
	{
		byte		Keys;								//key
		byte		Maor[_PRI_];					//major
		byte		Prim[_PRI_];					//primary
		byte		Secn[_SEC_];					//secondary nominator
		byte		Secd[_SEC_];					//secondary denominator
		byte		Susn[_SUS_];					//sub-secondary
		byte		Susd[_SUS_];					//sub-secondary
		byte		Sssn[_SUS_];					//second sub-secondary
		byte		Sssd[_SUS_];					//second sub-secondary
		byte		Finl[_PRI_];					//final
		byte		Flag;								//flag
	};

	/**************************************
			Base structures of data
	**************************************/

	//	Base image header
	struct P_PACKED_1 WZD_EI SData
	{
		short		Secret,							//secret
					ManDir;							//orientation order
		byte		ImType,							//L, F, P, S, A, T
					Number;							//image number
		word		Size_X,							//maximum x
					Size_Y;							//maximum y
		word		ImgDPI,							//image DPI
					ManDPI;							//man DPI
		byte		TipNet,							//section depth
					Shrink;							//presentation method
		byte*		Irefer;							//image refer
		word 		Status;							//statistic defence 
	};

	//	Common dacto item
	struct P_PACKED_1 WZD_EI SItem
	{
		int		Length;							//record length
		byte		VeSign,							//sign of version
					Number;							//image number
		word		ImgDPI,							//image DPI
					ManDPI;							//man DPI
		byte		Qualit,							//quality
					Densit,							//image density
					ImMask,							//type of pattern

					ImType,							//L, F, P, S, T
					Method,							//scale method
					Passxy,							//xy pass
					Passan,							//alpha pass
					TipNet,							//deep section
					PFocus;							//packed indignations length
		word		PPoint,							//packed points length
					PTotal,							//total number
					PRidge,							//count number
					PAreas;							//areas number
		int		PLinks;							//packed linkages length
		word		Size_X,							//image x size
					Size_Y;							//image y size
	};

	//	Common displacement
	struct P_PACKED_1 WZD_EI SDisp

	{
		int		DFocus,							//for focus
					DPoint,							//for point
					DTotal,							//for total
					DRidge,							//for ridge
					DAreas,							//for areas
					DLinks,							//for links
					DOwner,							//for owner
					DUnuse;							//free area
	};

	//packing alignment 
#ifdef _WINDOWS
	#pragma	pack( 4 )		
#endif

	/**************************************
			Declaration of CBase class
	**************************************/
	class P_PACKED_4 WZD_EI CBase
	{
   public:
		bool quick;

	public://object constructor & destructor
		CBase					(void);				//constructor
		virtual
	  ~CBase					(void);				//destructor

	public://document control
		virtual
		void		SetMap	(const int *lay);		//tune echelons
		virtual
		void		DelDoc	(void);				//delete document
		virtual
		void		DelTab	(void);				//delete fast table
		virtual
		void		ResDoc	(void);				//reset document
		virtual
		void		Resume	(void);				//default tuning

	public://data control
		virtual
		int		SetMod	(byte  *src);		//set module
		virtual

		int		VerMod	(byte  *src);		//verify module


	public://base tuning subfunctions
		void	  (CBase::*							//end
					Docend)	(void);				//of branch
		int	  (CBase::*							//do
					Docimm)	(void);				//immerce
		int	  (CBase::*							//do
					Docbox)	(int	 nlen);		//immerce into box
		int	  (CBase::*							//do
					Docbre)	(int	 step);		//Bresenham
		int	  (CBase::*							//do
					Docmin)	(int	 modu);		//minutiae module
		int	  (CBase::*							//do
					Docupo)	(void);				//outward control
		int	  (CBase::*Docupo_ptr)(void);

		
		int	  (CBase::*							//do
					Docupi)	(void);				//inner control
		int	  (CBase::*Docupi_ptr)(void);

		void	  (CBase::*							//do
					Dociso)	(void);				//outward work
		void	  (CBase::*Dociso_ptr)(void);

		void	  (CBase::*							//do
					Docisi)	(void);				//inner work
		void	  (CBase::*Docisi_ptr)(void);

		void	  (CBase::*							//do
					Docfno)	(void);				//outward final
		void	  (CBase::*							//do
					Docfni)	(void);				//inner final
		void	  (CBase::*							//do
					Docuse)	(void);				//callback
		void	  (CBase::*							//cross tuner
					Docvie)	(int	 dsth,
								 int	 srch);
		void	  (CBase::*							//next cross tuner
					Docvic)	(int	 dsth,
								 int	 srch);
		void	  (CBase::*							//cluster work
					Docexe)	(int	 flow,
								 int	 step);

//	protected://deaden code tuning
	public://deaden code tuning
		void		Deaden	(void);				//deaden code
		int		Deafen	(void);				//default code
		int		Spirit	(void);				//default code
		void		Deaden	(int	 nlen);		//deaden code
		void		Deaden	(int	 dsth,		//deaden code
								 int	 srch);

	private:
		//lug processing	
		inline
		void		DelLug	(int	 step);		//delete lug	
		inline
		void		SetLug	(void);				//restore lug

		//base scheme for fragment
		inline
		void		Fragmi	(int	 step,		//inner scheme of fragment
								 int	 jump);
		inline
		void		Fragmo	(int	 step,		//outward scheme of fragment
								 int	 jump);
	
	protected:
		//base scheme for image
		void Scener	(int	 srch);		//rectangle scene

		void Scenes	(int	 scan,		//kernal scene
					 int	 retr,
					 int	 dsth,
					 int	 srch);

		protected:

		void Scenei	(int	 scan,		//inner scene
					 int	 dsth,
					 int	 srch = H0);

		void Scenew	(int	 scan,		//whole scene
					 int	 dsth,
					 int	 srch = H0);

		int	Spiral	(int	 hier,		//cluster scene
					 int	 size = 00,
					 int	 util = 01);

	public://base work in pyramide
		int		GetKey	(int	 nkey,		//get key
								 int	 hier = H0);
		byte	  *GetLay	(int	 nkey,		//find lay
								 int	 hier = H0);
		void		DelLay	(int	 nkey,		//delete one lay
								 int	 hier = H0);

		void		OldLay	(int	 time);		//delete old lays
		void		ProLay	(int	 nkey,		//projection to lay
								 int	 srcx,
								 int	 srcy,
								 int	 dsth = H3,
								 int	 srch = H0);
		byte	  *ProRef	(int	 nkey,		//common reference
								 int	 srcx,
								 int	 srcy,
								 int	 dsth = H3,
								 int	 srch = H0);
		byte	  *ProSrc	(int	 nkey,		//source reference
								 int	 dsth = H3,
								 int	 srch = H3);
		int		DipPyr	(int	 coor,		//dip into pyramid
								 int	 dsth = H0,
								 int	 srch = H3);



	protected://standard list of impulses
//		inline
//		int		WebCon	(SStep *web,		//planar web convolution
//								 byte	 *src,
//								 int	 mult = 04);
		inline 
		void		FiRead	(byte	 *inf,		//read neighbourhood
								 byte	 *src,
								 int	 tune = 00);
		inline
		void		Fiimpo	(int	 *fun,		//oriented impulse
								 byte	 *src,
								 int	 tune = 00);
		inline 
		int		Fiimpo	(int	 flow,		//default oriented impulse
								 byte	 *src,
								 int	 tune = 00);

		inline
		int		Fiimpr	(byte  *src,		//range impulse
								 int	 tune = 00);
		inline 
		int		Fiimpn	(byte  *src,		//normal impulse
								 int	 tune = 00);
		inline
      int	Fiimpw( byte *src,int tune = 00);
		
      int		Fiimpp	(byte  *src,		//peripheral impulse
								 int	 tune = 00);
		inline 
		int		Fiimpc	(byte  *src,		//common collection
								 int	 tune = 00);
		inline 
		int		Fisuna	(byte	 *src);		//a sunlit
		inline 
		int		Fisunb	(byte	 *src);		//b sunlit
		inline 
		int		Fisunc	(byte	 *src);		//c sunlit

		inline

		int		Fisund	(byte	 *src);		//d sunlit
		inline 
		int		Fisune	(byte	 *src);		//e sunlit
		inline
		int		Fisunf	(byte	 *src);		//f sunlit
		inline
		int		Fisung	(byte	 *src);		//g sunlit
		inline
		int		Fisunh	(byte	 *src);		//h sunlit
		inline 
		int		FiBits	(byte	 *src,		//bits control
								 byte	 bits);
		inline 
		int		FiBite	(byte	 *src,		//bits 8-linked control
								 byte	 bits);
		inline 
		int		FiBitf	(byte	 *src,		//bits 4-linked control
								 byte	 bits);
		inline 
		int		FiList	(byte	 *src,		//item of sorted list
								 int	 item,
								 int	 tune = 00);
		inline 
		int		FiMirr	(byte	 *src);		//edge mirror
		inline 
		int		FiDoor	(int	 *coe);		//threshold level
		inline
		void		FiBrok	(SStep *fwd,		//read data from broken line
								 SStep *bck,
								 byte	 *src,
								 byte	 *inf,
								 int	 size);
		inline
		int		FiBrom	(SStep *fwd,		//broken medium range line
								 SStep *bck,
								 byte	 *src);
		inline
		int		FiBros	(SStep *fwd,		//broken small range line

								 SStep *bck,
								 byte	 *src);
      inline 
         int	FiBrot( SStep *fwd,SStep *bck,byte *src );

	protected://standard moving subfunction
		inline
		int		Chosew	(int	 adir);		//choose white
		inline
		int		Chosei	(int	 adir);		//choose inked
		inline
		int		Chsynw	(int	 adir);		//sinchro white
		inline
		int		Chsyni	(int	 adir);		//sinchro inked

	protected://standard moving functions
		inline
		void		MvMove	(int	 adir);		//advance
		inline
		void		MvSync	(int	 adir);		//advance

		void		MvTune	(int	 adir, int	 hier = H0);


		int		MvLayW	(int	 adir,		//move into white
								 int	 alen,
								 int	 vkey,
								 int	 hier = H0);
		int		MvLayI	(int	 adir,		//move into inked 	
								 int	 alen,
								 int	 vkey,
								 int	 hier = H0);
		int		MvSumW	(int	 adir,		//white sum
								 int	 alen,
								 int	 vkey,
								 int	 hier = H0);
		int		MvSumI	(int	 adir,		//inked sum
								 int	 alen,
								 int	 vkey,
								 int	 hier = H0);
		int		MvSynW	(int	 adir,		//white synchrosum

								 int	 alen,
								 int	 vkey,
								 int	 hier = H0);
		int		MvSynI	(int	 adir,		//inked synchrosum
								 int	 alen,
								 int	 vkey,
								 int	 hier = H0);

	private://immerce subfunctions
		inline 
		int		MvStop	(int	 adir);		//check edges
		void		Rounde	(int	 nlen);		//immerse in 8-area
		void		Roundf	(int	 nlen);		//immerse in 4-area

	protected://immerce functions
		inline 
		void		MvStep	(int	 adir);		//advance position
		void		Rounde	(int	 nlen,		//immerse in 8-area
								 int	 hier);
		void		Roundf	(int	 nlen,		//immerse in 4-area
								 int	 hier);
		void		Runner	(int	 nlen,		//runner into 8-area
								 int	 hier);
		void		UnWrap	(int	 nlen,		//unwrap trajectory
								 int	 hier);

	protected://quick access
		inline
		void		DoLink	(byte	**src);		//mount link
		inline
		void		DoKeep	(byte	**src);		//store moving data
		inline
		void		DoMove	(byte	**src);		//set moving data
		inline

		void		ReMove	(byte	**src);		//set & shift moving data

	protected://border functions

		inline
		int		R_Edge	(int	 xpos,		//right edge
								 int	 ypos,
								 int	 tune = 01);
		inline
		int		L_Edge	(int	 xpos,		//left edge
								 int	 ypos,
								 int	 tune = 01);
		inline
		int		N_Edge	(int	 xpos,		//right & left edge
								 int	 ypos,
								 int	 tune = 01);
		inline 
		int		Razors	(int	 tune = 01);//razor

	protected://prepare functions
		inline
		void		Mreset	(void);				//reset moving
		inline

		void		Breset	(void);				//reset Bresenham
		inline
		void		Basket	(void);				//reset basket
		inline
		void		Rreset	(void);				//reset random
		inline
		void		Weight	(int	 item = 01);//set basket
		inline
		void		DoMami	(byte	 item = 00);//set default

	protected://process rectangle 
		inline
		void		WiRect	(int	 eche = H0,	//set rectangle
								 int	 retr = 00);
		inline
		void		DeRect	(int	 eche = H0);//delete rectangle
		inline 
		int		InRect	(int	 srcx,		//into rectangle
								 int	 srcy);
		inline 
		int		FaRect	(int	 srcx,		//facet of rectangle
								 int	 srcy);
		inline 
		int		OnRect	(int	 srcx,		//on edge of rectangle
								 int	 srcy);

	protected://source refers: quick access
		byte	  *Srco,								//Srco
				  *Shpo,								//Shpo
				  *Snxo,								//Snxo
				  *Sexo,								//Sexo
				  *Sfno,								//Sfno
				  *Swoo,								//Swoo
				  *Smoo,								//Smoo
				  *Seio,								//Seio
				  *Seao,								//Seao
				  *Seco,								//Seco
				  *Seeo,								//Seeo
				  *Semo,								//Semo
				  *Sero,								//Sero
				  *Seso,								//Seso
				  *Seuo,								//Seuo
				  *Sezo;								//Sezo

	protected://destination refers: quick access
		byte	  *Dsto,								//Dsto
				  *Dhpo,								//Dhpo
				  *Dnxo,								//Dnxo
				  *Dexo,								//Dexo
				  *Dfno,								//Dfno
				  *Dwoo,								//Dwoo
				  *Dmoo,								//Dmoo
				  *Deio,								//Deio
				  *Deao,								//Deao
				  *Deco,								//Deco
				  *Deeo,								//Deeo
				  *Demo,								//Demo
				  *Dero,								//Dero
				  *Deso,								//Deso
				  *Deuo,								//Deuo
				  *Dezo;								//Dezo
		byte	*FR_4[4],
				*PR_4[4];

	public://working refers & quick access
		byte	  *Pack,								//Pack
				  *Movo,								//Movo
				  *Loco,								//Loco
				  *Helo,								//Helo
				  *Useo,								//Useo
				  *Prjo,								//Prjo
				  *Joff,								//j- off
				  *Hoff,								//H- off
				  *Noff,								//N- off
				  *Eoff;								//E- off

	protected://service working variables
		int		Lpck,								//Lpck
					Reax,								//Reax
					Reay,								//Reay
					Decx,								//Decx
					Incx,								//Incx
					Redx,								//Redx
					Redy,								//Redy
					Dedx,								//Dedx
					Indx,								//Indx
					Lugx,								//Lugx
					Lugy,								//Lugy
					Remo,								//Remo
					Remv;								//Remv

	public://size, coordinates, echelon
		int		Srcx,								//Srcx
					Srcy,								//Srcy
					Srch,								//Srch
					Srcl,								//Srcl
					Dstx,								//Dstx
					Dsty,								//Dsty
					Dsth,								//Dsth
					Dstl,								//Dsth
					Eche,								//echelon
					Reih,								//reih of echelon
					Movx,								//Movx
					Movy,								//Movy
					Locx,								//Locx
					Locy,								//Locy
					Helx,								//Helx
					Hely,								//Hely
					Usex,								//Usex
					Usey,								//Usey
					Prjx,								//Prjx
					Prjy;								//Prjy

	protected://moving parameters
		int		R_go,								//right go
					F_go,								//forward go
					L_go,								//left go
					D_go,								//this direction
					P_go,								//previous direction
					H_go;								//hierarchy

	protected://common service
		int		Imax,								//maximum
					Imin,								//minimum
					Thre,								//threshold
					Inna,								//in -area
					Outa,								//out-area
					Yard,								//colour yard
					Dose,								//portion
					Calc,								//calculator
					Seat,								//spiral couch
					Util,								//utilize scale

					Pran,								//success random
					Qran,								//failure random

					Team,								//team power
					Bask;								//basket

	public://rectangle
		int		L_re,								//left
					T_re,								//top
					R_re,								//right
					B_re;								//bottom

	protected://quick table access
		int	  *Stab,								//source table
			  *Dtab,								//destination table
			   Tabp;								//table position

	public://internal data
		int		What,								//error
					Tops,								//queue top
					Call;								//callback

	public://pyramidal structure
		const int  *PyrF,								//autocoding object
				  *PyrR,								//recoding legacy
				  *PyrL,								//semi-autocoding object
				  *PyrT,								//frames object
				  *PyrV;								//visual object

	public://hierarchy parameters
		SHier		Hier[ECHEM];					//hierarchy
		SMove		Move[ECHEM];					//table to move
		byte		Side[ECHEM],					//square side
					LayN[ECHEM];					//number of lays
		int		Size[ECHEM];					//a lay size
		word		MaxX[ECHEM],					//max x
					MaxY[ECHEM];					//max y



	protected://special environment
		int		Vide[_DIR_],					//environment
				Sets[_SET__];					//chain quality 

		short *I_Fisuna;
		short *I_Fisunb;
		short *I_Fisunc;
		short *I_Fisund;
		short *I_Fisunac;
   public:
      bool saveLayer(const char *filename, int lay, int hier);
      bool saveInt(const char *filename, int val);
      bool saveLink(const char *filename, SLink &slink);

	};//CBase

	/**************************************
			Declaration of CHues class
	**************************************/
	class P_PACKED_4 WZD_EI CHues
	{
	
	public://object constructor & destructor
		CHues					(void);				//constructor
		virtual
	  ~CHues					(void);				//destructor

	private://palette control
		virtual
		byte		HueInv	(byte	 *dst,		//set invertion hue
								 corn	 pall);
		virtual
		byte		HueOrg	(byte	 *dst,		//set original hue
								 corn	 pall);

	protected://load rgb poligons
		virtual
		void		PolHue	(int	 *pol);		//load poligons
		virtual
		void		PolHue	(int	 *pol,		//original poligons
								 byte	 *hue,
								 byte	  lum);

	public://load palette
		virtual
		void		Colour	(byte	 type);		//type of work
		virtual
		void		SetHue	(int	 type,		//load hue
								 corn	 huew,
								 corn	 huei = 00);


	protected://palette parameters
		byte		HuSa,								//hue & saturation
					Draw,								//flag to draw
					OHue[_PAL_],					//original palette
					OLum,								//lumination
					WHue[_PAL_],					//white palette
					WLum,								//lumination
					IHue[_PAL_],					//inked palette
					ILum,								//lumination
					SHue[_PAL_],					//skeleton palette
					SLum,								//lumination
					RHue[_PAL_],					//region palette
					RLum,								//lumination
					FHue[_PAL_],					//flow palette
					FLum,								//lumination

					DHue[_PAL_],					//flow order palette
					DLum;								//lumination

	protected://palette poligons
		int		Rrgb[SRANK],					//reg colour
					Grgb[SRANK],					//green colour
					Brgb[SRANK];					//blue colour

	};//CHues

	/***********************************
		  Declaration of CRank class
	***********************************/
	class P_PACKED_4 WZD_EI CRank
	{

	protected://initialize functions
		void		RanIni	(int	 vval = 00);//initialize Rank
		void		CorIni	(int	 vval = 00);//initialize Corn

		void		LorIni	(int	 vval = 00);//initialize Lord

	protected://build original polygon
		void		RanMod	(int	 *low);		//Rank polygon,
		void		LorMod	(int	 *low);		//Lord..
		void		CorMod	(int	 *low);		//argument..
		void		RanGau	(int	 *low);		//Rank gauss integral
		void		LorGau	(int	 *low);		//Lord.. 
		void		CorGau	(int	 *low);		//argument..

	protected://common processing
		void		RanBeg	(int	 feel);		//left edge
		void		RanEnd	(int	 feel);		//right edge

		int		RanImp	(int	 feel);		//impulse
		int		RanSha	(int	 feel);		//upper part of Rank
		int		LorSha	(int	 feel);		//upper part of Lord

	private://kernal of poligons
		void		AnyLog	(int	 *dst,		//poligon as logarithm
								 int	 high,
								 int	 fini);

	protected://special poligons
		void		RanLog	(int	 high = BM);//Rank as logarithm
		void		LorLog	(int	 high = BM);//Rank as logarithm
		void		GauSqr	(int	 high = 01);//Rank gauss f(f(x))
		void		RanOrg	(void);				//Rank default

		void		RanRes	(void);				//resize Rank
		void		RanUni	(void);				//Rank uniform 


	protected://smooth tables
		void		RanSmo	(int	 size);		//smooth Rank
		void		CorSmo	(int	 size);		//smooth Corn
		void		LorSmo	(int	 size);		//smooth Lord

	protected://statistic kernal preprocess
		void		CorCos	(int	 wing,		//cos correlation
								 int	 fini,
								 int	 anti,
								 int	 mami,
								 int	 *dst,
								 int	 *src);
		int		Rraise	(int	 *tab,		//raise to height
								 int	 zero,

								 int	 posi,
								 int	 fini);
		int		Rlower	(int	 *tab,		//find the foot of height
								 int	 zero,
								 int	 posi,
								 int	 fini);
		int		Rfloat	(int	 *tab,		//find floating threshold
								 int	 fini,		
								 int	 zero,
								 int	 hill);

	public://common functions
		int		AnyPow	(int	 *tab,		//get power
								 int	 fini);
		int		AnySup	(int	 *tab,		//get suprum
								 int	 fini);
		int		AnyInf	(int	 *tab,		//get infrum
								 int	 fini);
		int		AnySha	(int	 *tab,		//part of histogram
								 int	 fini,

								 int	 feel);
		void		AnyNor	(int	 isup,		//normalize range
								 int	 *src,
								 int	 fini);
		void		AnyMat	(int	 size,		//expectation
								 int	 *dst,
								 int	 *src,
								 int	 fini);
		void		AnyDev	(int	 size,		//deviation
								 int	 *dst,
								 int	 *src,
								 int	 fini);
		void		AnySmo	(int	 size,		//smooth anything
								 int	 *src,
								 int	 fini);
		void		CorCos	(int	 wing,		//cos correlation
								 int	 fini,
								 int	 anti = 00,
								 int	 mami = 01);

	public://histog parameters
		int		Rinf,								//infrum
					Rsup,								//suprume
					Rpow,								//power
					Llim,								//left limit
					Rlim,								//right limit
					Zero,								//float level
					Hend;								//end of histogram

	public://pointer to histogram
		int*		Hist,								//histogram
			*		Corr,								//correlation
			*		Devi,								//deviation
			*		Swap;								//swaping

	public://buffer of translatores
		int		Corn[SCORN],					//corner buffer
				Rank[SRANK],					//rank buffer
				Lord[SRANK],					//lord buffer
				Crop[SCROP];					//crop buffer

	};//CRank

	/***********************************
		  Declaration of Coral class
	***********************************/
	class P_PACKED_4 WZD_EI Coral : public CBase, public CHues
	{
	public:
		short Bresen_LookupCm[255][360];
		short Bresen_LookupSm[255][360];
	private://kernal private subfunctions
		void Pitchs	(int hier);		//get parameters
		void Bresen	(SStep *web);	//trace moving
		void Bresen	(void);			//working moving	
		int	Margin	(void);			//sense edge

	protected://interface functions
		int		Bresen	(int   desx,		//source:destination
						         int    desy,
						         int    soux,
						         int    souy,
						         int    hier = H3);
		int		Bresen	(int	 flow,		//along direction
                           int    lens,
                           int    hier = H3);
		int		Breweb	(int	 flow,		//quick movement
                           int	 lens,
                           int	 hier,
                           SStep  *web = 00);
		int	Breweb_Furiew(int flow, int lens, int hier, SStep *web = 0);
		void  Bresen_Furiew(SStep *web);
		int		Breinj	(int	 flow,		//injection
								 int	 lens,
								 int	 hier,
								 SStep *web = 00);

	private://kernal skeleton functions
		int		SkeSet	(int	 step);		//draw skeleton
		int		SkeSkeI		(int	 step);		//catch skeleton
		int		SkeEndI	(int	 step);		//fing ending
		int		SkeOutI	(int	 step);		//find outward

	protected://skeleton special functions
		void		Pastes	(int	 desx,		//draw skeleton
								 int	 desy );
		int		SkeEnd	(int	 flow,		//find ending	
								 int	 lens,
								 int	 hier = H0);
		int		SkeSke	(int	 flow,		//catch skeleton
								 int	 lens,
								 int	 hier = H0);
		int		SkeOut	(int	 flow,		//find outward
								 int	 lens,
								 int	 hier = H0);

	private://class parameters
		int		Ainc,								//a parameter
					Binc,								//b parameter
					Dexp,								//d parameter
					Xinc,								//x increment
					Yinc,								//y increment
					Oinc,								//o increment
					Difx,								//x difference
					Dify,								//y difference
					Absx,								//x size
					Absy,								//y size
					Limx,								//x limit
					Limy,								//y limit

					Deal,								//event
					Cnti;								//count


	};//Coral

	/***********************************
		  Declaration of Chain class
	***********************************/
	class P_PACKED_4 WZD_EI Chain : public Coral
	{

	private://build the skeleton tail
		inline
		int		Alphas	(void);				//tail alpha
		inline
		int		Length	(void);				//tail length
		inline
		void		Shrink	(void);				//tail = head
		inline
		void		Recent	(void);				//recent tail
		inline
		void		Diverg	(int	 head);		//divergence
		inline
		void		Aspire	(int	 sign);		//minutiae aspire
		inline
		void		Assign	(int	 nlen);		//asignment

	private://clear arm of the skeleton
		void		ArmDel	(void);				//clear arms
		void		ArmEnd	(void);				//end of arm
		void		ArmDir	(void);				//arm direction
		void		ArmArm	(void);				//full data

	private://kernal skeleton functions
		int		SkeHidV	(void);				//hide
		int		SkeRevV	(void);				//reveal
		int		SkeRubV	(void);				//rub out
		int		SkeDirV	(void);				//direction
		int		SkeMrkV	(void);				//remark
		int		SkeMinV	(void);				//find minutiae
		int		SkeLinV	(void);				//links
		int		SkeResV	(void);				//restore
		int		SkeDelV	(void);				//delete
		int		EChainV	(void);				//encode chain
		int		DChain	(void);				//decode chain

	private://upper skeleton functions
		int		SkeHid	(int	 nlen);		//hide
		int		SkeRev	(int	 nlen);		//reveal
		int		SkeRub	(int	 nlen);		//rub out
		int		SkeDir	(int	 nlen);		//direction
		int		SkeRes	(int	 nlen);		//restore
		int		SkeDel	(int	 nlen);		//delete
		int		SkeMrk	(int	 nlen);		//remark

		int		SkeMin	(int	 nlen); 		//find minutiae
		int		SkeLin	(int	 nlen);		//links
		int		EChain	(int	 nlen);		//encode chain

	private://complicative skeleton functions
		int		Sprout	(int	 nlen);		//subbranches
		int		Glance	(int	 nlen);		//direct glance
		int		Follow	(int	 nlen);		//follow link

	private://look around into the box
		void		Boxers	(int	 nlen);		//special box

	protected:
		void		Branch	(int	 nlen,		//correct branches
								 int	 orie);
		void		Colour	(int	 nlen);		//hide skeleton

		void		Visual	(int	 nlen);		//visual skeleton
		void		Orient	(int	 nlen);		//orientation
		void		Morpho	(int	 nlen);		//morphology
		int		Crossd	(int	 nlen);		//define cross
		void		Chaine	(int	 nlen);		//encode branches
		int		Chaind	(int	 nlen);		//decode branches

	private://class inner parameters
		int		Beta,				//orientation
               Deal,				//event
               Item,				//item
               Head,				//queue head
               Tail,				//queue tail
               Tree;				//chain tree

	protected://chain base parameters
		int		Narm;				//arm quantity

	protected://class special buffers
		SArms	   Arms[_ARM__];	//arm buffer
		SPace	   Walk[_SPY_];	//tail buffer
		void     SkeRes_1(void);
		byte*	   Route[100];
		int	   Route_size;

	};//Chain

	/***********************************
		 Declaration of CWork class
	***********************************/
	class P_PACKED_4 WZD_EI CWork : public Chain, public CRank
	{		
	public:

		bool Whether_Pattern;
		signed char Scheme_LookupCm[180];
		signed char Scheme_LookupSm[180];
		char Furiew_dist_lookup[30][30];
	public:
		int	Argums_Lookup[361];	//{-180...180)
		int  *Argums_Lookup0;
		int	Argums_LookupCosm[180];
		int	Argums_LookupSinm[180];

	protected:

	public://constructor and destructor
		CWork					(void);				//constructor
		virtual
	  ~CWork					(void);				//destructor

	public://document controle
		void		ResDoc	(void);				//reset document

	protected://gemmae for procedures		
		int		GemWeb( SStep *web,		//convolution synthesis
						int	 size,
						int	 hier = H0,
						int	 flow = 00,
						int	 type = 00);
		int		GemReg	(byte	 *arg,		//re-join regularity
						 byte	 *mod,
						 int	 beta);
		int	GemReg_I(byte *arg, byte *mod, int beta);
		void GemReg_Stream_1(byte *arg, byte *mod, int beta);

	public://common functions
		void Argums	(int flow, int	 step);	
		void Argums_NoApw(int flow, int step);
		void Argums_I_quick(int flow, int step);

  		void Argums_quick	(int flow, int	 step);	
		void Argums_NoApw_quick(int flow, int step);
		void Argums_I(int flow, int step);

		void Twists_I(int flow, int step);

		void		Twists	(int	 flow,		//do
							 int	 step);		//twist
		void		MaxMin	(int	 flow,		//do
							 int	 step);		//maxmin
		void		Sphere	(int	 flow,		//do
							 int	 step);		//bit research

	void parity_tune( int _Dsth,int _Srch );
	void parity_get(int, int);
	void parity_set( byte* _Dst );
	void parity_work();
	void parity();

	public://delicious processing 
		void		Active	(int   posx,      //set active
								 int   posy);
		int		Nature	(int   posx,      //nearest indignation
								 int   posy);
		int		Native	(int   posx,      //nearest minutiae by module
								 int   posy,
                         int   modu = -1);
		int		NativeI  (int	 modu);     //check nearest

//	protected://functions for <Lightf> & <Lights>
	public:
		void     LiTune	(int	 dsth,
                                    int	 srch);		//tuning
		void     LiNorm	(void);	//smooth normal image
		void     LiCopy	(void);	//copy image				
		void     LiCalSuns(void); //calculate suns_abcd
		void     LiSaveSuns(void); //save suns_abcd
		void     LiRank	(void);	//measure histogram
		void     LiGray	(void);	//gray
		void     LiSuns	(void);	//sunlight
	public:
		void		StSete	(int   dsth,      //expert
                         int   srch);     //tuning
		void		StSetf	(int	 dsth,      //flow
							    int   srch);     //tuning
		void		StGoon	(int	 flow,      //get
							    int   step);     //work regions
		void		StFlow	(void);				//measure flow
		void		StJoin	(void);				//re-join flow
		void		StIndi	(void);				//relax indignations
		void		StGoonV	(void);				//classify twist
		void		StReco	(void);				//recover flow

//	protected://functions for <Cohere>
	public:
		void		CoTune	(int	 dsth,		//do
							 int	 srch);		//tuning
		void		CoMini	(void);				//do
		void		CoMino	(void);				//minimum
		void		CoMaxi	(void);				//do
		void		CoMaxo	(void);				//maximum
		void		CoRefi	(void);				//refine & transform

//	protected://functions for <Pickup>
	public:
		void		PiTune	(int	 dsth,		//tune in 	
							 int	 srch);		//transmition
		void		PiRing	(int	 flow,		//do
							 int	 step);		//archs
		short *p_Delim, *p_Delim_c;
		void PiEdgeAddP(void);
		void		PiQual	(void);				//complex quality
		void		PiFlow	(void);				//prove kernal flow
		void		PiRingV	(void);				//prove yokes
      void	   PiTest( void );            //

//	protected://functions for <Ifocus>
	public:
		void	IfTune	(int	 dsth,		//do
						 int	 srch);		//tuning
		void	IfDeep	(int	 dsth,		//do
						 int	 srch);		//projection
		void	IfWide	(int	 flow,		//do
						 int	 step);		//widing
		int		IfRays	(int	 step);		//do rays
		int		IfImme	(void);				//lift immerce
		void	IfPrep	(void);				//prepare
		void	IfIndi	(void);				//recognize
		void	IfIndi_2(void);	//recognize
		void	IfTwis	(void);	//get twist
		void	IfLift	(void);	//lift up 
		void	IfEnum	(void);	//enumerate indignations
		void	IfWideV	(void);	//widing
		void	IfRaysV	(void);	//get rays
		void	IfDeepV	(void);	//projection
		void	IfDeepV_integ	(void);	//projection

		public:
		void		ReTune	(int	 dsth,		//tune in
								 int	 srch);		//transmition
		void		ReDeep	(int	 dsth,		//tune in 
								 int	 srch);		//immerce
		void		ReWave	(void);				//gradient wave
		void		RePrep	(void);				//prepare phase & module
		void		Respon	(void);				//response
		void		ReGrad	(void);				//measure gradient
		void		ReCome	(void);				//first reply
		int		RePrev	(void);				//prepare
		int		Replyi	(void);				//inner reply
		int		Replyo	(void);				//outward reply
		void		ReFilt	(void);				//hierarchy filter
		void		ReFili	(void);				//inner filter
		void		ReFilo	(void);				//outward filter

//	protected://functions for <Xfocus>
	public://functions for <Xfocus>
		void		XfTune	(int	 dsth,		//tune in 	
								 int	 srch);		//transmition

		void		XfWide	(int	 flow,		//look
								 int	 step);		//area
		void		XfIndi	(int	 flow,		//do
								 int	 step);		//indignations
		void		Rename	(int	 ipos,		//do
								 int	 type );		//rename
		void		XfWideV	(void);				//elarge focus area
		void		XfCurv	(void);				//curve in focus
		void		XfTwis	(void);				//twist of curve
		void		XfBest	(void);				//best position
		void		XfTrue	(void);				//collect trustable
		void		Rename	(void);				//rename focuses
		void		XfIndiV	(void);				//up indignations

	public:
		void		AtWide	(int	 flow,		//spread
                                                                int	 step);		//area
		void		AtRegi	(int	 *num);		//register indignations
		void		AtFlowV	(void);				//measure flow
		
		void		AtWideV	(void);				//spread model		

		public:
		void	SwTune	(int	 dsth,		//tune in
						 int	 srch);		//transmition
		int		SwFlow	(int	 step);		//write pattern
		void	Scheme	(void);				//calc model flow
		void	SwPrep	(void);				//prepare
		void	SwFlowV	(void);				//set model of indignation
//		void	SOrder	(void);				//set man order
		void	SwSour	(void);				//wavelet source
		void	Swellw	(void);				//spread wave of flow
		void	SwTake	(void);				//accept wave
		void	SwJoin	(void);				//re-join flow
		void	SwBest	(void);				//up flow extremum
		void GetFPRWithNoPattern(); //GET FLOW_R and PROB_R

		public:
		void		FlTune	(int	 dsth,		//tune in
								 int	 srch);		//transmition
		void		FlDeep	(int	 dsth,		//tune in 
								 int	 srch);		//projection
		void		FlConc	(void);				//flow pros and cons
		void		Flower	(void);				//set flow
		void		FlWave	(void);				//set wave
		void		FlGrad	(void);				//prepare phase & module
		void		FlQual	(void);				//measure gradient quality
		void		FlCome	(void);				//base decomposition
		int			FlPrep	(void);				//prepare to measure
		int			FlImpi	(void);				//inner impulse
		int			FlImpo	(void);				//outward impulse
		void		FlFilt	(void);				//hierarchy filter
		void		FlFili	(void);				//final inner filter

   public://functions for <Curvat>
		void		CuTune	(int	 dsth,		//tune in
								 int	 srch);		//transmition
		void		CuCurv	(void);				//curvature

		void		CuTwis	(void);				//twist
		void		CuDeep	(void);				//projection

//	protected://functions for <Furiew>
		public:
		void		FuTune	(int	 dsth,		//base
								 int	 srch);		//transmition
		void		FuKern	(int	 dsth,		//kernal
								 int	 srch);		//transmition
		void		FuJoin	(int	 dsth,		//tune in
								 int	 srch);		//frequency reply
		int		FuBres	(void);				//tune in needles
		int		FuPrep	(void);				//reset integrator
		int		FuCorr	(void);				//subtuning
		int		FuZero	(void);				//reset expectation
		void		FuNeed	(void);				//put needles
		void		FuCopy	(void);				//set copy
		void		FuRank	(void);				//prognoses gradient
		void		FuGrad	(void);				//build gradient
		void		FuKernV	(void);				//measure frequency
		void		FuEche	(void);				//collect spectrum
		void		FuDone	(void);				//hierarchy reply
		void		FuSpre	(void);				//spread reply

	private://functions for <Harmon>
		void		HaGeto	(int	 *dst);		//get original spectrum
		void		HaGets	(int	 *dst);		//get spectrum
		void		HaPuts	(int	 *src);		//put spectrum

//	protected://functions to assemble

	public:
		void		HaTune	(int	 dsth,		//kernal
							 int	 srch);		//transmition
		void		HaDeep	(int	 dsth,		//hierarchy
							 int	 srch);		//immerse
		void		HaLapl	(int	 flow,		//collect
							 int	 step);		//laplasian
		void		HaNear	(int	 flow,		//collect
							 int	 step);		//harmon
		int			HaImpi	(void);				//crumbs of harmon
		int			HaImpo	(void);				//copy harmon
		void		HaHerz	(void);				//up harmon
		void		HaLaplV	(void);				//laplasian
		void		HaGood	(void);				//unhomogeneous
		void		HaNearV	(void);				//spread harmon
		void		HaEthe	(void);				//up spreaded
		void		HaQual	(void);				//concordance
		void		HaWork	(void);				//build work harmon
//		void		HaDeep	(void);				//projection
		void		HaFilt	(void);				//harmon filter

//	protected://functions for <Expert>
	public:
		void		ExSkel	(int	 dsth,		//catch
							 int	 srch);		//skeleton

		void		ExKern	(int	 dsth,		//tune
							 int	 srch);		//kernal
		void		ExDeep	(int	 dsth,		//tune
							 int	 srch);		//projections

		void		ExSkelV	(void);				//skeleton
		void		ExPrep	(void);				//prepare
		void		ExKernV	(void);				//kernal
		int			ExImpi	(void);				//inner impulse
		int			ExImpo	(void);				//outward impulse
		void		ExFilt	(void);				//penetrate data
		int cogm_div_I[12];
		int cogm_temp_I[12][9];
		void get_cogm_temp(void);
		byte neighbors_I[9];
		int Fiimpo_I(int *inf, int div);

		public:
		void		LaTune	(int	 dsth,		//tune
							 int	 srch);		//transmition
		void		LaArea	(int	 dsth,		//tune
							 int	 srch);		//to group areas
		void		LaDeep	(int	 dsth,		//tune
							 int	 srch);		//projections
		
		void	LaDoor	(void);				//threshold
		
		void	LaRank(void);
		void	LaMarkPaper(void);
		
		void	LaEyei	(void);				//group inner regions
		void	LaEyeo	(void);				//group outward regions
		void	LaMark	(void);				//frontier 
		void	LaInje	(void);				//class projection
		
		void	LaAreaV	(void);				//previous region		

	private://functions for <Filter>
		int		FiLine	(SStep *fwd,		//broken line
							 SStep *bck,
							 byte	 *src);
		void	FiRays	(int	 size);		//tune this needle
		void	FiHarm	(void);				//tune this harmon
		int		FiHrzi	(void);				//(.)
		int		FiHrzo	(void);				//classification
		void		FiRayi	(void);				//(.)
		void		FiRayo	(void);				//needle & range

		void		FiIndi	(void);				//indignations
		void		FiFili	(void);				//transform
		void		FiFilo	(void);				//classification
		void		FiGray	(void);				//gray 
		void		FiCopy	(void);				//copy

		void		FiNoth	(void);				//nothing
		void		Binari	(void);				//classify
		void		Binaro	(void);				//lines of image

//s	protected://assemble the <Filter>
		public:
		void	FiType	(int	 dsth,		//tune
						 int	 srch);		//to classify
		void	FiTune	(int	 dsth,		//tune
						 int	 srch);		//transmition
		void	FiHarmII	(int	 dsth,		//tune
							 int	 srch);		//harmon

		void	FiEven	(int	 dsth,		//tune
						 int	 srch);		//smothing
		void	FiClas	(int	 dsth,		//tune
						 int	 srch);		//classification
		void	FiMode	(int	 flow,		//remark
						 int	 step);		//working area
		void	FiTypeV	(void);				//classify regions
		void	FiStop	(void);				//verify stop
		int		FiHari	(void);				//up
		int		FiHaro	(void);				//to harmonize
		int		FiEvei	(void);				//up
		int		FiEveo	(void);				//to smooth
		int		FiBini	(void);				//up
		int		FiBino	(void);				//to classify

//	protected://functions for <Skelet>
		public:
		void	SkTune	(int	 dsth,		//tune
						 int	 srch);		//refining
		void	Sketch	(int	 flow,		//do
						 int	 step);		//sketch
		int		Splits	(int	 nlen,		//split
								 int	 dirs);		//lines
		void	Ske_init(void);
		bool	check_neighbor(unsigned char *src);
		void	SkArea	(void);				//group goal
		int		SkKind	(void);				//kind of work
		int		SkEdge	(void);				//edge areas
		int		SkSign	(void);				//field goal
		int		SkHarm	(void);				//sense harmon
		void	SkThin	(void);				//kernal refine
		void	SkGoonV	(void);				//remark goal
		
		void	SkWipe	(void);				//rubout
		void	SkHidr	(void);				//verify hidrance
		void	SkBran	(void);				//correct branches
		void	SplitsV	(void);				//split ridges
		void	SkDumb	(void);				//glue dumb-bels

		void		SkMark	(void);				//mark skeleton goal

//	protected://functions for <Minuti>
		public:
		void		MiTune	(int	 dsth,		//tune
								 int	 srch);		//minutiae
		int		MiGoal	(void);				//field goal
		void		MiRead	(void);				//extract minutiae
		void		MiReadIso(void);				//extract minutiae in ISO compatible manner
		void		Doubts	(void);				//mark doubtfull
		void		MiPack	(void);				//pack minutiaes


//	protected://assemble <Linker>
		public:
		int		LiFind	(int	 beta);		//catch skeleton
		void	Lizard	(int	 &idl,		//ridge morphology
						 int	 *low);
		void	LiSave	(int	 type,		//write links
						 int	 *deg);
		void	LiPrep	(int	 dsth,		//tune
						 int	 srch);		//lay for links
		void	Lining	(void);				//read information
		void	GetRid	(void);				//reset morphology
		void	LiSort	(void);				//sort for packing
		void	LiHand	(void);				//throw projections
		int		Linkup	(void);				//linkages

//	protected://functions for <Epilog>
		public:
		void		EpTune	(int	 dsth,		//tune
								 int	 srch);		//epilog
		void		EpDeep	(int	 dsth,		//tune
								 int	 srch);		//projection
		void		EpHarm	(int	 flow,		//collect
								 int	 step);		//density
		void		IScale	(void);				//density
		void		EpZone	(void);				//informative areas
		int		EpPrep	(void);				//prepare areas
		void		EpPack	(void);				//pack regions
		void		EpList	(void);				//do list of regions
		void		EpDeepV	(void);				//do projection

	public://functions for <Rcount>
		int		Rcount	(SSign &dst,		//ridge count
								 SSign &src);

		int		Rtrace	(SCoor &dst,		//keep an eye
								 SSign &src);

	protected://functions for <Rcount>
		int		Rcount	(SSign &dst);		//ridge count
		int		Rtotal	(void);				//get total metric
		int		Rcount	(void);				//get ridge count

//	protected://interface for <Target>
	public:
		void		TaTune	(int	 dsth,		//tune
								 int	 srch);		//to mark targets
		void		TaDeep	(int	 dsth,		//tune
								 int	 srch);		//for projection
		int		TaPrep	(void);				//reset
		int		TaRank	(void);				//rank filter
		void		TaHist	(void);				//build clear space
		void		TaDone	(void);				//set background
		void		TaPlug	(void);				//plug
		void		TaArea	(void);				//collect clear space
		void		TaImmi	(void);				//inner immerse
		void		TaImmo	(void);				//outward immerse
		void		TaMark	(void);				//find out target

//	protected://functions for <Frames>
	public://functions for <Frames>
		void		FrTune	(int	 dsth,		//tune
								 int	 srch);		//frames
		void		Framex	(void);				//histogram along x
		void		Framey	(void);				//histogram along y

	protected://interface for <Frames>
		void		Fcatch	(int	 hill,		//try to catch height
								 int	 wing,
								 int	 tiny);
		void		FrFlex	(int	 look);		//find flexure
		void		ComeUp	(int	 look);		//wavelet approach
		int		FrDoor	(int	 inum,		//find goal between hills
								 int	 hill);

	public://some quantities
		int		Nmin,								//minutiaes quantity
					Nind;								//indignations quantity

	protected://help parameters

		int		Runs,                                                                   //free runner
					Proc,                                                           //processing sign
					Foot,								//track
					Clas,								//claster size
					Grax,								//x gradient
					Gray,								//y gradient
					Qual,								//quality
					Orie,								//orientation
					Args,								//arguments
					GoOn,								//continue
					Star,								//stair to star
					Open,								//opening
					Cont,								//context
					Bits,								//bit context
					Tr_w,								//white trust
					Tr_i,								//inked trist

					Fl_w,								//white flow
					Fl_i,								//inked flow
					Area,								//any area	
					Case,								//event
					Hypo,								//hypothethis
					Fine,								//penalty
					Harm,								//harmon
					Nact,								//active minutiae
					Nsec,								//current depth
					Deep,								//deep of section
					Twin;								//net wing
		int I_Hypo;
		uint		Nlin,							                //packed byte quantity
					Nbit;								//packed bits quantity


	protected://common buffers

		int		Flow[_DIR_],					//flower
				Modu[_DIR_],					//module
				Re_v[_DIR_],					//real
				Im_v[_DIR_],					//imaginary
				Ap_w[_DIR_],					//weight of amplitude & phase
				Tw_v[_DIR_],					//twist of curve
				Quan[_DIR_],					//quantity
				Asse[DAISY],					//weight
				Spec[_HAR_],					//spectrum
				Prob[_HAR_],					//probability
				Metr[_ARM__];					//metrics

	public://special buffers
		SRect		Rect[_TIP_];					//frames
		SStep		Head[SSTEP],					//head
					Tail[SSTEP],					//tail

					West[SSTEP],					//west
					HCon[SCONV],					//huge convolution
					MCon[SCONV],					//medium convolution
					TCon[SCONV];					//tiny convolution
		SSign		Indi[_GEN_];					//indignations
		int			Indi_x[_IND_];
		int			Indi_y[_IND_];
		SLink		Link[_NET_],					//one line - two branches
					Nest;								//ordered links
		SSign*	Sign;								//minutiaes
      int      exCQuali;

	};//CWork
								
	/***********************************
		Declaration of CCode class
	***********************************/
	class P_PACKED_4 WZD_EI CCode : public CWork
	{

//	protected://inner function to code
	public://inner function to code
		void		EnTune	(int	 dsth,		//tune
								 int	 srch);		//encoding

		void		DeTune	(int	 dsth,		//tune
								 int	 srch);		//decoding
		void		DoTune	(int	 dsth,		//tune
								 int	 srch);		//reconstruction
		void		DoCopy	(int	 dsth,		//tune
								 int	 srch);		//skeleton inheritence
		void		DoMini	(int	 dsth,		//tune
								 int	 srch);		//minutiae inheritence
		void		EnCodeV	(void);				//encode
		void		EnOrig	(void);				//original skeleton
		void		DeCodeV	(void);				//prepare unpack lay

//		void		ReConi	(void);				//inner convolution
		void		ReCono	(void);				//outward convolution
		void		Recons	(void);				//reconstruct image
		void		DoCopyV	(void);				//inherit skeleton
		void		DoMiniV	(void);				//inherit minutiae
	
	public://encode & decode skeleton
		int		EnCode	(byte  *dst);		//encode skeleton
		int		DeCode	(byte  *src);		//decode skeleton
	//	void		ReCode	(int	 subl);		//reconstruct image

	};//CCode


	/***********************************
		Declaration of CLoop class
	***********************************/
	class P_PACKED_4 WZD_EI CLoop : public CCode
	{

//	protected://interface for <Import>
public:
		void		ImTune	(int	 dsth,		//tune
								 int	 srch);		//zone import
		void		ImGodo	(int	 dsth,		//tune
								 int	 srch);		//godograph
		void		ImMark	(int	 flow,		//collect
								 int	 step);		//environment
		void		ImArea	(SCoor *src,		//import
								 int	 &num);		//all zones
		int		Godogr	(SCoor *src,		//recognize
								 int	 &num);		//godograph

		int		ImRibs	(int	 step);		//draw ribs
		int		ImFill	(void);				//fill area
		int		ImZero	(void);				//previous reset

		int		ImGodoV	(void);				//up godograph
		void		ImPrep	(void);				//prepare
		void		ImRect	(void);				//write rectangle
		void		ImMarkV	(void);				//mark non-figure
		void		ImCopy	(void);				//final building
		void		ImDeep	(void);				//collect areas
		void		ImDone	(void);				//fullfillment
		void		RubOutV	(void);				//clear skeleton

//	protected://interface inner processing
	public:
		int		ImDrawI	(int	 step);		//draw area
		void		ImDrawII	(int	 flow,		//draw pixel

								 int	 step);
		int		RubOutI	(int	 step);		//rubout area
		void		RubOutII	(int	 flow,		//rubout pixel
								 int	 step);
		int		ImFlow	(int	 step);		//draw flow

	protected://assemble interface processing
		void		ImDraw	(SCoor &dst,		//draw skeleton line
								 SCoor &src);
		void		RubOut	(SCoor &dst,		//rubout skeleton line
								 SCoor &src);

	protected://backloop sign
		int		Copy;								//if change preparation

	};//CLoop


	/***********************************
		Declaration of Charm class

	***********************************/
	class P_PACKED_4 WZD_EI Charm : public CLoop
	{

//	protected://common palette
	public://common palette
		void		Charms	(int	 dsth,		//tune
								 int	 srch);		//rgb image

//	protected://interface for <Source>
	public:
//		void		SoBows	(int	 dsth,		//tune
	//							 int	 srch);		//coloured source
		void		SoTune	(int	 dsth,		//tune
								 int	 srch);		//reloading
		void		SoBows	(void);				//coloured source image
		void		SoNega	(void);				//negative image

		void		SoMirr	(void);				//mirror image

//	protected://interface for <Photic>
	public:
		void		PhTune	(int	 dsth,		//tune
								 int	 srch);		//photic
		void		PhProg	(void);				//prognostication
		void		PhFili	(void);				//inner photofilter
		void		PhFilo	(void);				//& outward
		void		PhBows	(void);				//coloured photoimage

//	protected://interface for <Empire>

	public://interface for <Empire>
		void		EmTune	(int	 dsth,		//tune
								 int	 srch);		//auto empire
		void		EmBows	(int	 dsth,		//tune
								 int	 srch);		//coloured empire
		int		EmFlow	(void);				//tune needle
		int		EmSeek	(void);				//kernal of convolution
		void		EmNeed	(void);				//put needle
		void		EmCopy	(void);				//simple copy
		void		EmProg	(void);				//build histogram
		void		EmFili	(void);				//inner filter
		void		EmFilo	(void);				//outward filter
		void		EmBowsV	(void);				//coloured empier

//	protected://interface for <Shadow>

	public:
		void		ShTune	(int	 dsth,		//tune
								 int	 srch);		//shadow
		void		Shadoh	(void);				//shadow statistic
		void		Shadoi	(void);				//inner shadow
		void		Shadoo	(void);				//outward shadow
		void		ShBows	(void);				//coloured shadow

	};//Charm

	/***********************************
		Declaration of Codex class
	***********************************/
	class P_PACKED_4 WZD_EI Codex : public Charm
	{
      bool  m_ISO_compatibe;
      int   m_quality;

	public://constructor and destructor
		Codex					(void);				//constructor
		virtual
	  ~Codex					(void);				//destructor

	public://document controle
		void		ResDoc	(void);				//reset document

	public://quick context implementation
		void		Centre	(int	 qual = QH);//find centre
		void		SubDes	(void);				//extended design
		void		Design	(void);				//measure design
		void		DesImp	(void);				//import design
		void		Finger	(void);				//numeration

	public://rebuild source image
		void		Invert	(void);				//negative image

		void		Mirror	(void);				//mirror image


	public://encode & decode special data
		uint		EnFeat( byte *dst,SSign *src,uint size,uint *deg );
		int		DeFeat( SSign *dst,uint *src,uint size );


		int		DeIndi	(SSign *dst,		//indignations	
								 byte	 *src);
		int		DeSign	(SSign *dst,		//minutiaes
								 byte	 *src);
		int		DeArea	(byte	 *dst,		//unpack regions
								 byte	 *src);		
		int		DeArea	(byte	 *src);		//import regions

	public://exchange some data
		int		Parser	(int	 posx,		//parse nearest nest
						 int	 posy);
		int		Parser	(int	 *deg,		//parse one nest
						 int	 type);
		void		ExIndi	(byte  *dst,		//export indignations
							 int   &num);		
		void		ImIndi	(byte  *src,		//import indignations
							 int   &num);
		void		ImIndi	(SSign &src);		//correct indignation
		void	GetSize(int &num); //get template size
		void	ExGold(byte  *dst);
		void	ExData	(byte  *dst,		//export temporary data
							 int   &num);
		int		ImData	(byte  *src,		//import temporary data
						 int   &num);

	public://assemble <BackLoop>
		void		ImCoor	(SCoor *src,		//transform x&y

								 int	 inum);
		void		ImRect	(SCoor *src,		//define rectangle
								 int	 inum);
		void		ImZone	(SCoor *src,		//import bad area
								 int	 &num);
		void		ImGood	(SCoor *src,		//import good area
								 int   &num);
		void		RubOut	(SCoor *src,		//rubout skeleton
								 int	 &num);
		void		ImDraw	(SCoor *src,		//draw skeleton
								 int	 &num);
		void		ImFlow	(SCoor *src,		//draw flow order
								 int	 &num);

	public://debug procedure
//		void		Debugs	(int	 posx,		//debug 
//								 int	 posy);		
		void		Debugt	(int	 dsth,		//tune to debug
								 int	 srch);
		void		Debugi	(void);				//inner debug function
		void		Debugo	(void);				//outward debug function
//		void		Debugs	(void);				//standard debug

	public://colour intellect filters
		void		Source	(int   magn = 64,	//build source
								 int   subl = 64);
		void		Photic	(int   magn = 24,	//laplasian filter
								 int   subl = 48);
		void		Empire	(int	 magn = 24,	//oriented filter
								 int   subl = 48);
		void		Shadow	(int   magn,		//build shadows
								 int   subl,
								 int	 flow = 90);

	private://interface for <Visual>
		void		BoFlowII	(int	 dsth,		//tune
								 int	 srch);		//coloured flow
		void		BoSkel	(int	 dsth,		//tune
								 int	 srch);		//coloured skeleton
		void		BoArea	(int	 dsth,		//tune
								 int	 srch);		//coloured area
		int		BoFlowI	(int	 step);		//write coloured flow
		void		BoFlowV	(void);				//show flow
		void		BoAreaV	(void);				//show area
		void		BoSkelV	(void);				//show skeleton

	private://subfunctions to load object
		inline
		int		SizePi	(void);				//size of pyramid in bytes
		inline
		void		TunePi	(void);				//tune pyramid
		inline
		void		TuneQu	(void);				//tune quick access
		inline
		void		TuneFi	(byte	 *src);		//tune echelon's pointer
		void		APixel	(byte	 *dst,		//transformation of pixel
								 byte	 *src,

								 byte	 bits = C0);
		void		Loader	(byte	 *dst,		//transformation of image
								 byte	 *src,
								 int	 eche = H0,
								 byte	 bits = C0);
		int		ViCopy	(int	 dstl,		//reform lay copy
								 int	 srcl,
								 int	 eche = H0,
								 byte	 bits = C0);
		int		ViDraw	(int	 scan,		//reform drawing
								 int	 dsth,
								 int	 srch,
								 int	 step =  8);

	public://work loading procedures
		int		GetTip	(SData &inf);		//build image
		int		Loader	(SData &inf,		//quick load
						 const int *lay = 00, bool ISO_compatibe = false);
		int		Loader	(Codex &src,		//load intellectual icon
								 const int *lay = 00);
	//	int		Legacy	(byte	 *sig,		//inherit code
//
	//							 byte	 *ske = 00);
		void		Visual	(int	 type,		//synthesis of pattern
								 int	 magn,
								 int	 subl,
								 int	 flow,
								 int	 comp,
								 int	 step =  8);

	public://calculate dacto formula
		byte*		BaseFm	(int begins);		//common
		byte*		SuppFm	(int begins);		//supplemantary

	public://extention of the Henry system
		void		ExForm	(int	 init = 00);//initial data
		int		EnForm	(byte	 *dst);		//Henry encoding
		int		DeForm	(byte	 *src);		//Henry decoding
		int		NBISys	(byte	 *src);		//plonly Henry formula for NBI
		int		NBISys	(STips *tip,
								 Henry *hen);		//cases Henry system for NBI
		void		HenSys	(char	 *key,
								 char	 *maj,
								 char	 *pri,
								 char	 *sec,
								 char	 *sub,
								 char	 *sss,
								 char	 *fin);


	public://work procedure for tenprint
		void		Target	(int	 reih);		//find out target
		int		Frames	(int	 reih);		//set frames

	public://hierarchy linked functions
		void		Lightf	(int   reih);		//first sunlight image
		void		Stream	(int	 reih);		//measure stream
		void		Cohere	(int	 reih);		//coherence
		void		Pickup	(int	 reih);		//pick up flow
		void		Ifocus	(int	 reih);		//find out focuses		
		void		Respon	(int	 reih);		//stream response
		void		Xfocus	(int	 reih);		//define more precisely focuses
		void		Lights	(int   reih);		//second sunlight image
		void		Attrac	(int	 reih);		//set attractor-focuses, class
		void		Swells	(int	 reih);		//swell flow kernal
		void		Flower	(int	 reih);		//flow decomposition & confluence
		void		Curvat	(int	 reih);		//build curvature
		void		Furiew	(int   reih);		//measure correlation
		void		Harmon	(int	 reih);		//analize harmony
		void		Expert	(int	 reih);		//explore image
		void		Laying	(int	 reih);		//laying out pattern
		void		Filter	(int	 reih);		//filter image
		void		Skelet	(int	 reih);		//refine lines
		void		Minuti	(int	 reih);		//get minutiaes
		void		Linker	(int	 reih);		//extract metric
		void		Epilog	(int	 reih);		//epilog
//        void        correctBadArea(int newX, int newY); 


	public://new system convertor 
		int		Convrt	(byte	 *dst,		//convertor
								 byte	 *src,
								 int	 type);
		int		Convrt	(byte	 *dst,		//linkages convertor
								 void	 *min,
								 byte	 *src,
								 int	 size);
		public:
			//void Swellw_edges_1(unsigned char *t_Sfno, unsigned char *t_Dsto, int tempt_Indx,
			//			 int tempt_Redx, int tempt_Dedx);
			//void Swellw_edges_2(unsigned char *t_Sfno, unsigned char *t_Dsto, int tempt_Indx,
			//			 int tempt_Redx, int tempt_Dedx);
			void Swellw_edges_1(int tempt_Indx, int tempt_Redx, int tempt_Dedx);
			void Swellw_edges_2(int tempt_Indx, int tempt_Redx, int tempt_Dedx);
			void Swellw_inner();


	
	public://special info about image
		word		ImgDPI,							//original DPI
					ManDPI;							//for work
		int		ImgDir,							//original direction
					ManDir;							//for work
		byte		Method,							//scale method
					Shrink,							//presentation method
					Impose,							//two imprints superpose
					Number,							//image number
					Qualit,							//quality
					Densit,							//image density


					ImMask,							//type of image
					ImType,							//L, F, P, S, A, T, V

					TipNet,							//section depth
					Passxy,							//xy pass
					Passan;							//alpha pass
		word		ExMask;							//extended type of image

		//objects number
		int		PFocus,							//packed indignations length
					PPoint,							//packed minutiaes length
					PTotal,							//packed total count number
					PRidge,							//packed ridge count quantity
					PAreas,							//packed areas
					PLinks;							//packed linkages length


	public://special data
		SItem		Item;								//dacto data
		SDisp		Disp;								//displacement

	public://classification formula
		STips		Tips[_TIP_],					//
					Tipe[_TIP_];					//
		Henry		Henr[_FRM_];


	protected://tree of objects
		Codex*	Root,								//root of tree
			  *	Node;								//node of tree

   public:
      int getQuality()
      {
         return m_quality;
      }

	};//Codex


	/**************************************
				Models of indignations
	**************************************/
	extern	byte	Delta[],						//Delta
						Archs[],						//Arch
						Loops[],						//Loop
						Whorl[];						//Whorl

	//defualt alignment 
#ifdef _WINDOWS
	#pragma	pack(pop)
#endif

//	Set symmetric rectangle

inline void	CBase::WiRect( int eche,int retr )
{
	//set this rectangle
	L_re = retr,
	R_re = MaxX[eche]-1-
			 retr,
	T_re = retr,
	B_re = MaxY[eche]-1-
			 retr;
}

//	Reset basket
inline void	CBase::Basket( void )
{
	Bask = 
	Team = 0;
}

//	Reset random

inline void	CBase::Rreset( void )
{
	Pran = 
	Qran = 0;
}

//	Do links
inline void	CBase::DoLink( byte **psrc )
{
	  *psrc = Movo;
}

//	Store moving position
inline void	CBase::DoKeep( byte **psrc )
{
	if (psrc == &Useo)
	{
		Useo = Movo;
		Usex = Movx;
		Usey = Movy;
	}
	else
	if (psrc == &Loco)
	{
		Loco = Movo;
		Locx = Movx;
		Locy = Movy;
	}
	else
	if (psrc == &Helo)
	{
		Helo = Movo;
		Helx = Movx;

		Hely = Movy;
	}

	else
	if (psrc == &Prjo)

	{
		Prjo = Movo;
		Prjx = Movx;
		Prjy = Movy;
	}

	else//common
	{
	  *psrc = Movo;
		Srcx = Movx;
		Srcy = Movy;
	}
}

//	Set moving position
inline void	CBase::DoMove( byte **psrc ) 
{
	if (psrc == &Useo)
	{
		Movo = Useo;
		Movx = Usex;
		Movy = Usey;
	}
	else
	if (psrc == &Loco)
	{
	   Movo = Loco;
	   Movx = Locx;
	   Movy = Locy;
	}
	else
	if (psrc == &Helo)
	{
	   Movo = Helo;
	   Movx = Helx;
	   Movy = Hely;
	}
	else
	if (psrc == &Prjo)
	{
	   Movo = Prjo;
	   Movx = Prjx;
	   Movy = Prjy;
	}
	else//common
	{
		Movo =*psrc;
		Movx = Srcx;
		Movy = Srcy;
	}
}

//	Set moving position then shift
inline void	CBase::ReMove( byte **psrc )
{
		Movo =*psrc+
				 Remo;
		Movx = Srcx+
				 Remv;
		Movy = Srcy+
				 Remv;
}

//	Set maximum and minimum
inline void	CBase::DoMami( byte item )
{
	Imax = 
	Imin = item;
}

//	Sunlight along c direction
inline int	CBase::Fisunc( byte *src )
{
	return	*(src+Reax) * 2 +
			*(src+Incx)	  +
			*(src+Decx)	  -
			*(src-Reax) * 2 -
			*(src-Incx)	  -
			*(src-Decx);
}

//	Sunlight along f direction
inline int	CBase::Fisunf( byte *src )
{
	return	-Fisunb( src );
}

//	Sunlight along a direction
inline int	CBase::Fisuna( byte *src )
{
	return	
      *(src+   1) * 2 +
      *(src-Decx)	    +
      *(src+Incx)	    -
      *(src-   1) * 2 -
      *(src+Decx)	    -
      *(src-Incx);
}

//	Check razor edge
inline int	CBase::Razors( int tune )
{
	//source?
	if (tune)
		return Srcx == Reax-1 ||
				 Srcx ==		  0 ||
				 Srcy == Reay-1 ||
				 Srcy ==		  0;

	else
		return Dstx == Redx-1 ||
				 Dstx ==		  0 ||

				 Dsty == Redy-1 ||
				 Dsty ==		  0;
}

inline int	CBase::Fiimpw( byte *src,int tune )
{
//return *src;

	//inf data processing
	byte	   inf[9];//1+8

	//do gather & sorting
	FiRead(inf,src,tune);
	//influence sorting..
/*
   isort (  inf,less,7  );
	//final range result
	return  (
      inf[0]*1	  +
      inf[1]*1	  +
      inf[2]*2	  +
      inf[3]*2	  +
      inf[4]*2	  +
      inf[5]*2	  +
      inf[6]*1	  +
      inf[7]*1	  +
      inf[8]*1	  +8)/16;
*/

//	isort (  inf,less);
	//final range result
	return  (
      inf[0] +	
//      inf[1]*1 + 
      inf[2] + 
  //    inf[3]*1 +
      inf[4] +	
  //    inf[5]*1 + 
      inf[6]	+ 
  //    inf[7]*1 +
      inf[8]*4 + 
      4)/8;
}

//	Normal impulse
inline int	CBase::Fiimpn( byte *src,int tune )

{
	//inf data processing
	byte	   inf[9];//1+8

	//do gather & sorting
	FiRead(inf,src,tune);

	//final range result
	return  (inf[0]*2	  +
				inf[1]*1	  +
				inf[2]*2	  +
				inf[3]*1	  +
				inf[4]*2	  +
				inf[5]*1	  +
				inf[6]*2	  +
				inf[7]*1	  +

				inf[8]*4	  +8)/16;
}

//	Collection impulse
inline int	CBase::Fiimpc( byte *src,int tune )
{

	//inf data processing
	byte	   inf[9];//1+8

	//do gather & sorting
	FiRead(inf,src,tune);

	//final range result
	return   inf[0]*1	  +
				inf[1]*1	  +
				inf[2]*1	  +
				inf[3]*1	  +
				inf[4]*1	  +
				inf[5]*1	  +
				inf[6]*1	  +
				inf[7]*1	  +
				inf[8]*1	  ;
}

//	Read nearest region for filters
inline void	CBase::FiRead( byte *inf,byte *src,int tune )

{
	//source?
	if (tune)
	{
		//do gather & scaling
		inf[0] = *(src+   1);
		inf[1] = *(src+Incx);
		inf[2] = *(src+Reax);
		inf[3] = *(src+Decx);
		inf[4] = *(src-   1);
		inf[5] = *(src-Incx);
		inf[6] = *(src-Reax);
		inf[7] = *(src-Decx);

		inf[8] = *(src		 );
	}
	else
	{
		//do gather & scaling
		inf[0] = *(src+   1);
		inf[1] = *(src+Indx);
		inf[2] = *(src+Redx);
		inf[3] = *(src+Dedx);
		inf[4] = *(src-   1);
		inf[5] = *(src-Indx);
		inf[6] = *(src-Redx);
		inf[7] = *(src-Dedx);
		inf[8] = *(src		 );
	}
}


//	Resets Bresenham's position
inline void	CBase::Breset( void )
{
	Mreset();
	Joff = 0;
}


//	Check right edge
inline int	CBase::R_Edge( int xpos,int ypos,int tune )
{
	//source?
	if (tune)
		return Srcx-xpos <  Reax &&
				 Srcx-xpos >=	  0 &&
				 Srcy-ypos <  Reay &&
				 Srcy-ypos >=	  0;
	else
		return Dstx-xpos <  Redx &&
				 Dstx-xpos >=	  0 &&
				 Dsty-ypos <  Redy &&
				 Dsty-ypos >=	  0;
}

//	Check left edge
inline int	CBase::L_Edge( int xpos,int ypos,int tune )
{
	//source?
	if (tune)
		return Srcx+xpos <  Reax &&
				 Srcx+xpos >=	  0 &&

				 Srcy+ypos <  Reay &&
				 Srcy+ypos >=	  0;
	else
		return Dstx+xpos <  Redx &&
				 Dstx+xpos >=	  0 &&
				 Dsty+ypos <  Redy &&
				 Dsty+ypos >=	  0;

}

//	Check both left & right edge
inline int	CBase::N_Edge( int xpos,int ypos,int tune )
{
	return R_Edge( xpos,
						ypos,
						tune ) &&
			 L_Edge( xpos,
						ypos,
						tune );
}

//	Reset moving position
inline void	CBase::Mreset( void )
{
	Movo = 0;
   Movx =
   Movy = 0;
}

//	Standard medium broken line reply
inline int	CBase::FiBrom( SStep *fwd,SStep *bck,byte *src )
{
	//read data to buffer
	byte	inf[9]; 
	FiBrok(fwd, bck, src, inf, 9);

	//return final result
	return  (	inf[0]*1	  +
				inf[1]*1	  +
				inf[2]*2	  +
				inf[3]*2	  +
				inf[4]*4	  +
				inf[5]*2	  +
				inf[6]*2	  +
				inf[7]*1	  +
				inf[8]*1	  +8)/16;
}

//	Standard small broken line reply
inline int	CBase::FiBros( SStep *fwd,SStep *bck,byte *src )
{
	//read data to buffer
	byte	inf[7]; 
			FiBrok( fwd,bck,
							src,
							inf,7  );

	//return final result
	return  (inf[0]*1	  +
				inf[1]*2	  +
				inf[2]*2	  +
				inf[3]*6	  +
				inf[4]*2	  +
				inf[5]*2	  +
				inf[6]*1	  +8)/16;
}

//	Range impulse
inline int	CBase::Fiimpr( byte *src,int tune )
{
	//inf data processing
	byte	   inf[9];//1+8

	//do gather & sorting
	FiRead(inf,src,tune);

	//influence sorting..
	isort(inf, less);

	//final range result
	return  (
      inf[0]*1 +	
      inf[1]*1 + 
      inf[2]*2 + 
      inf[3]*2 +
      inf[4]*4 +	
      inf[5]*2 + 
      inf[6]*2	+ 
      inf[7]*1 +
      inf[8]*1 + 
      8)/16;
}

//	Common read data from the broken line
inline void	CBase::FiBrok( SStep *fwd,SStep *bck,byte *src,byte *inf,int size )
{
	//puts a needle forward and backward
	for (int i =0,j =1; i < size/2; i++)
	{
		inf[j++] = *( src + fwd[i].IncO );
		inf[j++] = *( src + bck[i].IncO );
	}

	
	//read center and sort the all pixels
	inf[0] = *src;	 isort( inf,less,
										size- 1 );
}

//	Bits' 8-linked collection
inline int	CBase::FiBite( byte *src,byte bits )
{
	int sign = 0;//default nothing

	//collect bits position
	if (*(src+   0) & bits) 
		++sign;
	if (*(src+   1) & bits) 
		++sign;
	if (*(src+Indx) & bits) 
		++sign;
	if (*(src+Redx) & bits) 
		++sign;
	if (*(src+Dedx) & bits) 
		++sign;
	if (*(src-   1) & bits) 
		++sign;
	if (*(src-Indx) & bits) 
		++sign;
	if (*(src-Redx) & bits) 
		++sign;
	if (*(src-Dedx) & bits) 
		++sign;

		//final area
		return sign;
}

//	Simple sense nearest bits
inline int	CBase::FiBits( byte *src,byte bits )
{
	int sign = 0;//default nothing

	//check bits in small position
	if ((sign = *(src+   0) & bits)) 
		return sign;
	if ((sign = *(src+   1) & bits) )
		return sign;
	if ((sign = *(src+Indx) & bits)) 
		return sign;
	if ((sign = *(src+Redx) & bits)) 
		return sign;
	if ((sign = *(src+Dedx) & bits)) 
		return sign;
	if ((sign = *(src-   1) & bits)) 
		return sign;
	if ((sign = *(src-Indx) & bits)) 
		return sign;
	if ((sign = *(src-Redx) & bits)) 
		return sign;
	if ((sign = *(src-Dedx) & bits)) 
		return sign;

		//final bits
		return sign;
}


//	Select item in a list
inline int	CBase::FiList( byte *src,int item,int tune )

{
	//inf data processing
	byte	   inf[9];//1+8

	//do gather & sorting

	FiRead(inf,src,tune);

	//influence sorting..
	isort (  inf,more  );

	//final range results
	return	inf[ item ];
}

//	Get mirror for edges
inline int	CBase::FiMirr( byte *src )
{
	int even = 0; //zero

	//generate the event
	if (Dstx -1 <	   0)
		 even+=1;
	if (Dsty -1 <	   0)
		 even+=2;
	if (Dstx +1 >= Redx)
		 even+=4;
	if (Dsty +1 >= Redy)
		 even+=8;

	if (even == 1)
		return*(src+	1);
	if (even == 2)
		return*(src+Redx);
	if (even == 3)
		return*(src+Indx);
	if (even == 4)
		return*(src-	1);
	if (even == 6)
		return*(src+Dedx);
	if (even == 8)
		return*(src-Redx);
	if (even == 9)
		return*(src-Dedx);
	if (even ==12)
		return*(src-Indx);

	return *src; //error!
}

//-------------------------------------
//	Threshold level
//-------------------------------------
inline int	CBase::FiDoor( int *coe )
{
	return (coe[0]*Imax +
			  coe[1]*Imin +
			  coe[2]*Thre)/
			 (coe[0]		  +
			  coe[1]		  +
			  coe[2]		 );
}

//	Oriented impulse
inline int CBase::Fiimpo( int flow,byte *src,int tune )
{
	//inf data processing
	int	   fun[9];//1+8

	//base impulse scheme
	fun[0] = fun[4] = cogm(32, cone(00, flow));
	fun[1] = fun[5] = cogm(32, cone(AQ, flow));
	fun[2] = fun[6] = cogm(32, cone(AR, flow));
	fun[3] = fun[7] = cogm(32, cone(AW, flow));
	fun[8] = 32; //pocket

	//base impulse weight
	int div	= (fun[0] + fun[1] + fun[2] + fun[3] + fun[4] +
         	   fun[5] +	fun[6] + fun[7] + fun[8]);

	//do gather & scaling
	Fiimpo(fun, src, tune);

	//an oriented impulse
	return DIP( fun[0] + fun[1] + fun[2] + fun[3] + fun[4] +
				fun[5] + fun[6] + fun[7] + fun[8], div);
}
//	Sunlight along e direction
inline int	CBase::Fisune( byte *src )
{

	return	-Fisuna( src );
}

//	Common oriented impulse

inline void	CBase::Fiimpo( int *fun,byte *src,int tune )
{
	//inf data processing
	byte	   inf[9];//1+8

	//do gather & sorting
	FiRead(inf,src,tune);

	//do gather & scaling
	fun[0]	*=	  inf[0];
	fun[1]	*=   inf[1];
	fun[2]	*=   inf[2];
	fun[3]	*=   inf[3];
	fun[4]	*=   inf[4];
	fun[5]	*=   inf[5];
	fun[6]	*=   inf[6];
	fun[7]	*=   inf[7];
	fun[8]	*=   inf[8];
}

//	Sunlight along d direction
inline int	CBase::Fisund( byte *src )
{
	return	*(src+Decx) * 2 +
				*(src+Reax)	  +
				*(src-   1)	  -
				*(src-Decx) * 2 -
				*(src-Reax)	  -
				*(src+   1);	  
}

//	Sunlight along b direction
inline int	CBase::Fisunb( byte *src )
{
	return	*(src+Incx) * 2 +
				*(src+Reax)	  +

				*(src+   1)	  -
				*(src-Incx) * 2 -
				*(src-Reax)	  -
				*(src-   1);
}

//	Facet of rectangle
inline int	CBase::FaRect( int srcx,int srcy )
{
	return srcx == L_re  ||
			 srcx == R_re  ||
			 srcy == T_re  ||
			 srcy == B_re;

}

inline int	CBase::InRect( int srcx,int srcy )
{
	return srcx >= L_re  &&
			 srcx <= R_re  &&
			 srcy >= T_re  &&
			 srcy <= B_re;
}
//	Choose inked point along direction
inline int	CBase::Chosei( int adir )
{
	//check echelon edge - exit
	if (Movx <= 0				 ||
		 Movx >= MaxX[H_go]-1 || 
		 Movy <= 0				 ||
		 Movy >= MaxY[H_go]-1 )		return 0;

	//read pixels to select
	int fwd = *(Movo+F_go);
	int rht = *(Movo+R_go);
	int lft = *(Movo+L_go);

	//select direction

	if (rht < fwd)
		if (rht < lft)//right
			MvMove((adir == 7) ? 0: adir+1 );
		else//left
			MvMove((adir == 0) ? 7: adir-1 );
	else 
		if (lft < fwd)//left
			MvMove((adir == 0) ? 7: adir-1 );
		else//forward
			MvMove( adir );			return 1;
}

//	Advance one position along
inline void	CBase::MvMove( int adir ) 
{
	//advance the current position
	Movx += Move[H_go].IncX[adir];
	Movy += Move[H_go].IncY[adir];
	Movo += Move[H_go].IncO[adir];
}

inline int	CBase::Fiimpp( byte *src,int tune )
{
	//inf data processing
	byte	   inf[9];//1+8

	//do gather & sorting
	FiRead(inf,src,tune);

	//final range result
	return  (inf[0]*1	  +
				inf[1]*1	  +
				inf[2]*1	  +
				inf[3]*1	  +
				inf[4]*1	  +
				inf[5]*1	  +
				inf[6]*1	  +
				inf[7]*1	  +4)/8;
}

//	Advance position along direction
inline void	CBase::MvStep( int adir )
{
	Movx += Move[H_go].IncX[adir];
	Movy += Move[H_go].IncY[adir];
	Movo += Move[H_go].IncO[adir];
	Joff += Move[H_go].IncO[adir];
	Hoff += Move[H_go].IncO[adir];
	Noff += Move[H_go].IncO[adir];
	Eoff += Move[H_go].IncO[adir];
}
//	Standard small broken line reply
inline int	CBase::FiBrot( SStep *fwd,SStep *bck,byte *src )
{
	//read data to buffer
	byte	inf[7]; 
			FiBrok( fwd,bck,
							src,
							inf,5  );

	//return final result
	return  (inf[0]	  +
				inf[1]	  +
			  (inf[2]<<2) +
				inf[3]	  +
				inf[4] 	  +4) >> 3;
}



#ifdef __cplusplus
} // namespace wizard73{
#endif  

#endif	//__WIZARD_H
