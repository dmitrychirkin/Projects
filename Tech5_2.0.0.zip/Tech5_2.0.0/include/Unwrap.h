#pragma		once
#ifndef		UNWRAP_H
#define		UNWRAP_H

//library dependence
#include   "Eskdef.h"

//export-import control
#if defined  (linux)
   #define    WRP_EI
#elif defined(LIBLDS)
   #define    WRP_EI
#elif defined(UNWRAP)
   #define    WRP_EI	__declspec( dllexport )
#else
   #define    WRP_EI	__declspec( dllimport )
#endif

#pragma pack(push,_ESK_PACKING)
#pragma pack(push,_ESK_TIGHTEN)
_ESK_BEGIN
//-------------------------------------
// Special interface declarations
//-------------------------------------
template<class _Ty>
struct  Dot;
typedef Dot<iint_t>  Point;

template<class _Ty>
struct  Roc;
typedef Roc<shrt_t>  Pore;

template<class _Ty>
struct  Lot;
typedef Lot<shrt_t>  Sign;

typedef Pore         pore_t, *pore_p;
typedef Sign         sign_t, *sign_p;
struct  Bond;
typedef Bond         bond_t, *bond_p;
struct  Link;
typedef Link         link_t, *link_p;

template<class _Ty>
struct _LNX_TIGHTEN Dot
	{//cartesian point
   typedef Dot<_Ty> Self_t;
   typedef     _Ty  item_t;

   Dot() : Movx(),Movy() 
      {//construct default
      }

   Dot( _Ty _X,_Ty _Y ) : Movx(_X),Movy(_Y) 
      {//construct from
      }

	Self_t & 
      operator=( const _Ty &_Rht )
         {//assign operator
         Movx  = _Rht;
         Movy  = _Rht;      return (*this);
         }

	Self_t & 
      operator=( const Self_t &_Rht )
         {//assign operator
         Movx  = _Rht.Movx;
         Movy  = _Rht.Movy; return (*this);
         }

	Self_t &
      operator+=( const Self_t &_Rht )
		   {//add other dot
		   Movx += _Rht.Movx;
		   Movy += _Rht.Movy; return (*this);
		   }

	Self_t &
      operator-=( const Self_t &_Rht )
		   {//subtract other dot
		   Movx -= _Rht.Movx;
		   Movy -= _Rht.Movy; return (*this);
		   }

	Self_t
      operator+( const Self_t &_Rht ) const
		   {//add other dot
		   Self_t _Tmp = *this; return (_Tmp += _Rht);
		   }

	Self_t
      operator-( const Self_t &_Rht ) const
		   {//subtract other dot
		   Self_t _Tmp = *this; return (_Tmp -= _Rht);
		   }

	template<class _Other> bool_t
      operator!=( const _Other &_Rht ) const
		   {//test for inequality
         return (Movx != _Rht.Movx || Movy != _Rht.Movy);
		   }

	template<class _Other> bool_t
      operator==( const _Other &_Rht ) const
		   {//test for equality
         return (Movx == _Rht.Movx && Movy == _Rht.Movy);
		   }

	item_t   //coordinates
		Movx,
		Movy;
	};

template<class _Ty>
struct _LNX_TIGHTEN Roc : public Dot<_Ty>
	{//feature
   typedef Dot<_Ty> Base_t;
   typedef Roc<_Ty> Self_t;

   Roc() : Prob()
      {//construct default
      }

   template<class _Other>
	Roc( _Other _X,_Other _Y,byte_t _P = 0 ) : Base_t((_Ty)_X,(_Ty)_Y),Prob(_P)
      {//constructor
      }

	byte_t   //probability
		Prob;
	};

template<class _Ty>
struct _LNX_TIGHTEN Lot : public Dot<_Ty>
	{//feature
   typedef Dot<_Ty> Base_t;
   typedef Lot<_Ty> Self_t;

   Lot() : Beta(),Type(),Prob(),Lace(),Curl(),Look()
      {//construct default
      }
   template<class _Other>
	Lot( _Other _X,_Other _Y,byte_t _T = 0,
                            shrt_t _B = 0,
                            byte_t _P = 0,
                            byte_t _L = 0,
                            byte_t _C = 0,
                            byte_t _O = 0 ) : Base_t((_Ty)_X,(_Ty)_Y),Type(_T),Beta(_B),Prob(_P),Lace(_L),Curl(_C),Look(_O) 
      {//constructor
      }

   shrt_t   //direction
      Beta;
	byte_t   //type, probability, density, curvature, zone
      Type,
		Prob,
		Lace,
      Curl,
		Look;
	};

struct _LNX_TIGHTEN Bond
	{//one knot
	Bond() : Deal(),Azim(),Teta(),Pink(),Size(),Item()
		{//default constructor
		}

   void_t
      init()
         {//initialize
		   Deal =
            Azim =
               Teta =
                  Pink = 0;
		               Size =
                        Item = 0;
         }

   byte_t   //linkage event, azimus, teta, pink
		Deal,
      Azim,
      Teta,
      Pink;

	twin_t   //radius, minutiae number
		Size,
      Item;
   };

struct _LNX_TIGHTEN Link
	{//complex nest
   Link() : Cage()
		{//construct default
		}

   bond_t   //linkages
      Knot[MAXL];
	byte_t   //max number of non-zero link
      Cage;
	};

#pragma pack(pop)

/**************************************
      Template code deblocking
**************************************/
class WRP_EI Unwrap
	{typedef  Unwrap Self_t;

	//have forbiden
	void_t operator&() const;
	void_t operator*() const;

	//----------------------------------
	// Constructor and destructor
	//----------------------------------
public:
	static
		Self_t*	create();                         //create object using secret key
	static
		void_t   cancel( /* */ Self_t*&_Obj );		 //delete object

	//----------------------------------
	// Control functions
	//----------------------------------
	virtual
		void_t   versor( /* */ uint_t	 _Ver ) = 0; //set active version of library
	virtual
		void_t   factor( /* */ bool_t  _Flg ) = 0; //true - 256, default false - 360 degree

	//----------------------------------
	// Verify template
	//----------------------------------
	virtual
		bool_t   verify( const byte_t *_Tpl ) = 0; //partial template inspection
	virtual
		bool_t   defend( const byte_t *_Tpl ) = 0; //first signature
	virtual
		bool_t   hasher( const byte_t *_Tpl ) = 0; //next signature

	//----------------------------------
	// Isolated parameters
	//----------------------------------
	virtual
		uint_t   length( const byte_t *_Tpl ) = 0; //template length
	virtual
		byte_t   versor( const byte_t *_Tpl ) = 0; //version number of template
	virtual
		byte_t   qualit( const byte_t *_Tpl ) = 0; //get pattern quality
	virtual
		byte_t   densit( const byte_t *_Tpl ) = 0; //get pattern density
	virtual
		byte_t   passxy( const byte_t *_Tpl ) = 0; //get radius pass
	virtual
		byte_t   passan( const byte_t *_Tpl ) = 0; //get angle pass
	virtual
		byte_t   square( const byte_t *_Tpl ) = 0; //get image area
	virtual
		byte_t   immask( const byte_t *_Tpl ) = 0; //get image mask
	virtual
		twin_t   exmask( const byte_t *_Tpl ) = 0; //get extended image mask
	virtual 
		twin_t   size_x( const byte_t *_Tpl ) = 0; //get <x> size of image
	virtual 
		twin_t   size_y( const byte_t *_Tpl ) = 0; //get <y> size of image
	virtual 
		twin_t   imgppi( const byte_t *_Tpl ) = 0; //image processing PPI
	virtual 
		twin_t   tplppi( const byte_t *_Tpl ) = 0; //template PPI
	virtual 
		byte_t   finger( const byte_t *_Tpl ) = 0; //number of finger

	//----------------------------------
	// Isolated deblocking
	//----------------------------------
	virtual
		twin_t   demain( Sign  *const  _Dst,
							  const byte_t *_Tpl ) = 0; //singularities deblocking
	virtual
		twin_t   denova( Sign  *const	 _Dst,
							  const byte_t *_Tpl ) = 0; //minutiae deblocking
   virtual
      twin_t   denest( const link_p &_Dst,
                       const sign_p &_Src,
                             twin_t  _Num,
                       const byte_t *_Tpl ) = 0; //linkages deblocking
	virtual
		twin_t   deabac( byte_t*const  _Dst,
							  const byte_t *_Tpl ) = 0; //ridge count deblocking
	virtual
		uint_t   dearea( byte_t*const  _Dst,
							  const byte_t *_Tpl ) = 0; //list of area deblocking

	//----------------------------------
	// Read size of
	//----------------------------------
	virtual
		twin_t   idmain( const byte_t *_Tpl ) = 0; //number of singularities
	virtual
		twin_t   idnova( const byte_t *_Tpl ) = 0; //number of minutiae
	virtual
		uint_t   idarea( const byte_t *_Tpl ) = 0; //size of areas

	};//Unwrap

_ESK_END
#pragma pack(pop)
#endif//UNWRAP_H
