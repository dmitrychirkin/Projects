/**************************************
				TypDef.h
	Type definitions for workspace.

		 Author Gudkov V.U.
**************************************/

//	Sentry
#if !defined (__TYPDEF_73_H)  
	#define __TYPDEF_73_H

//#pragma warning(disable: 4244)

#ifdef X64
   typedef      long long int_t;
#else
   typedef           int   int_t;
#endif


	//compatible types for source
	typedef	unsigned char	byte;
	typedef	unsigned short	word;
   typedef	unsigned int   uint;
	typedef	unsigned int	corn;


#endif	//__TYPDEF_73_H
