#ifndef NIST14_TEST_H_
#define NIST14_TEST_H_

#include <assert.h>
#include <stdint.h>


#define NIST14_SIZE     2700

inline uint64_t NIST14_getDbSize()
{
   return NIST14_SIZE * 2;
}

inline uint64_t NIST14_getRegNum (uint64_t id, uint64_t impression)
{
   assert(impression <= 1);
   return impression ? id + NIST14_SIZE : id;
}

inline void NIST14_getId_imp(uint64_t regNum, uint64_t &id, uint64_t &impression)
{
   id         = regNum % NIST14_SIZE;
   impression = regNum / NIST14_SIZE;
}

inline void NIST14_getImagePath (char *imageDir, char *imagePath, uint64_t regNum, uint64_t finger)
{
   uint64_t id = 0, impression = 0;
   NIST14_getId_imp(regNum, id, impression);
   sprintf (imagePath, "%s/CRD_%04d/%c%07d.WSQ", imageDir, id + 1, impression ? 'S' : 'F', id * 10 + finger + 1);
}


inline void NIST14_getTpName (char *tpName, uint64_t regNum)
{
   uint64_t id = 0, impression = 0;
   NIST14_getId_imp(regNum, id, impression);
   sprintf (tpName, "%c%04d.tpl", impression ? 'S' : 'F', id + 1);
}

inline void NIST14_getTemplatePath (char *templateDir, char *templatePath, uint64_t regNum, uint64_t finger)
{
   uint64_t id = 0, impression = 0;
   NIST14_getId_imp(regNum, id, impression);
   sprintf (templatePath, "%s/%c%07d.tpl", templateDir, impression ? 'S' : 'F', id * 10 + finger + 1);
}


inline uint64_t NIST14_getNumGenuine (uint64_t probeRegNum)
{
   uint64_t probeId   = 0, probeImp   = 0; 
   NIST14_getId_imp(probeRegNum, probeId, probeImp);

   switch(probeId)
   {
   case 95:
   case 144:
      return 3;
   case 992:
   case 1565:
   case 1850:
      return 5;
   case 1358:
   case 2015:
      return 3;
   default:
      return 1;
   }
}

inline uint64_t NIST14_fillNumGenuine (uint64_t probeRegNum, uint64_t *genuineNum)
{
   uint64_t probeId   = 0, probeImp   = 0; 
   NIST14_getId_imp(probeRegNum, probeId, probeImp);

   uint64_t count = 0;
   genuineNum[count++] =  NIST14_getRegNum (probeId, probeImp ? 0 : 1);

   switch(probeId)
   {
   case 95:
      genuineNum[count++] =  NIST14_getRegNum (144, 0);
      genuineNum[count++] =  NIST14_getRegNum (144, 1);
      break;
   case 144:
      genuineNum[count++] =  NIST14_getRegNum ( 95, 0);
      genuineNum[count++] =  NIST14_getRegNum ( 95, 1);
      break;
   case 992:
      genuineNum[count++] =  NIST14_getRegNum (1565, 0);
      genuineNum[count++] =  NIST14_getRegNum (1565, 1);
      genuineNum[count++] =  NIST14_getRegNum (1850, 0);
      genuineNum[count++] =  NIST14_getRegNum (1850, 1);
      break;
   case 1565:
      genuineNum[count++] =  NIST14_getRegNum ( 992, 0);
      genuineNum[count++] =  NIST14_getRegNum ( 992, 1);
      genuineNum[count++] =  NIST14_getRegNum (1850, 0);
      genuineNum[count++] =  NIST14_getRegNum (1850, 1);
      break;
   case 1850:
      genuineNum[count++] =  NIST14_getRegNum ( 992, 0);
      genuineNum[count++] =  NIST14_getRegNum ( 992, 1);
      genuineNum[count++] =  NIST14_getRegNum (1565, 0);
      genuineNum[count++] =  NIST14_getRegNum (1565, 1);
      break;
   case 1358:
      genuineNum[count++] =  NIST14_getRegNum (2015, 0);
      genuineNum[count++] =  NIST14_getRegNum (2015, 1);
      break;
   case 2015:
      genuineNum[count++] =  NIST14_getRegNum (1358, 0);
      genuineNum[count++] =  NIST14_getRegNum (1358, 1);
      break;
   default:
      break;
   }
   return count;
}


inline bool NIST14_isGenuine (uint64_t probeRegNum, uint64_t galleryRegNum)
{
   uint64_t probeId   = 0, probeImp   = 0; 
   uint64_t galleryId = 0, galleryImp = 0; 
   NIST14_getId_imp(probeRegNum  , probeId  , probeImp  );
   NIST14_getId_imp(galleryRegNum, galleryId, galleryImp);
   if (probeId == galleryId)
      return true;

   switch(probeId)
   {
   case 95:
      return (galleryId == 144);
   case 144:
      return (galleryId ==  95);
   case 992:
      return (galleryId == 1565 || galleryId == 1850); 
   case 1565:
      return (galleryId ==  992 || galleryId == 1850); 
   case 1850:
      return ( galleryId == 992 || galleryId == 1565); 
   case 1358:
      return (galleryId == 2015);
   case 2015:
      return (galleryId == 1358);
   default:
      return false;
   }

}

#endif