//	Tech5_ClientEdition.h - header file for Tech5_ClientEdition.dll
 
#ifndef TECH5_CLIENT_EDITION_H_
#define TECH5_CLIENT_EDITION_H_

#include <common.h>
#include <tech5_se.h>


typedef void* TECH5_CLIENT;  // handle of Tech5_ClientEdition SDK

typedef void (* ON_GET_IMAGE) (int result, unsigned char** p, void* data);

/////////////////////////////////////////////////////////////////////////////////////////



#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */


/////////////////////////////////////////////////////////////////////////////////////////
//	INITIALIZATION
/////////////////////////////////////////////////////////////////////////////////////////
/** 
	The function initializes the Tech5_ClientEdition
	Parameters:
	sdk (output)   - pointer of handle of Tech5_ClientEdition
	cores_count(input) - count of cores used for image processing (if applicable)
	Return value:
	The function returns SE_OK if success and error code otherwise
*/
int initSDK(TECH5_CLIENT* sdk, int cores_count = 1);

/** 
	The function uninitializes the Tech5_ClientEdition
	Parameters:
	sdk (input)   - pointer of handle of Tech5_ClientEdition
*/
void closeSDK(TECH5_CLIENT* sdk);

/////////////////////////////////////////////////////////////////////////////////////////
//	GET AND SET PARAMETERS 
/////////////////////////////////////////////////////////////////////////////////////////
/**
	The function sets search parameters
	NOTE: this change will be valid until you unload Tech5SDK dll. If you want to make 
	this changers persistent you should set these parameters in Windows Control Panel
	Parameters:
	sdk    (input)   - handle of Tech5_ClientEdition
	params (input)   - the pointer to structure with the new search parameters
	Return value:
	The function returns SE_OK if success and error code otherwise
*/
int setSearchParams (TECH5_CLIENT sdk, const SearchParams* params);

/**
	The function returns pointer to structure with current search parameters
	Parameters:
	sdk    (input)   - handle of Tech5_ClientEdition
*/
const SearchParams* getSearchParams (TECH5_CLIENT sdk);

/**
	The function sets license data
	Parameters:
	hSdk  (input)   - handle of Tech5_ClientEdition
	license_data (input)   - the data for checking of product legality
	extra_data (input) - the additional data. Must be NULL if unused.
	Return value:
	The function returns SE_OK if success and error code otherwise
*/
int setLicense(TECH5_CLIENT hSdk, const char* license_data, int* extra_data = 0);


/////////////////////////////////////////////////////////////////////////////////////////
//	PROSESS
/////////////////////////////////////////////////////////////////////////////////////////
/**
	Processes the fingerprint image and build the tech5 template. Finger position is FINGPOS_RT.
	Parameters:
	sdk       (input)    -	handle of Tech5_ClientEdition
	dib_image (input)    -	image structure that contains information about fingerprint
							NOTE: image should be uncompressed, 256 gray-level(8 bit per pixel),
							top-down and 500 dpi
   finger     (input)   - finger position
	fpTemplate(output)   - the buffer that receives the built template
 						   Memory for that buffer should be previously allocated by 
						   'allocateTemplate' function
	templSize (output)   - this variable receives the size of built template
	quality   (output)   - this variable receives the quality of fingerprint image
	maxWidth, maxHeight  - if this parameters > 0 and source image have size bigger than these
		                      values, then source image will cut to this size(input)
	Return Values:
	function returns SE_OK - if function succeeds, error code - otherwise
*/	
int create_Template_Tech5 (TECH5_CLIENT sdk, unsigned char* dib_image, FINGERS finger, unsigned char* fpTemplate,unsigned int* templSize, 
         unsigned char* quality, unsigned int maxWidth = MAX_WIDTH, 
         unsigned int maxHeight = MAX_HEIGHT);

/**
	Processes the fingerprint image and build the Tech5 template.
	Parameters:
	sdk       (input)    -	handle of Tech5_ClientEdition
	dib_image (input)    -	DIBImage structure that contains information about fingerprint
							NOTE: image should be uncompressed, 256 gray-level(8 bit per pixel),
							top-down and 500 dpi
	fpTemplate(output)   - the buffer that receives the built template
 						   Memory for that buffer should be previously allocated by 
						   'allocateTemplate' function
	templSize (output)   - this variable receives the size of built template
	quality   (output)   - this variable receives the quality of fingerprint image
	maxWidth, maxHeight  - if this parameters > 0 and source image have size bigger than these
		                      values, then source image will cut to this size(input)
	Return Values:
	function returns SE_OK - if function succeeds, error code - otherwise
*/	
int create_Template_Tech5Ex (TECH5_CLIENT sdk, DIBImage dib_image, unsigned char* fpTemplate,unsigned int* templSize, 
         unsigned char* quality, unsigned int maxWidth = MAX_WIDTH, 
         unsigned int maxHeight = MAX_HEIGHT);

/**
   The function takes set of images as input and outputs the corresponding ANSI INCITS 378 
   compliant template. 
   Parameters:
	sdk             (input) :	handle of Tech5_ClientEdition
   numFingers      (input) :	number of source images
   dibImage        (input) :	array of image structure, that contains information
							         about source fingerprint images 
							         NOTE: image should be uncompressed, 256 gray-level(8 bit per pixel),
							         top-down and 500 dpi
   templ           (output):	The processed ANSI INCITS 378 compliant template.
	         						The memory for the template should be allocated by 'allocateNISTtemplate' function
   quality			(output):	Array of quality of images in template
   templ_size		(output):	size of created template in bytes
   maxTemplateSize (input):	the maximum size of template. If size of template is more than this value,
                              then some of minutiae will be eliminated from template to satisfy this parameter.
                              If it's 0, then all minutiae will be put into template.
   certifiedSensor (input) :	is capture_Equipment comply with IQS (EFTS, Appendix F)?
   sensorID        (input) :	Capture Equipment ID. The vendor determines the value for this field.
	         						Applications developers may obtain the values for these codes from the vendor.
   Return value:
   The function returns SE_OK if success and error code otherwise. 
   In case of failure the null template will be output.
*/
int create_Template_NIST (TECH5_CLIENT sdk, unsigned int numFingers, DIBImage* dibImage, 
									unsigned char* templ, unsigned char* quality, int* templ_size, int maxTemplateSize = 0, bool certifiedSensor = false, unsigned short sensorID = 0);

/**
   The function takes set of images as input and outputs the corresponding ISO 19794-2 
   compliant template. 
   Parameters:
	sdk             (input) :	handle of Tech5_ClientEdition
   numFingers      (input) :	number of source images
   dibImage        (input) :	array of image structure, that contains information
      							   about source fingerprint images
		      					   NOTE: image should be uncompressed, 256 gray-level(8 bit per pixel),
				      			   top-down and 500 dpi
   templ           (output):	The processed  ISO 19794-2 compliant template.
						      	   The memory for the template should be allocated by 'allocateISOtemplate' function
   quality			(output):	Array of quality of images in template
   templ_size		(output):	size of created template in bytes
   maxTemplateSize (input):	the maximum size of template. If size of template is more than this value,
                              then some of minutiae will be eliminated from template to satisfy this parameter.
                              If it's 0, then all minutiae will be put into template.
   certifiedSensor (input) :	is capture_Equipment comply with IQS (EFTS, Appendix F)?
   sensorID        (input) :	Capture Equipment ID. The vendor determines the value for this field.
							         Applications developers may obtain the values for these codes from the vendor. 
   Return value:
   The function returns SE_OK if success and error code otherwise. 
   In case of failure the null template will be output.
*/
int create_Template_ISO (TECH5_CLIENT sdk, unsigned int numFingers, DIBImage* dibImage, 
								   unsigned char* templ, unsigned char* quality, int* templ_size, int maxTemplateSize = 0, bool certifiedSensor = false, unsigned short sensorID = 0);


/////////////////////////////////////////////////////////////////////////////////////////
//	MATCH
/////////////////////////////////////////////////////////////////////////////////////////
/**
	Compares two templates
	Parameters:
	sdk        (input)  - handle of Tech5_ClientEdition
	fpTempl1   (input)  - the first fingerprint template
	fpTempl2   (input)  - the second fingerprint template
	similarity (output) - this variable receives the value that shows 
				         how two fingerprints similarity one to other in percent
	Return value:
	The function returns SE_OK if success and error code otherwise
*/
int match_Templates_Tech5(TECH5_CLIENT sdk, const unsigned char* fpTempl1, const unsigned char* fpTempl2, unsigned char* similarity);

/**
	Next two functions have the same functionality as 'match' function but 
	allows you to perform the 1:many search more quickly.
	At first you should call 'loadTemplate' function for loading the first template
	and then call 'matchEx' function for match with each of second templates
	Parameters:
	sdk        (input)  - handle of Tech5_ClientEdition
	fpTempl1   (input)  - the first fingerprint template
	fpTempl2   (input)  - the second fingerprint template
	similarity (output) - this variable receives the value that shows 
				         how two fingerprints similarity one to other in percent
	Return value:
	The function returns SE_OK if success and error code otherwise
*/
int loadTemplate_Tech5(TECH5_CLIENT sdk, const unsigned char* fpTempl1);
int match_Templates_Tech5Ex(TECH5_CLIENT sdk, const unsigned char* fpTempl2, unsigned char* similarity);


/**
   The function compares two ANSI INCITS 378 compliant templates and outputs a match score. 
   Parameters:
	sdk              (input) :	handle of Tech5_ClientEdition
   probeTemplate    (input) : the first  ANSI INCITS 378 compliant template
   galleryTemplate  (input) : the second ANSI INCITS 378 compliant template
   score            (output): a similarity score resulting from comparison of the templates.   
   Return value:
   The function returns SE_OK if success and error code otherwise. 
   NOTE: At this version of software templates (probeTemplate and galleryTemplate) can keeps information about 
         two fingers
*/
int match_Templates_NIST (TECH5_CLIENT sdk, const unsigned char* probeTemplate, const unsigned char* galleryTemplate, unsigned char* score);

/**
   The function compares two ISO 19794-2 compliant templates and outputs a match score. 
   Parameters:
	sdk              (input) :	handle of Tech5_ClientEdition
   probeTemplate    (input) : the first ISO 19794-2 compliant template
   galleryTemplate  (input) : the second ISO 19794-2 compliant template
   score            (output): a similarity score resulting from comparison of the templates.   
   Return value:
   The function returns SE_OK if success and error code otherwise. 
   NOTE: At this version of software templates (probeTemplate and galleryTemplate) can keeps information about 
         two fingers
   */
int match_Templates_ISO (TECH5_CLIENT sdk, const unsigned char* probeTemplate, const unsigned char* galleryTemplate, unsigned char* score);

/**
   The function compares Tech5 and ANSI INCITS 378 compliant templates and outputs a match score. 
   Parameters:
	sdk             (input)  :	handle of Tech5_ClientEdition
   templateTech5    (input) : the Tech5 template
   templateNIS   T  (input) : the second ANSI INCITS 378 compliant template
   score            (output): a similarity score resulting from comparison of the templates.   
   Return value:
   The function returns SE_OK if success and error code otherwise. 
*/
int match_Tech5_NIST(TECH5_CLIENT sdk, const unsigned char* templateTech5, const unsigned char* templateNIST, unsigned char* score);
/**
   The function compares Tech5 and ISO 19794-2 compliant templates and outputs a match score. 
   Parameters:
	sdk              (input) :	handle of Tech5_ClientEdition
   templateTech5    (input) : the Tech5 template
   galleryISO       (input) : the second ISO 19794-2 compliant template
   score           (output) : a similarity score resulting from comparison of the templates.   
   Return value:
   The function returns SE_OK if success and error code otherwise. 
*/
int match_Tech5_ISO(TECH5_CLIENT sdk, const unsigned char* templateTech5, const unsigned char* templateISO, unsigned char* score);

/////////////////////////////////////////////////////////////////////////////////////////
//	TOOLS
/////////////////////////////////////////////////////////////////////////////////////////
/**
	function returns error description by its number
	Parameters:
	sdk    (input)   - handle of Tech5_ClientEdition
	Return value:
	The last error descriptions
*/
 
const char* getLastErrorMsg (TECH5_CLIENT sdk);

/**
	saves captured image to BMP file
	Parameters:
	sdk      (input) - handle of Tech5_ClientEdition
	filename (input) - output file name 
	dib      (input) - pointer to the DIB, that is returned by capture functions 
	Return value:
	The function returns SE_OK if success and error code otherwise
*/
int save2Bmp(TECH5_CLIENT sdk, const char* filename, const unsigned char* dib);

/**
	The function reads BMP file and put image to dib buffer
	If the image resolution is not set in bitmap header, then it set to 500 DPI
	Parameters:
	sdk       (input)        - handle of Tech5_ClientEdition
	filename  (input)        - input file name (input)
	size      (input-output) - before the function call this variable should contains the 
	                           size the buffer pointed by dib. After call it contains the 
							         real size of data copied to dib.
	dib       (output)	     - pointer to the buffer that receives the fingerprint image
							         Memory for that buffer should be allocated in application										
	Return value:
	The function returns SE_OK if success and error code otherwise
*/
int readBmp (TECH5_CLIENT sdk, const char* filename, unsigned int* size, unsigned char* dib);

/**
	The function reads BMP memory buffer and put image to dib buffer
	If the image resolution is not set in bitmap header, then it set to 500 DPI
	Parameters:
	sdk                (input) - handle of Tech5_ClientEdition
	bitmap_buffer      (input) - input bitmap memory buffer (input)
	bitmap_buffer_size (input)	- length of bitmap buffer in bytes
	size        (input-output) - before the function call this variable should contains the 
	                              size the buffer pointed by dib. After call it contains the 
							            real size of data copied to dib.
	dib               (output)	- pointer to the buffer that receives the fingerprint image
							           Memory for that buffer should be allocated in application										
	Return value:
	The function returns SE_OK if success and error code otherwise
*/
int readBmpEx (TECH5_CLIENT sdk, const unsigned char* bitmap_buffer, unsigned int bitmap_buffer_size, unsigned int* size, unsigned char* dib);

/**
	saves captured image to WSQ file
	Parameters:
	sdk            (input) - handle of Tech5_ClientEdition
	filename       (input) - output file name 
	dib            (input) - pointer to the DIB, that is returned by capture functions
	compressionRate (input) - compression image coefficient
	Return value:
	The function returns SE_OK if success and error code otherwise
*/
int save2Wsq(TECH5_CLIENT sdk, const char* filename, const unsigned char* dib, float compressionRate = 15.0f);

/**
	saves captured image to WSQ memory buffer
	Parameters:
	sdk             (input) - handle of Tech5_ClientEdition
	wsq_buffer     (output) - output buffer 
	wsq_size       (output) - if success contains the real size of data copied to wsq_buffer
	dib             (input) - pointer to the DIB, that is returned by capture functions
	compressionRate (input) - compression image coefficient
	Return value:
	The function returns SE_OK if success and error code otherwise
*/
int save2WsqEx(TECH5_CLIENT sdk, unsigned char* wsq_buffer, unsigned int *wsq_size, const unsigned char* dib, float compressionRate = 15.0f);

/**
	The function reads WSQ file and puts image to dib buffer
	If the image resolution is not set in bitmap header, then it set to 500 DPI
	Parameters:
	sdk       (input)        - handle of Tech5_ClientEdition
	filename  (input)        - input file name (input)
	size      (input-output) - before the function call this variable should contains the 
	                           size the buffer pointed by dib. After call it contains the 
							         real size of data copied to dib.
	dib       (output)	    - pointer to the buffer that receives the fingerprint image
							         Memory for that buffer should be allocated in application										
	Return value:
	The function returns SE_OK if success and error code otherwise
*/
int readWsq (TECH5_CLIENT sdk, const char* filename, unsigned int* size, unsigned char* dib);


/**
	The function reads WSQ from memory buffer and puts image to dib buffer
	If the image resolution is not set in bitmap header, then it set to 500 DPI
	Parameters:
	sdk               (input) - handle of Tech5_ClientEdition
	wsq_buffer        (input) - input wsq image buffer (input)
	wsq_buffer_size   (input) - length of wsq_buffer in bytes
	size       (input-output) - before the function call this variable should contains the 
	                            size the buffer pointed by dib. After call it contains the 
							          real size of data copied to dib.
	dib       (output)	     - pointer to the buffer that receives the fingerprint image
							          Memory for that buffer should be allocated in application										
	Return value:
	The function returns SE_OK if success and error code otherwise
*/
int readWsqEx (TECH5_CLIENT sdk, const unsigned char* wsq_buffer, unsigned int wsq_buffer_size, unsigned int* size, unsigned char* dib);


/**
	The function allocates memory for template variable
	Parameters:
	sdk        (input) - handle of Tech5_ClientEdition
	fpTempalte (input) - buffer for fingerprint template
	Return value:
	The function returns SE_OK if success and error code otherwise
*/
int allocate_Template_Tech5 (TECH5_CLIENT sdk, unsigned char** fpTemplate);

/**
   The function allocates memory for buffer that will receives INCITS 378 compliance template
   Parameters:
	sdk             (input) : handle of Tech5_ClientEdition
   numFingers      (input) : number of fingers informations about those will be put into template
                              (one view per finger). Should be not more than MAX_FINGERS   
                              NOTE: At this version of software template can keeps information about up to two fingers.
   nistTempl  (input/output): buffer for INCITS 378 compliance template
   Return value:
   The function returns SE_OK if success and error code otherwise. 
*/
int allocate_Template_NIST (TECH5_CLIENT sdk, unsigned int numFingers, unsigned char** nistTempl);

/**
   The function allocates memory for buffer that will receives ISO 19794-2 compliance template
   Parameters:
	sdk             (input) : handle of Tech5_ClientEdition
   numFingers     (input)  : number of fingers informations about those will be put into template
                              (one view per finger). Should be not more than MAX_FINGERS   
                              NOTE: At this version of software template can keeps information about up to two fingers.
   isoTempl  (input/output): buffer for ISO 19794-2 compliance template
   Return value:
   The function returns SE_OK if success and error code otherwise. 
   NOTE: At this version of software template can keeps information about up to two fingers
*/
int allocate_Template_ISO (TECH5_CLIENT sdk, unsigned int numFingers, unsigned char** isoTempl);
/**
   The function free memory that was allocated by 'allocate_Template_Tech5' function
   Parameters:
   sdk        (input) - handle of Tech5_ClientEdition
   fpTempalte (input) - buffer for fingerprint template
   Return value:
   The function returns SE_OK if success and error code otherwise
*/
int free_Template_Tech5 (TECH5_CLIENT sdk, unsigned char** fpTemplate);
/**
   The function frees memory that was allocated by one of 'allocate_Template_NIST' function
   Parameters:
   templ (input) - buffer for template
   Return value:
   The function returns SE_OK if success and error code otherwise. 
*/
int free_Template_NIST (TECH5_CLIENT sdk, unsigned char** templ);
/**
   The function frees memory that was allocated by one of 'allocate_Template_ISO' function
   Parameters:
   templ (input) - buffer for template
   Return value:
   The function returns SE_OK if success and error code otherwise. 
*/
int free_Template_ISO (TECH5_CLIENT sdk, unsigned char** templ);


#ifdef __cplusplus
}  //extern "C"
#endif  /* __cplusplus */

#endif //TECH5_CLIENT_EDITION_H_