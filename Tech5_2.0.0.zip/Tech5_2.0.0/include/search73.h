/**************************************
            Search.h 
    Definitions for compatible.

	    Author Gudkov V.U.
***************************************/

//	Workspace definition
#include		"wizard73.h"
#include		"virtue73.h"
#include		"inline73.h"

//	Sentry
#if !defined (__SEARCH_73_H)
	#define __SEARCH_73_H

#ifdef __cplusplus
namespace wizard73{
#endif  


	//	Tutor common definitions
	#define	SPACE			32768					//random space
	#define	TRAIN			100					//limited training of...
	#define	PSIZE			999					//
	#define	PARAM			4						//
	#define	TABLE			256					//

	//	Search common definitions
	#define	LLINE			2048					//size buffer
	#define	NESTS			MAXPAL				//minutiaes
	#define	PRESS			10000					//estimation pressing
	#define	_LAY_			36						//watch not more fragments
	#define	_VIR_			1						//candidates on the link
	#define	_DEV_			254					//interior of a fragment
	#define	_CAN_			3						//candidates for the nest
	#define	_KEY_			(NESTS*_CAN_)		//key positions
	#define	_MUL_			128					//scale coefficient
	#define	_DAT_			256					//size of knowledge
	#define	_HYP_			2						//length of hyper-arch

	//-------------------------------------
	//	Enumerator type for errors
	//-------------------------------------
	enum
	{
		ISSKIP = -1,								//skipping
		NOINDI = -2,								//ruined indignations
		NONEST = -3,								//ruined minutiaes
		NOABAC = -4,								//ruined ridge count
		NOLINK = -5,								//ruined linkages
		NOAREA = -6,								//ruined regions
		NOLAYS = -7,								//nothing variant
		NOHORI = -8,								//poor horizont
		NODATA = -9									//ruined common data
	};

	//packing alignment 
#ifdef _WINDOWS
	#pragma	pack( 1 )
#endif

	/**************************************
			Declarations of structures
	**************************************/

	//	Geometrical data
	struct P_PACKED_1 SEA_EI SGeom
	{
		byte		Type;								//type
		uint		Azim;								//turn to azimuth
		uint		Beta;								//turn to beta
		uint		Size;								//distance
	};

	/***********************************
			Virtue nest of minutiae
	***********************************/
	struct P_PACKED_1 SEA_EI CNest
	{
            int   Movx,								//x position
	          Movy;								//y position
            byte  Type,								//type
                  Lace,								//scale
                  Prob,								//probability
                  Beta;								//beta
            byte  Look,								//look
                  Curl;								//curvature

            //kernal of nest
            SGeom   Geom[_IND_];					//geometrical tether
            CNest*  Tree[_VIR_]						//tree for the nests
                        [_LIN_];
            byte    Deal[_VIR_]						//event
			[_LIN_],
                    Pink[_VIR_]						//pink
                        [_LIN_];
            word    Item[_VIR_]						//item
                        [_LIN_],
                    Size[_VIR_]						//distance
                        [_LIN_],
                    Fine[_VIR_]						//fine
                        [_LIN_];
            byte    Abac[_IND_];					//ridge count
					
            CNest*  Trap;								//trap for tree
            byte    Prox,								//proximity
                    Harm,								//image density
                    Qual,								//image quality
                    Wnet,								//wide of net
                    Gene;								//real indignations
            int     Nord;								//number

	};//CNest

	/***********************************
				Path of track
	***********************************/

	//	Candidate structure
	struct P_PACKED_1 SEA_EI CCand
	{
		CNest	  *CapI,								//icon capture
				  *CapT;								//test capture
		char	  *Kind;								//kind of transformation
		int		Simi;								//similarity
	};

	//	Native pairs
	struct P_PACKED_1 SEA_EI CPair
	{
		short		Icon,								//icon minutiae
					Test;								//test minutiae
	};

#ifdef _WINDOWS
	#pragma	pack( 4 )
#endif

	/***********************************
		Declaration of Comer class
	***********************************/
	class P_PACKED_4 SEA_EI Comer
	{

	private://decode system of sign
		int		DeAbac	(byte  *src);		//decode ridge count
		int		DeIndi	(byte  *src);		//decode indignations
		int		DeNest	(byte	 *src);		//decode nests
		int		DeLink	(byte  *src,		//decode
								 byte	 tree = 00);//linkages
		int		DeArea	(byte	 *dst,		//decode
								 byte	 *src);		//regions

	private://build synthetic data
		void		Ground	(void);				//preparation
		void		Tether	(void);				//indignation tether
		void		Steady	(void);				//define stability

	public://load data
		int		Loader	(byte  *src,		//load
								 byte	 type = 00);//all data
		int		DeCode	(byte	 *dst,		//load
								 byte	 *src,		//only
								 byte	 tree = 00);//quick data
		int		DeCase	(byte	 *dst,		//load
								 byte	 *src,		//part of
								 byte	 tree = 00,	//quick
								 byte	 type = 00);//data
	public://class common data
		int		What;								//errors
		uint		Nmin,								//minutiaes quantity
					Nind;								//indignations quantity

//JRM 11-11-05 : must make these public so that Template Viewer code can access them:
//{{
	public:
	//private://class internal data
		uint		Nlin,								//bytes quantity
					Nbit,								//bits quantity
					Ncod,								//dimension
					Reax,								//size x
					Reay;								//size y
		byte	  *Buff;	
		byte		Mask,								//image mask
					Type,								//image type
					Harm,								//image harmon	
					Qual,								//image quality
					Deep;								//deep section
//}}

	public://data classes
		CNest		Nest[NESTS];					//the nests
		SSign		Indi[_IND_];					//the indignations

	};//Comer

	/***********************************
			Declaration of Graph class
	***********************************/
	class P_PACKED_4 SEA_EI Graph
	{

	public://load data
		inline
		void		Loader	(CCand &src);		//load one duke
		inline
		void		Resets	(int	 size);		//prepare

	public://trajectory data
		int		Lose,								//lose quantity
					Tail,								//tail of list
					Head;								//head of list

	public://trajectory data
		byte		Free[NESTS];					//nest signatures
		CCand		Cand[_DEV_];					//development

	};//Graph

	/***********************************
			Declaration of CArch class
	***********************************/
	class P_PACKED_4 SEA_EI CArch
	{

	protected://simple inline functions
		inline
		word		TbFine	(int	 item);		//get table penalty
		inline
		word		TbFine	(char	 *tab);		//get table penalty

	private://interface for <Isomer>
		void		Resets	(char  *tab,		//prepare nests
								 CNest *dst,
								 CNest *src);
		void		MuArch	(char	 *tab,		//extend multi-arch
								 CNest *net,
								 word	 link,
								 byte	 even,
								 word	 fine);
		void		MuArch	(char  *tab,		//build multi-arches
								 CNest *dst,
								 CNest *src);
		void		HyArch	(CNest *src,		//hyper-arch recursion
								 word	 link,
								 word	 next,
								 word	 fine);
		void		HyArch	(CNest *src,		//trace one hyper-arch
								 word	 link,
								 word	 fine);
		void		HyArch	(char	 *tab,		//build hyper-arches
								 CNest *dst,
								 CNest *src);
		void		Conque	(CNest *src,		//add one conquer
								 word	 link,
								 word	 next,
								 word	 fine);
		void		Conque	(char	 *tab,		//build conquer events
								 CNest *dst,
								 CNest *src);
		void		Across	(CNest *net,		//add one cross
								 word	 link,
								 word	 from,
								 byte	 even,
								 word	 fine);
		void		Across	(char	 *tab,		//rebuild if crossing
								 CNest *dst,
								 CNest *src);

	protected://kernal of isomorphism
		void		Isomer	(char	 *tab,		//prove isomorphism
								 CNest *dst,
								 CNest *src);

	protected://kernal of isomorphism
		CNest*	Root;								//temporary root
		int		Disp,								//displacement
					Narc,								//arch quantity
					Apex[_HYP_];					//loop for hyper-arch

	};//CArch

	/***********************************
			Declaration of CKnow class
	***********************************/
	class P_PACKED_4 SEA_EI CKnow : public CArch
	{

	private://simple inline functions
		inline
		int		Native	(int	 dstn,		//if the same source
								 int	 srcn);

	private://isomorphism for <ExNest>
		int		Branch	(char	 *tab,		//evaluate branch
								 int	 link,
								 CNest *dst,
								 CNest *src);
		int		Branch	(char	 *tab,		//evaluate all branches
								 CNest *dst,
								 CNest *src);
	protected:
		void		ExNest	(char	 *tab,		//switching examination	
								 CNest *dst,
								 CNest *src,
								 CCand *can);
		void		ExNest	(CNest *dst,		//nest examination
								 CNest *src,
								 CCand *can);
		int		Expres	(CNest *dst,		//express recognition
								 CNest *src);

	private://matching subcontrol
		int		Insert	(Graph *lay);		//try insert candidate
		int		Splits	(Graph *lay);		//split the nest
		int		Survey	(Graph *lay);		//build gradient



		void		Select	(void);				//select trajectory	

	public://matching control
		int		Expres	(void);				//express estimation
		void		Reduce	(void);				//coherent candidates list
		void		Source	(void);				//free candidates list
		void		Tender	(void);				//cutoff candidates
		void		Gusher	(void);				//fragment gusher
		void		Growth	(void);				//develop fragments
		int		Search	(int	 goal);		//search kernal

	public://main search function
		int		Loader	(byte	 *src);		//load query
		int		Search	(byte	 *dst);		//main search
		int		Native	(CPair *dst);		//native pairs

	public://data to recognize pattern
		int		Tail,								//start of list
					Head,								//end of list of CCand
					Goal,								//pattern reply
					Mark,								//best estimate
					Gold,								//best index
					Time,								//time of execution
					Elim,								//elimination
					Ncan,								//quantity of candidates 
					Hori,								//horizont
					Over,								//minutiae overflow
					Lays,								//quantity of lays
					What,								//errors
					View[_LAY_];					//graph estimates
		Graph		Duke[_LAY_];					//fragments list
		CCand		Cand[_KEY_];					//list of candidates
		Comer		Test;								//test object
		Comer		Icon;								//icon object

	};//CKnow

	/***********************************
			Declaration of Coach class
	***********************************/
	class P_PACKED_4 SEA_EI Coach : public CKnow					  
	{

	private://translate knowledges
		int		Amatch	(char	 *dst);		//match strings
		int		Smatch	(char	 *src);		//simple match
		int		Astreq	(char	 *dst,		//strings equal on a dot
								 char	 *src);
		int		Sstreq	(char	 *dst,		//strings equal
								 char	 *src);
		int		Number	(void);				//get digit
		char		ThisCh	(void);				//get character
		char		NextCh	(void);				//advance character
		void		Blanks	(void);				//skip blanks

	public://function to assemble <Parser>
		void		Killer	(void);				//prepare buffer
		int		Parser	(void);				//parse knowledges

	public://signed random function
		int		Random	(void);				//signed value
		int		Random	(word	 *dst,
								 word	 *src,
								 int	 inum,		//random parameter
								 int	 iter);
		int		Random	(int	 expr);

	public://histogram function
		void		Resets	(void);				//reset the rank...

	public://measure quality
		int		QuPath	(int	 size);		//best path
		int		ATrust	(CCand *src, 		//reliability
								 int	 size);
		int		ATrust	(int	 tnum,		//prove native pair
								 int	 inum);
		int		Voting	(int	 sure);		//voiting
		int		Method	(int	 some);		//method of work

	public://print diagnostic data
//		void		PrList	(char	 *str);		//list of candidates
//		void		PrPath	(char	 *str);		//path document
//		void		PrTune	(char	 *str,		//store knowledges
	//								 word  *buf);
//		void		PrNest	(char	 *str,		//print nests
//								 char	 *tab,
//								 CNest *dst,
//								 CNest *src);

	public://mentor partition
//		void		Expres	(char	 *str);		//<Expres> tutor
//		void		Reduce	(char	 *str);		//<Reduce> tutor
//		void		Source	(char	 *str);		//<Source> tutor
//		void		Tender	(char	 *str);		//<Tender> tutor
//		void		Growth	(char	 *str);		//<Growth> tutor
		
		void		Tutor		(char	 *out,
								 char	 *str);
		void		Scaner	(char	 *out,		//scan directories
								 char	 *dst,
								 char	 *src,
								 char	 *mod);

		//list of points for model
		int		Lend,								//end of buffer
					Pair,								//native pairs
					Lptr,								//current position
					Pran,								//success random
					Qran,								//failure random
					Rank[PARAM]						//histogram
						 [PSIZE];
		word		Data[TABLE];
		char		Line[LLINE];					//line to parse
		short		Inum[NESTS],					//icon poiny number
					Tnum[NESTS];					//the nests

	};//Coach

	//defualt alignment 
#ifdef _WINDOWS
	#pragma	pack()
#endif
/**************************************
				Get penalty
**************************************/

//	Set fine from table of knowledge
inline word	CArch::TbFine( int item )
{
	return TabDat[ Disp+item ];
}

//	Set fine from table of knowledge
inline word	CArch::TbFine( char *tab )
{
	if (tab == TabNot)	
		return  TbFine(23);
	else
	if (tab == TabBbr ||
		 tab == TabBbl ||	
		 tab == TabEcr ||
		 tab == TabEcl)
		return  TbFine(24);
	else
		return  TbFine(25);
}

/**************************************
	Graph: Full and partial loading
**************************************/

//	Load start of fragment
inline void	Graph::Loader( CCand &src )
{
	Cand[Tail = 0] = src;
		  Head = 1;
		  Lose = 0;
}

//	Load start of fragment
inline void	Graph::Resets( int size )
{
	ResDst( Free,size );
}



#ifdef __cplusplus
} // namespace wizard73{
#endif  

#endif	//__SEARCH_H
