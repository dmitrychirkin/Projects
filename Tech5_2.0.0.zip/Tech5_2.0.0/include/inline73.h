/**************************************
				Inline.h
	Common small usefull functions.

		   Author Gudkov V.U.
***************************************/

//	Header project file
#include		"typdef73.h"

// Sentry
#if !defined (__INLINE_73_H)
	#define __INLINE_73_H

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

	//-------------------------------------
	//		Helpfull copy functions
	//-------------------------------------

	//	String copy and return destination
	template <class T>
	inline	T *StrDst( T *dst,T *src,int len )
	{
		while (len--) *dst++ = *src++; return	dst;
	}

	//	String copy and return source
	template <class T>
	inline	T *StrSrc( T *dst,T *src,int len )
	{
		while (len--) *dst++ = *src++; return	src;
	}

	//	Constant string copy [0..fin]
	template <class T>
	inline void StrCop( T *dst,T *src,int fin )
	{
		for (;fin >= 0; fin--) dst[fin] = src[fin];
	}

	//-------------------------------------
	//	Quick prepare any memory
	//-------------------------------------

	//	Reset memory
	template <class T>
	inline void ResDst( T *dst,int len,T val = 0x00 )
	{
		while (len) dst[--len] = val;
	}

	//	Upset memory
	template <class T>
	inline void SetDst( T *dst,int len,T val = 0xff )
	{
		while (len) dst[--len] = val;
	}

	//-------------------------------------
	//	Read string length in first four bytes
	//-------------------------------------

	//	Read size of string
	inline void ReadSz( byte *src,int &len )
	{
		len = 0;//see 4 byte in src
		for (int i = 0; i < 4; i++)
		{
			len+= src[i] << (i << 3);
		}
	}

	//	Save size of string
	inline void SaveSz( byte *dst,int  len )
	{
		//write first 4 byte in dst
		for (int i = 0; i < 4; i++) 
		{
			dst[i] = len >> (i << 3);
		}
	}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */

#endif

