#ifndef TECH5_DATA_TYPES
#define TECH5_DATA_TYPES	0x01

#ifdef __cplusplus

#if (defined _WIN64) || (defined WIN64)
#ifndef ARCH_64
#define ARCH_64
#endif
#endif 

#ifdef ARCH_64	// 64-bit operating system

typedef	bool				snd_bool;

typedef	char				snd_char;
typedef	wchar_t				snd_wchar;
typedef unsigned char		snd_byte;
typedef unsigned char		snd_uchar;

typedef	short				snd_short;
typedef unsigned short		snd_ushort;

typedef	int					snd_int;
typedef unsigned int		snd_uint;

typedef int					snd_long;
typedef	unsigned int		snd_ulong;

typedef long long			snd_long_long;
typedef	unsigned long long	snd_ulong_long;

typedef	float				snd_float;
typedef double				snd_double;

#else	// 32-bit operating system

typedef	bool				snd_bool;

typedef	char				snd_char;
typedef	wchar_t				snd_wchar;
typedef unsigned char		snd_byte;
typedef unsigned char		snd_uchar;

typedef	short				snd_short;
typedef unsigned short		snd_ushort;

typedef	int					snd_int;
typedef unsigned int		snd_uint;

typedef int					snd_long;
typedef	unsigned int		snd_ulong;

typedef long long			snd_long_long;
typedef	unsigned long long	snd_ulong_long;

typedef	float				snd_float;
typedef double				snd_double;

#endif	// ARCH_32

#else	// __cplusplus not defined

#ifdef ARCH_64	// 64-bit operating system

typedef	int					snd_bool;

typedef	char				snd_char;
typedef unsigned char		snd_byte;
typedef unsigned char		snd_uchar;

typedef	short				snd_short;
typedef unsigned short		snd_ushort;

typedef	int					snd_int;
typedef unsigned int		snd_uint;

typedef int					snd_long;
typedef	unsigned int		snd_ulong;

typedef long long			snd_long_long;
typedef	unsigned long long	snd_ulong_long;

typedef	float				snd_float;
typedef double				snd_double;

#else	// 32-bit operating system

typedef	int					snd_bool;

typedef	char				snd_char;
typedef unsigned char		snd_byte;
typedef unsigned char		snd_uchar;

typedef	short				snd_short;
typedef unsigned short		snd_ushort;

typedef	int					snd_int;
typedef unsigned int		snd_uint;

typedef int					snd_long;
typedef	unsigned int		snd_ulong;

typedef long long			snd_long_long;
typedef	unsigned long long	snd_ulong_long;

typedef	float				snd_float;
typedef double				snd_double;

#endif	// ARCH_32


#endif	//	__cplusplus

#endif	// TECH5_DATA_TYPES