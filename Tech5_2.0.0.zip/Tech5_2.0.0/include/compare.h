/*****************************************************************************
	compare.h - header file for one to one finger matching algorithm of Core Matching SDK

	The Core Matching SDK is the high-level tool, intended for easy creating
    of your own scalable biometric applications that use the person's fingerprint 
	for identification or verification purpose. 

******************************************************************************
	
	Copyright (C) 2005 Sonda Technologies Ltd.
	
	Version 1.1.0 of 14.05.2005
	    
*******************************************************************************/
 
#ifndef COMPARE_H__
#define COMPARE_H__

#include "ma.h"


/******************************************************************
          Compare class
******************************************************************/
class Compar;

class Compare
{
   Compar               *m_compar;        
   BYTE                 *m_templ[10];
   bool                  m_isProbeLoaded;  
   bool                  m_init;  

public:
   Compare();
	~Compare();

 	// allocate memory for template
	static int allocateTemplate(BYTE *&templ);
	// free memory that was earlier allocate by 'allocateTemplate' function
	static int freeTemplate(BYTE *&templ);

	/* 
	 Initialize work with Compare class functions
	 This function should be called  before call any other function of this class
	 Function returns MA_OK - if function succeeds, error code - otherwise
	*/
	int init();
   /* 
      Initialize work with Compare class
      In differ from 'init' function it take the protection data
      This function (of 'init' function)should be called first before call 
      any other function
      Parameters:
      protect                 (input) - pointer to 512 byte buffer with protection data
      Return value:
      The function returns MA_OK - if function succeeds, error code - otherwise
   */
   int initEx(BYTE protect[MAX_PROTECT_LEN]);
	/*
	Load set of fingerprint templates for future using in 'matxhEx' function
	function returns MA_OK - if function succeeds, error code - otherwise
	numFingers - number of templates in templSet array (input)
	templSet1  - set of fingerprint templates for loading (input)
	*/
	int loadTemplate(unsigned int numFingers, TemplateData templSet[]);
	/*
	Compare fingerprint template with corresponded finger from set of templates
	that was earlier load by 'loadTemplate' function 
	function returns MA_OK - if function succeeds, error code - otherwise
	param       (input)  - the search parameters
                          NOTE: because finger is not known, it uses maxAngle (not maxAngleThumb)
                          for angle tolerance
	templG      (input)  - gallery template for matching 
   finger      (input)  - finger position 
	similarity  (output) - variable that receives the value that shows 
				              how two fingerprints similarity one to other in a range 0...MAX_SCORE
	matchResult (output) - the structure with match result details. 
                          If is is NULL, it not used.
	*/
	int	matchEx (SearchParam &param, BYTE *templG, FINGERS finger, int &similarity, MatchResult *matchResult);

};

#endif // COMPARE_H__



