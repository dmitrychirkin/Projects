/*****************************************************************************
   SondaAfisSDK.h - the main header file for Sonda AFIS SDK

   The Sonda AFIS SDK is the high-level tool, intended for easy creating of your
   own biometric applications both for civil or police applications

******************************************************************************

   Copyright (C) 2005 Sonda Ltd.

   Version 1.0.0 of 25.08.2005

*******************************************************************************/
#include "SondaAfisSdkErr.h"
#include "common.h"

#ifndef SONDA_AFIS_SDK_H__
#define SONDA_AFIS_SDK_H__

#include <string.h>

#ifdef _WINDOWS
#endif

#if defined(_WINDOWS)	|| defined(_WIN32_WCE)
	#pragma warning(disable : 4996)
	#include <windows.h>
   #define SDK_EI __stdcall
#else
   #undef  SDK_EI
   #define SDK_EI

   typedef struct  tagPOINT
   {
   LONG x;
   LONG y ;
   }POINT ;
#endif

typedef unsigned char BYTE;

enum SCALE_PRINT 
{
   ONE_ONE    = 0,
   THREE_TWO  = 1,
   TWO_ONE    = 3,
   FIVE_TWO   = 4,
   THREE_ONE  = 5
};

enum SEARCH_SPEED 
{
   NORMAL_SPEED  = 0,       // normal speed, maximum accuracy
   HIGH_SPEED    = 1,       // high speed, lower accuracy
   HIGHEST_SPEED = 2        // highest speed, lowest accuracy
};

enum IMAGE_TYPE {   // image type
   WSQ_IMAGE = 0,
   RAW_IMAGE = 1
};

enum OBJ_TYPE {
   emptyType      = 0,  // no object
   fingerType     = 1,  // tenprints: finger, plain finger, palm
   latentType     = 2,  // finger latent
   latentPalmType = 3,  // palm latent
   slapType       = 4   // slap image for segment
};

enum HAND_TYPE     // slap type
{  
	RIGHT     = 1,  // fingers 12...15
	LEFT      = 2,  // fingers 17...20
	UNDEFINED = 3,  // left or right hand
	THUMBS    = 4   // fingers 11, 16
};

enum TypeNist 
{
   NistFbi  = 0,
   NistIpl  = 1
};

enum MAX_OBJECT {
   minPixelImage,        // minimum size of the image (width and height) in pixels, 500 dpi
   maxPixelFinger,       // maximum size of the image (width and height) in pixels, 500 dpi
   maxPixelPalm,         // minimum size of the palm image (width and height) in pixels, 500 dpi
   maxSizeFinger,        // maximum of the image square (width * height)
   maxSizePalm,          // maximum of the palm image square (width * height)
   maxMinutaiFinger,     // maximum number of finger minutiae
   maxMinutaiPalm,       // maximum number of palm minutiae
   maxSizeTepmlate,      // maximum size of finger template
   maxSizeTepmlatePalm,  // maximum size of palm template
   SizeIntegrTP,         // size of integrals for 10 fingers of tenprint
   maxIntT,              // maximum size of finger integrals temporary data
   maxIntTPalm,          // maximum size of palm integrals temporary data
   maxSizeSkeleton,      // maximum size of compressed finger skeleton
   maxSizeSkeletonPalm   // maximum size of compressed palm skeleton
};

#pragma pack(push, 1)
struct P_PACKED_1 AfisObj 
{
   int        numObject;      // number of rolled finger (1...10), plain fingerprint (11...20),
                              // palmprint (21 - right palm, 22 - left palm), latents(1...99)
                              // 0 - no object
   OBJ_TYPE   typeObj;        // fingerprint or latentprint or palm latent
   IMAGE_TYPE typeImage;      // type of the image: wsq or raw
   int        width;          // image width
   int        height;         // image height
   int        sizeImage;      // size of the data pointed by 'image'
   int        maxImage;       // maximum 'image' size
   BYTE      *image;          // image data
   bool       changeImage;    // true  - if image was changed by function call
   int        sizeTemplate;   // size of the template data
   int        maxTemplate;    // maximum size of 'fpTemplate'
   BYTE      *fpTemplate;     // template data
   bool       changeTemplate; // true  - if template was changed by function call
   int        sizeSkeleton;   // size of data pointed by skeleton
   int        maxSkeleton;    // maximum 'skeleton' size
   BYTE      *skeleton;       // skeleton data
   bool       changeSkeleton; // true  - if skeleton was changed by function call
   int        sizeIntT;       // size of temporary integral data
   int        maxIntT;        // maximum 'intT' size
   BYTE      *intT;           // temporary integral data for check up
   bool       changeIntT;     // true  - if integral data was changed by function call
   // If pointer to the image,fpTemplate,skeleton,intT is NULL, then these fields 
   // is not filed
   // The memory for these pointers should be allocated from application. 
   // For callback functions memory allocated by the SDK 
   // (it reased when corresponded function is finished)
   AfisObj()
   {
      numObject      = 0;
      typeObj        = emptyType;
      width          = 0;
      height         = 0;
      sizeImage      = 0;
      maxImage       = 0;
      image          = 0;
      changeImage    = false;
      sizeTemplate   = 0;
      maxTemplate    = 0;
      fpTemplate     = 0;
      changeTemplate = 0;
      sizeSkeleton   = 0;
      maxSkeleton    = 0;
      skeleton       = 0;
      changeSkeleton = false;
      sizeIntT       = 0;
      maxIntT        = 0;
      intT           = 0;
      changeIntT     = false;
   }
};

struct P_PACKED_1 OptionsOperator // operators settings
{ 
   int  Color[16];    // color descriptions. if 0 - everything by default
   bool changeColor;  // if true, then settings were changed, 
                      // it should be saved in database
   bool CodirTP;      // the operator have rights to coding tenprints   
   bool CodirLP;      // the operator have rights to coding latents
   bool RecomList;    // the operator have rights to run the searches 
                      //  and remove the recommended lists
};

struct P_PACKED_1 tip_TextCodir   // textual data for latent coding
{
   char numCard[16], nLat[16], Operator[32], Caption[80];
};

struct P_PACKED_1 TPData {
   TPData() {
      numCard = 0;  firstName[0] = 0;  lastName[0] = 0;
   }
   int  numCard;         // tenprint system number
   char firstName[80];
   char lastName[80];
};

struct P_PACKED_1 LPData 
{
   LPData() 
   {
      numCard = 0;  number[0] = 0;
   }
   int  numCard;     // latent card system number
   char number[16];  // latent card textual number
};

struct P_PACKED_1 ListCand      // recommended list of  LT,TL,LL searches
{  
   int numCard;      // tenprint (TP) system number for LT search or 
                     // latentprint system number for TL,LL searches
   int num;          // finger number (1...11,21,22) for LT search 
                     // or latent number for TL,LL search
   int similarity;   // similarity (search result)
   int nFing;        // finger number of TP probe for TL search 
                     // (don't use for LL,LT searches)
   bool view;        // record was viewed
   bool exclude;     // record was excluded by expert (who reviewed the result)
   bool coincidence; // record was defined as hit by expert (who reviewed the result)
};

struct P_PACKED_1 Semantic 
{
   int errCode;
   int errLevel;
   int numFinger;
};

struct P_PACKED_1 OutSemantic {
   int  numCard;
   int  numFinger;   // 1...10
   int  errCode;
   bool view;       // true if it was reviewed by operator
};

// search result
struct P_PACKED_1 Verdict 
{
   int similarity;                  // similarity
   int queryNum;                    // index number of loaded sample
   int fingerNum;                   // number of candidate finger
   int pairCount;                   // pairs amount
   unsigned short pairArr[256][2];  // number of minutiae in the pairs
};

struct P_PACKED_1 TypePhoto  // photo
{  
   int  size;
   unsigned char *photo; // photo in jpeg format
};

struct P_PACKED_1 type_Nist 
{
   TypeNist typeNist;  // Nist Fbi or Interpol
   TPData *tData;      // if NULL then Tenprints, lData != NULL
   LPData *lData;      // if NULL then Latents,   tData != NULL
   char Transac[80];   // list of transactions separated by comma (CAR,MPS,LFS...)
   char Source[80];    // source identification
   char Dest[80];      // destination identification
   char Ofr[80];       // the software developer name

   type_Nist()
   {
      typeNist = NistFbi;
      tData = 0;
      lData = 0;
      Transac[0] = 0;
      Source[0]  = 0;
      Dest[0] = 0;
      strcpy( Ofr, (const char *) "Sonda" );
   }
};
#pragma pack(pop)


#define SASDK_NIST_CARD_FBI     "CAR"
#define SASDK_NIST_LATENT_FBI   "LFS"
#define SASDK_NIST_CARD_IPL     "CPS"
#define SASDK_NIST_LATENT_IPL   "MPS"

#define SASDK_MAX_ANGLE_SLAP   45  // maximum image rotate angle for slap images, degree
extern "C" {
/////////////////////////////////////////////////////////////////////////////////////////
//   COMMON NOTES
/////////////////////////////////////////////////////////////////////////////////////////
/*
   Note1: image should be 256 grey-level(8 bit per prixel), 500 DPI
   Note2: memory for the templates and all intermediate buffers should be previously allocated
          in application. She maximum size required to the corresponded buffer should be
         get by 'getMaxObjectSize' function
   Note3: if one of the image pointer is NULL, then there is no corresponded image
*/

/*
   SDK initialisation. Should be call first
   Parameters:
   licenceName    (input) - Name of license file  
   sLanguage      (input) - *.lng file name (file that contains all strings for
                            localization)
   CompressFinger (input) - TP fingerprint image comress ratio  (5...40)[default =20]
   CompressPalm   (input) - TP palm image comress ratio  (10...50)[default =25]
   CompressLatent (input) - LP image comress ratio  (2...30)[default =10] 
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI initAfisSdk(const char *licenseName, 
                       char *sLanguage, int CompressFinger, int CompressPalm, 
                       int CompressLatent );   

/*
   close work with SDK
*/
void SDK_EI closeAfisSdk( void );



/////////////////////////////////////////////////////////////////////////////////////////
//   IMAGE PROSESSING ALGORITHM
/////////////////////////////////////////////////////////////////////////////////////////
/*
   Common NOTE:
   The recommended order of TP processing:              
   1. checkMixed - check if some fingers mixed
   2. showMixed  - if mixed, check it by operator
   3. process1   - automatic first processing (define the integral characteristics)
   4. checkIntegrals - chek up of integrals by operator
   5. process2   - automatic second processing
   6. getIntegrTP - get integral characteristics of TP for future TT search
   Te stages 1 and 2 can be omitted
*/

/*
   Perform the first processing of the set of fingerprint(palmprint) images of the tenprint
   and build the corresponded set of intermediate data.
   Parameters:
   obj      (input) - rolled, plain fingerprints and palmprints data
                      NOTE: in obj should be filled the image fields. The function puts 
                      integral information to 'intT' field
   progress (input) - callback function for drawing the progress bar. 
                      If NULL -  this function is not call.
                      Using this function is not thread safed!!! So, for multi thread application 
                      and for all Linux application this parameter should be NULL
                      Function parameters:
                      fing (input) - finger or palm number (numObject)
                      pos  (input) - ProgressBar positions
                                     if fing == 0 then pos contain ProgressBar length 
                                     (range = 0...length)
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI process1( AfisObj obj[22], void (*progress)( int fing, int pos ) );

/*
   Display the dialog that allows the operator to check up the integral points of the tenprint,
   those were automatically define while first image processing stage
   Parameters:
   param      (input) - pointer to user defined parameter. This paramter will 
                        be pass to callback function
   getCard    (input) - callback function. It put new integral data for processed 
                        TP and request the next TP by its TPData 
                        getCard parameters:
                           param    (input)        - pointer to user defined parameter that was passed 
                                                     to the function
                           obj      (input/output) - rolled fingerprints and palmprints data. Application 
                                                     should fill image field.
                           textData (output)       - textual data
                           flagSave (input)        - if true than put integral data in  obj[i].intT for 
                                                     'process2' function
                                                      false - don't put this data (it can be the first call 
                                                      of this function or operator decided to stop work)
                           flagRead (input)        - if true then request to next TP. The application should 
                                                     filed the  obj and textData fields
                           Return Values: 
                             true if there is next TP for cheking 
                             false if there are no more TP (after this the 
                             'checkIntegrals' function will finish it work
                  
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise

   NOTE1: the function can change the intT and image fields. The images can be
          rotated or removed.
   NOTE2: if the operator reviewed the finger, then function set the obj.changeIntT 
          to true and to false otherwise
*/
int SDK_EI checkIntegrals( void *param,
       bool (*getCard)( void *param, AfisObj obj[12], TPData *textData, bool flagSave, bool flagRead )
);

/*
   Perform the second processing the set of intermediate data of the tenprint, 
   those were get after first processing and probably check of integral points, 
   and build the corresponded set of templates.
   Parameters:
   obj        (input/output)  - rolled, plain fingerprints and palmprints data
                                in obj should be filed image fields and allocated 
                                memory for templates.
                                If intT == NULL or sizeIntegr == 0 then integral 
                                data build automatically
                                If skeleton == NULL than skeleton don't build
                                If image is not compressed then image will be compressed 
                                by WSQ with ration that was set in initialization function. 
                                NOTE: image size can be changed!!
                                For plain images the image size is not changed and 'intT' 
                                and 'skeleton' don't used
   progress   (input)        - callback function for progress bar drawing. If it is NULL, 
                               then it is not called
                               Using this function is not thread safed!!! So, for multi thread 
                               application and Visual Basic and for all Linux  application this parameter 
                               should be NULL
                               progress parameters:
                                 fing (input) - finger of palm number (numObject)
                                 pos  (input) - progress bar position
                                                if fing == 0, than pos = maximum length of 
                                                ProgressBar (range 0... lenght)
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI process2( AfisObj obj[22], void (*progress)( int fing, int pos ) );

/*
   Get the final tenprint integral data from tenprint templates.
   These data later can be used in TP-TP search
   Parameters:
   obj        (input)  - rolled, plain fingerprints and palmprints data
   integrTP   (output) - the final tenprint integral data for save in DB
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI getIntegrTP( const AfisObj obj[10], BYTE *integrTP );

/*
   Check if some of rolled fingerprint of the tenprint were mixed
   (for example the right thumb was input as right index etc)
   Parameters:
   obj        (input)  - rolled and plain fingerprints palmprints data
                         the image field should be filed. The fpTemplate can be NULL, 
                         but in this case processing performing with create 
                         the temporary templates
   needCheck  (output) - true, if check is required. In this case you shoud call 'showMixed'
                         function for check it by operator
   mixMask    (output) - the result of checking operation (what fingers should be checked)

   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI checkMixed( const AfisObj obj[20], bool *needCheck, short mixMask[10] );

/*
   Display the dialog that allows the operator to check if some of rolled
   fingerprint of the tenprint were mixed
   Parameters:
   param        (input) - pointer to user defined parameter. This paramter will 
                          be pass to callback function
   getCardMixed (input) - callback function that return result of check 
                          (the new number of fingers) and request the next TP
                          getCardMixed parameters:
                              param      (input) - pointer to user defined parameter passed 
                                                   to the function by caller
                              obj       (output) - rolled and fingerprints data (at furst fingers, 
                                                   than plain fingers)image field in obj should be field
                              textData  (output) - textual data
                              mixMask   (output) - the result of 'checkMixed' function
                              flagSave  (input)  - if true than the new number of fingers in 
                                                   maskFingers array
                                                   if false - it is a first call of the fucntion 
                                                   or operator decided to stop his work
                              maskFingers (input) - the new sequence of the fingers, 0 - amputated finger
                                                   1...10 - finger number, 11...20 - plain fingers
                              flagRead  (input)  - if true - request of the next TP (obj and textData 
                                                   should be filed)
                          Return Values: 
                              true if theres is TP for check, obj and  textData filed
                              false if no more TP, the fucntion is stop work
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI showMixed( void *param, bool (*getCardMixed)( void *param, 
                     AfisObj obj[20], TPData *textData, short mixMask[10], 
                     bool flagSave, int maskFingers[10], bool flagRead ) );


/*
   Display the dialog that allows the operator to recode the fingerprint(palmprint) image and
   make all correction he wants
   Parameters:
   textData   (input)        - tenprints textual data
   obj        (input/output) - fingerprints or palmprints data
   optionOper (input/output) - operator settings
   result     (output)       - if true then the results of coding available
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise

   NOTE1: the image, skeleton, templates can be changed in this function. The intT field is not used
   NOTE2: if the image was changed then it will compressed with ratio, that was set in 'initAfisSdk' function
*/
int SDK_EI codingT( const TPData *textData, AfisObj *obj, 
                   OptionsOperator *optionOper, bool *result );

/*
   Display the dialog that allows the operator to recode the fingerprint(palmprint) image and
   make all correction he wants
   Parameters:
   textData   (input)         - latentprints textual data
   obj        (input/output)  - latentprint or palm latentprints data
   optionOper (input/output)  - operator settings
   result     (output)        - if true then the results of coding available
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise

   NOTE1: the image, skeleton, templates can be changed in this function. The intT field is not used
   NOTE2: if the image was changed then it will compressed with ratio, that was set in 'initAfisSdk' function
*/
int SDK_EI codingL( const LPData *textData, AfisObj *obj, OptionsOperator *optionOper, bool *result );
/*
   The same as 'codingL' function, but use the direct minutiae placement mode
*/
int SDK_EI codingL2( const LPData *textData, AfisObj *obj, OptionsOperator *optionOper, bool *result );

/////////////////////////////////////////////////////////////////////////////////////////
// SHOW AND PRINTING OPERATIONS
/////////////////////////////////////////////////////////////////////////////////////////
/*
   Display the dialog that shows the fingerprint(palmprint) images of the tenprint with all features
   and you can call the dialog for recoding if it is necessary
   Parameters:
   textData        (input)        - tenprints textual data
   startObj        (input)        - object for start review (0...11)
   option          (input/output) - operator color settings and other operator settings
   obj             (input/output) - rolled fingerprints and palmprints data
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise

   NOTE1: the image, skeleton, templates can be changed in this function. The intT field is not used
   NOTE2: if field intT == NULL than operator cannot change the integral data, otherwise the new intT can be
          build and this image should be reprocessed by 'process2' function with this new integral data
*/
int SDK_EI displayTP( const TPData *textData, int startObj, AfisObj obj[12],
               OptionsOperator *option );

/*
   Display the dialog that shows the latent images with all features
   and you can call the dialog for recoding if it is necessary
   Parameters:
   numLatents      (input)        - quantity of latents in obj array
   textData        (input)        - latentprint textual data
   startObj        (input)        - object for start review (0...numLatents-1)
   obj             (input/output) - latentprints and palm latents data
   option          (input/output) - operator color settings and other operator settings
   param           (input)        - pointer to user defined parameter. This paramter will be pass to callback function
   query           (input)        - callback function for search query creating
                                    query parameters:         
                                      numCard - LP system number
                                      nLat    - number of latent
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise

   NOTE: the image, skeleton, templates can be changed in this function. The intT field is not used
*/
int SDK_EI displayLP( int numLatents, const LPData *textData, int startObj, AfisObj *obj,
               OptionsOperator *Option, void *param,
               void (*query)( void *param, int numCard, int nLat ) );

/* 
   Print the tenprint
   Parameters:
   textData    (input) - tenprints textual data
   preview     (input) - if this parameter is 'true' then preview mode using
   obj         (input) - rolled, plain fingerprints and palmprints data
   nPhoto      (input) - number of photos (in a current version printed only one)
   photo       (input) - array of photos
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI printTP( const TPData *textData, bool preview, const AfisObj obj[22],
             const int nPhoto, const TypePhoto *photo );

/*
   Print the latentprints card (can include the few latentprints)
   Parameters:
   textData    (input)  - pointer to the structure with demographic and other text information
   preview     (input)  - if this parameter is 'true' then preview mode using
   numPrints   (input)  - number of latents or palm latents in the card
   obj         (input)  - latentprints data
   fingerScale (input)  - scale of finger latent display from SCALE enumeration
   palmScale   (input)  - scale of palm latent display from SCALE enumeration
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI printLP( const LPData *textData, bool preview, int numPrints,
             const AfisObj *obj, SCALE_PRINT fingerScale, SCALE_PRINT palmScale );

/////////////////////////////////////////////////////////////////////////////////////////
// INTEGRAL MATCHING ALGORITHM
// It used for TT search on a first stage
// It used the integral data of 10 fingers of TP, shouse shall be checked by operator
/////////////////////////////////////////////////////////////////////////////////////////
/*
   Load the tenprints for matching with integral information ��� ������ TT
   Parameters:
   fpTemplate  (input) - the figerprint templates
   modeSpeed   (input) - �������� ������ TT, 0...2; 0 - ������, 2 - ��������.
                         recommended value = 1
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI loadQueryIntegrTT( BYTE *fpTemplate[10], int modeSpeed );

/*
   Perform the TP-TP search with integral information
   Parameters:
   integrTP    (input)  - tenprint interal data (integral data of 10 fingers)
   result      (output) - true if integral data of this TP is similar to integral data
                          of TP those were previously load by 'loadQueryIntegrTT' function
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI searchIntegrTT( BYTE *integrTP, bool *result);

/*
   Perform the TP-TP search with integral information, but in different of searchIntegrTT
   it return the array of finger numbers, thouse should be che�ked by minutiae
   Parameters:
   integrTP    (input)  - tenprint interal data (integral data of 10 fingers)
   countFing   (output) - number of fingers shouse should be used for minutiae search (0..3)
   fing        (output) - array of finger numbers
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI searchIntegrTT2(BYTE *integrTT, int *countFing, int *fing );

/*
   ������������ ������ ������� �������, ��������������� �� �������� ����������
   �������� ��� �������.
   Parameters:
   integrTP  (input)  - tenprint interal data (integral data of 10 fingers)
   countFing (input/output) - �� �����: ������������ ���������� ������� ���
                                        ����������� ������ (1...10) ������������� 4
                              �� ������: ���-�� ������� � ������� fing
   fing      (output) - array of finger numbers
   Return Values: function returns SASDK_OK.
*/
int SDK_EI listFingerTT(BYTE *integrTT, int *countFing, int *fing );

/////////////////////////////////////////////////////////////////////////////////////////
// MINUTIAE MATCHING ALGORITHM
/////////////////////////////////////////////////////////////////////////////////////////
/*
   Load the probe tenprints for matching with minutiae information
   The SearchTT, SearchLT, SearchTL, SearchLL used integral data that should be checked by operator
   Parameters:
   fpTemplate (input)  - the figerprint templates
   integrMode (input)  - for TL search: 0 - use integral information, 1 - free search
                         for TT search: �������� ������ (0...2), 0 - ������, 2- ��������.
                                        ������������� �������� - 1.
   threshold  (input)  - when the similarity of two images more than this value, search result
                         information is put to 'found' arrray
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI loadQueryT( BYTE *fpTemplate[10], int integrMode, int threshold );

/*
   Load the probe latentprint for matching with minutiae information
   Parameters:
   lpTemplate  (input) - the latentprint template
   integrMode (input)  - 0 use integral information,  1 - free search, combine image by image center
   maxDisp    (input)  - maximum displacement one fingerprint image from another, pixels (0...500)
   maxAngle   (input)  - maximum angle rotation one fingerprint image from another, +-degree (0...180)
   threshold  (input)  - when the similarity of two images more than this value, search result
                         information is put to 'foud' arrray
   numQuery   (output) - the variable that received the number of loaded query (0...99)
                         This value will put to the 'queryNum' member of 'Verdict' structure
                         in 'searchLT' function
   fingerMask (input)  - Array of finger mask that show which fingers should be used in search. 
                         1 - use corresponded finer, 0 - don't use 
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise

   NOTE: For LL search you can load only one latent. For LT search you can load up to
         100 query (queryNum from 0 till 99). This can increase the search speed.
*/
int SDK_EI loadQueryL( BYTE *lTemplate, int integrMode, int maxDisp, int maxAngle,
                int threshold, int *numQuery, unsigned char fingerMask[10] );

/*
   The release all memory that was allocated while successive call of 'loadQueryL' or 'loadQueryT' functions
*/
void SDK_EI freeQuery( void );

/* 
   Set the search speed for SearchLT, SearchTL, SearchLL 
   Parameters:
   speed (input) - search speed
*/
void SDK_EI setModeLT( SEARCH_SPEED speed );

/* 
   set the search speed for SearchTT, SearchSpeed
   Parameters:
   speed (input) - search speed
*/
void SDK_EI setModeTT( SEARCH_SPEED speed );

/*
   Perform the TP-TP search with minutiae information
   with the tenprints that was previously load by 'loadQueryT' function
   Parameters:
   fpTemplate  (input)  - the figerprint templates
   similarity  (output) - similarity index
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI searchTT( BYTE *fpTemplate[10], int *similarity );

/*
   ��������� ���������� ����� TP-TP with minutiae information.
   ������������� �������������� ������� ������� listFingerTT � �����������
   fpTemplate � ����������� ������� ��������
   Parameters:
   fpTemplate  (input)  - the figerprint templates
   similarity  (output) - similarity index
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI searchFullTT( BYTE *fpTemplate[10], int *similarity );

/*
   Perform the TP-LP search with minutiae information 
   with the tenprint that was previously load by 'loadQueryT' function. A memory must be distributed  under an
   array of 'found' search result with size 10.  
   Parameters:
   lTemplate  (input)  - the latentprint templates
   numFound   (output) - the number of found pairs
   found      (output) - information about search result
						 ������ ������������ 10 	
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI searchTL( BYTE *lTemplate, int *numFound, struct Verdict found[] );

/*
   Perform the LP-TP search with minutiae information
   with the latent that was previously load by 'loadQueryL' function
   Parameters:
   fpTemplate (input)  - the tenprint templates
   numFound   (output) - the number of found pairs
   found      (output) - information about search result
						 Array with size 10 * <amount of loaded search templates> 	
						 Search templates must be loaded previously by loadQueryL function.
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI searchLT( BYTE *fpTemplate[10], int *numFound, struct Verdict found[]);

/*
   Perform the LP-LP search with minutiae information
   with the latent that was previously load by 'loadQueryL' function
   (function 'loadQueryL' should be called only once)
   Parameters:
   lTemplate  (input)  - the latentprint templates
   found      (output) - information about search result
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI searchLL( BYTE *lTemplate, struct Verdict *found );


/////////////////////////////////////////////////////////////////////////////////////////
// QUICK SEARCH FOR CIVIL APPLICATION
// this search type doesn't use integrals, combination on points centre of gravity.   
/////////////////////////////////////////////////////////////////////////////////////////
/*
   Perform the quick TP-TP search for civil application with minutiae information
   with the tenprint that was previously load by 'loadQueryT' function
   Parameters:
   fpTemplate    (input)  - the tenprint templates
   maxDisp       (input)  - maximum displacement one fingerprint image from another, pixels (0...500)
   maxAngle      (input)  - maximum angle rotation one fingerprint image from another, +-degree (0...180)
   lowThreshold  (input)  - if after compare first pair of fingers the similarity less than this value
                            then another pairs is not matching [60]
   highThreshold (input)  - if after compare first pair of fingers the similarity more than this value
                            then another pairs is not matching [160]
   speed         (input)  - search speed
   similarity    (output) - the similarity index
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI searchSpeedTT( BYTE *fpTemplate[10], int maxDisp, int maxAngle, int lowThreshold,
                       int highThreshold, SEARCH_SPEED speed, int *similarity );
/*
   'Finger-finger'search for civil application with minutiae information.
   Inquired finger must be loaded previously as a one tenprint finger
   in 'loadQueryT' function.
   Parameters:
   fpTemplate   (input) - the finger templates
   maxDisp      (input) - maximum displacement one fingerprint image from another, pixels (0...500)
   maxAngle     (input) - maximum angle rotation one fingerprint image from another, +-degree (0...180)
   changeThres  (input) - similarity threshold. If the result of probe-galery fingerprint is below, 
                          then another search (galery-probe fingerprint) is performing
   fingerNum    (intput)- the number of probe finger. 
                          This number was used in 'loadQueryT' function (1...10) for finger number
   found        (output)- information about search result
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI searchSpeed( unsigned char *fpTemplate, int maxDisp, int maxAngle,
                        int changeThres, int fingerNum, struct Verdict &found );
/*
   Transform compressed template to halfCompressed
   NOTE: the size of halfCompressed template is depends from number of minutiae and image size
   and approximately in 6..15 times bigger than compressed template
   This half-compressed template can be used in 'searchSpeed' and 'searchSpeedTT' functions instead of 
   usual templates for increase speed purpose.
   Parameters:
   compTemplate     (input)  - the compressed templates
   halfCompTemplate (output) - the halfCompressed template
   lenBufOut        (output) - the size of halfCompressed template
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI loadCodeToCompress( unsigned char *compTemplate, unsigned char *halfCompTemplate, int *lenBufOut );

/*
   Take fingerprint tempaltess of two tenprints and outputs an ordered list of the
   best fingerprint pairs.
   Parameters:
   fpTemplate1   (input)  - the array of fingerprint templates of first tenprint
                            [0] - ����� 1, [1] - 2 ...  [9] - finger 10
   fpTemplate2   (input)  - the array of fingerprint templates of second tenprint
   fingerNum     (output) - the ordered list of the best fingerprint pair numbers.
   numPairs      (output) - the length of fingerNum list(0...10)
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI fingerSelector( const BYTE *fpTemplates1[10], const BYTE *fpTemplates2[10],
                     int fingerNum[10], int *numPairs );

/////////////////////////////////////////////////////////////////////////////////////////
// PALM SEARCH
/////////////////////////////////////////////////////////////////////////////////////////
/*
   Prepare the palm search
   function allocate 35MB memory. It should be called once before palm search
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI allocPalmMemory();

/*
   release the memory allocated by 'allocPalmMemory' function
*/
void SDK_EI freePalmMemory();

/*
   Check if allocPalmMemory allocated the memory             
   Return Values: true if memoty is allocated
*/
bool SDK_EI checkPalmMemory();

/*
   Load the palmprints for matching
   Parameters:
   palmTemplate  (input) - the palm templates
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/

int SDK_EI loadQueryPalmT( BYTE *palmTemplate[2] );
/*
   Load the palm latent for matching
   Parameters:
   lTemplate  (input) - the palm latent templates
   palmMask   (input) - if palmMask[0] == 1, palm latent can belong to the right palm, 
                        otherwise it cannot belong right palm
                        if palmMask[1] == 1, palm latent can belong to left palm, 
                        otherwise it cannot belong left palm
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI loadQueryPalmL( BYTE *lTemplate, BYTE palmMask[2] );
/*
   The same as 'loadQueryPalmL', but allows to set the palm latent position and 
   tolerance for this position
   Parameters:
   lTemplate  (input) - the palm latent templates
   palmMask   (input) - if palmMask[0] == 1, palm latent can belong to the right palm, 
                        otherwise it cannot belong right palm
                        if palmMask[1] == 1, palm latent can belong to left palm, 
                        otherwise it cannot belong left palm
   RectPalm   (input) - define the palm latent position in % from wh1ole palm image
                        (left, top, right, bottom). RectPalm[0] for the right palm,
                        RectPalm[1] for the left palm.
   maxAngle    (input) - angle tolerance for palm latent position, degree
   maxDisp     (input) - displacement tolerance for palm latent position, pixels
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI loadQueryPalmL2( unsigned char *lTemplate, unsigned char palmMask[2],
                         unsigned char RectPalm[2][4], int maxAngle, int maxDisp );

/*
   Perform the PP-PL search that previously loaded by 'loadQueryPalmL' funcion
   Parameters:
   lTemplate  (input) - the palm latent templates
   numFound   (output) - the number of found pairs
   found      (output) - search result information
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI searchPalmPL (BYTE *lTemplate, int *numFound, struct Verdict found[]);
/*
   The same as 'searchPalmPL' function, but allows to set the palm latent position and 
   tolerance for this position
   Parameters:
   lTemplate  (input) - the palm latent templates
   numFound   (output) - the number of found pairs
   found      (output) - search result information
   RectPalm   (input) - define the palm latent position in % from wh1ole palm image
                        (left, top, right, bottom). RectPalm[0] for the right palm,
                        RectPalm[1] for the left palm.
   maxAngle    (input) - angle tolerance for palm latent position, degree
   maxDisp     (input) - displacement tolerance for palm latent position, pixels
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI searchPalmPL2( unsigned char *lTemplate, int *numFound,
             struct Verdict found[], unsigned char RectPalm[2][4], 
                int maxAngle, int maxDisp );

/*
   Perform the LP-PP and LP-LP search with palm latent that previously loaded by 'loadQueryPalmL' funcion
   Parameters:
   pTemplate  (input)  - the palmprint templates
   numFound   (output) - the number of found pairs
   found      (output) - search result information
   flagTP     (input)  - if true then LP-PP search is performed
                         if false then LP-LP search is performed 
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI searchPalmLP( BYTE *pTemplate[2], int *numFound, struct Verdict found[],
                         bool flagTP );

/////////////////////////////////////////////////////////////////////////////////////////
// RECOMMENDED LIST REVIEW
/////////////////////////////////////////////////////////////////////////////////////////
/*
   Disply the dialog for review the TP_TP search recommended list
   Parameters:
   data       (input)  - the tenprints textual data
   tp         (input)  - tenprints data for two compare tenprints
   unite      (output) - if the tenprints were united, it is formed by fingerMask
   pasport    (output) - textual data of TP that was selected by operator for the united TP (0 or 1)
   fingerMsk  (output) - the array of finger numbers those were selected for the united TP
                         the value of each number means:
                           0 - take the finger (palm) from the first TP
                           1 - from the second TP
                           2 - no finger
   match     (output) - if true: operator say hit
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI showRecommendedListTT( const TPData data[2], const AfisObj tp[2][12],
                           bool *unite, int *pasport, int fingerMask[12], bool *match );

/*
   Disply the dialog for review the TP_LP search recommended list
   Parameters:
   tdata       (input)  - the tenprints textual data
   tp          (input)  - tenprints (fingerprints and palmprints) data
                          (only fingers or palms those are in recommended list, all other can be NULL)
   countList   (input)  - number of latents in recommended list
   start       (input/output) - item of the list from where start review before function call and the last item where the 
                                review stop after fun�tion call
   list        (input)  - recommended list
   param       (input)  - pointer to user defined parameter. This paramter will be pass to callback function
   getLatent   (input)  - the callback function, that should return the latent data by its number
                           getLatent parameters:
                              numCard  (input) - LP system number
                              nLat     (input) - latent number (1...99)
                              obj      (output)- description. Application should fill the 'image' and  'template' fields and 
                                                 also 'skeleton' field (if available)
                              textData (output)- LP textual data
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI showRecommendedListTL( const TPData *tdata, AfisObj tp[12],
        int countList,  int *start, ListCand *list, void *param,
        int (*getLatent)( void *param, int numCard, int nLat, AfisObj * obj, LPData *textData) );

/*
   Disply the dialog for review the TP_LP search recommended list
   Parameters:
   ldata        (input)       - the latentprint textual data
   latent       (input)       - latent data
   countList   (input)        - number of latents in recommended list
   start       (input/output) - item of the list from where start review before function call and the last item where the 
                                review stop after fun�tion call
   list        (input)        - recommended list
   param       (input)        - pointer to user defined parameter. This paramter will be pass to callback function
   getFinger (input)          - the callback function, that should return the tenprints data by its number
                                 getFinger parameters:
                                    numCard  (input) - TP system number
                                    nFing    (input) - finger number (1...10) or palm number (21...22)
                                    obj      (output)- description. Application should fill the 'image' and  'template' fields and 
                                                       also 'skeleton' field (if available)
                                    textData (output)- textual data
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI showRecommendedListLT (const LPData *lData, AfisObj *latent,
        int countList, int *start, ListCand *list, void *param,
        int (*getFinger)( void *param, int numCard, int nFing, AfisObj * obj, TPData *textData ) );

/*
   Disply the dialog for review the TP_LP search recommended list
   Parameters:
   ldata        (input)       - the latentprint textual data
   obj          (input)       - latent data
   countList   (input)        - number of latents in recommended list
   start       (input/output) - item of the list from where start review before function call and the last item where the 
                                review stop after fun�tion call
   list        (input)        - recommended list
   param       (input)        - pointer to user defined parameter. This paramter will be pass to callback function
   getLatent   (input)        - the callback function, that should return the latent data by its number
   Return Values:
   function returns SASDK_OK - if function succeeds, error code - otherwise
*/
int SDK_EI showRecommendedListLL (const LPData *lData, AfisObj *obj,
        int countList,  int *start, ListCand *list, void *param,
        int (*getLatent)( void *param, int numCard, int nLat, AfisObj * obj, LPData *textData) );


/////////////////////////////////////////////////////////////////////////////////////////
// TOOLS
/////////////////////////////////////////////////////////////////////////////////////////

/*
	function returns error description by its number
	In a case of System or Oracle error it returns the last happened error description
	Parameters:
	numError (input) - error number
	Return value:
	The test error descriptions
*/
void SDK_EI getSaSdkErrMsg (char *msg, int len, int numError);

/*
   function returns last error description
   Parameters:
   str  (output) - the last error happened
   maxLen (input) - maximum length of the message buffer 
   Return value: no
*/
void SDK_EI getLastErrorMsg( char *str, int maxLen);

/*
   The function return the maximum size that can be requered for variable of corresponded type
   Parameters:
   type (input)  - type of data (fingerprint template, palmprint template, fingerprint integral data,
                   tenprint integral data, palmprint integral data, skeleton of tenprint, skeleton of palm)
   size (output) - the maximum size, that the corresponded data can required
   Return value:
   The function returns SASDK_OK if success and error code otherwise
*/
int  SDK_EI getMaxObjectSize( MAX_OBJECT type, int *size );

/*
   The function check if the template is valid
   Parameters:
   obj            (input)  - finger of palm (according to AfisObj structure)
   result         (output) - SASDK_OK if the template is valid, error code otherwise
                             call 'getLastErrorMsg' for details
   canAutoProcess (output) - if the template is not valid, but this varialbe is set to true
                             then this template can be reprocessed aoutomatically.
                             In this case the temporary integral data for 'process2'
                             function is put to 'intT' variable
   intT           (output) - integral data for  'process2' function. the memory should be allocated by application
   sizeIntT       (output) - size of intT data
   Return value: The function returns SASDK_OK.
*/
int SDK_EI checkTemplate( const AfisObj *obj, int *result, bool *canAutoProcess,
                          BYTE *intT, int *sizeIntT );
/*
   The function check the semantic for tenprint(TP)
   Parameters:
   integrTP    (input)  - tenprint interal data (integrals of 10 fingers)
   count       (output) - number of items in  semantic array
   semantic    (output) - error message: errLevel - error level, errCode -
                          this varialbe is set to 0- if everythings OK.
                          Error code otherwise. This value should pass
                          to 'showSemantic' function
   Return value:
   The function returns SASDK_OK if success and error code otherwise
*/
int SDK_EI semantic( BYTE *integrTP, int *count, Semantic semantic[] );

/*
   Display the dialog to check the semantic for tenprint
   Parameters:
   countList   (input)        - the number of TP in semantic list
   start       (input/output) - start item of the list for review before call and the last item of the list after call
   outSemantic (input/output) - array of OutSemantic prepared by  'Semantic' function
   param       (input)        - pointer to user defined parameter. This paramter will be pass to callback function
   getFinger2  (input)        - the callback function, that should return the tenprints data by its number
                                getFinger2 paramters:
                                    numCard  (input) - TP system number 
                                    nFing    (input) - finger number (1...10)
                                    obj      (output)- description. Application should fill the 'image' and  'template' fields
                                    textData (output)- textual data
                                    fing     (output)- array of flags (is there corresponded finger on the TP?)
   setIntT     (input)      - the callback function, with new integral characteristics. You chould call 'process2' function for reprocessing
                              setIntT parameters:
                                    numCard    (input)- TP system number
                                    nFing      (input)- finger number (1...10)
                                    sizeIntegr (input)- integral data lenght
                                    IntT       (input)- integral data
   Return value:
   The function returns SASDK_OK if success and error code otherwise
*/
int SDK_EI showSemantic( int countList, int *start, OutSemantic *outSemantic, void *param,
      int  (*getFinger2)( void *param, int numCard, int nFing, AfisObj *obj,
                          TPData *textData, bool fing[10] ),
      int  (*setIntT)( void *param, int numCard, int nFing,
                       int sizeIntegr, unsigned char *intT ) );

/*
   Transform the TP or LP into Nist format file
   Parameters:
   obj      (input)  - array of images (fingers and palms for TP, only one latent for LP)
   countObj (input)  - number of objects
   nPhoto   (input)  - number of photos for TP (0...10)
   photo    (input)  - array of photos in Jpeg format
   tNist    (input)  - additional descriptions (for TP should be filed the tData, 
                       lData should be NULL, and otherwise for LP)
   bufOut   (output) - output buffer
   sizeBut  (input/output) - maximum size of bufOut before call and  the real 
                             size of data after call
   putSingularity  (input) - put into NIST file buffer integrals (singularity)
                             information 
   putMinutiae     (input) - put into NIST file buffer minutiae information 
   Return value:
   The function returns SASDK_OK if success and error code otherwise
*/
int SDK_EI saveToNist( AfisObj *obj, int countObj, int nPhoto, TypePhoto *photo,
                type_Nist *tNist, unsigned char *bufOut, int *sizeBuf,
                bool putSingularity, bool putMinutiae );

/*
   Transfor TP or latent from Nist format
   Parameters:
   bufNist  (input)  - buffer with Nist file
   sizeNist (input)  - Nist file size 
   obj      (output) - array of object that will be filed by this function. 
                       Field image will be put to bufTemp buffers
                       NOTE: the memory for these buffers shouldn't be allocated by
                       application
   countObj (output) - number of created obj objects
                       (can be created until 10 fingerprint and 2 palms for TP and 
                       until 99 latent for LP)
   tNist    (output) - textual data (memory should be allocated in application)
                       If tData is filed then it is a TP file, if lData - LP file
   photo    (output) - array of photo in Jpeg format (only for TP)
   nPhoto   (output) - number of created photo
   bufTemp  (output) - buffer where the function put images and photos
                       The memory is allocated by SDK. The application shoud call
                       'loadNistFree'fucntion for release this memory
   Return value:
   The function returns SASDK_OK if success and error code otherwise
*/
int SDK_EI loadNist( unsigned char *bufNist, int sizeNist, AfisObj obj[100],
                     int *countObj, type_Nist *tNist, TypePhoto photo[10], int *nPhoto,
                     unsigned char **bufTemp );

/*
   relase the memoty pointed by bufTemp, that was earlier allocated by loadNist
*/
void SDK_EI loadNistFree( unsigned char *bufTemp ); 

/*
	Take the single slap image, submitted during enrollment, and outputs the
	segmented flat impressions  of each finger from slap image
	Parameters:
	slapImage  (input)   - the single slap image (should be the RAW_IMAGE type, 500 DPI)
                          the maximum slap image  rotation is +- 45 degree
	maxAngle   (input)   - the slap image rotation tolerance, +-degree (0...45)
	hand       (input)   - hand identifier (left, right, undefined, thumb)
	numFound   (output)  - number of fingers found in slap
	rect       (output)  - the location of flat images (right-bottom, left-bottom, left-top, right-top)
	flatImage  (output)  - segmented flat images (the memory should be allocated in application (800*800 pixels))
	quality    (output)  - the quality of segmentation, %
	Return Values:
	function returns SASDK_OK - if function succeeds, error code - otherwise

*/
int SDK_EI segment( const AfisObj *slapImage, int maxAngle, HAND_TYPE hand, int *numFound,
                    POINT rect[4][4], AfisObj flatImage[4], int *quality );

/*
   Take a source image and return the compressed WSQ  image
	Parameters:
	imageSrc      (input)  - source uncompressed image
	compImage     (output) - buffer where WSQ image will be copied
   sizePress     (output) - size of compressed image imagePress
	width, height (input)  - dimension of source image
   ratio         (input)  - compression ratio (should be > 0.)
   The function returns SASDK_OK if success and error code otherwise
*/
int SDK_EI wsqEncode( unsigned char *imageSrc, unsigned char *compImage,
                      int *sizePress, int width, int height, float ration );

/*
   Take a WSQ image and return the uncompressed  image
	Parameters:
   imageDst      (input) - buffer where uncompressed image will be copied
	imagePress    (output)- pointer to the WSQ image buffer
	lensrc        (input) - size of WSQ image
	width, height (output)- the dimension of uncompressed image buffer
   The function returns SASDK_OK if success and error code otherwise
*/

int SDK_EI wsqDecode( unsigned char *imageDst, unsigned char *imagePress,
                      int lensrc, int *width, int *height );


/*****************************************************************************
 Visual Basic compatible functions
 Because VB cannot work with callback functions, this set of functions is
 added to SDK
 Each of this functions have the similar functionality as function with  
 corresponded name (without VB suffix)
*****************************************************************************/

int SDK_EI checkIntegrals_VB( AfisObj obj[12], TPData *textData, bool *flagSave );

int SDK_EI showMixed_VB( AfisObj obj[20], TPData *textData, short mixMask[10],
                           bool *flagSave, int maskFingers[10] );

int SDK_EI showSemantic_VB (OutSemantic outSemantic, AfisObj *obj,
                         TPData *textData, int *sizeIntegr, unsigned char *intT );

int SDK_EI showRecommendedListTL_VB( const TPData *tdata, AfisObj tp[12],
           int countList, int start, ListCand *list, AfisObj * objLatCand, LPData *lDataCand );

int SDK_EI showRecommendedListLL_VB( const LPData *ldata, AfisObj *lp,
           int countList, int start, ListCand *list, AfisObj * objLatCand, LPData *lDataCand );

int SDK_EI showRecommendedListLT_VB( const LPData *ldata, AfisObj *lp,
           int countList, int start, ListCand *list, AfisObj * objTpCand, TPData *tDataCand );

}  //extern "C"

#endif //SONDA_AFIS_SDK_H__



