/*****************************************************************************
	ip.h - header file for image processing (IP) ver. 7.3
   NOTE: ip71 is not thread-safe library!!!
	    
*******************************************************************************/
 
#ifndef IP_73_H__
#define IP_73_H__

#include "coreSdk.h"
#include "core_err.h"


/******************************************************************
          Image processing class
******************************************************************/
#pragma pack(push, _CORE_PACKING)

class FpProcess;

class Ip
{
	FpProcess *m_process;

public:
   Ip();
   ~Ip();
   /* 
      Initialize work with Ip class
      Eiter this function or 'initEx' function should be called first before call 
      any other function
      The function returns IP_OK - if function succeeds, error code - otherwise
   */
   int init();
   /* 
      Initialize work with Ip class
      In differ from 'init' function it take the protection data
      Eiter this function or 'initEx' function should be called first before call 
      any other function
      Parameters:
      protect                 (input) - pointer to 512 byte buffer  with 
                                        protection data
    Return value:
      The function returns IP_OK - if function succeeds, error code - otherwise
   */
   int initEx (BYTE protect[MAX_PROTECT_LEN]);

   // allocate memory for data[] templates
   // The function returns IP_OK - if function succeeds, error code - otherwise
   static int allocateTemplates(unsigned int numFingers, TemplateData data[]);
   // free memery that was earlier allocate templates
      // The function returns IP_OK - if function succeeds, error code - otherwise
   static int freeTemplates(unsigned int numFingers, TemplateData data[]);
   /* 
	   Processes a fingerprint image, taken as DIB and build its template.
      Parameters:
      pContext    (input)  - pointer to execution context, that will be passed as is to all callback functions 
	   data	      (input)  - the CaptureData structures, that contain the 
		                       fingerprint image data 
	   fpTemplates	(output) - the TemplateData structures that receives the built 
                             template. 
                             Memory for the value should be previously allocated
					              by 'allocateTemplates' function
		templSize   (output) - the buffer that receives the size of template
		quality     (output) - the buffer that will receives the fingerprint image quality. 
                             NOTE: If qualityOnly= true, then this value will contain the preliminary 
                             estimation of fingerprint quality and function will complete after getting this value 
                             (template will not be built).
                             If qualityOnly = false, then template will be built and this value will contain 
                             the final (more precise) quality of fingerprint image.
      param       (input)  - the process parameters. If it is NULL, default parameters 
                             are used
	   frame       (output) - if this parameter is non null, then the fingerprint image location 
                             (with white space cut off) will be put in this structure 
                             NOTE: the frame ccordinates will be applied to the image,
                             transformed to 500 DPI.
      onPreprocess (input) - callback function that will be called when preprocessing stage
                             (image segmentation etc.) is completed. 
                             If this parameter is NULL, no callback function will be called  
      onGetQuality (input) - callback function that will be called when preliminary 
                             estimation of fingerprint image quality will be calculated
                             If this parameter is NULL, no callback function will be called  
      onProcess1   (input) - callback function that will be called when the 1st processing stage
                             (define of core\delta location) is completed.  
                             If this parameter is NULL, no callback function will be called  
      onSkeleton   (input) - typedef for callback functions, those will be called when skeleton 
                             building will be completed.
                             If this parameter is NULL, no callback function will be called  
      Return value: 
	   function returns IP_OK - if function succeeds, error code - otherwise
   */	
   int  process      ( const LPVOID          pContext,
                       const CaptureData     data, 
                             TemplateData   &fpTemplate, 
                             unsigned int   *templSize, 
                             int            *quality,
                             ProcessParam   *param         = NULL,
                           ::Frame          *frame         = NULL,
                             ON_PRE_PROCESS  onPreprocess  = NULL, 
                             ON_GET_QUALITY  onGetQuality  = NULL, 
                             ON_PROCESS_1    onProcess1    = NULL,
                             ON_SKELETON     onSkeleton    = NULL);

   /* 
		Processes raw fingerprint image and build its template.
		Image should be 500 DPI, uncompressed, 256 gray-level(8bpp), top-bottom 
		Parameters:
      pContext   (input)  - pointer to execution context, that will be passed as is to all callback functions 
		image      (input) - the buffer that contains fingerprint image 
		widht      (input) - image width
		height     (input) - image height
		fpTemplate (otput) - the buffer that receives the built template. 
					            Memory for this variable should be allocated in application
		templSize   (output) - the buffer that receives the size of template
		quality     (output) - the buffer that will receives the fingerprint image quality. 
                             NOTE: If qualityOnly= true, then this value will contain the preliminary 
                             estimation of fingerprint quality and function will complete after getting this value 
                             (template will not be built).
                             If qualityOnly = false, then template will be built and this value will contain 
                             the final (more precise) quality of fingerprint image.
      param     (input)  - the process parameters. If it is NULL, defaul parameters are used
	   frame     (output) - if this parameter is non null, then the fingerprint image location 
                             (with white space cut off) will be put in this structure 
      finger    (input)  - finger position
      skeleton  (output) - if this parameter is non null, then the skeleton 
                             information will be copied in this buffer
                             The memory (with size at least width * height) should 
                             be allocated in application
      skeletonSize (output)- the buffer that receives the real size of copied skeleton data
      onPreprocess (input) - callback function that will be called when preprocessing stage
                             (image segmentation etc.) is completed. 
                             If this parameter is NULL, no callback function will be called  
      onGetQuality (input) - callback function that will be called when preliminary 
                             estimation of fingerprint image quality will be calculated
                             If this parameter is NULL, no callback function will be called  
      onProcess1   (input) - callback function that will be called when the 1st processing stage
                             (define of core\delta location) is completed.  
                             If this parameter is NULL, no callback function will be called  
      onSkeleton   (input) - typedef for callback functions, those will be called when skeleton 
                             building will be completed.
                             If this parameter is NULL, no callback function will be called  
		Return value:
		The function returns IP_OK - if function succeeds, error code - otherwise
	*/	
   int  processRaw   ( const LPVOID          pContext,      
                             BYTE           *image,
                             WORD            width,
                             WORD            height,
                             BYTE           *fpTemplate, 
                             unsigned int   *templSize, 
                             int            *quality,
                             ProcessParam   *param         = NULL,
                           ::Frame          *frame         = NULL,
                             FINGERS         finger        = FINGPOS_UK,
                             BYTE           *skeleton      = NULL,
                             int            *skeletonSize  = NULL,
                             ON_PRE_PROCESS  onPreprocess  = NULL, 
                             ON_GET_QUALITY  onGetQuality  = NULL, 
                             ON_PROCESS_1    onProcess1    = NULL,
                             ON_SKELETON     onSkeleton    = NULL
                             );

   /* 
	   Get a preliminary estimation of fingerprint quality
      Parameters:
	   data	      (input)  - the CaptureData structures, that contain the 
		                       fingerprint image data 
		quality   (output)   - the buffer that will receives the the preliminary estimation 
                             of fingerprint quality
      param       (input)  - the process parameters. If it is NULL, default parameters are used
	   frame       (output) - if this parameter is non null, then the fingerprint image location 
                             (with white space cut off) will be put in this structure 
                             NOTE: the frame ccordinates will be applied to the image,
                             transformed to 500 DPI.
      Return value: 
	   function returns IP_OK - if function succeeds, error code - otherwise
   */	
   int getQuality  (const CaptureData  data, 
                   int                *quality, 
                   ProcessParam       *param    = NULL,
                 ::Frame              *frame    = NULL);

};

#pragma pack(pop)

#endif // IP_73_H__



