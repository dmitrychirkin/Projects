/*****************************************************************************
	common.h - the common header file

*******************************************************************************/
 
#ifndef COMMON_H__
#define COMMON_H__

#include "win2lin.h"	
#include "ansi_nist_itl_1.h"

// packing defines
#define _CORE_TIGHT      1
#define _CORE_PACKING    8

#pragma pack(push, _CORE_PACKING)

#ifndef __cplusplus
   typedef char      bool;
   #define true          1
   #define false         0 
#endif

// make compatible with UNIX and ARM platforms
#if defined(_WINDOWS)|| defined(_WIN32_WCE)
   
#else
#endif

#define _DBG_INFO
#define _DBG_INFO_1
#define _DBG_INFO_2

#ifdef __cplusplus
   extern "C"{
#endif
/******************************************************************
          THE CONSTANRS
******************************************************************/
// search speed enum
enum MATCH_SPEED 
{
   LOW_MATCH_SPEED     = 0,       // low speed, maximum accuracy
   NORMAL_MATCH_SPEED  = 1,       // normal speed
   HIGH_MATCH_SPEED    = 2,       // high speed, lower accuracy
   HIGHEST_MATCH_SPEED = 3        // highest speed, lowest accuracy
};

// Finger quality values
enum NIST_QUALITY
{
   QUAL_POOR      =  20,    // NFIQ value 5
   QUAL_FAIR      =  40,    // NFIQ value 4
   QUAL_GOOD      =  60,    // NFIQ value 3
   QUAL_VGOOD     =  80,    // NFIQ value 2
   QUAL_EXCELLENT = 100     // NFIQ value 1
};

// Impression type codes
enum IMPRESSION_TYPE
{
   IMPTYPE_LP  = 0x00,       // Live-scan plain
   IMPTYPE_LR  = 0x01,       // Live-scan rolled
   IMPTYPE_NP  = 0x02,       // Nonlive-scan plain
   IMPTYPE_NR  = 0x03,       // Nonlive-scan rolled
   IMPTYPE_L_I = 0x04,       // Latent impression
   IMPTYPE_L_T = 0x05,       // Latent tracing
   IMPTYPE_L_P = 0x06,       // Latent photo
   IMPTYPE_L_L = 0x07,       // Latent lift
   IMPTYPE_SW  = 0x08,       // swipe
   IMPTYPE_LCL = 0x09        // Live-scan contactless
};

// Finger position codes
enum FINGERS
{
   FINGPOS_UK     =  POS_CODE_U_FINGER  ,     // Unknown finger
   FINGPOS_RT     =  POS_CODE_R_THUMB   ,     // Right thumb
   FINGPOS_RI     =  POS_CODE_R_INDEX_F ,     // Right index finger
   FINGPOS_RM     =  POS_CODE_R_MIDDLE_F,     // Right middle finger
   FINGPOS_RR     =  POS_CODE_R_RING_F  ,     // Right ring finger
   FINGPOS_RL     =  POS_CODE_R_LITTLE_F,     // Right little finger
   FINGPOS_LT     =  POS_CODE_L_THUMB   ,     // Left thumb
   FINGPOS_LI     =  POS_CODE_L_INDEX_F ,     // Left index finger
   FINGPOS_LM     =  POS_CODE_L_MIDDLE_F,     // Left middle finger
   FINGPOS_LR     =  POS_CODE_L_RING_F  ,     // Left ring finger
   FINGPOS_LL     =  POS_CODE_L_LITTLE_F,     // Left little finger
   PALM           =  POS_CODE_U_PALM    ,              
};

#define MAX_WIDTH              (4 * 1024)   // maximum image width
#define MAX_HEIGHT             (4 * 1024)	  // maximum image height	

#pragma pack (push, _CORE_TIGHT)

// structure keeps information about RAW image
struct P_PACKED_1 RawImage
{
   WORD width;               // size of Scanned Image in x direction, pixels        
   WORD height;              // size of Scanned Image in y direction, pixels
   BYTE* image;              // pointer to RAW image. The raw image should be uncompressed, upright, 
                             // 8 bit per pixel, 500 DPI.       
   BYTE finger;              // fnger Position, 0...10 refer to ANSI/NIST standard 
   BYTE impression_type;

#ifdef __cplusplus
   RawImage()
   {
      width             = MAX_WIDTH;
      height            = MAX_HEIGHT;
      image             = 0;
      finger            = FINGPOS_UK;
      impression_type   = IMPTYPE_LP;
   }
#endif
};

// structure keeps information about DIB image
struct P_PACKED_1 DIBImage
{
	BYTE* image;              // pointer to DIB image. The image should be uncompressed, upright, 
	// 8 bit per pixel, 500 DPI.       
	BYTE finger;              // finger Position, 0...10 refer to ANSI/NIST standard 
	BYTE impression_type;

#ifdef __cplusplus
   DIBImage()
	{
		image             = 0;
		finger            = FINGPOS_UK;
		impression_type   = IMPTYPE_LP;
	}
#endif
};


#pragma pack (pop)
#pragma pack(pop)

#ifdef __cplusplus
   } // extern "C"{
#endif

#endif // COMMON_H__



