/**************************************
				Moulds.h
	Templates for some parameters.

			Author Gudkov V.U.
***************************************/

//	Header project file
#include		"wizard73.h"

// Sentry
#if !defined (__MOULDS_73_H)
	#define __MOULDS_73_H

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

	//----------------------------------
	//	Issue for complicative object
	//----------------------------------

	//	Verify equal coordinates
	template <class A,class B> 
	inline uint	Tequal( A &dst,B &src )
	{
		return dst.Movx == src.Movx &&
				 dst.Movy == src.Movy;
	}

	//	Get distance between dst and src
	template <class A,class B> 
	inline uint	Tdists( A &dst,B &src )
	{
		return dist( dst.Movx,dst.Movy,
						 src.Movx,src.Movy );
	}

	//	Get direction from src to dst
	template <class A,class B> 
	inline int	Tdirec( A &dst,B &src )
	{
		return atan( dst.Movx-src.Movx,
						 dst.Movy-src.Movy );
	}

	//	Turn beta(src) to beta(dst)
	template <class A,class B>
	inline int	Tturns( A &dst,B &src )
	{
		return turn( dst.Beta << 1,
						 src.Beta << 1 );
	}

	//	Turn beta(src) to dst orientation
	template <class A,class B>
	inline int	Trotat( A dst,B &src )
	{
		return turn( dst,//as original
						 src.Beta << 1 );
	}

	//	Turn beta(src) to dst orientation
	template <class A,class B>
	inline int	Tphase( A dst,B &src )
	{
		return simu( dst,//as original
						 src.Beta << 1 );
	}

	//	Add beta(src) and dst angle
	template <class A,class B> 
	inline int	Talpha( A dst,B &src )
	{
		return upci( dst+//add original
					  ( src.Beta << 1));
	}

	//	Turn beta(src) to direction from src to dst
	template <class A,class B> 
	inline int	Tcompl( A &dst,B &src )
	{
		return turn( Tdirec( dst,src ),
						 src.Beta << 1 );
	}

	//	Get order of object of this type
	template <class A>
	inline int	Torder( A src[],int size,int type,int num = 0 )
	{
		//look over the list of objects
		for (int i = 0,n = 0; i < size; i++)
		{
			//if native object type
			if (src[i].Type == type)
			{
				if (n == num)
					return i;
				else
					n++;//next
			}
		}

		//nothing
		return -1;
	}

	//	Get number of object of this type
	template <class A>
	inline int	Tcubic( A src[],int size,int type )
	{
		//look over the list of objects
		int i = 0,n = 0;
		for (; i < size; i++)
		{
			//if native object type
			if (src[i].Type == type) 
			{
				n++;
			}
		}

		//quantity
		return  n;
	}

	//	Copy the list of objects
	template <class A>
	inline void	Tocopy( A dst[],A src[],int size )
	{
		//look over the list of objects
		for (int i = 0; i < size; i++)
		{
			dst[i] = src[i];
		}
	}

	//	Find maximum x
	template <class A>
	inline int	Tmax_x( A *src,int size )
	{
		//look over the hole list of objects
		int i = 0,x = 0;
		for (; i < size; i++)
		{
			if (x < src[i].Movx)
				 x = src[i].Movx;
		}

		//maximum
		return x;
	}

	//	Find maximum y
	template <class A>
	inline int	Tmax_y( A *src,int size )
	{
		//look over the hole list of objects
		int i = 0,y = 0;
		for (; i < size; i++)
		{
			if (y < src[i].Movy)
				 y = src[i].Movy;
		}

		//maximum
		return y;
	}

	//	Find maximum y
	template <class A>
	inline int	Tmax_l( A *src,int size )
	{
		//look over the hole list of objects
		int i = 0,y = 0;
		for (; i < size; i++)
		{
			if (y < src[i].Lace)
				 y = src[i].Lace;
		}

		//maximum
		return y;
	}

	//----------------------------------
	//	Flow proccessing
	//----------------------------------

	//	Get flow argument
	template <class A,class B,class C>
	inline void	Targum( A rev,A imv,B dir,C org)
	{
		//finds in every real multitude
		for (int i = 0; i < _DIR_; i++)
		{
			//is data collected?
			if(rev[i] || imv[i])
				dir[i] = atan( rev[i],imv[i] )/2;
			else
				dir[i] = *org;
		}
	}

	//	Get flow module
	template <class A,class B,class C>
	inline void	Tmodul( A rev,A imv,B mod,C apw)
	{
		//finds in every real multitude
		for (int i = 0; i < _DIR_; i++)
		{
			//is data collected?
			if(apw[i])
				mod[i] = dist( rev[i]/apw[i],
									imv[i]/apw[i] )/1;
			else
				mod[i] = 0;
		}
	}

	//	Measure curve direction
	template <class A,class B>
	inline void	Tcurve( A flow,B goal,B mode )
	{
		if (ROT( flow[0],*mode,flow[4] ) > 0)
			*goal = upci( *mode+AR )/2;
		else
			*goal = upci( *mode-AR )/2;
	}

	//	Measure curvature value
	template <class A,class B>
	inline void	Tcrook( A flow,B goal,B mode )
	{
		*goal = cone( *mode,flow[4] )+
				  cone( *mode,flow[0] );
	}

	//	Reset any buffer
	template <class A>
	inline void	Treset( A dst,int val = 0)
	{
		for (int i  = 0; i < _DIR_; i++)
			  dst[i] = val;
	}

	//	Get buffer power
	template <class A>
	inline int	Tpetel( A dst,int val = 0)
	{
		for (int  i = 0; i < _DIR_; i++)
			if(dst[i]) val++;

		//the power
		return val;
	}

	//	Get weight of petals
	template <class A,class B>
	inline void	Tlevel( A dst,B pow )
	{
		//get average level
		for (int i = 0; i < _DIR_; i++)
		{
			//if exist
			if(pow[i])
			{
				dst[i] /= pow[i];
			}
		}
	}

	//	Recognize focuses
	template <class A>
	inline int	Tfocus( A src, bool quick )
	{
		//recognize probability local focus area
		int j = 0,rot = 0, t = 0;
		for (; j < _DIR_; j++)
		{
			t = scis( src[updi(j+1)],src[j] );
         if (quick)
         {
            if (ABS(t) < 89)
               rot += t;
            else
               return 0;
         }
         else
            rot += t;
		}

		//focus type
		return  rot;
	}

	//	Recognize focuses
	template <class A, class B>
	inline void	Trecog_StIndi(A dst, B focus_type )
	{
		switch(focus_type)
		{
			case +AF: *dst = FW;
						 break;
			case +AH: *dst = FL; 
						 break;
			case -AH: *dst = FD;
						 break;
			default : *dst = FN;
						 break;
		}
	}
	template <class A,class B>
	inline void	Trecog( A dst,B src, bool quick )
	{
		switch( Tfocus (src, quick ))
		{
			case +AF: *dst = FW;
						 break;
			case +AH: *dst = FL; 
						 break;
			case -AH: *dst = FD;
						 break;
			default : *dst = FN;
						 break;
		}
	}

	//	Carry out oscillation
	template <class A,class B>
	void	Toscil( A flow,B supp,B type,B beta,B orie = 0)
	{
		int inc = 2,
			 beg,
			 end;

		//check focus type
		switch (*type)
		{
			case FD:	beg = (orie) ? -12 :110;
						end = (orie) ? +12 :254;
						break;
			case FL:	beg = (orie) ? -16 :  0;
						end = (orie) ? +16 :360;
						break;
			case FW:	beg = (orie) ? -90 :268;
						end = (orie) ? +90 :448;
						break;
			default:	return;   //can't work !
		}

		int dir = (orie) ? *orie*2:
								  TIPDIR;
		int tet = upci( dir +beg );
		int cnt = ( end-beg )/inc ;

		//define focal orientation
		for (int minim = EVK(AF); cnt--; tet = upci( tet+inc ))
		{
			//get model disbalance while rotate model
			int i = 0,error = 0;
			for (; i < _DIR_; i++)
			{
				int loc = flow[ updi( i+(tet+AC- *supp)/AQ )];

				//gather error
				switch (*type)
				{
					case FD:	error += cone( Delta[i]+tet,loc );
								break;
					case FL: error += cone( Loops[i]+tet,loc );
								break;
					case FW:	error += cone( Whorl[i]+tet,loc );
								break;
				}
			}

			//selects the best
			if (error < minim)
			{
				//best tether
				*beta = tet/2;
				minim = error;
			}
		}
	}

	//	Relax yokes model flow
	template <class A,class B,class C>
	void Trelax( A flow,B vict,C mode, bool quick)
	{
		int focus = Tfocus(flow, quick);
		//finds in every real multitude
		for (int i = 0,opt = EVK(AF),arg = *vict; i < _DIR_; i++)
		{
			//extract all petal's flower
			int  fwd = flow[i], bck = flow[updi(i + 4)],
				 dir = ARC(fwd,	arg, bck);
            //a next sector argument
			 arg = upci(arg + AQ);

			//measure an arch parameters
			int rot = ROT(flow[updi(i+1)], flow[updi(i+2)], flow[updi(i+3)]),
				ang = MAX(cone(fwd, dir), cone(bck, dir)),
				dis = EVK(DIS(fwd, dir, bck));

			switch(focus)
			{
				case +AF:
				case +AH:	ang += 4*rot;
								break;
				case -AH:	ang -= rot/4;
								break;
				default :	ang += 1*dis;
								break;
			}
			//find optimum
			if(opt >= ang)
			{
                opt  = ang; *mode = dir;
			}
		}
	}
	template <class A, class B, class C, class D>
	void Trelax_StIndi(A flow, B vict, C mode, D focus_type)
	{
		//finds in every real multitude
		for (int i = 0,opt = EVK(AF),arg = *vict; i < _DIR_; i++)
		{
			//extract all petal's flower
			int  fwd = flow[i], bck = flow[updi(i + 4)],
				 dir = ARC(fwd,	arg, bck);
            //a next sector argument
			 arg = upci(arg + AQ);

			//measure an arch parameters
			int rot = ROT(flow[updi(i+1)], flow[updi(i+2)], flow[updi(i+3)]),
				ang = MAX(cone(fwd, dir), cone(bck, dir)),
				dis = EVK(DIS(fwd, dir, bck));

			switch(focus_type)
			{
				case +AF:
				case +AH:	ang += 4*rot;
								break;
				case -AH:	ang -= rot/4;
								break;
				default :	ang += 1*dis;
								break;
			}
			//find optimum
			if(opt >= ang)
			{
                opt  = ang; *mode = dir;
			}
		}
	}
	//----------------------------------
	//	Harmon proccessing
	//----------------------------------

	//	Find the spectrum density
	template <class A>
	inline void	Tmodah( A spec, byte* goal, byte* harm  = 0, bool quick = false)
	{
		//a local
		if (harm)
		{
         int h = *harm - (quick? HL_Q : HL);

			if(h < _HAR_-1 && spec[h] < spec[h+1])
			{ *goal = 0; return; }
			if(h > 0 && spec[h] < spec[h-1])
				*goal = 0;
		}
		else
		{
			int final_i = -1;
			//scan restricted spectrum list...
			for(int i = 0,amax = 0; i < _HAR_; i++)
			{
				//finds best harmon
				if(amax < spec[i])
				{
					//*goal = HL + i ;
					final_i = i;
					amax = spec[i];
				}
			}
			if(final_i != -1) *goal = (quick? HL_Q : HL) + final_i;
		}
	}

	//	Find local spectrum amplitude
	template <class A>
	inline void	Tmodam( A spec, byte* goal, byte* harm = 0, bool quick = false )
	{
		//a local
		if (harm)
			*goal = spec[*harm-(quick? HL_Q : HL)];
		else
		//scan restricted spectrum list...
		for (int i = 0,amax =-1; i < _HAR_; i++)
		{
			//finds the maximum
			if (amax < spec[i])
			{
				*goal =
				 amax	= spec[i];
			}
		}
	}

	//----------------------------------
	//	Bits proccessing
	//----------------------------------

	//	Classify center
	template <class A>
	void	Tmidst( A bits,int *inna,int *outa )
	{
		//verify
		if(bits)
			*inna = 0;
		else
			*inna = 1;
	
			//outward
			*outa = 0;
	}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */

#endif
