/*****************************************************************************
	ma100_TT.h - header file for TP-TP matching algorithm (MA) of Core Matching SDK
                using ma100 algorithm
*******************************************************************************/
#ifndef MA_100_H_TT_
#define MA_100_H_TT_

#include "coreSdk.h"
#include "core_err.h"


namespace accelMatch{
#pragma pack(push,_CORE_PACKING)

/******************************************************************
          Matching Algorithm class
******************************************************************/
class Compare100_TT;

class Ma100_TT
{
	Compare100_TT     *m_compare;
   bool               m_isProbeLoaded;
   bool               m_init;

public:
	Ma100_TT();
  ~Ma100_TT();

	/* 
	 Initialize work with Ma100_TT class functions
	 This function should be called before call any other function of this class
	 Function returns MA_OK - if function succeeds, error code - otherwise
	*/
	int init();
   /* 
      Initialize work with Ma100_TT class
      In differ from 'init' function it take the protection data
      This function (or 'init' function)should be called first before call 
      any other functions
      Parameters:
      protect      (input) - pointer to the buffer with protection data
      Return value:
      The function returns MA_OK - if function succeeds, error code - otherwise
   */
   int initEx (int protect[MAX_PROTECT_LEN]);

 	/*
	Compares two TP
	function returns MA_OK - if function succeeds, error code - otherwise
	param         (input)  - search parameters
	probe         (input)  - probe TP
	gallery       (input)  - gallery TP
   matchResultTT (output) - the result of TP-TP matching
   typeP         (input)  - type of probe fingerprints
   typeG         (input)  - type of gallery fingerprints
	*/
	int matchTT (SearchParam &param, TpTemplate &probe, TpTemplate &gallery, MatchResultTT &matchResultTT, 
                  FP_TYPE typeP = UNKNOWN, FP_TYPE typeG = UNKNOWN);

 	/*
	load TP for future compare it with anoter TP by 'matchTTex' of 'matchEx' functions
	function returns MA_OK - if function succeeds, error code - otherwise
	probe       (input)  - probe TP
	*/
	int loadTT (TpTemplate &probe, FP_TYPE typeP = UNKNOWN);
 	/*
	Compares TP with another TP that was earlier loaded by 'loadTT' finction
	function returns MA_OK - if function succeeds, error code - otherwise
	param         (input)  - search parameters
   gallery       (input)  - gallery TP
   matchResultTT (output) - the result of TP-TP matching
   typeG         (input)  - type of gallery fingerprints
	*/
	int matchTTex (SearchParam &param, TpTemplate &gallery, MatchResultTT &matchResultTT, FP_TYPE typeG = UNKNOWN);

   /*
	Perfrom TP-TP identification 
	function returns MA_OK - if function succeeds, error code - otherwise
   param       (input)  - parameter of matching  
   probe       (input)  - probe TP 
   gallery    	(input)  - array of gallery TP
   gallerySize (input)  - size of gallery array
   rl          (input)  - pointer to recommended list array. Memory should be allocated in application
   sizeRl      (input)  - size of recommended list array 
   typeP       (input)  - type of probe fingerprints
   typeG       (input)  - type of gallery fingerprints
	*/
	int identifyTT (SearchParam &param, TpTemplate &probe, TpTemplate *gallery, unsigned int gallerySize, RL *rl, unsigned int sizeRl,
                  FP_TYPE typeP = UNKNOWN, FP_TYPE typeG = UNKNOWN);

};

#pragma pack(pop)
} // namespace accelMatch
#endif // MA_100_H_TT_

