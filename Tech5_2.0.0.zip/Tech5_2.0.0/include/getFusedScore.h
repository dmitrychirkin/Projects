#ifndef GET_FUSED_SCORE_H
#define GET_FUSED_SCORE_H

#include <stdlib.h>
#include "sfsDef.h"

#pragma pack(push, _CORE_PACKING)

static inline int compareScores (const void *val1, const void *val2) 
{
   return (*(int*)val2 - *(int*)val1);  
} 

// for matching minex version
inline int getFusedScore_minex (unsigned int numItems, unsigned int numRealScore, int *sim) 
{
	if (!sim)
		return -1;
   int score[10];
   memcpy(score, sim, sizeof(score[0]) * numItems);
	int fusedScore = 0;
   if      (numRealScore == 0) return 0;
   else if (numRealScore == 1) return score[0];

   qsort(score, numItems, sizeof(score[0]), compareScores); 
	for(unsigned int i = 0; i < numRealScore; i++)
      fusedScore += score[i];

   fusedScore /= numRealScore;
	if (fusedScore > MAX_SCORE)
		fusedScore = MAX_SCORE;
	return fusedScore;
}


// for matching version 73 (ma)
inline int getFusedScore_73 (unsigned int numItems, unsigned int numRealScore, int *sim) 
{
	if (!sim)
		return -1;
   int score[10];
   memcpy(score, sim, sizeof(score[0]) * numItems);
   qsort(score, numItems, sizeof(score[0]), compareScores); 
   if      (numRealScore == 0) return 0;
   else if (numRealScore == 1) return score[0];
   else if (numRealScore == 2) return (score[0] + score[1]) / 2;
   else if (numRealScore == 3) return (score[0] + score[1] + score[2]) / 3;

	int fusedScore = 0;
   if (numRealScore > 4) numRealScore = 4;
   for(unsigned int i = 0; i < numRealScore; i++)
	{
		switch (int(score[i]  / 1000))
		{
		case 10:
		case 9:
		case 8:
		case 7:
		case 6:
		case 5:
		case 4:
		case 3:
		case 2:
		case 1:
			fusedScore += score[i];
			break;
		case 0:
			fusedScore += score[i] / 2;
			break;
      default:
         break;
		}
	}
   fusedScore /= numRealScore;
   if (fusedScore > MAX_SCORE)
		fusedScore = MAX_SCORE;

	return fusedScore;
}




// for matching version 100 (ma100)
inline int getFusedScore_100 (unsigned int numItems, unsigned int numRealScore, int *sim) 
{
	if (!sim)
		return -1;
   int score[10];
   memcpy(score, sim, sizeof(score[0]) * numItems);
   qsort(score, numItems, sizeof(score[0]), compareScores); 
   if      (numRealScore == 0) return 0;
   else if (numRealScore == 1) return score[0];

   int fusedScore = 0;
   int k_score_2  [] = {52, 48};
   int k_score_3  [] = {45, 40, 15};       
   int k_score_4  [] = {30, 30, 30, 10};  

   int k_score[10];
   memset (k_score, 0, sizeof(k_score));
   if      (numRealScore == 2) memcpy (k_score, k_score_2 , sizeof(k_score_2));
   else if (numRealScore == 3) memcpy (k_score, k_score_3 , sizeof(k_score_3));
   else                        memcpy (k_score, k_score_4 , sizeof(k_score_4));

   for(unsigned int i = 0; i < numRealScore; i++)
			fusedScore += score[i] * k_score[i] / 100;

   if (fusedScore > MAX_SCORE)
		fusedScore = MAX_SCORE;
	return fusedScore;
}



// for accelMatch matching optimized for CMC curve
inline int getFusedScore_accel (unsigned int numItems, unsigned int numRealScore, int *sim) 
{
	if (!sim)
		return -1;
   int score[10];
   memcpy(score, sim, sizeof(score[0]) * numItems);
   qsort(score, numItems, sizeof(score[0]), compareScores); 
   if      (numRealScore == 0) return 0;
   else if (numRealScore == 1) return score[0];

   int fusedScore = 0;
   int k_score_2  [] = {220, 40       }; 
   int k_score_3  [] = {195, 39, 26   };
   int k_score_4  [] = {220, 26, 14, 0};

   int k_score[10];
   memset (k_score, 0, sizeof(k_score));
   if      (numRealScore == 2) memcpy (k_score, k_score_2 , sizeof(k_score_2));
   else if (numRealScore == 3) memcpy (k_score, k_score_3 , sizeof(k_score_3));
   else                        memcpy (k_score, k_score_4 , sizeof(k_score_4));

   for(unsigned int i = 0; i < numRealScore; i++)
	{
		switch (score[i]  * 10 / MAX_SCORE)
		{
		case 10:
		case 9:
		case 8:
		case 7:
		case 6:
		case 5:
		case 4:
			fusedScore += score[i] * k_score[i] / 256;
			break;
		case 3:
		case 2:
			fusedScore += score[i] * k_score[i] * 38 / 256 / 64;
			break;
		case 1:
			fusedScore += score[i] * k_score[i] * 19 / 256 / 64;
			break;
		case 0:
			break;
      default:
         break;
		}
	}

   if (fusedScore > MAX_SCORE)
		fusedScore = MAX_SCORE;
	return fusedScore;
}




#pragma pack(pop)

#endif // GET_FUSED_SCORE_H