/*************************************************************************
   fileUtils.h: - declaration of utilites for work with files
 

   Author A.Mosunov
   Version 1.0 from 25.09.2004
*************************************************************************/
//////////////////////////////////////////////////////////////////////
#ifndef FILE_UTILS_H
#define FILE_UTILS_H

#include <string>
#ifdef _WINDOWS
#include <tchar.h>
#endif
#include "common.h"

#pragma pack(push, _CORE_PACKING)

#define FU_OK                0       // success
#define FU_OPEN             -1       // cannot open the specified file
#define FU_READ             -2       // read file errror
#define FU_MORE_DATA		    -3       // the size of the buffer is not large enough	
#define FU_WRITE  		    -4       // error write to file
#define FU_WRONG_POINTER    -5       // one or more of pointers passed to the function is NULL
#define FU_NOT_OPEN         -6       // pointer to not opened file was passed to the function

/*
   get length of opened file f
   return FU_OK if success or error code otherwise
   f   - pointer to the open file
   len - pointer to variable that received length of file
*/
int getFileLen(FILE *f, size_t& len);

/*	
   read len bytes from opened file into buffer
	return FU_OK if success or error code otherwise
	memory for the buffer should be allocated befor function call
   f      - pointer to the open file
	buffer - buffer where file will be read
	size   - before function call it contains the size of the buffer, after function call 
	         it contains the real size of data that were read
   len - number of bytes thouse should be read
*/
int readFileContent(FILE *f, unsigned char *buffer, size_t *size, size_t len); 

/*
	read file filename into buffer
	return FU_OK if success or error code otherwise
	memory for the buffer should be allocated befor function call
	buffer - buffer where file will be read
	size   - before function call it contain the size of the buffer, after function call 
	         it contain the length of the file
*/
int readFile(const wchar_t *filename, unsigned char *buffer, size_t *size);
int readFile(const char *filename, unsigned char *buffer, size_t *size);

// save image to BMP with add padding at the end of each row 
// (if width % 4 != 0)
#ifdef _WINDOWS
bool save2BmpP(TCHAR* filename, const unsigned char *image, unsigned int width, 
			  unsigned  int height);

// save image to bmp (image is copy as is)
bool save2Bmp(TCHAR* filename, const unsigned char *image, unsigned int width, 
			  unsigned  int height);
#endif
bool createDib (unsigned char **dib, const unsigned char *image, int width, int height);

#if defined(_WINDOWS) && !defined(_WIN32_WCE)
/*
	write data from buffer to file. If file does not exist the function create it. 
	If the directory, that include in the full path, does not exist - function create it also
	Parameters:
	name - full path to the file
	buffer - data that should be copy to file
	size - size of the data shat should be write to the file
	Return value:
	true if function successfull and else otherwise
*/
bool saveFileDir (std::string &name, unsigned char* buffer, DWORD size);
bool saveFileDir (std::wstring &name, unsigned char* buffer, DWORD size);
//bool saveFileDir (std::basic_string<TCHAR> &name, unsigned char* buffer, unsigned int size);
#endif

// save binary data to file
int saveFile (char *name, unsigned char *buffer, size_t size);
int saveFile (const char *name, unsigned char *buffer, size_t size);
int saveFile (wchar_t *name, unsigned char *buffer, size_t size);
int saveFile (const wchar_t *name, unsigned char *buffer, size_t size);

/*
   get length of opened file f
   return FU_OK if success or error code otherwise
   f   - pointer to the open file
   len - pointer to variable that received length of file
*/
int getFileLen(FILE *f, size_t& len); 

/*	
   read len bytes from opened file into buffer
	return FU_OK if success or error code otherwise
	memory for the buffer should be allocated befor function call
   f      - pointer to the open file
	buffer - buffer where file will be read
	size   - before function call it contains the size of the buffer, after function call 
	         it contains the real size of data that were read
   len - number of bytes thouse should be read
*/
int readFileContent(FILE *f, unsigned char *buffer, size_t *size, size_t len);


/*
	read file filename into buffer
	return FU_OK if success or error code otherwise
	memory for the buffer should be allocated befor function call
   f      - pointer to the open file
	buffer - buffer where file will be read
	size   - before function call it contains the size of the buffer, after function call 
	         it contains the real size of data that were read
*/
int readFromFile(FILE *f, unsigned char *buffer, size_t *size); 


#pragma pack(pop)

#endif // FILE_UTILS_H

