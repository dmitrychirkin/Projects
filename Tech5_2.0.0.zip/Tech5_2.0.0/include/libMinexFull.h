/*
The main header file for libminex library
Libminex library is implemented the TECH5 algorithm
that is compliance with API specification for minex ongoing test

*/

#ifndef TECH5_LIB_MINEX_FULL_H_
#define TECH5_LIB_MINEX_FULL_H_

#include "coreSdk.h"
#include "libminex.h"

#pragma pack(push, _CORE_PACKING)

#define MAX_FINGERS                   10  // maximum number of fingers that should be put into template in this version of software

#define SME_DIF_FING                1000  // Two compared templates keep information about different fingers, 
                                          //  so nothing was matched   
#define SME_SAME_FING               1001  // array of rawImage structure has members with same value of 
                                          // 'finger' field   
                                          // NOTE: At this version of software you cannot put into template the information 
                                          //  about more than one impression of same finger. 
#define SME_NULL_IMAGE              1002  // passed image has zero size or pointer to the image is NULL  
#define SME_PARSE_TEMPL             1003  // error of parse template
#define SME_DIF_FING_SIZE           1004  // fingerprint images have different size. 
                                          // NOTE: The fingerprint images those are passed to 'create_NIST_template' or 
                                          // 'create_ISO_template' function should be taken from the same sensor 
                                          // and have the same size 
#define SME_SMALL_REQUIRED_SIZE     1005  // required template size is too small


#ifdef __cplusplus
extern "C" { 	
#endif  

/*
	The function allocates memory for buffer that will receives INCITS 378 compliance template
	Parameters:
   numFingers (input)       : number of fingers informations about those will be put into template
                              (one view per finger). Cannot be more than MAX_FINGERS   
                              NOTE: At this version of software template can keeps information about 
                              up to two fingers.
	nistTempl  (input/output): buffer for INCITS 378 compliance template
	Return value:
   The function returns SME_OK if success and error code otherwise. 
*/
int __cdecl allocateNISTtemplate (unsigned int numFingers, BYTE **nistTempl);

/*
	The function allocates memory for buffer that will receives ISO 19794-2 compliance template
	Parameters:
   numFingers (input)       : number of fingers informations about those will be put into template
                              (one view per finger). Cannot be more than MAX_FINGERS   
                              NOTE: At this version of software template can keeps information about 
                              up to two fingers.
	isoTempl  (input/output): buffer for ISO 19794-2 compliance template
	Return value:
   The function returns SME_OK if success and error code otherwise. 
   NOTE: At this version of software template can keeps information about up to two fingers
*/
int __cdecl allocateISOtemplate (unsigned int numFingers, BYTE **isoTempl);

/*
	The function frees memory that was allocated by 'allocateNISTtemplate' function
	Parameters:
	templ (input) - buffer for template
	Return value:
   The function returns SME_OK if success and error code otherwise. 
*/
int __cdecl freeNISTtemplate (BYTE **templ);

/*
	The function frees memory that was allocated by 'allocateISOtemplate' function
	Parameters:
	templ (input) - buffer for template
	Return value:
   The function returns SME_OK if success and error code otherwise. 
*/
int __cdecl freeISOtemplate (BYTE **templ);


/*
   Function converts TECH5 template into ANSI INCITS 378 compliance template 
   Parameters:
   fpTemplate      (input) : the TECH5 template  
   nistTemplate    (output): the INCITS 378 compliance template
                             Memory for it should be allocated in application 
                             (you can use allocateNISTtemplate function)
   Retrun value:
   The function returns SME_OK if success and error code otherwise. 
   In case of failure the null template will be output.
*/
int __cdecl convertToNIST (BYTE *fpTemplate, BYTE *nistTemplate);

/*
   Function converts TECH5 template into ISO 19794-2 compliance template 
   Parameters:
   fpTemplate      (input) : the TECH5 template  
   nistTemplate    (output): the ISO 19794-2 compliance template. 
                             Memory for it should be allocated in application 
                             (you can use allocateISOtemplate function)
   Retrun value:
   The function returns SME_OK if success and error code otherwise. 
   In case of failure the null template will be output.
*/
int __cdecl convertToISO (BYTE *fpTemplate, BYTE *isoTemplate);


/*
   The function takes a raw image as input and outputs the corresponding ANSI INCITS 378 
   compliant template. 
   Parameters:
   numFingers      (input) : number of source images. Cannot be more than MAX_FINGERS   
   rawImage        (input) : array of raw image structure, that contains information
                             about source fingerprint images 
   templ           (output): The processed ISO 19794-2 compliant template.
                             Memory for it should be allocated in application 
                             (you can use allocateNISTtemplate function)
   templSize       (output): The pointer to variable that receives the size of template
   quality_out     (output): array of image quality, that was put in template. Memory for it should be allocated in application  
   maxTemplateSize (input) : the maximum size of template. If size of template is more than this value,
                             then some of minutiae will be eliminated from template to satisfy this parameter.
                             If it's 0, then all minutiae will be put into template. 
   quality_in      (input) : array of image quality. If it's NULL, quality will be calculated from source image 
   certifiedSensor (input) : is capture equipment comply with IQS (EFTS, Appendix F)?
   sensorID        (input) : Capture Equipment ID. The vendor determines the value for this field.
                             Applications developers may obtain the values for these codes from the vendor.
   Retrun value:
   The function returns SME_OK if success and error code otherwise. 
   In case of failure the null template will be output.
*/
int __cdecl create_NIST_template (unsigned int    numFingers, 
                                  RawImage      * rawImage, 
                                  unsigned char * templ, 
                                  unsigned int  * templSize,
                                  unsigned char * quality_out,
                                  unsigned int    maxTemplateSize = 0, 
                                  unsigned char * quality_in      = NULL, 
                                  bool            certifiedSensor = false, 
                                  WORD            sensorID        = 0        );
/*
   The function takes a raw image as input and outputs the corresponding ISO 19794-2 
   compliant template. 
   Parameters:
   numFingers      (input) : number of source images. Cannot be more than MAX_FINGERS   
   rawImage        (input) : array of raw image structure, that contains information
                             about source fingerprint images 
   templ           (output): The processed ANSI INCITS 378 compliant template.
                             Memory for it should be allocated in application 
                             (you can use allocateISOtemplate function)
   templSize       (output): The pointer to variable that receives the size of template
   quality_out     (output): array of image quality, that was put in template. Memory for it should be allocated in application  
   maxTemplateSize (input) : the maximum size of template. If size of template is more than this value,
                             then some of minutiae will be eliminated from template to satisfy this parameter.
                             If it's 0, then all minutiae will be put into template. 
   quality_in      (input) : array of image quality. If it's NULL, quality will be calculated from source image 
   certifiedSensor (input) : is capture equipment comply with IQS (EFTS, Appendix F)?
   sensorID        (input) : Capture Equipment ID. The vendor determines the value for this field.
                             Applications developers may obtain the values for these codes from the vendor. 
   Retrun value:
   The function returns SME_OK if success and error code otherwise. 
   In case of failure the null template will be output.
*/
int __cdecl create_ISO_template (unsigned int numFingers, 
                                 RawImage      *rawImage, BYTE *templ, 
                                 unsigned int  *templSize, 
                                 unsigned char *quality_out,                                 
                                 unsigned int  maxTemplateSize = 0, 
                                 BYTE         *quality_in = NULL, 
                                 bool          certifiedSensor = false, 
                                 WORD          sensorID = 0);


/*
   The function compares two ANSI INCITS 378 compliant templates and outputs a match score. 
   Parameters:
   probeTemplate    (input) : the first  ANSI INCITS 378 compliant template
   galleryTemplate  (input) : the second ANSI INCITS 378 compliant template
   maxAngle         (input) : a fingerprint rotation angle tolerance, degree 
   score            (output): pointer to variable that receive a match score in a range 0...MAX_SCORE
   Retrun value:
   The function returns SME_OK if success and error code otherwise. 
   NOTE: At this version of software templates (probeTemplate and galleryTemplate) can keeps information about 
         two fingers
*/
int __cdecl match_NIST_templates (const BYTE *probeTemplate, const BYTE *galleryTemplate,
                     int maxAngle, int *score);

/*
   The function compares two ISO 19794-2 compliant templates and outputs a match score. 
   Parameters:
   probeTemplate    (input) : the first ISO 19794-2 compliant template
   galleryTemplate  (input) : the second ISO 19794-2 compliant template
   maxAngle         (input) : a fingerprint rotation angle tolerance, degree 
   score            (output): pointer to variable that receive a match score in arange 0...MAX_SCORE
   Retrun value:
   The function returns SME_OK if success and error code otherwise. 
   NOTE: At this version of software templates (probeTemplate and galleryTemplate) can keeps information about 
         two fingers
*/
int __cdecl match_ISO_templates (const BYTE *probeTemplate, const BYTE *galleryTemplate,
                     int maxAngle, int *score);


/*
   The function compares two ANSI INCITS 378 or ISO 19794-2 compliant templates and outputs a match score. 
   Parameters:
   probeTemplate    (input) : the first ANSI INCITS 378 or ISO 19794-2 compliant template
   galleryTemplate  (input) : the second ANSI INCITS 378 or ISO 19794-2 compliant template
   maxAngle         (input) : a fingerprint rotation angle tolerance, degree 
   nistTemplates    (input) : if true - probe and gallery templates should be in ANSI INCITS 378 format 
                              if else - probe and gallery templates should be in ISO 19794-2 format   
   matchResult      (output): array of matching result details for all possible pair of finger views 
                              those can be mathced
   score            (output): pointer to variable that receive a match score in a range 0...MAX_SCORE
   Return value:
   The function returns SME_OK if success and error code otherwise. 

   NOTE1: both (probe and gallery) templates should be in same format (either ANSI or ISO)
   NOTE2: At this version of software templates (probeTemplate and galleryTemplate) can keeps information about 
         two fingers
*/
int __cdecl match_templatesEx (const BYTE *probeTemplate, const BYTE *galleryTemplate, int maxAngle,
                       MatchResult matchResult[MAX_FINGERS][MAX_FINGERS], bool nistTemplates, 
                       int *score);


/*
   Reads information from ANCI INCITS 378 template
   Parameters:
   numFingers   (input/output) : the variable that contains:
                                 - maximum number of finger view for reading before 
                                   function call(cannot be more than MAX_FINGERS)
                                 - number of read finger views after  function call
   templ        (input)        : the ANSI INCITS 378 compliant template
   numMinutiae  (output)       : array of minutiae numbers
   minutiae     (output)       : array of minutiae 
   width        (output)       : the variable that receives image width
   height       (output)       : the variable that receives image height
   quality      (output)       : array the image quality
   finger       (output)       : array finger positions 
   Return value:
   The function returns SME_OK if success and error code otherwise. 
*/
int __cdecl readNISTtemplate (unsigned int &numFingers,
                              const   BYTE *templ, 
                              BYTE          numMinutiae[MAX_FINGERS],
                              Minutiae      minutiae[MAX_FINGERS][MAX_MINUTIAE], 
                              WORD         &width, 
                              WORD         &height, 
                              BYTE          quality[MAX_FINGERS],
                              BYTE          finger [MAX_FINGERS]);

/*
   Reads information from ISO 19794-2 template
   Parameters:
   numFingers   (input/output) : the variable that contains:
                                 - maximum number of finger view for reading before 
                                   function call(cannot be more than MAX_FINGERS)
                                 - number of read finger views after  function call
   templ        (input)        : the ISO 19794-2 compliant template
   numMinutiae  (output)       : array of minutiae numbers
   minutiae     (output)       : array of minutiae 
   width        (output)       : the variable that receives image width
   height       (output)       : the variable that receives image height
   quality      (output)       : array the image quality
   finger       (output)       : array finger positions 
   Return value:
   The function returns SME_OK if success and error code otherwise. 
*/
int __cdecl readISOtemplate (unsigned int &numFingers, 
                      const BYTE *templ, BYTE numMinutiae[MAX_FINGERS],
                      Minutiae minutiae[MAX_FINGERS][MAX_MINUTIAE], 
                      WORD &width, WORD &height, BYTE quality[MAX_FINGERS],
                      BYTE finger[MAX_FINGERS]);

/*
   Save ANCI INCITS 378 template to file
   Parameters:
   name    (input) :  file name
   templ   (input) :  the INCITS 378 compliant template
   Return value:
   The function returns true if success and false otherwise. 
*/
bool __cdecl saveNISTtemplate (const char *name, const BYTE *templ);
/*
   Save ISO 19794-2 template to file
   Parameters:
   name    (input) :  file name
   templ   (input) :  the ISO 19794-2 compliant template
   Return value:
   The function returns true if success and false otherwise. 
*/
bool __cdecl saveISOtemplate (const char *name, const BYTE *templ);

/*
   Get size of INCITS 378 compliant template
   Parameters:
   templ (input) : the ANSI INCITS 378 compliant template
   Return value:
   size of INCITS 378 compliant template
*/
int __cdecl getNISTtemplateSize(const BYTE *templ);

/*
   Get size of ISO 19794-2 compliant template
   Parameters:
   templ (input) : the ISO 19794-2 compliant template
   Return value:
   size of ISO 19794-2 compliant template
*/
int __cdecl getISOtemplateSize(const BYTE *templ);


/*
   Reads information about finger position from ISO 19794-2 template
   Parameters:
   numFingers   (input/output) : the variable that contains:
                                 - maximum number of finger view for reading before 
                                   function call(cannot be more than MAX_FINGERS)
                                 - number of read finger views after  function call
   templ        (input)        : the ISO 19794-2 compliant template
   finger       (output)       : pointer to array finger positions. Memory should be allocated in application 
   Return value:
   The function returns SME_OK if success and error code otherwise. 
*/
int __cdecl getNumFingers_ISO (unsigned int &numFingers, const BYTE *templ, FINGERS *finger);

/*
   Reads information about finger position from ANCI INCITS 378 template
   Parameters:
   numFingers   (input/output) : the variable that contains:
                                 - maximum number of finger view for reading before 
                                   function call(cannot be more than MAX_FINGERS)
                                 - number of read finger views after  function call
   templ        (input)        : the ANSI INCITS 378 compliant template
   finger       (output)       : pointer to array finger positions. Memory should be allocated in application 
   Return value:
   The function returns SME_OK if success and error code otherwise. 
*/
int __cdecl getNumFingers_NIST (unsigned int &numFingers, const BYTE *templ, FINGERS *finger);


#ifdef __cplusplus
}  // extern "C" { 	
#endif  

#pragma pack(pop)

#endif //TECH5_LIB_MINEX_FULL_H_
