/*****************************************************************************
	ma100_accel_TT.h - header file for TP-TP matching algorithm 
                using in accelerator matching library for final mathcing
*******************************************************************************/
#ifndef MA_100_ACCEL_TT_H_
#define MA_100_ACCEL_TT_H_

#include "coreSdk.h"
#include "core_err.h"

namespace accelMatch{
#pragma pack(push,_CORE_PACKING)

/******************************************************************
          Matching Algorithm class
******************************************************************/
class Compare100_TT;

class Ma100_accel_TT
{
	Compare100_TT     *m_compare;
   bool               m_isProbeLoaded;
   bool               m_init;

public:
	Ma100_accel_TT();
  ~Ma100_accel_TT();

	/* 
	 Initialize work with Ma100_accel_TT class functions
    This function (or 'initEx' function)should be called first before call 
    any other functions
	 Function returns MA_OK - if function succeeds, error code - otherwise
    Parameters:
    accelHandle (input) - handle of accelerator library 
	*/
	int init(void *accelHandle);
	/* 
   Initialize work with Ma100_accel_TT class functions
   In differ from 'init' function it take the protection data
   This function (or 'init' function)should be called first before call 
   any other functions
   Parameters:
   accelHandle (input) - handle of sondaAccel library. If it's NULL, library will create it itself
   protect     (input) - pointer to MAX_PROTECT_LEN byte buffer with protection data
   Return value:
   The function returns MA_OK - if function succeeds, error code - otherwise
	*/
	int initEx(void *accelHandle, int protect[MAX_PROTECT_LEN]);


 	/*
	load TP for future compare it with anoter TP by 'matchTTex' of 'matchEx' functions
	function returns MA_OK - if function succeeds, error code - otherwise
	probe       (input)  - probe TP
   typeP       (input)  - type of probe fingerprint
   areaP       (input)  - array of bad areas for each probe finger. It can be NULL 
                          (in this case it will be calculated in the function)
   areaWidth   (input)  - array of bad area with   for each probe finger. It can be NULL (in this case it will be calculated in the function)
   areaHeight  (input)  - array of bad area height for earh probe finger. It can be NULL (in this case it will be calculated in the function)
	*/
	int loadTT (TpTemplate &probe, FP_TYPE typeP, BYTE **areaP, int *areaWidth, int *areaHeight);

   
   /*
	Compare fingerprint template with corresponded finger template
	that was earlier load by 'loadTT' function 
	function returns MA_OK - if function succeeds, error code - otherwise
	param          (input)  - the search parameters
	templG         (input)  - gallery fingerprint template for match  
   typeG          (input)  - type of gallery fingerprint
	similarity     (output) - variable that receives the value that shows 
				                  how two fingerprints similarity one to another in a range 0...MAX_SCORE
   fingerP        (input)  - probe finger number
	matchResult    (output) - the structure with match result details. 
                              If is is NULL, it not used.
   useCombineData (input)  - if true, information about pair of minutiae thouse was found on 
                             accelerator matching stage will be used in matching 
   np             (input) - array of probe   minutiae number that was found on accelerator matching stage
   ng             (input) - array of gallery minutiae number that was found on accelerator matching stage
   accelGroupSize (input) - size of np and ng arrays
	*/
	int	matchEx (SearchParam &param, BYTE *templG, FP_TYPE typeG, int &similarity, FINGERS fingerP, 
                  MatchResult *matchResult, 
                  bool useCombineData, BYTE *np, BYTE *ng, BYTE accelGroupSize, bool quickAccelMatch);

};

#pragma pack(pop)
} // namespace accelMatch
#endif //MA_100_ACCEL_TT_H_

