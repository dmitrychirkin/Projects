#ifndef	GET_HDD_SERIAL
#define	GET_HDD_SERIAL

#define  MAX_SERIAL_COUNT		20

#ifdef _WIN32_WCE
#define modificator __cdecl
#else
#ifdef _WINDOWS
#define modificator __cdecl
#else
#define modificator 
#endif // _WIN32
#endif // _WIN32_WCE

#ifdef __cplusplus
extern "C"
{
//	getAllHDDSerial gets hard disks's serial numbers
//	Parameters:
//	[out] serials - on success contains serial numbers of disks
//	Return value:
//	count of detected disks
//	int  __stdcall getAllHDDSerial (char	serials[MAX_IDE_DRIVES*MAX_DISCS_ON_DRIVES][MAX_SERIAL_COUNT]);

//	getHDDSerialByLetter gets hard disk serial numbers
//	Parameters:
//	[in] disk_letter - letter of disk ( i.e. "C", "D:", "P:\")
//	[out] serial - on success contains serial number of disk
//	Return value:
//	zero on fail and non-zero on success
//	Comments:
//	works under administrator's account
	int  modificator getHDDSerialByLetter (char* disk_letter, char	serial[MAX_SERIAL_COUNT]);
//	getHDDSerialByNumber gets hard disk serial numbers
//	Parameters:
//	[in] disk_physical_number - number of physical disk (0,1,2 etc.)
//	[out] serial - on success contains serial number of disk
//	Return value:
//	zero on fail and non-zero on success
	int  modificator getHDDSerialByNumber (int disk_physical_number, char	serial[MAX_SERIAL_COUNT]);
}
#endif // __cplusplus

#endif // GET_HDD_SERIAL
