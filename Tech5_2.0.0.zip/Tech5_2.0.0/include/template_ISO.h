/*
   template_ISO.h - declare function for work with template in 
   ISO 19794-2 format
*/
#ifndef TEMPLATE_ISO_H_
#define TEMPLATE_ISO_H_

#include "template_nist_iso.h"
#include "win2lin.h"
#include "coreSdk.h"
#include "transEndian.h"

#define MAX_ISO_MINUTIAE       255 // 128 by standard


#pragma pack(push, _CORE_TIGHT)

struct P_PACKED_1 ISO_viewHeader
{
   BYTE  m_position;                // Finger Position, 0...10 refer to ANSI/NIST standard
   BYTE  m_impressionType  : 4;     // Impression Type, 0...3 or 8
   BYTE  m_viewNumber      : 4;     // View Number, 0...15
   BYTE  m_quality;                 // Finger Quality 0...100
   BYTE  m_numMinutiae;             // Number of Minutiae
};

// Finger Minutiae Data
struct P_PACKED_1 ISO_minutiae
{
   WORD  m_x;           // The x coordinate of the minutia 
                        // (2 high bites - minutiae type)
   WORD  m_y;           // The y coordinate of the minutia 
                        // (2 high bites - reserved)
   BYTE  m_angle;       // The angle of the minutia, 0...255 resolution is 1.40625 degrees
   BYTE  m_quality;     // Minutia Quality  1...100 (0 indicates �quality not reported�)
};

// ISO 19794-2 record header
struct P_PACKED_1 ISO_header
{
   DWORD    m_formatID;               // Format Identifier
   DWORD    m_version;                // Version Number   
   DWORD    m_length;                 // Length of Record, 26...65535, or 65536...4294967295 ????(������ 4 �����???)
   WORD     m_capture_e;              // Capture Equipment compliance, 4 bits
                                      //   and ID, 12 bits
   WORD     m_width;                  // Size of Scanned Image in x direction, pixels
   WORD     m_height;                 // Size of Scanned Image in y direction, pixels
   WORD     m_resolutionX;            // Horizontal resolution, pixels/centimeter
   WORD     m_resolutionY;            // Vertical resolution, pixels/centimeter
   BYTE     m_numView;                // Number of Finger Views, 0...255
   BYTE     m_reserved;               // Reserved byte. For this version of the 
                                      // standard, this field shall be set to 0.
  };
// ISO 19794-2 extended data header
struct P_PACKED_1 ISO_extendedHeader
{
   WORD     m_length;                 // Length of Record (0x0000 = no private area)
};





// calculate maximum size of ISO template for corresponded number of fingers
int calcFullISOtemplSize(unsigned int numFingers);

// calculate miminum size of ISO template for corresponded number of fingers
int getMinISOtemplateSize(unsigned int numFingers);

// calculate maximum minutiae that can be put to template (all view)  for 
// given maximum size of whole template
int getAlowsNumMinutiaeISO(unsigned int numFingers, unsigned int maxSize);


/*
   Build ISO 19794-2 template
   Parameters:
   numFingers      (input) : number of source fingers. Cannot be more than MAX_FINGERS   
   rawImage        (input) : array of raw image structure, that contains information
                             about source fingerprint images. Field image is not used in 
                             this function and can be NULL
   quality         (input) : array of image quality (one value for each finger). 
                             Size of this array should be not less than numFingers
   isoTemplate     (output): buffer for building ISO template
                             Memory for it should be allocated in application 
                             (you can use allocateISOtemplate function)
   numMinutiae     (input) : array of number of minutiae in each finger   
   minutiae        (input) : array of minutiae information for each finger 
                             Size of this array should be not less than numFingers
   frame           (input) : array of information about segmentation, that was performed while
                             image processing (returns by function 'process' and 'processRaw'
                             of Ip, Ip10, Ip71, Ip110 classes)
                             Size of this array should be not less than numFingers
   certifiedSensor (input) : is capture equipment comply with IQS (EFTS, Appendix F)?
   sensorID        (input) : Capture Equipment ID. The vendor determines the value for this field.
                             Applications developers may obtain the values for these codes from the vendor. 
   templSize       (output): The pointer to variable that receives the size of template 
                              (if it's not NULL)
   Retrun value:
   The function returns SME_OK if success and error code otherwise. 
*/
int buildISOtemplate ( unsigned int numFingers, const RawImage *rawImage, 
                       BYTE *quality,
                       BYTE *isoTemplate,
                       unsigned int *numMinutiae,
                       Minutiae minutiae[MAX_MINUTIAE][MAX_MINUTIAE], 
                       Frame *frame = NULL, 
                       bool certifiedSensor = false, WORD sensorID = 0,
                       unsigned int *templSize = NULL);


#pragma pack(pop)


#endif // TEMPLATE_ISO_H_
