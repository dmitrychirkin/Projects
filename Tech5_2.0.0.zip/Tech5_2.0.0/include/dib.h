/*************************************************************************
   dib.h: - interface of the CDib class
 
	CDib - class for work with DIB (device independent bitmap)
	
	Compatibility:
		Windows NT: Requires version 3.1 or later.
		Windows: Requires Windows 95 or later.
		Windows CE: Requires version 1.0 or later.
  

   Author A.Mosunov
   Version 1.0 from 17.06.2002
*************************************************************************/
//////////////////////////////////////////////////////////////////////
#ifndef DIB_H
#define DIB_H

#include "common.h"
#ifdef _WINDOWS
   #include <windows.h>
   #include <tchar.h> 
#else
   #include "win2linGdi.h"
#endif

#pragma pack(push, _CORE_PACKING)

#ifndef M2INCH
#define M2INCH(x) (DWORD(x * 254 / 10000))  // change value from meter to inch
#endif
#ifndef INCH2M
#define INCH2M(x) (DWORD(x * 10000 / 254))  // change value from inch to meter
#endif

#define DIB_OK                   0    // success
#define DIB_FILE_OPEN            1    // cannot open a file
#define DIB_FILE_READ            2    // cannot read a file
#define DIB_NO_MEMORY            3    // not enough memory
#define DIB_NULL_POINTER         4    // null pointer was to function as parameter
#define DIB_UNKNOWN_EXCEPTION    5    // unknown exception rised
#define DIB_WRONG_FORMAT         6    // wrong DIB format


class CDib
{
	unsigned char* m_pDib;
	DWORD m_size;
	DWORD m_allocSize;
	DWORD m_offset;        // shift to image bytes

public:
	// Constructors
	CDib();
	CDib (const CDib& dib);
	~CDib();

#ifdef _WINDOWS
	bool setDib (const HANDLE hDib);
#endif
	CDib& operator= (const CDib& dib);
	operator unsigned char* (){return m_pDib;}
	unsigned char* getDib() const {return m_pDib;}
	DWORD getSize() const {return m_size;} 
	DWORD getImageSize() const;
	// return length of row
	DWORD getRowLen();

	DWORD getOffset() {return m_offset;} 
	// get offset to the image bytes
	static DWORD getOffset(LPBITMAPINFOHEADER pBmih);
	// get bmiColors size
	static DWORD getColorTableSize(LPBITMAPINFOHEADER pBmih);

	bool setDib(const unsigned char* pDib, DWORD size);
	bool setDib(const unsigned char* pDib);
	int setDibFromBmp(const char* pBmp, const DWORD size);
	DWORD getWidth() const;
	DWORD getWidthAlign() const;
	DWORD getHeight() const;
	LONG  getSignHeight() const;
	LPBITMAPINFOHEADER getBih() const { return (LPBITMAPINFOHEADER)m_pDib;}
   unsigned char* getImage()
   {
      return m_pDib + m_offset;
   }

	unsigned char* getImage() const;
	DWORD getResolutionX (); 
	DWORD getResolutionY () ;
	void setResolutionX (int dpi);
	void setResolutionY (int dpi);
	/*
		Paint matrix to parent window 
		x0, y0 - position of the top left corner of the image on context
		if direct = true - use write directly to video memory
	*/
#ifdef _WINDOWS
	BOOL paint(HWND parent, int x0, int y0, double &M, bool direct = true) const;
#endif	
	/*
		Create 8 bpp grey DIB 
		pImage - point to the image bytes (image bytes should be already 
			arranged)
		width, height - image size in pixels
	*/
	bool create8BitGray(const unsigned char* pImage, DWORD width, DWORD height);
	// cut part of the image
	bool cut (unsigned int x0, unsigned int y0, unsigned int width, unsigned int height);
	/* 
	cut part of the source image  and put it to the destination image
	pSrc - source image
	srcWidth, srcHeight - size of source image 
	pDst - destination image that is part of the source image
	x0, y0 width, height - define size and location of the cutting area 
	NOTE: all dimensions (x0, width etc.) should be pass in bytes (not in points)
	*/
	static bool cut (unsigned char* pSrc, unsigned int srcWidth, unsigned int srcHeight,
				unsigned int x0, unsigned int y0, unsigned int width, unsigned int height,
				unsigned char* pDst);
	/*
		strech image
		srcWidth, srcHeight - size of the source image
		dstWidth, dstHeight - size of the destination image
		kx, ky - stretching coefficients
		pSrc - source image
		pDst - destination image
		bpp - bit per pixels
	*/
	static void stretch(const WORD srcWidth, const WORD srcHeight, const unsigned char* pSrc, 
				   const float kx, const float  ky,
				   WORD& dstWidth, WORD& dstHeight, unsigned char* pDst, int bpp);

	// turn image over X
	bool turnOverX ();
	// turn image over X and change the sign of bih->biHeight
	bool turnOverXex ();
	// turn image over Y
	bool turnOverY ();
   // invert image color
   bool invert();
	// read from BMP file
	int readBmp  (const TCHAR *filename);
	// save DIB to BMP file
	bool save2Bmp (const TCHAR *filename);
   // check if dib is valid DIB
   bool checkDib (const unsigned char * dib);

private:
	bool allocDib(DWORD size);
	void init();
	void freeDib();
};

#pragma pack(pop)

#endif // #ifndef DIB_H

