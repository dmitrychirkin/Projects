/**************************************
				WiBase.h
	Transform refer to the base class.

		 Author Gudkov V.U.
**************************************/

//	Sentry
#if !defined (__WIBASE_73_H)
	#define __WIBASE_73_H

#include "typdef73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */


	//transform to the class member pointer
	typedef	void	(CBase::*tvii)	(int,int);
	typedef	void	(CBase::*tv_i)	(int );
	typedef	int	(CBase::*ti_i)	(int );
	typedef	int	(CBase::*ti_v)	(void);
	typedef	void	(CBase::*tv_v)	(void);

    
#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */

#endif	//__WIBASE_H
