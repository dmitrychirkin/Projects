/**************************************
				  Virtue.h
		 Property of the nest.

			Author Gudkov V.U.
**************************************/

//	Sentry
#if !defined (__VIRTUE_73_H)
	#define	__VIRTUE_73_H

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

	//workspace definition
	#include		"typdef73.h"

	//-------------------------------------
	//	Enumeration of links if other type
	//-------------------------------------
	extern char		TabNot[],				//as original
						TabEcr[],				//ending close to right	
						TabEcl[],				//ending close to left
						TabBbr[],				//bifurcation break to right
						TabBbl[],				//bifurcation break to left
						TabEsr[],				//ending switch to right
						TabEsl[],				//ending switch to left
						TabBcr[],				//bifurcation close to right
						TabBcl[];				//bifurcation close to left

	//-------------------------------------
	//	Extend probability events
	//-------------------------------------
	extern char		EndswR[],				//switch right in nest of ending
						EndswL[],				//switch left in nest of ending
						BifswR[],				//switch right in nest of bifurcation
						BifswL[];				//switch left in nest of bifurcation
	extern byte		TabVir[];				//hypothesis to spread events


	//-------------------------------------
	//	Extend crossing events
	//-------------------------------------
	extern char		EndCro[],				//cross linkages in ending nest
						BifCro[];				//cross linkages in bifurcation nest
	extern byte		TabCro[];				//hypothesis to analize cross

	//-------------------------------------

	//	Hypothesis to match nest similarity
	//-------------------------------------
	extern byte		TabCon[],				//conquer events
						TabPar[];				//parses events

	//-------------------------------------
	//	Search knowledge
	//-------------------------------------
	extern word		TabDat[];				//

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */

#endif		//Virtue.h
