/*
   template_nist_iso.h - declare constants and structure those common for NIST and ISO template

*/
#ifndef TEMPLATE_NIST_ISO_H_
#define TEMPLATE_NIST_ISO_H_

#pragma pack(push, _CORE_PACKING)


#define MIN_MINUTIAE                       52  // minumum number of minutiae in one finger view

enum ISO_NIST_MINUTIAE_TYPE
{
   ISO_NIST_OTHER       = 0,
   ISO_NIST_ENDING      = 1,
   ISO_NIST_BIFURCATION = 2
};

#pragma pack(pop)

#endif // TEMPLATE_NIST_ISO_H_
