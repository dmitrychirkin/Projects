#ifndef _FSEG_H_
#define _FSEG_H_

#include <string.h>
#include "ansi_nist_itl_1.h"


#ifdef FSEG_EXPORT
 #define FSEG_PREFIX extern "C" __declspec(dllexport)
#else
#ifdef FSEG_EXTERN
 #define FSEG_PREFIX extern "C"
#else
 #define FSEG_PREFIX
#endif
#endif


#define SGM_MAX_RECTS_COUNT  100  // maximum number of segmented rectangles



// Segmentation type

enum SGM_TYPE
{
	SGM_TYPE_FINGER    = 0,   // single fingerprints segmentation (distal segments)
	SGM_TYPE_SLAP      = 1,   // slap (plain four fingers) segmentation (distal segments)
	SGM_TYPE_PALM      = 2,   // single lower palm segmentation
	SGM_TYPE_EDGE      = 3,   // single palm edge (writer's palm) segmentation
	SGM_TYPE_THUMBS    = 4,   // two (left & right) thumbs segmentation (distal segments)
	SGM_TYPE_PALMS     = 5,   // two (left & right) lower palms segmentation
	SGM_TYPE_FULL_PALM = 6    // single full palm segmentation
};


// Hand

enum SGM_HAND
{
	SGM_HAND_UNKNOWN        = 0,  // unknown hand
	SGM_HAND_LEFT           = 1,  // left hand
	SGM_HAND_RIGHT          = 2,  // right hand
	SGM_HAND_PROBABLY_LEFT  = 3,  // rather left than right hand
	SGM_HAND_PROBABLY_RIGHT = 4   // rather right than left hand
};


// Finger position codes

enum SGM_FINGER
{
	SGM_FINGER_RT = POS_CODE_R_THUMB,       // right thumb
	SGM_FINGER_RI = POS_CODE_R_INDEX_F,     // right index finger
	SGM_FINGER_RM = POS_CODE_R_MIDDLE_F,    // right middle finger
	SGM_FINGER_RR = POS_CODE_R_RING_F,      // right ring finger
	SGM_FINGER_RL = POS_CODE_R_LITTLE_F,    // right little finger

	SGM_FINGER_LT = POS_CODE_L_THUMB,       // left thumb
	SGM_FINGER_LI = POS_CODE_L_INDEX_F,     // left index finger
	SGM_FINGER_LM = POS_CODE_L_MIDDLE_F,    // left middle finger
	SGM_FINGER_LR = POS_CODE_L_RING_F,      // left ring finger
	SGM_FINGER_LL = POS_CODE_L_LITTLE_F     // left little finger
};


// Segments position codes

enum SGM_SEGMENT
{
	SGM_SEGMENT_UNKNOWN  = 0,
	SGM_SEGMENT_DISTAL   = 1,
	SGM_SEGMENT_MEDIAL   = 2,
	SGM_SEGMENT_PROXIMAL = 3
};


// Segmented rectangle

struct SgmRect
{
	NIST_POS_CODE pos;        // friction ridge position code (POS_CODE_...)
	SGM_SEGMENT   segment;    // segment position code (SGM_SEGMENT_...)

	int coords[4][2];   // rectangle coordinates:
	                    //  coords[vertex index][coordinate index]:
	                    //   vertex index: 0 - left-top
	                    //                 1 - right-top
	                    //                 2 - left-bottom
	                    //                 3 - right-bottom
	                    //   coordinate index: 0 - X coordinate
	                    //                     1 - Y coordinate
#ifdef __cplusplus
	SgmRect()
	{
		pos     = POS_CODE_U_FINGER;
		segment = SGM_SEGMENT_UNKNOWN;

		memset(coords, 0, sizeof(coords));
	}
#endif
};


// Segmentation result

enum SGM_RESULT
{
	SGM_RES_SUCCESS      =  1,    // success

	SGM_RES_WRN_NORECTS  =  0,    // no segmented rectangles
	SGM_RES_WRN_HAND     = -1,    // wrong hand

	SGM_RES_ERR_IMAGE    = -2,    // no source image (img)
	SGM_RES_ERR_WIDTH    = -3,    // incorrect image width (imgWidth)
	SGM_RES_ERR_HEIGHT   = -4,    // incorrect image height (imgHeight)
	SGM_RES_ERR_PPI      = -5,    // incorrect image resolution (imgPPI)
	SGM_RES_ERR_TYPE     = -6,    // incorrect segmentation type (sgmType)
	SGM_RES_ERR_HAND     = -7,    // incorrect hand (sgmHand)
	SGM_RES_ERR_IMP_TYPE = -8,    // incorrect impression type (impType)
	SGM_RES_ERR_POS      = -9,    // incorrect fingerprint position in exclude position array (exclPos)
	SGM_RES_ERR_EXCLUDE  = -10,   // not allocated memory for exclude position array (exclPos), but not null number of items (exclPosCount) defined
	SGM_RES_ERR_RECTS    = -11,   // not allocated memory for rectangles array (rects)
	SGM_RES_ERR_COUNT    = -12,   // incorrect number of rectangles (rectsCount) for specified segmentation type (sgmType)
	SGM_RES_ERR_MEMORY   = -13,   // not enough memory
	SGM_RES_ERR_UNKNOWN  = -99    // unknown error
};


/*
Friction ridge (fingerprint / palm print) image segmentation
Parameters:
- img          (input)  - source image (RAW; 8 bit per pixel, 256 gray levels; left-right, top-bottom; without alignment).
                          Image size = imgWidth * imgHeight bytes.
                          If img == NULL, function returns SGM_RES_ERR_IMAGE.
- background   (input)  - background image (encoded as the source image).
                          Can be obtained from a live scanner before hand scanning.
                          If background != NULL, it's used for cleaning the source image before segmentation.
                          If background == NULL, it's not used.
- imgWidth     (input)  - image width, pixels.
                          If imgWidth  < 64, function returns SGM_RES_ERR_WIDTH.
- imgHeight    (input)  - image height, pixels.
                          If imgHeight < 64, function returns SGM_RES_ERR_HEIGHT.
- imgPPI       (input)  - image resolution, PPI (pixels per inch).
                          Typical values: 300, 500, 1000.
                          If imgPPI < 50, function returns SGM_RES_ERR_PPI.
- sgmType      (input)  - segmentation type. Defines the objects of segmentation.
                          If value of sgmType is not present in SGM_TYPE enum (SGM_TYPE_...), function returns SGM_RES_ERR_TYPE.
- sgmHand      (input)  - hand.
                          It's used only for SGM_TYPE_SLAP, SGM_TYPE_PALM and SGM_TYPE_EDGE segmentation types:
                            SGM_HAND_UNKNOWN - unknown hand (autodetect hand);
                            SGM_HAND_LEFT / SGM_HAND_RIGHT - segmentation is performed for defined hand;
                            SGM_HAND_PROBABLY_LEFT / SGM_HAND_PROBABLY_RIGHT - segmentation give preference to defined hand
                              but if it can found more fingers with supposition that it's another hand, then function returns SGM_RES_WRN_HAND
                              and perform segmentation for another hand.
                          If value of sgmHand is not present in SGM_HAND enum (SGM_HAND_...), function returns SGM_RES_ERR_HAND.
- impType      (input)  - impression type.
                          If value of impType is not present in NIST_IMP_TYPE enum (IMP_TYPE_...), function returns SGM_RES_ERR_IMP_TYPE.
                          This parameter has influence to preliminary source image filtration algorithm
                          (clean background, contrast improve, binarization etc.).
- rotation     (input)  - defines the possibility of rotated rectangles segmentation.
                          If rotation == true, quality of segmentation algorithm is better.
- exclPos      (input)  - array of finger position (SGM_FINGER_...) that should be excluded (segmentation will not try 
                          to find corresponded fingers on source image).
                          It's used only for SGM_TYPE_SLAP and SGM_TYPE_THUMBS segmentation types.
                          If exclPos == NULL, nothing will be excluded.
- exclPosCount (input)  - number of items in exclPos array. Should be in a range 0...SGM_MAX_RECTS_COUNT.
                          If exclPosCount == 0, nothing will be excluded.
- rects        (input)  - array of rectangles.
                          If rects == NULL, function returns SGM_RES_ERR_RECTS.
                          In depends of segmentation type (sgmType), need allocate memory for following number of rectangles:

                           SGM_TYPE_SINGLE_FINGER : 1  (POS_CODE_U_FINGER, if impType != IMP_TYPE_FP_LT_...)
                                                    10 (POS_CODE_U_FINGER, if impType == IMP_TYPE_FP_LT_...)
                           SGM_TYPE_SLAP          : 4  (POS_CODE_..._F)
                           SGM_TYPE_PALM          : 2  (POS_CODE_..._LOWER_PALM, POS_CODE_..._INTERDIGITAL)
                           SGM_TYPE_EDGE          : 1  (POS_CODE_..._WR_PALM)
                           SGM_TYPE_THUMBS        : 2  (POS_CODE_..._THUMB)
                           SGM_TYPE_PALMS         : 2  (POS_CODE_..._LOWER_PALM)
                           SGM_TYPE_FULL_PALM     : 13 (POS_CODE_..._F, POS_CODE_..._LOWER_PALM)

               (output) - output array of segmented rectangles.
- rectsCount   (input)  - number of items in rectangles array (rects). Should be in a range 1..SGM_MAX_RECTS_COUNT.
                          If input value of rectsCount == 0, function returns SGM_RES_ERR_COUNT.
               (output) - number of segmented rectangles (0..SGM_MAX_RECTS_COUNT).
                          If output value of rectsCount == 0, function returns SGM_RES_WRN_NORECTS (no segmented rectangles).
Results: SGM_RES_SUCCESS, SGM_RES_WRN..., SGM_RES_ERR_...
*/
FSEG_PREFIX SGM_RESULT FSeg(unsigned char *img,            // source image
                            unsigned char *background,     // background image
                            unsigned int   imgWidth,       // image width
                            unsigned int   imgHeight,      // image height
                            unsigned int   imgPPI,         // image resolution
                            SGM_TYPE       sgmType,        // segmentation type
                            SGM_HAND       sgmHand,        // hand
                            NIST_IMP_TYPE  impType,        // impression type
                            bool           rotation,       // can be rotated?
                            SGM_FINGER    *exclPos,        // array of excluded finger position
                            unsigned int   exclPosCount,   // number of items in exclPos array
                            SgmRect       *rects,          // segmented rectangles array
                            unsigned int  &rectsCount);    // number of rectangles

/*
Cut segmented image defined by 3 vertex coordinates from whole image
Results: SGM_RES_SUCCESS    - success
         SGM_RES_ERR_MEMORY - not enough memory
*/
FSEG_PREFIX SGM_RESULT Get3Rect(unsigned char *img,        // source image
                                unsigned int   imgWidth,   // image width
                                unsigned int   imgHeight,  // image height
                                int x1, int y1,            // left-top coordinates
                                int x2, int y2,            // right-top coordinates
                                int x3, int y3,            // left-bottom coordinates
                                unsigned char *res,        // output (cut) image (if res == NULL only resWidth and resHeight are filled)
                                unsigned int  &resWidth,   // output image width
                                unsigned int  &resHeight); // output image height

/*
Get quick estimation of segmented image quality
Results:    SGM_RES_SUCCESS    - success
            SGM_RES_ERR_MEMORY - not enough memory
*/
FSEG_PREFIX SGM_RESULT GetFingerprintQuality(unsigned char *img,          // segmented image
                                             unsigned int   imgWidth,     // image width
                                             unsigned int   imgHeight,    // image height
                                             unsigned int   imgPPI,       // image resolution
                                             unsigned char &quality);     // output quality (0 - 100)
#endif//_FSEG_H_
