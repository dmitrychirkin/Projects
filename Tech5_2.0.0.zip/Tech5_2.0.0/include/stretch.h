/*****************************************************************************
	Stretch.h - header file for image stretching functions
   
*******************************************************************************/
#ifndef STRETCH_H_
#define STRETCH_H_

#include "common.h"

#pragma pack(push, _CORE_PACKING)

/*   
	strech image
   NOTE: image should be 8bpp (1 byte per pixel)
	srcWidth, srcHeight - size of the source image
	srcRowLen           - size of the source image row lengh 
                         (it can be up to 3 pixels more then srcWidth because of padding)
	dstWidth, dstHeight - size of the destination image
	kx, ky - stretching coefficients
	pSrc - source image
	pDst - destination image
	bpp - bit per pixels
*/
void stretch (unsigned int srcWidth, unsigned int srcHeight, unsigned int srcRowLen,
			     const unsigned char* pSrc, float kx, float  ky,
				  unsigned int* dstWidth, unsigned int* dstHeight, unsigned char* pDst);
/*
	strech image
	srcWidth, srcHeight - size of the source image
	dstWidth, dstHeight - size of the destination image
	kx, ky - stretching coefficients
	pSrc - source image
	pDst - destination image
	bpp - bit per pixels
*/
void stretch4 (unsigned int srcWidth, unsigned int srcHeight, unsigned int srcRowlen,
			  const unsigned char* pSrc, float kx, float  ky,
				   unsigned int* dstWidth, unsigned int* dstHeight, unsigned char* pDst);


#pragma pack(pop)

#endif // STRETCH_H_
