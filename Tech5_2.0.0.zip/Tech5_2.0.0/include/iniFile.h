/*
	define the function for work with ini file
*/
#ifndef INI_FILE_H_
#define INI_FILE_H_

#include <string>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "linuxTools.h"
#include <ctype.h>
#include "common.h"

#pragma pack(push, _CORE_PACKING)

// common constants
#define MAX_STRING_LEN  255    // maximum length of string in INI file

// return values
#define INI_OK          0   // sucess
#define INI_OPEN       -1   // file not opened
#define INI_MORE_DATA  -2   // the size of buffer is not enought for required data
#define INI_NOT_FOUND  -3   // the corresponded key not found in INI file



enum TRIM_MODE
{
	TRIM_LEFT  = 0,
	TRIM_RIGHT = 1,
	TRIM_BOTH  = 2
};

bool checkBool(const char *s);

class IniFile
{
	FILE   *m_f;
	char    m_buffer[MAX_STRING_LEN + 1]; 
	char    m_key[MAX_STRING_LEN + 1]; 

public:
	IniFile();
	~IniFile();

   bool openOrCreate(const char *name);
   bool create(const char *name);
	bool open(const char *name);
	void close();

	// get int value
	int getValue (const char *keyName, int *var, int defaultVal) 
		{ return getNumValue(keyName, var, defaultVal, atoi);}
	// get long value
	int getValue (const char *keyName, long *var, long defaultVal) 
		{ return getNumValue(keyName, var, defaultVal, atol);}
	// get long long  value
	int getValue (const char *keyName, long long *var, long long defaultVal) ;
	// get double value
	int getValue (const char *keyName, double *var, double defaultVal) 
		{ return getNumValue(keyName, var, defaultVal, atof);}
	// get float value
	int getValue (const char *keyName, float *var, float defaultVal); 
	// get string value
	int getValue (const char *keyName, char *var,	int *size,
								const char *defaultVal);
	// get boolean value
	int getValue (const char *keyName, bool *var, bool defaultVal)
		{ return getNumValue(keyName, var, defaultVal, checkBool);}

	// put the string value
	int putValue (const char *keyName, char *val)
	{ return putValue (keyName, "%s=%s\n", val);}
	// put the int value
	int putValue (const char *keyName, int val)
	{ return putValue (keyName, "%s=%d\n", val);}
	// put the long value
	int putValue (const char *keyName, long val)
	{ return putValue (keyName, "%s=%ld\n", val);}
	// put the long long value
	int putValue (const char *keyName, long long val)
	{ return putValue (keyName, "%s=%lld\n", val);}
	// put the float value
	int putValue (const char *keyName, float val)
	{ return putValue (keyName, "%s=%f\n", val);}
	// put the double value
	int putValue (const char *keyName, double val)
	{ return putValue (keyName, "%s=%f\n", val);}
	// put the boolean value
	int putValue (const char *keyName, bool val)
	{ return putValue (keyName, "%s=%s\n", val ? "true" : "false");}
	
private:
	template <class T> int getNumValue (const char *keyName, T *var, T defaultVal, 
							T(* func)(const char *));
	template <class T> int putValue (const char *keyName, const char *format, T var);

	// find string with corresponded name in INI file
	char* findKeyString (const char *keyName);
	// trim the string
	char* trim(char *s, TRIM_MODE mode = TRIM_BOTH);

	/*
		Put the size of 'src' string into '*dstSize' 
		If  the size of 'dst' ('dstSize') is enought then copies 'src' string into 'dst'
		and returns INI_OK, otherwise return INI_MORE_DATA
	*/
	int safeCopyString(char *dst, int *dstSize, const char* src);

};

template <class T>
int IniFile::getNumValue (const char *keyName, T *var, T defaultVal, 
							T(* func)(const char *))
{
	if (!m_f) return INI_OPEN;
	*var = defaultVal;
	char *s = findKeyString (keyName);
	if (!s) return INI_NOT_FOUND;
	*var = func (s);
	return INI_OK;	
}

template <class T> 
int IniFile::putValue (const char *keyName, const char *format, T var)
{
	if (!m_f) return INI_OPEN;
	fprintf (m_f, format, keyName, var);
	fflush (m_f);
	return INI_OK;	
}

#pragma pack(pop)

#endif // INI_FILE_H_
