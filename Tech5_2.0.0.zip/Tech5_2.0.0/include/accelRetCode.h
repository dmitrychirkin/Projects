/*****************************************************************************
	accelRetCode.h - header file with ret code of TECH5 Accelerator library

*******************************************************************************/

#ifndef ACCEL_MATCH_RET_CODE_H_
#define ACCEL_MATCH_RET_CODE_H_

// error codes
#define SA_OK                     0   // success 
#define SA_UNPACK_INIT            1   // error of initialilize unpack library
#define SA_NULL_POINTER           2   // one of the pointer passed to the function is NULL
#define SA_NULL_TEMPLATE          3   // pointer to template is NULL
#define SA_UNPACK_ERR             4   // template unpacking error
#define SA_LOW_MEMORY             5   // not enough memory
#define SA_NOT_INITIALIZED        6   // library is not initialized. Call 'initAccelLib' function first

#define SA_ACCEL_CORRUPT          8   // accelerator is corrupted
#define SA_NOT_SUPPORT_SSSE3      9   // the CPU is not support the SSSE3 instruction set
#define SA_NO_FINGERS            10   // no one finger information was loaded
#define SA_WRONG_TEMPLATE        11   // wrong template format
#define SA_TRIAL_TIME_EXPIRED    12   // evaluation time is expired
#define SA_WRONG_FINGER_NUMBER   13   // wrong finger number (< 0 or > 9 ) was passed to the function
#define SA_NUM_THREADS_EXCEEDED  14   // parameter 'numThread' has a value more than was initialized in 'initAccelLib'
#define SA_ACCEL_CALC_ERR        15   // accelerator calculation error
#define SA_STEP_NUM_ERR          16   // numStep value passed to 'doStepCompareTP' is too big
#define SA_FINAL_NOT_INITIALIZED 17   // final matching is not initialized. Call 'initAccelLib' function with initFinalMatching= true
#define SA_DB_NOT_LOADED         18   // DB is empty (try to call one of the identification function before call 'uploadDb' function or all templtes are NULL)
#define SA_DB_SIZE_NULL          19   // function 'uploadDb' was called with gallerySize = 0 
#define SA_IP_VER_NOT_SUPPORTED  20   // not supported image processing version was passed to 'initAccelLib' function (only 73 or 140 is supprted in current version) 


#endif //ACCEL_MATCH_RET_CODE_H_
