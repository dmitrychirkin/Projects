/*****************************************************************************
	core_err.h - header file for errors code of IDS Core SDK

	The Core Matching SDK is the high-level tool, intended for easy creating
    of your own scalable biometric applications that use the person's fingerprint 
	for identification or verification purpose. 

*******************************************************************************/
#ifndef CORE_ERROR_H__
#define CORE_ERROR_H__

/******************************************************************
          THE FUNCTIONS RETURN VALUES
******************************************************************/

// the function finished successfully
#define AFIS_OK                   0 

/******************************************************************
          THE DAPI FUNCTIONS RETURN VALUES
******************************************************************/
#define DAPI_BASE                 0 
// the function finished successfully
#define DAPI_OK                   0 
// not enough memory
#define DAPI_LOW_MEMORY          DAPI_BASE - 4
// you are trying call on of the function before call init() function
#define DAPI_NOT_INITIALIZED     DAPI_BASE - 6
// unknown exception happened
#define DAPI_UNKN_EXCEPTION      DAPI_BASE - 8 
// cannot load corresponded scan DLL
#define DAPI_LOAD_SCANDLL		   DAPI_BASE - 10
// the value of the one of the pointer that was passed to the function is NULL 
#define DAPI_WRONG_POINTER       DAPI_BASE - 22  
// Sensor specific error. 
// You can get addition information by call 'getLastErrorMsg' function
#define DAPI_DEVICE              DAPI_BASE - 24
// The capture process was canceled by user 
#define DAPI_CANCEL              DAPI_BASE - 26 
// The specified timeout is expired 
#define DAPI_TIMEOUT             DAPI_BASE - 28     
// The function is not implemented 
#define DAPI_NOT_IMPLEMENTED     DAPI_BASE - 30
// error open device 
#define DAPI_OPEN_SENSOR         DAPI_BASE - 32       
// system error 
// You can get addition information by call 'getLastErrorMsg' function
#define DAPI_SYSTEM              DAPI_BASE - 34
// sensor with the name that was passed to 'getSensorNum' function is not supported
#define DAPI_NO_SUCH_SENSOR		 DAPI_BASE - 36
// sensor is not opened
#define DAPI_NOT_OPENED			 DAPI_BASE - 38
// At least one of the function parameters is out of range 
#define DAPI_WRONG_PARAMETRS     DAPI_BASE - 40
// Spoof finger detected
#define DAPI_SPOOF_FINGER        DAPI_BASE - 42

/******************************************************************
          THE IP FUNCTIONS RETURN VALUES
******************************************************************/
#define IP_BASE                 -200 
// the function finished successfully
#define IP_OK                   0 
// the number of fingers that was passed to function is wrong (should be >= 1 and <= 10)
#define IP_WRONG_FINGER_NUMBER IP_BASE - 2 
// not enough memory
#define IP_LOW_MEMORY          IP_BASE - 4
// you are trying call on of the function before call init() function
#define IP_NOT_INITIALIZED     IP_BASE - 6
// unknown exception happened
#define IP_UNKNOWN_EXCEPTION   IP_BASE - 8 
/* 
   The dib that was passed to process function is not satisfied to 
   one of following conditions:
   - 8 bit per prixel
   - uncompressed
   - number of planes equal 1
   - width  more then zero
   - height is not equal zero
*/
#define IP_WRONG_DIB           IP_BASE - 10
// one of the dib that was passed to process function has width > MAX_WIDTH or height > MAX_HEIGHT
#define IP_IMAGE_TOO_BIG       IP_BASE - 12
// one of the dib that was passed to process function has resolution less than MIN_RESOLUTION  or 
// more than MAX_RESOLUTION or resolution is not specified in header of dib
#define IP_WRONG_RESOLUTION    IP_BASE - 14
// the dib that was passed to process function didn't contains any fingerprint image
#define IP_NO_IMAGE            IP_BASE - 16
// processing error
#define IP_PROCESSING          IP_BASE - 18
// the value of the one of the pointer that was passed to the function is NULL 
#define IP_WRONG_POINTER       IP_BASE - 20  
// At least one of the function parameters is out of range 
#define IP_WRONG_PARAMETRS     IP_BASE - 26
// A process canceled by user (one of callback function return false)
#define IP_CANCEL              IP_BASE - 28
// A conversion template from version 7.1 or from NIST to ISO format is fail
#define IP_CONVERTION          IP_BASE - 30
// one of the dib that was passed to process function has width or height is to big or too small for choosen image processing algorithm
#define IP_WRONG_IMAGE_SIZE    IP_BASE - 32


/******************************************************************
          THE MA FUNCTIONS RETURN VALUES
******************************************************************/
#define MA_BASE                           -400 
// the function finished successfully
#define MA_OK                                0 
// the number of fingers that was passed to function is wrong (should be >= 1 and <= 10)
#define MA_WRONG_FINGER_NUMBER      MA_BASE - 2 
// not enough memory
#define MA_LOW_MEMORY               MA_BASE - 4
// you are trying call on of the function before call init() function
#define MA_NOT_INITIALIZED          MA_BASE - 6
// unknown exception happened
#define MA_UNKNOWN_EXCEPTION        MA_BASE - 8 	
// probe template has wrong format
#define MA_WRONG_PROBE_TEMPLATE     MA_BASE - 10 	
// gallery template has wrong format
#define MA_WRONG_GALLERY_TEMPLATE   MA_BASE - 11 	
// error of template set loading
#define MA_LOAD				         MA_BASE - 12 	
// matching error
#define MA_MATCH			            MA_BASE - 14 	
// two set of templates have no fingers with the same number
// or all templates passed to loadTemplate fuction are NULL
#define MA_NO_FINGERS		         MA_BASE - 16 	
// function 'matchEx' was called before load the first set of templates 
// by function 'loadtemplate' or no tempaltes was passed to 'loadtemplate'
#define MA_NO_LOAD                  MA_BASE - 18
// wrong number of finger  (should be >= 1 and <= 10)
#define MA_WRONG_FINGER_NUM         MA_BASE - 20 
// the value of the one of the pointer that was passed to the function is NULL 
#define MA_WRONG_POINTER             MA_BASE - 22  
// the number of finger pairs is less than required by minMatch parameter 
#define MA_NOT_ENOUGH_FINGERS       MA_BASE - 24  
// At least one of the function parameters is out of range 
#define MA_WRONG_PARAMETRS          MA_BASE - 26
// The doungle key not found
#define MA_KEY_ERR			         MA_BASE - 28
// You are trying to unpack template that already unpacked
#define MA_UNPACKED_TEMPL		      MA_BASE - 30
// the pointer to the fpTemplate in TemplateData structure is NULL
#define MA_NULL_TEMPLATE            MA_BASE - 32  
// error of initialilize unpack library
#define MA_UNPACK_INIT              MA_BASE - 34  
// the CPU is not support the SSE3 instruction set
#define MA_NOT_SUPPORT_SSE3         MA_BASE - 36  
// some finger of tenprints wasn't loaded
#define MA_NOT_ALL_FINGES_LOADED    MA_BASE - 38  
// the CPU is not support the SSE4.2 instruction set
#define MA_NOT_SUPPORT_SSE4_2       MA_BASE - 36  

/******************************************************************
          THE TI FUNCTIONS RETURN VALUES
******************************************************************/
#define TI_BASE                 -600 
// the function finished successfully
#define TI_OK                   0 
// the value of the one of the pointer that was passed to the function is NULL 
#define TI_WRONG_POINTER        TI_BASE - 2  
// not enough memory
#define TI_LOW_MEMORY           TI_BASE - 4
// wrong template format
#define TI_WRONG_TEMPLATE	     TI_BASE - 6 	


#endif // CORE_ERROR_H__
