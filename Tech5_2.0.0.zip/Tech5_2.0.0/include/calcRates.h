/*************************************************************************
   calcRates.h: - assemble functions for calculate rates in various 
                  Biometrics tests 
 
   Author A.Mosunov
   Version 1.0 from 25.11.2004
*************************************************************************/

#ifndef CALC_RATES_H
#define CALC_RATES_H

#include <assert.h>
#include "coreSdk.h"

////////////////////////////////////////////////////////////////////////////
//			TERMINOLOGY
////////////////////////////////////////////////////////////////////////////
//  FNMR - False Not Match Rate
//  FMR  - False Match Rate
//  FAR  - False Acceptable Rate. It is equal FMR
//  FRR  - False Rejection Rate. It is equal FNMR
//  TAR  - True Acceptable Rate. It is equal 1 - FRR(1 - FNMR)
////////////////////////////////////////////////////////////////////////////

class Score
{
	double  m_score;

public:
	Score () {m_score = 0;}
	Score (double score) 
   { 
      if (score < 0) score = 0;
      if (score > 1) score = 1;
      m_score = score; 
   }

   double getScore()const {return m_score;}
   bool operator> (Score& score) const { return m_score > score(); }
	bool operator< (Score& score) const { return m_score < score(); }
	operator double()   const { return m_score; }
	double operator()() const { return m_score; }
};

class CalcRate
{
   int         m_numStep;
   double      m_step;
   double     *m_FMR;
	double     *m_FNMR;
	long long  *m_gen;
	long long  *m_imp;
   bool        m_modified;

public:
	CalcRate()
   { 
      m_FMR      = 0;
      m_FNMR     = 0;
      m_gen      = 0;
      m_imp      = 0;
      m_numStep  = MAX_SCORE;
      m_step     = 1.0 / m_numStep;
      alloc();
      clear();
   }
   CalcRate (const CalcRate *calc)
   {
      *this = calc;
   }
	~CalcRate()
   {
      if (m_FMR )    delete [] m_FMR , m_FMR   = NULL;
      if (m_FNMR)    delete [] m_FNMR, m_FNMR  = NULL;
      if (m_gen )    delete [] m_gen , m_gen   = NULL;
      if (m_imp )    delete [] m_imp , m_imp   = NULL;
   }
   CalcRate& operator= (const CalcRate &calc)
   {
      memcpy(this->m_FMR,   calc.m_FMR , sizeof(m_FMR[0] ) * (m_numStep + 1)); 
	   memcpy(this->m_FNMR,  calc.m_FNMR, sizeof(m_FNMR[0]) * (m_numStep + 1));
	   memcpy(this->m_gen,   calc.m_gen , sizeof(m_gen[0] ) * (m_numStep + 1));
	   memcpy(this->m_imp,   calc.m_imp , sizeof(m_imp[0] ) * (m_numStep + 1));
      this->m_modified = calc.m_modified;
      return *this;
   }
   void alloc()
   {
      m_FMR       = new double    [m_numStep + 1];
      m_FNMR      = new double    [m_numStep + 1];
      m_gen       = new long long [m_numStep + 1];
      m_imp       = new long long [m_numStep + 1];
   }
   void clear()
   {
   	memset(m_FMR,     0, sizeof(m_FMR [0]) * (m_numStep + 1)); 
	   memset(m_FNMR,    0, sizeof(m_FNMR[0]) * (m_numStep + 1));
	   memset(m_gen,     0, sizeof(m_gen [0]) * (m_numStep + 1));
	   memset(m_imp,     0, sizeof(m_imp [0]) * (m_numStep + 1));
      m_modified = true;
   }
   void putGenuineScore (double score, long long times = 1)
   {
      m_gen[getPosition(score)] += times;
      m_modified = true;
   }
   void putImpostorScore (double score, long long times = 1 )
   {
      m_imp[getPosition(score)] += times;
      m_modified = true;
   }
   void add( const CalcRate & rate )
   {
      assert (m_numStep == rate.m_numStep);
      for( int i = 0; i <= m_numStep; i++ )
      {
         this->m_gen[i] += rate.m_gen[i];
         this->m_imp[i] += rate.m_imp[i];
      }
      m_modified = true;
   }
   void operator += (const CalcRate & rate)
   {
      add(rate);
   }
   // get FMR100 (value of FNMR where FMR = 1%) for 2-finger matching
   double calc_fmr100_2f();

	// return value of FNMR(FRR) for defined FMR (FAR)
	inline double FNMR_FMR(double fmr);
	inline double FRR_FAR(double fmr)
   {
      return FNMR_FMR(fmr);
   }
	// return value of FMR (FAR) for defined FNMR (FRR)
	inline double FMR_FNMR(double fnmr);
	inline double FAR_FRR(double frr)
   {
      return FMR_FNMR(frr);
   }
	// return value of TAR  for defined FAR 
	inline double TAR_FAR(double far);
	// return value of FAR for defined TAR
	inline double FAR_TAR(double far);

	// get EER
	inline double EER();

	// get FMR100 (value of FNMR where FMR = 1%)
	double FMR100()      {return FNMR_FMR(1.0f);}  
	// get FMR1000 (value of FNMR where FMR = 0.1%)
	double FMR1000()     {return FNMR_FMR(0.1f);}
	// get FMR10000 (value of FNMR where FMR = 0.01%)
	double FMR10000 ()   {return FNMR_FMR(0.01f);}
	// get ZeroFMR (value of FNMR where FMR = 0.0%)
	double ZeroFMR ()    {return FNMR_FMR(0.0f);}

	// get TAR@FAR1 (value of TAR where FMR = 1%)
	double TAR_FAR1 ()   {return TAR_FAR(1.0f);}  
	// get TAR@FAR01 (value of TAR where FMR = 0.1%)
	double TAR_FAR0_1 ()  {return TAR_FAR(0.1f);}  
	// get TAR@FAR001 (value of TAR where FMR = 0.01%)
	double TAR_FAR0_01 () {return TAR_FAR(0.01f);}  

	// get FAR@TAR98 (value of FAR where TAR = 98%)
	double FAR_TAR98 ()  { return  FAR_TAR(98.0f); }  
   double getFMR    ( double score );
   // calculate number of genuine scores
   long long getNumGen () const
   {
      long long genCount = 0;
	   for (int i = 0; i <= m_numStep; i++)
         genCount += m_gen[i];
      return genCount;
   }
   // calculate number of impostor scores
	long long getNumImp () const
   {
      long long impCount = 0;
      for (int i = 0; i <= m_numStep; i++)
         impCount += m_imp[i];
      return impCount;
   }
private:
   inline void calc();

   int getPosition (double score) const
   {
      int n = (int)(score / m_step);
      if (n < 0)
         n = 0;
      else if (n > m_numStep)
         n = m_numStep;
      return n;
   }
};



inline void CalcRate::calc()
{
   if (!m_modified)
      return;

   long long genCount = getNumGen ();
   long long impCount = getNumImp ();
//printf ("genCount = %d impCount = %d\n", genCount, impCount);
//	for (int i = 0; i < m_numStep; i++)
//      printf ("i = %06d m_gen[i] = %06d m_imp[i] = %06d\n", i, m_gen[i], m_imp[i]);
   long long count = 0;
   // calculate m_FNMR (FRR)
   count = 0;
   m_FNMR[0] = 0;
	for (int i = 0; i < m_numStep; i++)
   {
      count += m_gen[i];
      m_FNMR[i + 1] = (double)100 * count / genCount;
   }

   // calculate m_FMR (FAR)
   count = 0;
	for (int i = m_numStep; i >= 0; i--)
   {
      count += m_imp[i];
      m_FMR[i] = (double)100 * count / impCount;
   }
   m_modified = false;
}

// get FMR100 (value of FNMR where FMR = 1%) for 2-finger matching
inline double CalcRate::calc_fmr100_2f()
{
	long long  *gen_2f    = new long long [m_numStep + 1];
	long long  *imp_2f    = new long long [m_numStep + 1];
   double     *FMR_2f    = new double    [m_numStep + 1];
   double     *FNMR_2f   = new double    [m_numStep + 1];
   if (!gen_2f || !imp_2f || !FMR_2f || !FNMR_2f)
      return -1;
	memset(gen_2f,  0, sizeof(long long) * (m_numStep + 1));
	memset(imp_2f,  0, sizeof(long long) * (m_numStep + 1));

   for(int i = 0; i <= m_numStep; i++)
   {
      for(int j = 0; j <= m_numStep; j++)
      {
         gen_2f[(i + j) / 2] += m_gen[i] * m_gen[j];   
      }
   }
   for(int i = 0; i <= m_numStep; i++)
   {
      for(int j = 0; j <= m_numStep; j++)
      {
         imp_2f[(i + j) / 2] += m_imp[i] * m_imp[j];   
      }
   }

   long long genCount_2f = 0;
	for (int i = 0; i <= m_numStep; i++)
      genCount_2f += gen_2f[i];

   long long impCount_2f = 0;
   for (int i = 0; i <= m_numStep; i++)
      impCount_2f += imp_2f[i];

   long long count = 0;
   // calculate m_FNMR (FRR)
   count = 0;
   FNMR_2f[0] = 0;
	for (int i = 0; i < m_numStep; i++)
   {
      count += gen_2f[i];
      FNMR_2f[i + 1] = (double)100 * count / genCount_2f;
   }

   // calculate m_FMR (FAR)
   count = 0;
	for (int i = m_numStep; i >= 0; i--)
   {
      count += imp_2f[i];
      FMR_2f[i] = (double)100 * count / impCount_2f;
   }
   // calculate FMR100
   double fmr100 = 100.0;
	for(int n = 0; n <= m_numStep; n++)
		if (FMR_2f[n] <= 1.0)
		{
			fmr100  = FNMR_2f[n];
			break;
		}

   delete [] gen_2f;
   delete [] imp_2f;
   delete [] FMR_2f;
   delete [] FNMR_2f;

	return fmr100;
}

inline double CalcRate::FNMR_FMR(double fmr)
{
   calc();
	double result = 100.0;
	for(int n = 0; n <= m_numStep; n++)
		if (m_FMR[n] <= fmr)
		{
			result  = m_FNMR[n];
			break;
		}
	return result;
}

inline double CalcRate::EER()
{
   calc();
	double err = 100.0;
	int n1 = 0, n2 = 0;
	for(int n = 0; n <= m_numStep; n++)
		if (m_FMR[n] <= m_FNMR[n])
		{
			n2  = n;
			break;
		}
	for(int n = m_numStep; n >= 0; n--)
		if (m_FMR[n] >= m_FNMR[n])
		{
			n1  = n;
			break;
		}
    if (m_FMR[n1] + m_FNMR[n1] <= m_FMR[n2] + m_FNMR[n2])
        err = (m_FMR[n1] + m_FNMR[n1]) / 2;
    else
        err = (m_FMR[n2] + m_FNMR[n2]) / 2;

	return err;
}

// return value of FMR (False Match Rate) for defined FNMR (False Not Match Rate)
inline double CalcRate::FMR_FNMR(double fnmr)
{
   calc();
	double result = 100.0;
	for(int n = m_numStep; n >= 0; n--)
		if (m_FNMR[n] <= fnmr)
		{
			result  = m_FMR[n];
			break;
		}
	return result;
}

// return value of TAR (True Acceptable Rate) for defined FAR (False Acceptable Rate)
inline double CalcRate::TAR_FAR(double farRate)
{
	return 100 - FNMR_FMR (farRate);
}
// return value of FAR for defined TAR
inline double CalcRate::FAR_TAR(double tarRate)
{
	return FMR_FNMR (100 - tarRate);
}

inline double CalcRate::getFMR ( double score )
{
   calc();
   return m_FMR[ getPosition( score ) ];
}



#endif // CALC_RATES_H

