#ifndef STRING_TO_NUMERIC_H_
#define STRING_TO_NUMERIC_H_

#include <sstream>
#include <stdlib.h>

#ifdef _WINDOWS
#define strtoull _strtoui64
#endif


inline string uint64ToString(uint64_t val)
{
#ifdef _WINDOWS
   char buffer[256];
   _i64toa(val, buffer, 10);
   return string(buffer);
#else
   std::stringstream ss;
    ss << val;
    return ss.str();
#endif
}

inline uint64_t getIdFromString  (string id)
{
   char *endptr = NULL;
   return strtoull (id.c_str(), &endptr, 10); 
}


#endif