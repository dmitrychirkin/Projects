#ifndef HARDWARE_ANSWER_CLASS
#define HARDWARE_ANSWER_CLASS

#include "hardware_common.h"

bool create_answer_file(wchar_t* request_filename, wchar_t* answer_filename, TECH5_PRODUCTS product, char* m_serial_number_answer = NULL, char* m_macAddress_answer[_MAX_ADAPTER_COUNT] = NULL, __time32_t* end_license = NULL, bool is_trial = false, bool* is_old_format = 0, unsigned char* additional_info = 0, unsigned long additional_info_length = 0, int m_instance_count = 1);
bool create_answer_file(unsigned char* request_buffer,int lenth_request ,unsigned char* answer_filename,int& length_answer , TECH5_PRODUCTS product, char* m_serial_number_answer = 0, char* m_macAddress_answer[_MAX_ADAPTER_COUNT] = 0, __time32_t* end_license = 0, bool is_trial = false, bool* is_old_format = 0, unsigned char* additional_info = 0, unsigned long additional_info_length = 0, int m_instance_count = 1);

#endif