/*
   The main header file for libminex library
   Libminex library is implemented the TECH5 algorithm
   that is compliance with API specification for minex ongoing test
*/

#ifndef TECH5_LIB_MINEX_H_
#define TECH5_LIB_MINEX_H_

#ifdef _WINDOWS
   #include <windows.h>
#endif

#pragma pack(push, _CORE_PACKING)

// common constants
#define MAX_MINEX_MINUTIAE       255 //128  
#define MAX_MINEX_TEMPL_SIZE     800


// Error codes
#define SME_OK                0  // Success
#define SME_IMAGE_SIZE        1  // Image size not supported
#define SME_PROCESS           2  // Unspecified error happened while extract 
                                 // minutiae
#define SME_IMPRESSION_TYPE   3  // Specified impression type is not supported
#define SME_NULL_TEMPLATE     4  // Failed to match templates � null probe or 
                                 // gallery template
#define SME_PROBE_PARSE       5  // Failed to match templates � unable to parse 
                                 // probe template
#define SME_GALLERY_PARSE     6  // Failed to match templates � unable to parse 
                                 // gallery template
#define SME_WRONG_POINTER     7  // one of the pointer passed to the function is NULL
#define SME_WRONG_PARAM       8  // one of the parameter passed to the function is 
                                 // out of range (e.g. finger number > 10)
#define SME_MATCH             9  // Unspecified error happened while matching
#define SME_LOW_MEMORY       10  // not enough memory
#define SME_UNKN_ERR         11  // Unspecified error happened
#define SME_TRIAL_EXPIRED    12  // evaluation time is expired


#ifdef __cplusplus
extern "C" { 	
#endif  

/*
   The function takes a raw image as input and outputs the corresponding MINEX 
   compliant template. 
   Parameters:
   raw_image       (input): The raw image used for template creation
                            The raw image should be uncompressed, upright, 
                            8 bit per pixel, 500 DPI.    
   finger_quality  (input): The quality of the fingerprint image
   finger_position (input): The finger position code
   impression_type (input): The impression type code
   height          (input): The number of pixels indicating the height of the image.
   width           (input): The number of pixels indicating the width of the image.
   moTemplate      (output): The processed MINEX compliant (minutiae only) template.
                             The memory for the template should be allocated 
                             in application before the call.
   Retrun value:
   The function returns SME_OK if success and error code otherwise. 
   In case of failure the null template will be output.
*/
int create_template (const BYTE* raw_image, BYTE finger_quality,
                     BYTE finger_position, BYTE impression_type,
                     WORD height, WORD width, BYTE *moTemplate);

/*
   The function compares two MINEX compliant templates and outputs a match score. 
   Parameters:
   probe_template   (input):  the first MINEX compliance template
   gallery_template (input):  the second MINEX compliance template
   score            (output): pointer to varialbe that receives a match score in a range 0...1
   Retrun value:
   The function returns SME_OK if success and error code otherwise. 
*/
int match_templates (const BYTE *probe_template, const BYTE *gallery_template,
                     float *score);

/*
   The function retrieves CBEFF PID information which identifies the SDK�s 
   core feature extractor and template matcher.
   Parameters:
   feature_extractor (output): pointer to varialbe that receives 
                               a PID which identifies the SDK�s feature extractor
   matcher           (output): pointer to varialbe that receives
                               a PID which identifies the SDK�s matcher
   Return Value:
   The function returns SME_OK if success and error code otherwise. 
   In the latter case, both output parameters are set to 0.
*/
int get_pids (DWORD *feature_extractor, DWORD *matcher);

#ifdef __cplusplus
}  // extern "C" { 	
#endif  

#pragma pack(pop)

#endif // TECH5_LIB_MINEX_H_
