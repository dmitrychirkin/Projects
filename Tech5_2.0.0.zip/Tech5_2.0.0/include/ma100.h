/*****************************************************************************
	ma100.h - header file for finger to finger matching algorithm (MA) of Core Matching SDK
             using ma100 algorithm
*******************************************************************************/
#ifndef MA_100_H__
#define MA_100_H__

#include "coreSdk.h"
#include "core_err.h"


class Fs;

namespace accelMatch{
#pragma pack(push,_CORE_PACKING)

/******************************************************************
          Matching Algorithm class
******************************************************************/
class Compare100;

class Ma100
{
	Compare100     *m_compare;
   bool            m_init;

public:
	Ma100();
  ~Ma100();

	/* 
	 Initialize work with Ma100 class functions
	 This function (or 'initEx' function) should be called before call any other function
    of this class
    Function returns MA_OK - if function succeeds, error code - otherwise
	*/
	int init();
   /* 
      Initialize work with Ma100 class
      In differ from 'init' function it take the protection data
      This function (or 'init' function)should be called first before call 
      any other functions
      Parameters:
      protect      (input) - pointer to the buffer with protection data
      Return value:
      The function returns MA_OK - if function succeeds, error code - otherwise
   */
   int initEx (int protect[MAX_PROTECT_LEN]);

	// allocate memory for template
	static int allocateTemplate(BYTE *&templ);
	// free memory that was earlier allocate by 'allocateTemplate' function
	static int freeTemplate(BYTE *&templ);

	/*
	Match two templates.
	function returns MA_OK, if function succeeds, error code otherwise.
	param          (input)  - search parameters
                             NOTE: because finger is not known, it uses maxAngle (not maxAngleThumb)
                             for angle tolerance
	templP         (input)  - probe template for matching 
	templG         (input)  - gallery template for matching 
   similarity     (output) - template similarity in a range 0...MAX_SCORE
   typeP          (input)  - type of probe fingerprint
   typeG          (input)  - type of gallery fingerprint
	matchResult    (output) - if not NULL contains the final match result details.
   */
	int match  ( SearchParam  &param, 
                BYTE         *templP, 
                BYTE         *templG, 
                int          &similarity,
                FP_TYPE       typeP = UNKNOWN,
                FP_TYPE       typeG = UNKNOWN,
                MatchResult  *matchResult = 0);
	
   /* 
   Load probe template for future matching with 'matchEx'
	function returns MA_OK, if function succeeds, error code otherwise.
   */
	int   loadTemplate (BYTE *templP, FP_TYPE typeP = UNKNOWN);       

   /*
   Match previosely loaded with 'loadTemplate' probe template with 
	function returns MA_OK, if function succeeds, error code otherwise.
	param          (input)  - search parameters
                             NOTE: because finger is not known, it uses maxAngle (not maxAngleThumb)
                             for angle tolerance
	templG         (input)  - gallery template for matching 
   similarity     (output) - template similarity in a range 0...MAX_SCORE
   typeG          (input)  - type of gallery fingerprint
	matchResult    (output) - if not NULL contains the final match result details.
   */
	int	matchEx     ( SearchParam  &param,               
                       BYTE         *templG,      
                       int          &similarity,          
                       FP_TYPE       typeG = UNKNOWN,
                       MatchResult  *matchResult = 0);    
private:
   // check value of SearchParam items for acceptable value
   bool checkSearchParam(SearchParam &param);
};

#pragma pack(pop)
} // namespace accelMatch
#endif // MA_100_H__

