/**************************************
				ExpImp.h
 Export & import definitions for DLLs.

		 Author Gudkov V.U.
**************************************/

//	Sentry
#if !defined (__EXPIMP_H)
	#define __EXPIMP_H

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

/*
	#if defined (_WINDOWS)

		//for school project
		#if defined (SCHDLL)
			#define SCH_EI __declspec( dllexport )
		#else
			#define SCH_EI __declspec( dllimport )
		#endif

		//for wizard project
		#if defined (WZDDLL)
			#define WZD_EI __declspec( dllexport )
		#else
			#define WZD_EI __declspec( dllimport )
		#endif

		//for packed project
		#if defined (PCKDLL)
			#define PCK_EI __declspec( dllexport )
		#else
			#define PCK_EI __declspec( dllimport )
		#endif

		//for packed project
		#if defined (SEADLL)
			#define SEA_EI __declspec( dllexport )
		#else
			#define SEA_EI __declspec( dllimport )
		#endif

	#else

		#pragma message( "Need _WINDOWS"  __FILE__ ) 
*/
		//blank definitions
		#define SCH_EI 
		#define WZD_EI 
		#define PCK_EI 
		#define SEA_EI 

//	#endif

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */

#endif	//__EXPIMP_H
