/**************************************
				 Sorter.h
		  Some sort templates.

			Author Gudkov V.U.
**************************************/

//	Sentry
#if !defined( __SORTER_73_H )
	#define __SORTER_73_H

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

	//----------------------------------
	//	Swap variables
	//----------------------------------
	template <class T> 
	static inline void swap( T &a,T &b )
	{
		T c(a); a = b;	b = c;
	}

	//----------------------------------
	//	Compare two values
	//----------------------------------

	//	Good if (b > a)
	static inline int more( int a,int b )
	{
		return a < b;
	}

	//	Good if (b < a)
	static inline int less( int a,int b )
	{
		return a > b;
	}

	//	Good if (+b > +a) or (-b < -a)
	static inline int comp( int a,int b )
	{
		//exchange objects
		if (a < 0 && b < 0)
			return a > b;
		else
			return a < b;
	}

	//	Good if (|b| < |a|)
	static inline int lesa( int a,int b )
	{
		if (a < 0)
			if (b < 0)
			  return less( -a,-b );
			else
			  return less( -a,+b );
		else
			if (b < 0)
			  return less( +a,-b );
			else
			  return less( +a,+b );
	}

	//	Good if (|b| > |a|)
	static inline int mora( int a,int b )
	{
		if (a < 0)
			if (b < 0)
				return more( -a,-b );
			else
				return more( -a,+b );
		else
			if (b < 0)
				return more( +a,-b );
			else
				return more( +a,+b );
	}

	//----------------------------------
	//	Template for simple sorting
	//----------------------------------

	//	Bubble sorting
	template <class L,class M,class P> 
	static inline void bsort( L *list,M *metr,P comp,int size = 9 )
	{
		for (register int i = 0; i < size-1; i++)
		{
			for (register int j = i+1; j < size; j++)
			{
				//exchange objects
				if (comp( metr[i],metr[j] ))
				{
					swap( metr[i],metr[j] );
					swap( list[i],list[j] );
				}
			}
		}
	}	

	//	Insert sorting
	template <class L,class P>
	static inline void isort( L *list,P comp,int l = 8,int f = 0 )
	{
		//set first boundary
		for (register int i = f+1; i <= l; i++)
		{
			//store the item
			L item = list[i];

			//set second boundary
			register int j;
			for (j = i-1; j >= f && comp( item,list[j] ); j--)
			{
				//shift temporary it
				list[j+1] = list[j];
			}

			//restore an item
			list[j+1] = item;
		}
	}	

	//	Insert sorting by metric
	template <class L,class M,class P>
	static inline void isortM( L *list,M *metr,P comp,int l = 8,int f = 0 )
	{
		//set first boundary
		for (register int i = f+1; i <= l; i++)
		{
			//store the item
			L item = list[i];
			M mval = metr[i];

			//set second boundary
			register int j = i - 1;
			for ( ; j >= f && comp( mval,metr[j] ); j--)
			{
				//shift temporary it
				list[j+1] = list[j];
				metr[j+1] = metr[j];
			}

			//restore an item
			list[j+1] = item;
			metr[j+1] = mval;
		}
	}	

	//	Quick sorting
	template <class L,class P> 
	static void qsort( L *list,P comp,int l = 8,int f = 0 )
	{
		//set frontier
		for (register int b = f,t = l; b < t;)
		{
			//look upper list
			for (;b < t; t--)
			{
				//sort and exchange objects
				if (comp( list[b],list[t] ))
				{
					swap( list[b],list[t] );
					break;
				}
			}

			//look down  list
			for (;b < t; b++)
			{
				//sort and exchange objects
				if (comp( list[b],list[t] ))
				{
					swap( list[b],list[t] );
					break;
				}
			}

			//sort upper list
			if (f < b-1)
				qsort( list,comp,b-1,f );

			//sort down list
			if (l > b+1)
				qsort( list,comp,l,b+1 );
		}
	}	

	//----------------------------------
	//	Median core
	//----------------------------------
	template <class T> 
	static inline T among( T x,T y,T z )
	{
		if (x < y)
			return (y < z ? y : x < z ? z : x);
		else
			return (x < z ? x : y < z ? z : y); 
	}

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */

#endif	//SORTER_H

