/**************************************
				 Packed.h
	Some procedures to pack/unpack data.

			Author Gudkov V.U.
**************************************/

#include		<memory.h>

//	Workspace definition
#include		"expimp73.h"
#include		"typdef73.h"

//	Sentry
#if !defined (__PACKED_73_H)
	#define __PACKED_73_H

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

	//	Masks of n-bits
	static uint Gud[] = 
	{	
		0x00000000,	
		0x00000001,0x00000003,0x00000007,0x0000000f,
		0x0000001f,0x0000003f,0x0000007f,0x000000ff,
		0x000001ff,0x000003ff,0x000007ff,0x00000fff,
		0x00001fff,0x00003fff,0x00007fff,0x0000ffff,
		0x0001ffff,0x0003ffff,0x0007ffff,0x000fffff,
		0x001fffff,0x003fffff,0x007fffff,0x00ffffff,
		0x01ffffff,0x03ffffff,0x07ffffff,0x0fffffff,
		0x1fffffff,0x3fffffff,0x7fffffff,0xffffffff
	};

	//	Pack and unpack tree-node
	PCK_EI extern	int	EnNode		(byte		*dst,
												 byte		*src);
	PCK_EI extern	int	DeNode		(byte		*dst,
												 byte		*src);

	/***********************************
		Bits processing common library
	***********************************/

	//	Necessary bits to represent
	template <class T>
	static inline T Quants( T base )
	{
		T i = 0;
		for (; ((T)1 << i) <= base; i++); return i;
	}

	//	Pack value into the bits performance
	template <class T,class L,class U>
	static inline T	EnBits( byte *dst,L *lin,L *bit,T item,U size )
	{
		//the bit packing for point
		for (U i = 0; i < size; i++)
		{
			//clear if use next byte..
			if ( !(*bit) )	dst[*lin] = 0;

			//set destination
			dst[*lin] |= ((item >> i)& 1) << (*bit);
			//get end of byte
			if (++(*bit) == 8)	{ (*bit) = 0; ++(*lin);}
		}
		//final value
		return	item;
	}

	//	Depack value from the bits performance
	template <class T,class L>
	static inline int	DeBits( byte *src,L *lin,L *bit,T size )
	{
		//the bit parsing for event
		T i = 0,item = 0;
		for (; i < size; i++)
		{
			//calculate next bit from the source 
			item |= ((src[*lin] >> (*bit))& 1) << i;
			//get end of byte
			if (++(*bit) == 8)	{ (*bit) = 0; ++(*lin);}
		}

		//final value
		return	item;
	}

	/***********************************
		Definitions of quick decoding
	***********************************/

	//	Unpack 1 bit
#ifndef _WIN32_WCE
	#define DEBIT1( src,lin,bit,val,tmp )										\
	{																						\
		tmp = val & 1;																	\
		if (bit <  31)																	\
			{bit +=  1;	val >>= 1;}													\
		else																				\
			{bit =   0; val = src[++lin]; }										\
	}
#else
	static inline uint getUint(byte *p)
	{
		uint temp;
		memmove(&temp, p, sizeof(temp));
		return temp;
	}
	static inline void DEBIT1 (uint *src, uint &lin, uint &bit, uint &val, uint&tmp )										
	{																						
		tmp = val & 1;																	
		if (bit <  31)																	
			{bit +=  1;	val >>= 1;}													
		else							
		{
			bit =   0; 
			val = getUint((byte*)(src + ++lin)); 
		}
	}
#endif

	//	Unpack 2 bits
#ifndef _WIN32_WCE
	#define DEBIT2( src,lin,bit,val,tmp )										\
	{																						\
		tmp = val & 3;																	\
		if (bit <  30)																	\
			{bit +=  2;	val >>= 2;}													\
		else																				\
		if (bit == 30)																	\
			{bit =   0; val = src[++lin]; }										\
		else																				\
			{bit =   1; val = src[++lin]; tmp += (val&1)<<1; val >>= 1;}\
	}
#else
	static inline void DEBIT2(uint *src, uint &lin, uint &bit, uint &val, uint &tmp )										\
	{																			
		tmp = val & 3;
		if (bit <  30)
			{bit +=  2;	val >>= 2;}
		else					
		if (bit == 30)
		{
			bit =   0; 
			val = getUint((byte*)(src + ++lin)); 
		}
		else
		{
			bit =   1; 
			val = getUint((byte*)(src + ++lin)); 
			tmp += (val&1)<<1; val >>= 1;
		}
	}
#endif
	//	Unpack 3 bits
#ifndef _WIN32_WCE
	#define DEBIT3( src,lin,bit,val,tmp )										\
	{																						\
		tmp = val & 7;																	\
		if (bit <  29)																	\
			{bit +=  3;	val >>= 3;}													\
		else																				\
		if (bit == 29)																	\
			{bit =   0; val = src[++lin]; }										\
		else																				\
		if (bit == 30)																	\
			{bit =   1; val = src[++lin]; tmp += (val&1)<<2; val >>= 1;}\
		else																				\
			{bit =   2; val = src[++lin]; tmp += (val&3)<<1; val >>= 2;}\
	}
#else
	static inline void DEBIT3 (uint *src, uint &lin, uint &bit, uint &val, uint &tmp )										\
	{
		tmp = val & 7;
		if (bit <  29)
			{bit +=  3;	val >>= 3;}
		else					
		if (bit == 29)			
		{
			bit =   0; 
			val = getUint((byte*)(src + ++lin)); 
		}	
		else								
		if (bit == 30)						
		{
			bit =   1; 
			val = getUint((byte*)(src + ++lin)); 
			tmp += (val&1)<<2; val >>= 1;
		}
		else															
		{
			bit =   2; 
			val = getUint((byte*)(src + ++lin)); 
			tmp += (val&3)<<1; val >>= 2;
		}
	}
#endif

	//	Unpack 4 bits
#ifndef _WIN32_WCE
	#define DEBIT4( src,lin,bit,val,tmp )										\
	{																						\
		tmp = val &15;																	\
		if (bit <  28)																	\
			{bit +=  4; val >>= 4;}													\
		else																				\
		if (bit == 28)																	\
			{bit =   0; val = src[++lin]; }										\
		else																				\
		if (bit == 29)																	\
			{bit =   1; val = src[++lin]; tmp += (val&1)<<3; val >>= 1;}\
		else																				\
		if (bit == 30)																	\
			{bit =   2; val = src[++lin]; tmp += (val&3)<<2; val >>= 2;}\
		else																				\
			{bit =   3; val = src[++lin]; tmp += (val&7)<<1; val >>= 3;}\
	}
#else
	static inline void DEBIT4( uint* src, uint &lin, uint &bit, uint &val, uint &tmp )										
	{																						
		tmp = val &15;																	
		if (bit <  28)																	
			{bit +=  4; val >>= 4;}													
		else																		
		if (bit == 28)
		{
			bit =   0; 
			val = getUint((byte*)(src + ++lin)); 
		}
		else																	
		if (bit == 29)
		{
			bit =   1; 
			val = getUint((byte*)(src + ++lin)); 
			tmp += (val&1)<<3; val >>= 1;
		}
		else															
		if (bit == 30)	
		{
			bit =   2; 
			val = getUint((byte*)(src + ++lin)); 
			tmp += (val&3)<<2; val >>= 2;
		}
		else
		{
			bit =   3; 
			val = getUint((byte*)(src + ++lin)); 
			tmp += (val&7)<<1; val >>= 3;
		}
	}
#endif
#ifndef _WIN32_WCE
	//	Unpack any quantity of bits
	#define DEBITS( src,lin,bit,val,tmp,num )									\
	{																						\
		uint	sht = 32-bit ;															\
		tmp = val &Gud[num];															\
		if (num <  sht)																\
			{bit += num;	val >>= num;}											\
		else																				\
			{val = src[++lin]; tmp += (val&Gud[bit = num-sht])<<  sht;	\
																		val  >>= bit;}	\
	}
#else
		//	Unpack any quantity of bits
	static inline void DEBITS(uint *src, uint &lin, uint &bit, uint &val, uint &tmp, uint num )									
	{																				
		uint	sht = 32-bit;
		tmp = val &Gud[num];
		if (num <  sht)
		{
			bit += num;	val >>= num;
		}
		else
		{
			val = getUint((byte*)(src + ++lin)); 
			tmp += (val & Gud[bit = num-sht])<<  sht;	
			val  >>= bit;
		}
	}
#endif

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */

#endif
