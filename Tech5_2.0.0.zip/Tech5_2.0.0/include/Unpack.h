/**************************************
            UNNPACK.H 
		Definitions for facets.

        Copyright (c) 1994-2004.
        Copyright (c) 2005-2012.
***************************************/
#pragma		once
#ifndef		UNPACK_H
#define		UNPACK_H

// Functional dependence
#include   "Ldsdef.h"

//export-import control
#if defined  (LIBLDS)
   #ifndef    PCK_EI
   #define    PCK_EI
   #endif
#elif defined(UNPACK)
   #ifndef    PCK_EI
   #define    PCK_EI	__declspec( dllexport )
   #endif
#else
   #ifndef    PCK_EI
   #define    PCK_EI	__declspec( dllimport )
   #endif
#endif

#pragma pack(push,_LDS_PACKING)
_LDS_BEGIN
/**************************************
      List of export enumerators
**************************************/
enum LAUNCH
	{//template deblocking factor for
	CAES_A = 1 << 0,                              //accelerator	(default is on)
	CAES_G = 1 << 1,                              //geometry between minutiae (default is on)
	CAES_H = 1 << 2,                              //distance with taking density into account (explicit)
	CAES_P = 1 << 3                               //topological proximity (default is on)
	};

enum SOCKET
	{//factor for linkages: max, min, accelerators, minutiae in nest
	LIMA = 35,
	LIMI = 05,
   SISE = 05,
   TRIO = 16
	};

#pragma pack(push,_LDS_TIGHT)
/**************************************
   Special interface declarations
**************************************/
template<class _Ty>
struct Dot
	{//cartesian point
   typedef Dot<_Ty> Self_t;
   typedef     _Ty  sute_t;

   Dot( const _Ty &_X,const _Ty &_Y ) : Movx(_X),Movy(_Y) 
      {//construct from
      }

   Dot() : Movx(),Movy() 
      {//construct default
      }

	Self_t & 
      operator=( const Self_t &_Right )
         {//assign operator
         Movx = _Right.Movx;
         Movy = _Right.Movy; 
         return(*this);
         }

	Self_t &
      operator+=( const Self_t &_Left )
		   {//add other dot
		   Movx += _Left.Movx;
		   Movy += _Left.Movy; 
         return (*this);
		   }

	Self_t &
      operator-=( const Self_t &_Left )
		   {//subtract other dot
		   Movx -= _Left.Movx;
		   Movy -= _Left.Movy;
		   return (*this);
		   }

	Self_t &
      operator*=( const Self_t &_Left )
		   {//multiply by other dot
         Movx *= _Left.Movx;
         Movy *= _Left.Movy;
		   return (*this);
		   }

	Self_t & 
      operator/=( const Self_t &_Left )
		   {//divide by other dot
		   Movx /= _Left.Movx;
         Movy /= _Left.Movy;
		   return (*this);
		   }

	Self_t
      operator+( const Self_t &_Left ) const
		   {//add other dot
		   Self_t _Tmp = *this; 
         return (_Tmp += _Left);
		   }

	Self_t
      operator-( const Self_t &_Left ) const
		   {//subtract other dot
		   Self_t _Tmp = *this;
		   return (_Tmp -= _Left);
		   }

	Self_t 
      operator*( const Self_t &_Left ) const
		   {//multiply by other dot
		   Self_t _Tmp = *this;
		   return (_Tmp *= _Left);
		   }

	Self_t 
      operator/( const Self_t &_Left ) const
		   {//divide by other dot
		   Self_t _Tmp = *this;
		   return (_Tmp /= _Left);
		   }
	
	template<class _Other> Self_t &
      operator()( const _Other &_Left )
		   {//transformation
		   Movx = (_Left.L_re + _Left.R_re)/2;
		   Movy = (_Left.T_re + _Left.B_re)/2;	   
		   return (*this);
		   }
	
	_Ty //pair coordinates
		Movx,
		Movy;
	};

// Cartesian coordinates
typedef Dot<iint_t>  Point;

struct Signet : public Point
	{//triplet
   typedef Signet Self_t;

   Signet( iint_t _X,iint_t _Y,byte_t _T ) : Point(_X,_Y),Type(_T) 
      {//construct from
      }

   Signet( iint_t _X,iint_t _Y ) : Point(_X,_Y),Type() 
      {//construct from
      }

   Signet() : Point(),Type() 
      {//construct default
      }
	
	byte_t //type of signet
		Type;
	};

struct Sign : public Signet
	{//feature
   typedef Sign Self_t;

	Sign( iint_t _X,
         iint_t _Y,byte_t _T,
                   byte_t _P,twin_t _B,byte_t _L,
                                       byte_t _K,
                                       byte_t _C ) : Signet(_X,_Y,_T),Beta(_B),Prob(_P),Lace(_L),Look(_K),Curl(_C) 
      {//construct from
      }

	Sign( iint_t _X,
         iint_t _Y,byte_t _T,
                   byte_t _P,twin_t _B ) : Signet(_X,_Y,_T),Prob(_P),Beta(_B),Lace(),Look(),Curl() 
      {//construct from
      }

	Sign( iint_t _X,
         iint_t _Y,byte_t _T,twin_t _B ) : Signet(_X,_Y,_T),Beta(_B),Prob(),Lace(),Look(),Curl() 
      {//construct from
      }

	Sign( iint_t _X,
         iint_t _Y ) : Signet(_X,_Y),Beta(),Prob(),Lace(),Look(),Curl() 
      {//construct from
      }

   Sign() : Signet(),Beta(),Prob(),Lace(),Look(),Curl() 
      {//construct default
      }

   twin_t //direction
      Beta;
	byte_t //parameters
		Prob,
		Lace,
		Look,
		Curl;
	};

struct Link
	{//topology vector
	twin_t //linkage minutiae
		Item[LIMA],
		Size[LIMA];

	byte_t //linkage events
		Deal[LIMA],
		Pink[LIMA],
      Comb[LIMA];

	};//Link

struct Nest : public Link, public Sign
	{//complex nest
   Nest() : Sign(),Cage(),Prox()
		{//construct default
		}

	uint_t //link's accelerator
		Clou[SISE],
      Char[SISE],
		Mask[SISE];

	byte_t //nest parameters
		Cage,
		Prox;

	};//Nest

struct Node : public Nest
	{//complex nest
   Node() : Nest()
		{//construct default
		}

	twin_t //geometry property
		Teta[LIMA],
		Hand[LIMA];

   };//Node

struct Kind
	{//list of classes
   Kind() : Rank()
		{//construct default
      }

   quad_t //classes
      Rank;

   };//Kind

struct Clat
	{//class type
   Clat() : Inex(),Mode()
		{//construct default
      }

   twin_t //number, property
      Inex,
      Mode;

   };//Clat

#pragma pack(pop)
/**************************************
      Template code deblocking
**************************************/
class PCK_EI Unpack
	{typedef  Unpack Self_t;

	//have forbiden
	void_t operator&() const;
	void_t operator*() const;

public:
	//----------------------------------
	// Control functions
	//----------------------------------
	static
		Self_t*	create();                         //create object
	static
		void_t   cancel(       Self_t*&_Obj );		 //delete object
	virtual
		bool_t   factor( const LAUNCH  _Key ) = 0; //unpack factor

	//----------------------------------
	// Verify template
	//----------------------------------
	virtual
		bool_t   verify( const byte_t *_Tpl ) = 0; //partial template inspection
	virtual
		bool_t   defend( const byte_t *_Tpl ) = 0; //verify template by module

	//----------------------------------
	// Isolated parameters
	//----------------------------------
	virtual
		uint_t   length( const byte_t *_Tpl ) = 0; //template length
	virtual
		byte_t   versor( const byte_t *_Tpl ) = 0; //version number of template
	virtual
		byte_t   qualit( const byte_t *_Tpl ) = 0; //get pattern quality
	virtual
		byte_t   densit( const byte_t *_Tpl ) = 0; //get pattern density
	virtual
		byte_t   passxy( const byte_t *_Tpl ) = 0; //get radius pass
	virtual
		byte_t   passan( const byte_t *_Tpl ) = 0; //get angle pass
	virtual
		byte_t   square( const byte_t *_Tpl ) = 0; //get image area
	virtual
		byte_t   immask( const byte_t *_Tpl ) = 0; //get image mask
	virtual
		twin_t   exmask( const byte_t *_Tpl ) = 0; //get extended image mask
	virtual 
		twin_t   size_x( const byte_t *_Tpl ) = 0; //get <x> size of image
	virtual 
		twin_t   size_y( const byte_t *_Tpl ) = 0; //get <y> size of image
	virtual 
		twin_t   imgppi( const byte_t *_Tpl ) = 0; //image processing PPI
	virtual 
		twin_t   tplppi( const byte_t *_Tpl ) = 0; //template PPI

	//----------------------------------
	// Isolated deblocking
	//----------------------------------
	virtual
		twin_t   demain( Sign  *const  _Dst,
							  const byte_t *_Tpl ) = 0; //singularities deblocking
	virtual
		twin_t   denova( Sign  *const	 _Dst,
							  const byte_t *_Tpl ) = 0; //minutiae deblocking
	virtual
		twin_t   denest( Nest  *const	 _Dst,
							  const byte_t *_Tpl ) = 0; //minutiae & linkages deblocking
	virtual
		twin_t   denode( Node  *const	 _Dst,
							  const byte_t *_Tpl ) = 0; //rich minutiae & linkages deblocking
	virtual
	   twin_t   detrio( Kind  *const  _Dst,
                       const byte_t *_Tpl ) = 0; //triangles deblocking
	virtual
	   twin_t   deverb( Clat  *const  _Dst,
                       const byte_t *_Tpl ) = 0; //triangles deblocking
	virtual
		twin_t   deabac( byte_t*const  _Dst,
							  const byte_t *_Tpl ) = 0; //ridge count deblocking
	virtual
		uint_t   dearea( byte_t*const  _Dst,
							  const byte_t *_Tpl ) = 0; //list of area deblocking

	//----------------------------------
	// Read size of
	//----------------------------------
	virtual
		twin_t   idmain( const byte_t *_Tpl ) = 0; //number of singularities
	virtual
		twin_t   idnova( const byte_t *_Tpl ) = 0; //number of minutiae
	virtual
		uint_t   idarea( const byte_t *_Tpl ) = 0; //size of area

	};//Unpack

_LDS_END
#pragma pack(pop)
#endif//UNPACK_H
/*
All rights reserved. Consult your license regarding permissions and restrictions.
*/
