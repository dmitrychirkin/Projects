/*****************************************************************************
	FpTemplate.h - header file for FpTemplate class

*******************************************************************************/
#ifndef FP_TEMPLATE_H__
#define FP_TEMPLATE_H__

#include "coreSdk.h"
#include "core_err.h"
#include "Unwrap.h"

/******************************************************************
          Template Information class
******************************************************************/

class FpTemplate
{
   bool               m_init;
   BYTE              *m_area;
   ESK::Unwrap       *m_unpack;

public:
	FpTemplate();
	~FpTemplate();

   /*   
      Extract information about minutiae from fingerprint template
      Parameters:
      fpTemplate  (input)  - pointer to the fingerprint template
      numMinutiae (output) - number of minutiae
      minutiae    (output) - minutiae information
      Function returns TI_OK - if function succeeds, error code - otherwise
   */
   int getMinutiae (const BYTE * fpTemplate, unsigned int &numMinutiae, 
                     Minutiae minutiae[MAX_MINUTIAE]);
   /*   
      Extract information about core/delta from fingerprint template
      Parameters:
      fpTemplate     (input)  - pointer to the fingerprint template
      numSingular (output) - number of Singular
      Singular    (output) - core/delta information
      pattern        (output) - pattern type
      Function returns TI_OK - if function succeeds, error code - otherwise
   */
   int getSingular (const BYTE * fpTemplate, unsigned int &numSingular,
                       Singular singular[MAX_SINGULAR],
                        unsigned int &pattern);
   /*   
      Extract information about bad (not informative) are from fingerprint template
      Parameters:
      fpTemplate (input)  - pointer to the fingerprint template
//      frame      (input)  - the location of fingerprint image location in whole image
//                            (with white space cut off), that were returned 
//                            by 'processEx' function of Ip
      area       (output) -  information about bad (not informative) area.
                             Each item correspond to the one pixel.
                             If corresponded  item == 0 then this pixel is 
                             belong to unclear area. Memory for that buffer should 
                             be allocated in application. Buffer should have at least 
                             (width * height) bytes size.
      Function returns TI_OK - if function succeeds, error code - otherwise
   */
   int getArea (const BYTE * fpTemplate,/* Frame *frame, */BYTE *area);
    /*
      Extract information about fingerprint image quality from fingerprint template
      Parameters:
      fpTemplate (input)  - pointer to the fingerprint template
      quality    (output) - fingerptint image quality
      Function returns TI_OK - if function succeeds, error code - otherwise
    */
   int getQuality   (const BYTE * fpTemplate, BYTE &quality);
    /*
      Extract information about fingerprint image size from fingerprint template
      Parameters:
      fpTemplate (input)  - pointer to the fingerprint template
      width     (output) - fingerptint image width
      height    (output) - fingerptint image height
      Function returns TI_OK - if function succeeds, error code - otherwise
    */
   int getImageSize (const BYTE * fpTemplate, int &width, int &height);
    /*
      Return finerprint template version
      Parameters:
      fpTemplate (input)  - pointer to the fingerprint template
    */
   int getVersion   ( const BYTE * fpTemplate);
    /*
      Extract information about finger position from fingerprint template
      Parameters:
      fpTemplate (input)  - pointer to the fingerprint template
      finger    (output) - finger position
      Function returns TI_OK - if function succeeds, error code - otherwise
    */
   int getFingerPos   ( const BYTE * fpTemplate, FINGERS &finger           );

private:
   bool init();
   bool checkTemplate73  (const BYTE * fpTemplate);
   bool checkTemplate75  (const BYTE * fpTemplate);
   bool checkTemplate110 (const BYTE * fpTemplate);

   int getArea110 (const BYTE * fpTemplate,/* Frame *frame, */BYTE *area);

   int getSingular110 (const BYTE * fpTemplate, unsigned int &numSingular,
                         Singular singular[MAX_SINGULAR],
                         unsigned int &pattern);

   int getMinutiae110 (const BYTE * fpTemplate, unsigned int &numMinutiae, 
                      Minutiae minutiae[MAX_MINUTIAE]);

   int getQuality73  (const BYTE * fpTemplate, BYTE &quality);
   int getQuality110 (const BYTE * fpTemplate, BYTE &quality);

   int getImageSize73  (const BYTE * fpTemplate, int &width, int &height);
   int getImageSize110 (const BYTE * fpTemplate, int &width, int &height);

   int getFingerPos73  (const BYTE * fpTemplate, FINGERS &fingerPos);
};

#endif // FP_TEMPLATE_H__
