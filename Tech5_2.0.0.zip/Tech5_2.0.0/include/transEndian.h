/*
   transEndian.h - declare function for transform multibytes values
   from little-endian to big-endian and from big-endian to little-endian format
*/

#ifndef TRANS_ENDIAN_H_
#define TRANS_ENDIAN_H_

#include "win2lin.h"

#pragma pack(push, _CORE_PACKING)

inline DWORD swapDWORD(DWORD v)
{
   DWORD result = v;
   unsigned char *src = (unsigned char *)&v;
   unsigned char *dst = (unsigned char *)&result;
   dst[3] = src[0]; 
   dst[2] = src[1]; 
   dst[1] = src[2]; 
   dst[0] = src[3]; 
   return result;
}

inline WORD swapWORD(WORD v)
{
   WORD result = v;
   unsigned char *src = (unsigned char *)&v;
   unsigned char *dst = (unsigned char *)&result;
   dst[1] = src[0]; 
   dst[0] = src[1]; 
   return result;
}

#pragma pack(pop)
#endif // TRANS_ENDIAN_H_