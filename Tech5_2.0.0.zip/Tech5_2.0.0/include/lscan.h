/*****************************************************************************
	LScan.h - header file for LScan.dll		

   The LScan.dll is intended for work with live scanner
   
******************************************************************************
	
	Copyright (C) 2005 Sonda Technologies Ltd.
	
	Version 1.1.0 of 14.05.2005
	    
*******************************************************************************/
#ifndef LSCAN_H_
#define LSCAN_H_

//#ifdef WINDOWS
#ifdef LSCAN_EXPORT
   #define LIVE_SCAN_API __declspec(dllexport)
#else
   #define LIVE_SCAN_API __declspec(dllimport)
#endif
//#endif

#include <string.h>
#include <stdlib.h>
#include <wchar.h>
#include <math.h>
//#include <core_err.h>
//#include <coreSdk.h>
//#include "sfsDef.h"
//#include "ImageUtl.h"

/* common constants*/
#define S_MAX_DESCR_LENGTH      255     /* maximum length of error messages in characters */
#define ENDLESSLY               -1	

// change value from DPI to PixelPerMeter
#ifndef DPI2PPM
#define DPI2PPM(x) ((DWORD)(x * 10000 / 254 + 0.5))  
#endif


#if defined(_WINDOWS)

#ifndef _WIN32_WCE
#include <process.h>
#endif
#include <time.h>

#else

#include <signal.h>
#include <pthread.h>
#include <unistd.h>

typedef void*	HANDLE;
typedef void*	HWND;

#undef  LIVE_SCAN_API
#define LIVE_SCAN_API

#endif

#ifdef OLD_NAMES
#define CALL_CONVENTION __stdcall
#else
#define CALL_CONVENTION
#endif // OLD_NAMES

const int offset = sizeof(BITMAPINFOHEADER) + 256 * sizeof (RGBQUAD);

#define  THREAD_TIMEOUT     3000      // timeout waiting of thread termination 
//#define  THREAD_TIMEOUT       INFINITE      // timeout waiting of thread termination 


/* return codes */
#define LS_OK                   DAPI_OK                /* Success */
#define LSE_LOW_MEMORY          DAPI_LOW_MEMORY        /* Insufficient memory available */
#define LSE_UNKN_EXCEPTION      DAPI_UNKN_EXCEPTION    /* unknown exception raised */
#define LSE_NOT_INITIALIZED     DAPI_NOT_OPENED        /* Scan device was not opened */
#define LSE_CANCEL              DAPI_CANCEL            /* The capture process canceled by user */
#define LSE_TIMEOUT             DAPI_TIMEOUT           /* The timeout is expired */
#define LSE_NOT_IMPLEMENTED     DAPI_NOT_IMPLEMENTED   /* The function is not implemented */
#define LSE_OPEN                DAPI_OPEN_SENSOR       /* error open device */
#define LSE_DEVICE              DAPI_DEVICE            /* Scan device error. You can get additional  
							                                     information call 'getErrorMessage' function */
#define LSE_SYSTEM              DAPI_SYSTEM            /* system error */
#define LSE_LOAD_SCANDLL        DAPI_LOAD_SCANDLL      /* cannot load corresponded scan DLL*/
#define LSE_NO_SUCH_SENSOR      DAPI_NO_SUCH_SENSOR
#define LSE_WRONG_PARAMETRS		DAPI_WRONG_PARAMETRS
#define LSE_SPOOF_FINGER		DAPI_SPOOF_FINGER		/* possible spoofed finger image*/


// value that used for check if class object really was initialized
#define INIT_VALUE         0x12345678
#define CHECK_OPEN_VALUE   1234567890

/*
	typedef function that will be called when fingerprint image captured
	if result = LS_OK, then *p - pointer to DIB, that contains
	final captured image data. This memory is valid until the next call 
	of 'scan' or 'start' or 'close' functions or unload the dll
	if result = LSE_DEVICE, then p contains pointer to error message string
	in other cases result contains error code
*/

typedef void (* ON_GET_IMAGE) (int result, unsigned char** p, void* data);

// the scan thread control function 
#if defined(_WINDOWS)
static unsigned int __stdcall controlFunction(void* param);
#else
static void* controlFunction(void* param);
#endif

#if defined(_WINDOWS)
static unsigned int __stdcall controlFunction2(void* param);
#else
static void* controlFunction2(void* param);
#endif

class SdkSensor
{
public:
	int                m_init;			// flag is memory for the object was allocated
	int                m_open;			// flag is object was initialized
	HWND               m_parent;		// handle of the parent window		
	HANDLE             m_scanThread;	// scan thread handle
	unsigned char     *m_buffer;		// buffer for DIB
	unsigned char     *m_buffer1;		// temporary buffer
	BYTE              *m_image;      // pointer to the captured image bytes
	LPBITMAPINFOHEADER m_bih;        // captured image DIB header
	WORD               m_maxX;                        
	WORD               m_maxY;
	int                m_timeout;
	volatile bool      m_stop;
	ON_GET_IMAGE  m_func;          
	void				*m_user_context;
	wchar_t            m_msg[S_MAX_DESCR_LENGTH];
	bool               m_needInvert;
	bool               m_needFlipH;
	bool               m_needFlipV;
	bool               m_needStretch;

public:
   SdkSensor()
   {
      m_init         = 0;
      m_open         = 0;
      m_parent       = 0;
      m_scanThread   = 0;
      m_buffer       = NULL;
      m_buffer1      = NULL;
      m_maxX         = 0;
      m_maxY         = 0;
      m_timeout      = 0;
      m_stop         = true;
      m_image        = NULL;
      m_bih          = NULL;
      m_func         = NULL;
	  m_user_context = NULL;
      m_msg[0]       = 0;
      m_needInvert   = false;
      m_needFlipH    = false;
      m_needFlipV    = false;
      m_needStretch  = false;
   }

   virtual ~SdkSensor()
   {
      if (m_buffer) 
         delete[] m_buffer; m_buffer = NULL;
      if (m_buffer1) 
         delete[] m_buffer1; m_buffer1 = NULL;
	  m_init         = 0;
	  m_open         = 0;
	  m_parent       = 0;
	  m_scanThread   = 0;
	  m_buffer       = NULL;
	  m_buffer1      = NULL;
	  m_maxX         = 0;
	  m_maxY         = 0;
	  m_timeout      = 0;
	  m_stop         = true;
	  m_image        = NULL;
	  m_bih          = NULL;
	  m_func         = NULL;
	  m_user_context = NULL;
	  m_msg[0]       = 0;
	  m_needInvert   = false;
	  m_needFlipH    = false;
	  m_needFlipV    = false;
	  m_needStretch  = false;
   }

   int init(WORD width, WORD height, HWND parent, bool invert = false, 
            bool needFlipH = false, bool needFlipV = false, bool needStretch = false)
   {
      m_maxX = width;
      m_maxX = (m_maxX + 3) / 4 * 4;
      m_maxY = height;
      m_parent = parent;
      m_needInvert = invert;
      m_needFlipH = needFlipH;
      m_needFlipV = needFlipV;
      m_needStretch = needStretch;
	  if (m_buffer) 
		  delete[] m_buffer;
	  m_buffer = new unsigned char[m_maxX * m_maxY + offset + offset];
	  if (m_buffer1) 
		  delete[] m_buffer1;
	  m_buffer1 = new unsigned char[m_maxX * m_maxY];
	  if (!m_buffer || !m_buffer1) 
		  return LSE_LOW_MEMORY;
	  
	  memset(m_buffer,0,m_maxX * m_maxY + offset + offset);
	  memset(m_buffer1,0,m_maxX * m_maxY);
	  m_bih = (LPBITMAPINFOHEADER)m_buffer;
	  memset (m_bih, 0, sizeof(BITMAPINFOHEADER));
	  m_bih->biWidth = width;
	  m_bih->biHeight = -height;
	  m_bih->biSizeImage = width * height;
	  m_bih->biBitCount = 8;
	  m_bih->biCompression = BI_RGB;
	  m_bih->biPlanes = 1;
	  m_bih->biSize = sizeof(BITMAPINFOHEADER);
	  m_bih->biXPelsPerMeter = DPI2PPM(500);
	  m_bih->biYPelsPerMeter = DPI2PPM(500);
	  LPRGBQUAD rgb = (LPRGBQUAD)(m_buffer + sizeof(BITMAPINFOHEADER));
	  memset (rgb, 0, 256 * sizeof (RGBQUAD));
	  for(int i = 0; i < 256; i++)
		{
			rgb[i].rgbBlue = rgb[i].rgbGreen = 
			  rgb[i].rgbRed = i;
		}
	  m_image = m_buffer + offset;
	  m_open = CHECK_OPEN_VALUE;
      return LS_OK;
   }
   bool isInit ()
   {
      return (m_init == INIT_VALUE);
   }
   bool isOpen ()
   {
      return (m_open == CHECK_OPEN_VALUE);
   }
   
   // paint current image to the parent window
   void paint()
   {
/*
      if (!m_parent)
         return;
	   HDC hDc = GetDC (m_parent);
	   if(!hDc) return;		

	   RECT rect;
	   GetClientRect (m_parent, &rect);
	   int width = abs(rect.right - rect.left);
	   int height = abs(rect.top - rect.bottom);
	   HBRUSH hBrush = CreateSolidBrush(RGB(255, 255, 255));
	   FillRect(hDc, &rect,  hBrush); 
      DeleteObject(hBrush);

      if (!m_bih || !m_image)
         return;
	   LPBITMAPINFO bi = (LPBITMAPINFO)m_bih;
      bool isFirst = true;
      int srcWidth = m_bih->biWidth;
      int srcHeight = abs(m_bih->biHeight);
      if (m_needInvert)
	      invert(m_image, srcWidth, srcHeight);
      if (m_needFlipH)
      {
         flipH (isFirst ? m_image : m_buffer1, 
                isFirst ? m_buffer1 : m_image, srcWidth, srcHeight);
         isFirst = !isFirst;
      }
      if (m_needFlipV)
      {
         flipH (isFirst ? m_image : m_buffer1, 
                isFirst ? m_buffer1 : m_image, srcWidth, srcHeight);
         isFirst = !isFirst;
      }
	  int dstWidth = width, dstHeight = height;
	  int x0 = 0, y0 = 0;
	  int k = 1;
	  if(m_needStretch)
	  {
		  ;
	  }
	  else
	  {
		  if (srcHeight > height || srcWidth > width)
		  {
			  while ((srcHeight > (height << k)) || 
				  (srcWidth > (width << k))
				  ) k++;
			  dstWidth  = srcWidth   >> k;
			  dstHeight = srcHeight >> k;
		  }
		  else
		  {
			  while ((srcHeight < (height >> k)) && 
				  (srcWidth < (width >> k))
				  ) k++;
			  dstWidth = srcWidth   << (k - 1);
			  dstHeight = srcHeight << (k - 1);
		  }
		  x0 = (width  - dstWidth)  / 2;
		  y0 = (height - dstHeight) / 2;
	  }

	   // Make sure to use the stretching mode best for color pictures 
#if !defined(_WIN32_WCE)
	   SetStretchBltMode(hDc, COLORONCOLOR);
#endif
	   StretchDIBits(hDc, x0, y0, dstWidth, dstHeight, 0, 0, 
         srcWidth, srcHeight, isFirst ? m_image : m_buffer1, bi, 
				   DIB_RGB_COLORS, SRCCOPY ); 
*/
	   return;
   }
   /*
	   Stop capture 
	   return LS_OK if success, error code otherwise
   */
   int stop()
   {
	   if(!isInit()) 
		   return LSE_NOT_INITIALIZED;
	   m_msg[0] = 0;
	   m_stop = true;
	if(m_scanThread != NULL)
#if defined (_WINDOWS)
		WaitForSingleObject(m_scanThread,THREAD_TIMEOUT);
#else
		sleep(THREAD_TIMEOUT/1000);
#endif
//	   m_scanThread = NULL;
	   return LS_OK;
   }

#if !defined(_WIN32_WCE)

   /*
	   start capture fingerprint image in the separate thread thread 
	   This process can be stopped any time by calling stop() function
	   Function send send 'WM_TAKE_IMAGE' message to the parent window
	   return LS_OK if success, error code otherwise
	   When function return 'data' contain captured image
	   parent - handle of the parent window that will be get messages
	   timeOut - timeout (sec)
   */

   int start(ON_GET_IMAGE pFunc, int TimeOut, void* data)
   {
	   if(!isInit()) 
         return LSE_NOT_INITIALIZED;

	   m_msg[0] = 0;
	   m_timeout = TimeOut;
	   if (m_scanThread)
	   {
		   try
		   {
			   stop();
#if defined (_WINDOWS)
			   TerminateThread(m_scanThread,LSE_CANCEL);
#else
			   pthread_kill((pthread_t)m_scanThread,LSE_CANCEL);
#endif
			   m_scanThread = NULL;
		   }
		   catch(...)
		   {
		   }
	   }
	   m_stop = false;
	   m_func = pFunc;
	   m_user_context = data;
#if defined(_WINDOWS)
	   unsigned tid = 0; 
	   m_scanThread = (HANDLE)_beginthreadex (NULL, NULL, controlFunction, 
										   (void*)this, NULL, &tid);
#else
	   pthread_t	tid;
	   if( pthread_create(&tid,NULL,controlFunction,(void*)this) == 0)
		   m_scanThread = (HANDLE)tid;
#endif
	   if(m_scanThread)
		   return LS_OK;
	   else
		   return LSE_UNKN_EXCEPTION;
   }

   /*
	   start capture fingerprint image in the separate thread thread 
	   This process can be stopped any time by calling stop() function
	   Function send send 'WM_TAKE_IMAGE' message to the parent window
	   return LS_OK if success, error code otherwise
	   When function return 'data' contain captured image
	   parent - handle of the parent window that will be get messages
	   timeOut - timeout (sec)
   */

   int start2(ON_GET_IMAGE pFunc, int TimeOut, void* data)
   {
	   if(!isInit()) 
         return LSE_NOT_INITIALIZED;

	   m_msg[0] = 0;
	   m_timeout = TimeOut;
	   if (m_scanThread)
	   {
		   try
		   {
			   stop();
#if defined (_WINDOWS)
			   TerminateThread(m_scanThread,LSE_CANCEL);
#else
			   pthread_kill((pthread_t)m_scanThread,LSE_CANCEL);
#endif
			   m_scanThread = NULL;
		   }
		   catch(...)
		   {
		   }
	   }
	   m_stop = false;
	   m_func = pFunc;
	   m_user_context = data;
#if defined(_WINDOWS)
	   unsigned tid = 0; 
	   m_scanThread = (HANDLE)_beginthreadex (NULL, NULL, controlFunction2, 
										   (void*)this, NULL, &tid);
#else
	   pthread_t	tid;
	   if( pthread_create(&tid,NULL,controlFunction2,(void*)this) == 0)
		   m_scanThread = (HANDLE)tid;
#endif
	   if(m_scanThread)
		   return LS_OK;
	   else
		   return LSE_UNKN_EXCEPTION;
   }

#endif // _WIN32_WCE
   /*
	   Capture fingerprint image
	   return LS_OK if success, error code otherwise
	   When function return '*dib' contain captured image as pointer to DIB
	   Parent - handle of the parent window, where will be draw the current fingerprint 
			   image while scanning. If this parameter is NULL, image won't be drawing.
	   timeOut - timeout (sec)
   */
   int scan(BYTE **dib, int timeOut)
   {
	   if(!isInit()) 
         return LSE_NOT_INITIALIZED;

	   m_msg[0] = 0;
	   m_timeout = timeOut;
	   if (m_scanThread) 
         stop();
	   m_stop = false;
	   int result = getImage();
	   if (result == LS_OK || result == LSE_SPOOF_FINGER)
		   *dib = m_buffer;
	   return result;
   }

   /*
	   Capture fingerprint image
	   return LS_OK if success, error code otherwise
	   When function return '*dib' contain captured image as pointer to DIB
	   Parent - handle of the parent window, where will be draw the current fingerprint 
			   image while scanning. If this parameter is NULL, image won't be drawing.
	   timeOut - timeout (sec)
   */
   int scan2(BYTE **dib, int timeOut)
   {
	   if(!isInit()) 
         return LSE_NOT_INITIALIZED;

	   m_msg[0] = 0;
	   m_timeout = timeOut;
	   if (m_scanThread) 
         stop();
	   m_stop = false;
	   int result = getImage2();
	   if (result == LS_OK || result == LSE_SPOOF_FINGER)
		   *dib = m_buffer;
	   return result;
   }

   // capture the fingerprint image
   virtual int getImage() = 0;

   // capture the fingerprint image
   virtual int getImage2() = 0;
   /*
	   return text description of the last error
   */
   wchar_t* getLastErrorMessage ()
   {
	   if(!isInit()) 
         return NULL;
	   return m_msg;
   }
   void setErrorMessage (const wchar_t* str)
   {
	   m_msg[0] = 0;
	   if (!str) return;
	   try
	   {
			memcpy(m_msg,str,wcslen(str)*sizeof(str));
	   }
	   catch(...)
	   {
	   }
   }

};


// the scan thread control function 
#if defined(_WINDOWS)
static unsigned int __stdcall controlFunction(void* param)
#else
static void* controlFunction(void* param)
#endif //_WINDOWS
{
	int result = LS_OK;
	SdkSensor *sensor = (SdkSensor*)param;

	try
	{
		if(!sensor || !sensor->isInit()) 
		  throw LSE_NOT_INITIALIZED;

		result = sensor->getImage();

		if(sensor->m_func != NULL)
			sensor->m_func(result,&sensor->m_buffer,sensor->m_user_context);
		else
			throw LSE_CANCEL;
	}
	catch(int code)
	{
		result = code;
	}
	catch(...)
	{
		result = LSE_UNKN_EXCEPTION;
	}
#if defined(_WINDOWS)
	return result;
#else
	return (void*)result;
#endif
}

// the scan thread control function 
#if defined(_WINDOWS)
static unsigned int __stdcall controlFunction2(void* param)
#else
static void* controlFunction2(void* param)
#endif //_WINDOWS
{
	int result = LS_OK;
	SdkSensor *sensor = (SdkSensor*)param;

	try
	{
		if(!sensor || !sensor->isInit()) 
		  throw LSE_NOT_INITIALIZED;

		result = sensor->getImage2();

		if(sensor->m_func != NULL)
			sensor->m_func(result,&sensor->m_buffer,sensor->m_user_context);
		else
			throw LSE_CANCEL;
	}
	catch(int code)
	{
		result = code;
	}
	catch(...)
	{
		result = LSE_UNKN_EXCEPTION;
	}
#if defined(_WINDOWS)
	return result;
#else
	return (void*)result;
#endif
}

#ifdef __cplusplus
extern "C" { 			
#endif  /* __cplusplus */


/*
	Initializes work with scan device
	function returns LS_OK - if function succeeds, error code - otherwise
	parent - handle of the parent window, where will be draw the current fingerprint 
			image while scanning. If this parameter is NULL, image won't be drawing.
*/
LIVE_SCAN_API int CALL_CONVENTION  init(void* parent, int wParam, SdkSensor *&sensor);
typedef int (* INIT)(void*, int, SdkSensor *&);

/*
	Close work with scan device
	function returns LS_OK - if function succeeds, error code - otherwise
*/
LIVE_SCAN_API int CALL_CONVENTION  closeDevice(SdkSensor *&Sensor);
typedef int (* CLOSEDEVICE)(SdkSensor *&);

/*
	Captures fingerprint image
	function returns LS_OK - if function succeeds, error code - otherwise
	When function returns, '*data' contains captured image as pointer to the DIB
	This memory is valid until the next call of 'scan' or 'start' or 'close' 
	functions or unload the dlltimeOut - the maximum time of scanning (sec). If this value is ENDLESSLY, then
				timeout is never happened.
*/
LIVE_SCAN_API int CALL_CONVENTION  scan(SdkSensor *sensor, BYTE **dib, int timeOut = ENDLESSLY);
typedef int (* SCAN)(SdkSensor*, BYTE **, int);

/*
	Captures fingerprint image
	function returns LS_OK - if function succeeds, error code - otherwise
	When function returns, '*data' contains captured image as pointer to the DIB
	This memory is valid until the next call of 'scan' or 'start' or 'close' 
	functions or unload the dlltimeOut - the maximum time of scanning (sec). If this value is ENDLESSLY, then
				timeout is never happened.
*/
LIVE_SCAN_API int CALL_CONVENTION  scan2(SdkSensor *sensor, BYTE **dib, int timeOut = ENDLESSLY);
typedef int (* SCAN2)(SdkSensor*, BYTE **, int);

/*
	Starts capture fingerprint in the separate thread. This process can be stopped any
	time by calling stop() function
	function returns LS_OK - if function succeeds, false - otherwise
	timeOut - the maximum time of scanning (sec). If this value is ENDLESSLY, then
				timeout is never happened.
	pFunc - pointer to callback function that will be called when 
			fingerprint image will be captured
	data - a pointer to data to be transmitted to the callback.
*/
LIVE_SCAN_API int CALL_CONVENTION  start(SdkSensor *sensor, ON_GET_IMAGE pFunc, int timeOut = ENDLESSLY, void* data = 0);
typedef int (* START)(SdkSensor*, ON_GET_IMAGE, int, void*);

/*
	Starts capture fingerprint in the separate thread. This process can be stopped any
	time by calling stop() function
	function returns LS_OK - if function succeeds, false - otherwise
	timeOut - the maximum time of scanning (sec). If this value is ENDLESSLY, then
				timeout is never happened.
	pFunc - pointer to callback function that will be called when 
			fingerprint image will be captured
	data - a pointer to data to be transmitted to the callback.
*/
LIVE_SCAN_API int CALL_CONVENTION  start2(SdkSensor *sensor, ON_GET_IMAGE pFunc, int timeOut = ENDLESSLY, void* data = 0);
typedef int (* START2)(SdkSensor*, ON_GET_IMAGE, int, void*);

/*
	Stop capture 
	function returns LS_OK - if function succeeds, error code - otherwise
*/
LIVE_SCAN_API int CALL_CONVENTION  stop(SdkSensor *sensor);
typedef int (* STOP)(SdkSensor*);

/*
	return text description of the last error
*/
LIVE_SCAN_API wchar_t* CALL_CONVENTION  getLastErrorMessage (SdkSensor* sensor);
typedef wchar_t* (* GET_LAST_ERROR_MESSAGE) (SdkSensor*);


#ifdef __cplusplus
} /* extern "C"  */
#endif  /* __cplusplus */

#endif // LSCAN_H_
