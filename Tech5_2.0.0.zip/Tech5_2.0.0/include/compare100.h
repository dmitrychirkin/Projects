/*****************************************************************************
	compare100.h - header file for one to one finger matching algorithm of Core Matching SDK
                  using ma100 algorithm 

*******************************************************************************/
 
#ifndef COMPARE_100_H__
#define COMPARE_100_H__

#include "ma100.h"

namespace accelMatch{
#pragma pack(push,_CORE_PACKING)


/******************************************************************
          Compare class
******************************************************************/
class Matcher100;

class Compare100
{
   Matcher100      *m_matcher;        
   BYTE            *m_templ;
   bool             m_init;

public:
	Compare100();
	~Compare100();

	/* 
	 Initialize work with Compare class functions
    Parameters:
    accelHandle (input) - handle of accelMatch library. If it's NULL, library will create it itself
	 Function returns MA_OK - if function succeeds, error code - otherwise
	*/
	int init(void *accelHandle);
	/* 
   Initialize work with Compare class functions
   In differ from 'init' function it take the protection data
   This function (or 'init' function)should be called first before call 
   any other functions
   Parameters:
   accelHandle (input) - handle of accelMatch library. If it's NULL, library will create it itself
   protect     (input) - pointer to MAX_PROTECT_LEN byte buffer with protection data
   Return value:
   The function returns MA_OK - if function succeeds, error code - otherwise
	*/
	int initEx(void *accelHandle, int protect[MAX_PROTECT_LEN]);

   // allocate memory for template
	static int allocateTemplate(BYTE *&templ);
	// free memory that was earlier allocate by 'allocateTemplate' function
	static int freeTemplate(BYTE *&templ);

	/*
	Load probe fingerprint template
	function returns MA_OK - if function succeeds, error code - otherwise
	templP     (input) - probe fingerprint template 
   typeP      (input) - type of probe fingerprint
	*/
	int loadTemplate(BYTE *tempP, FP_TYPE typeP = UNKNOWN);
   /*
	Compare fingerprint template with corresponded finger from set of templates
	that was earlier load by 'loadTemplate' function 
	function returns MA_OK - if function succeeds, error code - otherwise
	param       (input)  - the search parameters
                          NOTE: because finger is not known, it uses maxAngle (not maxAngleThumb)
                          for angle tolerance
	templG      (input)  - gallery fingerprint template for match  
	similarity  (output) - variable that receives the value that shows 
				              how two fingerprints similarity one to other in a range 0...MAX_SCORE
	matchResult (output) - the structure with match result details. 
                          If is is NULL, it not used.
   typeG       (input)  - type of gallery fingerprint
	*/
	int	matchEx (SearchParam &param, BYTE *templG,
                  int &similarity, MatchResult *matchResult, FP_TYPE typeG = UNKNOWN,
                  bool useCombineData = false, BYTE *np = NULL, BYTE *ng = NULL, BYTE accelGroupSize = 0, bool quickAccelMatch = false);

private:
   /*
    allocate memory necessary for work all functions
	 Function returns MA_OK - if function succeeds, error code - otherwise
   */
   int alloc ();
   /*
    free memory allocated in alloc function
	 Function returns MA_OK - if function succeeds, error code - otherwise
   */
   void free();
};

#pragma pack(pop)
} // namespace accelMatch{

#endif // COMPARE_100_H__



