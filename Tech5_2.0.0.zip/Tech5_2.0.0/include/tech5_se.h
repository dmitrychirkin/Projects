#ifndef TECH5_SE_H_
#define TECH5_SE_H_


#if defined( WIN32 ) || defined(_WIN32_WCE) || defined(_WINDOWS)
#  define SDK_SE_PACKED_1
#elif defined( linux ) || defined (ANDROID)
#  define SDK_SE_PACKED_1 __attribute__ ((aligned(1),packed))
#else
#  error Cannot determine alignment - contact your vendor for support
#endif

typedef void* Sensor;

/////////////////////////////////////////////////////////////////////////////////////////

// common values
#define DEVICE_NUM_DEF			FUTRONIC_FS80_88				// first sensor
#define S_MAX_DESCR_LEN			255


/////////////////////////////////////////////////////////////////////////////////////////
// common return value 
#define SE_OK					   0		// Success
#define SE_UNKN_EXCEPTION		1		// Unknown exception raised
#define SE_LOW_MEMORY			2		// Insufficient memory available
#define SE_SYSTEM				   3		// System error. You can get addition 
// information call getErrorDescription function	
#define SE_KEY					   4		// the dongle is not plugged to computer
#define SE_TIME					5		// the evaluation time is expired
#define SE_INIT					6		// the SDK is not initialized
#define SE_HARDWARE				7		//	the computer's hardware not match to license
#define SE_WRONG_POINTER		8     // the value of the one of the pointer that was 
// passed to the function is NULL 
#define SE_WRONG_PARAMETER    9     // the value of the one of the parameters out of range 
#define SE_LOAD_RESOURSE_DLL	10    // cannot load dll 
#define SE_FAM					   11		// the licensed FAM not detected
#define SE_JNI					   12    // JNI (java native interface)  error
#define SE_LICENSE_NOT_FOUND	14		//	license file  not found or not set
#define	SE_MORE_DATA         200   // The size of buffer is not large enough for 
//       required data

/////////////////////////////////////////////////////////////////////////////////////////
// capture functions return values 
#define SE_DEVICE             1000	// Sensor specific error. You can get addition information call getLastErrorMsg function
#define SE_LOAD_SCANDLL       1002  // Cannot load scan dll
#define SE_NOT_INITIALIZED	   1003  // Sensor is not initialized
#define SE_CANCEL             1006  // The capture process is canceled by user
#define SE_TIMEOUT			   1007  // The timeout is expired
#define SE_NOT_IMPLEMENTED	   1008  // The function is not implemented
#define SE_OPEN_SENSOR		   1010  // open sensor error
#define SE_NO_SUCH_SENSOR	   1012  // the sensor with such name or number is not supported
#define SE_NOT_OPEN_SENSOR		1014  // the sensor is not opened
#define SE_SPOOF_IMAGE			1016 // possible fake finger image
/////////////////////////////////////////////////////////////////////////////////////////
// process return values 
/* 
the DIB that was passed to process function is not satisfied to one of following conditions:
- 8 bit per pixel
- uncompressed
- up left (top-down)
- number of planes equal 1
- width  more then zero and multiple for 4
- height is not equal zero
- resolution by X and by Y is equal 500 dpi
*/
#define SE_WRONG_DIB          2000		
#define SE_PROCESSING         2002		// Error occurs while template building
#define SE_IMAGE_TOO_BIG      2020		// The image size is more then MAX_WIDTH x MAX_HEIGHT pixels
#define SE_WRONG_RESOLUTION   2022		// The dib passed to the 'process' function hasn't resolution 500 dpi
#define SE_NO_IMAGE           2024		// The fingerprint image is not found in the source image
#define SE_IMPRESSION_TYPE    2026		// Specified impression type is not supported
#define SE_SAME_FING_ERR      2028		// array of Image structure has members with same value of 
										         // 'finger' field   
										         // NOTE: At this version of software you cannot put into template 
										         // the information about more than one impression per finger. 
#define SE_NULL_IMAGE         2030		// passed image has zero size or pointer to the image is NULL  
#define SE_DIF_FING_SIZE_ERR	2032	   // fingerprint images have different size. 
                                       // NOTE: The fingerprint images those are passed to 'create_NIST_template' or 
                                       // 'create_ISO_template' function should be taken from the same sensor 
                                       // and have the same size 

/////////////////////////////////////////////////////////////////////////////////////////
// Match algorithm return values 
#define SE_MATCH              10002	   // Error occurs while match process
#define SE_WRONG_TEMPLATE     12000	   // The template is wrong
#define SE_NULL_TEMPLATE		12002    // null probe or gallery template
#define SE_NO_LOAD            12004   
#define SE_PROBE_PARSE        12006    // Failed to match templates � unable to parse probe template
#define SE_GALLERY_PARSE      12008    // Failed to match templates � unable to parse gallery template
#define SE_DIF_FING_ERR       12010    // Two compared templates keep information about different fingers, 
//  so nothing was matched   
#define SE_PARSE_TEMPL     12012       // error of parse template

/////////////////////////////////////////////////////////////////////////////////////////
// readBmp, save2Bmp return values
#define SE_OPEN_FILE          22000		// cannot open or create the specified file
#define SE_WRITE_FILE         22001		// error occurs while writing to the specified file
#define SE_READ_FILE          22002		// error occurs while reading from the specified file


/////////////////////////////////////////////////////////////////////////////////////////
//		STRUCTURES
/////////////////////////////////////////////////////////////////////////////////////////
#if defined (WIN32) || defined(_WIN32_WCE)
#pragma pack(push,1)
#endif

// search parameters
typedef struct SDK_SE_PACKED_1 __SEARCHPARAMS
{
	unsigned short maxAngle;			// maximum of the finger turn angle (0...180 degree)
	unsigned short maxDisp;				// maximum of the finger displacement from the center 
					      					// of sensor surface, mm
	MATCH_SPEED  searchSpeed;			// one of the MATCH_SPEED constants
							      			// searchSpeed works only with match_Templates_Tech5 and
									      	// match_Templates_Tech5Ex functions.
   __SEARCHPARAMS()
   {
      maxAngle    = 180;
      maxDisp     = 20;
      searchSpeed = LOW_MATCH_SPEED;
   }
} SearchParams, *LPSearchParams;

#if defined (WIN32) || defined(_WIN32_WCE)
#pragma pack(pop)
#endif



#endif // TECH5_SE_H_
