#pragma		once
#ifndef		JULWIN_H
#define		JULWIN_H

//library dependence
#include   "Unwrap.h"

//export-import control
#if defined  (linux)
   #define    GVJ_EI
#elif defined(LIBLDS)
   #define    GVJ_EI
#elif defined(JULWIN)
   #define    GVJ_EI	__declspec( dllexport )
#else
   #define    GVJ_EI	__declspec( dllimport )
#endif

#pragma pack(push,_ESK_PACKING)
#pragma pack(push,_ESK_TIGHTEN)
_ESK_BEGIN
//-------------------------------------
//    List of enumerators
//-------------------------------------
enum STATUS_QUO
   {
	//factor: skeleton packing
   SKEL_O = 1 << 0,							          //old packing method
   SKEL_N = 1 << 1,                              //new packing method

	//show: viewer or latent processing
   V_LACK = 0,    							          //show nothing
	V_AREA = 1 << 0,							          //show area or region from DB
	V_FLOW = 1 << 1,							          //show flow
	V_NUDE = 1 << 2,							          //show skeleton
	V_MINT = 1 << 3,							          //show minutiae
	V_SING = 1 << 4,                              //show singularity
   //simple viewer
   V_MISC = 1 << 7,                              //show minutiae from DB
   V_CANV = 1 << 8,                              //show skeleton from DB

	//status: latent processing
   S_LACK = 0,                                   //nothing ready
   S_SING = 1 << 0,							          //singularity ready
   S_FLOW = 1 << 1,							          //flow ready
	S_NUDE = 1 << 2,							          //skeleton, area and minutiae ready
   S_SAVE = 1 << 3,                              //template ready

	//goal: processing
	M_GOAL = 1 << 0,							          //list of minutiae
	S_GOAL = 1 << 1,							          //list of singularities
	A_GOAL = 1 << 2,							          //list of area
	L_GOAL = 1 << 3,							          //list of linkage
	T_GOAL = 1 << 4,							          //list of ridge count between singularities
   P_GOAL = 1 << 6,                              //list of pores
   };

enum PATTERN_TYPE
   {
	//basic
	ARCH_P =	1 << 0,							          //plain arch
	TENTED =	1 << 1,							          //tented arch
	LOOP_R =	1 << 2,							          //plain right loop
	CURV_R =	1 << 3,							          //curved right loop
	LOOP_L =	1 << 4,							          //plain left loop
	CURV_L =	1 << 5,							          //curved left loop
	WHORLP =	1 << 6,							          //plain whorl

   //extended
	POCK_R =	1 << 8,							          //right central pocket loop
	POCK_L =	1 << 9,							          //left central pocket loop
	LOOP_T =	1 << 10,	                            //twin loop
	LOOPLP =	1 << 11,                             //lateral pocket loop
	ACCIDL =	1 << 12,                             //accidental

	//their collection
   ARCHES =	ARCH_P | TENTED,                     //arches
	LOOP_D =	LOOP_T | LOOPLP,                     //double loop
	POCKET =	POCK_R | POCK_L,                     //central pocket loop
	ARMADA = LOOP_R | CURV_R |                    //loops
				LOOP_L | CURV_L,
	WHORLS = WHORLP | POCK_R |                    //whorls
				POCK_L | LOOP_T |
				LOOPLP | ACCIDL
   };

/**************************************
  Declaration of loader interfaces
**************************************/
template<class _Ty>
class   Row;
typedef Row<byte_t>   Rowb;
typedef Row<uint_t>   Rowu;
typedef Row<atom_t>   Rowa;

template<class _Ty>
class _LNX_TIGHTEN Row
	{//tiny header to load image
public:
   typedef _Ty  simg_t;
   typedef _Ty* simg_p;

	Row( iint_t _Size_X = 0,
           iint_t _Size_Y = 0,
              simg_p _ImgRef = 0 )
		{//constructor
      Size_X = _Size_X;
         Size_Y = _Size_Y;
            ImgRef = _ImgRef;
		}
	
	iint_t //sizes of image
		Size_X,
		Size_Y;
	_Ty* //pointer to image
		ImgRef;									
	};

template<class _Ty,class _Tp>
class   Load;
typedef Load<atom_t,atom_t>   Loaa;
typedef Load<byte_t,atom_t>   Loba;
typedef Load<atom_t,byte_t>   Loab;
typedef Load<byte_t,byte_t>   Lobb;
typedef Load<atom_t,uint_t>   Loau;

template<class _Ty,class _Tp>
class _LNX_TIGHTEN Load
	{//header to load image
public:
   typedef _Ty  simg_t;
   typedef _Ty* simg_p;
   typedef _Tp  dimg_t;
   typedef _Tp* dimg_p;

	Load( 
      shrt_t _DesDir = 0,
         byte_t _ImType = 0,
            byte_t _Number = 0,
               iint_t _Size_X = 0,
                  iint_t _Size_Y = 0,
                     twin_t _ImgPPI = 0,
                        twin_t _DesPPI = 0,
                           simg_p _ImgRef = 0,
                              dimg_p _DesRef = 0,
                                 byte_t _Bright = 0,
                                    byte_t _Hierar = 0,
                                       byte_t _TipNet = 0 ) : Priory(),Img_OX(),Img_OY(),Des_OX(),Des_OY(),Dest_X(),Dest_Y()
      {//constructor
		DesDir = _DesDir; 
			ImType = _ImType; 
				Number = _Number;
					Size_X = _Size_X; 
						Size_Y = _Size_Y; 
							ImgPPI = _ImgPPI;
								DesPPI = _DesPPI;
									ImgRef = _ImgRef; 
                              DesRef = _DesRef;
                                 Bright = _Bright;
                                    Hierar = _Hierar; TipNet = _TipNet ? _TipNet : MAXR;
		}

	shrt_t //priority. orientation
      Priory,
		DesDir;

	byte_t //(L)atenprint, (F)ingerprint, (P)almprint, (T)enprint, (V)isualization & number
		ImType,
		Number;

	iint_t //source dimension
		Size_X,
		Size_Y;

   twin_t //pattern PPI and desired PPI
		ImgPPI,
		DesPPI;

   _Ty //pointer to source pattern and reception
     *ImgRef;
   _Tp
     *DesRef;

	byte_t //bright, hierarchy, topology depth
      Bright,
		Hierar,
		TipNet;

	iint_t //pattern axes, desired axes
		Img_OX,
		Img_OY,
		Des_OX,
		Des_OY;

	iint_t //destination dimension
		Dest_X,
		Dest_Y;

   };//Load

/**************************************
      Latenprint visual interface
**************************************/
struct _LNX_TIGHTEN Artist
   {//latentprint portrayal
   Artist() : Show(),Spot(),Stud(),Flow()
      {//construct default
      }
   Artist( uint_t _V,byte_t _P,byte_t _S,byte_t _F ) : Show(_V),Spot(_P),Stud(_S),Flow(_F)
      {//other constructor
      }

	uint_t  //what to show
      Show;
	byte_t  //size of minutiae, singularity, length of flow
      Spot,
	   Stud,
      Flow;
   };

struct _LNX_TIGHTEN Notion
   {//filter notion
   Notion() : Type(),Hard(),Beta(),Infi(),Ashl()
      {//construct default
      }

   Notion( iint_t _T,iint_t _H,iint_t _B,iint_t _I,bool_t _A ) : Type(_T),Hard(_H),Beta(_B),Infi(_I),Ashl(_A)
      {//other constructor
      }

   iint_t  //sunlit direction 0..255, filter type 0..4, contrast 0..127, aperture size 1..30
      Beta,
      Type,
      Hard,
	   Infi;
   bool_t  //ashler
      Ashl;
   };
#pragma pack(pop)

/**************************************
			Generalized entity
**************************************/
class GVJ_EI Entity
	{
	//have forbiden
	void_t operator&() const;
	void_t operator*() const;

public:
	//----------------------------------
	// Control functions
	//----------------------------------
	virtual
		bool_t   test	() = 0;							 //test if version correct and machine exist
	virtual
		void_t   killer() = 0;							 //deallocate inner engine
	virtual
		void_t   unload() = 0;                     //clear engine
	virtual
		void_t   versor( /* */ uint_t	 _Ver ) = 0; //set active version of library
	virtual
		void_t   openmp( /* */ byte_t	 _Nmp ) = 0; //set number of parallel threads
	virtual
		bool_t   loader( const Rowb   &_Dat ) = 0; //load raw image in engine
	virtual
		bool_t   loader( const Loba   &_Dat ) = 0; //load image type LFPT

	//----------------------------------
	// Image conversion after loading
	//----------------------------------
	virtual 
		bool_t   invert() = 0;							 //negative image
	virtual 
		bool_t   mirror() = 0;							 //mirror image
	virtual 
		bool_t   upside() = 0;							 //upside image

	//----------------------------------
	//	Image representation
	//----------------------------------
	virtual 
      void_t   gospel( /* */ byte_t *_Dib,
                             atom_t  _Mul,
                             atom_t  _Key,
                             byte_t  _Ech ) = 0; //image portrayal 32 bits RGB
	virtual 
      void_t   jasper( /* */ atom_t  _Key,
                             byte_t  _Dsh,
                             byte_t  _Srh ) = 0; //growth lay down

	//----------------------------------
	// Miscellanea for developer
	//----------------------------------
	virtual 
		uint_t   size_x() = 0;                     //main echelon width
	virtual 
		uint_t   size_y() = 0;                     //main echelon height
	virtual 
		uint_t   size_x( /* */ byte_t  _Ech ) = 0; //echelon width
	virtual 
		uint_t   size_y( /* */ byte_t  _Ech ) = 0; //echelon height
	virtual 
		atom_p	getlay( /* */ atom_t  _Key,
									  byte_t  _Ech ) = 0; //get pointer to lay of echelon
	virtual 
		bool_t   getkey( /* */ atom_t  _Key,
									  byte_t  _Ech ) = 0; //get key of lay of echelon
	virtual 
		iint_p	histog( /* */ uint_t &_Len,
                             uint_t  _Num ) = 0; //select histogram
   virtual
		shrt_p	wizdom( /* */ uint_t  _Itm ) = 0; //pointer to tuning date
	static const 
      char*    report();							    //get last error message

	};//Entity

/**************************************
	Template processing department
**************************************/
class GVJ_EI Nugget : public Entity
	{
	//have forbiden
	void_t operator&() const;
	void_t operator*() const;

public:
	//----------------------------------
	// Block and deblock template
	//----------------------------------
	virtual
		void_t   factor( const uint_t  _Key ) = 0; //processing factor, see constant
	virtual
		uint_t   nugget( /* */ byte_t *_Dst ) = 0; //export template
	virtual 
		uint_t   demain( const byte_t *_Src ) = 0; //deblocking from template model singularities
	virtual 
		uint_t   denova( const byte_t *_Src ) = 0; //deblocking from template model minutiae
	virtual 
		bool_t   dearea( const byte_t *_Src ) = 0; //deblocking from template informative areas

	//----------------------------------
	// Set extern null pointer to:
	//----------------------------------
	virtual 
		uint_t   resing( const Sign*  &_Dst ) = 0; //singularities into kernal!
	virtual 
		uint_t   reindi( const Sign*  &_Dst ) = 0; //indignations into kernal!
	virtual 
		uint_t   remint( const Sign*  &_Dst ) = 0; //minutiae into kernal!
	virtual 
		uint_t   remisc( const Sign*  &_Dst ) = 0; //miscalanious into kernal!

	//----------------------------------
	// Block and deblock sceleton
	//----------------------------------
	virtual 
		uint_t   encode( /* */ byte_t *_Ske,
									  uint_t  _Key	) = 0; //encode and export skeleton: old or new packing
	virtual 
		bool_t   decode( /* */ Rowa   &_Dst,
                       const byte_t *_Ske ) = 0; //import and decode skeleton	

   };//Nugget

/**************************************
	    Fingerprint processing
**************************************/
class GVJ_EI System : public Nugget
	{typedef  System Self;

	//have forbiden
	void_t operator&() const;
	void_t operator*() const;

public:
	//----------------------------------
	// Constructor and destructor: image type <LFP>
	//----------------------------------
	static                                                
		Self*		create();                         //create object using secret key
	static
		void_t   cancel(       Self*  &_Obj );		 //delete object

	//----------------------------------
	// Control functions
	//----------------------------------
	virtual
		bool_t   reload(		  Loba   &_Dat,
							  const byte_t	*_Raw ) = 0; //test roi mask and reload pyramid
	virtual
		bool_t   clipon( const Point  *_Pnt,
							        uint_t  _Num ) = 0; //load a fragment of image

	//----------------------------------
	// Import and export data
	//----------------------------------
	virtual
		twin_t   exmask() = 0;							 //export image type
	virtual
		bool_t   immask( const twin_t &_Msk ) = 0; //import image type
	virtual
		uint_t   exsing(       Sign   *_Dst ) = 0; //export automatic singularities as is
	virtual
		uint_t   exindi(       Sign   *_Dst ) = 0; //export model singularities if we have
	virtual
		uint_t   exmint(       Sign   *_Dst ) = 0; //export automatic minutiae as is
	virtual
		uint_t   exmisc(       Sign   *_Dst ) = 0; //export model minutiae if we have
	virtual
		uint_t   expore(       Pore   *_Dst ) = 0; //export automatic pores as is
	virtual
		uint_t   imsing( const Sign   *_Src,
							        uint_t  _Num,
                             bool_t  _Flg ) = 0; //import model singularities as sample, false - 360 degree
	virtual
		uint_t   immisc( const Sign   *_Src,
							        uint_t  _Num,
                             bool_t  _Flg ) = 0; //import model minutiae as sample, false - 360 degree

	//----------------------------------
	// Call chain for the first processing
	//----------------------------------
	virtual 
		bool_t   lights() = 0;							 //measure lights and shades
	virtual 
		bool_t   tensor() = 0;							 //build tensor
	virtual 
		bool_t   gralet() = 0;							 //build gralet
	virtual 
		bool_t   detail() = 0;							 //poroscopy
	virtual 
		bool_t   stream() = 0;							 //measure stream
	virtual 
		bool_t   pickup() = 0;							 //analize flow
	virtual
		bool_t   mapper()	= 0;							 //first processing
                                                                                                                       
   //----------------------------------
	// Call chain for the second processing
	//----------------------------------
	virtual 
		bool_t   depict()	= 0;							 //depict new flows
	virtual 
		bool_t   swells() = 0;							 //swell pattern flow
	virtual 
		bool_t   flowin() = 0;							 //to flow in pyramid
	virtual 
		bool_t   curves() = 0;							 //build curvature
	virtual 
		bool_t   furiew() = 0;							 //measure spectrum
	virtual 
		bool_t   schist() = 0;							 //retrieve spectrum
	virtual 
		bool_t   harmon() = 0;							 //spectrum analisys
	virtual 
		bool_t   laying() = 0;							 //classify areas
	virtual 
		bool_t   filter() = 0;							 //build filtered image
	virtual 
		bool_t   skelet() = 0;							 //refine ridges and extract minutiae
	virtual 
		bool_t   linker() = 0;							 //extract linkage
	virtual
		bool_t   epilog() = 0;							 //fulfill processing

   //----------------------------------
	// Some image estimations
	//----------------------------------
	virtual
		byte_t   qualit() = 0;							 //on-line quality
	virtual
		byte_t   densit() = 0;							 //on-line density
	virtual
		byte_t   square() = 0;							 //on-line square

	//----------------------------------
	// Convert skeleton if image is loaded
	//----------------------------------
	virtual 
		bool_t   revise( const byte_p  &_Ske ) = 0; //convert skeleton to template

	//----------------------------------
	// Tenprint formula
	//----------------------------------
	virtual 
		byte_t*	rumain( /* */ bool_t  _Ini ) = 0; //the Russian primary
   virtual 
      byte_t*	runext( /* */ bool_t  _Ini ) = 0; //the Russian secondary

	//----------------------------------
	// Accuracy rating
	//----------------------------------
	virtual 
		iint_t   ratify() = 0;							 //rating of singularity
	virtual 
		iint_t   rating() = 0;							 //rating of minutiae
	virtual 
		iint_t   region() = 0;							 //rating of region map
	virtual 
		iint_t   ration() = 0;							 //rating of image quality

	//----------------------------------
	// Miscellanea for developer
	//----------------------------------
	virtual 
		uint_t   tissue( /* */ void_p &_Set,
                             iint_t  _Thx,
									  iint_t  _Thy ) = 0; //show topology
	virtual 
		iint_p	harmon( /* */ uint_t  _Thx,
                             uint_t  _Thy,
                             byte_t  _Ech ) = 0; //show density
	};//System

/**************************************
 Semi-automatic latentprint processing
**************************************/
class GVJ_EI Latent : public Nugget
	{typedef  Latent Self;

	//have forbiden
	void_t operator&() const;
	void_t operator*() const;

public:
   enum
		{//coloured filters
      SAMPLE,
      SHADOW,
      SKETCH,
      STYLUS,
      RELIEF,
      __XX__,
      //houskeeping parameters
      REGION,
      FLOWER,
      SKELET,
      MINUTI,
      INDIGO,
      MAXPAL
		};

	//----------------------------------
	// Constructor and destructor: image type <LFPT>
	//----------------------------------
	static
		Self*		create();                         //create object using secret key
	static
		void_t   cancel(		  Self*	&_Obj );	    //delete object

	//----------------------------------
	// Clipon image fragment
	//----------------------------------
	virtual
		bool_t   clipon( const Point  *_Pnt,
									  uint_t  _Num ) = 0; //cutout image fragment

	//----------------------------------
	// Rotate image
	//----------------------------------
	virtual
		bool_t   rotate( /* */ twin_t  _Ang,
									  byte_t  _Lum ) = 0; //reload rotated image
	virtual
		bool_t   rotate( const Rowu   &_Row,
									  twin_t  _Ang,
                             uint_t  _Col ) = 0; //rotate image in front-end colour interface
	virtual
		uint_t   diamet( /* */ byte_t  _Ech ) = 0; //diameter of image

	//----------------------------------
	// Zoom image
	//----------------------------------
   virtual
      bool_t   zoomin( /* */ uint_t  _Pyr ) = 0; //set scale as pyramid number 0..16
   virtual
      twin_t   getppi( /* */ uint_t  _Pyr ) = 0; //get point per inch for pyramid
   virtual
      twin_t   getppi() = 0;                     //get active point per inch
   virtual
      bool_t   maxppi() = 0;                     //test if maximum point per inch
   virtual
      bool_t   minppi() = 0;                     //test if minimum point per inch
	virtual 
		iint_p*	huehue() = 0;                     //current colour histogram

   //----------------------------------
	// Some image estimations
	//----------------------------------
	virtual
		byte_t   densit() = 0;							 //on-line density
	virtual
		byte_t   qualit() = 0;							 //on-line quality
	virtual
		byte_t   square() = 0;							 //on-line square

	//----------------------------------
	// Import and export state
	//----------------------------------
	virtual
		twin_t   exmask() = 0;							 //export image type
	virtual
		uint_t   nunova() = 0;                     //number of minutiae
	virtual
		uint_t   numain( /* */ byte_t  _Typ ) = 0; //number of assigned type of singularities
	virtual
		bool_t   immask( /* */ twin_t  _Msk ) = 0; //import image type
	virtual
		uint_t   exmint(       Sign   *_Dst ) = 0; //export minutiae
	virtual
		uint_t   exsing(       Sign   *_Dst ) = 0; //export singularities
	virtual
		bool_t   insert( const Sign   &_Val ) = 0; //insert one singularity
	virtual
		bool_t   remove( const Sign   &_Val ) = 0; //remove one singularity
	virtual
		bool_t   moving( const Sign   &_Val, 
                             uint_t  _Ind ) = 0; //move one singularity
	virtual
		iint_t   active( const Sign   &_Val ) = 0; //index of nearest singularity
	virtual
		uint_t   summit( const Point  &_Val,
                             twin_t  _Tol ) = 0; //detect summit of singularity

	//----------------------------------
	// Latentprint processing
	//----------------------------------
	virtual 
		bool_t   knight( const uint_t &_Sts ) = 0; //filfil instriction
	virtual
		uint_t   status() = 0;							 //get condition of process
	virtual 
		bool_t   launch()	= 0;							 //clear result

	//----------------------------------
	// Subsystem for image representation
	//----------------------------------
	virtual
		bool_t   visual( /* */ Rowu   &_Dst,       //view portrayal 24 bits
                       const Artist &_Art,       //graphic artist
                       const Notion &_Not,       //filter notion
                       const Point  &_Lpt,       //left position
                       const Point  &_Med,       //center position
                       const Point  &_Rpt ) = 0; //right position
   virtual
      bool_t   sketch( /* */ Rowu   &_Row,
                       const Sign   &_Lpt,
                       const Sign   &_Mpt,
                       const Sign   &_Rpt,
                       const Sign   &_Dpt ) = 0; //view sketch box portrayal 24 bits
   virtual
      bool_t   viewer( /* */ Rowu   &_Row,
                       const Sign   &_Wht,
                       const Sign   &_Ink ) = 0; //view colour box portrayal 24 bits
	virtual
		bool_t   sethue( /* */ uint_t  _Ind,
									  uint_t  _Wht,
									  uint_t  _Ink ) = 0; //set RGB for index _Ind
	virtual
		bool_t   gethue( /* */ uint_t  _Ind,
									  uint_t &_Wht,
									  uint_t &_Ink ) = 0; //get RGB the index _Ind
	virtual
		uint_t   colour( const Point	&_Pos,
							  const Point	&_Max ) = 0; //get RGB of position into panel
	virtual
		bool_t   ground( /* */ Rowu   &_Dst ) = 0; //navigator portrayal 24 bits

	//----------------------------------
	// Operator communication
	//----------------------------------
	virtual 
		bool_t   riopen( Point *const  _Pnt,
									  iint_t  _Num ) = 0; //open region of interest
	virtual 
		bool_t   rilock( Point *const  _Pnt,
									  iint_t  _Num ) = 0; //close region of interest
	virtual 
		bool_t   reveal( Point *const  _Pnt,
									  iint_t  _Num ) = 0; //open informative area
	virtual 
		bool_t   lockup( Point *const  _Pnt,
									  iint_t  _Num ) = 0; //close informative area
	virtual 
		bool_t   direct( Point *const  _Pnt,
									  iint_t  _Num ) = 0; //draw the model flow
	virtual 
		bool_t   freely( Point *const  _Pnt,
									  iint_t  _Num ) = 0; //release flow
	virtual 
		bool_t   rubout( Point *const  _Pnt,
									  iint_t  _Num ) = 0; //rubout skeleton
	virtual 
		bool_t   drawer( Point *const  _Pnt,
									  iint_t  _Num ) = 0; //draw skeleton

	//----------------------------------
	// Miscellanea for developer
	//----------------------------------
	virtual 
		uint_t   tissue( /* */ void_p &_Set,
                             iint_t  _Thx,
									  iint_t  _Thy ) = 0; //show topology

	};//Latent

/**************************************
       View data after processing
**************************************/
class GVJ_EI Viewer : public Nugget
	{typedef  Viewer Self;

	//have forbiden
	void_t operator&() const;
	void_t operator*() const;

public:
	//----------------------------------
	// Constructor and destructor: image type <V>
	//----------------------------------
	static
		Self*		create();                         //create object using secret key
	static
		void_t   cancel(		  Self*	&_Obj );	    //delete object

	//----------------------------------
	// Zoom image
	//----------------------------------
   virtual
      bool_t   zoomin( /* */ twin_t  _Ppi ) = 0; //set viewer scale 300..1000
   virtual
      twin_t   getppi() = 0;                     //get active point per inch

	//----------------------------------
	// Subsystem for image representation
	//----------------------------------
	virtual
		bool_t   visual( /* */ Rowu   &_Dst,       //view portrayal 24 bits
                       const Artist &_Art,       //graphic artist
                       const Notion &_Not,       //filter notion
                       const Point  &_Lpt,       //left position
                       const Point  &_Med,       //center position
                       const Point  &_Rpt ) = 0; //right position

	virtual
		bool_t   sethue( /* */ uint_t  _Ind,
									  uint_t  _Wht,
									  uint_t  _Ink ) = 0; //set RGB for index _Ind
	virtual
		bool_t   gethue( /* */ uint_t  _Ind,
									  uint_t &_Wht,
									  uint_t &_Ink ) = 0; //get RGB the index _Ind
   };//Viewer

_ESK_END
#pragma pack(pop)
#endif//JULWIN_H
