#ifndef CIPHER_H
#define CIPHER_H

#include "data_types.h"

#ifdef _WINDOWS
#define modificator __cdecl
#else
#define modificator 
#endif // _WINDOWS

#ifdef __cplusplus
extern "C" { 
#endif  // __cplusplus

////////////////////////////////////// string functions /////////////////////////////////


// these two functions used the GOST 28147-89 (Russian) ( ���� 28147-89 )
// with hash algorithm GOST R34.11-94 ( ���� �34.11-94 )
//			

//	IN	pbSource	- plain text
//	IN	lenSource	- length of plain text in bytes
//	IN	szPassword	- set of key symbols
//	IN	passwordLength - length of szPassword in bytes
//	OUT	pbDestination		- cipher text
//	IN/OUT lenDest		- length of cipher text in bytes
//	if set lenDest = -1 at first call the function return in lenDest needed length of pbDestination buffer.
//	any another value of lenDest will be ignored.

snd_bool modificator CAPIEncryptGostString(snd_char* pbSource, snd_ulong lenSource, const snd_char* szPassword, snd_ulong passwordLength, snd_char* pbDestination, snd_ulong* lenDest);

snd_bool modificator CAPIDecryptGostString(snd_char* pbSource, snd_ulong lenSource, const snd_char* szPassword, snd_ulong passwordLength, snd_char* pbDestination, snd_ulong* lenDest);


// these two functions used the BLOWFISH algorithm
//			

//	IN	pbSource	- plain text
//	IN	lenSource	- length of plain text in bytes
//	IN	szPassword	- set of key symbols
//	IN	passwordLength - length of szPassword in bytes
//	OUT	pbDestination		- cipher text
//	IN/OUT lenDest		- length of cipher text in bytes
//	if set lenDest = -1 at first call the function return in lenDest needed length of pbDestination buffer.
//	any another value of lenDest will be ignored.

snd_bool modificator CAPIEncryptString(snd_char* pbSource, snd_ulong lenSource, const snd_char* szPassword, snd_ulong passwordLength, snd_char* pbDestination, snd_ulong *lenDest);

snd_bool modificator CAPIDecryptString(snd_char* pbSource, snd_ulong lenSource, const snd_char* szPassword, snd_ulong passwordLength, snd_char* pbDestination, snd_ulong *lenDest);

// these two functions used the RC5 - compatible algorithm
//			

//	IN	pbSource	- plain text
//	IN	lenSource	- length of plain text in bytes
//	IN	szPassword	- set of key symbols
//	IN	passwordLength - length of szPassword in bytes
//	OUT	pbDestination		- cipher text
//	IN/OUT lenDest		- length of cipher text in bytes
//	if set lenDest = -1 at first call the function return in lenDest needed length of pbDestination buffer.
//	any another value of lenDest will be ignored.

snd_bool modificator CAPIEncrypt(snd_char* pbSource, snd_ulong lenSource, const snd_char* szPassword, snd_ulong passwordLength, snd_char* pbDestination, snd_ulong *lenDest);

snd_bool modificator CAPIDecrypt(snd_char* pbSource, snd_ulong lenSource, const snd_char* szPassword, snd_ulong passwordLength, snd_char* pbDestination, snd_ulong *lenDest);

////////////////////////////////////// end of string functions ///////////////////////////

////////////////////////////////////// raw data functions /////////////////////////////
// these two functions used the rc4 - compatible algorithm
//			
snd_bool modificator CAPIEncryptData(snd_uchar* pbSource, snd_ulong lenSource, const snd_char* szPassword, snd_ulong passwordLength);

snd_bool modificator CAPIDecryptData(snd_uchar* pbSource, snd_ulong lenSource, const snd_char* szPassword, snd_ulong passwordLength);
////////////////////////////////////// ens raw data functions /////////////////////////

////////////////////////////////////// file functions /////////////////////////////////

// these functions used the RC4 - compatible algorithm
//			

//	IN	hSource  - handle of plaintext file opened with fopen
//	IN	hDestination - handle of ciphertext file opened with fopen
//	IN	SourceFileName  - filename of plaintext file
//	IN	DestinationFileName - filenames of ciphertext file
//	IN	szPassword - a set of key symbols
//	IN	passwordLength - a count of szPassord in bytes
//	IN	dwSize - a count of bytes to read and encrypt ( or decrypt) from source file.

// For	SEncryptFile dwSize=0 mean read and encrypt from current position of filepointer to end of file. 
// For	SDecryptfile dwSize=0 mean do nothing.

// The filename version functions read and encrypt/decrypt completely source file.
// If source and destination filename is identical, then plain text will be overwrited
snd_bool modificator SDecryptFile( FILE* hSource, FILE* hDestination, const snd_char* szPassword, snd_ulong passwordLength, snd_ulong dwSize);
snd_bool modificator SEncryptFile( FILE* hSource, FILE* hDestination, const snd_char* szPassword, snd_ulong passwordLength, snd_ulong dwSize);

//	IN	SourceFileName  - filename of plaintext files
//	IN	DestinationFileName - filename of ciphertext files
//	IN	szPassword - a set of key symbols
//	IN	passwordLength - a count of szPassord in bytes

snd_bool modificator SDecryptFileByFilename( const snd_char* SourceFileName, const snd_char* DestinationFileName, const snd_char* szPassword, snd_ulong passwordLength);
snd_bool modificator SEncryptFileByFilename( const snd_char* SourceFileName, const snd_char* DestinationFileName, const snd_char* szPassword, snd_ulong passwordLength);

////////////////////////////////////// end of file functions /////////////////////////////////

#ifdef __cplusplus
};	//extern "C"
#endif  // __cplusplus

#endif //CIPHER_H
