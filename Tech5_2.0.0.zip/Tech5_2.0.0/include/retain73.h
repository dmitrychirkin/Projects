/**************************************
				Retain.h
		 Class to create copy.

		   Author Gudkov V.U.
***************************************/

//	Header project file
#include		"typdef73.h"

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

// Sentry
#if !defined (__RETAIN_73_H)
	#define __RETAIN_73_H

	//-------------------------------------
	//	Class to save and restore position
	//-------------------------------------
	class CCopy
	{
	public://access for anybody

		//retain positions
		template <class T> 
		inline void	Retain( T *obj )
		{
			Movx = obj->Movx;
			Movy = obj->Movy;
			Movo = obj->Movo;
			Joff = obj->Joff;
			Hoff = obj->Hoff;
			Noff = obj->Noff;
			Eoff = obj->Eoff;
		};

		//repair positions
		template <class T> 
		inline void	Repair( T *obj )
		{
			obj->Movx = Movx;
			obj->Movy = Movy;
			obj->Movo = Movo;
			obj->Joff = Joff;
			obj->Hoff = Hoff;
			obj->Noff = Noff;
			obj->Eoff = Eoff;
		};

		//retain positions
		template <class T,class A> 
		inline void	Retain( T *obj,A &src )
		{
			src.Movx = obj->Movx;
			src.Movy = obj->Movy;
			src.Movo = obj->Movo;
		};

		//repair positions
		template <class T,class A> 
		inline void	Repair( T *obj,A &src )
		{
			obj->Movx = src.Movx;
			obj->Movy = src.Movy;
			obj->Movo = src.Movo;
		};

		//encode position
		template <class T>
		inline void	EnMask( T *obj,int mask )
		{
			Cval = *obj->Movo;
			*obj->Movo = mask;
		}

		//decode position
		template <class T> 
		inline void	DeMask( T *obj,int mask )
		{
			*obj->Movo = Cval;
		}

	private://inner parameters
		int		Movx,								//Movx
					Movy,								//Movy
					Cval;								//value

		byte	  *Movo,								//Movo
				  *Joff,								//J-off
				  *Hoff,								//H-off
				  *Noff,								//N-off
				  *Eoff;								//E-off
	};

#ifdef __cplusplus
} // namespace wizard73{
#endif  /* __cplusplus */

#endif//Retain.h
