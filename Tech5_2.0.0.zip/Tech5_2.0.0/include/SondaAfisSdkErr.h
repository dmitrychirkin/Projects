/*****************************************************************************
	SondaAfisSdkErr.h - define the error numbers for Sonda AFIS SDK

******************************************************************************
	
	Copyright (C) 2005 Sonda Ltd.
	
	Version 1.0.0 of 25.08.2005
	    
*******************************************************************************/
 
#ifndef SONDA_AFIS_SDK_DEF_H__
#define SONDA_AFIS_SDK_DEF_H__


#define SASDK_OK		            0  // success
#define SASDK_WRONG_POINTER      -1 // one of the pointers passed to the function is NULL
#define SASDK_WRONG_TYPE         -2 // this object type is not applied to this function
#define SASDK_ZERO_IMAGE         -3 // the image size is zero
#define SASDK_WRONG_IMAGE_TYPE   -4 // not supported image type
#define SASDK_WRONG_WSQ          -5 // error of decompressing WSQ image
#define SASDK_LOW_MEMORY         -6 // not enough memory
#define SASDK_BIG_IMAGE          -7 // the image size is too big
#define SASDK_SMALL_IMAGE        -8 // the image is too small
#define SASDK_NO_IMAGE           -9 // no fingerprint(palmprint, latentprint) image
                                    // found in source image
#define SASDK_SASDK_SEGMENTATION -10 // slap segmentation error
#define SASDK_UNKNOWN_EXCEPTION  -11 // unknown exception rised
#define SASDK_WRONG_TEMPLATE     -12 // the template is corrupted
#define SASDK_MATCH              -13 // core matching algorithm error
#define SASDK_NO_FINGERS         -14 // two sets of templates have no fingers with the same number
#define SASDK_PROCESSING         -15 // core image processing algorithm error
#define SASDK_WRONG_PARAMETRS    -16 // At least one of the function parameters is out of range
#define SASDK_BADCHECKSUM        -17 // The incorrect check sum

#define SASDK_NOT_INIT           -30 // The module is not initialized
#define SASDK_LOADDLL            -31 // Error of loading DLL
#define SASDK_OBJ_ARG            -32 // Error of argument AfisObj of function
#define SASDK_SKELETON           -33 // The compressed skeleton is corrupted
#define SASDK_BUFER              -34 // There is no size of the buffer
#define SASDK_CORRUPTTEMPLN      -35 // Corrupt fpTemplate[%d]
#define SASDK_NQUERYMAX          -36 // nQuery (%d) >= MAX
#define SASDK_TEMPLATENULL       -37 // the template is corrupted, lTemplate == NULL
#define SASDK_NUMOBJECT          -38 // NumObject=%d
#define SASDK_FUNC_LOWMEMORY     -39 // Error in function %s, not enough memory.
#define SASDK_FUNC_CHECKSUMM     -40 // Error in function %s, check sum arg
#define SASDK_FUNC_COORUPTIMAGE  -41 // Error in function %s, corrupt wsq image
#define SASDK_FUNC_WSQWIDTH      -42 // Error in function %s, width obj %d != width Wsq %d
#define SASDK_FUNC_ERROR         -43 // Error in function %s, error code %d
#define SASDK_FUNC_SMALLIMAGE    -44 // Error %s, tine image < 128, width=%d, height=%d
#define SASDK_PROCESSINGN        -45 // Error processing image %d, numObject=%d.
#define SASDK_ARG                -46 // Wrong function argument
#define SASDK_ERR                -47 // Error
#define SASDK_WSQ_IMAGE          -48 // Error WSQ encoding

#define SASDK_SYSTEMERR          -50 // System Error


// ���� ������ ������
#define KEY_BASE                    -15200
#define KEY_READLICENSE             KEY_BASE       // -15200	licence file reading error
#define KEY_LOADLIBRARY             KEY_BASE - 1   // -15201	Error during the dongle library loading 
#define KEY_NOMODULE                KEY_BASE - 2   // -15202	There is not licence for the module in this dongle
#define KEY_BADKEY                  KEY_BASE - 3   // -15203	Incorrect dongle


// Error Code of Rockey dongle
// KEY_ROCKEY_BASE will be returned - <error code of Rockey dongle driver>
#define	 KEY_ROCKEY_BASE						-16000
#define  ERR_KEY_ROCKEY_NO_PARALLEL_PORT		KEY_ROCKEY_BASE - 1		// No parallel port on the computer
#define  ERR_KEY_ROCKEY_NO_DRIVER				KEY_ROCKEY_BASE - 2		// No install drivers
#define  ERR_KEY_ROCKEY_NO_ROCKEY				KEY_ROCKEY_BASE - 3		// No rockey dongle
#define  ERR_KEY_ROCKEY_INVALID_PASSWORD		KEY_ROCKEY_BASE - 4		// Found rockey dongle, but base password is wrong
#define  ERR_KEY_ROCKEY_INVALID_PASSWORD_OR_ID 	KEY_ROCKEY_BASE - 5		// Wrong password or rockey HID
#define  ERR_KEY_ROCKEY_SETID					KEY_ROCKEY_BASE - 6     // Set rockey HID wrong
#define  ERR_KEY_ROCKEY_INVALID_ADDR_OR_SIZE	KEY_ROCKEY_BASE - 7		// Read/Write address is wrong
#define  ERR_KEY_ROCKEY_UNKNOWN_COMMAND        	KEY_ROCKEY_BASE - 8		// No such command
#define  ERR_KEY_ROCKEY_NOTBELEVEL3				KEY_ROCKEY_BASE - 9		// Inside error
#define  ERR_KEY_ROCKEY_READ					KEY_ROCKEY_BASE - 10	// Read error
#define  ERR_KEY_ROCKEY_WRITE                  	KEY_ROCKEY_BASE - 11	// Write error
#define  ERR_KEY_ROCKEY_RANDOM                 	KEY_ROCKEY_BASE - 12	// Random error
#define  ERR_KEY_ROCKEY_SEED                   	KEY_ROCKEY_BASE - 13	// Seed Code error
#define  ERR_KEY_ROCKEY_CALCULATE              	KEY_ROCKEY_BASE - 14	// Calculate error
#define  ERR_KEY_ROCKEY_NO_OPEN					KEY_ROCKEY_BASE - 15	// No open dongle before operate dongle
#define  ERR_KEY_ROCKEY_OPEN_OVERFLOW          	KEY_ROCKEY_BASE - 16	// Too more open dongle(>16)
#define  ERR_KEY_ROCKEY_NOMORE					KEY_ROCKEY_BASE - 17	// No more dongle
#define  ERR_KEY_ROCKEY_NEED_FIND				KEY_ROCKEY_BASE - 18	// No Find before FindNext
#define  ERR_KEY_ROCKEY_DECREASE				KEY_ROCKEY_BASE - 19	// Decrease error

#define  ERR_KEY_ROCKEY_AR_BADCOMMAND			KEY_ROCKEY_BASE - 20	// Arithmetic instruction error
#define  ERR_KEY_ROCKEY_AR_UNKNOWN_OPCODE		KEY_ROCKEY_BASE - 21	// Arithmetic operator error
#define  ERR_KEY_ROCKEY_AR_WRONGBEGIN			KEY_ROCKEY_BASE - 22	// Const number can't use on first arithmetic instruction
#define  ERR_KEY_ROCKEY_AR_WRONG_END			KEY_ROCKEY_BASE - 23	// Const number can't use on last arithmetic instruction
#define  ERR_KEY_ROCKEY_AR_VALUEOVERFLOW		KEY_ROCKEY_BASE - 24	// Const number > 63

#define  ERR_KEY_ROCKEY_RECEIVE_NULL			KEY_ROCKEY_BASE - 0x100	// Receive null
#define  ERR_KEY_ROCKEY_PRNPORT_BUSY			KEY_ROCKEY_BASE - 0x101	// Parallel busy
#define  ERR_KEY_ROCKEY_UNKNOWN_SYSTEM			KEY_ROCKEY_BASE - 0x102	// Unknown operate system


#define  ERR_KEY_ROCKEY_NET_LOGINAGAIN			KEY_ROCKEY_BASE - 1001	//A module can only be opened once by the same process.  
#define  ERR_KEY_ROCKEY_NET_NETERROR			KEY_ROCKEY_BASE - 1002	//Network error.
#define	 ERR_KEY_ROCKEY_NET_LOGIN				KEY_ROCKEY_BASE - 1003	//Too many users are logged on.
#define	 ERR_KEY_ROCKEY_NET_INVALIDHANDLE		KEY_ROCKEY_BASE - 1004	//Invalid handle, this handle might have been closed.
#define	 ERR_KEY_ROCKEY_NET_BADHARDWARE			KEY_ROCKEY_BASE - 1005	//Defective hardware 
#define	 ERR_KEY_ROCKEY_NET_REFUSE				KEY_ROCKEY_BASE - 1006	//Client dll modified, service refused request.
#define	 ERR_KEY_ROCKEY_NET_BADSERVER			KEY_ROCKEY_BASE - 1007	//Nrsvr.exe modified, service is invalid.





//Error code for network

#define ERR_KEY_ROCKEY_INIT_SOCK				KEY_ROCKEY_BASE - 2001	//Error when initializing.
#define ERR_KEY_ROCKEY_NOSUCHPROTO				KEY_ROCKEY_BASE - 2002	//No such protocol.
#define ERR_KEY_ROCKEY_UDPSOCKCREATE			KEY_ROCKEY_BASE - 2003	//UDP error when creating socket.
#define ERR_KEY_ROCKEY_UDPSETBROADCAST			KEY_ROCKEY_BASE - 2004	//UDP error when setting broadcast.
#define ERR_KEY_ROCKEY_UDPBINDFAILED			KEY_ROCKEY_BASE - 2005	//UDP error when binding.
#define ERR_KEY_ROCKEY_SVRCALLBACKNULL			KEY_ROCKEY_BASE - 2006	//Server call back null.
#define ERR_KEY_ROCKEY_TCPSOCKCREATE			KEY_ROCKEY_BASE - 2007	//TCP error when creating socket.
#define ERR_KEY_ROCKEY_TCPBINDFAILED			KEY_ROCKEY_BASE - 2008	//TCP error when binding.
#define ERR_KEY_ROCKEY_TCPLISTENFAILED			KEY_ROCKEY_BASE - 2009	//TCP error when listening.
#define ERR_KEY_ROCKEY_NOSUCHSEARCH				KEY_ROCKEY_BASE - 2010	//No such search mode.
#define ERR_KEY_ROCKEY_UDPSEND					KEY_ROCKEY_BASE - 2012	//UDP error when sending.
#define ERR_KEY_ROCKEY_UDPTIMEOUT				KEY_ROCKEY_BASE - 2013	//UDP timeout error when waiting.
#define ERR_KEY_ROCKEY_UDPRECV					KEY_ROCKEY_BASE - 2014	//UDP error when receiving.
#define	ERR_KEY_ROCKEY_TCPCONNECT				KEY_ROCKEY_BASE - 2015	//TCP error when connecting to server.
#define ERR_KEY_ROCKEY_TCPSENDTIMEOUT			KEY_ROCKEY_BASE - 2016	//TCP time out error when sending.
#define	ERR_KEY_ROCKEY_TCPSEND					KEY_ROCKEY_BASE - 2017	//TCP error when sending.
#define ERR_KEY_ROCKEY_TCPRECVTIMEOUT			KEY_ROCKEY_BASE - 2018	//TCP time out error when receiving.
#define	ERR_KEY_ROCKEY_TCPRECV					KEY_ROCKEY_BASE - 2019	//TCP error when receiving.
#define ERR_KEY_ROCKEY_IPXSOCKCREATE			KEY_ROCKEY_BASE - 2020	//IPX error when creating socket.
#define ERR_KEY_ROCKEY_IPXSETBROADCAST			KEY_ROCKEY_BASE - 2021	//IPX error when setting broadcast.
#define	ERR_KEY_ROCKEY_IPXSEND					KEY_ROCKEY_BASE - 2022	//IPX error when sending data. 
#define	ERR_KEY_ROCKEY_IPXRECV					KEY_ROCKEY_BASE - 2023	//IPX error when receiving data.
#define ERR_KEY_ROCKEY_IPXBIND					KEY_ROCKEY_BASE - 2024	//IPX error when binding.
#define ERR_KEY_ROCKEY_NBSRESET					KEY_ROCKEY_BASE - 2025	//NetBIOS error when initializing.
#define ERR_KEY_ROCKEY_NBSADDNAME				KEY_ROCKEY_BASE - 2026	//NetBIOS error when adding name.
#define ERR_KEY_ROCKEY_NBSSEND					KEY_ROCKEY_BASE - 2027	//NetBIOS error when sending data.
#define ERR_KEY_ROCKEY_NBSRECV					KEY_ROCKEY_BASE - 2028	//NetBIOS error when receiving data.



// Error Code of Guardant dongle
// KEY_GUARDANT_BASE will be returned - <error code of Guardant dongle driver>
#define KEY_GUARDANT_BASE           -16500
#define ERR_KEY_GUARDANT_KeyNotFound         KEY_GUARDANT_BASE	- 1 //	Dongle with specified search  conditions not found                
#define ERR_KEY_GUARDANT_AddressTooBig       KEY_GUARDANT_BASE	- 3 // The specified address is too big    
#define ERR_KEY_GUARDANT_GPis0               KEY_GUARDANT_BASE	- 5 // GP executions counter exhausted  (has 0 value)
#define ERR_KEY_GUARDANT_BadCommand          KEY_GUARDANT_BASE	- 6 // Bad key call command                
#define ERR_KEY_GUARDANT_VerifyError         KEY_GUARDANT_BASE	- 8 // Write verification error            
#define ERR_KEY_GUARDANT_LANProtNotFound     KEY_GUARDANT_BASE	- 9 // Network protocol not found          
#define ERR_KEY_GUARDANT_LANResourceExhaust  KEY_GUARDANT_BASE	- 10 // License counter of Guardant Net exhausted
#define ERR_KEY_GUARDANT_ConnectionLoosed    KEY_GUARDANT_BASE	- 11 // Connection with Guardant Net server  was lost
#define ERR_KEY_GUARDANT_ConnectionLost      KEY_GUARDANT_BASE	- 11 //Connection with Guardant Net server was lost
#define ERR_KEY_GUARDANT_LANplugsNotFound    KEY_GUARDANT_BASE	- 12 // Guardant Net server not found       
#define ERR_KEY_GUARDANT_LANserverMemory     KEY_GUARDANT_BASE	- 13 // Guardant Net server memory allocation error
#define ERR_KEY_GUARDANT_LANDPMIError        KEY_GUARDANT_BASE	- 14 // Guardant Net server found DPMI  error
#define ERR_KEY_GUARDANT_Internal            KEY_GUARDANT_BASE	- 15 // Guardant Net server internal error
#define ERR_KEY_GUARDANT_ServerReloaded      KEY_GUARDANT_BASE	- 16 // Guardant Net server has been  reloaded
#define ERR_KEY_GUARDANT_VersionTooOld       KEY_GUARDANT_BASE	- 17 // This command is not supported by this key version (the version is too old)
#define ERR_KEY_GUARDANT_BadDriver           KEY_GUARDANT_BASE	- 18 // Windows NT driver is required       
#define ERR_KEY_GUARDANT_LANNetBIOS          KEY_GUARDANT_BASE	- 19 // Network protocol error              
#define ERR_KEY_GUARDANT_LANpacket           KEY_GUARDANT_BASE	- 20 // Network packet format is not  supported
#define ERR_KEY_GUARDANT_LANneedLogin        KEY_GUARDANT_BASE	- 21 // Logging in Guardant Net server is   required
#define ERR_KEY_GUARDANT_LANneedLogout       KEY_GUARDANT_BASE	- 22 // Logging out from Guardant Net server is required  
#define ERR_KEY_GUARDANT_LANKeyBusy          KEY_GUARDANT_BASE	- 23 // Guardant Net is busy locked by  another copy of protected  application 
#define ERR_KEY_GUARDANT_DriverBusy          KEY_GUARDANT_BASE	- 24 // Guardant driver cannot capture the parallel port 
#define ERR_KEY_GUARDANT_CRCError            KEY_GUARDANT_BASE	- 30 // CRC error occurred while attempting  to call the key
#define ERR_KEY_GUARDANT_CRCErrorRead        KEY_GUARDANT_BASE	- 31 // CRC error occurred while attempting  to read data from the key
#define ERR_KEY_GUARDANT_CRCErrorWrite       KEY_GUARDANT_BASE	- 32 // CRC error occurred while attempting to write data to the key 
#define ERR_KEY_GUARDANT_Overbound           KEY_GUARDANT_BASE	- 33 // The boundary of the key's memory  has been override
#define ERR_KEY_GUARDANT_AlgoNotFound        KEY_GUARDANT_BASE	- 34 // The hardware algorithm with this number has not been found in the key
#define ERR_KEY_GUARDANT_CRCErrorFunc        KEY_GUARDANT_BASE	- 35 // CRC error of the hardware algorithm 
#define ERR_KEY_GUARDANT_CRCChkNSK           KEY_GUARDANT_BASE	- 36 // CRC error occurred while attempting  to execute
#define ERR_KEY_GUARDANT_ProtocolNotSup      KEY_GUARDANT_BASE	- 37 // ChkNSK operation, or all keys found  Guardant API release is too old
#define ERR_KEY_GUARDANT_CnvTypeError        KEY_GUARDANT_BASE	- 38 // Non-existent reversible conversion  method has been specified 
#define ERR_KEY_GUARDANT_InvalidArg	         KEY_GUARDANT_BASE	- 46 // One or more arguments are invalid   


#define SASDK_ERR_MAXLENMESSAGE     1024 // maximum length of error message in characters

#define SASDK_MESSAGEFILE        "sasdkMsg.txt"

#endif  // SONDA_AFIS_SDK_DEF_H__

 
