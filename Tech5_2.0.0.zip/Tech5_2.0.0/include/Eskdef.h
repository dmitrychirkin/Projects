#pragma		once
#ifndef		ESKDEF_H
#define		ESKDEF_H

//-------------------------------------
// Defence section
//-------------------------------------
#if   defined _CPUVID_MODE
   #pragma error  ERROR: Protected mode of chip redefined!
#endif
#if defined _TIMEID_MODE
   #pragma error  ERROR: Protected mode of time redefined!
#endif

//-------------------------------------
// Expert system kit section 
//-------------------------------------
#ifdef _CHAR_UNSIGNED   
   #pragma error  ERROR: Default char type must be signed!
#endif

#ifndef  __cplusplus
   #pragma error  ERROR: C++ programs only!
#else //definitions
   #define  _ESK_BEGIN     namespace ESK {
   #define  _ESK_END       }

   //state of protector
   #define  _ESK_GUARD     0

   //struct packing 
   #define  _ESK_TIGHTEN   1
   #define  _ESK_PACKTWO   2
   #define  _ESK_PACKING   8

   //my identificator <day month year>
   #define  _ESK_ID        0x7a8f1200

   //time in seconds since UTC 1/1/70
   #define  _ESK_TM        1525777033

#endif

#if defined (linux) || defined (ANDROID)

   #define  _LNX_TIGHTEN   __attribute((aligned(_ESK_TIGHTEN),packed))
   #define  _LNX_PACKTWO   __attribute((aligned(_ESK_PACKTWO),packed))
   #define  _LNX_PACKING   __attribute((aligned(_ESK_PACKING),packed))
#else //visual C++
   #define  _LNX_TIGHTEN
   #define  _LNX_PACKTWO
   #define  _LNX_PACKING
#endif

#ifndef _NO_THROW_DEFINED
   #define _NOTHROW        throw()
   #define _RAISE(X)       throw X
#else
   #define _NOTHROW
   #define _RAISE(X)
#endif


#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
//-------------------------------------
// The special constants
//-------------------------------------
struct _LNX_PACKING Fictitious 
	{//fictitious position
	enum
		{
		_ = 0
		};
   };

enum SOCKET
	{//linkage factors: max size, max links, max ridges, min ridges, topology accelerators
   SIMA = 512,
	MAXL =  35,
   MAXR =  17,
	MINR =   5,
   SISE =   3,
	};

//-------------------------------------
// Dependent types
//-------------------------------------
#if defined (X64)
   //run on a 64-bits operating system
   #if defined (linux)
      ///linux section
      #ifndef INTPTR_T_DEFINED
      typedef signed long int       Intptr_t;
      #define INTPTR_T_DEFINED
      #endif
      #ifndef UINTPTR_T_DEFINED
      typedef unsigned long int     Uintptr_t;
      #define UINTPTR_T_DEFINED
      #endif
      #ifndef PTRDIFF_T_DEFINED
      typedef signed long int       Ptrdiff_t;
      #define PTRDIFF_T_DEFINED
      #endif
      #ifndef QUAD_T_DEFINED
      typedef unsigned long int     quad_t, *quad_p;
      #define QUAD_T_DEFINED
      #endif
      #ifndef GUAR_T_DEFINED
      typedef signed long int       guar_t, *guar_p;
      #define GUAR_T_DEFINED
      #endif
      #ifndef SIZE_T_DEFINED
      typedef unsigned long int     size_t, *size_p;
      #define SIZE_T_DEFINED
      #endif
   #else
      //windows section
      #ifndef INTPTR_T_DEFINED
      typedef signed long long      Intptr_t;
      #define INTPTR_T_DEFINED
      #endif
      #ifndef UINTPTR_T_DEFINED
      typedef unsigned long long    Uintptr_t;
      #define UINTPTR_T_DEFINED
      #endif
      #ifndef PTRDIFF_T_DEFINED
      typedef signed long long      Ptrdiff_t;
      #define PTRDIFF_T_DEFINED
      #endif
      #ifndef QUAD_T_DEFINED
      typedef unsigned long long    quad_t, *quad_p;
      #define QUAD_T_DEFINED
      #endif
      #ifndef GUAR_T_DEFINED
      typedef signed long long      guar_t, *guar_p;
      #define GUAR_T_DEFINED
      #endif
      #ifndef SIZE_T_DEFINED
      typedef unsigned long long    size_t, *size_p;
      #define SIZE_T_DEFINED
      #endif
   #endif
#else
   //run on a 32-bits operating system
   #if defined(linux) || defined (ANDROID)
      //linux section
      #ifndef INTPTR_T_DEFINED
      typedef signed int            Intptr_t;
      #define INTPTR_T_DEFINED
      #endif
      #ifndef UINTPTR_T_DEFINED
      typedef unsigned int          Uintptr_t;
      #define UINTPTR_T_DEFINED
      #endif
      #ifndef PTRDIFF_T_DEFINED
      typedef signed int            Ptrdiff_t;
      #define PTRDIFF_T_DEFINED
      #endif
      #ifndef QUAD_T_DEFINED
      typedef unsigned long long    quad_t, *quad_p;
      #define QUAD_T_DEFINED
      #endif
      #ifndef GUAR_T_DEFINED
      typedef signed long long      guar_t, *guar_p;
      #define GUAR_T_DEFINED
      #endif
      #ifndef SIZE_T_DEFINED
      typedef unsigned int          size_t, *size_p;
      #define SIZE_T_DEFINED
      #endif
   #else
      //windows section
      #ifndef INTPTR_T_DEFINED
      typedef signed int            Intptr_t;
      #define INTPTR_T_DEFINED
      #endif
      #ifndef UINTPTR_T_DEFINED
      typedef unsigned int          Uintptr_t;
      #define UINTPTR_T_DEFINED
      #endif
      #ifndef PTRDIFF_T_DEFINED
      typedef signed int            Ptrdiff_t;
      #define PTRDIFF_T_DEFINED
      #endif
      #ifndef QUAD_T_DEFINED
      typedef unsigned long long    quad_t, *quad_p;
      #define QUAD_T_DEFINED
      #endif
      #ifndef GUAR_T_DEFINED
      typedef signed long long      guar_t, *guar_p;
      #define GUAR_T_DEFINED
      #endif
      #ifndef SIZE_T_DEFINED
      typedef unsigned int          size_t, *size_p;
      #define SIZE_T_DEFINED
      #endif
   #endif
#endif//end of operating system

//-------------------------------------
// Independent types
//-------------------------------------
#ifndef FDBL_T_DEFINED
typedef double             fdbl_t, *fdbl_p;
#define FDBL_T_DEFINED
#endif
#ifndef FLOT_T_DEFINED
typedef float              flot_t, *flot_p;
#define FLOT_T_DEFINED
#endif
#ifndef LONG_T_DEFINED
typedef long               long_t, *long_p;
#define LONG_T_DEFINED
#endif
#ifndef UINT_T_DEFINED
typedef unsigned int       uint_t, *uint_p;
#define UINT_T_DEFINED
#endif
#ifndef IINT_T_DEFINED
typedef signed int         iint_t, *iint_p;
#define IINT_T_DEFINED
#endif
#ifndef TWIN_T_DEFINED
typedef unsigned short     twin_t, *twin_p;
#define TWIN_T_DEFINED
#endif
#ifndef SHRT_T_DEFINED
typedef signed short       shrt_t, *shrt_p;
#define SHRT_T_DEFINED
#endif
#ifndef BYTE_T_DEFINED
typedef unsigned char      byte_t, *byte_p;
#define BYTE_T_DEFINED
#endif
#ifndef CHAR_T_DEFINED
typedef signed char        char_t, *char_p;
#define CHAR_T_DEFINED
#endif
#ifndef BOOL_T_DEFINED
typedef bool               bool_t, *bool_p;
#define BOOL_T_DEFINED
#endif
#ifndef VOID_T_DEFINED
typedef void               void_t, *void_p;
#define VOID_T_DEFINED
#endif
#ifndef ATOM_T_DEFINED
typedef signed int         atom_t, *atom_p;
#define ATOM_T_DEFINED
#endif

_ESK_END
#pragma pack(pop)
#endif//ESKDEF_H
