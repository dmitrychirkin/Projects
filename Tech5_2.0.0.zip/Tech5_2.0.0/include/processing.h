/*****************************************************************************
	process.h - header file for 'FpProcess' class

*******************************************************************************/
#ifndef PROCESS_H__
#define PROCESS_H__

#include "processBase.h"
#include "wizard73.h"

using namespace wizard73;

#pragma pack(push, _CORE_PACKING)

class FpProcess : public ProcessBase
{
	Codex              *m_codex;               

public:
	FpProcess();
	~FpProcess();

  	/* 
 	   Initialize work with FpProcess class
      Parameters:
      numThreads (input)  - number of threads, that will be used for parallel works. 
                            if numThread = 0 - then it will be set to the number of Core
                            in system.
      Return value: 
	   function returns IP_OK - if function succeeds, error code - otherwise
	*/
   //virtual int common_init(int numThreads);

protected:
   	/* 
		Processes one fingerprint image and build its template.
		Image sould be 500 DPI, uncompressed, 256 gray-level(8bpp)
		Size of imge should be not more than MAX_WIDTH * MAX_HEIGHT
		Parameters:
      pContext       (input)  - pointer to execution context, that will be passed as is to all callback functions 
		image          (input)  - source image 
		widht          (input)  - image width
		height         (input)  - image height
		templ          (output) - the buffer that receives the built template. 
		templSize      (output) - the buffer that will receives the size of built template 
		quality        (output) - the buffer that will receives the fingerprint image quality. 
                                 NOTE: If qualityOnly= true, then this value will contain the preliminary 
                                 estimation of fingerprint quality and function will complete after getting this value 
                                 (template will not be built).
                                 If qualityOnly = false, then template will be built and this value will contain 
                                 the final (more precise) quality of fingerprint image.
	   frame          (in-out) - the fingerprint image location with white space cut off).
                                 Before call it contains frame before image processing, that 
                                 can be change while image processing
      finger         (input)  - finger position
		skeleton       (output) - if this parameter is not NULL then fingerprint sceleton will be copy 
		                           to this buffer. Memory should be allocated in application. Size of buffer 
							            should be not less than width * height in bytes
      skeletonSize   (output) - size of skeleton
      ISO_compatible (input)  - create template, that can be conver to ISO/NIST format
      onPreprocess   (input)  - callback function that will be called when preprocessing stage
                                 (cut off the white space) is completed. 
                                 If this parameter is NULL, no callback function will be called  
      onGetQuality   (input) - callback function that will be called when preliminary 
                                estimation of fingerprint image quality will be calculated
                                If this parameter is NULL, no callback function will be called  
      onProcess1     (input) - callback function that will be called when the 1st processing stage
                                (define of core\delta location) is completed.  
                                If this parameter is NULL, no callback function will be called  
      onSkeleton     (input) - typedef for callback functions, those will be called when skeleton 
                                building will be completed.
                                If this parameter is NULL, no callback function will be called  
      qualityOnly    (input) - if its true, then function returns as soon as preliminary 
                                estimation of fingerprint image quality will be calculated
                                (template will not be built)
		Return value:
		The function returns IP_OK - if function succeeds, error code - otherwise
	*/	
	virtual int wizardWork (
                   const LPVOID     pContext,   
                   unsigned char   *image, 
                   unsigned int     width, 
                   unsigned int     height, 
                   unsigned char   *templ,  
                   unsigned int    *templSize, 
                   int             *quality,   
                   ::Frame         &frame,  
                   FINGERS          finger                  = FINGPOS_RT,
                   BYTE            *skeleton                = NULL, 
                   int             *skeletonSize            = NULL, 
                   bool             ISO_compatible          = false,
                   ON_PRE_PROCESS   onPreprocess            = NULL, 
                   ON_GET_QUALITY   onGetQuality            = NULL, 
                   ON_PROCESS_1     onProcess1              = NULL,
                   ON_SKELETON      onSkeleton              = NULL,
                   bool             qualityOnly             = false);

   // set protection code
   virtual void setProtect(BYTE protect[MAX_PROTECT_LEN]);
   // get protection code
   virtual void getProtect(BYTE protect[MAX_PROTECT_LEN]);
   // callback function (after preprocess1 complete)
   virtual bool onProcess1Complete(const LPVOID pContext, ON_PROCESS_1 onProcess1Complete, FINGERS finger);

   // alloc memory for call members
   virtual bool alloc(int num_threads);
   // release memory for class members
   virtual void release();
};


#pragma pack(pop)

#endif // PROCESS_H__
