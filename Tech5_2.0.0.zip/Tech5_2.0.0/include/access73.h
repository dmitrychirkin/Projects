/**************************************
					Access.h
		Quick access to the code.

			Author Gudkov V.U.
**************************************/

//	Header project file
#include		"search73.h"

// Sentry
#if !defined (__ACCESS_73_H)
	#define __ACCESS_73_H

#ifdef __cplusplus
namespace wizard73{
#endif  /* __cplusplus */

	/**************************************
			Get quick displacement
	**************************************/

	//	Get quantity of bytes in src
	template <class T>
	static inline	T	QPower( byte *src )
	{
		return (T)(((SItem*)src)->Length );
	}

	//	Get quantity of indignations in list
	template <class T>
	static inline	T	QFocus( byte *src )
	{
		return (T)(((SItem*)src)->PFocus );
	}

	//	Get quantity of minutiaes in list
	template <class T>
	static inline	T	QPoint( byte *src )
	{
		return (T)(((SItem*)src)->PPoint );
	}

	//	Get quantity of total count
	template <class T>
	static inline	T	QTotal( byte *src )
	{
		return (T)(((SItem*)src)->PTotal );
	}

	//	Get quantity of ridge count
	template <class T>
	static inline	T	QRidge( byte *src )
	{
		return (T)(((SItem*)src)->PRidge );
	}

	//	Get quantity of areas in list
	template <class T>
	static inline	T	QAreas( byte *src )
	{
		return (T)(((SItem*)src)->PAreas );
	}

	//	Get quantity of links in list
	template <class T>
	static inline	T	QLinks( byte *src )
	{
		return (T)(((SItem*)src)->PLinks );
	}

	//	Get mask of image
	template <class T>
	static inline	T	ImMask( byte *src )
	{
		return (T)(((SItem*)src)->ImMask );
	}

	//	Get type of image
	template <class T>
	static inline	T	ImType( byte *src )
	{
		return (T)(((SItem*)src)->ImType );
	}

	//	Get density of the image
	template <class T>
	static inline	T	Densit( byte *src )
	{
		return (T)(((SItem*)src)->Densit );
	}

	//	Get quality of the image
	template <class T>
	static inline	T	Qualit( byte *src )
	{
		return (T)(((SItem*)src)->Qualit );
	}

	//	Get net power of the image
	template <class T>
	static inline	T	TipNet( byte *src )
	{
		return (T)(((SItem*)src)->TipNet );
	}

	//	Displacement to list of indignations
	template <class T>
	static inline T	DFocus( byte *src,int step = 0 )
	{
		return (T)(src + ((SDisp*)(src + sizeof(SItem) - step))->DFocus);
	}

	//	Displacement to the total ridge count
	template <class T>
	static inline T	DTotal( byte *src,int step = 0 )
	{
		return (T)(src + ((SDisp*)(src + sizeof(SItem) - step))->DTotal);
	}

	//	Displacement to list of minutiaes
	template <class T>
	static inline T	DPoint( byte *src,int step = 0 )
	{
		return (T)(src + ((SDisp*)(src + sizeof(SItem) - step))->DPoint);
	}

	//	Displacement to ridge count
	template <class T>
	static inline T	DRidge( byte *src,int step = 0 )
	{
		return (T)(src + ((SDisp*)(src + sizeof(SItem) - step))->DRidge);
	}

	//	Displacement to list of links
	template <class T>
	static inline T	DAreas( byte *src,int step = 0 )
	{
		return (T)(src + ((SDisp*)(src + sizeof(SItem) - step))->DAreas);
	}

	//	Displacement to list of links
	template <class T>
	static inline T	DLinks( byte *src,int step = 0 )
	{
		return (T)(src + ((SDisp*)(src + sizeof(SItem) - step))->DLinks);
	}

	//	Displacement to list of owner
	template <class T>
	static inline T	DOwner( byte *src,int step = 0 )
	{
		return (T)(src + ((SDisp*)(src + sizeof(SItem) - step))->DOwner);
	}

	//	Displacement to unuse region
	template <class T>
	static inline T	DUnuse( byte *src,int step = 0 )
	{
		return (T)(src + ((SDisp*)(src + sizeof(SItem) - step))->DUnuse);
	}

#ifdef __cplusplus
} // namespace wizard73{
#endif

#endif
