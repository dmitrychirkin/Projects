#pragma		once
#ifndef		ESKUSE_H
#define		ESKUSE_H

//	Use project headers
#include		"Eskdef.h"

#pragma pack(push,_ESK_PACKING)
_ESK_BEGIN
//-------------------------------------
// Hash or mash of lays
//-------------------------------------
enum KEYNOTE_ENUM
	{
   /*
   Patterns
   */
	SAMPLE =	 00,
   DETAIL,
   GRALET,
	SOURCE,
	REFINE,
	SKELET,
   LOCKER,
	DIFFER,
	PROPHE,
   BINARY,
   THPATH,
   MODULE,
   ZIPPER,
	CANVAS,
	LIGHTS,
   /*
	Sunlight
   */
	LIGHTC = LIGHTS + 00,
   LIGHTD,
   LIGHTE,
   LIGHTF,
   /*
	Reconstruction
   */
	SHADED,
   SHADEV,
   SKETCH,
   MORPHU,
   MORPHD,
   STYLUS,
	STYLUD,
   STYLUV,
	RIVERS,
   RIVERU,
   RIVERD,
	/*
	Flow
   */
	FLOW_I,
	FLOW_W,
	FLOW_L,
	FLOW_A,
	FLOW_P,
	FLOWsI,
	FLOWsW = FLOWsI + 04,
   /*
	Probability
   */
	PROB_I =	FLOWsW + 04,
	PROB_W,
	PROB_L,
   PROB_A,
	PROB_P,
	PROBsI,
	PROBsW = PROBsI + 04,
   /*
	Coherence
   */
	COHE_I =	PROBsW + 04,
   COHE_W,
	/*
	Curvature
   */
	ARCH_D =	COHE_W + 04,
	ARCH_V,
	ARCH_T,
   /*
	Development
   */
   INFLOW,
   /*
	Concordance
   */
	CONC_F,
	CONC_H,
   INTR_H,
   /*
   Gradient
   */
   GRAD_A,
   GRAD_M,
   GRAD_E,
   /*
   Tensor
   */
   TENS_A,
   TENS_C,
   /*
	Density
   */
	DENSIT,
   ENERGY,
	INTRAR,
   /*
	Spectrum
   */
	SPEC_O,
	SPEC_C = SPEC_O + 20,
   /*
	Class field
   */
	CCLASS = SPEC_C + 20,
   BETA_F,
   REGION,
   TERRAS,
	TYPE_F,
   ZONULE,
   /*
	Operator's order
   */
	MORDER,
	DORDER,
   IMAREA,
   /*
	Quality
   */
	QUAL_E,
   QUAL_S,
   /*
	Goals
   */
	GOAL_F,
	GOAL_I,
	GOAL_M,
   /*
	Proximity
   */
	VORTEX,
   /*
	Type of processing
   */
	PROC_F,
   /*
	Lists of signs
   */
	LIST_M,
	LIST_S,
	LIST_A,
	LIST_L,
	LIST_T,
	LIST_R,
	/*
	Special show lay to debug
   */
   JUSPER,
	/*
	Temporary lay must be the highest and less then 160
   */
   _TEMP_
	};

//-------------------------------------
// State of processing - view table!
//-------------------------------------
enum QUEUE_ENUM
	{
   /*
   Preparations
   */
   ZIPper = 00,
	SAMple,
	RELoad,
   ORDers,
   SOUrce,
   /*
   First processing
   */
	LIGhts,
   TENsor,
   GRAlet,
   DETail,
	STReam,
	PICkup,
	MAPing,
   /*
   Second processing
   */
	DEPict,
	SWElls,
	FLOwin,
	CURves,
	FURiew,
	SCHist,
	HARmon,
	FIXing,
	LAYing,
	FILter,
	SKElet,
	LINker,
	EPIlog,
   /*
	Learning by instruction
   */
	RATing
	};

//-------------------------------------
// Constants of processing
//-------------------------------------
enum LOCUS_ENUM
   {
   /*
   Localization for 1000 PPI
   */
   MAXLEN =  16384,  //maximum image size
   MINLEN =    128,  //minimum image size
   SING_C =     90,  //singularity capacity
   MINT_C =    900,  //minutiae capacity
   PORE_C =   1000,  //pores capacity
   /*
   Resolution
   */
   MAXPPI =   2000,  //maximum resolution
   MINPPI =    300,  //minimum resolution
   DEFLUM =    255,  //default paper bright
   TPLPPI =    500,  //template PPI
   STDPPI =    500,  //standard PPI
   DEFPPI =   1000,  //default processing PPI
   /*
   Template versions
   */
   WIZARD =	    73,  //ancient
   VERWIZ =	   130,  //version threshold
   ISSUER =	   130,  //issure
   /*
   Feature
   */
   SING_F =    200,  //singularity limit
   MINT_F =  60000,  //minutiae limit
   AREA_F = 765625,  //area limit <MAXLEN>
   /*
   Template length
   */
   TPLLEN = 250000,  //max template length
   };

//-------------------------------------
// Supporting constants
//-------------------------------------
enum BYTE_ENUM
   {
   /*
   Hierarchy
   */
   H0 =	   0,		   // 1*1 1000 PPI
   H1 =	   1,       // 2*2  500 PPI
   H2 =	   2,       // 4*4
   H3 =	   3,       // 8*8
   H4 =	   4,       //16*16
   H5 =	   5,	      //32*32
   PY =	   6,       //height of pyramid
   HB =     1,       //base hierarchy
   /*
   Directions
   */
   MD =     8,		   //directions
   /*
   Byte constants
   */
   BA	=   127,       //byte median
   BM	=   255,       //byte maximum
   /*
   Quality
   */
   QC =    64,       //best coherence
   QH	=	  63,		   //maximum quality
   QM	=	  13,		   //minutiae quality multiplicator
   QS	=	 119,		   //singularity quality multiplicator
   QP	=	  20,		   //pattern quality multiplicator
   /*
   Curve
   */
   CH	=	  63,		   //curve value 0..63
   };

enum CHAR_ENUM
   {
   /*
   Char constants
   */
   SC =   127,       //supremum of char
   UC =   255,       //supremum of unsigned char
   };

enum SHORT_ENUM
   {
   /*
   Short constants
   */
   SS	= 32767,       //supremum of short
   US	= 65535,       //supremum of unsigned short
   };

enum ANGLE_ENUM
   {
   /*
   Angle constants
   */
   G0 =     0,       //zero
   G1 =    32,       //next
   G2 =    64,       //right angle
   G3 =    96,       //next
   G4 =   128,       //open angle
   G5 =   160,       //next
   G6 =   192,       //upright angle
   G7 =   224,       //next
   G8 =   256,       //full period
   GS =    86,       //triplet
   GM =   255,       //end angle
   };

enum OTHER_ENUM
   {
   /*
   Integrity limits
   */
   ST =    60,       //number of steps
   /*
   Class interpreter
   */
   C0 =     0,
   C1 =     1,	      //empty
   C2 =     2,	      //steady flow
   C3 =     4,	      //other steady flow
   C4 =     8,	      //model flow
   C5 =    16,	      //empty
   C6 =    32,	      //informative area
   C7 =    64,       //unreadable area
   C8 =   128,	      //variable
   C9 =   256,	      //no interested region
   CA =   512,	      //empty
   CB =  1024,	      //empty
   CC =  2048,	      //empty
   CD =  4096,	      //empty
   CE =  8192,	      //empty
   CF = 16384,	      //empty
   /*
   Class combinations
   */
   CG = C2 | C3,     //groop of steady flow
   CY = C6 | C7,	   //groop of areas
   CR = C7 | C9,	   //complex region out of interest
   /*
   Work interpreter
   */
   W0 =     0,
   W1 =     1,	      //empty
   W2 =     2,	      //active area
   W3 =     4,	      //empty
   W4 =     8,	      //empty
   W5 =    16,	      //empty
   W6 =    32,	      //informative active area
   W7 =    64,       //unreadable active area
   W8 =   128,	      //empty
   W9 =   256,	      //empty
   /*
   Mask minutiae interpreter
   */
   M0 =     0,
   M1 =     1,	      //empty
   M2 =     2,	      //minutae
   M3 =     4,	      //doubtfull
   M4 =     8,	      //rupture
   /*
   Poincare index
   */
   IW =   256,		   //whorl - switch off
   IL =    71,		   //loop
   ID =    76,       //delta
   /*
   Singularities
   */
   FN =     0,
   FW	=     1,	      //whorl
   FL	=     2,	      //loop
   FA	=     4,	      //arch
   FD	=     8,	      //delta
   FX	=    16,	      //axes
   FV	=   128,	      //veil
   /*
   Combination of singularities
   */
   FC	= FW | FL | FD | FA,
   /*
   Minutiae type
   */
   MB =     0,       //bifurcation
   ME =     1,       //ending
   MC =     2,       //cross
   MI =     4,       //rupture
   /*
   Skeleton
   */
   BE	=     1,		   //ending
   BI	=     2,		   //rupture
   BB =	   4,		   //bifurcation
   BC =	   8,		   //cross
   BU	=    16,		   //hidrance
   BP	=    32,		   //projection
   BL	=    64,		   //left bifurcation branch
   BR	=   128,		   //right bifurcation branch
   BS	=   256,		   //pure skeleton
   BX	=	 512,		   //mark
   BG	=	1024,		   //inner gap
   BO	=	2048,		   //outward gap
   BK	=	2559,		   //multi key (BO | BX-1)
   BY	=	  12,		   //multi key (BB | BC)
   /*
   Thresholds
   */
   TA =    48,       //threshold between C6,C7
   TS =   800,       //threshold between BG,BS
   /*
   Ridge count
   */
   RM =	  31,		   //maximum ridge count
   RT	=	   3,       //tolerance band
   /*
   Harmonics
   */
   HM =    12,		   //middle period
   HL	=	   1,		   //minimum period
   HH	=	  18,		   //maximum period
   HP	=	   8,		   //multiplier
   HD =    HH-HL+1,  //harmon dimension
   };

_ESK_END
#pragma pack(pop)
#endif//ESKUSE_H
