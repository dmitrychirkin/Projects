#ifndef ACCEL_MATCH_ADJUST_H
#define ACCEL_MATCH_ADJUST_H

#include <stdio.h>
#include <string.h>
#include "coreSdk.h"
#include "accelMatch.h"

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)

//extern int g_probeId, g_galleryId, g_numGroup, g_finger;
//extern FILE *g_adjustFile;
//
//int accelIdetifyTP_Adj (void *accelHandle, AccelSearchParam &param, TpTemplate &probe, BYTE **gallery, int sizeGallery, 
//                     RL *rl, int sizeRl, int numFingers, PersonalData *personalData, bool doSegErrCorrect, TpTemplate *galleryTemplate);



#pragma pack(push, 1)
struct P_PACKED_1 AccelScoreParam
{
   BYTE  numFound;
   BYTE  posDif;
   BYTE  minAngleDif;				// minutiae angle differences
   BYTE  numMinutiaeP;
   BYTE  numMinutiaeG;
   BYTE  numExcludeG;
   BYTE  numExcludeP;
   BYTE  mainGroupSize;
   short topologySim;
   BYTE  pairLenDif;
   BYTE  qualityP;
   BYTE  qualityG;
   BYTE  angleDif;		      // differences in angle  from centre of rotation to minutiae
   BYTE  maxProbeDist;

   AccelScoreParam()
   {
      memset(this, 0, sizeof(AccelScoreParam));
   }
};



#pragma pack(pop)

//bool openLog(const char *name, bool forRead);
//void closeLog();
//
//
//bool saveParameters(AccelScoreParam &param);
//bool readParameters(int &probeId, int &galleryId, int &finger, int &numGroup, AccelScoreParam &param);

#pragma pack(pop)
} // namespace accelMatch{

#endif // ACCEL_MATCH_ADJUST_H
