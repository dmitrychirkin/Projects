/*****************************************************************************
	coreSdk.h - the common header file for all components of Core Matching SDKs

	The Core Matching SDKs is the high-level tools, intended for easy creating
    of your own scalable biometric applications that use the person's fingerprint for 
    identification or verification purpose. 
	    
*******************************************************************************/
 
#ifndef CORE_SDK_H__
#define CORE_SDK_H__

#include <stdint.h>

#ifdef __cplusplus
   #include <set>
   #include <string.h>
   #include <functional>
   using namespace std;
#endif

#include "common.h"

#ifdef __cplusplus
   extern "C"{
#endif


/******************************************************************
          THE CONSTANRS
*****************************************************************/
#pragma pack(push, _CORE_PACKING)

enum MATCHING_MODE
{
   NORMAL_MATCHING_MODE             = 0,  // in this mode all probe finger positions will be matched only
                                          // with corresponded gallery finger positions
   CHECK_MIX_FINGER_MATCHING_MODE   = 1,  // check if some finger were mixed. In this mode
                                          //  matching process will check all possible 
                                          // combination of probe and gallery fingers and 
                                          // choose the combination of probe and gallery fingers 
                                          // that give the max fusion score
   CHECK_MIX_SLAP_MATCHING_MODE     = 2,  // check if slaps were mixed. 
   CHECK_MIX_HAND_MATCHING_MODE     = 3,  // check if hand (slaps and/or thumbs) were mixed. 
};

enum FUSION_MODE
{
	OPTIMAL_FUSION_MODE     = 0,	// Method, optimised for reach the best ROC and CMC 
	LOW_BINNING_FUSION_MODE = 1,	// Resulting scores from every finger are separated in 3 bins 
                                 // by low and high thresholds (from SearchParams)
	                              // scores are sorted by increase, and only scores from lowest bin 
                                 // are used in calculating cumulative score 
	                              // (s1*8+s2*4+s3*2+s4)/(8+4+2+1)
	HIGH_BINNING_FUSION_MODE = 2, // Same as LOW_BINNING, except that sorting is done by decrease, 
                                 // and scores from highest bin are used.
};


// singularity type
enum SINGULAR_TYPE
{
   WHORL = 1,  
   LOOP  = 2,
   DELTA = 8
};

// minutiae type
enum MINUTIAE_TYPE
{
   BIFURCATION = 0,
   ENDING      = 1
};

// pattern type
enum PATTERN_TYPE
{
   ARCHSC	=	0x01,					//classical arch
   ARCHSU	=	0x02,					//tented arch
   LOOPRC	=	0x04,					//classical right loop
   LOOPRU	=	0x08,					//another right loop
   LOOPLC	=	0x10,					//classical left loop
   LOOPLU	=	0x20,					//another left loop
   WHORLC	=	0x40,					//classical whorl
   WHORLU	=	0x80					//complicated
};

// search type
enum SEARCH_TYPE 
{
   FINGER_TO_FINGER     = 0,          // seach generally any finger with any finger - no specific information
   LATENT_TO_FINGER     = 1,          // seach automatically processed latent template among fingers
   LATENT_TO_LATENT     = 2,          // 
};

// fingerprint type
enum FP_TYPE 
{
   UNKNOWN    = 0,
   ROLLED     = 1,          
   FLAT       = 2,          
   LATENT     = 3,          
};


#define MAX_PROTECT_LEN       512     // maximum lenght of protect buffer

#define MAX_SINGULAR            16    // maximum number of singularity
#define MAX_MINUTIAE           255    // maximum number of minutiae in fingerprint
                                      // template

#define MIN_RESOLUTION         100    // minimum supported image resolution
#define MAX_RESOLUTION         1000   // maximum supported image resolution
// if source image dpi is different from 500 dpi more than DPI_TOL then image will be stretched 
// before image processing
#define DPI_TOL	   			   5


#define MAX_SENSOR_NAME        50     // maximum length of sensor name
#define MAX_SENSORS            50     // maximum number of supported sensors
#define ENDLESSLY              -1     // the special value for unlimited timeout

#define MIN_REL_POINTS         32     // minimum number of reliable points
#define MAX_SCORE              10000  // maximum value for score  

// default parameters
#define SEARCH_SPEED_DEF       LOW_MATCH_SPEED
#define MAX_ANGLE_DEF          180
#define MAX_DISP_DEF           400
#define LOW_THRESHOLD_DEF      0
#define HIGH_THRESHOLD_DEF     MAX_SCORE
#define MIN_MATCH_DEF          1
#define MAX_MATCH_DEF          10

#define DEF_MAX_FRAMES         8


// fingerprint template data
struct TemplateData
{
	enum FINGERS numFinger;     // number of finger	
	BYTE        *fpTemplate;    // pointer to the fingerprint template

#ifdef __cplusplus
   TemplateData()
   {
      numFinger  = FINGPOS_UK;
      fpTemplate = 0;
   }
#endif
};

struct CaptureData
{
	enum FINGERS  numFinger;   // number of the finger
	BYTE         *dib;         // pointer to the buffer that contains the device
                              // independent bitmap (DIB)     
};

#pragma pack (push, _CORE_TIGHT)
struct P_PACKED_1 TemplHeader
{
   uint32_t       size;              // size of template
   uint8_t        checkIntegral;     // flag for checked integral points 
                                     // by operator, 
                                     // 0 - checked, 1 - not ckecked.
   uint8_t        specialFields[6];   
   uint16_t       points;            // number of points in template
   uint8_t        relPoints;         // number of reliable points in template
   uint8_t        quality;           // quality of fingerprint image
   uint8_t        reserved[5];
   uint8_t        version;
   
#ifdef __cplusplus
   TemplHeader()
   {
      memset (this, 0, sizeof(TemplHeader));
   }
#endif
};

struct P_PACKED_1 ROI_Mask 
{
   BYTE         * data;
   WORD           width;
   WORD           height;
};

struct P_PACKED_1 Frame
{
	int left;
	int right;
	int top;
	int bottom;

#ifdef __cplusplus
   Frame()
   {
      left = right = top = bottom = 0;
   }
   Frame& operator= (Frame &frame)
   {
      left      = frame.left;
      right     = frame.right;
      top       = frame.top;
      bottom    = frame.bottom;
      return *this;
   }
#endif
};
#pragma pack (pop)

// minutiae and singularity data
// NOTE: all coordinates is applied to 500 DPI fingerprint image
struct  Feature
{
   int				x;				// x position from top-left corner, pixels
   int				y;				// y positionf rom top-left corner, pixels
   BYTE           prob;			// probability, %
   int            angle;      // direction (clockwise from OX axis), degree (-180...180)
   BYTE           density; 

#ifdef __cplusplus
   Feature()
   {
      x        = 0;
      y        = 0;
      prob     = 0;
      angle    = 0;
      density  = 0;
   }
#endif
};

// Minutiae data
#ifdef __cplusplus
struct Minutiae : public ::Feature
{
   MINUTIAE_TYPE  type;				// type
   Minutiae() : Feature()
   {
      type = BIFURCATION;
   }
};
#else
struct Minutiae 
{
   int				      x;				// x position from top-left corner, pixels
   int				      y;				// y positionf rom top-left corner, pixels
   BYTE                 prob;			// probability, %
   int                  angle;      // direction (clockwise from OX axis), degree (-180...180)
   BYTE                 density;  
   enum MINUTIAE_TYPE   type;			// type
};

#endif

// Singularity data
#ifdef __cplusplus
struct Singular : public ::Feature
{
   SINGULAR_TYPE  type;			// type
};
#else
struct Singular
{
   int				      x;				// x position from top-left corner, pixels
   int				      y;				// y positionf rom top-left corner, pixels
   BYTE                 prob;			// probability, %
   int                  angle;      // direction (clockwise from OX axis), degree (-180...180)
   BYTE                 density;  
   enum SINGULAR_TYPE   type;			// type
};
#endif

// search parameters
struct SearchParam
{
   // search speed 
   enum MATCH_SPEED  searchSpeed;  
   // the maximum of the finger turn angle for all fingers except thumbs, (0...180 degree)
   unsigned int      maxAngle;     
   // the maximum of the finger turn angle for thumbs, (0...180 degree)
   unsigned int      maxAngleThumbs;     
   // the maximum of the displacement between center of two fingerprint images, pixels 
   unsigned int      maxDisp;      
   /* 
     parameters for TP-TP matching:
   */
   // thresholds for fusionScore in a range 0...MAX_SCORE.
   // If after match the minMatch pairs of templates 
   // fusionScore >= highThreshold || fusionScore<= lowThreshold
   // then matching will be finished
   // In other case, another pair of templates will be matched until all pair 
   // will be used or maxMatch pairs of tempaltes will be matched
   // NOTE: this won't works if matchingMode == CHECK_MIX_FINGER_MATCHING_MODE 
   //       int this case all possible finger pairs will be matched
   int              lowThreshold;
   int              highThreshold;
   // minimum number of finger pairs that should be matched (see comments above)
   unsigned int      minMatch;
   // maximum number of finger pairs that can be matched (see comments above)
   unsigned int      maxMatch;
   MATCHING_MODE     matchingMode;  
   FUSION_MODE       fusionMode;  

#ifdef __cplusplus
   SearchParam()
   {
      searchSpeed    = SEARCH_SPEED_DEF;
      maxAngle       = MAX_ANGLE_DEF;
      maxAngleThumbs = MAX_ANGLE_DEF;
      maxDisp        = MAX_DISP_DEF;
      lowThreshold   = LOW_THRESHOLD_DEF;
      highThreshold  = HIGH_THRESHOLD_DEF;
      minMatch       = MIN_MATCH_DEF;
      maxMatch       = MAX_MATCH_DEF;
      matchingMode   = NORMAL_MATCHING_MODE;
      fusionMode     = OPTIMAL_FUSION_MODE;
   }
#endif
};

// process parameters
struct  ProcessParam
{
   // if this value is true, then algorithm:
   // - will try to separate and cut out the fingerprint image from the background  
   // if it's false, then cutting will be performed only if:  
   // 1) image width > maxWidth or image height > maxHeight 
   // 2) image size is not alignment as it required by certain image processing algorithm (usually by 4)
   // 3) image width < minWidth or image height < minHeight as it required by certain image processing algorithm 
   // This operations will be done before perform image processing itself
   bool doSegmentation;                
   // by default, segmentation (if doSegmentation = true) can add a white space around fingerprint image
   // before pass image to image processing itself
   // it can happened, if fingerprint image is close to source image border. In this case the source image 
   // size will be increased and additional space will be filled with white color RGB(255, 255, 255)
   // and 'frame' after return from 'process' or 'processRaw' functions can have:
   // frame.left < 0
   // frame.top  < 0
   // frame.right  >= imageWidth
   // frame.bottom >= imageHeight 
   // if allowsIncreaseFrame = false or isCut = false, this operation is not permitted
   bool allowsIncreaseFrame;
   // need generate template that can be converted to ISO/IEC 19794 or INCITS 378 template
   bool ISO_compatible;
   // the maximum image size (if isCut = true and the source image have 
   // size bigger than this value, then source image will cut to this size)
   unsigned int maxWidth;     
   unsigned int maxHeight;
   // if image is latent
   bool isLatent;

#ifdef __cplusplus
   ProcessParam()
   {
      doSegmentation          = true;
      allowsIncreaseFrame     = true;
      isLatent                = false;
      ISO_compatible          = false;
      maxWidth                = MAX_WIDTH;
      maxHeight               = MAX_HEIGHT;
   }
   ProcessParam& operator= (ProcessParam &param)
   {
      memcpy(this, &param, sizeof(ProcessParam));
      return *this;
   }
#endif
};

#pragma pack(push, _CORE_PACKING)
// matching result 
struct  P_PACKED_8 MatchResult 		
{  
   enum FINGERS   fingerP; 
   enum FINGERS   fingerG; 
   int            similarity;           // similarity score of compared fingerprints in a range 0...MAX_SCORE
   unsigned int   numPairs;             // number of found minutiae pairs
   // number of corresponded minutiae for probe and gallery template
   //those were found while matching
	short          minutiaeNum[MAX_MINUTIAE][2]; 
   // information for combine fingerprint images
   int            xcP, ycP;            // coordinates of found minutiae center on probe   fingerprint
   int            xcG, ycG;            // coordinates of found minutiae center on gallery fingerprint 
   int            angle;               // clockwise angle rotation of gallery fingerprint relatively 
                                       //             probe fingerprint around found minutiae center

#ifdef __cplusplus
   MatchResult()
   {
      clear();
   }
   void clear()
   {
      memset(this, 0, sizeof(MatchResult));
   }
#endif
};
#pragma pack (pop)

struct MatchResultTT
{
   int          fusionScore;     // TP-TP fusion score in a range 0...MAX_SCORE
   int          score[10];       // input-output: score for each probe finger in a range 0...MAX_SCORE
   char         galleryPair[10]; // input-output: keeps position of gallery finger, that was 
                                 // defined as best pair for corresponded probe finger 
                                 // (for matching mode, different from NORMAL_MATCHING_MODE )
                                 // if there is no pair, corresponded value will be set to -1           
   unsigned int numMatched;      // number of really matched finger pairs  

#ifdef __cplusplus   
   MatchResultTT()
   {
      clear();
   }
   void clear()
   {
      fusionScore = 0;
      numMatched  = 0;
      clearScore();
   }
   void clearScore()
   {
      for(int pos = 0; pos < 10; pos++)
      {
         score      [pos]  =  0;
         galleryPair[pos]  = -1;
      }
   }
#endif
};





struct TpTemplate                // Tenprint with TECH5 templates. NULL means finger is absent  
{
   BYTE *templ[10];              // TECH5 template each of 10 fingers

#ifdef __cplusplus
   TpTemplate()
   {
      clear();
   }
   TpTemplate& operator= (const TpTemplate& tp)
   {
      for(int finger = 0; finger < 10; finger++)
         this->templ[finger] = tp.templ[finger];
      return *this;
   }
   TpTemplate(const TpTemplate& tp)
   {
      *this = tp;
   }
   void clear()
   {
      for(int finger = 0; finger < 10; finger++)
         templ[finger] = NULL;
   }
#endif
};

// recommended list structure
struct RL                       
{
   uint64_t regNum;                  // TP number 
   int      finger;                  // finger number (not used for TP matching)
   int       score;                  // match similarity in a range 0...MAX_SCORE
};

#ifdef __cplusplus
struct RLex : public RL
{
   RLex(int regNum, int finger, int score)
   {
      this->regNum = regNum;
      this->finger = finger;
      this->score = score;
   }
   bool operator< (const RLex &rl) const
   {
      return this->score < rl.score;
   }
   operator int () const
   {
      return this->score;
   }
};
typedef std::multiset <RLex, std::greater<int> > RL_SET;
#endif

#ifdef __cplusplus
/******************************************************************
          FUNCTION TYPEDEF
******************************************************************/
/*
   typedef for callback functions, those will be called while image processing of IP (IP10, IP71, IP110)
   when preprocessing routine (image segmentation etc.) will be completed
   Parameters:
   pContext	- pointer to execution context
   finger   - number of finger
   frame    - contans the location of fingerprint image (with white space cut off)
   Return value:
   The processing continue if function returns true and stop otherwise
*/
typedef bool (*ON_PRE_PROCESS)(const LPVOID pContext, FINGERS  finger, ::Frame &frame);

/*
   typedef for callback functions, those will be called while image processing of IP (IP10, IP71, IP110)
   when preliminary estimation of fingrprint image qulity will be completed
   Parameters:
   pContext	- pointer to execution context
   finger   - number of finger
   quality  - image quality
   Return value:
   The processing continue if function returns true and stop otherwise
*/
typedef bool (*ON_GET_QUALITY)(const LPVOID pContext, FINGERS finger, int quality);

/*
   typedef for callback functions, those will be called while image processing of IP (IP10, IP71, IP110)
   wnen 1st image processing (define of core/delta location) will be completed 
   Parameters:
   pContext		    - pointer to execution context
   finger          - number of finger
   pattern         - defined pattern type, that can be combination of basic type,
                     enlisted in PATTERN_TYPE enumeration
   numSingularity  - number of found singularity
   singular        - array of singularity those where found in fingerprint image
   quality         - quality of fingerprint 
   Return value:
   The processing continue if function returns true and stop otherwise
*/
typedef bool (*ON_PROCESS_1)(
                       const LPVOID         pContext, 
                             FINGERS        finger, 
                             unsigned int   pattern, 
                             unsigned int   numSingularity,
                             const Singular singular[MAX_SINGULAR]);
/*
   typedef for callback functions, those will be called while image processing of IP (IP71, IP110)
   when skeleton building will be completed
   Parameters:
   pContext		- pointer to execution context
   finger       - number of finger
   skeleton     - pointer to the buffer with skeleton data
   skeletonSize - the size of skeleton data
   NOTE: if you need to save skeleton data you should copy it in your own buffer. 
   The maximum size of skeletonSize is not exceed the MAX_WIDTH * MAX_HEIGHT
   Return value:
   The processing continue if function returns true and stop otherwise
*/
typedef bool (*ON_SKELETON)(const LPVOID pContext, FINGERS finger, BYTE *skeleton, int skeletonSize);


#endif //#ifdef __cplusplus

#pragma pack(pop)
#ifdef __cplusplus
   } // extern "C"{
#endif

#endif // CORE_SDK_H__



