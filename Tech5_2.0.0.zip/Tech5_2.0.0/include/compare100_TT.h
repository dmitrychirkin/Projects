/*****************************************************************************
	compare100_TT.h - header file for TP-TP matching algorithm of Core Matching SDK
                     using ma100 algorithm
   
*******************************************************************************/
 
#ifndef COMPARE_100_H_TT_
#define COMPARE_100_H_TT_

#include "ma100.h"
#include "fingerSelector.h"

namespace accelMatch{
#pragma pack(push,_CORE_PACKING)


/******************************************************************
          Compare class
******************************************************************/
class Matcher100;

class Compare100_TT
{
   Matcher100      *m_matcher;        
	Fs              *m_fs;
   bool             m_init;
   bool             m_isProbeLoaded;

public:
	Compare100_TT();
	~Compare100_TT();

	/* 
	 Initialize work with Compare100_TT class functions
    This function (or 'initEx' function)should be called first before call 
    any other functions
    Function returns MA_OK - if function succeeds, error code - otherwise
    accelHandle - handle of accelerator library
	*/
	int init(void *accelHandle);
	/* 
   Initialize work with Compare100_TT class functions
   In differ from 'init' function it take the protection data
   This function (or 'init' function)should be called first before call 
   any other functions
   Parameters:
   accelHandle (input) - handle of accelMatch library. If it's NULL, library will create it itself
   protect     (input) - pointer to MAX_PROTECT_LEN byte buffer with protection data
   Return value:
   The function returns MA_OK - if function succeeds, error code - otherwise
	*/
	int initEx(void *accelHandle, int protect[MAX_PROTECT_LEN]);

   /*
	Load probe TP
	function returns MA_OK - if function succeeds, error code - otherwise
	probe       (input) -  probe TP
   typeP       (input) -  type of probe fingerprints
   areaP       (input)  - array of bad areas for each probe finger. It can be NULL 
                          (in this case it will be calculated in the function)
   areaWidth   (input)  - array of bad area with   for each probe finger. It can be NULL (in this case it will be calculated in the function)
   areaHeight  (input)  - array of bad area height for earh probe finger. It can be NULL (in this case it will be calculated in the function)
	*/
	int loadTT(TpTemplate &probe, FP_TYPE typeP, BYTE **areaP, int *areaWidth, int *areaHeight);

   /*
	Compare TP with TP, previously loaded by 'loadTT' function
	function returns MA_OK - if function succeeds, error code - otherwise
	param         (input)  - the search parameters
	gallery       (input)  - gallery TP
	matchResultTT (output) - the result of TP-TP matching
   typeG         (input) -  type of gallery fingerprints
	*/
	int	matchTTEx (SearchParam &param, TpTemplate &gallery, MatchResultTT &matchResultTT, FP_TYPE typeG);

   /*
	Compare fingerprint template with corresponded finger template
	that was earlier load by 'loadTT' function 
	function returns MA_OK - if function succeeds, error code - otherwise
	param          (input)  - the search parameters
	templG         (input)  - gallery fingerprint template for match  
	similarity     (output) - variable that receives the value that shows 
				                  how two fingerprints similarity one to another in a range 0...MAX_SCORE
   fingerP        (input)  - probe finger number
	matchResult    (output) - the structure with match result details. 
                              If is is NULL, it not used.
   typeG          (input) -  type of gallery fingerprints
   useCombineData (input)  - if true, information about pair of minutiae thouse was found on 
                             accelerator matching stage will be used in matching 
   np             (input) - array of probe   minutiae number that was found on accelerator matching stage
   ng             (input) - array of gallery minutiae number that was found on accelerator matching stage
   accelGroupSize (input) - size of np and ng arrays
	*/
	int	matchEx (SearchParam &param, BYTE *templG, int &similarity, FINGERS fingerP,
                  MatchResult *matchResult, FP_TYPE typeG,
                  bool useCombineData, BYTE *np, BYTE *ng, BYTE accelGroupSize, bool quickAccelMatch);

private:
   /*
    allocate memory necessary for work all functions
	 Function returns MA_OK - if function succeeds, error code - otherwise
   */
   int alloc ();
   /*
    free memory allocated in alloc function
	 Function returns MA_OK - if function succeeds, error code - otherwise
   */
   void free();
    // check value of SearchParam items for acceptable value
   bool checkSearchParam(SearchParam &param);
   /* 
   Return calculated fusion score
   Parameters:
   fusionMode    (input) - fusion mode
   int numItems  (input) - size of score array
   numRealScore  (input) - number of really filled items in score array
   */
   int calcFusionScore(SearchParam &searchParam, unsigned int numItems, unsigned int numRealScore, int *score);
 	/*
	Compare TP with earlier loaded by 'loadTT' probe TP 
   in    matchingMode = CHECK_MIX_FINGER_MATCHING_MODE
	function returns MA_OK - if function succeeds, error code - otherwise
	param         (input)  - search parameters
	templSet      (input)  - gallery TP
   typeG         (input)  - type of gallery fingerprints
   matchResultTT (output) - the result of TP-TP matching
	*/
   int fingerMixMatchTTex (SearchParam &param, TemplateData templSet[10], FP_TYPE typeG, MatchResultTT &matchResultTT);
 	/*
	Compare TP with earlier loaded by 'loadTT' probe TP 
   in matchingMode = CHECK_MIX_SLAP_MATCHING_MODE
	function returns MA_OK - if function succeeds, error code - otherwise
	param         (input)  - search parameters
	gallery       (input)  - gallery TP
   typeG         (input)  - type of gallery fingerprints
   matchResultTT (output) - the result of TP-TP matching
	*/
   int slapMixMatchTTex (SearchParam &param, TpTemplate &gallery, FP_TYPE typeG, MatchResultTT &matchResultTT);
 	/*
	Compare TP with earlier loaded by 'loadTT' probe TP 
   in matchingMode = CHECK_MIX_HAND_MATCHING_MODE
	function returns MA_OK - if function succeeds, error code - otherwise
	param         (input)  - search parameters
	gallery       (input)  - gallery TP
   typeG         (input)  - type of gallery fingerprints
   matchResultTT (output) - the result of TP-TP matching
	*/
   int handMixMatchTTex (SearchParam &param, TpTemplate &gallery, FP_TYPE typeG, MatchResultTT &matchResultTT);
 	/*
	match TP with probe TP earlier loaded by 'loadTT'
	function returns MA_OK - if function succeeds, error code - otherwise
	param         (input)  - search parameters
	templSet      (input)  - gallery TP
   matchResultTT (output) - the result of TP-TP matching
   typeG         (input)  - type of gallery fingerprints
	*/
   int compareTT (SearchParam &param, TemplateData templSet[10], MatchResultTT &matchResultTT, FP_TYPE typeG);

};

#pragma pack(pop)
} // namespace accelMatch{

#endif // COMPARE_100_H_TT_



