/**************************************
					LDSDEF.H
     Definitions and declarations.

        Copyright (c) 1994-2004.
        Copyright (c) 2005-2012.
**************************************/
#pragma		once
#ifndef		LDSDEF_H
#define		LDSDEF_H

#ifdef _CHAR_UNSIGNED
#pragma error ERROR: Default char type must be signed!
#endif

#ifndef  __cplusplus
#pragma error ERROR: C++ programs only.
#else //library of dactilogram system kit
#define _LDS_TIGHT      1
#define _LDS_PACKING    8
#define _LDS_BEGIN      namespace LDS {
#define _LDS_END        }
#define _LDS_USING      using namespace LDS;
#define _LDS_C_BEGIN    extern "C" {
#define _LDS_C_END      }
#endif

#if defined (linux)
#define _LNX_TIGHT   __attribute((aligned(_LDS_TIGHT),packed))
#else //visual C++
#define _LNX_TIGHT
#endif

#if defined (ANDROID)
#define TYPENAME
#else
#define TYPENAME typename
#endif

#ifndef ANDROID
#define RIGHTREFERENCE
#endif

#ifndef RIGHTREFERENCE
#define RREF const _Ty&
#else
#define RREF _Ty&&
#endif

#pragma pack(push,_LDS_PACKING)
_LDS_BEGIN
//-------------------------------------
// Dependent types
//-------------------------------------
#if defined (X64)
   ///run on a 64-bits operating system
   #if defined (linux)
      ///linux section
      #ifndef INTPTR_T_DEFINED
      typedef signed long int       Intptr_t;
      #define INTPTR_T_DEFINED
      #endif
      #ifndef UINTPTR_T_DEFINED
      typedef unsigned long int     Uintptr_t;
      #define UINTPTR_T_DEFINED
      #endif
      #ifndef PTRDIFF_T_DEFINED
      typedef signed long int       Ptrdiff_t;
      #define PTRDIFF_T_DEFINED
      #endif
      #ifndef QUAD_T_DEFINED
      typedef unsigned long int     quad_t;
      #define QUAD_T_DEFINED
      #endif
      #ifndef GUAR_T_DEFINED
      typedef signed long int       guar_t;
      #define GUAR_T_DEFINED
      #endif
      #ifndef SIZE_T_DEFINED
      typedef unsigned long int     size_t;
      #define SIZE_T_DEFINED
      #endif
      #ifndef FORM_T_DEFINED
      typedef signed long int       form_t;
      #define FORM_T_DEFINED
      #endif
   #else
      ///windows section
      #ifndef INTPTR_T_DEFINED
      typedef signed long long      Intptr_t;
      #define INTPTR_T_DEFINED
      #endif
      #ifndef UINTPTR_T_DEFINED
      typedef unsigned long long    Uintptr_t;
      #define UINTPTR_T_DEFINED
      #endif
      #ifndef PTRDIFF_T_DEFINED
      typedef signed long long      Ptrdiff_t;
      #define PTRDIFF_T_DEFINED
      #endif
      #ifndef QUAD_T_DEFINED
      typedef unsigned long long    quad_t;
      #define QUAD_T_DEFINED
      #endif
      #ifndef GUAR_T_DEFINED
      typedef signed long long      guar_t;
      #define GUAR_T_DEFINED
      #endif
      #ifndef SIZE_T_DEFINED
      typedef unsigned long long    size_t;
      #define SIZE_T_DEFINED
      #endif
      #ifndef FORM_T_DEFINED
      typedef signed long long      form_t;
      #define FORM_T_DEFINED
      #endif
   #endif
#else
   ///run on a 32-bits operating system
   #if defined(linux)
      //linux section
      #ifndef INTPTR_T_DEFINED
      typedef signed int            Intptr_t;
      #define INTPTR_T_DEFINED
      #endif
      #ifndef UINTPTR_T_DEFINED
      typedef unsigned int          Uintptr_t;
      #define UINTPTR_T_DEFINED
      #endif
      #ifndef PTRDIFF_T_DEFINED
      typedef signed int            Ptrdiff_t;
      #define PTRDIFF_T_DEFINED
      #endif
      #ifndef QUAD_T_DEFINED
      typedef unsigned long long    quad_t;
      #define QUAD_T_DEFINED
      #endif
      #ifndef GUAR_T_DEFINED
      typedef signed long long      guar_t;
      #define GUAR_T_DEFINED
      #endif
      #ifndef SIZE_T_DEFINED
      typedef unsigned int          size_t;
      #define SIZE_T_DEFINED
      #endif
      #ifndef FORM_T_DEFINED
      typedef signed int            form_t;
      #define FORM_T_DEFINED
      #endif
   #else
      ///windows section
      #ifndef INTPTR_T_DEFINED
      typedef signed int            Intptr_t;
      #define INTPTR_T_DEFINED
      #endif
      #ifndef UINTPTR_T_DEFINED
      typedef unsigned int          Uintptr_t;
      #define UINTPTR_T_DEFINED
      #endif
      #ifndef PTRDIFF_T_DEFINED
      typedef signed int            Ptrdiff_t;
      #define PTRDIFF_T_DEFINED
      #endif
      #ifndef QUAD_T_DEFINED
      typedef unsigned long long    quad_t;
      #define QUAD_T_DEFINED
      #endif
      #ifndef GUAR_T_DEFINED
      typedef signed long long      guar_t;
      #define GUAR_T_DEFINED
      #endif
      #ifndef SIZE_T_DEFINED
      typedef unsigned int          size_t;
      #define SIZE_T_DEFINED
      #endif
      #ifndef FORM_T_DEFINED
      typedef signed int            form_t;
      #define FORM_T_DEFINED
      #endif
   #endif
#endif///end of operating system

//-------------------------------------
// Independent types
//-------------------------------------
#ifndef LONG_T_DEFINED
typedef long               long_t;
#define LONG_T_DEFINED
#endif
#ifndef UINT_T_DEFINED
typedef unsigned int       uint_t;
#define UINT_T_DEFINED
#endif
#ifndef IINT_T_DEFINED
typedef signed int         iint_t;
#define IINT_T_DEFINED
#endif
#ifndef TWIN_T_DEFINED
typedef unsigned short     twin_t;
#define TWIN_T_DEFINED
#endif
#ifndef CUNE_T_DEFINED
typedef signed short       shrt_t;
#define CUNE_T_DEFINED
#endif
#ifndef BYTE_T_DEFINED
typedef unsigned char      byte_t;
#define BYTE_T_DEFINED
#endif
#ifndef CHAR_T_DEFINED
typedef signed char        char_t;
#define CHAR_T_DEFINED
#endif
#ifndef ATOM_T_DEFINED
typedef unsigned char      atom_t;
#define ATOM_T_DEFINED
#endif
#ifndef BOOL_T_DEFINED
typedef bool               bool_t;
#define BOOL_T_DEFINED
#endif
#ifndef VOID_T_DEFINED
typedef void               void_t;
#define VOID_T_DEFINED
#endif

_LDS_END
#pragma pack(pop)
#endif//LDSDEF_H
/*
All rights reserved. Consult your license regarding permissions and restrictions.
*/
