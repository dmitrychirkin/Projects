/*****************************************************************************
	ImageUtl.h - header file for some utilites for work with images

*******************************************************************************/
#ifndef IMAGE_UTL_H_
#define IMAGE_UTL_H_

#include "win2linGdi.h"


#ifdef __cplusplus
	extern "C" {
#else
	typedef int		bool;
	#define true	1
	#define false	0
#endif


/*
	flip image horizontally
*/
void flipH (const unsigned char* src, unsigned char* dst, unsigned int width, 
			unsigned int height);
/*
	 flip image vertically
*/	 
void flipV (const unsigned char* src, unsigned char* dst, unsigned int width, 
			unsigned int height);

/*
 invert the image
*/ 
void invert (unsigned char* image, unsigned int width, unsigned int height);

// rotate image on 90 degree clockwise or anticlockwise
// after conversion width and height have a new value
void rotate90(const unsigned char* src, unsigned char* dst, unsigned int *width,
			  unsigned int *height, bool clockwise);

/*
	transform image from 32 to 8 bpp
	Parameters:
	image    (input) - pointer to source image
	width    (input)  - source image width
	height   (input)  - source image height
*/
void trans32To8Bpp(BYTE *image, int width, int height);


/* 
	cut part of the source image  and put it to the destination image
	src - source image
	srcWidth, srcHeight - size of source image 
	dst - destination image that is part of the source image
	x0, y0 width, height - define size and location of the cutting area 
	NOTE: 
		all X dimensions (x0, width srcWidth) in bytes (not in pixels)
		all Y dimensions (y0, height srcHeight) in pixels 
		width should contain 4 (image rows should be arranged)
*/
bool cut (const unsigned char* src, unsigned int srcWidth, unsigned int srcHeight,
				unsigned int x0, unsigned int y0, unsigned int width, 
				unsigned int height,	unsigned char* dst);


/*******************************************************************************************
  find finger location
*******************************************************************************************/
/*
	Allocate memory for 'findFinger' function
	Parameters:
	width, heght - source image size (input)
	dif, top, bottom, left, right, excludeX, excludeY - pointers to temporary buffers 
														for 'findFinger' function (output)
*/
bool findFingerAlloc(int ***dif, int **top, int **bottom, int **left, int **right, 
					 int **excludeX, int **excludeY,  int width, int height);

/*
	Free memory, previously allocated by 'findFingerAlloc' function
	Parameters:
	width, heght - source image size (input)
	dif, top, bottom, left, right, excludeX, excludeY - pointers to temporary buffers 
														for 'findFinger' function (output)
*/
void findFingerFree(int ***dif, int **top, int **bottom, int **left, int **right, 
					 int **excludeX, int **excludeY, int width, int height);

/*
	The fucntion trying to find fingerprint image location
	image                        - point to source image bytes (input)
	                              It is supposed that image is get from BMP, so image rows is arranged on 4 bytes. 
	width, heght                  - source image size (input)
	Left, Right, Top, Bottom      - fingerprint image location (output)
	dif, top, bottom, left, right,
	excludeX, excludeY            - temporary buffers. These buffers should be allocate by 'findFingerAlloc' function
	                                before the first call of 'findFinger' and free by call of 'findFingerFree' 
*/
bool findFinger (const unsigned char *image, unsigned int width, 
				 unsigned int height, 
				 unsigned int *Left, unsigned int *Right, unsigned int *Top, 
				 unsigned int *Bottom, int *left, int *right, int *top, int *bottom, 
				 int **dif, int *excludeX, int *excludeY);
/*******************************************************************************************
*******************************************************************************************/

// cut 8 bpp image to be arranged on 4 bytes
// (newWidth = width / 4 * 4)
// memory for dstImage should be allocated by caller
// return the new width
int arrangeImageCut (int width, int height, const unsigned char *srcImage, 
				  const unsigned char *dstImage);

// aranged each row in image to be divided on 4 bytes
// (newWidth = (width + 3) / 4 * 4)
// memory for dstImage should be allocated by caller
// return the new width
int arrangeImage (int width, int height, const unsigned char *srcImage, 
				  const unsigned char *dstImage);

// change 8 bpp image to be arranged on 4 bytes
// (newWidth = (width + 3) / 4 * 4)
// and put it to the same buffer
// return the new width or 0 if an error happened 
// image buffer should be large enough for new image
int arrangeImage2 (int width, int height, unsigned char *image);


// calculate histogram
void calcHistog(const unsigned char *image, unsigned int width, 
					unsigned int height, RECT rect, int histogram[256]);

// normalize image
bool normalize (const unsigned char *image, unsigned int width, unsigned int height, 
                unsigned char *normImage);

/*
   return averange color of image bytes in given area
   parameters:
      image          - pointer to image bytes
      width, height  - image size
      x0, y0, w, h   - position of area
*/
unsigned char getAverangeColor(const unsigned char *image, int width, int height, int x0, int y0, int w, int h);


#ifdef __cplusplus
	}
#endif

#endif // IMAGE_UTL_H_
