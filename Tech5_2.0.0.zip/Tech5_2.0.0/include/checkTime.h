#ifndef CHECK_TIME_H_
#define CHECK_TIME_H_

#include <stdint.h>

#if defined _WINDOWS
#include <windows.h>
#else
#include <sys/time.h>
#endif

class Timer 
{ 
public: 
	Timer()
	{
#if defined _WINDOWS
		QueryPerformanceFrequency(&m_frequency);
#endif
	} 
	void start()
	{
#if defined _WINDOWS
		QueryPerformanceCounter(&m_start);
#else
		struct timeval t;
		gettimeofday( &t, NULL );
		m_start = (t.tv_sec * 1000) + (t.tv_usec / 1000);
#endif
	} 

   // return number of millisecond after start call
	int64_t elapsed_msec() const 
	{  
#if defined _WINDOWS
		LARGE_INTEGER current; 
		QueryPerformanceCounter(&current); 
		return (int64_t)(((current.QuadPart - m_start.QuadPart) * 1000) / m_frequency.QuadPart); 
#else
      struct timeval t;
		unsigned long current; 
		gettimeofday( &t, NULL );
		current = (t.tv_sec * 1000) + (t.tv_usec / 1000);
		return (int64_t)(current - m_start);
#endif
   } 
   // return number of seconds after start call
	float elapsed_sec() const 
	{  
      return (float)(elapsed_msec() / 1000.0);
	} 

private:
#if defined _WINDOWS
	LARGE_INTEGER m_frequency; 
	LARGE_INTEGER m_start; 
#else
	int64_t m_start; 
#endif
}; 





#endif // CHECK_TIME_H_