#ifndef INTEGR_TRIG_H_
#define INTEGR_TRIG_H_

#include <math.h>
#include "common.h"

#pragma pack(push, _CORE_PACKING)

//extern int	tab_sin_lm_[];
extern char	tab_sqr_lm[];
extern int	tab_tan_lm[];
extern int	tab_sin_lm[361];
extern int	tab_cos_lm[361];

//	Normalize angle to 360 degree
inline int upci( int ang )
{
	while(ang <    0) ang += 360;
	while(ang >= 360) ang -= 360;

	return ang;//angle is 0..359
}
//	Normalize angle to 180 degree
inline int uppi( int ang )
{
   while(ang <    0)	ang += 180;
   while(ang >= 180)	ang -= 180;
   return ang;//angle is 0..179
}
// Normalize angle to 90 degrees
inline int upri( int ang )
{
   ang = uppi( ang );
   if( ang > 90 ) return 180 - ang;
   else           return ang; //angle is 0..90
}
// return cos from angle in degree(clockwise)
float iCos(float angle);
float iCos(int angle);

inline int cost( int alpha )
{
	//quick check alpha dimension
	alpha = upci (-alpha);

   return tab_cos_lm[alpha];
}

// return sin from angle in degree(clockwise)
float iSin(float angle);
float iSin(int angle);

inline int sint( int alpha )
{
	alpha = upci( -alpha );

   return tab_sin_lm[alpha];
}


//	Get square root
inline int iSqrt( int val )
{
	//for small value-quick table
	if (val < 9872) 
		return tab_sqr_lm[val];	//use
	else
		return iSqrt( 1+val/4 )<<1;
}

//	Get index for table
inline int in( int da,int db )
{
	return ((da << 7) + db)/db;
}

// return arctangents in a range -180... +180 degree
inline int iAtan2 (int y, int x)
{
	int quad = 0;  // quadrant number
	//check d(x),d(y)
	if (x == 0)
	{
		if      (y == 0) return   0;
		else if (y >  0) return  90;
		else      		  return 270;
	}
	else if (y == 0)
	{
		if  (x > 0) return 0;
		else			return 180;
	}

	//check  d(x)
	if (x < 0)
	{
		x = -x; quad += 1;
	}
	//check  d(y)
	if (y < 0)
	{
		y = -y; quad += 2;
	}

	//arctangent..
	if (quad == 0)
		if (y > x)
			return 90 -tab_tan_lm[in( x,y )];
		else
			return	  tab_tan_lm[in( y,x )];
	else
	if (quad == 1)
		if (y > x)
			return 90 +tab_tan_lm[in( x,y )];
		else
			return 180-tab_tan_lm[in( y,x )];
	else
	if (quad == 2)
		if (y > x)
			return tab_tan_lm[in( x,y )] - 90;
		else
			return -tab_tan_lm[in( y,x )];
	else
		if (y > x)
			return -tab_tan_lm[in( x,y )] - 90;
		else
			return tab_tan_lm[in( y,x )] - 180;
}



//	Get scaled sin value for any alpha
inline int sinm( int mul,int alpha )
{
	if ((mul *= sint( alpha )) >= 0)
		return  ((+mul + 4096) >> 13);
	else
		return -((-mul + 4096) >> 13);
}

//	Get scaled cos value for any alph
inline int cosm( int mul,int alpha )
{
   if ((mul *= tab_cos_lm[upci( alpha )]) >= 0)
	   return  ((+mul + 4096) >> 13);
   else
	   return -((-mul + 4096) >> 13);
}


//	Turn a-vec clockwize to b-vec
inline int cloc( int a,int b )
{
   //check <a> dimension
   a = upci(a);
   //check <b> dimension
   b = upci(b);

   //calculate parameter
   int ang = b - a;

   //is delta clockwize?
   if ( ang >= 0 ) return ang;//ok
   else            return ang+360;
}
//
inline bool isVectorInSector( int vec, int start, int end )
{
   int sv = cloc( start , vec );
   int se = cloc( start, end  );
   return ( sv < se ) ;
}
//
inline int   dist( int dx, int dy )
{
   return iSqrt( dx * dx + dy * dy );
}

inline float dist(float dx, float dy)
{
   return (float)(sqrt(dx * dx + dy * dy) + 0.5);
}

template < class T >
inline T dist( T x1, T y1, T x2, T y2)
{
   return ( T )dist( x2 - x1, y2 - y1 );
}

template <class T> 
static inline T normAngle (T angle)
{
   while (angle < -180)
      angle += 360;
   while (angle > 180)
      angle -= 360;
   return angle;
}

#pragma pack(pop)
#endif // INTEGR_TRIG_H_
