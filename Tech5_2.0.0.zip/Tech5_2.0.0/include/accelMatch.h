/*****************************************************************************
	accelMatch.h - header file for acceleration matching module
    
*******************************************************************************/
#ifndef TECH5_ACCEL_H_
#define TECH5_ACCEL_H_

#include <list>
#include <stdint.h>

#include "coreSdk.h"
#include "accelRetCode.h"

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)


// default values
#define ACCEL_SEARCH_SPEED_DEF    2     // default accelerator matching speed
#define ACCEL_MAX_ANGLE_DEF       65    // default angle tolerance in accelerator matching 
#define ACCEL_AGE_TOLERANCE       5     // default tolerance for age in accelerator age filter

// Accelerator search parameters
struct AccelSearchParam
{
   // search speed. The current valid value from 0 to 6
   unsigned int   searchSpeed;  
   // the maximum of the finger turn angle for all fingers expcept thumbs, (0...180 degree)
   unsigned int   maxAngle;     
   // the maximum of the finger turn angle for thumbs, (0...180 degree)
   unsigned int   maxAngleThumbs;     
   // nuumber of fingers for accelerator matching. If numFingers == -1, number of fingers for matching will 
   // be chosen by library automatically
   int            numFingers;           
   // parameters of demographic data filter
   bool           useSexFilter;
   bool           useAgeFilter;
   unsigned int   ageTolerance;
   // try to correct possible segmentation error
   bool           doSegErrCorrect; 
   MATCHING_MODE  matchingMode;                 
   /* 
     parameters for final (precise) stage of matching in 'completeIdentifyTP' and 'finalIdentifyTP' functions:
   */
   int            low_threshold;                 
   int            high_threshold;  

   AccelSearchParam()
   {
      searchSpeed                   = ACCEL_SEARCH_SPEED_DEF;
      maxAngle                      = ACCEL_MAX_ANGLE_DEF;
      maxAngleThumbs                = ACCEL_MAX_ANGLE_DEF;
      numFingers                    = -1;
      useSexFilter                  = false;
      useAgeFilter                  = false;
      ageTolerance                  = ACCEL_AGE_TOLERANCE;
      doSegErrCorrect               = false;    
      matchingMode                  = NORMAL_MATCHING_MODE;
      low_threshold                 = LOW_THRESHOLD_DEF;  
      high_threshold                = HIGH_THRESHOLD_DEF;  
   }
};

struct GalleryItem
{
   TpTemplate  m_tpTemplate;
   BYTE       *m_accel     ;
   uint64_t    m_id        ;
   GalleryItem()
   {
      memset (this, 0, sizeof(GalleryItem));
   }
   GalleryItem(uint64_t id, TpTemplate &tpTemplate) 
   {
      m_id         = id        ;
      m_tpTemplate = tpTemplate;
   }
   ~GalleryItem() { }
   GalleryItem& operator= (const GalleryItem& item)
   {
      m_tpTemplate = item.m_tpTemplate;
      m_accel      = item.m_accel     ;
      m_id         = item.m_id        ;  
      return *this;
   }
   GalleryItem(const GalleryItem& item)
   {
      *this = item;
   }
   bool operator==( const GalleryItem &item ) const
   {
      return (item.m_id == m_id);
   }
   operator uint64_t () const
   {
      return m_id;
   }
};


#ifdef _WINDOWS
enum Sex : BYTE
#else
enum Sex
#endif
{
   SEX_X = 0, // unknown gender
   SEX_M = 1, // gender reported as male
   SEX_F = 2, // gender reported as female 
   SEX_G = 3, // occupation or charge indicated "Male Impersonator
   SEX_N = 4, // occupation or charge indicated "Female Impersonator" or transvestite
   SEX_Y = 5, // male name, no gender given
   SEX_Z = 6, // female name, no gender given
};

#pragma pack (push, 1)
struct P_PACKED_1 PersonalData
{
#ifdef _WINDOWS
   Sex            m_sex;                         
#else
   BYTE           m_sex;
#endif
   WORD           m_birthYear;                   // year of birth 
   BYTE           m_leftSlapError;               // less than 4 fingers was found in left   slap
   BYTE           m_rightSlapError;              // less than 4 fingers was found in right  slap
   BYTE           m_thumbsError;                 // less than 2 fingers was found in thumbs slap
   BYTE           m_reserved[10];                // sizeof of this structure shouls be aligned to 16!!!               

   PersonalData()
   {
      clear();
   }
   void clear()
   {
      memset (this, 0, sizeof(PersonalData));
      m_sex = SEX_X;
   }
   PersonalData& operator=(const PersonalData &pd)
   {
      m_sex            = pd.m_sex; 
      m_birthYear      = pd.m_birthYear;  
      m_leftSlapError  = pd.m_leftSlapError;
      m_rightSlapError = pd.m_rightSlapError;
      m_thumbsError    = pd.m_thumbsError;     
      memcpy (m_reserved, pd.m_reserved, sizeof(m_reserved));
      return *this;
   }
   PersonalData(const PersonalData &pd)
   {
      *this = pd; 
   }
};
#pragma pack (pop)




// return maximum size of template with 'numFingers' fingers in accelerator format
unsigned int getMaximumAccelSize (unsigned int numFingers = 10); 

/*
   Initialize accelMatch libraty. Should be called one time before call any functions below
   NOTE: it not initialized functions for final matching, like 'completeIdentifyTP', 
   'doStepCompareTP' for numStep > 0, 'finalIdentifyTP'
   To use these functions call 'initFinalMatching' function first
   Parameters:
   accelHandle       (input-output)  - pointer to handle of accelMatch library
   numThreads        (input-output)  - number of threads, that will be used in parallel works. 
                                       if numThread = 0 - then it will be set to the number of Core in system.
                                       return the reall nummber of threads the library was initialized for
   ipVer             (input)          - image processing version (can be 73 or 140)
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
*/
int initAccelLib (void **accelHandle, unsigned int &numThreads);

/*
   Initialize accelMatch libraty for work with final matching functions, like 'completeIdentifyTP', 
   'doStepCompareTP' for numStep > 0, 'finalIdentifyTP'
   Parameters:
   accelHandle     (input)   - pointer to handle of accelMatch library, that was get from 'initAccelLib' function
   maxGallerySize  (input)   - maximum possible size of gallery that will be used while identification
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
*/
int initFinalMatching (void *accelHandle, unsigned int &maxGallerySize);



/*
   Close work with accelMatch libraty. Should be called one time before and of work with the library
   Parameters:
   accelHandle  (input)   - pointer to handle of accelMatch library, that was get from 'initAccelLib' function
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
*/
int closeAccelLib (void **accelHandle);


/*
   Calculate accelerator from TP in TECH5 formatl
   Function is multithreaded (use all available Core)
   Parameters:
   accelHandle (input)  - handle of accelMatch library, that was get from 'initAccelLib' function
   templ       (input)  - 10-finger templates in TECH5 format
   accel    	(output) - 10-fingers tempate in accelerator format. Memory should be allocated in application
                          NOTE: memory should be aligned to 16 
   accelSize   (output) - a real size of calculated accelerator
   personalData (input) - pointer to structure with some personal data. If it's NULL, then all data will have default value
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
   NOTE: in multi-thread enviroment function should not be called at the same time with matching function inside one library instance (same accelHandle)!!!! 
*/
int calcAccel (void *accelHandle, TpTemplate &templ, BYTE *accel, DWORD &accelSize, PersonalData *personalData = NULL);

/*
   Get the number of fingers the accelerator keeps information about
   Parameters:
   accel      (input)  - pointer to accelerator.
   numFigners (output) - this varialbe get he number of fingers accelerator keeps information about
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
*/
int getFingers (BYTE *accel, unsigned int &numFingers);


/*
   validate accelerator data
   Parameters:
   accel    	(input) - pointer to 10-finger accelerator.
   fullCheck   (input) - if it's false, then only some quick checks are preformaed
   Return value: 
   true if accelerator data valid, false otherwise
*/
bool checkAccel (BYTE *accel, bool fullCheck = false);

/*
   Upload database
   Should be called before call any identification functions ('accelIdentifyTP', 'completeIdentifyTP', 'accelIdentifyLT')
   Parameters:
   accelHandle  (input)  - handle of accelMatch library, that was get from 'initAccelLib' function
   gallery      (input)  - container of fast and slow templates 
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
*/
int uploadDb (void *accelHandle, list <GalleryItem> &gallery);

/*******************************************************************************************************************
   Functions for accelerator matching only
********************************************************************************************************************/

/*
   Perform TP-TP identification by accelerators
   Function is multithreaded 
   Function 'uploadDb' should be called before
   Parameters:
   accelHandle       (input)  - handle of accelMatch library, that was get from 'initAccelLib' function
   param             (input)  - parameter of matching  
   probe             (input)  - probe 10-finger templates in TECH5 format
   rl                (input)  - pointer to recommended list array. Memory should be allocated in application
   sizeRl            (input)  - size of recommended list array 
   probePersonalData (input) - pointer to structure with some personal data those wil be used as a filter in mathcing. 
                               If it's NULL, then no filter will be used
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
*/
int accelIdentifyTP (void *accelHandle, AccelSearchParam &param, TpTemplate &probe, 
                     RL *rl, unsigned int sizeRl, PersonalData *probePersonalData = NULL);


/*
   load probe TP that will be compared by accelerator with gallery TP by 'compareAccelTP'function
   Parameters:
   accelHandle       (input)  - handle of accelMatch library, that was get from 'initAccelLib' function
   probe             (input)  - probe 10-finger templates in TECH5 format
   probePersonalData (input) - pointer to structure with some personal data those wil be used as a filter in mathcing. 
                               If it's NULL, then no filter will be used
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
*/
int loadAccelTP (void *accelHandle, TpTemplate &probe, PersonalData *probePersonalData = NULL);

/*
   Perform matching by accelerators gallery TP with probe TP that was previously loaded by 'loadAccelTP' function
   Parameters:
   accelHandle       (input)  - handle of accelMatch library, that was get from 'initAccelLib' function
   param             (input)  - parameter of matching  
   galleryAccel    	(input)  - pointer to gallery 10-finger template in accelerator format
   threadNum         (input)  - number of thread in which mathcing should be performed. 
                                It may not has value more then was set in 'initAccelLib' function
   matchResultTT     (output) - TP-TP match result information
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
*/
int compareAccelTP (void *accelHandle, AccelSearchParam &param, BYTE *galleryAccel, 
               unsigned int threadNum, MatchResultTT &matchResultTT);

/*******************************************************************************************************************
   Functions for complete (accelerator + precise) matching 
********************************************************************************************************************/
/*
   Perform complete TP-TP identification in 2 steps: at first by accelerator, then top of recommended list matched by 
   precise matching algorithm
   Function is multithreaded 
   Function 'uploadDb' should be called before
   Parameters:
   accelHandle       (input)  - handle of accelMatch library, that was get from 'initAccelLib' function
   param             (input)  - parameter of matching  
   probe             (input)  - probe 10-finger templates in TECH5 format
   outRl             (output) - pointer to final recommended list array. Memory should be allocated in application
   sizeRl            (input)  - size of outRl recommended list array 
   probePersonalData (input) - pointer to structure with some personal data those wil be used as a filter in mathcing. 
                               If it's NULL, then no filter will be used
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
*/
int completeIdentifyTP (void *accelHandle, AccelSearchParam &param, TpTemplate &probe,
                        RL *outRl, unsigned int outRlsize, 
                        PersonalData *probePersonalData);



/*******************************************************************************************************************
   Following block of funtions is supposed to implement step by step matching, when caller can don't know how many 
   steps exists

********************************************************************************************************************/

// return maximum matching step number for current implementation
unsigned int getMaxStepNum ();


/*
   Load probe TP that will be used for complete matching with gallery TP by 'doNextStepCompareTP' function
   or for accelerator matching by 'compareAccelTP' function
   Parameters:
   accelHandle       (input)  - handle of accelMatch library, that was get from 'initAccelLib' function
   probe             (input)  - probe 10-finger templates in TECH5 format
   probePersonalData (input) - pointer to structure with some personal data those wil be used as a filter in mathcing. 
                               If it's NULL, then no filter will be used
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
*/
int loadTP (void *accelHandle, TpTemplate &probe, PersonalData *probePersonalData = NULL);


/*
   Perform step by step matching gallery TP with probe TP that was previously loaded by 'loadTP' function
   NOTE: you can use this function for all matching steps or you can use 'compareAccelTP' for step=0 (accelerator matching)
         and then use this function with step = 1...getMaxStepNum () for precise matching. 
   Parameters:
   accelHandle       (input)        - handle of accelMatch library, that was get from 'initAccelLib' function
   param             (input)        - parameter of matching  
   threadNum         (input)        - define the number of thread where compare will be done
   numStep           (input)        - number of matching step. It can have value from 0 till getMaxStepNum ()
   probeTech5        (input)        - probe 10-finger templates in TECH5 format
   galleryAccel    	(input)        - pointer to gallery 10-finger template in accelerator format
   galleryTemplate 	(input)        - pointer to gallery 10-finger template in TECH5 format
   matchResultTT     (input-output) - keeps match result information, that should be passed from one step to another. 
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
*/
int doStepCompareTP (void *accelHandle, AccelSearchParam &param, unsigned int threadNum, unsigned int numStep,
                           TpTemplate &probeTech5, BYTE *galleryAccel, TpTemplate &galleryTemplate, 
                           MatchResultTT &matchResultTT);

/*******************************************************************************************************************
   Latent matching
   

********************************************************************************************************************/


/*
   Perform LT identification by accelerators
   Function is multithreaded (use all available Core)
   Parameters:
   accelHandle       (input)  - handle of accelMatch library, that was get from 'initAccelLib' function
   param             (input)  - parameter of matching  
   latentTempl       (input)  - latent template in TECH5 format
   fingerMask        (input)  - finger mask (1 -matching with corresponded finger, 0 - not matching)
   rl                (input)  - pointer to recommended list array. Memory should be allocated in application
   sizeRl            (input)  - size of recommended list array 
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
*/
int accelIdentifyLT (void *accelHandle, AccelSearchParam &param, BYTE *latentTempl, BYTE fingerMask[10], 
                     RL *rl, unsigned int sizeRl);


#pragma pack(pop)
} // namespace accelMatch{

#endif //TECH5_ACCEL_H_
