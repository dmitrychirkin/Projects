/*****************************************************************************
	processBase.h - header file for 'processBase' class

*******************************************************************************/
#ifndef PROCESS_BASE_H__
#define PROCESS_BASE_H__

#include "coreSdk.h"
#include "core_err.h"
#include "sfsDef.h"
#include "win2linGdi.h"

#pragma pack(push, _CORE_PACKING)

#define CHECK(x) if (x != IP_OK) return x; 


class ProcessBase
{
	BYTE               *m_buffer[2];       // array of buffers for temporary image data   
	bool                m_firstBuffer;     // is the current image in first buffer?
	BITMAPINFOHEADER   *m_bih;             // current image header
	unsigned char      *m_src;             // pointer to temporary buffer	
	unsigned char      *m_dst;             // pointer to temporary buffer
   /*
      segmentation parameters specific for image processing version
   */
   unsigned int        m_alignmentX;       // image alignment by width
   unsigned int        m_alignmentY;       // image alignment by height
   unsigned int        m_minWidth  ;       // minimum image width
   unsigned int        m_maxWidth  ;       // maximum image width
   unsigned int        m_minHeight ;       // minimum image height
   unsigned int        m_maxHeight ;       // maximum image height

protected:
	bool                m_init;            // initialization flag 


public:
	ProcessBase();
	~ProcessBase();

	// allocate memory for data[] templates
	static int allocateTemplates(unsigned int numFingers, TemplateData data[], int maxFingerTemplateSize);
	// free memery that was earlier allocate templates
	static int freeTemplates(unsigned int numFingers, TemplateData data[]);
   /* 
	   Processes a fingerprint image, taken as DIB and build its template.
	   Parameters:
      pContext    (input)  - pointer to execution context, that will be passed as is to all callback functions 
	   data	      (input)  - the CaptureData structures, that contain the fingerprint image data 
	   fpTemplate	(output) - the TemplateData structures that receive? the built template. 
                             Memory for the value should be previously allocated
				                 by 'allocateTemplates' function
		templSize   (output) - the buffer that receives the size of template
		quality     (output) - the buffer that will receives the fingerprint image quality. 
                             NOTE: If qualityOnly= true, then this value will contain the preliminary 
                             estimation of fingerprint quality and function will complete after getting this value 
                             (template will not be built).
                             If qualityOnly = false, then template will be built and this value will contain 
                             the final (more precise) quality of fingerprint image.
      param       (input)  - the process parameters. If it is NULL, defaul parameters are used
	   frame       (output) - if this parameter is non null, then the fingerprint image location 
                             (with white space cut off) will be put in this structure 
      onPreprocess (input) - callback function that will be called when preprocessing stage
                             (image segmentation etc.) is completed. 
                             If this parameter is NULL, no callback function will be called  
      onGetQuality (input) - callback function that will be called when preliminary 
                             estimation of fingerprint image quality will be calculated
                             If this parameter is NULL, no callback function will be called  
      onProcess1   (input) - callback function that will be called when the 1st processing stage
                             (define of core\delta location) is completed.  
                             If this parameter is NULL, no callback function will be called  
      onSkeleton   (input) - typedef for callback functions, those will be called when skeleton 
                             building will be completed.
                             If this parameter is NULL, no callback function will be called  
      qualityOnly  (input) - if its true, then function returns as soon as preliminary 
                             estimation of fingerprint image quality will be calculated
		Return value:
		The function returns IP_OK - if function succeeds, error code - otherwise
   */	
   int  process  (
                  const LPVOID          pContext,   
                  const CaptureData     data, 
                        TemplateData   &fpTemplate, 
                        unsigned int   *templSize, 
                        int            *quality,
                        ProcessParam   *param        = NULL, 
                      ::Frame          *frame        = NULL,
                        ON_PRE_PROCESS  onPreprocess = NULL, 
                        ON_GET_QUALITY  onGetQuality = NULL, 
                        ON_PROCESS_1    onProcess1   = NULL,
                        ON_SKELETON     onSkeleton   = NULL,
                        bool            qualityOnly  = false);  
   /* 
	   Processes a fingerprint image, taken as DIB and build its template.
		Image should be 500 DPI, uncompressed, 256 gray-level(8bpp), top-bottom 
		Parameters:
      pContext     (input) - pointer to execution context, that will be passed as is to all callback functions 
		image        (input) - the buffer that contains fingerprint image 
		widht        (input) - image width
		height       (input) - image height
		fpTemplate   (otput) - the buffer that receives the built template. 
					              Memory for this variable should be allocated in application
		templSize   (output) - the buffer that receives the size of template
		quality     (output) - the buffer that will receives the fingerprint image quality. 
                             NOTE: If qualityOnly= true, then this value will contain the preliminary 
                             estimation of fingerprint quality and function will complete after getting this value 
                             (template will not be built).
                             If qualityOnly = false, then template will be built and this value will contain 
                             the final (more precise) quality of fingerprint image.
      param       (input)  - the process parameters. If it is NULL, defaul parameters are used
	   frame       (output) - if this parameter is non null, then the fingerprint image location 
                             (with white space cut off) will be put in this structure 
      finger      (input)  - finger position
      skeleton    (output) - if this parameter is non null, then the skeleton 
                             information will be copied in this buffer
                             The memory (with size at least width * height) should 
                             be allocated in application
      skeletonSize (output)- the buffer that receives the real size of copied skeleton data
      onPreprocess (input) - callback function that will be called when preprocessing stage
                             (image segmentation etc.) is completed. 
                             If this parameter is NULL, no callback function will be called  
      onGetQuality (input) - callback function that will be called when preliminary 
                             estimation of fingerprint image quality will be calculated
                             If this parameter is NULL, no callback function will be called  
      onProcess1   (input) - callback function that will be called when the 1st processing stage
                             (define of core\delta location) is completed.  
                             If this parameter is NULL, no callback function will be called  
      onSkeleton   (input) - typedef for callback functions, those will be called when skeleton 
                             building will be completed.
                             If this parameter is NULL, no callback function will be called  
      qualityOnly  (input) - if its true, then function returns as soon as preliminary 
                             estimation of fingerprint image quality will be calculated
		Return value:
		The function returns IP_OK - if function succeeds, error code - otherwise
	*/	
	int processRaw    (    
                      const LPVOID         pContext,   
                            unsigned char *image, 
                            unsigned int   width, 
                            unsigned int   height, 
                            unsigned char *fpTemplate, 
                            unsigned int   *templSize, 
                            int            *quality,
                            ProcessParam   *processParam = NULL,
                          ::Frame          *frame        = NULL,
                            FINGERS         finger       = FINGPOS_UK,
                            BYTE           *skeleton     = NULL,
                            int            *skeletonSize = NULL,  
                            ON_PRE_PROCESS  onPreprocess = NULL, 
                            ON_GET_QUALITY  onGetQuality = NULL, 
                            ON_PROCESS_1    onProcess1   = NULL,
                            ON_SKELETON     onSkeleton   = NULL,
                            bool            qualityOnly  = false 
                            );
///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
   	/* 
   	Initialize work with ProcessBase class
      Parameters:
      numThreads (input)  - number of threads, that will be used for parallel works. 
                            if numThread = 0 - then it will be set to the number of Core
                            in system.
      Return value: 
      The function returns IP_OK - if function succeeds, error code - otherwise
	*/
   virtual int common_init(int num_threads);
   int init(int num_threads);
   /* 
      Initialize work with Ip class
      In differ from 'init' function it take the protection data
      This function (of 'init' function)should be called first before call 
      any other function
      Parameters:
      protect  input) - pointer to 512 byte buffer  with protected data
      numThreads (input)  - number of threads, that will be used for parallel works. 
                            if numThread = 0 - then it will be set to the number of Core
                            in system.
      Return value:
      The function returns IP_OK - if function succeeds, error code - otherwise
   */
   int initEx (BYTE protect[MAX_PROTECT_LEN], int num_threads);

protected:
   // set segmentatin parameters, specific for certain image processing version
   void setSegmentationParameters(unsigned int minWidth  , unsigned int maxWidth, 
                                  unsigned int minHeight , unsigned int maxHeight,
                                  unsigned int alignmentX, unsigned int alignmentY);
   // alloc memory for call members
   virtual bool alloc(int num_threads);
   // release memory for class members
   virtual void release();
	// check the input image and read the resolution
	int checkImage();
	// flip image if it is necessary
	int flipImage();
   // transform DIB to standart RGB color table if it's necessary
   int correctRGB(RGBQUAD *rgb);
	// find figerprint image in source image and cut it
   int cutImage(unsigned int maxWidth, unsigned int maxHeight, ::Frame &frame);
	// find figerprint image in source image and cut it
	int cutImage(unsigned int width, unsigned int height, ProcessParam &processParam,
               ::Frame &frame);
   // be sure that new image size is satisfy the requirements
   // return true if size was changed
   bool correctImageSize(unsigned int width , unsigned int height,
                         int &left , int &top, int &right, int &bottom,
                         ProcessParam &param);
	// strech image if it is necessary
	int  strechImage(ProcessParam &param, BYTE *dib);
	// white padding pixels if necessary
   void  whitePadding();
	// prepare image before processing
   int prepareImage(BYTE *dib, ProcessParam &param, ::Frame &frame);

	/* 
		Processes one fingerprint image and build its template.
		Image sould be 500 DPI, uncompressed, 256 gray-level(8bpp)
		Size of imge should be not more than MAX_WIDTH * MAX_HEIGHT
		Parameters:
      pContext  (input)  - pointer to execution context, that will be passed as is to all callback functions 
		image     (input)  - source image 
		widht     (input)  - image width
		height    (input)  - image height
		templ     (output) - the buffer that receives the built template. 
		templSize (output) - the buffer that will receives the size of built template 
		quality   (output) - the buffer that will receives the fingerprint image quality. 
                           NOTE: If qualityOnly= true, then this value will contain the preliminary 
                           estimation of fingerprint quality and function will complete after getting this value 
                           (template will not be built).
                           If qualityOnly = false, then template will be built and this value will contain 
                           the final (more precise) quality of fingerprint image.
	   frame     (in-out) - the fingerprint image location with white space cut off).
                           Before call it contains frame before image processing, that 
                           can be change while image processing
      finger    (input)  - finger position
		skeleton  (output) - if this parameter is not NULL then fingerprint sceleton will be copy 
		                     to this buffer. Memory should be allocated in application. Size of buffer 
							 should be not less than width * height in bytes
		good      (input)  - if the image has a good quality?
      onPreprocess (input) - callback function that will be called when preprocessing stage
                             (cut off the white space) is completed. 
                             If this parameter is NULL, no callback function will be called  
      onGetQuality (input) - callback function that will be called when preliminary 
                             estimation of fingerprint image quality will be calculated
                             If this parameter is NULL, no callback function will be called  
      onProcess1   (input) - callback function that will be called when the 1st processing stage
                             (define of core\delta location) is completed.  
                             If this parameter is NULL, no callback function will be called  
      onSkeleton   (input) - typedef for callback functions, those will be called when skeleton 
                             building will be completed.
                             If this parameter is NULL, no callback function will be called  
      qualityOnly  (input) - if its true, then function returns as soon as preliminary 
                             estimation of fingerprint image quality will be calculated
                             (template will not be built)
		Return value:
		The function returns IP_OK - if function succeeds, error code - otherwise
	*/	
	virtual int wizardWork (
             const LPVOID           pContext,   
                   unsigned char   *image, 
                   unsigned int     width, 
                   unsigned int     height, 
                   unsigned char   *templ,  
                   unsigned int    *templSize, 
                   int             *quality,   
                 ::Frame           &frame,   
                   FINGERS          finger                  = FINGPOS_RT,
                   BYTE            *skeleton                = NULL, 
                   int             *skeletonSize            = NULL, 
                   bool             ISO_compatible          = false,
                   ON_PRE_PROCESS   onPreprocessingComplete = NULL, 
                   ON_GET_QUALITY   onGetQuality            = NULL, 
                   ON_PROCESS_1     onProcess1              = NULL,
                   ON_SKELETON      onSkeleton              = NULL,
                   bool             qualityOnly             = false) = 0;

	// set source and destination buffers for image operations
	inline void setSrcDst(); 
	// set initial state of buffers
	inline void initBuffers(unsigned char* buffer); 
	// change state of buffers
	inline void changeBuffers(); 
	// get current buffer
	inline unsigned char* getBuffer(); 
   // set protection code
   virtual void setProtect(BYTE protect[MAX_PROTECT_LEN]) = 0;
   // get protection code
   virtual void getProtect(BYTE protect[MAX_PROTECT_LEN]) = 0;
   // callback function (after preprocessing complete)
   bool onPreProcessComplete(const LPVOID pContext, ON_PRE_PROCESS onPreprocess, FINGERS finger, ::Frame &frame);
   // callback function (after preprocess1 complete)
   virtual bool onProcess1Complete(const LPVOID pContext, ON_PROCESS_1 onProcessing1Complete, FINGERS finger) = 0;
   // callback function (after getting quality)
   bool onGetQualityComplete(const LPVOID pContext, ON_GET_QUALITY onGetQuality, FINGERS finger, int quality);
   // callback function (after getting skeleton)
   bool onSkeletonComplete(const LPVOID pContext, ON_SKELETON onGetQuality, FINGERS finger, BYTE *skeleton, int skeletonSize);
};

inline void ProcessBase::setSrcDst()
{
	m_src = (m_firstBuffer ? m_buffer[0] : m_buffer[1]);
	m_dst = (m_firstBuffer ? m_buffer[1] : m_buffer[0]);
}

inline void ProcessBase::initBuffers(unsigned char* buffer) 
{
  	m_src = buffer;
   if (buffer == m_buffer[1])
   {
	   m_dst = m_buffer[0];
	   m_firstBuffer = false;
   }
   else
   {
	   m_dst = m_buffer[1];
	   m_firstBuffer = true;
   }
}
inline void ProcessBase::changeBuffers() 
{
	m_firstBuffer = !m_firstBuffer;
   setSrcDst();
}
inline unsigned char* ProcessBase::getBuffer()
{
	return m_firstBuffer ? m_buffer[0] : m_buffer[1];
}

#pragma pack(pop)


#endif // PROCESS_BASE_H__
