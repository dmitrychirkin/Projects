/*****************************************************************************
	accelMatchEx.h - extended header file for acceleration matching module
    
*******************************************************************************/
#ifndef TECH5_ACCEL_EX_H_
#define TECH5_ACCEL_EX_H_

#include "accelMatch.h"

namespace accelMatch{
#pragma pack(push, _CORE_PACKING)



struct SS_RL                  // 2nd stage of matching recommended list
{
   uint64_t         regNum;
   int           score[10];  // final score for each finger in a range 0...MAX_SCORE
   char    galleryPair[10];  // input-output: keeps position of gallery finger, that was 
                             // defined as best pair for corresponded probe finger
                             // if there is no pair, corresponded value will be set to -1           
   int         fusionScore;
   SS_RL()
   {
      this->regNum     = -1;
      this->fusionScore = -1;
      for(int pos = 0; pos < 10; pos++)
      {
         score       [pos] = -1;
         galleryPair [pos] = -1;
      }
   }
   SS_RL (uint64_t regNum, int fusionScore, int score[10], char galleryPair[10])
   {
      this->regNum      = regNum;
      this->fusionScore = fusionScore;
      memcpy (this->score      ,         score, sizeof(      score[0]) * 10);
      memcpy (this->galleryPair,   galleryPair, sizeof(galleryPair[0]) * 10);
   }
   operator int () const
   {
      return this->fusionScore;
   }
};
typedef std::multiset <SS_RL, std::greater<int> > SS_RL_SET;



/*
   Perform finger to finger matching by accelerators
   Parameters:
   accelHandle   (input)  - handle of accelMatch library, that was get from 'initAccelLib' function
   param         (input)  - matching  parameter
   probe         (input)  - probe fingerprint template in TECH5 format
   gallery_accel (input)  - gallery 10-fingerprint acceleration template
   probeFinger   (input)  - probe   finger number
   galleryFinger (input)  - gallery finger number
   similarity    (output) - fingerprint similarity
   matchResult   (output) - structure with information about result of matching
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
*/
int accelPairMatch (void *accelHandle, AccelSearchParam &param, BYTE *probe, BYTE *gallery_accel, int probeFinger, int galleryFinger, int &similarity, MatchResult &matchResult);

/*
   Load Probe accelerator for future m finger to finger matching with 'accelPairMatchEx' function
   Parameters:
   accelHandle   (input)  - handle of accelMatch library, that was get from 'initAccelLib' function
   probe         (input)  - first  fingerprint template in TECH5 format
   finger        (input)  - probe finger number
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
*/
int loadProbeAccel (void *accelHandle, BYTE *probe, int finger);

/*
   Perform finger to finger gallery accelerator matching with probe, previously loaded by 'loadProbeAccel' function
   Parameters:
   accelHandle   (input)  - handle of accelMatch library, that was get from 'initAccelLib' function
   param         (input)  - parameter of matching  
   gallery_accel (input)  - second 10-fingerprint acceleration template
   probeFinger   (input)  - probe   finger number
   galleryFinger (input)  - gallery finger number
   similarity    (output) - fingerprint similarity
   matchResult   (output) - structure with information about result of matching
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
*/
int accelPairMatchEx (void *accelHandle, AccelSearchParam &param, BYTE *gallery_accel, 
                        int probeFinger, int galleryFinger, int &similarity, MatchResult &matchResult);

/*
   Perform TP-TP identification by accelerators
   Function is multithreaded (use all available Core)
   Parameters:
   accelHandle       (input)  - handle of accelMatch library, that was get from 'initAccelLib' function
   param             (input)  - parameter of matching  
   probe             (input)  - probe 10-finger templates in TECH5 format
   rlSet             (output) - recommended list.
   probePersonalData (input) - pointer to structure with some personal data those wil be used as a filter in mathcing. 
                               If it's NULL, then no filter will be used
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
*/
int accelIdentifyTP_ (void *accelHandle, AccelSearchParam &param, TpTemplate &probe, RL_SET &rlSet,
                      PersonalData *probePersonalData);



int compareAccelTP_ (void *accelHandle, AccelSearchParam &param, BYTE *galleryAccel, unsigned int threadNum, 
                     MatchResultTT &matchResultTT, bool saveCombineData);


/*
   Perform 2nd stage of TP-TP identification: match top of recommended list by precise matching algorithm
   Function is multithreaded (use all available Core)
   Parameters:
   accelHandle       (input)  - handle of accelMatch library, that was get from 'initAccelLib' function
   accelParam        (input)  - parameter of accelerator matching. Should be the same as in 'compareTP' function   
   probe             (input)  - probe 10-finger templates in TECH5 format 
   galleryAccel      (input)  - array of gallery 10-finger templates in accelerator format
   galleryTemplate   (input)  - array of gallery 10-finger templates in TECH5 format
   gallerySize       (input)  - size of gallery array
   rlSet             (input)  - recommended list set, that was returen by 'accelIdentifyTP_' function   
   outRl             (output) - pointer to final recommended list array. Memory should be allocated in application
   sizeRl            (input)  - size of outRl recommended list array 
   probePersonalData (input) - pointer to structure with some personal data those wil be used as a filter in mathcing. 
                               If it's NULL, then no filter will be used
   Return value: 
   function returns SA_OK - if function succeeds, error code - otherwise
*/
int finalIdentifyTP (void *accelHandle, AccelSearchParam &accelParam, TpTemplate &probe,
                     BYTE **galleryAccel, TpTemplate *galleryTemplate, unsigned int gallerySize, 
                     RL_SET &rlSet, RL *outRl, unsigned int outRlSize, PersonalData *probePersonalData);


#pragma pack(pop)
} // namespace accelMatch{

#endif //TECH5_ACCEL_EX_H_
