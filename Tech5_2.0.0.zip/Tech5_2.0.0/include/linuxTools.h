/*
	this file contains the implementation of the functions those there are in Windows but absent in Linux
*/
#ifndef LINUX_TOOLS_H_
#define LINUX_TOOLS_H_

#include "common.h"
#pragma pack(push, _CORE_PACKING)

#ifndef	_WINDOWS
#include <ctype.h>


 inline int _strnicmp(const char *s1, const char *s2, size_t size) 
 {
	int res = 0;
	size_t i = 0;
	while (!res && size--) 
	{
		if (!s1[i]) return s2[i] ? -1 : 0;
		if (!s2[i]) return 1;
		res = tolower(s1[i]) - tolower(s2[i]);
		++i;
	}
	return res;
}


 
#endif	//	WIN32
#pragma pack(pop)
#endif  //LINUX_TOOLS_H_
