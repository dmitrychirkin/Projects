/*
   template_NIST.h - declare function for work with template in 
   INCITS 378 format
*/
#ifndef TEMPLATE_NIST_H_
#define TEMPLATE_NIST_H_

#include "template_nist_iso.h"
#include "win2lin.h"
#include "coreSdk.h"
#include "transEndian.h"

#ifndef PIV_CERTIFICATION
   #define EXTRACTOR_CBEFF_PID   0x003C0101   //0x003C0113
   #define MATCHER_CBEFF_PID     0x003C0213
#else
   #define EXTRACTOR_CBEFF_PID   0x0
   #define MATCHER_CBEFF_PID     0x0
#endif

#pragma pack(push, _CORE_TIGHT)

struct P_PACKED_1 NIST_viewHeader
{
   BYTE  m_position;                // Finger Position, 0...10 refer to ANSI/NIST standard
   BYTE  m_impressionType  : 4;     // Impression Type, 0...3 or 8 (0 or 2 for sp800-76)
   BYTE  m_viewNumber      : 4;     // View Number, 0...15 (0 for sp800-76)
   BYTE  m_quality;                 // Finger Quality 0...100
   BYTE  m_numMinutiae;             // Number of Minutiae (0...128 for sp800-76)
};

// Finger Minutiae Data
struct P_PACKED_1 NIST_minutiae
{
   WORD  m_x;           // The x coordinate of the minutia 
                        // (2 high bites - minutiae type)
   WORD  m_y;           // The y coordinate of the minutia 
                        // (2 high bites - reserved)
   BYTE  m_angle;       // The angle of the minutia in units of 2 degrees , 0...179
   BYTE  m_quality;     // Minutia Quality 1...100 (0 indicates �quality not reported�) (0 for sp800-76)
};

// INCITS 378 record header
struct P_PACKED_1 NIST_header
{
   DWORD    m_formatID;               // Format Identifier
   DWORD    m_version;                // Version Number   
   WORD     m_length;                 // Length of Record 26...65535, or 65536...4294967295 (26...800 for sp800-76)
   DWORD    m_PID;                    // CBEFF Product Identifier (PID)(0 for PIV certification)
   WORD     m_capture_e;              // Capture Equipment compliance, 4 bits (0 for PIV certification) 
                                      //   and ID, 12 bits(0 for PIV certification)
   WORD     m_width;                  // Size of Scanned Image in x direction, pixels 
   WORD     m_height;                 // Size of Scanned Image in y direction, pixels 
   WORD     m_resolutionX;            // Horizontal resolution, pixels/centimeter (197 for sp800-76)
   WORD     m_resolutionY;            // Vertical resolution, pixels/centimeter (197 for sp800-76)
   BYTE     m_numView;                // Number of Finger Views, 0...255 (1 for PIV certification, 2 for sp800-76)
   BYTE     m_reserved;               // Reserved byte. For this version of the 
                                      // standard, this field shall be set to 0.
  };
// INCITS 378 extended data header
struct P_PACKED_1 NIST_extendedHeader
{
   WORD     m_length;                 // Length of Record (0x0000 = no private area) (0 for sp800-76)
};



// calculate size of NIST template for corresponded TECH5 template
int getNISTtemplateSize(const BYTE *templ);

// calculate maximum size of NIST template for corresponded number of fingers
int calcFullNISTtemplSize(unsigned int numFingers);

// calculate miminum size of NIST template for corresponded number of fingers
int getMinNISTtemplateSize(unsigned int numFingers);

// calculate maximum minutiae that can be put to template (all view)  for 
// given maximum size of whole template
int getAlowsNumMinutiaeNIST(unsigned int numFingers, unsigned int maxSize);

bool checkNISTtemplate     (unsigned int &numFingers, const BYTE *moTemplate, float &kx, float &ky);

/*
   Build INCITS 378 template
   Parameters:
   numFingers      (input) : number of source fingers. Cannot be more than MAX_FINGERS   
   rawImage        (input) : array of raw image structure, that contains information
                             about source fingerprint images. Field image is not used in 
                             this function and can be NULL
   quality         (input) : array of image quality (one value for each finger). 
                             Size of this array should be not less than numFingers
   nistTemplate    (output): buffer for building NIST template
                             Memory for it should be allocated in application 
                             (you can use allocateISOtemplate function)
   numMinutiae     (input) : array of number of minutiae in each finger   
                             Size of this array should be not less than numFingers
   minutiae        (input) : array of minutiae information for each finger 
   frame           (input) : array of information about segmentation, that was performed while
                             image processing (returns by function 'process' and 'processRaw'
                             of Ip, Ip10, Ip71, Ip110 classes)
                             Size of this array should be not less than numFingers
   certifiedSensor (input) : is capture equipment comply with IQS (EFTS, Appendix F)?
   sensorID        (input) : Capture Equipment ID. The vendor determines the value for this field.
                             Applications developers may obtain the values for these codes from the vendor. 
   templSize       (output): The pointer to variable that receives the size of template 
                              (if it's not NULL)
   Retrun value:
   The function returns SME_OK if success and error code otherwise. 
*/
int buildNISTtemplate ( unsigned int numFingers, const RawImage *rawImage, 
                       BYTE *quality,
                       BYTE *nistTemplate,
                       unsigned int *numMinutiae,
                       Minutiae minutiae[MAX_MINUTIAE][MAX_MINUTIAE], 
                       Frame *frame = NULL, 
                       bool certifiedSensor = false, WORD sensorID = 0,
                       unsigned int *templSize = NULL);


#pragma pack(pop)

#endif // TEMPLATE_NIST_H_
