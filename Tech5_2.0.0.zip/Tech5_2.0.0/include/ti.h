/*****************************************************************************
	ti.h - header file for Template Information  of Core Matching SDK

	The Core Matching SDK is the high-level tool, intended for easy creating
   of your own scalable biometric applications that use the person's fingerprint 
	for identification or verification purpose. 

*******************************************************************************/
#ifndef TI_H__
#define TI_H__

#include "coreSdk.h"
#include "core_err.h"

#pragma pack(push, _CORE_PACKING)

/******************************************************************
          Template Information class
******************************************************************/
class FpTemplate;

class Ti
{
   FpTemplate *m_templ;
public:
	Ti();
	~Ti();

   /*   
      Extract information about minutiae from fingerprint template
      Parameters:
      fpTemplate  (input)  - pointer to the fingerprint template
      numMinutiae (output) - number of minutiae
      minutiae    (output) - minutiae information
      Function returns TI_OK - if function succeeds, error code - otherwise
   */
   int getMinutiae (const BYTE * fpTemplate, unsigned int &numMinutiae, 
                     Minutiae minutiae[MAX_MINUTIAE]);
   /*   
      Extract information about core/delta from fingerprint template
      Parameters:
      fpTemplate     (input)  - pointer to the fingerprint template
      numSingular (output) - number of Singular
      Singular    (output) - core/delta information
      pattern        (output) - pattern type
      Function returns TI_OK - if function succeeds, error code - otherwise
   */
   int getSingular (const BYTE * fpTemplate, unsigned int &numSingular,
                       Singular singular[MAX_SINGULAR],
                        unsigned int &pattern);
   /*   
      Extract information about bad (not informative) are from fingerprint template
      Parameters:
      fpTemplate (input)  - pointer to the fingerprint template
      area       (output) -  information about bad (not informative) area.
                             Each item correspond to the one pixel.
                             If corresponded  item == 0 then this pixel is 
                             belong to unclear area. Memory for that buffer should 
                             be allocated in application. Buffer should have at least 
                             (frame.right - frame.left + 1) * (frame.bottom - frame.top + 1)
                             bytes size.
      Function returns TI_OK - if function succeeds, error code - otherwise
   */
   int getArea (const BYTE * fpTemplate, unsigned char * area );
    /*
      Extract information about fingerprint image quality from fingerprint template
      Parameters:
      fpTemplate (input)  - pointer to the fingerprint template
      quality    (output) - fingerptint image quality
      Function returns TI_OK - if function succeeds, error code - otherwise
    */
   int getQuality   ( const BYTE * fpTemplate, BYTE &quality           );
    /*
      Extract information about fingerprint image size from fingerprint template
      Parameters:
      fpTemplate (input)  - pointer to the fingerprint template
      width    (output) - fingerptint image width
      height   (output) - fingerptint image height
      Function returns TI_OK - if function succeeds, error code - otherwise
    */
   int getImageSize ( const BYTE * fpTemplate, int &width, int &height );
    /*
      Return finerprint template version
      Parameters:
      fpTemplate (input)  - pointer to the fingerprint template
    */
   int getVersion   ( const BYTE * fpTemplate);
    /*
      Extract information about finger position from fingerprint template
      Parameters:
      fpTemplate (input)  - pointer to the fingerprint template
      finger    (output) - finger position
      Function returns TI_OK - if function succeeds, error code - otherwise
    */
   int getFingerPos   ( const BYTE * fpTemplate, FINGERS &finger           );
};

#pragma pack(pop)

#endif // TI_H__
