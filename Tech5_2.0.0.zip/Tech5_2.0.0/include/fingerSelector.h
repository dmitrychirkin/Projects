/*****************************************************************************
	fingerSelector.h - header file for finger selection class 
	The finger selection class is used for choose the best pair of fingers 
	for  matching in multifinger matching algorithm (MA) of Core Matching SDK

	The Core Matching SDK is the high-level tool, intended for easy creating
    of your own scalable biometric applications that use the person's fingerprint 
	for identification or verification purpose. 

*******************************************************************************/
 
#ifndef FINGER_SELECT_H
#define FINGER_SELECT_H

#include "coreSdk.h"

#pragma pack(push, _CORE_PACKING)

/******************************************************************
          Quality class
******************************************************************/
class Quality
{
	BYTE m_finger;			  // number of finger
	BYTE m_quality;		  // quality of fingerprints
	BYTE m_points;         // number of minutiae
	BYTE m_relPoints;      // number of relible minutiae
	int m_modQuality;		  // modified quality

public:
	Quality()
	{ clear();}
   void clear()
	{ m_finger = 0; m_quality = 0, m_points = 0, m_relPoints = 0, m_modQuality = 0;}
	Quality(BYTE finger, BYTE quality, BYTE points, BYTE relPoints, int modQuality = 0) 
	{ 
      set(finger, quality, points, relPoints, modQuality);
	}
	void set (BYTE finger, BYTE quality, BYTE points, BYTE relPoints, int modQuality = 0) 
	{ 
		m_finger = (finger >= 1 && finger <= 10) ? finger : 0; 
		m_quality = quality; 
      m_points = points; 
      m_relPoints = relPoints; 
		if (modQuality) 
         m_modQuality = modQuality;
		else     		
         calcModQuality();
	}
	int getFinger()const { return m_finger; }
	bool operator== (int n)const	{ return m_finger == n;}
	
	int getModQuality()const { return m_modQuality; }
	bool operator< (const Quality& q)const	{ return m_modQuality < q.getModQuality();}
	bool operator> (const Quality& q)const	{ return m_modQuality > q.getModQuality();}
	Quality operator+ (const Quality& q)const
	{
		if (m_finger != q.getFinger()) 
         return Quality();
		return Quality(m_finger, 0, 0, 0, m_modQuality + q.getModQuality());
	}
	Quality& operator= (const Quality& q)
   {
      set(q.m_finger, q.m_quality, q.m_points, q.m_relPoints, q.m_modQuality);
      return *this;
   }

protected:
	// calculate the modified quality
	void calcModQuality() 
	{
		m_modQuality = m_quality;
	}
};

/******************************************************************
          Finger Selector class
******************************************************************/


class Fs
{
	Quality  m_quality1[10];        // array of quality of the first set of templates
	Quality  m_quality2[10];		// array of quality of the second set of templates
   int      m_num1;
   int      m_num2;

public:
	Fs();


	const Quality*  getQuality1() const {return m_quality1;}
	const Quality*  getQuality2() const {return m_quality2;}

	// extract quality information from first template and put it to m_quality1
	int loadTemplate1 (unsigned int numFingers, TemplateData templSet[]);
	// extract quality information from second template set and put it to m_quality2
	int loadTemplate2 (unsigned int numFingers, TemplateData templSet[]);
	/*
	returns the numbers of finger pairs those available for match and
	ourputs the sorted list of fingerprints pairs  (the top number is the best pair)
	*/
	int getBestPairs(unsigned int numFinger[10], MATCHING_MODE  matchingMode = NORMAL_MATCHING_MODE);
protected:
	// extract quality information from template set and fill the quality vector
	int loadTemplate (unsigned int numFingers, TemplateData templSet[], Quality quality[], int &num);
   void clear(Quality quality[], int num)
   {
      if (num > 10) num = 10;
      for(int i = 0; i < num; i++)
         quality[i].clear();
   }
   bool checkTemplate(BYTE * templ);
};

#pragma pack(pop)


#endif // FINGER_SELECT_H



