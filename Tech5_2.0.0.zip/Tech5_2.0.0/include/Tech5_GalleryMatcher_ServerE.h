#ifndef TECH5_GALLERY_MATCHER_SERVER_E_H
#define TECH5_GALLERY_MATCHER_SERVER_E_H

#include <vector>
#include <string>

#include "coreSdk.h"

#ifdef _WINDOWS
	#ifdef TECH5_FINGER_SDK_BUILD_dll
		#define TECH5_FINGER_EXPORT __declspec(dllexport)
	#else
		#define TECH5_FINGER_EXPORT __declspec(dllimport)
	#endif
#else
	#define TECH5_FINGER_EXPORT
#endif


namespace Tech5Finger {
	
   // return SDK versin as a string
   char * getVersion();

   const static int32_t 
   SUCCESS                    =  0,
   LICENSE_FILE_NAME_INVALID  =  1,               
   LOW_MEMORY                 =  2,  
   IMAGE_TOO_BIG              =  3,       // image width > MAX_WIDTH  or image height > MAX_HEIGHT
   NO_IMAGE                   =  4,       // image size = 0, or pointer to the image = 0 or image processing cannot find any fingerprint image 
   IMAGE_PROCESSING_FAILED    =  5,       // image processing error  
   WRONG_FINGER_POS           =  6,       // wrong finger position was passed to the image processing 
   WSQ_INIT_FAILED            =  7,       // error of WSQ library initialization
   WRONG_WSQ_IMAGE            =  8,       // error of parsing WSQ image 
   WSQ_FAILED                 =  9,       // WSQ decompressing error
   VERIFICATION_FAILED        = 10,       // verification error  
   WRONG_TEMPLATE             = 11,       // fingerprint template parsing error
   NO_SAME_FINGERS            = 12,       // two 10-fingerprint templates have no fingerprint templates for same finger position
   WRONG_PARAMETRS            = 13,       // wrong matching parameters
   UNPACK_INIT_FAILED         = 14,       // error of unpack library initialization      
   ACCEL_CORRUPT              = 15,       // accelerator template is corrupted  
   NOT_SUPPORT_SSSE3          = 16,       // the CPU is not support SSSE3
   ACCEL_CALC_ERR             = 17,       // accel calculation error
   NO_FINGERS_GOOD_FOR_ACCEL  = 18,    
   ACCEL_MATCHING_FAILED      = 19,       // accelerator matching failed  
   DOUBLE_ID                  = 20,       // record with such ID already exist in database
   IDENTIFICATION_FAILED      = 21,       // identifation error 
   NO_LICENSE                 = 22,       // no license were installed (call the 'initLicense' functin first)
   MAX_GALLERY_SIZE_REACHED   = 23,       // the maximum allowed gallery size was reached 
   NO_SUCH_RECORD             = 24,       // there is no record with this ID in a gallery
   NOT_SUPPORT_SSE4_2         = 25,       // the cpu not support SSE4.2 instruction set

   UNKNOWN_EXCEPTION          = 100;     // unknown exception thrown
      

   struct candidates_string
   {
	   std::string uid;
	   float score;
   };


   struct RawImage
   {
      FINGERS    m_finger;   // finger position
      uint32_t   m_width ;   // image width, pixels 
      uint32_t   m_height;   // image height, pixels
      BYTE      *m_image ;   // image buffer
      
      RawImage()                                   
      {
         memset(this, 0, sizeof(RawImage));
      }
   };

   struct WsqImage
   {
      FINGERS    m_finger;           // finger position
      uint32_t   m_size;             // size of wsq image    
      BYTE      *m_wsq;              // wsq image buffer
      
      WsqImage()                                
      {
         memset(this, 0, sizeof(WsqImage));
      }
   };
   class TECH5_FINGER_EXPORT TemplateCreator
   {
   public:
      // create object of TemplateCreator. Return NULL in case of error
      static TemplateCreator*	create();                        
      // delete object of TemplateCreator
      static void cancel(TemplateCreator *&templateCreator);	
      virtual ~TemplateCreator() {}

      /*
      Function set license
      Parameters:
      licensePath (input) - path to the license file
	   Return value:
   	true if success and false otherwise
      */
      virtual bool initLicense(const char *licensePath) = 0;  
      /*
      Function build template from image in either RAW or WSQ format 
      Parameters:
      image        ( input) - fingerprint image in either RAW or WSQ format. Image should be 500 DPI, 256 greyscale leveles
      templateSize (output) - size of builded template
      quality      (output) - quality of fingerptint image
	   Return value:
   	SUCCESS if success and error code otherwise
      */
      virtual uint32_t createTemplate (RawImage &image, uint32_t &templateSize, uint8_t& quality) = 0;
      virtual uint32_t createTemplate (WsqImage &image, uint32_t &templateSize, uint8_t& quality) = 0;
      /*
      Function copy template builded by one of 'create_Template' function
      to the 'fpTemplate' buffer
      Parameters:
      fpTemplate   ( input) - pointer to the buffer where fingerprint template will be copied. 
                              Memory for that buffer should be allocated in application based on templateSize value, returned by 
                              'create_Template' function
      */
      virtual void  getTemplate (unsigned char *fpTemplate) = 0;
   };

   class TECH5_FINGER_EXPORT FpTemplateChecker
   {
   public:
      // create object of FpTemplateChecker. Return NULL in case of error
      static FpTemplateChecker*	create();                        
      // delete object of FpTemplateChecker
      static void cancel(FpTemplateChecker *&checker);	
      virtual ~FpTemplateChecker() {}
      /*
      Function check  fingerprint template - if it has a right format and in good health
      Parameters:
      fpTemplate   ( input) - fingerprint template for checking
	   Return value:
   	true if template is OK and false  otherwise
      */
      virtual bool check (BYTE *fpTemplate) = 0;
   };


   const static int32_t 
      MATCHING_SPEED_DEF = 3; 

// Matching parameters
struct MatchingParameters
{
   // search speed. The current valid value from 0 to 6
   unsigned int   searchSpeed;  
   // the maximum of the finger turn angle for all fingers expcept thumbs, (0...180 degree)
   unsigned int   maxAngle;     
   // the maximum of the finger turn angle for thumbs, (0...180 degree)
   unsigned int   maxAngleThumbs;     
   MATCHING_MODE  matchingMode;                 

   MatchingParameters()
   {
      searchSpeed                   = MATCHING_SPEED_DEF ;
      maxAngle                      = MAX_ANGLE_DEF      ;
      maxAngleThumbs                = MAX_ANGLE_DEF      ;
      matchingMode                  = NORMAL_MATCHING_MODE;
   }
};
   class TECH5_FINGER_EXPORT Matcher
   {
   public:
      //create object of Matcher. Return NULL in case of error
      static Matcher*	create();                        
      // delete object of TemplateCreator
      static void cancel(Matcher *&matcher);	
      virtual ~Matcher() {}

      /*
      Function set license
      Parameters:
      licensePath (input) - path to the license file
	   Return value:
   	true if success and false otherwise
      */
      virtual bool initLicense(const char *licensePath) = 0;  
      /*
      Function verify two records, each of them can have from 1 till 10 fingerprints
      Parameters:
      matchingParameters ( input) - matching parameters
      tpTemplate1        ( input) - first  10-finger template record. It can have from 1 till 10 fingerprint templates.
      tpTemplate2        ( input) - second 10-finger template record. It can have from 1 till 10 fingerprint templates.
      score              (output) - similarity of two records in a range 0...1
	   Return value:
   	SUCCESS if success and error code otherwise
      */
		virtual uint32_t verify_record(MatchingParameters &matchingParameters, TpTemplate &tpTemplate1, TpTemplate &tpTemplate2, double &score) = 0;
      /*
      Function insert record in memory database
      Parameters:
      id         ( input) - unique record ID. NOTE: id - slhould be numerical only!
      tpTemplate ( input) - 10-finger template record. It can have from 1 till 10 fingerprint templates.
	   Return value:
   	SUCCESS if success and error code otherwise
      */
      virtual uint32_t insertRecord (std::string &id,TpTemplate &tpTemplate                        ) = 0;
      /*
      Function delete record from memory database
      Parameters:
      id         ( input) - unique record ID. NOTE: id - slhould be numerical only!
	   Return value:
   	SUCCESS if success and error code otherwise
      */
      virtual uint32_t deleteRecord (std::string &id                                                ) = 0;
      /*
      Function return current gallery size
      */
      virtual uint64_t getFinalGallerySize(                                                         ) = 0;
      /*
      Function perform identification 
      Parameters:
      matchingParameters    ( input) - matching parameters
      probe                 ( input) - probe 10-finger record. It can have from 1 till 10 fingerprint templates.
      numberOfThreads       ( input) - number of threads that will be used in matching. 
                                       0 - means use all logical CPU (the valuse returned by omp_get_num_procs())
      candidate_list_length ( input) - size of output candidate list
      candidate_list        (output) - output candidate list
	   Return value:
   	SUCCESS if success and error code otherwise
      */
      virtual uint32_t identify_record(MatchingParameters             &matchingParameters    , 
                                       TpTemplate                     &probe                 , 
                                       const uint32_t                  numberOfThreads       , 
                                       const uint32_t                  candidate_list_length , 
                                       std::vector<candidates_string> &candidate_list               ) = 0;
   };

} // namespace Tech5Finger {


#endif // TECH5_GALLERY_MATCHER_SERVER_E_H

