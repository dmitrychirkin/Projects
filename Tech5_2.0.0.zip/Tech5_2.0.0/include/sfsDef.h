/*****************************************************************************
	sfsDef.h - define the common constants, structures, typedef and 
					enum for TECH5 Fingerprint System SFS)

*******************************************************************************/
 
#ifndef SFS_DEF_H__
#define SFS_DEF_H__

#include "win2lin.h"
/////////////////////////////////////////////////////////////////////////////////////////

// common values
#define S_MAX_DESCR_LEN 		               255   // maximum length of error description in characters
#define MAX_TEMPLATE_SIZE		         12 * 1024	// maximum size of the template ver. 7.3 in bytes
#define MAX_UNPACKED_TEMPLATE_SIZE		60 * 1024	// maximum size of the unpacked in memory template v.7.3 in bytes
#define MAX_TEMPLATE_SIZE_80	         25 * 1024	// maximum size of the template ver. 8.2 in bytes
#define MAX_TEMPLATE_SIZE_100	         50 * 1024	// maximum size of the template ver. 10 in bytes
#define MAX_TEMPLATE_SIZE_200	         25 * 1024	// maximum size of the template ver. 10 in bytes
#define MAX_PALM_TEMPLATE_SIZE	      250 * 1024	// maximum size of the pam template


// default DPI
#define DEF_DPI					   500

// minutiae reliability threshold
#define MIN_REL_THRES             18       


// change value from meter to inch
#ifndef M2INCH
#define M2INCH(x) (DWORD(x * 25.4 / 1000 + 0.5))  
#endif
// change value from DPI to PixelPerMeter
#ifndef DPI2PPM
#define DPI2PPM(x) ((DWORD)(x * 10000 / 254 + 0.5))  
#endif

//#define TIME_PROTECT

// PROTECT DATE
#define PROTECT_YEAR	   2015
#define PROTECT_MONTH	1
#define PROTECT_DAY		1


#endif // SFS_DEF_H__



