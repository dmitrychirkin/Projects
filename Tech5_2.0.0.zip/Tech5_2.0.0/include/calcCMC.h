#ifndef CALC_CMC_H_
#define CALC_CMC_H_

#include <vector>
#include <string>

#include <assert.h>
#include <stdint.h>

#include "coreSdk.h"
#include "stringToNumeric.h"

#define CMC_SIZE 100

typedef bool     (*IS_GENUINE_FUNC      ) (uint64_t probeRegNum, uint64_t  galleryRegNum);
typedef uint64_t (*GET_NUM_GENUINE_FUNC ) (uint64_t probeRegNum                         );
typedef uint64_t (*FILL_NUM_GENUINE_FUNC) (uint64_t probeRegNum, uint64_t *genuineregNum);
typedef void     (*GET_TP_NAME          ) (char *tpName        , uint64_t regNum        );

inline bool ifNeedCorrectPlace(uint64_t probeRegNum, uint64_t galleryRegNum, uint64_t genuineRegNum, IS_GENUINE_FUNC isGenuineFunc)
{
   if (galleryRegNum == probeRegNum)   // TP itself
      return true;
   if (galleryRegNum == genuineRegNum)   // Genuine
      return false;
   return isGenuineFunc (probeRegNum, galleryRegNum);
}

inline void reportResult(FILE *f, uint64_t probeRegNum, uint64_t galleryRegNum, float score, int place, int rlSize, GET_TP_NAME getTpName)
{
   char probeName[MAX_PATH], galleryName[MAX_PATH], msg[1024];
   getTpName (probeName   , probeRegNum );
   getTpName (galleryName, galleryRegNum);
   if (place == -1) sprintf (msg, "%-15s %-15s %6.4f,   >%3d", probeName, galleryName, score, rlSize);
   else             sprintf (msg, "%-15s %-15s %6.4f,  %3d"  , probeName, galleryName, score, place );
   printf (    "%s\n", msg);
   fprintf (f, "%s\n", msg);
}


inline void calcCMC (FILE* cmcLog, uint64_t probeRegNum, std::vector<candidates_string>  candidate_list, int placeArray[CMC_SIZE], int &placeMoreRlSize, 
                     IS_GENUINE_FUNC isGenuineFunc,GET_NUM_GENUINE_FUNC getNumGenuineFunc, FILL_NUM_GENUINE_FUNC fillNumGenuineFunc, GET_TP_NAME getTpName,
                     int maxRlSize)
{
   int place = -1;
   uint64_t numGenuine = getNumGenuineFunc(probeRegNum);
   uint64_t *genuineRegNum = new uint64_t [numGenuine];

   fillNumGenuineFunc (probeRegNum, genuineRegNum);
   uint64_t genRegNum = 0;
   int correct = 0;
   float genuineScore = 0;
   uint64_t galleryRegNum = 0;

   for(uint64_t k = 0; k < numGenuine; k++)
   {
      genRegNum = genuineRegNum[k];
      place = -1;
      genuineScore = 0;
      correct = 0;
      int rlSize = (int)candidate_list.size();
      for(int m = 0; m < rlSize; m++)
      {
         galleryRegNum = getIdFromString (candidate_list[m].uid.c_str());  
         if (ifNeedCorrectPlace (probeRegNum, galleryRegNum, genRegNum, isGenuineFunc))
         { 
            correct++;
            continue;
         }
         if (galleryRegNum == genRegNum)  // it's genuine record
         {
            genuineScore = candidate_list[m].score;
            for(int i = m + 1; i < rlSize; i++)  // check if in recommended list there are more records with same score
            {
               if (candidate_list[i].score < genuineScore)
                  break;
               galleryRegNum = getIdFromString(candidate_list[i].uid);
               if (isGenuineFunc ( probeRegNum, galleryRegNum)) // genuine
                  continue;
               m++;                    // impostor record with same score
            }
            place = (int)m + 1 - correct;
            break;
         }
      }
      if (!genuineScore) 
         place = -1;
      reportResult (cmcLog, probeRegNum, genRegNum, genuineScore, place, maxRlSize, getTpName);


      // collect statistics of places
      if (place == -1 || place > CMC_SIZE)
         placeMoreRlSize++;
      else if (place <= CMC_SIZE)
         placeArray[place - 1]++;
   }
   if (genuineRegNum) delete [] genuineRegNum, genuineRegNum = NULL;
}

inline void reportCmc (FILE *log, int *placeArray, int placeMoreRlSize, int rlSize)
{
   assert(log && placeArray);

   char msg[1024];
   float M[CMC_SIZE];
   float w = 0;
   int totalCount = 0;
   for(int j = 0; j < CMC_SIZE; j++)
      totalCount += placeArray[j];
   totalCount += placeMoreRlSize;

   if (!totalCount)
   {
      printf ("totalCount = %d\n", totalCount);
      return;
   }

   for(int j = 0; j < CMC_SIZE; j++)
   {
      M[j] = (float)placeArray[j] * 100 / totalCount;
      w += M[j] / (j + 1); 
   }
   for(int i = 1; i < CMC_SIZE; i++)
      M[i] += M[i - 1];

   fprintf (log, "\n\n");
   sprintf (msg,  "w = %4.2f\n", w); 
   printf ("%s\n", msg);
   fprintf (log, "%s\n", msg);
   for(int k = 0; k < 20; k++)
   {
      sprintf (msg,  "Number of TP on %03d place = %06d M%02d = %4.2f%%\n", k + 1, placeArray[k], k + 1, M[k]); 
      printf ("%s", msg);
      fprintf (log, "%s", msg);
   }
   sprintf (msg, "\nNumber of TP on more than %d place = %06d (%4.2f%%)\n", rlSize - 1, placeMoreRlSize, (float)placeMoreRlSize * 100 / totalCount); 
   printf (      "%s", msg);
   fprintf (log, "%s", msg);
}



#endif