#ifndef HARDWARE_BIND_CLASS
#define HARDWARE_BIND_CLASS

#include "hardware_common.h"

class Tech5_Hardware_Protect
{
private:
	char m_serial_number[_MAX_SERIAL_COUNT];
	char macAddress[_MAX_ADAPTER_COUNT][_MAC_LENGTH];
	bool getAdapterMACAddress(char address[][_MAC_LENGTH],int& count);
	bool getAdapterMACAddress2(char address[][_MAC_LENGTH],int& count);
	int getAdaptersNames(char address[][48]);
	bool IsHardware(wchar_t*  classname, char* instanceId);
	int m_adapters_count;
	int m_instance_for_count_request;
	int m_instance;
	wchar_t* m_instance_guid;
	unsigned char* m_additional_data;
	unsigned long m_additional_data_length;
	unsigned char* m_memory_file;
	unsigned long  m_memory_file_length;
public:
	Tech5_Hardware_Protect(TECH5_PRODUCTS product);
	~Tech5_Hardware_Protect();
	bool create_request_file(wchar_t* request_filename, bool is_trial = false);
	bool initLicense(wchar_t* license_filename);
        bool parseLicense(bool is_trial = false);
	bool check_protect(bool is_trial = false);
	void setInstanceInLicense(int count = 4) { m_instance_for_count_request = count;}
	int getInstanceCountFromLicense(){return m_instance;}
	unsigned long getAdditionalBufferLength() { return m_additional_data_length;}
	void getAdditionalBuffer(unsigned char* addBuffer);
	wchar_t* getinstanceUUID() { return m_instance_guid;}
};

#endif