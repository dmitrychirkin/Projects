#ifndef TP_ACCEL_H
#define TP_ACCEL_H

#include "common.h"
#include "accelMatch.h"

namespace accelMatch{

#pragma pack (push, 1)
struct P_PACKED_1 TpAccelHeader
{
   BYTE              m_version;             // version of accelerator  
   PersonalData      m_personalData;
   WORD              m_accelOffset[10];     // offset to the begin of accelerator for corresponded finger
                                            // in accelBuffer            
                                            // NULL means there is no accelerator for corresponded finger
   DWORD             m_size;                // a real size of 10-finger accelerator   
   BYTE              m_reserved[7];         // structure should be alligned to 16 
   
   TpAccelHeader()
   {
      clear();
   }
   void clear()
   {
      m_personalData.clear();
      m_version = 10;
      memset (m_accelOffset, 0, sizeof(m_accelOffset));
      m_size = 0;
      memset (m_reserved,    0, sizeof(m_reserved));
   }
};
#pragma pack (pop)

struct  TpAccel                           // tenprint template in accelerator format
{
   BYTE           *m_accel [10];         
   PersonalData   *m_personalData;

   TpAccel()
   {
      m_personalData = NULL;
      for(int finger = 0; finger < 10; finger++)
         m_accel[finger] = NULL;
   }
   TpAccel(const TpAccel& tpAccel)
   {
      *this = tpAccel;
   }
   TpAccel& operator= (const TpAccel& tpAccel)
   {
      for(int i = 0; i < 10; i++)
         this->m_accel[i] = tpAccel.m_accel[i];
      m_personalData = tpAccel.m_personalData;
      return *this;
   }

   // Save inforamtion about all 10 accelerators and personal data in buffer.
   // Memory for this buffer should be prevoiosly allocated
   // use getSize() function for get a real required size
   // or getMaxSize() function for get a maximum possible size
   // memory for buffer should be alligned to 16 
   // Return a real size of data copied to buffer
//   DWORD save2Buffer (BYTE *buffer);  
   // Return a real size of 10-finger accelerator
   DWORD getSize();      
   // Return a real size of accelerator for corresponded finger
   DWORD getSize(int finger);      
   // Read inforamtion about all 10 accel from buffer
   // Memory is not allocated. Will be used memory allocated for buffer
   // Memory for buffer should be alligned to 16 
   bool readFromBuffer (BYTE *buffer);      
   // save information about all 10 accelerators and personal data in buffer.
   // memory for this buffer should be prevoiosly allocated
   // use getSize() function for get a real required size
   // or allocate getMaximumAccelSize() bytes memory
   // return a real size of data copied to buffer
   DWORD save2Buffer (BYTE *buffer);
};

} // namespace accelMatch{

#endif // TP_ACCEL_H
