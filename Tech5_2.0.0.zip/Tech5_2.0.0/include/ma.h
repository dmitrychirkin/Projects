/*****************************************************************************
	ma.h - header file for matching algorithm (MA) of Core Matching SDK

	The Core Matching SDK is the high-level tool, intended for easy creating
    of your own scalable biometric applications that use the person's fingerprint 
	for identification or verification purpose. 

******************************************************************************
	
	Copyright (C) 2005 Sonda Technologies Ltd.
	
	Version 1.1.0 of 14.05.2005
	    
*******************************************************************************/
#ifndef MA_H__
#define MA_H__

#include "coreSdk.h"
#include "core_err.h"



/******************************************************************
          Matching Algorithm class
******************************************************************/
class Compare;
class Fs;

class Ma
{
	Compare *m_compare;
	Fs      *m_fs;
   bool     m_isProbeLoaded;
   bool     m_init;

public:
	Ma();
	~Ma();

	/* 
	 Initialize work with Ma class functions
	 This function should be called before call any other function of this class
    Parameters:
	 Function returns MA_OK - if function succeeds, error code - otherwise
	*/
	int init();
   /* 
      Initialize work with Ma class
      In differ from 'init' function it take the protection data
      This function (of 'init' function)should be called first before call 
      any other function
      Parameters:
      protect      (input) - pointer to 512 byte buffer with protection data
      Return value:
      The function returns IP_OK - if function succeeds, error code - otherwise
   */
   int initEx (BYTE protect[MAX_PROTECT_LEN]);

 	// allocate memory for template
	static int allocateTemplate(BYTE *&templ);
	// free memory that was earlier allocate by 'allocateTemplate' function
	static int freeTemplate    (BYTE *&templ);


	/*
	Compares two templates
	function returns MA_OK - if function succeeds, error code - otherwise
	param       (input)  - search parameters
                          NOTE: because finger is not known, it uses maxAngle (not maxAngleThumb)
                          for angle tolerance
	templ1      (input)  - first template for matching 
	templ2      (input)  - second template for matching 
   similarity  (output) - variable that receives the value that shows 
				              how two set of templates similarity one to other 
                          in a range 0...MAX_SCORE
	matchResult (output) - the array of match result details. The item in the 
                          array are filled in the same order as finger pairs 
                          matching. If is is NULL, it not used.
	*/
	int match (SearchParam &param, 
              BYTE        *templ1, 
              BYTE        *templ2, 
              int         &similarity,
              MatchResult *matchResult = 0);

   /*
	Next two functions have the same functionality as 'match' function but 
	allows you to perform the 1:many search more quickly.
	At first you should call 'loadTemplate' function for loading the first template
	and then call 'matchEx' function for match with each of second template
	*/
	int  loadTemplate(BYTE        *templ1);
	int  matchEx     (SearchParam &param, 
                     BYTE        *templ2,
                     int         &similarity,
                     MatchResult *matchResult = 0);
 	/*
	Compare two TP
	function returns MA_OK - if function succeeds, error code - otherwise
	param         (input)  - search parameters
	probe         (input)  - probe TP
	gallery       (input)  - gallery TP
   matchResultTT (output) - the result of TP-TP matching
	*/
   int matchTT (SearchParam &param, TpSonda &probe, TpSonda &gallery, MatchResultTT &matchResultTT);
   /*
	Next two functions have the same functionality as 'matchTT' function but 
	allows you to perform the 1:many search more quickly.
	At first you should call 'loadTT' function for loading the first TP
	and then call 'matchTTEx' function for match with each of second TP
   */
	int loadTT    (TpSonda &probe);
	int matchTTex (SearchParam &param, TpSonda &gallery, MatchResultTT &matchResultTT);

 	/*
	Perfrom TP-TP identification 
	function returns MA_OK - if function succeeds, error code - otherwise
   param       (input)  - parameter of matching  
   probe       (input)  - probe TP 
   gallery    	(input)  - array of gallery TP
   gallerySize (input)  - size of gallery array
   rl          (input)  - pointer to recommended list array. Memory should be allocated in application
   sizeRl      (input)  - size of recommended list array 
	*/
	int identifyTT (SearchParam &param, TpSonda &probe, TpSonda *gallery, int gallerySize, RL *rl, int sizeRl);
   /*
	   Perfrom 1-finger identification 
	   function returns MA_OK - if function succeeds, error code - otherwise
      param       (input)  - parameter of matching  
      probe       (input)  - probe templte
      gallery    	(input)  - array of gallery templates
      gallerySize (input)  - size of gallery array
      rl          (input)  - pointer to recommended list array. Memory should be allocated in application
      sizeRl      (input)  - size of recommended list array 
   */
   int identify (SearchParam &param, BYTE *probe, BYTE **gallery, int gallerySize, RL *rl, int sizeRl);


private:
   // check value of SearchParam items for acceptable value
   bool checkSearchParam(SearchParam &param);
   /* 
   Return calculated fusion score
   Parameters:
   fusionMode    (input) - fusion mode
   int numItems  (input) - size of score array
   numRealScore  (input) - number of really filled items in score array
   */
   int calcFusionScore(SearchParam &searchParam, unsigned int numItems, unsigned int numRealScore, int *score);

 	/*
	Compare TP with earlier loaded by 'loadTT' probe TP 
   in    matchingMode = CHECK_MIX_FINGER_MATCHING_MODE
	function returns MA_OK - if function succeeds, error code - otherwise
	param         (input)  - search parameters
	templSet      (input)  - gallery TP
   matchResultTT (output) - the result of TP-TP matching
	*/
   int fingerMixMatchTTex (SearchParam &param, TemplateData templSet[10], MatchResultTT &matchResultTT);
 	/*
	Compare TP with earlier loaded by 'loadTT' probe TP 
   in matchingMode = CHECK_MIX_SLAP_MATCHING_MODE
	function returns MA_OK - if function succeeds, error code - otherwise
	param         (input)  - search parameters
	gallery       (input)  - gallery TP
   matchResultTT (output) - the result of TP-TP matching
	*/
   int slapMixMatchTTex (SearchParam &param, TpSonda &gallery, MatchResultTT &matchResultTT);
 	/*
	Compare TP with earlier loaded by 'loadTT' probe TP 
   in matchingMode = CHECK_MIX_HAND_MATCHING_MODE
	function returns MA_OK - if function succeeds, error code - otherwise
	param         (input)  - search parameters
	gallery       (input)  - gallery TP
   matchResultTT (output) - the result of TP-TP matching
	*/
   int handMixMatchTTex (SearchParam &param, TpSonda &gallery, MatchResultTT &matchResultTT);
 	/*
	match TP with probe TP earlier loaded by 'loadTT'
	function returns MA_OK - if function succeeds, error code - otherwise
	param         (input)  - search parameters
	templSet      (input)  - gallery TP
   matchResultTT (output) - the result of TP-TP matching
	*/
   int compareTT (SearchParam &param, TemplateData templSet[10], MatchResultTT &matchResultTT);

};

#endif // MA_H__
